Elangovan vs State on 25 October, 2017
Bench: P.N.Prakash, C.V.Karthikeyan
IN THE HIGH COURT OF JUDICATURE AT MADRAS
                RESERVED ON     :       26.08.2017
                PRONOUNCED ON   :        25.10.2017
CORAM:
THE HON'BLE MR.JUSTICE P.N.PRAKASH
AND
THE HON'BLE MR.JUSTICE C.V.KARTHIKEYAN
Referred Trial No.2 of 2017
and
Criminal Appeal Nos.402 and 465 of 2017
Referred Trial No.2 of 2017:
State 
represented by the Deputy Superintendent of Police
Namakkal                                         Complainant
vs.
Kamaraj 
Elangovan                                Accused (A2 and A3)
Criminal Appeal Nos.402 & 465 of 2017: 
Elangovan               Appellant in Crl.A. No. 402 of 2017
Kamaraj                 Appellant in Crl.A. No.465 of 2017
vs.
State 
represented by the Deputy Superintendent of Police
Namakkal Police Station
Namakkal District               Respondent in both the appeals
        Referred Trial numbered under Section 366 of the Cr.P.C. to go into the question of confirmation of the death sentence awarded by the Additional District and Sessions Court, Namakkal in S.C.No.94 of 2012 on 02.06.2017.
        Criminal Appeal No.402 of 2017 filed under Section 374(2) Cr.P.C. to call for the records relating to the judgment dated 02.06.2017 in S.C.No.94 of 2012 on the file of the Additional District and Sessions Court, Namakkal and set aside the same as illegal.
        Criminal Appeal No.465 of 2017 filed under Section 374(2) Cr.P.C. to set aside the conviction order dated 02.06.2017 passed against the appellant in S.C. No.94 of 2012 on the file of the Additional District and Sessions Court, Namakkal.Elangovan vs State on 25 October, 2017

In Referred Trial:
        For the State           Mr.R.Rajarathinam
                                Public Prosecutor 
                                assisted by Mr. C. Emalias
                                Addl. Public Prosecutor
        For A2                  Mr. R. Rajasekaran
        For A3                  Mr. M. Subash Babu
In Criminal Appeals:
        For A2                  Mr. R. Rajasekaran
                                (Crl.A.No.465 /2017)
        For A3                  Mr. M. Subash Babu
                                (Crl.A. No.402 of 2017)
        For respondent in               Mr.R.Rajarathinam
        both the appeals                Public Prosecutor  
                                assisted by 
                                Mr. C. Emalias
                                Addl. Public Prosecutor                 
COMMON JUDGMENT
P.N. PRAKASH, J. & C.V.KARTHIKEYAN, J.
The reference in R.T. No.2 of 2017 has been made by the learned Additional District and Sessions
Judge, Namakkal, under Section 366 Cr.P.C., seeking confirmation of the capital punishment
imposed upon Kamaraj (A2) and Elangovan (A3) vide judgment dated 02.06.2017 in S.C. No. 94 of
2012. Kamaraj (A2) and Elangovan (A3) have independently preferred Criminal Appeal Nos.465 of
2017 and 402 of 2017 respectively, challenging their convictions and sentences.
2 The case of the prosecution, culled out from the materials on record, is as follows:
2.1 This is a case of triple murder for gain. Umadevi (P.W.1) and her husband Dr.
Sundaram (P.W.4) are the owners of Annai Eye Hospital and Annai Opticals in Fort
Road, Namakkal. Dr.Sundaram (P.W.4) is an Ophthalmologist by profession and his
wife Umadevi (P.W.1) manages the hospital. The couple live in the ground floor of the
hospital and they have no children. The couple own an independent bungalow a
kilometre away in Mullai Nagar. The father of Umadevi (P.W.1) died sometime in
1977 leaving behind his wife Visalakshi (D1), one son by name Sivagurunathan and
three daughters, viz., Sathyavathi (D3), Parvathy (P.W.7) and Umadevi (P.W.1).
Sathyavathi (D3) was married to Dr. Thirumalaiswamy (P.W.8), an E.N.T. specialist
and through the said wedlock, she begot a daughter Sindhu (D2), who also became a
medical professional. As Sathyavathi (D3) got estranged from her husband
Dr.Thirumalaiswamy (P.W.8), she started living separately with her daughter Dr.
Sindhu (D2). Dr. Sindhu (D2) was married to Dr.Balasubramaniam (P.W.9), an
Orthopaedic Surgeon and they have a daughter named Abinandhini, aged about 6Elangovan vs State on 25 October, 2017

years.
2.2 It appears that the sisters, viz., Sathyavathi (D3), Umadevi (P.W.1) and Parvathi (P.W.7) were
very close and since Umadevi (P.W.1) was issueless, she was very fond of the daughter of her sister
Sathyavathi (D3), viz., Dr. Sindhu (D2) and they treated Dr. Sindhu (D2) as their own child. Since
Sathyavathi (D3) was estranged from her husband, the family decided to house Visalakshi (D1) and
Sathyavathi (D3) in the house of Umadevi (P.W.1) at Mullai Nagar. Since Dr. Sindhu (D2) was in
active practice, she left her child Abinandhini in the care and custody of her mother Sathyavathi
(D3) and grandmother Visalakshi (D1) in their Mullai Nagar residence.
2.3 Ten days prior to the incident, Dr. Sindhu (D2) came to the Mullai Nagar residence to be with
her mother Sathyavathi (D3) and daughter Abinandhini. A gruesome tragedy struck the family on
13.10.2011 between 3.15 p.m and 3.30 p.m., when two persons entered into the house. Those two
persons, after tying up the inmates, slit the neck of Visalakshi (D1), Dr. Sindhu (D2) and Sathyavathi
(D3) and left with a huge haul of gold jewellery from them. There was a little life left in Sathyavathi
(D3) and so, she managed to come out of the house and entered the house of her neighbour
Sampathkumar (P.W.2). Sampathkumar (P.W.2) and his wife were aghast on seeing Sathyavathi
(D3) bleeding all over and unable to speak, as she was having cut injuries on her neck and left wrist.
Sathyavathi (D3) wanted to write something and so, Sampathkumar (P.W.2) gave her a scrap of
paper, on which, Sathyavathi (D3) wrote in Tamil as follows:
mk;kh vd;d Mdhh;/ rpe;Jit fhg;ghw;W';fs;/ mgpia !;TypypUe;J Tl;o tut[k;/ ,uz;L
ngh;/ 3/30 kzp/ rpe;J capnuhL ,Uf;fpwjh> She left her blood stains on the paper.
2.4 Immediately, Sampathkumar (P.W.2) and his wife went to the next door to see
what had happened and at that time, Umadevi (P.W.1) and her husband Dr.
Sundaram (P.W.4) were entering into the house. Umadevi (P.W.1) was shocked to see
her mother Visalakshi (D1) beneath the staircase, lying in a pool of blood, with cut
injuries in her neck and with a lungi tied around her neck. Thereafter, she saw her
niece Dr. Sindhu (D2) in the dining hall, lying in a pool of blood, with cut injuries in
her neck, with her hands and legs tied. This ghastly scene terrified them and when
they came out, they were called by Sampathkumar (P.W.2), who told them that
Sathyavathi (D3) is in his house.
2.5 Umadevi (P.W.1) and her husband Dr. Sundaram (P.W.4) rushed to the house of
Sampathkumar (P.W.2), where, they found Sathyavathi (D3) in a pathetic situation.
Sampathkumar (P.W.2) called 08 ambulance and Sathyavathi (D3) was rushed
immediately to the Government Hospital and from there, she was shifted to
Dr.Aravind Hospital for intensive treatment. Sathyavathi (D3) lost her consciousness
and was in a critical condition at Dr.Aravind Hospital till 31.10.2011 under the
treatment of Dr. Mani (P.W. 38) and thereafter, when her condition started
deteriorating further, she was taken to K.M.H. Hospital in Coimbatore, where, she
ultimately breathed her last on 14.11.2011.Elangovan vs State on 25 October, 2017

2.6 Noticing that the jewels worn by her mother Visalakshi (D1), Dr.Sindhu (D2) and
Sathyavathi (D3) were missing, it became apparent to Umadevi (P.W.1) that it was a
murder for gain. Hence, she lodged a written complaint (Ex.P.1) enclosing the
blood-stained note (Ex.P.2) left by Sathyavathi (D3), based on which, Subramaniam
(P.W.52), Circle Inspector of Namakkal Police Station registered an F.I.R. (Ex.P.47)
in Cr. No.1636 of 2011 on 13.10.2011 at 5.00 p.m. for the offences u/s 302 and 392
IPC. The original complaint (Ex.P.1), the blood-stained note (Ex.P.2) written by
Sathyavathi (D3) and the printed FIR (Ex.P.47), reached the jurisdictional Magistrate
at 7.00 p.m. on 13.10.2011, as could be seen from the endorsement of the Magistrate
thereon.
3 In the complaint (Ex.P.1), Umadevi (P.W.1) has given the list of missing jewellery which is as
follows:
Jewellery of Visalakshi (D1):
= sovereign gold ring Jewellery of Dr. Sindhu (D2):
9 = sovereigns of thali chain 2 bangles each weighing 2 sovereigns 2 gold rings
weighing = sovereign each a pair of ear rings weighing = sovereign each Jewellery of
Sathyavathi (D3):
1 thali chain weighing 7 = sovereigns 2 bangles weighing 2 sovereigns each 2 rings
weighing = sovereign each Thus, totally, 28 sovereigns of gold jewellery were found
missing from the deceased trio.
4 Investigation of the case in Namakkal P.S. Cr. No.1636 of 2011 was taken over by Thamaraiselvan
(P.W.57), Inspector of Police, Rasipuram Police Station, who was in charge of Namakkal Police
Station at the relevant point of time, who went to the place of occurrence at the residence of the
deceased in Mullai Nagar around 6.30 p.m. on 13.10.2011 and in the presence of Ravichandran
(P.W.10), Village Administrative Officer and Subramaniam (P.W.11), Village Assistant, prepared
Observation Mahazar (Ex.P.4) and rough sketch (Ex.P.50). In the scene of occurrence, he recovered
the following articles under the cover of mahazar (Ex.P.5):
A sharp edged knife (M.O.1) Tiles with and without blood stains (M.O.2) from the
place where the body of Visalakshi (D1) was found Tiles with and without blood
stains (M.O.3) from the place where the body of Dr. Sindhu (D2) was found Lungi
cloth (M.O.4) from the neck of Visalakshi (D1) Lungi cloth (M.O.5) tied around the
neck of Dr. Sindhu (D2) Lungi cloth (M.O.6) tied around the neck of the injured
Sathyavathi (D3) Blood samples of Dr. Sindhu (D2) and Visalakshi (D1) (M.O.7.) The
seized items were sent to the jurisdictional Court on 14.10.2011 at 6.00 p.m., as could
be seen from the endorsement of the Magistrate thereon.Elangovan vs State on 25 October, 2017

5 At the request of the Investigating Officer, Karuppannan (P.W.42), finger print
expert, came to the house of occurrence on 13.10.2011 and from the inner side of the
main door, he lifted three finger prints and from the wall tiles in the kitchen, he lifted
two finger prints and compared them with the finger prints of the inmates of the
house and also with the data available with the Finger Print Bureau. The two finger
prints which were lifted from the wall tiles of the kitchen tallied with those of
Sathyavathi (D3). The three finger prints which were lifted from the inner side of the
main door, tallied with those of a known offender by name Santhanam, S/o
Vijayaram, who was concerned in Vellore P.S. Cr. No.843 of 2011 under Sections 457
and 380 IPC. The memorandum prepared by Karuppannan (P.W.42) relating to
lifting of finger prints from the scene of occurrence was marked as Ex.P.32 and his
opinion was marked as Ex.P.31 and the memorandum submitted by him to the
Judicial Magistrate No.I, Namakkal, was marked as Ex.P.30.
6 On the orders of the Superintendent of Police, Namakkal dated 14.10.2011, the
investigation of the case was transferred to Parameswara (P.W.58), Deputy
Superintendent of Police, who was assisted by Subramaniam (P.W.59), who
ultimately filed the final report in this case.
7 Thamaraiselvan (P.W.57), the Inspector of Police, conducted inquest over the
bodies Visalakshi (D1) and Dr. Sindhu (D2) and sent the bodies to the Government
Hospital for post-mortem.
8 Dr. Karunanidhi (P.W.39) conducted post-mortem on the body of Visalakshi (D1)
and issued post-mortem certificate (Ex.P.22). He has noted in his evidence and in the
post-mortem certificate (Ex.P.22) the following external injuries on the body of
Visalakshi (D1):
 Lacerated injury around right side neck to left side neck. Size 15 x 6 x 3 cm. (Below
right ear (?) to middle of left side clavicle bone with Tracheal cut injury.
2 Cut injury over right shoulder back size 10 x 5 x 3 cm. in length.
3 Right shoulder back (n.c.) 3 x .2 x 1 cm.
4 Lacerated injury (n.c.) right occipital region 7 x .3 x bone depth.
5 Lacerated injury left side face (near left ear) size 3 x .1 x 1 cm.
6. Abrasion over right ear pinna Skull: intact; Membrane: intact; Brain: normal;
hyoid bone preserved. Thorax: Ribs intact; Lungs: Pale; Heart: Chambers empty;
stomach: undigested food particle around 250 gm. present; Intestine: distended.
Liver, kidney, spleen organs-Pale; Bladder: empty. Uterus: empty. After getting the
viscera and hyoid bone reports, he has opined that Visalakshi (D1) would have diedElangovan vs State on 25 October, 2017

on account of excessive blood loss due to the injuries sustained by her and shock. In
his evidence before the Court, he has stated that the injuries could have been caused
by knives (M.O.s 1 and 8) which were shown to him.
9 Dr. Chitra, (P.W.40) performed autopsy on the body of Dr.Sindhu (D2) and issued post-mortem
certificate (Ex.P.25). In her evidence before the Court and in the post-mortem certificate (Ex.P.25),
she has noted the following injuries:
Appearances found at post-mortem:
Moderately built and nourished female body lies on its back clothes soaked with
(n.c.). Eyes-partially opened, mouth closed. Legs tied, hands tied in the back.
External examination:
1. An incised wound in front of the neck measuring about 75 inch length, 2 inch
breadth. 1.5 inch depth at the level of the thyroid cartilage extending from right side 5
cm below the right ear lobe to left side 5 cm below the left angle of the mandible.
Margins clear cut. Trachea opened. Great vessels in front of the neck opened. Muscle
in the anterior compartment of the neck cut.
2. Incised wound 2.5 inch x 0.5 inch x 0.5 inch in front of the neck above the previous
one.
3. Linear abrasion 3.5 inch (l) x 0.5 inch (b) near left shoulder.
4. Linear abrasion 3 inch x 0.5 inch (b) present 5 cm. below the left clavicle.
Internal examination:
Skull: intact; membrane intact; back of the skull: intact, Brain: Normal, Thorax: ribs
intact.
Lungs: Pale, intact; Heart: Chamber empty. Hyoid Bone-preserved. Liver, spleen,
kidney-pale and intact. Intestine distended with gas; stomach: (n.c.) 250 ml. of
undigested food present: bladder empty, uterus-empty; spinal cord-intact. Organs
preserved for chemical analysis: 1. Stomach and its content 2. Intestine and its
content 3. liver, 4. Kidney, 5. Preservative, 6. Hyoid Bone, 7. Vaginal swab. After
obtaining viscera and Hyoid bone report, Dr. Chitra (P.W.40), has given her opinion
in Ex.P.24 as to the cause of death as follows:
I am of the opinion that the deceased would appear to have died of shock with
haemorrhage due to major vessels of the neck cut injury and trachea opened and died
about 18-24 hours prior to PM examination. 10 As stated above, Sathyavathi (D3)Elangovan vs State on 25 October, 2017

was first rushed to the Government Hospital at Namakkal, where, she was examined
by Dr.Baskar (P.W. 50), who made entries in the Accident Register, the copy of which
his Ex.P.39. He has noted the following two injuries:
Nature of injuries/treatment:
1 Lacerated wound in left arm exposive wrist joint bone 2 Cut injury in neck 8 cm x
exposive the (n.c.) Further, he advised that Sathyavathi (D3) should be admitted as
in-patient, but, her relatives stated that they would take her to a private hospital for
treatment and therefore, she was rushed to Aravind Hospital in a very critical
condition, where, she was treated by Dr.Mani (P.W.38) till 31.10.2011. Since she had
to be kept on ventilator, she was shifted from Aravind Hospital to K.M.H. Hospital in
Coimbatore. Dr.Mani (P.W.38) issued discharge summary (Ex.P.20).
Dr.Kesavamoorthy (P.W.53) of K.M.H. Hospital at Coimbatore, admitted Sathyavathi
(D3) in the I.C.U. and gave her treatment till 14.11.2011, despite which, he was not
able to save her. Sathyavathi (D3) died around 12.50 p.m. on 14.11.2011.
Subramaniam (P.W.59) conducted inquest over the body of Sathyavathi (D3) and the
inquest report is (Ex.P.59). Thereafter, the body of Sathyavathi (D3) was sent to the
Government Medical College and Hospital, Coimbatore, where, Dr. Jayasingh
(P.W.56) performed autopsy over the body of Sathyavathy (D3) and issued
post-mortem certificate (Ex.P.49). Dr. Jayasingh (P.W.56), in his evidence and in the
post-mortem certificate (Ex.P.49), has noted the following ante-mortem injuries:
The following ante mortem injuries noted on the body:
1 Old healed liner scar 8 cm. in length noted over top of left shoulder, 5 cm in length
noted over lateral aspect of left lower arm and 4 cm in length noted over back of left
upper forearm.
2 Recently removed sutured healed scar 6 cm in length noted over back of left lower
forearm, 7 cm. in length noted over back of left wrist, 6 cm in length noted over back
of left hand and 4 cm in length noted over back of lower part of left hand.
3 Infected wound 3 x 2 cm. noted over lateral aspect of left index finger.
4 Recently healed wound 3 cm. in length noted over inner aspect of right thigh,
K.wire fixation noted on lateral aspect of left wrist joint.
5 Healed scar 15 cm. in length noted over back of upper chest at the level of T-3
vertebra.
6 Bed sore noted over right gluteal region.
7 Horizontal linear scar 15 cm in length noted over middle of neck.Elangovan vs State on 25 October, 2017

On dissection of Neck: Front and right side neck muscle found sutured measuring 10
cm in length. Right external jungular vein found sutured. Hyoid bone intact. Trachea
found recently healed sutured at the level of 1 cm. below the vocal cord. In his final
opinion, Dr. Jayasingh (P.W.56) has stated as follows:
OPINION: The deceased would appear to have died of neck injury and its
complication. Viscera does not contain any poison. 11 Since the police were clueless,
search parties were set up to apprehend the suspects, but, to no avail. Breakthrough
came in this case with the voluntary appearance of Elangovan (A3) on 17.01.2012
before Balu @ Balasubramaniam (P.W.21), a Congress politician, to whom Elangovan
(A3) confessed the commission of not only the present offence, but also the murder
for gain of two ladies and one child on 28.12.2011 within the jurisdiction of Karur
District, in which, he and two others, viz., Santhanam @ Manoj Kumar (A1) and
Kamaraj (A2) were involved.
12 Balu @ Balasubramaniam (P.W.21) produced Elangovan (A3) before Parameswara
(P.W.58), Investigating Officer. Elangovan (A3) made a startling disclosure about his
involvement not only in this case, but also in the triple murder case in Karur District
and a robbery case in Paramathi limits. The statement of Elangovan (A3) was
recorded in the presence of Balu @ Balasubramaniam (P.W.21) and Murugesan
(P.W.30). The police formed a special team comprising Parameswara (P.W.58),
Subramanian (P.W.59), Shanmugam (P.W.55) and other policemen to effect seizures
not only in this case, but also in the other two cases.
13 On the showing of Elangovan (A3), the Investigating Officer apprehended
Santhanam @ Manoj Kumar (A1) and Kamaraj (A2) around 9.45 p.m. on 17.01.2012.
Santhanam @ Manoj Kumar (A1) and Kamaraj (A2) were interrogated and they
disclosed certain facts, pursuant to which, discoveries were made and therefore, it
becomes relevant under Section 27 of the Evidence Act.
14 Pursuant to the disclosure of Santhanam @ Manoj Kumar (A1) that he had handed
over the jewellery relating to the present case to his friend Vimal Raj (P.W.25), who,
in turn, had sold it to Saravanan (P.W.27), who has a jewellery shop in Vaniyambadi,
the police took Vimal Raj (P.W.25) and Rajesh (P.W.26) to the shop of Saravanan
(P.W.27), from where, they recovered one thali chain and five rings (M.O.13 series)
under the cover of mahazar (Ex.P.10) attested by Sivabalan (P.W.23) and Selvaraj
(P.W.24). On further disclosure of Santhanam @ Manoj Kumar (A1) that he handed
over a part of the jewellery to his friend Kumar (P.W.28), the police party went to the
house of Kumar (P.W.28) and recovered a 7= sovereign thali chain (M.O.14) under
the cover of mahazar (Ex.P.16) in the presence of Ravi (P.W.29) and Venugopal (P.W.
31). Exs.P.10 and P.16 reached the jurisdictional Court on 18.01.2012, as could be
seen from the endorsement of the Magistrate thereon.Elangovan vs State on 25 October, 2017

15 From the disclosure made by Kamaraj (A2), the police recovered a knife (M.O.8)
and a blood-stained jeans pants (M.O.12) under the cover of mahazar (Ex.P.9) in the
presence of an independent witness, viz., Balasubramanian (P.W.22), Village
Administrative Officer, which were kept hidden in a bush. From the residence of
Kamaraj (A2), the police recovered two bangles weighing 4 = sovereigns (M.O.9) and
an Ind Suzuki bike (M.O.10) under the cover of mahazar (Ex.P.7) in the presence of
Balasubramanian (P.W.22).
16 From the disclosure statement of Elangovan (A3), police recovered 2 bangles
weighing 3 = sovereigns (M.O.11) from his residence under the cover of mahazar
(Ex.P.8) in the presence of Balasubramanian (P.W.22).
17 Exs.P.7 to P.9 reached the jurisdictional Court on 18.01.2012. After effecting the
recoveries and seizures, Santhanam @ Manoj Kumar (A1), Kamaraj (A2) and
Elangovan (A3) were produced before the Judicial Magistrate No.I, Namakkal, on
18.01.2012 at 6.30 p.m. and they did not make any complaint of ill treatment and
they were placed under judicial custody.
18 On the request made by the Investigating Officer, the District
Munsif-cum-Judicial Magistrate, Paramathi, recorded the 164(5) statement of the
following witnesses on 28.01.2012:
Vimal Raj (P.W.25) S/o Venkatesan Rangan, S/o Lakshmanan (not examined) Mani
S/o Lakshmanan (not examined) Rajesh (P.W.26), S/o Karunakaran TEST
IDENTIFICATION PARADE:
19 On 30.01.2012, Ms. Nandhini Devi (P.W.37), District Munsif-cum-Judicial
Magistrate, Paramathi, conducted Test Identification Parade for identification of
Santhanam @ Manoj Kumar (A1) and Kamaraj (A2) by witnesses Ajith (P.W.18),
Mohanraj (P.W.19) and Kathiresan (P.W.20).
20 Ajith (P.W.18) and Kathiresan (P.W.20) identified Santhanam @ Manoj Kumar
(A1) and Kamaraj (A2). Mohanraj (P.W.19) identified Santhanam @ Manoj Kumar
(A1). The Test Identification Parade report was marked as Ex.P.17.
21 The Investigating Officer, Parameswara (P.W.58) examined the doctors who
conducted the post-mortems and all the witnesses and completed the investigation
and filed a final report before the Judicial Magistrate No.I, Namakkal, for offences
u/s 120-B, 449, 449 r/w 120-B, 392 r/w 387, 392 r/w 120-B, 302 (3 counts) and 302
(3 counts) r/w 120-B IPC against Santhanam @ Manoj Kumar (A1), Kamaraj (A2)
and Elangovan (A3).
22 The accused were furnished with copies of the relevant documents under Section
207 Cr.P.C. and the case was committed to the Court of Sessions in S.C. No.94 ofElangovan vs State on 25 October, 2017

2012 and was made over to the Court of the Additional District and Sessions Judge,
Namakkal.
23 It is the case of the prosecution that Santhanam @ Manoj Kumar (A1), Kamaraj
(A2) and Elangovan (A3) conspired to commit the offence of murder for gain,
pursuant to which, they identified the Mullai Nagar house where the three ladies
were living and on 13.10.2011, they struck between 3.15 p.m. and 3.45 p.m.;
Elangovan (A3) stood guard outside the house when Santhanam @ Manoj Kumar
(A1) and Kamaraj (A2) forcefully entered the house, slit the throats of the three ladies
in the house causing fatal injuries and robbed them of their jewellery, after which, all
the three decamped with the booty.
24 The following charges were framed against Santhanam @ Manoj Kumar (A1),
Kamaraj (A2) and Elangovan (A3) by the trial Court on 02.01.2013:
A-1 120-B, 449,392 r/w 397, 302 (3 counts) IPC A-2 120-B, 449, 392 r/w 397, 302 (3
counts) IPC A-3 120-B, 449 r/w 120-B, 392 r/w 120-B & 302 (3 counts) r/w 120-B
IPC 25 When questioned, all the three accused pleaded 'not guilty'. Before the
commencement of the trial, Santhanam @ Manoj Kumar (A1) died on 08.07.2013
and therefore, the charges against him abated.
26 The trial in S.C. No.94 of 2012 proceeded before the Additional District and
Sessions Judge, Namakkal, as against Kamaraj (A2) and Elangovan (A3) and
commenced on 22.06.2015 with the examination of Umadevi (P.W.1). The
prosecution examined 59 witnesses and marked 59 exhibits and 14 M.Os. The
accused were questioned about the incriminating circumstances appearing against
them in the evidence, under Section 313 Cr.P.C. and they merely denied the same. No
witness was examined nor was any document marked on the side of the accused.
27 After hearing both sides, the Trial Court, by judgment dated 02.06.2017, convicted
Kamaraj (A2) and Elangovan (A3) as under:
Kamaraj (A2) (Death sentence + Double life imprisonment) 120-B IPC Life
imprisonment 449 IPC Life imprisonment 392 r/w 397 IPC 10 years R.I. 302 (3
counts) IPC Death sentence Elangovan (A3) (Death sentence + Double life
imprisonment) 120-B IPC Life imprisonment 449 r/w 120-B IPC Life imprisonment
392 r/w 120-B IPC 10 years R.I. 302 (3 counts) r/w 120-B IPC Death sentence 28
Hence, this reference under Section 366, Cr.P.C. and Criminal Appeals by the
accused 2 and 3, as aforestated.
29 Heard Mr. R. Rajarathinam, learned Public Prosecutor appearing for the State in the Referred
Trial and in the Criminal Appeals, assisted by Mr. C. Emalias, learned Additional Public Prosecutor,
Mr. R. Rajasekaran, learned counsel for Kamaraj (A2) and Mr.M. Subash Babu, learned counsel for
Elangovan (A3).Elangovan vs State on 25 October, 2017

30 This case is based on circumstantial evidence and bearing in mind, the following passage from
the Constitution Bench judgment of the Supreme Court in Govinda Reddy and another v. State of
Mysore [AIR 1960 SC 29], we propose to appraise the evidence on record:
"In cases where the evidence is of a circumstantial nature, the circumstances from
which the conclusion of guilt is to be drawn would in the first instance be fully
established, and all the facts so established should be consistent only with the
hypothesis of the guilt of the accused. Again, the circumstances should be of a
conclusive nature and tendency and they should be such as to exclude every
hypothesis but the one proposed to be proved. In other words, there must be a chain
of evidence so far complete as not to leave any reasonable ground for a conclusion
consistent with the innocence of the accused and it must be such as to show that
within all human probability the act must have been done by the accused."
31 Before going into the analysis of the evidence, we hereby catalogue the facts not disputed by
either side:
Visalakshi (D1) was the mother of Sathyavathi (D3), Umadevi (P.W.1) and Parvathy
(P.W.7.).
Dr. Sindhu (D2) was the daughter of Sathyavathi (D3) and grand daughter of
Visalakshi (D1).
Visalakshi (D1) and Dr. Sindhu (D2) suffered homicidal death on 13.10.2011 in the
house at Mullai Nagar.
Sathyavathi (D3) suffered injuries on 13.10.2011 and subsequently, she died at
K.M.H. Hospital in Coimbatore on 14.11.2011.
MOTIVE FOR THE MURDER:
32 It is the case of the prosecution that this was a murder for gain, whereas, to some
of the witnesses, it was suggested by the accused that the murder was on account of
money dispute in share transactions amongst Sathyavathi (D3) and her sisters
Umadevi (P.W.1) and Parvathy (P.W.7). It was also suggested that the murder must
have been engineered by Dr. Thirumalaiswamy (P.W.8), husband of Sathyavathi (D3)
and father of Dr. Sindhu (D2).
33 We are unable to agree with the theory propounded by the defence that the
murder must have been engineered by Umadevi (P.W.1) and Parvathy (P.W.7),
because, there would have been no necessity for Umadevi (P.W.1) and Parvathy
(P.W.7) to murder their own mother Visalakshi (D1) and Dr. Sindhu (D2), who is
their niece. Concededly, all the three deceased were living in the house of Umadevi
(P.W.1) and her husband Dr. Sundaram (P.W.4), as the said couple were childlessElangovan vs State on 25 October, 2017

and they were very fond of Dr. Sindhu (D2).
34 Even Parvathi (P.W.7), in her evidence, has stated that people would normally say
that Dr. Sindhu (D2) is blessed with three mothers and such was her relationship
with Dr. Sindhu (D2) and Sathyavathi (D3). Parvathi (P.W.7) has further stated in
her evidence that all the three sisters, viz., Umadevi (P.W.1), Sathyavathi (D3) and
Parvathy (P.W.7) were into share business and it was being managed by Sathyavathi
(D3) and that, on account of fluctuations in share market, there would be losses and
gains, which they used to take in their stride.
35 Except making such suggestions which have been denied by the witnesses, the
defence were not able to produce any credible material to show that there were
differences of opinion amongst the sisters, viz., Sathyavathi (D3) and Umadevi
(P.W.1) and Parvathy (P.W.7), so as to form the motive for the murder of the trio.
36 Coming to the allegation against Dr.Thirumalaiswamy (P.W.8), he has stated in
his evidence that he got married to Sathyavathi (D3) in 1976 and Dr. Sindhu was born
to them in 1978; Dr. Sindhu (D2) completed her Medicine and was married to
Dr.Balasubramaniam (P.W.9) in 2003. He has further deposed that his wife
Sathyavathi (D3) was doing share business and lost heavily and he refused to finance
her further. It is his further evidence that they got separated in 2008 and they had
their marriage dissolved by a decree of mutual consent. It is also his evidence that he
settled one house in favour of his wife Sathyavathi (D3) and their daughter Dr.Sindhu
(D2), but, they did not live in that house and instead, they preferred to stay in the
house of Umadevi (P.W.1) at Mullai Nagar.
37 It was not suggested to Dr. Thirumalaiswamy (P.W.8) that he had engineered the
murder, but, it was suggested to him that he developed intimacy with one Lilly, a staff
nurse and that is why, he divorced Sathyavathi (D3), which suggestion was denied by
him and which suggestion is irrelevant to this case.
38 However, Umadevi (P.W.1), in her complaint (Ex.P.1) given to the police, has
clearly given the description of the jewellery found missing from Visalakshi (D1), Dr.
Sindhu (D2) and Sathyavathi (D3), about which, we have stated above. Therefore, we
have no incertitude in rejecting the theories propounded by the defence with regard
to the motive for the murder and accordingly, we hold that the prosecution have
proved beyond doubt that the murder of the trio were murders for gain.
EVIDENCE OF P.W.1, P.W.2 and P.W.4:
39 Umadevi (P.W.1) deposed about the general facts of the case and as regards the
incident on 13.10.2011, she stated that 13.10.2011 was her father's death anniversary
and she sent food through Ajith (P.W.18), a worker in Annai Eye Hospital to her
mother Visalakshi (D1) and her sister Sathyavathi (D3) around 10.00 a.m.; AjithElangovan vs State on 25 October, 2017

(P.W.18) came back to the hospital around 1.30 p.m. and around 3.00 p.m., she
spoke to Dr. Sindhu (D2); again, at 3.15 p.m., when she tried contacting Dr. Sindhu
(D2) over phone, Dr. Sindhu (D2) did not pick up her call and thereafter, she called
Sathyavathy (D3), who also did not pick up her call; therefore, she went to the house
at Mullai Nagar around 3.45 p.m. with her husband Dr. Sundaram (P.W.4.) and
found that the door was open; on entering into the house, she was shocked to see her
mother Visalakshi (D1) lying in a pool of blood beneath the staircase, with a lungi
cloth tied around her neck; she was further shocked to see Dr. Sindhu (D2) lying in
the dining hall with her hands and legs tied with injuries; around the same time,
Sampathkumar (P.W.2) told her that Sathyavathi (D3) is in his house and so, she
went with her husband to the house of Sampathkumar (P.W.2) and found
Sathyavathi (D3) with bleeding injuries around her neck and left wrist; 108
ambulance was called and Sathyavathi (D3) was shifted to the hospital.
40 Umadevi (P.W.1) gave a hand written complaint (Ex.P.1) along with a
blood-stained Note (Ex.P.2) written by Sathyavathi (D3) based on which, the police
registered the FIR, about which, we have stated in detail above. On all these aspects,
the evidence of Umadevi (P.W.1) has been corroborated by the evidence of her
husband Dr. Sundaram (P.W.4) and Sampathkumar (P.W.2).
41 The police came to the place of occurrence along with the police photographer
(P.W.47), who took photographs of the scene of occurrence which were marked as
Ex.P.36 series. From the place of occurrence, the police seized a sharp long knife
(M.O.1) along with other clue materials under the cover of mahazar (Ex.P.5) in the
presence of Ravichandran (P.W.10) and Subramaniam (P.W.11).
42 Umadevi (P.W.1), in her evidence, has spoken about the presence of a knife on the
kitchen wash basin. We perused the photographs (Ex.P.36 series) and as deposed by
Umadevi (P.W.1), an old lady, presumably, Visalakshi (D1) is lying on the cot with
blood splashed over her garments and a young lady, presumably, Dr. Sindhu (D2) is
lying on the floor with her hands tied behind and her legs tied together. In the
photographs (Ex.P.36 series), she is found wearing churidar which is drenched in
blood. We also saw a knife with a wooden handle on the kitchen wash basin, where, a
portion of the leg of Dr. Sindhu (D2) was found extended. This is shockingly telltale
evidence and the recovery of knife (M.O.1) assumes great significance, about which,
we will discuss later.
Confession of Elangovan (A3) to Balu @ Balasubramaniam (P.W.21):
43 Balu @ Balasubramaniam (P.W.21), in his evidence, has stated that he is a farmer
and belongs to the Congress party and that he had held several positions in the party;
he knew Elangovan (A3) for a decade; Elangovan (A3) came to his house around 12
noon on 17.01.2012 in a nervous state and voluntarily confessed to him that, when he
was arrested and jailed in another case, he came into contact with Santhanam @Elangovan vs State on 25 October, 2017

Manoj Kumar (A1) and Kamaraj (A2) in the prison and thus, they became friends;
thereafter, they took a house and stayed together and committed robbery at
Kuppachipalayam; on 13.10.2011, in Namakkal, they entered into a house and slit the
throat of three women and took away their jewellery; again, on 28.12.2011, they
entered into a house in Karur, where, they slit the throat of two women and one child
and took away their jewellery and that since the police are behind him, he was scared.
Balu @ Balasubramaniam (P.W.21) has further deposed that he assured Elangovan
(A3) that he would surrender him to the police and ensure that he is not beaten by
the police and with that assurance, he took Elangovan (A3) and handed him over to
the Deputy Superintendent of Police, Namakkal, on the same day with a letter
(Ex.P.6), which contained the confession made to him by Elangovan (A3).
44 In the cross-examination, Balu @ Balasubramaniam (P.W.21) has stated that he
had given the letter on 18.01.2012. But, in the re-examination done by the Public
Prosecutor, he has clarified that he had handed over Elangovan (A3) to police on
17.01.2012, but, his statement before the police was recorded on 18.01.2012. He has
further admitted that when he gave the letter (Ex.P.6), there were other policemen in
the police station.
45 The learned counsel for the accused assailed the letter (Ex.P.6) given by Balu @
Balasubramaniam (P.W.21) and submitted that the same is an inadmissible evidence
as it is a record of confession inasmuch as it is addressed to the Deputy
Superintendent of Police and that admittedly, it was rendered in the police station by
Balu @ Balasubramaniam (P.W.21).
46 There appears to be force in the aforesaid submission of the learned counsel for
the accused that the letter (Ex.P.6) would be hit by Section 25 of the Evidence Act.
However, it is in the evidence of Balu @ Balasubramaniam (P.W.21) that Elangovan
(A3) came to his house and confessed to him as to how he got acquainted with the
other two accused and where all, they had committed robberies and murders. As
regards the incident at hand, Elangovan (A3) had specifically confessed that on
13.10.2011, they had gone to a house in Namakkal, where, they had slit the throat of
three women and taken away their jewellery. This, in our opinion, is an extra judicial
confession and is not hit by Section 25 of the Evidence Act, as Elangovan (A3) had
given the oral confession in the house of Balu @ Balasubramaniam (P.W.21), where,
police were not there. There is no requirement in law that an extra judicial confession
should be written down by the listener to make it authentic. For example, if a person
were to give a confession to a Parish Catholic priest that he had committed an
offence, cannot the priest give evidence in the Court about the confession?
47 The aforesaid question has been answered in the affirmative by a 9 Judge Bench of
the Supreme Court of Canada in Adele Rosemary Gruenke vs. Her Majesty the Queen
[1991 SCC Online Can. SC 85]. Lamer, C.J., speaking for the majority has opined
thus:Elangovan vs State on 25 October, 2017

In my view, religious communications, notwithstanding their social importance, are
not inextricably linked with the justice system in the way that solicitor-client
communications surely are.
Of course, the Bench has suggested the application of the Wigmore Test on a
case-to-case basis. In India, we have a codified law of evidence where the privileges
have been set out in Sections 122 to 129, where, there is no bar for the admissibility of
a confession given to a priest.
48 Yet another example is, if one were to give a confession to an illiterate person that
he had committed a crime, can that illiterate person not come to the Court and give
evidence about the confession given to him without there being any
contemporaneous written record made at the time of the confession? One should
remember that we have a huge illiterate population in our country and to hold that,
only literates can listen to confessions and depose about it in the Court would be a
travesty of justice. In State of Andhra Pradesh vs. Gangula Satya Murthy [1997) 1 SCC
272, the Supreme Court has held as under:
7. . . . The second reason is that the said extra-judicial confession was reduced to
writing as Ext. P-7, inside the police station and hence it is hit by Section 26 of the
Evidence Act, 1872.
20. But the confession made by the respondent to PW 6 and PW 7 was not made
while he was anywhere near the precincts of the police station or during the
surveillance of the police. Though Ext. P-7 would have been recorded inside the
police station its contents were disclosed long before they were reduced to writing.
We are only concerned with the inculpatory statement which the respondent had
made to PW 6 and PW 7 before they took him to the police station. So the mere fact
that the confession spoken to those witnesses was later put in black and white is no
reason to cover it with the wrapper of inadmissibility. We find that the High Court
has wrongly sidelined the extra-judicial confession. 49 In view of this authoritative
exposition of the law, we are of the view that, even if Ex.P.6 is held as inadmissible,
the evidence of Balu @ Balasubramaniam (P.W.21) before the Trial Court in which he
has deposed about the confession given by Elangovan (A3) cannot be jettisoned.
50 Though extra judicial confession is a weak piece of evidence, but, the same is not totally
inadmissible. The Court has to independently analyse the intrinsic worth of it before accepting or
rejecting it. In a given case, as in this, the evidence of Balu @ Balasubramaniam (P.W.21) to whom
Elangovan (A3) has confessed, does inspire our confidence.
51 In the case at hand, it was merely suggested that Elangovan (A3) was arrested 10 days ago and
was kept in illegal custody and at the request of the police, false evidence is being given, which, of
course, Balu @ Balasubramaniam (P.W.21) has denied. It was not suggested to Balu @
Balasubramaniam (P.W.21) that he does not know Elangovan (A3) at all. Even in the Section 313Elangovan vs State on 25 October, 2017

Cr.P.C. examination of Elangovan (A3), he has not stated that he did not know Balu @
Balasubramaniam (P.W.21) at all. It was also not suggested that Balu @ Balasubramaniam (P.W.21)
had any previous enmity against Elangovan (A3), on account of which, he is falsely deposing against
him.
52 In view of the above discussion, we accept the evidence of Balu @ Balasubramaniam (P.W.21) to
the extent that on 17.01.2012, Elangovan (A3) came to his residence at 12 noon and confessed that
he, along with Santhanam @ Manoj Kumar (A1) and Kamaraj (A2), had committed the offence in
the instant case. Of course, this extra judicial confession is relevant not as substantive evidence, but,
in terms of Section 30 of the Evidence Act as against Kamaraj (A2) also, as both of them were tried
in the same trial. It is pertinent to point out at this juncture that we are not predicating our
conclusion only on the extra judicial confession as we are aware of its evidentiary value. However,
we are not rejecting it in toto, as pleaded by the defence.
Spotting of Santhanam @ Manoj Kumar (A1) and Kamaraj (A2) near the scene of occurrence:
53 It is the case of the prosecution that Ajith (P.W.18) and Kathiresan (P.W.20) had
seen two persons on 13.10.2011 in and around the place of occurrence.
EVIDENCE OF AJITH (P.W.18):
54 Ajith (P.W.18) was a worker in Annai Eye Hospital run by Umadevi (P.W.1) and
her husband Dr. Sundaram (P.W.8) on a monthly salary of Rs.2,000/-. In his
evidence, Ajith (P.W.18) has stated that he would be deputed to take care of the
garden at the Mullai Nagar residence and run errand between the hospital and the
Mullai Nagar residence by the owners, including Visalakshi (D1) and Sathyavathi
(D3). He has further stated that Sathyavathi (D3) used to ask him to go to ration shop
or get provisions now and then and would also provide him food in the house.
55 Coming to the incident at hand, Ajith (P.W.18) has stated in his evidence that on
13.10.2011, he carried food and fruits from the hospital to the Mullai Nagar residence
in the morning; he handed over the bag to Sathyavathi (D3), who asked him to sweep
the garden; after he swept the garden, he was asked to go to the ration shop for
purchase of ration items and accordingly, he went to the ration shop and returned
saying that, since the ration card was mutilated, the Salesman did not supply any
item and hence, he returned; again, he was sent to the ration shop to find out as to
where the mutilated ration card should be presented for getting a new one, for which,
he went back to the ration shop to make enquiries and came back and told
Sathyavathi (D3) that the mutilated ration card should be given to the Taluk Office
for getting a new one; he was asked to do other odd jobs and later, Sathyavathi (D3)
gave him a bag and asked him to go to the hospital; when he came out of the house,
two persons who came in a motor bike, asked him Are Sir and Madam there? for
which, he replied, Sir is not there, only Madam is there; after saying so, he
proceeded to the hospital; later, around 4 p.m., he learnt about the murder that hadElangovan vs State on 25 October, 2017

taken place in the house.
56 Ajith (P.W.18) was examined by the police on 16.10.2011 and his statement
reached the Court on 17.10.2011 itself, as could be seen from the Magistrate's
endorsement thereon. In his evidence before the Court, Ajith (P.W.18) has deposed
that one person was fair and lean and was having a bag and the other person was
dark and hefty, with his left leg appearing wide spread.
57 In the Test Identification Parade, Ajith (P.W.18) identified Santhanam @ Manoj
Kumar (A1) and Kamaraj (A2). In the evidence before the Court, he identified only
Kamaraj (A2) and stated that Santhanam @ Manoj Kumar (A1) is not there in the
dock. Obviously, Santhanam @ Manoj Kumar (A1) could not have been there in the
dock when Ajith (P.W.18) was examined on 09.07.2015, because, he had died on
08.07.2013 itself. In his cross-examination, it was asked to Ajith (P.W.18) whether
the police had shown him the photographs of the suspects, for which, he replied in
the negative. Except suggesting to him that he had not seen anybody, as deposed by
him on 13.10.2011, for which, he denied, the defence were not able to make any
serious dent in his testimony.
EVIDENCE OF KATHIRESAN (P.W.20) 58 The other person who had seen the
accused in and around the spot on 13.10.2011 is Kathiresan (P.W.20). Kathiresan
(P.W.20) is a farmer-cum-real estate agent. In his evidence, he has stated that on
13.10.2011, around 3.30 p.m. to 4.45 p.m., while he was returning with his friend by
his motorcycle from Spectrum School side towards west, he saw two persons rushing
out of a house and started a motorcycle and they were about to dash him; he shouted
at them angrily and one of them who was fair and tall, menacingly threatened him by
showing gestures at him and the second person told the first person to immediately
leave the place and so, they sped away in their motorcycle; two days later, when he
learnt about the murder that had taken place in that area, he went to the place and
felt that the two persons, who had come out of the house, could possibly be the
perpetrators and hence, he informed the police about the incident that had taken
place on 13.10.2011.
59 The police recorded the statement of Kathiresan (P.W.20) on 16.10.2011 and it
reached the jurisdictional Court on 17.10.2011. In the Test Identification Parade,
Kathiresan (P.W.20) identified Santhanam @ Manoj Kumar (A1) and Kamaraj (A2)
as the persons with whom he had a confrontation on 13.10.2011. In the evidence
before the Court, Kathiresan (P.W.20) identified Kamaraj (A2) and stated that the
other person is not there in the dock. Kathiresan (P.W.20) was examined in the trial
Court on 29.07.2015 and much before that, Santhanam @ Manoj Kumar (A1) had
died on 08.07.2013. In the cross-examination, Kathiresan (P.W.20) was questioned
about the location of the Mullai Nagar house and he explained in detail as to the
direction in which the house was located, thereby further fortifying his version in the
chief-examination. Except suggesting to him that he had not seen the incident, theElangovan vs State on 25 October, 2017

defence were not able to make much headway in his cross-examination.
60 Ergo, we have no reasons to disbelieve the testimony of Ajith (P.W.18) and
Kathiresan (P.W.20) that the accused were found near the place of occurrence prior
to and after the incident. This should be pieced along with the evidence of
Karuppannan (P.W.42), finger print expert, who has lifted the chance finger prints
from the scene of occurrence, which tallied with that of Santhanam @ Manoj Kumar
(A1).
61 The learned counsel for the accused submitted that the report of Karuppannan
(P.W.42), finger print expert does not satisfy the requirements of law, as he had not
sated either in his evidence or in his report, as to how he had arrived at the said
opinion. We do not propose to delve on this issue since the finger print is that of
Santhanam @ Manoj Kumar (A1) who had breathed his last during trial.
EVIDENCE OF MOHANRAJ (P.W.19):
62 Mohanraj (P.W.19) has a lathe where he makes knives and other farm
implements. In his evidence, he has stated that his father started the lathe in which
knives and farm implements were made and after the demise of his father, he
continued to run the lathe. He has further stated that a fair and lean person came to
his lathe and wanted two knives to be made saying that he needs those knives for pig
hunting; he drew a model on the ground and stated that the knives should bear a
sharp tip and the blades should be flat and sharp on either side; the rate per knife was
fixed at Rs.500/- and he gave an advance of Rs.500/- and came the next day and
collected the two knives after paying the balance of Rs.500/-. It is his specific
evidence that every knife maker will have his own unique design in the handle
portion and accordingly, the knives made by him will have corrugated ridges and
stripes in the handle portion; therefore, he could identify the knives made by him
easily.
63 The police examined Mohanraj (P.W.19) on 16.10.2011 and his statement reached
the Court on 17.10.2011 itself, as could be seen from the endorsement of the
Magistrate thereon. After the accused were arrested, one knife (M.O.8) was seized on
the disclosure of Kamaraj (A2). Test Identification parade was done, wherein,
Mohanraj (P.W.19) identified Santhanam @ Manoj Kumar (A1) as the person who
had come to his lathe and purchased the two knives. In the Court, he identified the
knives (M.Os.1 and 8) and stated that both the knives were made by him.
64 In his cross-examination, he was asked whether he has the necessary licence to
make such knives, for which, he stated that he does not have one and that however,
only on the customers' request, he would make knives for them. In the
cross-examination, he admitted that there is a difference in size between M.O.1 and
M.O.8. He was cross-examined with regard to the Test Identification Parade and itElangovan vs State on 25 October, 2017

was ultimately suggested to him that he has given false evidence. Beyond that, there
was no suggestion put to him that he had not made M.Os. 1 and 8. His identification
of Santhanam @ Manoj Kumar (A1) in the Test Identification Parade does not have
any relevance because Santhanam @ Manoj Kumar (A1) had died thereafter on
08.07.2013. Mohanraj (P.W.19) was examined in the trial Court only on 09.07.2015.
65 In order to satisfy our judicial conscience, we summoned M.O.s 1 and 8 from the
Trial Court and had a careful look at them. Both the knives appear similar, though
not identical. We do not think that they have been made by a continuous mechanical
dye process for them to be identical and that they are obviously hand-made and the
blades are sharpened in the lathe. The knife (M.O.1) is the knife seen in the
photographs (Ex.P.36 series). The handle portion of M.Os.1 and 8 contain similar
ridges and stripes. To reiterate, Section 161(3) statement of Mohanraj (P.W.19) had
gone to the Court on 17.10.2011 and the knife (M.O.8) was recovered by the police on
the confession of Kamaraj (A2) on 18.01.2012 under Ex.P.9, mahazar, in the presence
of Balasubramanian (P.W.22). Therefore, we have no reason to disbelieve the
evidence of Mohanraj (P.W.19) that it was he who had made the two knives viz.,
M.Os.1 and 8.
66 On the showing of Elangovan (A3), the police arrested Santhanam @ Manoj
Kumar (A1) and Kamaraj (A2) on 17.01.2012 and their disclosure statement was
recorded, which provided material for the investigation in the triple murder case at
Karur and the Karur police effected seizures for their case simultaneously along with
the Namakkal police. From their disclosure statements, it came to light that the
accused had taken a house in Aeroplane Building at Palapatti and were staying there.
HOUSE AT PALAPATTI:
67 The building named Aeroplane Building in Palapatti Main Road in Mohanur
Village, Namakkal, belongs to Murugesan (P.W.35). In the said building, there are
two shop portions in the ground floor and six rooms in the first floor. Mathivanan
(P.W.32) is a tailor who was in occupation of one portion in the ground floor.
EVIDENCE OF MATHIVANAN (P.W.32) 68 Mathivanan (P.W.32), in his evidence,
has stated that he knew Elangovan (A3) of Kuppachipalayam; two years before
(evidence was given on 21.08.2015), Elangovan (A3) approached him and wanted a
room to stay; Mathivanan (P.W.32) approached one Kuppusamy (P.W.36) and
requested him to speak to the owner, Murugesan (P.W.35); accordingly, one room
was given to Elangovan (A3) on a monthly rent of Rs.400/- with an advance of
Rs.1,000/-, in which, apart from Elangovan (A3), two other persons were staying. In
the Court, Mathivanan (P.W.32) identified Kamaraj (A2) and Elangovan (A3) and he
described the other person as Manoj Kumar who will be fair, tall and lean.Elangovan vs State on 25 October, 2017

69 In his cross-examination, Mathivanan (P.W.32) has stated that Elangovan (A3)
would come to his shop frequently and he got acquainted with him and because of
this acquaintance, he had helped Elangovan (A3) to get a room in the Aeroplane
Building. He has been corroborated by Kuppusamy (P.W.36), who has stated that at
the request of Mathivanan (P.W.32), he spoke to Murugesan (P.W.35) and got a room
in the first floor in the Aeroplane Building for Elangovan (A3) and his two friends.
EVIDENCE OF MURUGESAN (P.W.35) 70 Murugesan (P.W.35), owner of
Aeroplane Building, has stated in his evidence that Kuppusamy (P.W.36)
approached him for letting out one room to a person known to him and since
Kuppusamy (P.W.36) had helped him to buy the building, he did not bother to see
the tenants, but, only told Kuppusamy (P.W.36) to fix the rent at Rs.400/- per month
and advance of Rs.1,000/-; four months later, on coming to know of this, the police
came to the Aeroplane Building and when he asked Mathivanan (P.W.32) about this,
he stated that he did not know their antecedents and apologised for recommending
them.
71 These witnesses were cross-examined as to whether any oral agreement was
entered into or rent receipt was given, for which, they stated that it was not a practice
to enter into any formal rent agreements. Murugesan (P.W.35) has stated that he was
told by Kuppusamy (P.W.36) that the tenants were good persons and that they can be
given the room and beyond that, he did not bother to verify anything about the
tenants.
72 This Court carefully analysed the evidence of Mathivanan (P.W.32), Murugesan
(P.W.35) and Kuppusamy (P.W.36). It is worth pointing out that the witnesses had
not let out a flat-like accommodation to the accused. The Aeroplane Building has two
shop portions in the ground floor and six rooms in the first floor for bachelors'
accommodation. In the countryside, it is quite common that persons are
accommodated in rooms on the recommendations of known persons and owners
normally do not insist upon entering into rental agreements with tenants or issuance
of receipts to tenants. According to the witnesses, the rent itself was fixed at Rs.400/-
and the advance was only Rs.1,000/-, from which, we can gauge the nature of the
accommodation. The fact that all the three accused were staying in the room was
spoken to by Mathivanan (P.W.32) and Kuppusamy (P.W.36) and not by the owner
of the accommodation, viz., Murugesan (P.W.35), who has stated that he had
completely left it to the hands of his friend Kuppusamy (P.W.36) and had not
bothered to even check who were staying in the room, as long as rent was properly
being paid. All the accused were arrested on 17.01.2012 and as usual, subsequently,
the case details became public in the print and electronic media. The police knew that
the accused had taken a room in the first floor of Aeroplane Building and this led
the police to interrogate Mathivanan (P.W.32), Murugesan (P.W.35) and Kuppusamy
(P.W.36). These witnesses have stated that four months prior to the matter coming to
the public domain (which must be around September 2011), the accused had takenElangovan vs State on 25 October, 2017

one room in the first floor of Aeroplane Building. Therefore, from the evidence of
Mathivanan (P.W.32), Murugesan (P.W.35) and Kuppusamy (P.W.36), we hold that
the prosecution have satisfactorily proved that all the three accused knew one
another well.
RECOVERIES AND SEIZURES:
73 Though we may not be concerned about the case of Santhanam @ Manoj Kumar
(A1) since he had died pendente trial, pursuant to his disclosure statement, the police
recovered one thali kodi and five rings (M.O.13) and 7 = sovereign thali chain
(M.O.14), which have been identified by Umadevi (P.W.1) as belonging to Dr.Sindhu
(D2) and Sathyavathi (D3).
SEIZURE RELATING TO KAMARAJ (A2) AND ELANGOVAN (A3):
74 Pursuant to the disclosure statement (Ex.P.56) of Kamaraj (A2), the Investigating
Officer seized knife (M.O.8) and blood-stained jeans pants (M.O.12) under the cover
of mahazar (Ex.P.9) in the presence of Balasubramanian (P.W.22). Balasubramanian
(P.W.22) was the Village Administrative Officer of Namakkal Town and on the
request of the police, he went to the police station, where, the disclosure statement of
Elangovan (A3) was recorded. Thereafter, Santhanam @ Manoj Kumar (A1) and
Kamaraj (A2) were arrested and brought to the police station. Balasubramanian
(P.W.22) stated that Kamaraj (A2) took them to his residence from where two
bangles weighing 4= sovereigns (M.O.9) and Ind Suzuki blue colour motorbike
(M.O.10), were seized under the cover of mahazar (Ex.P.7) and subsequently,
Kamaraj (A2) took them to a place from where he had kept hidden the knife (M.O.8)
and jeans pants (M.O.12) which were seized under cover of mahazar (Ex.P.9). The
seizure has been spoken to by the Investigating Officer (P.W.59) and corroborated by
Balasubramanian (P.W.22).
75 The learned counsel for the accused submitted that in the cross-examination,
Balasubramanian (P.W.22) has stated that when he went to the police station, he saw
all the three accused there and therefore, the contention of the prosecution that
Elangovan (A3) was arrested first and only thereafter, Santhanam @ Manoj Kumar
(A1) and Kamaraj (A2) were arrested stands belied.
76 This Court carefully scanned the evidence of Balasubramanian (P.W.22) and the
Investigating Officer (P.W.59). Though, initially, Balasubramanian (P.W.22) had
stated that when he went to the police station, he saw three accused, in the latter part
of the cross-examination itself, he has stated that when he went to the police station
first at 7 p.m., he saw only one accused, viz., Elangovan (A3) there; thereafter, he
went for his dinner and returned to the police station, at which time, he had seen
Santhanam @ Manoj Kumar (A1) and Kamaraj (A2). Hence, we are of the view that
Balasubramanian (P.W.22) has clarified this alleged congruity satisfactorily in theElangovan vs State on 25 October, 2017

cross-examination itself.
77 Pursuant to the disclosure statement of Elangovan (A3), the police recovered two
bangles of 3 = sovereigns each (M.O.11) from the residence of Elangovan (A3) under
the cover of mahazar (Ex.P.8) in the presence of Balasubramanian (P.W.22).
Umadevi (P.W.1) identified the two bangles weighing 3 = sovereigns (M.O.11), five
rings (part of M.O.13 series) and = sovereign ear ring (part of M.O.14 series) as
belonging to Dr. Sindhu (D2). Umadevi (P.W.1) further identified the red
stone-studded thali chain weighing 7 = sovereigns (part of M.O.14 series), two
bangles (M.O.9) and 2 rings each weighing = sovereign (part of M.O.13 series), as
belonging to Sathyavathi (D3). Besides, she identified one = sovereign gold ring (part
of M.O.13 series) as that of her mother Visalakshi (D1).
78 In the cross-examination, Umadevi (P.W.1) was asked as to whether she could
produce any receipt for having purchased the jewellery, for which, she stated that she
does not have any receipt. Further, in the cross-examination, she was shown the
jewellery and asked as to how the jewellery was still maintaining its lustre, for which,
she candidly replied that after the jewels were seized by the police and produced in
the Court, she filed an application before the Magistrate to obtain the jewels and gave
the same for polishing and have brought them to the Court, in view of the
undertaking given by her at the time of taking interim custody of the jewels. This
straightforward explanation given by Umadevi (P.W.1) is undoubtedly acceptable to
us. It must be remembered that Umadevi (P.W.1) had given the description of these
jewels even in her complaint (Ex.P.1) and after the jewels were recovered, she was
asked to identify the same, which she did. After the jewels were produced before the
jurisdictional Magistrate, she obtained interim custody of the same under Section 451
Cr.P.C. and had them polished, because, these jewels belonging to her loved ones will
naturally be objects of preservation in the memory of the departed.
79 Coming to the knife (M.O.8), we have expatiated about this in the earlier
paragraphs, where, we ourselves compared M.Os.1 and 8 and found that the assertion
of the prosecution that both the M.Os., viz., M.O.1 and M.O.8 were made by
Mohanraj (P.W.19), cannot be disbelieved.
80 In fine, we hereby list out the proved circumstances:
The accused had taken a room in the first floor of the Aeroplane Building and
therefore, all the three were known to one another.
Santhanam @ Manoj Kumar (A1) and Kamaraj (A2) were found near the place of
occurrence on 13.10.2011 prior to the incident by Ajith (P.W.18).
Sathyavathi (D3) came inside the house of Sampathkumar (P.W.2) after 3.30 p.m
and before 3.45 p.m and wrote the blood-stained note (Ex.P.2), in which, she hasElangovan vs State on 25 October, 2017

stated .30 kzp (3.30 time) 2 unknown persons. This statement of Sathyavathi
(D3) is a dying declaration relevant under Section 32 of the Evidence Act. Thus, the
prosecution have established that the offences had taken place between 3.00 p.m and
3.30 p.m. Between 3.30 p.m. and 3.40 p.m., Kathiresan (P.W.20) has seen
Santhanam @ Manoj Kumar (A1) and Kamaraj (A2) very near the scene of
occurrence.
Visalakshi (D1), Dr. Sindhu (D2) and Sathyavathi (D3) suffered homicidal deaths and
the jewellery worn by them that were found missing, have already been listed in the
complaint (Ex.P.1) given by Umadevi (P.W.1).
Dr. Karunanidhi (P.W.39), the surgeon who conducted post-mortem on Visalakshi
(D1), has stated that he commenced the post-mortem at 11.10 a.m. on 14.10.2011. In
his evidence as well in the post-mortem report (Ex.P.22), he has stated that the time
of death was 18-24 hours prior to conduct of the post-mortem. This means that the
death could have occurred between 12.00 noon and 5.00 p.m. on 13.10.2011, which is
in sync with the prosecution case that the death had occurred between 3.00 p.m and
3.30 p.m. on 13.10.2011. Dr. Karunanidhi (P.W.39) was not cross-examined with
respect to the period given by him regarding the probable time of death.
The extra judicial confession of Elangovan (A3) to Balu @ Balasubramaniam
(P.W.21) stands accepted.
Recoveries of gold jewellery on the disclosure statement made by Kamaraj (A2) and
Elangovan (A3) and the identification of those jewellery by Umadevi (P.W.1)
completes the circle.
Discovery of the knife (M.O.8) on the disclosure made by Kamaraj (A2) and its
comparison with the one found at the place of occurrence, viz., knife (M.O.1) coupled
with the evidence of Mohanraj (P.W.19), who made both the knives, if viewed from
the backdrop of the evidence of the doctors who conducted the post-mortems that the
knife (M.Os.1 and 8) could have caused the injuries found on the bodies of Visalakshi
(D1), Dr. Sindhu (D2) and Sathyavathi (D3), leads us to draw the inference that the
two knives were used for the commission of the offence.
Though there is no direct evidence for the charge of conspiracy, yet, from the proved
circumstances and with the aid of Section 10 of the Evidence Act, we hold that the
offences could not have been committed without a prior concert amongst the
accused.
81 At this juncture, it may be apposite to refer to the judgment of the Supreme Court
in AIR 1988 SC 1883, Kehar Singh and others vs. State (Delhi Administration),
wherein, it has been held as under:Elangovan vs State on 25 October, 2017

75. Generally, a conspiracy is hatched in secrecy and it may be difficult to adduce
direct evidence of the same. . . . . The express agreement, however, need not be
proved. Nor actual meeting of two persons is necessary. Nor it is necessary to prove
the actual words of communication. The evidence as to transmission of thoughts
sharing the unlawful design may be sufficient. . . . . (Emphasis supplied) 82 Though
there is no direct evidence to prove the change of conspiracy, yet, from the following
proved facts, we are legitimate in drawing an inference that the offences were
committed pursuant to the conspiracy hatched amongst the accused.
a All the three accused had taken a room in the first floor of Aeroplane Building at Palapatti in
September 2011, which stands established from the evidence of Mathivanan (P.W.32), Murugesan
(P.W.35) and Kuppusamy (P.W.36).
b Santhanam @ Manoj Kumar (A1) and Kamaraj (A2) were seen near the place of occurrence on
13.10.2011 around 1.30 p.m. by Ajith (P.W.18) and they asked a question to Ajith (P.W.18) as to
whether Sir and Madam were there at the house, for which, Ajith (P.W.18) replied saying Sir is not
there, only Madam is there. From this, the accused ensured themselves that there was no male
member in the house.
c From the scene of occurrence, a peculiar knife (M.O.1), which is not a cutlery item, was recovered
on 13.10.2011. The knife (M.O.1) and the knife (M.O.8), which were recovered on the disclosure
statement of Kamaraj (A2) were both made by Mohanraj (P.W.19) on the request of Santhanam @
Manoj Kumar (A1).
d Medical opinion shows that the injuries on the deceased could have been caused by knives (M.Os.1
and 8).
e Jewels worn by the deceased were found missing and they were subsequently recovered on the
disclosure statement of the three accused.
f Elangovan (A3) confessed to Balu @ Balasubramaniam (P.W.21). This extra judicial confession
about which we have discussed above threadbare, is a substantive piece of evidence as against
Elangovan (A3) not only for the charge of conspiracy, but also for his participation in the robbery
and murders. Of course, this extra judicial confession, having been given after the conspiracy had
ended, cannot be used under Section 10 of the Evidence Act as against Kamaraj (A2). However, it is
relevant under Section 30 of the Evidence Act as against Kamaraj (A2,) since both Kamaraj (A2) and
Elangovan (A3) underwent a joint trial.
83 The death of Santhanam @ Manoj Kumar (A1) will not have any impact on the complicity or
otherwise of Kamaraj (A2) and Elangovan (A3). This situation can be best explained with the
following illustration:
'A', a wealthy man, wants to eliminate his business rival 'C'. 'A' engages 'B', a hired
killer. 'A' and 'B' conspire to murder 'C' on a particular date. 'A' pays the moneyElangovan vs State on 25 October, 2017

demanded by 'B' and goes abroad so as to avoid being available in town on the day of
murder of 'C'. In pursuance of the conspiracy, 'B' murders 'C'. 'A' and 'B' can be
charged under Section 120-B read with 302 IPC. 'B' can be charged for the offence
under Section 302 read with 120-B IPC. 'A' cannot be charged for the offence of
Section 302 IPC. Supposing, after the murder of 'C', 'B' dies of heart attack, can 'A' be
left scot-free? If that is the law, then, it will be easy for 'A' to escape criminal liability
by eliminating 'B' after 'B' had murdered 'C'. 'A' can be charged for conspiracy with 'B'
to murder 'C' even after the death of 'B'. The court cannot convict 'B', but the Court
can receive the evidence against 'B'. Reception of evidence against 'B' in order to
prove the charges qua 'A' is clearly not illegal. Thus, the reception of evidence against
Santhanam @ Manoj Kumar (A1) deceased for proving that he was also a conspirator
along with Kamaraj (A2) and Elangovan (A3) and also for proving that the murders
for gain were committed pursuant to the conspiracy by all the three, cannot be said to
be inadmissible. The termination of the conspiracy to commit murder for gain cannot
end merely with the murder and removal of the loot from the possession of the
murdered. The umbrella of conspiracy can be safely expanded and extended upto the
time when the loot is disposed of and money gained through its disposal. Until then,
the conspiracy would subsist. During the subsistence of such a conspiracy, anything
said and done by one conspirator is relevant as against the other under Section 10 of
the Evidence Act, which reads as under:
"10. Things said or done by conspirator in reference to common design:
Where there is reasonable ground to believe that two or more persons have conspired
together to commit an offence or an actionable wrong, anything said, done or written
by any one of such persons in reference to their common intention, after the time
when such intention was first entertained by any one of them, is a relevant fact as
against each of the persons believed to be so conspiring, as well for the purpose of
proving the existence of the conspiracy as for the purpose of showing that any such
person was a party to it."
84 Dr.V.Nageswara Rao, in his treatise, the Indian Evidence Act - A Critical Commentary Covering
Emerging Issues and International Developments (II edition), has given a very elucidative
illustration on the contours of Section 10, which would make even a layman understand the scope of
the said provision:
"1. 1.1.2010: A first entertained the idea that the existing Government must be
overthrown by a people's war. He commits some murders and causes some
explosions in busy areas to create panic and to subvert people's confidence in the
Government. A tries to convert others also to his ideology by distributing pamphlets,
literature etc.
2. 1.4.2010: B joins A and both commit some more offences in furtherance of their
ideology. Conspiracy starts on this date as two persons are there. But B is liable forElangovan vs State on 25 October, 2017

what A has done before he joined him because the last part of the illustration says
"although they may have taken place before he joined the conspiracy or after he left
it."
3. 1.8.2010: C joins the conspiracy of A and B and the three commit some more offences.
4. 1.10.2010: D joins A, B and C and the four commit some more gruesome offences.
5. 1.1.2011: B is fed up with all the bloodshed and criminal activity and, in disgust and repentance,
totally disassociates himself from the conspiracy and does not take part in the activities any more.
6. 1.4.2011: E, F and G join hands with A, C and D in the conspiracy and they commit more offences.
7. 1.8.2011: A,B,C,D,E,F and G are all arrested and put on trial for the conspiracy. With their arrest,
conspiracy terminates.
In the above illustration, though technically the conspiracy started on 1.4.2010 with two persons
joining hands, the liability under Section 10 commences from 1.1.2010 itself because that was the
date on which "when such intention was first entertained by any one of them". So the conspiracy
starts with two but liability starts with one only.
So, B to G are all liable for the conspiracy and all the offences right from 1.1.2010 and up to 1.8.2011.
Though B washed off his hands and left the conspiracy in utter remorse on 1.1.2011, he is still liable
even after he left the conspiracy for all the offences committed by all the other conspirators right
until 1.8.2011, the date of their arrest and termination of conspiracy. This is the result of the last part
of the illustration i.e, "although they may have taken place before he joined the conspiracy or after
he left it."
Hence, some authors have expressed the opinion that the illustration "is wider than the section and
goes beyond the English law.""
Of course, some authors are of the view that though the period of conspiracy can be
extended backwards when it was first entertained by one of them, yet, all the
conspirators can be convicted only for the substantive offence of conspiracy and not
for the individual offence committed by one without the participation of the other. In
the illustration given by Dr.V.Nageswara Rao, 'A' to 'G' can be prosecuted for the
offence of conspiracy fixing the period from 01.01.2010 to 01.08.2011, but 'B' to 'G'
may not be liable for the individual offences committed by 'A' between 01.01.2010
and 01.04.2010. The following passage from the judgment of the Supreme Court in
State (N.C.T. of Delhi) v. Navjot Sandhu @ Afsan Guru [(2005) 11 SCC 600] will
throw light on this aspect.Elangovan vs State on 25 October, 2017

"We do not think that the theory of agency can be extended thus far, that is to say, to
find all the conspirators guilty of the actual offences committed in execution of the
common design even if such offences were ultimately committed by some of them,
without the participation of others. We are of the view that those who committed the
offences pursuant to the conspiracy by indulging in various overt acts will be
individually liable for those offences in addition to being liable for criminal
conspiracy; but, the non-participant conspirators cannot be found guilty of the
offence or offences committed by the other conspirators. There is hardly any scope
for the application of the principle of agency in order to find the conspirators guilty of
a substantive offence not committed by them. Criminal offences and punishments
therefor are governed by the statute. The offender will be liable only if he comes
within the plain terms of the penal statute. Criminal liability for an offence cannot be
fastened by way of analogy or by extension of a common law principle."
(emphasis supplied) From this authoritative pronouncement of the Supreme Court, it is beyond
cavil that accused who are not actually involved in the commission of specific offences cannot be
convicted for those offences, though they may be convicted for the substantive offence of conspiracy.
85 When once the Court holds that there is prima facie material for conspiracy, Section 10 of the
Evidence Act would come into play. In fact, for invoking Section 10, ibid, it would suffice if the Court
has a reasonable ground to believe that two or more persons have conspired to commit an offence.
Here, it is worth pointing out that the expression reasonable ground in Section 10, ibid, is used in
singularity and not in plurality. In other words, Section 10, ibid, does not say reasonable
grounds but says reasonable ground. Thus, in this case, we have more than one reasonable
ground to believe that the accused had conspired together to commit the offences. When once the
Court has a reasonable ground to believe that the accused had conspired, then, (i) the act of the
three accused staying together in a room at the first floor of Aeroplane Building at Palapatti; (ii)
the purchase of knives (M.Os. 1 and 8) by Santhanam @ Manoj Kumar (A1) from Mohanraj
(P.W.19); (iii) the enquiry made by Santhanam @ Manoj Kumar (A1) and Kamaraj (A2) with Ajith
(P.W.18) as to who were in the house; (iv) the presence of Santhanam @ Manoj Kumar (A1) and
Kamaraj (A2) near the place of occurrence around 3.30 p.m to 3.45 p.m and they picking up a
quarrel with Kathiresan (P.W.20) and (v) secreting away of the jewels, are relevant factors qua each
of the conspirators, viz., Santhanam @ Manoj Kumar (A1), Kamaraj (A2) and Elangovan (A3).
86 To sum up, the prosecution have proved beyond reasonable doubt that pursuant to the
conspiracy, the accused had committed the offences of murders for gain, resulting in the demise of
the three hapless women.
87 It is the specific case of the prosecution that Santhanam @ Manoj Kumar (A1) and Kamaraj (A2)
entered into the house while Elangovan (A3) was standing guard outside the house. In Barendra
Kumar Ghosh vs. King Emperor [AIR 1925 PC 1], while discussing the contours of Section 34 IPC,
the Privy Council has quoted John Milton and has held that they also serve who only stand and
wait. Therefore, Elangovan (A3) who was standing guard outside the house is equally liable for the
offences committed by Kamaraj (A2) and can be convicted and sentenced with the aid of Section 34Elangovan vs State on 25 October, 2017

IPC, apart from the substantive offence of conspiracy under Section 120-B IPC. It is trite law that
Section 34 IPC is not a substantive charging section, but, a rule of evidence and ergo, the failure of
the Trial Court to include Section 34 IPC while framing the charges, will not be a bar for this Court
to invoke the said provision for mulcting criminal liability on Elangovan (A3).
SENTENCE:
88 The law on sentencing by the Courts after conviction is passed, has been dealt
with by the Supreme Court in Dagdu Vs. State of Maharashtra [(1977) 3 SCC 68]. For
better clarity, the relevant portion is extracted hereunder :-
8. Section 235 of the Criminal Procedure Code, 1973 reads thus:
35. (1) After hearing arguments and points of law (if any), the Judge shall give a
judgment in the case.
(2) If the accused is convicted, the Judge shall, unless he proceeds in accordance with the provisions
of Section 360, hear the accused on the question of sentence, and then pass sentence on him
according to law. The imperative language of sub-section (2) leaves no room for doubt that after
recording the finding of guilt and the order of conviction, the Court is under an obligation to hear
the accused on the question of sentence unless it releases him on probation of good conduct or after
admonition under Section 360. The right to be heard on the question of sentence has a beneficial
purpose, for a variety of facts and considerations bearing on the sentence can, in the exercise of that
right, be placed before the Court which the accused, prior to the enactment of the Code of 1973, had
no opportunity to do. The social compulsions, the pressure of poverty, the retributive instinct to
seek an extra-legal remedy to a sense of being wronged, the lack of means to be educated in the
difficult art of an honest living, the parentage, the heredity all these and similar other considerations
can, hopefully and legitimately, tilt the scales on the propriety of sentence. The mandate of Section
235(2) must, therefore, be obeyed in its letter and spirit.
79. But we are unable to read the judgment in Santa Singh as laying down that the failure on the part
of the Court, which convicts an accused, to hear him on the question of sentence must necessarily
entail a remand to that Court in order to afford to the accused an opportunity to be heard on the
question of sentence. The Court, on convicting an accused, must unquestionably hear him on the
question of sentence. But if, for any reason, it omits to do so and the accused makes a grievance of it
in the higher court, it would be open to that Court to remedy the breach by giving a hearing to the
accused on the question of sentence. That opportunity has to be real and effective, which means that
the accused must be permitted to adduce before the Court all the data which he desires to adduce on
the question of sentence. The accused may exercise that right either by instructing his counsel to
make oral submissions to the Court or he may, on affidavit or otherwise, place in writing before the
Court whatever he desires to place before it on the question of sentence. The Court may, in
appropriate cases, have to adjourn the matter in order to give to the accused sufficient time to
produce the necessary data and to make his contentions on the question of sentence. That, perhaps,
must inevitably happen where the conviction is recorded for the first time by a higher court. 89Elangovan vs State on 25 October, 2017

Now, the core question that needs to be decided is whether the case at hand is one falling under the
rarest of rare cases category warranting sentence of death. While the learned counsel for the
appellants submitted that the case does not fall under the category of rarest of rare cases as
propounded by the Supreme Court, the learned Additional Public Prosecutor submitted that the
crime is a heinous one committed by the accused on three vulnerable women. Further, it is
submitted by the learned Additional Public Prosecutor that the accused are habitual offenders,
which is evident from the conviction sustained by them which shall be examined hereunder. It is
therefore submitted by the learned Additional Public Prosecutor that the accused indulging in
similar crime after the commission of the first crime unquestionably led the trial Court to the
inference that the accused are beyond reformation and their continuation in the social system would
only lead to more similar crimes and considering all the above factors, sentence of death was
imposed on the accused and therefore, no interference is called for.
90 In the light of the principles enunciated by the Supreme Court, what is to be decided by us is the
nature of punishment to be awarded to the accused. In Bachan Singh Vs State of Punjab [(1980) 2
SCC 684], the Supreme Court held that for making the choice of punishment or for ascertaining the
existence or absence of 'special reasons' in that context, the Court must pay due regard both to the
crime and the criminal and what is the relative weight to be given to the aggravating and mitigating
factors depends on the facts and circumstances of the particular case. More often than not, these
two aspects are so intertwined that it is difficult to give a separate treatment to each of them. In
many cases, the extremely cruel or beastly manner of the commission of murder is itself a
demonstrated index of the depraved character of the perpetrator and that is why, it is not desirable
to consider the circumstances of the crime and the circumstances of the criminal in two separate
water-tight compartments. In a sense, to kill is cruel and therefore, all murders are act of cruelty.
But, such cruelty may vary in its degree of culpability and it is only when the culpability assumes the
proportion of extreme depravity that 'special reasons' can legitimately be said to exist. The Supreme
Court, in the said judgment, held that in the exercise of its discretion, the Court shall take into
account the following circumstances, before awarding sentence :-
(a) That the offence was committed under the influence of extreme mental or
emotional disturbance.
(b) The age of the accused. If the accused is young or old, he shall not be sentenced to
death.
(c) The probability that the accused would not commit criminal acts of violence as
would constitute a continuing threat to society.
(d) The probability that the accused can be reformed and rehabilitated. The State
shall by evidence prove that the accused does not satisfy the conditions (c) and (d)
above.
(e) That in the facts and circumstances of the case, the accused believed that he was
morally justified in committing the offence.Elangovan vs State on 25 October, 2017

(f) That the accused acted under the duress or domination of another person.
(g) That the condition of the accused showed that he was mentally defective and that
the said defect impaired his capacity to appreciate the criminality of his conduct.
91 In Machhi Singh & Ors. Vs State of Punjab [1983 SCC (Cri) 681], the Supreme
Court held that before awarding death sentence, the following questions may be
asked and answered as a test to determine the 'rarest of rare' case in which death
sentence can be inflicted :-
(i) Is there something uncommon about the crime which renders sentence of
imprisonment for life inadequate and calls for a death sentence?
(ii) Are the circumstances of the crime such that there is no alternative but to impose
death sentence even after according maximum weightage to the mitigating
circumstances which speak in favour of the offender?
92 The Supreme Court went on to hold that the guidelines which emerge from Bachan Singh
(supra), will have to be applied to the facts of each individual case, where the question of imposition
of death sentence arises. It was further held that in rarest of rare cases, when the collective
conscience of the community is so shocked that it will expect the holders of the judicial power-centre
to inflict death penalty irrespective of their personal opinion as regards desirability or otherwise of
retaining death penalty, death sentence can be awarded.
93 The tests laid down by the Supreme Court in Bachan Singh (supra) have been dealt with in a
catena of decisions and the circumstances, which are mitigating and aggravating, based on which
sentence needs to be awarded, have been culled out from various decisions and highlighted by the
Supreme Court in Ramnaresh Vs. State of Chhattisgarh [(2012) 4 SCC 257] and the same are
extracted hereunder :-
6. The law enunciated by this Court in its recent judgments, as already noticed,
adds and elaborates the principles that were stated in Bachan Singh and thereafter, in
Machhi Singh. The aforesaid judgments, primarily dissect these principles into two
different compartments - one being the 'aggravating circumstances' while the other
being the 'mitigating circumstances'. The court would consider the cumulative effect
of both these aspects and normally, it may not be very appropriate for the court to
decide the most significant aspect of sentencing policy with reference to one of the
classes under any of the following heads while completely ignoring other classes
under other heads. To balance the two is the primary duty of the court. It will be
appropriate for the court to come to a final conclusion upon balancing the exercise
that would help to administer the criminal justice system better and provide an
effective and meaningful reasoning by the court as contemplated under Section
354(3) Cr.P.C.Elangovan vs State on 25 October, 2017

Aggravating circumstances:
(1) The offences relating to the commission of heinous crimes like murder, rape,
armed dacoity, kidnapping, etc. by the accused with a prior record of conviction for
capital felony or offences committed by the person having a substantial history of
serious assaults and criminal convictions.
(2) The offence was committed while the offender was engaged in the commission of
another serious offence.
(3) The offence was committed with the intention to create a fear psychosis in the
public at large and was committed in a public place by a weapon or device which
clearly could be hazardous to the life of more than one person.
(4) The offence of murder was committed for ransom or like offences to receive
money or monetary benefits.
(5) Hired killings.
(6) The offence was committed outrageously for want only while involving inhumane
treatment and torture to the victim.
(7) The offence was committed by a person while in lawful custody.
(8) The murder or the offence was committed to prevent a person lawfully carrying
out his duty like arrest or custody in a place of lawful confinement of himself or
another. For instance, murder is of a person who had acted in lawful discharge of his
duty under Section 43 Cr.P.C.
(9) When the crime is enormous in proportion like making an attempt of murder of
the entire family or members of a particular community.
(10) When the victim is innocent, helpless or a person relies upon the trust of
relationship and social norms, like a child, helpless woman, a daughter or a niece
staying with a father/uncle and is inflicted with the crime by such a trusted person.
(11) When murder is committed for a motive which evidences total depravity and
meanness.
(12) When there is a cold-blooded murder without provocation.
(13) The crime is committed so brutally that it pricks or shocks not only the judicial
conscience but even the conscience of the society.Elangovan vs State on 25 October, 2017

Mitigating circumstances:
(1) The manner and circumstances in and under which the offence was committed,
for example, extreme mental or emotional disturbance or extreme provocation in
contradistinction to all these situations in normal course.
(2) The age of the accused is a relevant consideration but not a determinative factor
by itself.
(3) The chances of the accused of not indulging in commission of the crime again and
the probability of the accused being reformed and rehabilitated.
(4) The condition of the accused shows that he was mentally defective and the defect
impaired his capacity to appreciate the circumstances of his criminal conduct.
(5) The circumstances which, in normal course of life, would render such a behaviour
possible and could have the effect of giving rise to mental imbalance in that given
situation like persistent harassment or, in fact, leading to such a peak of human
behaviour that, in the facts and circumstances of the case, the accused believed that
he was morally justified in committing the offence.
(6) Where the court upon proper appreciation of evidence is of the view that the
crime was not committed in a preordained manner and that the death resulted in the
course of commission of another crime and that there was a possibility of it being
construed as consequences to the commission of the primary crime.
(7) Where it is absolutely unsafe to rely upon the testimony of a sole eyewitness
though the prosecution have brought home the guilt of the accused.
77. While determining the questions relatable to sentencing policy, the court has to follow certain
principles and those principles are the loadstar besides the above considerations in imposition or
otherwise of the death sentence.
Principles (1) The court has to apply the test to determine, if it was the 'rarest of rare' case for
imposition of a death sentence.
(2) In the opinion of the court, imposition of any other punishment i.e. life imprisonment would be
completely inadequate and would not meet the ends of justice.
(3) Life imprisonment is the rule and death sentence is an exception.
(4) The option to impose sentence of imprisonment for life cannot be cautiously exercised having
regard to the nature and circumstances of the crime and all relevant considerations.Elangovan vs State on 25 October, 2017

(5) The method (planned or otherwise) and the manner (extent of brutality and inhumanity, etc.) in
which the crime was committed and the circumstances leading to commission of such heinous
crime.
60. This Court has consistently held that only in those exceptional cases where the crime is so
brutal, diabolical and revolting so as to shock the collective conscience of the community, would it
be appropriate to award death sentence. Since such circumstances cannot be laid down as a
straitjacket formula but must be ascertained from case to case, the legislature has left it open for the
courts to examine the facts of the case and appropriately decide upon the sentence proportional to
the gravity of the offence. 94 On the question of striking a delicate balance between the
proportionality of crime to the sentencing policy and arriving at the imposition of penalty in rarest
of rare cases, the words of Lord Denning have been quoted with approval by the Supreme Court in
Deepak Rai Vs State of Bihar [(2013) 10 SCC 421], which are quoted hereunder :-
 . . . . . The punishment is the way in which society expresses its denunciation of
wrongdoing; and, in order to maintain respect for the law, it is essential that the
punishment inflicted for grave crimes should adequately reflect the revulsion felt by
the great majority of citizens for them. It is a mistake to consider the objects of
punishments as being a deterrent or reformative or preventive and nothing else. . . . .
The truth is that some crimes are so outrageous that society insists on adequate
punishment, because the wrongdoer deserves it, irrespective of whether it is a
deterrent or not. 95 In the case at hand, following the principles laid down by the
Supreme Court above, this Court has to consider the aggravating and mitigating
circumstances before inflicting the sentence of death on the accused. On a
consideration of the circumstances, more particularly, the mitigating factors relating
to lack of criminal antecedents or probabilities of the appellant to be a menace to the
society, the Supreme Court in Gurudev Singh vs. State of Punjab [2003 (7) SCC 258],
has observed as hereunder :-
. . . it is indeed true that the underlying principle of our sentencing jurisprudence is
reformation and there is nothing in evidence to show that the appellants have been a
threat or menace to the society at large besides the FIR regarding the theft of buffalo.
It is also true that we cannot say that they would be a further menace to the society or
not as we live as creatures saddled with an imperfect ability to predict the future.
Nevertheless, the law prescribes for future, bases upon its knowledge of the past and
is being forced to deal with tomorrow's problems with yesterday's tools. 96 In
Shankar Kisanrao Khade vs. State of Maharashtra [(2013) 5 SCC 546], the Supreme
Court has requested the Law Commission of India to examine the imposition of death
penalty even in rarest of rare cases. This was referred, whether, as a principle, death
penalty can be imposed in any case in which the accused have been found guilty of
the charges of murder and which charges and which offences have been found to be
falling under the category of rarest of rare cases.Elangovan vs State on 25 October, 2017

97 While examining the issue of death sentence, the Law Commission of India, in
their conclusions, had finally recommended as follows:
.2.2 The march of our own jurisprudence  from removing the requirement of
giving special reasons for imposing life imprisonment instead of death in 1955; to
requiring special reasons for imposing the death penalty in 1973; to 1980 when the
death penalty was restricted by the Supreme Court to the rarest of rare cases  shows
the direction in which we have to head. Informed also by the expanded and deepened
contents and horizons of the right to life and strengthened due process requirements
in the interactions between the state and the individual, prevailing standards of
constitutional morality and human dignity, the Commission feels that time has come
for India to move towards abolition of the death penalty.
7.2.3 Although there is no valid periological justification for treating terrorism
differently from other crimes, concern is often raised that abolition of death penalty
for terrorism-related offences and waging war, will affect national security. However,
given the concerns raised by the law makers, the Commission does not see any reason
to wait any longer to take the first step towards abolition of the death penalty for all
offences other than terrorism-related offences.
7.2.4 The Commission accordingly recommends that the death penalty be abolished
for all crimes other than terrorism- related offences and waging war.
7.2.5 The Commission trusts that this Report will contribute to a more rational,
principled and informed debate on the abolition of the death penalty for all crimes.
7.2.6 Further, the Commission sincerely hopes that the movement towards absolute
abolition will be swift and irreversible. 98 On the basis of the guidelines given by the
Supreme Court in the judgments referred to above, it is clear that this Court should
also consider the mitigating circumstances surrounding the accused. As a matter of
fact, even under the Criminal Procedure Code, it had been stated that before entering
into the realm of sentence, the accused should be heard. However, when hearing the
accused, it must be borne in mind that he is being heard after he is informed that he
is found guilty of commission of the offences for which he has been charged. This
naturally puts him in an emotional and nebulous situation. It is for that reason that
the Supreme Court has advised that the Court should give a reflective time to
consider the quantum of punishment.
99 In the present case, the trial Judge had decided that the accused who are now before us, viz.,
Kamaraj (A2) and Elangovan (A3) had committed the offence and that the prosecution had proved
the charges beyond all reasonable doubt. Thereafter, the learned trial Judge had examined the
nature of the offence and had found that as a fact, Santhanam @ Manoj Kumar (A1) and Kamaraj
(A2) had entered into the house identified by Elangovan (A3). Identification plays a very important
role since not only, should the object of theft and robbery be accomplished but also that nobody isElangovan vs State on 25 October, 2017

there inside the house who would probably prevent such robbery from being accomplished. The
persons reasonably expected to be present should also be vulnerable to threats and should be of
such age and sex that the person(s) gaining illegal ingress into the house, should be able to
overcome them to achieve the object of robbery. It would have been very naove on the part of
Elangovan (A3) to have identified the house which had four or five male members who would be in a
position to overpower and thwart the attempt of robbery. Consequently, identification of the house
involves great preponderance and application of mind. It is this role that Elangovan (A3) played.
The facts, as held to be proved, reveal that Santhanam @ Manoj Kumar (A1) and Kamaraj (A2)
barged into the house. Elangovan (A3) is to do guard outside.
100 The learned counsel for Elangovan (A3) stated that Elangovan (A3) had not actually committed
the offence.
101 We have still found Elangovan (A3) equally guilty of commission of offence of murder of three
innocent and vulnerable ladies belonging to three different age groups, one an old lady, the other
middle aged and the other comparatively young and they did not have any chance against two
individuals who had armed themselves with the knives which they had specially made to kill pigs.
This itself exposes the attitude of Santhanam @ Manoj Kumar (A1) Kamaraj (A2) and Elangovan
(A3). Moreover, the learned trial Judge has also found that Santhanam @ Manoj Kumar (A1),
Kamaraj (A2) and Elangovan (A3) had also been found guilty in yet another case of a very similar
nature. Subsequent to the commission of the offence which this Court has been considering in these
criminal appeals, all the three accused, together with a common intention and common object, had
been found guilty of commission of a triple murder for gain in yet another crime registered as Cr.
No.618 of 2011 in Vengamedu Police Station, Karur District. That was taken cognizance of, after
committal by the Judicial Magistrate as S.C. No.18 of 2012 and the Principal Sessions Judge, Karur,
had thought it fit, by judgment dated 10.03.2014 rendered after full trial, to convict the very same
accused, viz., Santhanam @ Manoj Kumar (A1), Kamaraj (A2) and Elangovan (A3) of the major
offence of murder with a common intention, conspiracy and common object. In that case in which
the trial concluded earlier to the conclusion of the trial which is the subject matter of the appeals
hereunder, the Principal Sessions Judge, Karur, had thought it fit to give life sentences
consecutively. Even before the pronouncement of the judgment in that case, Santhanam @ Manoj
Kumar (A1) had died. Consequently, Kamaraj (A2) and Elangovan (A3) were convicted and
sentenced to life imprisonment for the offence of murder. But, the Principal Sessions Judge, Karur,
had directed that the three life sentences should run consecutively.
102 One feature which has to be mentioned at this juncture is that as against the said judgment,
Kamaraj (A2) alone had preferred a criminal appeal in Crl.A. (MD) No.174 of 2015 before this Court
and a Division Bench of this Court had also confirmed that the prosecution had proved the charges
of Section 302 IPC as against Kamaraj (A2) and had dismissed the appeal on 27.09.2016 and upheld
the conviction and did not interfere with the award of life sentence to run consecutively. Elangovan
(A3) had not preferred any appeal. He preferred to abide by the judgment of the trial Court.
103 In the present case, while deciding the sentence as against Kamaraj (A2) and Elangovan (A3),
apart from the principles laid down by the Supreme Court, the Additional District and SessionsElangovan vs State on 25 October, 2017

Judge, Namakkal, had also stated the earlier conviction in S.C. No.18 of 2012 by the Principal
Sessions Judge, Karur, as a fact, and thereafter, again, as a reason for imposing the maximum death
sentence and had once again relied on such conviction. But, very unfortunately, a copy of the said
judgment was not provided to Kamaraj (A2) and Elangovan (A3) and their opinion with respect to
such conviction was not sought.
104 Mr. Subash Babu, learned counsel for Elangovan (A3) submitted that in the absence of the Trial
Court framing a specific charge with regard to the previous conviction as required under Sections
211(7) and 236 Cr.P.C., this Court cannot take into consideration, the conviction of the accused
herein in the earlier case.
105 To appreciate the aforesaid submission of Mr.Subash Babu, it may be necessary to extract
Sections 211(7) and 236 Cr.P.C. as under:
11. Contents of charge:
(7) If the accused, having been previously convicted of any offence, is liable, by
reason of such previous conviction, to enhanced punishment or to punishment of a
different kind, for a subsequent offence, and it is intended to prove such previous
conviction for the purpose of affecting the punishment which the Court may think fit
to award for the subsequent offence, the fact, date and place of the previous
conviction shall be stated in the charge; and if such statement has been omitted, the
Court may add it at any time before sentence is passed.
236. Previous conviction:
In a case where a previous conviction is charged under the provisions of sub-section
(7) of section 211, and the accused does not admit that he has been previously
convicted as alleged in the charge, the Judge may, after he has convicted the said
accused under Section 229 or Section 235, take evidence in respect of the alleged
previous conviction, and shall record a finding thereon;
Provided that no such charge shall be read out by the Judge nor shall the accused be
asked to plead thereto nor shall the previous conviction be referred to by the
prosecution or in any evidence adduced by it, unless and until the accused has been
convicted under Section 229 or Section 235. 106 Section 211(7) Cr.P.C. will not
apply to the facts of this case, because, it is not the case of the prosecution that since
the accused were convicted and sentenced under Section 302 IPC in the earlier case,
they have to be ipso facto inflicted with death penalty, in the event of their conviction
under Section 302 IPC in this case.
107 Sections 211(7) and 236 Cr.P.C. will apply only in cases where the law provides
for an enhanced punishment for repeat of an offence by an offender. This can be
illustrated by citing the example of Section 303 IPC (which has, of course, been heldElangovan vs State on 25 October, 2017

unconstitutional) which envisages only one punishment, viz., death sentence, for a
person under life imprisonment committing an offence under Section 302 IPC. In
this case, the provisions of Section 298 Cr.P.C. may apply for proving the earlier
conviction and for taking it as an aggravating circumstance for the purpose of
imposing death penalty.
108 Be that as it may, when that fact was pointed out to us, we rectified the said error
committed by the learned Additional District & Sessions Judge, Namakkal and
provided a copy of not only the judgment in S.C. No.18 of 2012 but also the judgment
of this Court rendered in the appeal preferred against the judgment in S.C. No.18 of
2012 and called upon Kamaraj (A2) and Elangovan (A3) to attend the Court and saw
to it that the copies of judgments were provided to them. They were also provided
with a list of cases in which they had been charged and in some of which, they had
been even convicted for various IPC offences. Thereafter, we gave a very meaningful
hearing to both the learned counsel for Kamaraj (A2) and Elangovan (A3). At this
juncture, without any reservation, we place on record, our deep appreciation for the
manner in which Mr. R. Rajasekaran, learned counsel for Kamaraj (A2) and Mr. M.
Subash Babu, learned counsel for Elangovan (A3) advanced the causes of their
clients.
109 Among the cases in which they had been earlier charged or rather they had an
occasion to be involved in conflict with the law, Kamaraj (A2) had been earlier
charged and convicted in C.C. No.455 of 2003 under Sections 457 and 380 IPC; in
C.C. No.456 of 2003 under Sections 457 and 380 IPC; in C.C. No.457 of 2003 under
Sections 457 and 380 IPC; in C.C. No.458 of 2003 under Sections 457 and 380 IPC;
in C.C. No.459 of 2003 under Sections 457 and 380 IPC and in C.C. No.460 of 2003
under Sections 457 and 380 IPC, all for a sentence of rigorous imprisonment for a
period of two years and all by judgments on the same day, i.e., 24.02.2004 and all by
the very same Court, viz., Judicial Magistrate No.I, Puducherry and in the FIRs
registered as offences by the Mudaliarpet Police Station in Puducherry Union
Territory, except for one case which was registered by Reddiarpalayam Police Station,
again, in Puducherry Union Territory. The other strange aspect of the above
convictions is that the second and third convictions are with respect to consecutive
crime numbers, viz. Cr. Nos. 72 of 2003 and 73 of 2003. These offences are of the
year 2002 and 2003 respectively.
110 Mr. C. Emalias, learned Additional Public Prosecutor had impressed upon this
Court the necessity to consider these convictions as an antecedent character and
conduct of Kamaraj (A2). The learned Additional Public Prosecutor had further urged
that these convictions reflect that Kamaraj (A2) is a history sheeter so far as
specialised offences under Sections 457 and 380 IPC are concerned which relate to
illegal/forceful trespass and robbery.Elangovan vs State on 25 October, 2017

111 But, one crucial mitigating aspect in all these cases is that, though Kamaraj (A2)
has been convicted for house trespass and robbery and which conviction we cannot
examine at present, there had not been a commission of an offence relating to hurt or
bodily harm on any individual in those cases. They are offences committed by a
person who has committed the offence of robbery but had never thought it fit to even
cause harm or at least, simple injury to the victim. Apart from this, from a reading of
the charges in the present case and in the Karur case, there appears to have been an
unholy nexus and companionship between Santhanam @ Manoj Kumar (A1) and
Kamaraj (A2), which had resulted in the commission of heinous offences. Admittedly,
Santhanam @ Manoj Kumar (A1) is no more. In this case, when we ask ourselves the
question, had Kamaraj (A2) operated alone, would he have committed the offence
under Section 302 IPC or murder had occurred owing to his allegiance and
companionship with Santhanam @ Manoj Kumar (A1), we do not have a definitive
answer. This is a factor to be considered when a further preponderance has to be
made whether Kamaraj (A2) deserves death penalty as the only mode of sentencing
or whether a chance could be given to him to think over his actions and reform in
future. This becomes all the more crucial when we take into account the age and the
family circumstances of Kamaraj (A2). We have been informed that in 2011, when the
present occurrence took place, Kamaraj (A2) was aged about 32 years and he has a
wife, a daughter and a son. His children are young. The impact on the family, in the
event of the death sentence inflicted on him being confirmed, would be discussed
subsequently.
112 Mr. Rajasekaran, learned counsel for Kamaraj (A2) persuaded us to read the
police confession of Kamaraj (A2) in order to show that he did not have intrinsic
criminal propensities, but, that he had acted merely as a puppet in the hands of
Santhanam @ Manoj Kumar (A1). When we brought to his notice that the police
confession is inadmissible under Section 25 of the Evidence Act and Section 162
Cr.P.C. save as otherwise provided under Section 27 of the Evidence Act, he placed
reliance on the judgment of a Division Bench of this Court in In Re: Mottai Thevar
[AIR 1952 Madras 586], wherein, the Division Bench had relied upon the confession
statement of the accused given to the police to give benefits to the accused.
113 A reading of the facts in In Re: Mottai Thevar (supra), would show that the
accused, after committing the offence, went straight to the police station with the
blood-stained spear and there made a clean breast of the offence and this was the
first information received in that case. Only in such a circumstance, the bar under
Section 162 Cr.P.C. did not apply and the Court used the statement in favour of the
accused. The Division Bench which decided In Re: Mottai Thevar (supra), had an
occasion to deal with another case, viz., In Re. Vokkaligara Yengtappa [AIR 1952
Madras 535 - which was decided one month after In Re: Mottai Thevar (supra)]
wherein, they refused to read the police confession in favour of the accused in view of
the bar under Section 162 Cr.P.C. In In Re: Vokkaligara Yengtappa (supra), Mack, J.,
speaking for the Bench, lamented thus:Elangovan vs State on 25 October, 2017

2. It is most regrettable in the present state of the law that even a Public Prosecutor
although he may know that there is something in a statement made by an accused
when examined at the commencement of great help to him, is precluded from
bringing it openly to Court's notice by way of evidence. But, this is the present state of
the law under Section 162, Criminal P.C. and Sections 25 to 27 of the Evidence Act
and until the law is changed, it is extremely difficult to utilise material in a case diary
even in favour of an accused person. In his concurring opinion, Somasundaram, J.
said:
3. . . . So far as Sections 25 to 27 of the Indian Evidence Act are concerned, I have
already stated in another case, that they only prohibit the use of the confession
against the accused and that there is no prohibition of their use in favour of the
accused. But as regards Section 162 Criminal P.C., it prohibits the use of the
statement made by any person (which includes the statement of the accused) for any
purpose. There is, therefore, a prohibition to use the statement of the accused if made
in the course of investigation even if it is in favour of the accused. This section needs
to be amended so as to enable the statements of the accused to be used if they are in
their favour particularly if they happen to be in explanation of the recovery of
incriminating articles from their possession. 114 The above legal position was
further reiterated by the Supreme Court in Aghnoo Nagesia vs. State of Bihar [AIR
1966 SC 119] in the following terms:
9. . . . It provides that when any fact is deposed to as discovered in consequence of
information received from a person accused of any offence, in the custody of a police
officer, so much of such information, whether it amounts to a confession or not, as
relates distinctly to the fact thereby discovered, may be proved. Section 162 of the
Code of Criminal Procedure forbids the use of any statement made by any person to a
police officer in the course of an investigation for any purpose at any enquiry or trial
in respect of the offence under investigation, save as mentioned in the proviso and in
cases falling under sub-section (2), and it specifically provides that nothing in it shall
be deemed to affect the provisions of Section 27 of the Evidence Act. The words of
Section 162 are wide enough to include a confession made to a police officer in the
course of an investigation. . . .  115 In the Parliament attack case [Navjot Sandhu @
Afsan Guru (supra)], an attempt was made Mr. Gopal Subramanium, Senior Counsel
representing the Union of India, to use the police statement of Afsan Guru to prove
the names of the slain terrorists who attacked the Parliament and other non per se
incriminatory facts. The Supreme Court declined to accept Mr.Gopal Subramanium's
submission by placing strong reliance upon the judgment of the Privy Council in
Pullurkuri Kotayya vs. King Emperor [AIR 1947 PC 67] and the judgment of the
Supreme Court in Himachal Pradesh Administration vs. Om Prakash [(1972) 1 SCC
249] and held that the police confession can be used only for the discovery of a
hitherto unknown fact and nothing else. To a little extent, this position has been
watered down by the Supreme Court in its recent judgment in Mehboob Ali v State of
Rajasthan [(2016) 14 SCC 640], wherein, the Supreme Court has permitted the usageElangovan vs State on 25 October, 2017

of the police confession of an accused for the purpose of identifying the co-accused.
That being the law, this Court cannot read the police confession of Kamaraj (A2) that
was given by him during the course of investigation, in his favour, ignoring the bar
under Section 162 Cr.P.C. and the law laid down by the Supreme Court.
116 Coming to Elangovan (A3), Mr. Emalias, learned Additional Public Prosecutor brought to the
notice of this Court that Elangovan (A3) had been involved in three cases, the offences in all of
which are gruesome. They all relate to offences under Sections 302, IPC. But, again, a distinction
can be made. It had been pointed out that trial is underway before the Additional District Court,
Namakkal in S.C. No.104 of 2017 which emanated from Cr. No.132 of 2011 and which was under
Sections 302 and 379 IPC registered by Paramathi Police Station, Namakkal District. As stated
above, along with Kamaraj (A2), Elangovan (A3) had also been convicted by the Principal Sessions
Judge, Karur, in S.C. No.18 of 2012 in Cr. No.618 of 2011, again, under Sections 302 and 380 IPC.
That was a case wherein he had been awarded life sentence consecutively against which he did not
even prefer any appeal and he seems to have taken it stoically.
117 With respect to the other case in which Elangovan (A3) is facing trial in S.C. No.104 of 2007, the
charge sheet was provided to us and the facts reveal that he had an affair with another lady, who was
also incidentally married and who interfered with his marriage with the present wife. Consequently,
with that as a motive, he had been charged with the commission of an offence under Section 302
IPC. That trial also is still underway and it would be highly prejudicial to his interest and also
equally inappropriate, if this Court were to rely upon a charge levelled by the police as equivalent to
a previous conviction which just cannot be. The proof or otherwise of the charges will have to be
independently assessed by the Additional District Judge, Namakkal, where the trial is underway and
only thereafter, can an opinion be expressed regarding the validity or otherwise of the charges. Till
such time, as is always the case, every accused person should be presumed to be innocent.
118 Based on this analysis, we are now left with the offence for which both Kamaraj (A2) and
Elangovan (A3) have been convicted by the Sessions Court, Karur, wherein, consecutive life
sentences had been awarded and appeal filed by Kamaraj (A2) alone has been dismissed. Elangovan
(A3) has not preferred any appeal. While dealing with the appeal in Crl.A. (MD) No.174 of 2015 filed
by Kamaraj (A2), this Court had also not examined the fact that Elangovan (A3) had not filed any
appeal and had also not examined the necessity of seeking the assistance of the Legal Services
Authority to examine whether Elangovan (A3) would require assistance to file a criminal appeal.
119 Be that as it may, life sentences to run consecutively have been held to be unconstitutional by the
Supreme Court in Muthuramalingam and others vs. State represented by Inspector of Police [(2016)
8 SCC 313]. With respect to the family members of Elangovan (A3), we have been informed that in
2011, when the present offence took place, he was aged 27 years and he has one son.
120 Kamaraj (A2) and Elangovan (A3) are youngsters. The Supreme Court, in the judgments which
had been referred to above, has pointed out that the age of the accused is a factor to be considered
before imposing or examining the necessity to impose death penalty. We would like to expand the
theory a little further.Elangovan vs State on 25 October, 2017

121 In a referred trial, this Court takes the role of parens patriae of the families of both the death row
prisoners and the victims. When we look at the present case, Kamaraj (A2) has two children and
Elangovan (A3) has one child. Moving away from determining whether the offence falls under the
category of rarest of rare cases and examining the mitigating circumstances instead of merely
stating that the accused are young and that they have young children, as parens patriae, the Court
cannot keep its eyes blind and say we have given this particular sentence and thereafter, we have
nothing further to do with this case or with the family of the accused and the victims!!. The duty of
the Court extends further. We also would like to ponder that the children of Kamaraj (A2) and
Elangovan (A3) are also citizens of this country. This Court functions under the power and right
given by the citizens of this country while hearing a criminal appeal to examine the evidence
presented before it and also to examine where the family of the accused and the victim would be
placed.
122 Viewed from that angle, when there are three young children who have a long future and who
have to enter into school and gain education, the question we ask for ourselves is, whether we are
over-burdening ourselves by examining whether in the school records of the three children, when a
question is asked about their father, would it leave an indelible mark in the minds of the three future
citizens that their father had been executed by the orders of the Court or whether as has become
acceptable in society that their father is alive but somewhere else and out of accessible reach. We
must keep in our mind that this Court must also ensure that these three children, when they grow
up and enter into the society, do not have any anger or any reason to wreak vengeance in any
manner whatsoever. To this extent, we feel that it would only be appropriate that an alternative to
death sentence can be imposed on Kamaraj (A2) and Elangovan (A3). Looking at it from another
angle and viewing it from the eyes of Kamaraj (A2) and Elangovan (A3), they would certainly reform
themselves or at least, we hope that they would do, in spite of being convicted on the murder of six
other Indian citizens. When they realise that the Court has held that since their children have to live
a future, they have been given life sentence and not imposed with death sentence, it would certainly
be a very important factor in the minds of Kamaraj (A2) and Elangovan (A3). They may be
convicted, but, they are still citizens of this country.
123 We cannot rest with the above analysis alone. In the present case, we are left with a young child
whose mother had been murdered, whose grandmother had been murdered and whose great
grandmother had been murdered. How is that young child going to view life when she grows up, is
another question which this Court has to ponder and reflect. Would that anger in her, boil over
against a system which had not imposed death penalty against the persons who have been convicted
of the offence?
124 Here, we would like to examine the background of the young unfortunate child Abhinandhini.
Abhinandhini hails from a family of doctors. Her father is a doctor. Her mother, who died, was a
doctor. Her uncles are doctors and her grandfather is a doctor. Every doctor is in the holy profession
of saving lives and not extinguishing lives. She could be taught the value of life and that living a life
is worth more than a dead body. She has undoubtedly suffered. We are really pained at the suffering
that has been inflicted on her. But, with the circumstances surrounding her life, she would realise
that further death would not solve the problem. She can, with inspiration from her near and dearElangovan vs State on 25 October, 2017

relatives, distinguish herself in life. Viewed from that angle, she would realise, we hope, that life is
very valuable.
125 We are now placed with two weighing scales, the family of the two accused, viz., Kamaraj (A2)
and Elangovan (A3), where, there are three children who have a future, on the one hand and the
family of the three deceased, on the other, where also, there is one young child who, as well, has a
future. If Kamaraj (A2) and Elangovan (A3) are given capital punishment, then, the three children of
theirs would have to necessarily and possibly lead an uncertain future. They have to live with the
idea that an establishment called judiciary had thought it fit to impose capital punishment on
their fathers. To young minds, words of robbery, murder and death sentence are meaningless. All
they would know is that the Government or the judiciary, through the Government, was responsible
for the death of their fathers. Leaving out to society, these three children would be more hazardous
than leaving out to society the victim child Abhinandhini who is surrounded by a family of doctors
who can very well impress upon her, the value of human life, accepting that though her mother, her
grandmother and her great grandmother were dead, the two men who have been found guilty are
still alive and are being sufficiently punished not to enter into society to kill more people and be an
endanger to the society. This conversely would impress upon her that sufficient restraints placed on
the imposition of life sentence of Kamaraj (A2) and Elangovan (A3) would actually be giving life to
other innocent women who are left alone in their house and who would be possible targets of their
venture.
126 The period of restraint would have to be examined keeping a few aspects in mind. In the present
case, the primary factor is to keep Abhinandhini's age in mind. She was aged about 6 years at the
time of the offence in 2011. To repeat, she lost her mother, her grandmother and her great
grandmother. There would be simmering anger in her mind whenever she reflects on the personal
loss suffered by her for no reason of hers and for no fault on the part of her mother, grandmother or
great grandmother. They were equally innocent. They alone were there in the house as they always
were, but, on that fateful day, when Abhinandhini came back from school, they were not there to
receive her. They were dead. They were dead owing to the acts of horror committed by Kamaraj (A2)
and Elangovan (A3). But, equalising anger in her mind is the fact that she comes from a family of
doctors and medical practitioners and with their influence, she can, realise that saving life is actually
one of the ideals and for which her mother, also a doctor, lived and when her mother judges
Abhinandhini, she would also appreciate if Abhinandhini were to uphold the value of life rather than
expecting revenge by imposition of death sentence.
127 This leads to us to a further question as to the number of years to which restraint has to be
placed on Kamaraj (A2) and Elangovan (A3). It has to be at least for a period of thirty years till
Abhinandhini becomes a woman of 36 years. By that time, hopefully, with the grace of the Almighty
and the blessings of her elders, she would have settled down in life and the anger owing to the loss of
her mother, grandmother and great grandmother would diminish to a large extent. She might even
have a family. This would give her confidence in life and by that time, if Kamaraj (A2) and
Elangovan (A3) are released, she would be at peace with herself and would have a future to look
forward to with her own independent family. Keeping that in mind, we hold that Kamaraj (A2) and
Elangovan (A3) should be restrained for a period of thirty years in prison, without any remission byElangovan vs State on 25 October, 2017

the State Government on any account.
128 Having stated that, we must now look into the future of the three children of Kamaraj (A2) and
Elangovan (A3). In this regard, we would request the District Legal Services Authority of Vellore and
Namakkal Districts to work positively with respect to the family of Kamaraj (A2) and Elangovan
(A3). The District Legal Services Authority at Vellore and Namakkal Districts are requested to send
their para legal workers/legal aid advocates and ensure that the children of Kamaraj (A2) and
Elangovan (A3) are placed in schools and imparted education and also more importantly, ensure
that the occupation of Kamaraj (A2) and Elangovan (A3) are not insisted by the school authorities.
The District Legal Services Authorities may also lend their services, if the wives of Kamaraj (A2) and
Elangovan (A3) are in some way qualified and show them a way in moving forward in life. These
positive initiatives taken by the Court with respect to the children and wives of Kamaraj (A2) and
Elangovan (A3) would propel Kamaraj (A2) and Elangovan (A3) to reform themselves and when
they come out of prison, they would be useful to society at least in extolling virtues of a crime-free
life and the punishment which would be imposed by indulgence in crime.
129 Another factor which has to be ensured is that both Kamaraj (A2) and Elangovan (A3) must be
confined in two separate Central Jails. The entire nucleus of this case emanated by a conspiracy
made out in jail by the three accused. Consequently, it is imperative that any further interaction
between Kamaraj (A2) and Elangovan (A3) during the next thirty years has to be totally cut off. This
would ensure that they can reflect in solitude over their actions and at the same time, also take
solace in the fact that judiciary had not let their family down.
130 The Superintendent of Prisons, Central Prison, Trichy and the Superintendent of Prisons,
Central Prison, Coimbatore where Kamaraj (A2) and Elangovan (A3) were lodged from 10.03.2014
onwards, have sent individual reports to the effect that both the said prisoners did not involve
themselves in any prison offence and that their conduct inside the prison was satisfactory.
131 The reports of the Central Prison, Trichy and Central Prison, Coimbatore reinforce our
conviction that death sentence may not be the appropriate answer and rather, life sentence for thirty
years without any possibility of any remission or coming out of jail for any reason whatsoever, could
be a more appropriate answer with respect to sentence imposed on Kamaraj (A2) and Elangovan
(A3).
132 Consequently, this Court confirms the conviction imposed upon Kamaraj (A2) and Elangovan
(A3) under Section 302, but, the sentence of death imposed upon them, is modified to one of
imprisonment for life. But, we direct that Kamaraj (A2) and Elangovan (A3) shall not be released
unless they complete 30 years of actual imprisonment without any statutory remission or
commutation. Such a course has been held to be permissible in Haru Ghosh Vs. State of West
Bengal [(2009) 15 SCC 551], on the basis of the law laid down in Swami Shradhanand @ Murali
Manohar Mishra Vs. State of Karnataka [(2008) 13 SCC 767], where, the Supreme Court, after
considering several cases, held that such a course was permissible.
133 SUMMARY OF CONVICTIONS AND SENTENCES:Elangovan vs State on 25 October, 2017

KAMARAJ (A2):
I Convicted for the offence under Section 120-B IPC read with Sections 449, 397 and
302 IPC and sentenced to life imprisonment.
II Convicted for the offence under Section 449 IPC and sentenced to undergo life
imprisonment and fine of Rs.5,000/-, in default to undergo one year Rigorous
Imprisonment.
III Convicted under Section 392 IPC read with Section 397 IPC read with Section 34
IPC and sentenced to undergo ten years Rigorous Imprisonment.
IV Convicted under Section 302 IPC (3 counts) and sentenced to life imprisonment
for each count and fine of Rs.5,000/, in default to undergo one year Rigorous
Imprisonment for each count.
134 It is made clear that the life imprisonments shall run concurrently. However, the
sentence of ten years Rigorous Imprisonment for the offence under Section 392 IPC
read with Section 397 IPC read with Section 34 IPC and the life imprisonments shall
run consecutively. In other words, Kamaraj (A2) shall first undergo the Rigorous
Imprisonment of ten years for the offence under Section 392 IPC read with Section
397 IPC read with Section 34 IPC and thereafter, undergo the life imprisonments
concurrently.
ELANGOVAN (A3):
I Convicted for the offence under Section 120-B IPC read with Sections 449, 397 and
302 IPC and sentenced to undergo life imprisonment.
II Convicted for the offence under Section 449 IPC read with Section 34 IPC and
sentenced to undergo life imprisonment and fine of Rs.5,000/-, in default to undergo
one year Rigorous Imprisonment.
III Convicted under Section 392 IPC read with Section 34 IPC and sentenced to
undergo ten years Rigorous Imprisonment and fine of Rs.1,000/-, in default to
undergo six months Rigorous Imprisonment.
IV Convicted under Section 302 IPC (3 counts) read with Section 34 IPC and
sentenced to life imprisonment for each count and fine of Rs.5,000/, in default to
undergo one year Rigorous Imprisonment for each count.
135 It is made clear that the life imprisonments shall run concurrently. However, the
sentence of ten years Rigorous Imprisonment for the offence under Section 392 IPC
read with Section 34 IPC and the life imprisonments shall run consecutively. In otherElangovan vs State on 25 October, 2017

words, Elangovan (A3) shall first undergo the Rigorous Imprisonment of ten years
for the offence under Section 392 IPC read with Section 34 IPC and thereafter,
undergo the life imprisonments concurrently.
136 At the cost of repetition, we direct that Kamaraj (A2) and Elangovan (A3) shall
not be released, unless they complete thirty years of actual imprisonment without any
statutory remission or commutation.
In the result, with the above modification in sentence, the criminal appeals are
dismissed. The reference of the learned Additional District and Sessions Judge,
Namakkal, is answered accordingly.
(P.N.P., J.) (C.V.K., J.) 25.10.2017 cad Index: Yes Speaking Order: Yes To 1 The
Deputy Superintendent of Police Namakkal 2 The Additional District and Sessions
Judge Namakkal 3 The Public Prosecutor High Court of Madras Chennai  600 104 4
The Chairperson District Legal Services Authority Vellore District 5 The Chairperson
District Legal Services Authority Namakkal District P.N. PRAKASH, J.
& C.V. KARTHIKEYAN, J.
cad Common judgment in and Criminal Appeal Nos.402 and 465 of 2017 25.10.2017Elangovan vs State on 25 October, 2017

