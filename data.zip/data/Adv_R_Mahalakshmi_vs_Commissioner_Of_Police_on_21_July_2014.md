Adv R.Mahalakshmi vs Commissioner Of Police on 21 July, 2014
Author: C.T.Selvam
Bench: C.T.Selvam
IN THE HIGH COURT OF JUDICATURE AT MADRAS
RESERVED ON
:
28.02.2014
DELIVERED ON
:
21.06.2016
CORAM
THE HONOURABLE MR.JUSTICE C.T.SELVAM
CRL.O.P.Nos.27389 of 2013, 16652, 16678 of 2014, 
Crl.O.P.No.Sr.43843 of 2013 and Contempt Petition No.447 of 2015
Crl.O.P.No.27389 of 2013
ADV R.Mahalakshmi,
D/o.R.Rajagopal                                                         . Petitioner
vs.
1.Commissioner of Police,
   Greater Chennai,
   Egmore.
2.Inspector of Police,
   Cyber Crime,
   Greater Chennai,
   Egmore.      
3.M/s.Google India Pvt. Ltd.,
   8th and 9th Floors, 
   Tower C, Building No.8, 
   DLF Cyber City, 
   Gurgaon, India  122 002.
4. Facebook India Pvt. Ltd., 
    Building No.20, Raheja Mindspace, 
    Hi-tech City Main Road, 
    Vittal Rao Nagar, 
    Hitech City, Hyderabad, 
    Telangana  500 081.Adv R.Mahalakshmi vs Commissioner Of Police on 21 July, 2014

5.The Secretary,
   Ministry of Communication and Information Technology,
   Department of Telecommunication,
   Government of India, New Delhi.
6.The Director (DS-II), 
   Ministry of Communication and Information Technology, 
   Department of Telecommunications, 
   Government of India, New Delhi.
7.The Group Co-ordinator (Joint Secretary),
   Cyber Law Division,
   Department of Information Technology,
   Ministry of Communication and Information Technology,
   Government of India, Electronic Niketan No.6,
   Central Government Offices Complex,
   New Delhi  110 003.
(Respondents 3 to 6 are suo motu impleaded 
  as per order of the Court dated 21.07.2014 
  and 28.08.2014 in Crl.O.P.No.27389 of 2013 
  and the seventh respondent is suo motu 
  impleaded vide order dated 02.03.2015)                                .Respondents
        Criminal Original Petition filed  u/s.482 of the Code of Criminal Procedure praying to direct the second respondent to register a case on the complaint dated 07.09.2013 and take action against all the accused.        
Crl.O.P.No.16652 of 2014
ADV R.Mahalakshmi,
D/o.R.Rajagopal                                                         . Petitioner
vs.
1.Commissioner of Police,
   Greater Chennai,
   Egmore.
2.Inspector of Police,
   Cyber Crime,
   Greater Chennai,
   Egmore.                                                                      .Respondents
        Criminal Original Petition filed  u/s.482 of the Code of Criminal Procedure praying to transfer the investigation of Crime No.96 of 2014 on the file of Inspector of Police, CCB Chennai to any other investigating police agency.
Crl.O.P.No.16678 of 2014
ADV R.Mahalakshmi,
D/o.R.Rajagopal                                                         . Petitioner
vs.
1.Commissioner of Police,
   Greater Chennai,
   Egmore.Adv R.Mahalakshmi vs Commissioner Of Police on 21 July, 2014

2.Inspector of Police,
   Cyber Crime,
   Greater Chennai,
   Egmore.                                                                      .Respondents
        Criminal Original Petition filed  u/s.482 of the Code of Criminal Procedure praying to transfer the investigation of Crime No.260 of 2013 on the file of Inspector of Police, CCB Chennai to any other investigating police agency.
Crl.O.P.No.Sr 43843 of 2013
ADV R.Mahalakshmi,
D/o.R.Rajagopal                                                         . Petitioner
vs.
1.Commissioner of Police,
   Greater Chennai,
   Egmore.
2.Inspector of Police,
   Cyber Crime,
   Greater Chennai,
   Egmore.                                                                      .Respondents
        Criminal Original Petition filed  u/s.482 of the Code of Criminal Procedure seeking a direction to respondents to delete all the post made by the accused against the petitioner in his blog https://www.facebook.com/savukku, https://www.facebook.com/achimuithushankar, www.savukku.net and direct the respondents to take action against all the accused.
Contempt Petition No.447 of 2015
ADV R.Mahalakshmi,
D/o.R.Rajagopal                                                         . Petitioner
vs.
1.R.S.Sharma,
   The Secretary,
   Ministry of Communication and Information Technology,
   Department of Telecommunications,
   Electronic Niketan,
   No.6, Central Government Offices Complex,
   New Delhi  110 003.
2.Arya
   The Director (DS-II),
   Ministry of Communication and Information Technology,
   Government of India, Electronic Niketan,
   No.6, Central Government Offices Complex,
   New Delhi  110 003.
Both represented by ADV.Kanagaraj
Senior Central Government Standing Counsel,
High Court Buildings,
Chennai.
3.Suryakumar
   Inspector of Police,
   Central Bureau of Investigation,Adv R.Mahalakshmi vs Commissioner Of Police on 21 July, 2014

   III Floor, Shastri Bhavan,
   No.26, Haddows Road,
   Nungambakkam,
   Chennai  600 006.                                                   .Respondents
        Contempt Petition filed under Section 11 of the Contempt of Courts Act to punish the respondents herein for their willful disobedience of the order passed in Crl.O.P.No.27389 of 2013 dated 14.11.2014.
Appearance:
For Petitioner:
CRL.O.P.Nos.27389 of 2013, 
16652, 16678 of 2014, and 
Contempt Petition No.447/15
:
Ms.R.Mahalakshmi, Party-in-Person
Crl.O.P.No.Sr.43843 of 2013 
:
Mr.R.Sankarasubbu
For Respondents:
State Government
:
Mr.A.L.Somayaji, Advocate General
assisted by Mr.S.Shanmugavelayutham,
Public Prosecutor assisted by
Mr.C.Emalias, Additional Public Prosecutor
Google India Pvt. Ltd.
:
Mr.P.S.Raman, senior counsel for
Mr.G.Balasubramanian
Facebook India Pvt. Ltd.
:
Mr.Sathish Parasaran Madhan Babu
Central Bureau of India
:
Mr.K.Srinivasan, 
Special Public Prosecutor (CBI cases)
Mr.G.Rajagopal,
Additional Solicitor General of India
Mr.Su.Srinivasan,
Additional Solicitor General of India
Mr.C.Kanagaraj,
Senior Central Government Standing CounselAdv R.Mahalakshmi vs Commissioner Of Police on 21 July, 2014

*****
C O M M O N  O R D E R
Crl.O.P.No.27389 of 2013 seeks a direction to second respondent to register a case on the complaint
dated 07.09.2013.
2. Crl.O.P.Nos.16652 and 16678 of 2014 seek transfer of investigation in Crime Nos.260 of 2013 and
96 of 2014 on the file of Inspector of Police, CCB, Chennai to any other investigating police agency.
3. Crl.O.P.No.Sr 43843 of 2013 seeks a direction to respondents to delete all the post made by the
accused against the petitioner in his blog
https://www.facebook.com/savukku,https://www.facebook.com/achimuithushankar,www.savukku.net.
4. Contempt Petition No.447 of 2015 is preferred against the non-compliance of the order of this
Court passed in Crl.O.P.No.27389 of 2013 dated 14.11.2014.
5. Petitioner has alleged that one Shankar s/o.Aachimuthu Shankar had created a blog in the name
of www.savukku.net as also a facebook account, that such Shankar S/o.Achimuthu is the accused in
case pending trial in S.C.No.192 of 2009 on the file of Fast Track Court III, Chennai, he having been
charged for offences u/s.5 of the Official Secrets Act, 43 and 66 of the Information Technology Act,
378, 379, 463, 465, 470, 471 and 505 IPC on a complaint lodged by an erstwhile Principal Secretary
to Government Home (SC) Department, Secretariat, Chennai  9, that on such website he was
publishing articles mocking the judiciary and tarnishing the image of Advocates and bringing into
public discussion the personal life of individuals towards blackmailing and extorting money from
them. Petitioner alleged that acting at the instance of her sister-in-law and others, the said Shankar
and others towards defaming her and her family members had posted much false information on
the net and on face book. Informing the same to be grossly abusive and menacing in nature and
intended to cause annoyance, inconvenience, obstruction, insult, injury, enmity, hatred by
persistent use of computer resources and misuse of photographs of the petitioner and her family
members as a result of which petitioner has suffered much damage, a complaint has been lodged by
the petitioner with the Commissioner of Police on 31.05.2013. Petitioner informed that though the
complaint discloses cognizable offences neither preliminary enquiry was conducted nor was a case
registered. She further contended that despite knowledge of the complaint the accused continued
their wrongful actions. Petitioner preferred a complaint u/s.200 Cr.P.C. before learned Chief
Metropolitan Magistrate, Chennai, praying for a direction to the Inspector of Police, Cyber Crime,
Egmore, to register a case against Shankar s/o.Achimuthu and another and her sister-in-law
Panimalar u/s.199, 211, 354, 120(b) IPC and Section 66-A of Information Technology Act and
Protection of Women against Harassment Act. The learned Magistrate directed registration of a
case, investigation thereupon and filing of final report under orders in C.M.P.No.3967 of 2013 dated
05.06.2013. Petitioner further informed that as against the order dated 05.06.2013, a case was
registered only on 08.07.2013 but despite the same the said Shankar, Panimalar and others
continued their wrongful actions and also threatened the petitioner and her brother and demanded
a sum of Rs.50 lakhs towards removal of the earlier posts and for not acting likewise in future.
Complaining against non-blocking of the website or removal of the defamatory post and submitting
that she and her family members are subjected to much harassment by way of threats, warning ofAdv R.Mahalakshmi vs Commissioner Of Police on 21 July, 2014

dire consequences and of demands for huge sums of money, that a further complaint dated
07.09.2013 had met with no response, the petitioner sought a direction towards registration of a
case on her complaint dated 07.09.2013. Certain orders came to be passed by this Court and, we
would confess, on impression of validity of Section 66-A of the Information Technology Act, the
same then being on the statue book. As the same inform the concern of this Court, orders dated
07.01.2014, 30.01.2014 and 28.02.2014 are reproduced hereunder:
7.01.2014 The petitioner herein has raised a very important issue as to the
prevention of abuse and misuse of information technology for the purpose of
defaming the reputation of an individual by uploading obscene pictures/
photographs.
2. In the present case, it may be stated without any reservation that the materials
placed before us shows that a scandalous attempt has been made with intent to cause
damage to the reputation of the petitioner and her family members. The petitioner
places before this Court a chart, which provides the names of the website created and
other particulars showing the manner in which the offensive blogs have been created
by using internet.
3. Learned counsel for the petitioner submits that the said particulars are available
merely upon entering the website and yet the respondent has not initiated any action
on the basis of the complaint given by the petitioner.
4. Learned Additional Public Prosecutor informs that the concerned person against
whom complaint was given by the petitioner was examined by the investigating
officer and he has denied his involvement in any wrong doing. The Status report filed
by the investigating officer inter alia informs of their having requested the assistance
of Indian Computer Emergency Response Team for blocking/deletion of contents.
5. Learned member of the bar, Mr. Madan Babu informs that the procedure for
blocking of access to any computer service was framed by the Telecom Regulatory
Authority of India (TRAI). Provision has been made for blocking from public view
such offending materials.
6. Considering the seriousness of the issue, we have requested Shri. B. Kumar, Senior
Advocate to assist this Court. We have also expressed the view that it is open to the
members of the bar to come forward with their suggestions with regard to the
manner in which such objectionable contents can be dealt with. Shri. B.Kumar,
learned Senior Counsel also accepted the request to assist this Court by acting as
Amicus Curiae.
7. In the meantime, the petitioner is directed to implead TRAI as a party respondent
to this Criminal Original Petition. The petitioner is also directed to furnish a copy of
the entire record to Shri. B. Kumar, learned Senior Counsel. The respondent, besidesAdv R.Mahalakshmi vs Commissioner Of Police on 21 July, 2014

moving the authorities of TRAI towards probing the offence and for redressal in this
case may also take effective immediate action against such of the persons who may be
involved in such wrong doing. Post the matter on 24.01.2014 at 2.15 pm. The
respondent may also ascertain and inform the response of Indian Computer
Emergency Response Team to the representation made by the respondent, on such
date.
30.01.2014 Taking note of 'Booklet Information' furnished by the petitioner, the
submissions of Mr.Sankarasubbu, learned counsel and having no reason to doubt the
truthfulness of the contents, this Court directs the respondents to take immediate
proper action on the materials available and inform this Court of developments
pursuant thereto by 04.00 p.m. on 31.01.2014.
Post on 31.01.2014 at 04.00 p.m. 28.02.2014 Pursuant to dismissal of M.P.No.3 of
2014, the following order stands passed by this Court.
2. As informed in the order of this Court dated 07.01.2014, the petitioner herein has
raised a very important issue as to the prevention of abuse and misuse of information
technology for the purpose of defaming the reputation of an individual by uploading
obscene pictures/photographs. Most demeaning articles tarnishing ones reputation
accompany the same.
3. This Court has also observed that given the seriousness of the issue, it would be
open to the members of the bar to come forward with their suggestions with regard to
the manner in which such objectionable contents can be dealt with. Similarly,
considering the seriousness involved, this Court has requested Shri.B.Kumar, learned
senior counsel, to assist this Court. He has made very detailed submissions. The same
as also other facets of the case will be discussed in detail in the final order to be
passed. The material placed by the petitioner absolutely makes clear that the
person/persons, behind the offending material placed on the net, have done her
immeasurable harm. Placed before us also is a volume informing the posts in the
website "savukku" informing various transgressions into privacy, tarnishing of
reputations and damage caused to several persons. Five advocates, offended by posts
in the website, have filed affidavits before this Court. This Court notes that the
reputation and status of not less than half a dozen Judges, very many advocates, very
many IAS and IPS officers stands attacked and damaged at the hands of this
vituperative site. All this is done without so much as having the courage to inform
who is behind the offending website. Website service providers and all other persons
providing internet service necessarily would require the persons in charge of websites
to inform true particulars regards their names and addresses. Clearly in this case, the
names and addresses stand wrongly informed. The contents of the posts in the
website are so grossly demeaning, so obnoxious and so harmful as are not worthy of
being brought in print in an order of this Court. If sites such as these are allowed to
be operated, the damage to society at large can hardly be imagined. To be wedAdv R.Mahalakshmi vs Commissioner Of Police on 21 July, 2014

couples would turn their backs on each other. Many a husband and wife would part
ways, many a child would be left clinging in anguish to the hands of one parent
instead of gleefully holding the hands of both. We can go on and on. Suffice it to state
that by way of interim order, this Court directs the Group Co-ordinator (Joint
Secretary), Cyber Law Division, Department of Information Technology, Ministry of
Communication and Information Technology, Govt. of India, Electronic Niketan
No.6 Central Govt. Offices Complex, New Delhi  110 003, to block the entire website
(www.savukku.net) with immediate effect upon receipt of this order.
4. Taking note of the serious concern expressed by learned Advocate General of the
State and having due regard to his submissions and the information furnished by
him, this Court has passed the above order. Learned Advocate General has informed
that Special Teams stand formed, the location of the accused stands fixed and the
investigation in the case will be actively and duly proceeded with.
5. This Court would reserve orders in the matter and close for now by merely stating
that each and every instance of objectionable and vituperative malignant post in the
website would give cause for separate cases and actions thereupon. Pending further
orders, it would always be open to the petitioner or the State to seek that the matter
be posted under the head "for being mentioned" as and when occasion requires.
Registry is directed to communicate this order to the Group Co-ordinator (Joint Secretary), Cyber
Law Division, Department of Information Technology, Ministry of Communication and Information
Technology, Govt. of India, Electronic Niketan No.6 Central Govt. Offices Complex, New Delhi  110
003, through fax.
6. This Court may add that M.P.No.3 of 2014 dismissal whereof is mentioned in the order dated
28.02.2014 was an attempt to avoid this Court on the plea that certain undesirable statements
against the Hon'ble Mr.Justice C.T.Selvam were placed on the website viz. www.savvukku.net by
some unknown persons and that such statements would be likely to influence the mind of the Judge
while deciding the above Criminal OP, it would be in the interest of justice that the above Criminal
OP be heard by some other Hon'ble Judge.
7. Being unimpressed by the submission of Shri.N.Radhakrishnan, learned counsel for the petitioner
in M.P.No.3 of 2014, this Court had dismissed the same. Finding lukewarm the response of various
authorities in complying with the orders of this Court directing blocking of the offending sites,
several orders came to be passed on different dates. This Court would readily admit that such orders
were passed on the understanding that Section 66-A of the Information Technology Act was good in
law. The Apex Court having informed otherwise, this Court would not dwell upon such orders and
for the same reason, this Court would not discuss the various submissions made before us by
Shri.B.Kumar, learned senior counsel, though under order dated 28.02.2014, this Court has
informed that this Court would do so in the final order. This Court merely places on record its
appreciation for the painstaking and detailed submissions made by him on what has transformed
from the plea of an individual into a public cause.Adv R.Mahalakshmi vs Commissioner Of Police on 21 July, 2014

8. Two cases have been registered on the complaints of the petitioner viz., (i)Crime No.260 of 2013
for offences u/s.199, 211 IPC, 66-A of Information Technology Act and 4 of Tamil Nadu Prohibition
of Harassment of Women Act, 1998 and (ii) Crime No.96 of 2014 for offences u/s.384, 506(i),
120(B), 66-A of Information Technology Act and 4 of Tamil Nadu Prohibition of Harassment of
Women Act, 1998, re-numbered as Crime Nos.RC.10/(S)/2014/CBI/SCB/Chennai and
RC.11/(S)/2014/CBI/SCB/ Chennai. This Court found reason to be dissatisfied with the
investigation not merely at one instance but on two. The cases which were originally investigated by
Inspector of Police, Cyber Crime, Greater Chennai, Egmore, were transferred to Additional
Commissioner, Cyber Crime and thereafter, investigation was handed over to the Central Bureau of
Investigation. In the interregnum and under orders in Crl.O.P.No.2494 of 2014 dated 18.02.2014,
Shankar s/o.Aachimuthu was granted relief u/s.438 Cr.P.C. in respect of Crime No.260 of 2013. As
regards Crime No.96 of 2014, the said Shankar s/o.Aachimuthu was granted interim anticipatory
bail under orders in Crl.O.P.No.4379 of 2014 and the same was cancelled under order dated
02.09.2014. The investigating agency through out and even after cancellation of the order of the
anticipatory bail, has not found it necessary to cause the arrest of Shankar S/o.Aachimuthu. Be that
as it may, investigation in Crime No.260 of 2013 has been completed and a final report has been
filed before learned Additional Chief Metropolitan Magistrate on 30.12.2015 informing commission
of offences u/s.509 IPC and 4 of Tamil Nadu Prohibition of Harassment of Women Act, 1998. The
case in Crime No.96 of 2014 has resulted in filing of a final report on 08.06.2016.
9. Though it is the contention of petitioner that the cases stand not properly investigated and that
other offences which are made out stand not included, this Court would close the present petitions
with the observation that it would be open to the petitioner to move the Courts below by way of
protest petitions/private complaints within one month of receipt of this order, if such a course is
considered appropriate.
10. Accordingly, Criminal Original Petition Nos.27389 of 2013, 16652, 16678 of 2014,
Crl.O.P.No.Sr.43843 of 2013 and Contempt Petition No.447 of 2015 are closed.
11. Unfortunately, the issue would not rest there.
12. This matter has first engaged our attention on 07.01.2014. As earlier stated, every order of this
Court has been met with scandalous and slanderous posts on the sites operated by the offender.
Unfortunately, the offender did not, and persons of his ilk will not, realize that a Court cannot be
scared away, that in the face of insults and ignominies being thrown at it, the response of the Court
would be to hold steadfast and that eventually 'the long arm of the law' would reach him. Against the
escapism indulged by the offender in informing that he was not responsible, investigation has
revealed that he indeed is so. Final reports now having been filed in both cases investigated by the
Central Bureau of India, this Court now considers it appropriate to dispose of the matters.
13. This Court already has noted that this Court found need to transfer the investigation on two
occasions and that the investigating agency never found the need to arrest Shankar
S/o.Aachimuthu, who beyond any doubt has rendered himself liable for action in contempt of Court.
Before informing why this Court is of such view, this Court is constrained to observe that in the sitesAdv R.Mahalakshmi vs Commissioner Of Police on 21 July, 2014

posted by this individual, so much offensive, vituperative and abusive material is displayed against
officers of almost every rank. Would it be possible without 'insider participation' ? Are sites such as
these used to settle scores ? Just almost anything can be said about almost anybody with total
disregard for the truth and without having to prove or produce anything in support of the wild
allegations. All that these sites need to survive and do is to appeal to the baser sentiments of those
who find matters abusive, defamatory, derogative and to the detriment of the next man or woman,
titillating. In the instant case, the offender, having had no courage to disclose his identity, has
sought to make a hero of himself stating that it was necessary not to disclose his identity as
otherwise he would be put to death. Here again, he angles for hero worship of the misled.
14. On 30.06.2014, this Court passed the following order:
Today the matter is listed under the caption for being spoken to.
2. Learned counsel for petitioner has informed this Court that the website material is
now available on the web under a different heading
'www.newsavukku.com/lang/tamil'. The status report filed by the Additional
Commissioner of Police also informs such position. The status report is also
suggestive that the Director (DS-II), Ministry of Communication and Information
Technology, Department of Telecommunications, Government of India, New Delhi
and Group Co-ordinator and Director General (CERT), Ministry of Communication
and Information Technology, Department of Telecommunications, Government of
India, New Delhi, are not addressing the issue with the seriousness it calls for. This
Court learns that an organisation functioning under the name 'National Cyber Safety
and Security Standards' having as its Chair Person, a person of such eminence as
Justice Mr.S.Mohan, Former Judge, Supreme Court of India, is well-equipped to
make a detailed study and inform a more detailed position, as also suggests measures
towards alleviating this nefarious practice of posting offending defamatory matter on
websites under cloaks of secrecy. Therefore, this Court by way of further interim
order, orders as follows:
(1)there shall be an interim stay of investigation pending further orders in the case;
(2)despite the order of stay, the Additional Commissioner of Police, shall be upon
duty to carry out the functions designated to him towards ensuring compliance with
the orders of this Court dated 30.04.2014. It would be open to the National Cyber
Safety and Security Standards also to address all concerned authorities in the Central
Ministry viz., Director (DS-II), Ministry of Communication and Information
Technology, Department of Telecommunications, Government of India, New Delhi
and Group Co-ordinator and Director General (CERT), Ministry of Communication
and Information Technology, Department of Telecommunications, Government of
India, New Delhi and the Secretary, Ministry of Communication and Information
Technology, Department of Telecommunications, Government of India, New Delhi,
towards the purpose of blocking of materials appearing on any website answering to
the name 'www.savukku.net' or 'www.newsavukku.com/lang/tamil' or any direct orAdv R.Mahalakshmi vs Commissioner Of Police on 21 July, 2014

intermediary link connecting to any website wherein the word 'savukku' figures. (3)A
team headed by Mr.Khalie Raaj, Regional Head, Government and Industrial
Initiatives, shall cause a detailed enquiry into the posting, conduct, setup, installation
and all related information as they may access pertaining to 'www.savukku.net' or
'www.newsavukku.com/lang/tamil' or any direct or intermediary link connecting to
any website wherein the word 'savukku' figures. The team shall be authorised and
empowered to take all action as may be necessary to stop the appearance of any
material on any website under the name 'www.savukku.net' or
'www.newsavukku.com/ lang/tamil' or any direct or intermediary link connecting to
any website wherein the word 'savukku' figures. Such authority shall stand extended
also to act in respect of other social networking sites such as facebook, twitter, etc.
Post on 21.07.2014 for report of National Cyber Safety and Security Standards.
15. A team of the National Cyber Safety and Security Standards took all out efforts to effect
compliance of the orders of this Court in letter and spirit and met with much success. This Court
would acknowledge their service which made true the adage 'Where there is a will there is a way'.
The National Cyber Safety and Security Standards has filed a report before this Court and therein
informed that they had done extensive study on the setup and domain registration process in
internet and the accessibility of data in social media. They submitted as follows:
1.There are no particular standards for domain registration and since it is
internationally connected, we have to discuss this issue in the international forum
and have to make the UN Council to execute the new policy on domain registrations.
2.The only way to get the details of website is by approaching the Domain Registrant.
3.If domain ID booked in person and paid by cash then there is 100% possibility of
giving false information about the ownership and retrieving the owner information is
not possible but if they book the domain by giving false owner information and paid
by Debit/Credit card then it is 100% possible to retrieve the ownership details by
seeking the bank account details from domain registrant.
4.Social Media has become the Danger to our Nation. Terrorist are using the Social
Media effectively for their activities starting from recruitment to execution. Social
Media has to be viewed very seriously.
5.We come to know that to block any website in India it is taking more than 10 days
and which has to come down to 1 day to reduce the damage.
6.The ISP's are facing technical difficulties to block certain websites.
7.In social media the Cyber Criminals mainly targetting women, children.Adv R.Mahalakshmi vs Commissioner Of Police on 21 July, 2014

8.All Big Internet Search Engines, Social Media Companies are registered and having
their Head Quarters in United States and they are not bound by our Indian laws.
9.In recent days some Apps has been developed and being used by our Indian public
which has High Security threat to the Nation. Some of them as follows:
9.1. Whatsup 9.2. Viber 9.3. True Caller 9.4. Fake Call 9.5. Hike Messenger All these
apps gives alternative to regular method of calling and messaging. The data stores in
private environment and government has no control over these companies. It is easy
to organize any event which creates more disaster to our Nation.
10.To spoil our culture and tradition the cyber criminals have started more than 3
million pornography websites which are making our young society to fallen in wrong
direction. This may lead to unacceptable things like Rape and Sexual Harassment,
etc.
16. The National Cyber Safety and Security Standards also made suggestions as follows:
1.It is necessary to form a Cyber Monitoring Committee (CMC) Roles and
Responsibilities of CMC as follows:
To continuously monitor the Internet data flow and activities To establish the
possible ways of curbing the cyber crimes To create awareness to the public regarding
the Cyber Crimes and its Seriousness To safeguard the women and children from
Cyber Threats To help Law Enforcement Agencies to effectively identify the criminals
as early as possible. To suggest the State and Central Government on police
decisions.
To identify the wrong doing websites and to block them.
2.All search engine and social media companies must have their Nodal officer in
India for effective communication which can help us to monitor and control the
Cyber Crimes.
3.It is necessary to provide the advance training on Cyber Threats and Crimes to Law
Enforcement Agencies on regular basis.
4.On basis of Honourable Committee formed as per the order of Honourable High
Court of Madras, we have formed the Special Technical Team which will identify and
provide the solutions to technical difficulties which government is facing to block and
control the Cyber Threats.
5.The National Cyber Safety and Security Standards is Establishing 100 research
centre's across India National Cyber Defence Research Centre and theAdv R.Mahalakshmi vs Commissioner Of Police on 21 July, 2014

establishment manual will be submitted to the Honourable High Court of Madras as
early as possible.
17. As stated earlier, very many Judges including a former Chief Justice of the Country have been
abused, referred to derisively and allegations against them of corruption and other malpractices
have been thrown like straws in the wind. The same are unworthy of and this Court is of the view
that it would be unbecoming to reproduce them in the present order of this Court. For purposes of
Court, the same are included by way of an annexure running into 205 pages. Every action of this
Court towards curtailing the menace has been met with, rebuke, offensive posturing and challenges
thrown at it. Adding insult to injury, the offender has opened sites in the name of a Judge of this
Court. The offender repeatedly has and continuously is in contempt of this Court. At this juncture,
though lengthy, it would be useful to reproduce the following from the 'self contained note'
submitted by the Deputy Inspector General of Police, Head of Branch, CBI/SCB/Chennai:
Investigation conducted by CBI, SCB, Chennai on the allegations in the complaint of
Advocate Mahalakshmi revealed as follows:
Investigation revealed that after the arrest and release on bail in CBCID case and also
suspension from Directorate of Vigilance &Anti Corruption,Shri Shankar created a
website in the name of www.savukku.net with the help of Shri Murugaiyan of
Pondicherry, by making payment to the website registrar Google*Enom on
24.11.2009. Shri Shankar used to write articles regarding corruption activities in
Tamil Nadu Politics and also among Governments Officials. He gave link of the
website www.savukku.net to his Facebook account. Shri Shankar published the
following articles relevant to the present case in the website www.savukku.net.
1.SoodhuKavvum published in www.savukku.net Date of Publication:23.05.2013 @
11.14 hrs Thursday Comments on 23.05.2013 @ 12.22 hrs Thursday
2.Paul KanagarajThalaimayilValakarignargalAdavadi published in www.savukku.net
Date of Publication:23.05.2013 @ 20.02 hrs Thursday Comments on 23.05.2013 @
20.13 hrs Thursday
3.Irandu Per EzhuKaadhal published in www.savukku.net Date of
Publication:30.05.2013 @ 00.34 hrs Tuesday Comments on 30.05.2013 @ 10.28 hrs
4.Savukku Thalam Meethu Sun TV Mahalakshmi Kaaval Thurayil Pugaar published
in www.savukku.net Date of Publication:31.05.2013 @ 14.58 hrs Comments on
31.05.2013 @ 15.38 hrs It is revealed that the contents of the articles Soodhu
Kavvum, Paul Kanakaraj Thalaimayil Vazhakarignargal Adaavadi, Irandu Per
EzhuKaadhal and Savukku Thalammeedhu SUN TV Mahalakshmi Kaaval
Thuraiyil Pugar and the comments of the viewers of these articles were against
Advocate Mahalakshmi, her mother Smt. Jhansi Rani, her brother ShriSatish
Narayanan and her colleagues of SUN TV Network. The contents were also foundAdv R.Mahalakshmi vs Commissioner Of Police on 21 July, 2014

against the Advocates S/ShriPaul Kanagaraj, Ruben and Krishna Kumar.Smt.
Mahalakshmi alleged that the contents of these articles and the comments of the
viewers were defamatory in nature.
Investigation conducted on therole of website www.savukku.net revealed that as per the registration
details of www.savukku.net, the website was created on 24.11.2009 through the registrar
Google*Enom in the registrant name of Kesava Perumal, Mount Road, Green Ville vide E-mail id
newsavukku@gmail.com with Phone No.97920 94271. It is revealed from the Statement of Account
of Citi Bank Credit Card No.4386280246833002 in the name of Shri Achimuthu Shankar that he
made the payment of US $10.00 (INR483.23) to Google*Enom on 24.11.2009 for the creation of
web site www.savukku.net. It is also revealed that Shri Achimuthu Shankar has renewed this
website www.savukku.net annually by making payment to Google*Enom from Citi Bank Credit Card
Nos. 4386280246833002 & 4386280009923974. It is revealed from the Statements of Account of
Citi Bank Credit Card No. 4386280246833002 that Shri Achimuthu Shankar made payment of
$10.00 (INR 474.42) on 25.11.2010 and $10 (INR 515.52) on 25.10.2011 to Google*Enom for the
renewal of www.savukku.net. It is also revealed from the Statement of Account of Citi Bank Credit
Card No.4386280009923974 that Shri Achimuthu Shankar made payment of $10.00 (INR 557.11)
on 26.10.2012. Hence, investigation revealed from the above Statement of Accounts of the Credit
Cards in the name of Shri Achimuthu Shankar that he paid $10.00 to Google*Enom on 24.11.2009
for registration of www.savukku.net and further renewal of the same website on 25.11.2010,
25.10.2011 & 26.10.2012.
The registration details of the website www.savukku.net taken from Whois.net by National Cyber
Safety and Security Standards, Chennai are as follows:
Domain Name : savukku.net Date Updated Date : 14.11.2014 T07:49:13.00Z Creation
Date : 24.11.2009 T08:26:21.00Z Registrar Registration Expiration Date : 24.11.2015
T08:26:21.00Z Registrar details Registrar : ENOM INC.
Registrar IANA ID : 48 Registrar Abuse Contact Email : abuse@enom.com Registrar
Abuse Contact Phone : +1.4252982646 Registrant details Registrant Name : KESAVA
PERUMAL Registrant Organization :
Registrant Street : 1421 ROPER MOUNTAINROAD Registrant City : GREENVILLE
Registrant State/Province : SC Registrant Postal Code : 29615 Registrant Country :
IN Registrant Phone : +91.9792094271 Registrant Phone Ext :
Registrant Fax :
Registrant Fax Ext :
Registrant Email                        NEWSAVUKKU@GMAIL.COM
Admin details
Admin Name                              :       GOOGLE TEAMAdv R.Mahalakshmi vs Commissioner Of Police on 21 July, 2014

Admin Organization              :       GOOGLE INC.
Admin Street                    :       1600, AMPHITHEATRE PARKWAY
Admin City                              :       MOUNTAIN VIEW
Admin State / Province          :       CA
Admin Postal Code                       :       94043
Admin Country                   :       US
Admin Phone                     :       +1.6501234567
Admin Phone Ext                 :
Admin Fax                               :
Admin Fax Ext                   :
Admin Email                             :       
        GOOGLECLIENTS@ENOM.COM
Investigation revealed that on 07.01.2014, the Honble Justice C.T.Selvam, High
Court of Judicature at Madras passed orders in Crl.O.P.No.27389/2013 filed by
Advocate Mahalakshmi to block/delete the objectionable contents/defamatory
articles available in www.savukku.netand instructed TRAI to probe into the matter
and also appointed Shri B.Kumar, Senior Advocate to assist the Court in this regard.
Hence, Shri Achimuthu Shankar created other website in the name of
www.savukku.in through the website registrar Godaddy.com. It is revealed from the
Statement of Account of Citi Bank Credit Card No. 4386280017803739 that Shri
Achimuthu Shankar made payment of INR 798.99to DNH*Godaddy.Com on
08.01.2014 through his Credit Card No. 4386280017803739. The registration details
of the website www.savukku.in taken from Whois.net by National Cyber Safety and
Security Standards, Chennai areas follows:- Domain Name : savukku.in Domain ID :
D8025319-AFIN Date Creation Date : 07.01.2014 10:22:41 UTC Updated Date :
14.07.2014 18:20:13 UTC Expiration Date : 17.01.2017 10:22:41 UTC Registrar details
Registrar : Gandi SAS Registrar IANA ID : R 91 AFIN Registrant details Registrant ID
: CS9201-GANDI Registrant Name : CYRIL THAMARAI SELVAM Registrant
Organization :
Registrant Street 1 : Madras High Court Registrant Street 2 : N.S.C. Bose Road
Registrant Street 3 : Parrys, George Town Registrant City : Chennai Registrant
State/Province :
Registrant Postal Code : 600001 Registrant Country : IN Registrant Phone :
+91.9444352479 Registrant Phone Ext :
Registrant Fax :
Registrant Fax Ext :
Registrant Email : ctselvam.noreply@gmail.com Admin details Admin ID :
CS9201-GANDI Admin Name : CYRIL THAMARAI SELVAM Admin Organization :Adv R.Mahalakshmi vs Commissioner Of Police on 21 July, 2014

Admin Street 1 : Madras High Court Admin Street 2 : N.S.C. Bose Road Admin Street
3 : Parrys, George Town Admin City : Chennai Admin State / Province :
Admin Postal Code : 600001 Admin Country : IN Admin Phone : +91.9444352479
Admin Phone Ext :
Admin Fax :
Admin Fax Ext :
Admin Email : ctselvam.noreply@gmail.com Investigation revealed that on
28.02.2014, the Honble Justice C.T.Selvam, High Court of Judicature at Madras
passed an order in Crl. O.P No.27389 of 2013 filed by Smt.Mahalakshmi, in which
directions were issued to the Group Co-Ordinator (Joint Secretary), Cyber Law
Division, Department Information Technology, New Delhi to block the entire website
www.savukku.net. Shri Achimuthu Shankar came to know about the Orders dated
28.02.2014 passed by Justice C.T.Selvam, High Court of Judicature at Madras to
block his web site www.savukku.net and he created three other websites in the name
of HonbleJustice C.T.Selvam viz. www.ctselvam.in, www.ctselvam.com &
www.ctselvam.net on 01.03.2014. The Registration details of the Account collected
from Godaddy through DEITY, New Delhi are as follows:- CTSELVAM.IN Registrant
:
Name : Suresh Ramasamy Company : Court business Email :
meesaimunusamy@gmail.com Address 1 : Cool Pettai Address 2 : Madras High Court
City : Kochi State/Province : Kerala Postal Code : 600095 Country : India Phone :
+91.9427920923 CTSELVAM.COM and CTSELVAM.NET Registrant :
Name : Registration Private Company : Domains By Proxy, LLC Email :
DBP@domainsbyproxy.com Address 1 : DomainsByProxy.com Address 2 : 14747 N
Northsight Blvd Suite 111, PMB 309 City : Scottsdale State/Province : Arizona Postal
Code : 85260 Country : United States Phone : +1.4806242599 Fax : +1.4806242598
Credit Card Transactions:
Date                            :       2/28/2014 7:40:34 PM By customer via Online
IP                              :       95.130.9.89
Transaction Occurred as :       Swiss Franc (CHF)
Payment 1                       :       CHF 200.71
Paid                            :       Credit Card
Name                            :       ACHIMUTHU SHANKAR
Credit card Number      :       ############3739
Credit card Information : Visa Exp. 8/2016
Investigation revealed from the Statement of Account of Citi Bank Credit Card No.
4386280017803739 that ShriAchimuthu Shankarmade payment of INR 14,771.65
(Swiss Franc 200.71) to DNH*Godaddy.Com SWISS on 01.03.2014 through hisAdv R.Mahalakshmi vs Commissioner Of Police on 21 July, 2014

Credit Card No. 4386280017803739 for the creation of these three websites i.e.
www.ctselvam.in, www.ctselvam.com & www.ctselvam.net. Investigation further
revealed that ShriK.Pothi, S/o. Late Kalimuthu, a Diploma holder and Graduate in
Electronics & Communication was working as a freelancer and doing business of
server management and website hosting in odesk.com. He was a permanent reader of
articles published in www.savukku.net and timeline and link of face book Account of
Shri Achimuthu Shankar. ShriPothiKalimuthuused to write his own comments and
thoughts for the articles published in the www.savukku.net and conveyed comments
on Shankars Face book account. Shri Pothi has his own web sites in the names of
www.tinywp.in, www.tinywp.com, www.tiny.net and www.Pothi.info. Shri Pothi was
also having his own server in digital ocean.com., Linode.com and amazon.com/aws.
In the beginning of the year 2014, ShriPothiKalimuthu came to know through the
face book time line of Shri Achimuthu Shankar that www.savuku.net was blocked and
nobodycould read the contents of the website www.savukku.netwithin
India.Hence,ShriPothi created a new domain in the name of
www.newsavukku.comon 03.03.2014 through Gandi Uxembourg.com in the
registrant name of PothiKalimuthu, 4/118, Kambar Street, Kurunji Nagar, Reserve
Line, Madurai. Shri K.Pothi started reading the articles posted in www.savukku.net
through his website www.newsavukku.com. It is revealed from the Statement of
Account of Axis Bank Credit Card No. 4059950000148278 that Shri Pothi made
payment of INR Rs. 884.62 (EUR 10.00) to GandiUxembourg.com through
PAYPAL*VIMDONATION on 04.03.2014for the creation of website
www.newsavukku.com. The Registration details of the www.newsavukku.com
collected from GANDI through DEITY, New Delhi are as follows:- Domain Name :
newsavukku.com Date Creation Date : 03.03.2014 T15:56:44Z Updated Date :
16.02.2015 16T18:16:58Z Expiration Date : 03.03.2015 T15:56:44Z Registrar details
Registrar : Gandi SAS Registrar IANA ID : 81 Registrar Abuse Contact Email :
abuse@support.gandi.net Registrar Abuse Contact Phone : +33.170377661 Registrant
details Registrant Name : PothiKalimuthu Registrant Organization :
Registrant Street                       :       4/118, Kambar Street,                                                   Kurunji Nagar, Reserve Line, 
Registrant City                 :       Madhurai
Registrant State/Province               :       TN
Registrant Postal Code          :       625014
Registrant Country                      :       IN
Registrant Phone                        :       9894928049
Registrant Phone Ext            : 
Registrant Fax                  :       +33.143730576
Registrant Fax Ext                      :
Registrant Email                        :
90500b5f836bddf3497f3bb03e9a9d85-
1424831@contact.gandi.net
Admin details
Admin Name                              :       PothiKalimuthu
Admin Organization              :
Admin Street                    :       4/118, Kambar Street,                                                   Kurunji Nagar Reserve Line
Admin City                              :       MadhuraiAdv R.Mahalakshmi vs Commissioner Of Police on 21 July, 2014

Admin State / Province          :
Admin Postal Code                       :       625014
Admin Country                   :       IN
Admin Phone                     :       9894928049
Admin Phone Ext                 :
Admin Fax                               :
Admin Fax Ext                   :
Admin Email                             :
90500b5f836bddf3497f3bb03e9a9d85-
1424831@contact.gandi.net
Investigation revealed that on 29.03.2014, ShriPothi contacted ShriA.Shankar
through Facebook account and sent a message wherein he stated that
www.savukku.net is not accessible and he registered a new domain to mirror the
contents of www.savukku.net and he may see this at newsavukku.com and share it as
he wishes. Shri Achimuthu Shankar accepted the same and thereafter Shri Pothi
Kalimuthu pulled out the contents of the website www.savuku.net to the proxy
website www.newsavuku.com and hosted the same by using his server, so that the
people from India could read the articles published in www.savukku.net through the
proxy website www.newsavukku.com. The contents of the website www.savukku.net
were reappeared in the website www.newsavukku.com and later
www.newsavukku.com was also blocked during July 2014 on the directions of the
Honble High Court of Judicature at Madras. Investigation further revealed that Shri
Pothi Kalimuthu rendered his assistance in the maintenance of savukku
websites.ShriAchimuthu Shankar also introduced his friend Shri K.S. Nagarajan to
ShriPothiKalimuthu. In the process of Posting of Articles in the savukku websites,
initially Shri Shankarused Joomla CMS Platform, which was designed by Shri
Murugaiyan for the website www.savukku.net. Thereafter, Shri K.S.Nagarajan
suggested Shri Achimuthu Shankar to convert the entire articles of savukku websites
from Joomla CMS to Word Press. Shri Achimuthu Shankar also agreed for the
same and the contents of savukku websites were published by using Word Press
thereafter. Investigation revealed that on 30.04.2014, the Honble Justice
C.T.Selvam, High Court of Judicature at Madras passed orders in Crl. O.P No.27389
of 2013 filed by Smt. Mahalakshmi, in which directions were issued to the Addl.
Commissioner of Police, Cyber Crime, CCB, Chennai to co-ordinate with the Ministry
of Communication, New Delhi and Director of CERT-In to block the entire savukku
websites and directed to forward the copy to Google, Yahoo, Youtube, Facebook, etc.
On the same day itself i.e. 30.04.2014, the Honble Justice C.T.Selvam, High Court
of Judicature at Madras passed another order in Crl. O.P No.27389 of 2013 filed by
Smt. Mahalakshmi, in which directions were issued to ShriE.KhalieRaaj, Regional
Head, National Cyber Safety and Security Standards, Southern Region, Adyar,
Chennai that a team headed by Shri E.KhalieRaaj shall cause a detailed enquiry into
the posting, conduct setup, installation and all related information as they may access
pertaining to www.savuku.net or www.newsavukku.com or a direct or intermediary
link connecting to any website wherein the word savukku figures. Such authority
shall stand extended also to act in respect of other social networking sites such asAdv R.Mahalakshmi vs Commissioner Of Police on 21 July, 2014

Face book, Twitter, etc. Investigation revealed that Shri Achimuthu Shankar came to
know about the orders dated 30.04.2014 passed by Justice C.T.Selvam, High Court of
Judicature at Madras, directing the agency i.e. National Cyber Safety & Security
Standards to pursue and block the entire savukku websites and thus Godaddy, USA
blockedthe website www.newsavukku.comand other savakku websites. Shri
Achimuthu Shankar instructed Shri Pothi Kalimuthu to re-register the website
www.savukku.in from Godaddy to Gandi SAS, France, so that the authorities in India
could not block the savukku websites. Accordingly, Shri Pothi Kalimuthu
re-registered the website www.savukku.in through Gandi Uxembourg.Com in the
existing registrant name of Cyril Thamarai Selvam. It is revealed from the Statement
of Account of Axis Bank Credit Card No. 4059950000148278 of Shri Pothi
Kalimuthu that an amount of INR Rs.774.33 ($12.50) was paid to Gandi
Uxembourg.Com on 15.05.2014.Thereafter, they posted all backupof
www.savukku.net and subsequent savukku websitesthrough the new website
www.savukku.in. The Registration details of the www.savukku.incollected from
Gandi through DEITY, New Delhi are as follows:- Domain Name : savukku.in
Domain ID : D8025319-AFIN Date Reg Creation Date : 07.01.2014 10:22:41 Updated
Date : 15.05.2015 09:35:14 Expiration Date : 07.01.2017 10:22:41 Created :
15.05.2014 11:22:41 Changed : 20.08.2014 19:42:49 Registrar details Registrar :
Gandi SAS Registrar IANA ID : R 91 AFIN Registrant details Registrant ID :
CS9201-GANDI Registrant Name : CYRIL THAMARAI SELVAM Registrant
Organization :
Registrant Street 1 :
Registrant Street 2 :
Registrant City :
Registrant State/Province :
Registrant Postal Code :
Registrant Country :
Registrant Phone :
Registrant Phone Ext :
Registrant Fax :
Registrant Fax Ext :Adv R.Mahalakshmi vs Commissioner Of Police on 21 July, 2014

Registrant Email : ctselvam.noreply@gmail.com Admin details Admin ID :
CS9201-GANDI Admin Name : CYRIL THAMARAI SELVAM Admin Organization :
Admin Street 1 :
Admin Street 2 :
Admin Street 3 :
Admin City :
Admin State / Province :
Admin Postal Code :
Admin Country :
Admin Phone :
Admin Phone Ext :
Admin Fax :
Admin Fax Ext :
Admin Email : ctselvam.noreply@gmail.com Investigation revealed that Shri
Achimuthu Shankar and Shri Pothi Kalimuthu came to know that the website
www.savukku.in registered with Gandi SAS was also in holding position by the
Registrar Gandi SAS. Hence, they created a new website in the name of
www.newsavukku.org on 19.06.2014 through Gandi SAS in the registrant name of
Pothi Kalimuthu. It is revealed from the Statement of Account of Axis Bank Credit
Card No. 4059950000148278 of Pothi Kalimuthu that an amount Rs. 854.51
($13.65) was paid to Gandi Uxembourg.Com on 19.06.2014 by ShriPothiKalimuthu
(A-4) through his Axis Bank Credit Card No. 4059950000148278. The Registration
details of the website www.newsavukku.orgcollected from Gandi through DEITY,
New Delhi are as follows:-
Domain Name                     :       newsavukku.org
Domain ID                               :       D173025506-LROR 
Date 
Creation Date                   :       19.06.2014       T17:12:35.Z
Updated Date                    :       09.08.2014       T03:47:01.Z
Registry Expiry Date            :       19.06.2015       T17:12:35.Z
Registrar details
Sponsoring Registrar            :       Gandi SAS 
Registrar ID                            :       R42 - LRORAdv R.Mahalakshmi vs Commissioner Of Police on 21 July, 2014

Registrar Abuse Contact Email   :       abuse@support.gandi.net
Registrar Abuse Contact Phone   :       +33.170377661
Registrant details
Registrant ID                   :       PK1428 Gandi
Registrant Name                 :       PothiKalimuthu
Registrant Organization         : 
Registrant Street                       :       4/118, Kambar Street,   
                                                Kurunji Nagar, Reserve Line
Registrant City                 :       Madhurai
Registrant State/Province               :       TN
Registrant Postal Code          :       625014
Registrant Country                      :       IN
Registrant Phone                        :       +919894928049
Registrant Phone Ext            : 
Registrant Fax                  :       
Registrant Fax Ext                      :
Registrant Email                        :
90500b5f836bddf3497f3bb03e9a9d85-
1424831@contact.gandi.net
Admin details
Admin ID                                :       PK1428 Gandi
Admin Name                              :       PothiKalimuthu
Admin Organization              :
Admin Street                    :       4/118, Kambar Street,                                                   Kurunji Nagar, Reserve Line
Admin City                              :       Madhurai
Admin State / Province          :       TN
Admin Postal Code                       :       +91 9894928049
Admin Country                   :       IN
Admin Phone                     :
Admin Phone Ext                 :
Admin Fax                               :
Admin Fax Ext                   :
Admin Email                             :
90500b5f836bddf3497f3bb03e9a9d85-
1424831@contact.gandi.net
Registry Bill ID                        :       PK 1428  GANDI
Bill Name                               :       PothiKalimuthu
Bill Organization 
Bill Street                             :       4/118, Kambar/Street,                                                   Kurunji Nagar, Reserve Line.
Bill City                               :       Madhurai
Bill State/Province                     :       TN
Bill Postal Code                        :       625014
Bill Country                            :       IN
Bill Phone                              :       +919894928049
Bill E-mail: 
90500b5f836bddf3497f3bb03e9a9d85-1424831@contact.gandi.net
Name Server                             :       A.DNS.GANDI.NET
Investigation revealed that after the blocking of website www.newsavukku.com, the
entire contents of www.savukku.net and www.newsavukku.com had reappeared in
www.newsavukku.org on 16.07.2014 and subsequently www.newsavukku.org wasAdv R.Mahalakshmi vs Commissioner Of Police on 21 July, 2014

also blocked during July 2014. Investigation further revealed that while passing
orders for blocking/holding the savukku websites by the Honble Justice C.T.Selvam
and while blocking the savukku websites by the registrars of websites i.e.
Godaddy&Gandi SAS, Shri Achimuthu Shankar and Shri Pothi Kalimuthu created a
new website in the name of www.savukkuonline.com through the registrar Gandi SAS
on 14.07.2014 in the registrant name Cyril Thamarai Selvam, No.1 NSC, Bose Road,
Chennai, TN, 600104 in email id
1d337f1e4f9af62ee23c5cc370f6f6211931176@contact.gandi.net with Phone No.+33
170377666. It is revealed from the Statement of Account of Citi Bank Credit Card No.
4386280017803739 that Shri Achimuthu Shankar made payment of INR Rs. 968.24
($15.50) to Gandi Uxembourg.Com on 13.07.2014 through his Credit Card No.
4386280017803739 for the registration of website www.savukkuonline.com. The
Registration details of the website www.savukkuonline.comcollected from Gandi
through DEITY, New Delhi are as follows:- Domain Name : savukkuonline.com
Registry Domain ID : 1866901815_DOMAIN_COM-VRSN Date Updated Date :
03.12.2014 T13:52:29.Z Creation Date : 14.07.2014 T21:39:34.Z Registrar
Registration Expiration Date : 14.07.2015 T21:39:34.Z Registrar details Registrar :
Gandi SAS Registrar IANA ID : 81 Registrar Abuse Contact Email :
abuse@support.gandi.net Registrar Abuse Contact Phone : +33.170377661 Registrant
details Registrant Name : Cyril Thamari Selvam Registrant Organization :
Registrant Street : No.1 NSC, Bose Road Registrant City : Chennai Registrant
State/Province : TN Registrant Postal Code : 600104 Registrant Country : IN
Registrant Phone : +91 9444352479 Registrant Phone Ext :
Registrant Fax :
Registrant Fax Ext :
Registrant Email :
1d337f1e4f9af62ee23c5cc370f6f621-
1931176@contact.gandi.net
Admin details
Admin Name                              :       Cyril ThamaraiSelvam
Admin Organization              :
Admin Street                    :       No.1 NSC, Bose Road
Admin City                              :       Chennai
Admin State / Province          :       TN
Admin Postal Code                       :       600104
Admin Country                   :       IN
Admin Phone                     :       +91 9444352479
Admin Phone Ext                 :
Admin Fax                               :
Admin Fax Ext                   :
Admin Email                             :Adv R.Mahalakshmi vs Commissioner Of Police on 21 July, 2014

1d337f1e4f9af62ee23c5cc370f6f621-
1931176@contact.gandi.net
Investigation revealed that the website www.savukkuonline.com has not been
blocked. Investigation revealed that Honble Justice C.T.Selvam, High Court of
Judicature at Madras passed Orders dated 21.07.2014 in Crl. OP No. 27389 of 2013
filed by Mahalakshmi, in which directions were given to CCB to proceed with the
investigation based on the Interim Report filed by the Special Team, National Cyber
Safety & Security Standards, Chennai. Investigation also revealed that on the same
day i.e. 21.07.2014 Honble Justice C.T.Selvam passed Orders in the same
Crl.O.P.No.27389 of 2013, in which the Honble High Court suo-motto impleaded
Google India Pvt. Ltd., 8 & 9th Floor, Tower C, Building No.8, DLF Cyber City,
Gurgaon, India and Facebook India Pvt. Ltd., Building No.20, Raheja Mind Space,
Hi-Tech City Main Road, Vittal Rao Nagar, Hyderabad as party Respondent 3 & 4
and this was to be effected through 2nd Respondent i.e. Inspector of Police, Cyber
Crime, CCB, Chennai. It is also revealed that during the investigation conducted by
Cyber Crime, CCB, Chennai, they arrested ShriPothiKalimuthu on 24.07.2014 by
arraigning him as accused. The confessional statement of ShriPothi was recorded in
the presence of independent witnesses regarding the creation of the above websites.
He was remanded to Judicial Custody and further lodged in Puzhal Prison for about
45 days. Shri Achimuthu Shankar obtained Anticipatory Bail from the Honble High
Court of Judicatureat Madras. Investigation revealed that Honble Justice
C.T.Selvam, High Court of Judicature at Madras passed Orders dated 28.08.2014 in
Crl. OP No. 27389 of 2013 filed by Mahalakshmi, in which the Honble Court
suo-motto impleaded Secretary, Ministry of Communication and Information
Technology, Department of Telecommunication, Govt. of India, New Delhi as
Respondent-5 and the Director (DS-II), Ministry of Communication and Information
Technology, Department of Telecommunication, Govt. of India, New Delhi as
Respondent-6 in the case. In the same orders, the detailed investigation conducted by
the Special Team was also mentioned. Investigation revealed that Shri Pothi
Kalimuthu filed Bail Petition before the Honble High Court of Judicature at Madras
and he was granted conditional bail on 05.09.2014 by the Honble High Court of
Judicature at Madras. After the release of ShriK.Pothi on bail, Shri Achimuthu
Shankar instructed him to create a new website in the name of
www.savukkunews.com. Accordingly, Shri Pothi Kalimuthu created a new website in
the name of www.savukkunews.com on 13.10.2014 through GUI Gandi US Inc in the
Registrant name of Shri Mike P.Sinn, US. It is revealed from the Statement of
Account of Axis Bank Credit Card No. 4059950000148278 of PothiKalimuthu that an
amount Rs. 990.54 ($15.50) was paid to GUI*Gandi US Inc. on 15.10.2014 for the
registration of website www.savukkunews.com. The Registration details of the
website www.savukkunews.com collected from Gandi through DEITY, New Delhi are
as follows:- Domain Name : savukkunews.com Registry Domain ID :
1880273852_DOMAIN_COM_VRSN Date Updated Date : 14.10.2014 T14:19:08.Z
Creation Date : 13.10.2014 T23:32:53.Z Registrar Registration Expiration Date :
13.10.2015 T23:32:53.Z Registrar details Registrar : Gandi SAS Registrar IANA ID :Adv R.Mahalakshmi vs Commissioner Of Police on 21 July, 2014

81 Registrar Abuse Contact Email : abuse@support.gandi.net Registrar Abuse
Contact Phone : +33.170377661 Registrant details Registrant Name : Mike P.Sinn
Registrant Organization :
Registrant Street : 167, Glenwood Drive, Registrant City : Glen Carbon Registrant
State/Province :
Registrant Postal Code : 62034 Registrant Country : US Registrant Phone :
+16183910002 Registrant Phone Ext :
Registrant Fax :
Registrant Fax Ext :
Registrant Email :
915a92ce3edd9846ac363a64d3988ab8-
2375944@contact.gandi.net
Admin details
Admin Name                              :       Mike P.Sinn
Admin Organization              :
Admin Street                    :       167, Glenwood Drive 
Admin City                              :       Glen Carbon
Admin State / Province          :
Admin Postal Code                       :       62034
Admin Country                   :       US
Admin Phone                     :       +16183910002
Admin Phone Ext                 :
Admin Fax                               :
Admin Fax Ext                   :
Admin Email                             :
915a92ce3edd9846ac363a64d3988ab8-2375944@contact.gandi.net
Registry Bill ID                        :       PK 1428  GANDI
Bill Name                               :       PothiKalimuthu
Bill Organization
Bill Street                             :       4/118, Kambar/Street,                                                   Kurunji Nagar, Reserve Line.
Bill City                               :       Madhurai
Bill State/Province                     :       TN
Bill Postal Code                        :       625014
Bill Country                            :       IN
Bill Phone                              :       +919894928049
Bill E-mail: 
90500b5f836bddf3497f3bb03e9a9d85-1424831@contact.gandi.net
Name Server                             :       A.DNS.GANDI.NET
Investigation further revealed that since the Honble High Court of Judicature at
Madras passed orders to block the entire websites in the name of savukku from all
ISP Providers and Website Service Providers, Shri Achimuthu Shankar registered aAdv R.Mahalakshmi vs Commissioner Of Police on 21 July, 2014

website by name www.tamilwhip.com on 06.11.2014 through Gandi SAS, in which
there was no word/letter savukku figured. He registered this website by giving his
own name as registrant i.e. Achimuthu Shankar, Obfuscated whois Gandi-63-65
boulevard Massena - Paris in email id
04136d4cba6b45b6bcfc44882f2095192517508@contact.gandi.net with Phone
No.+33.143730576. It is revealed from the Citi Bank Credit Card Payment details in
the name of ShriAchimuthu Shankar vide Credit Card No. 4386280017803739 that
an amount of Rs. 991.20 ($15.50) was paid to Gandi Uxembourg.Com on 06.11.2014.
The registration details of www.tamilwhip.com taken from who is.netby National
Cyber Safety and Security Standards are as follows: Domain Name : tamilwhip.com
Registry Domain ID : 1883905742_DOMAIN_COM_VRSN Date Updated Date :
07.11.2014 T15:48:05.Z Creation Date : 06.11.2014 T12:48:45.Z Registrar
Registration Expiration Date : 06.11.2015 T12:48:45.Z Registrar details Registrar :
Gandi SAS Registrar IANA ID : 81 Registrar Abuse Contact Email:
abuse@support.gandi.net Registrar Abuse Contact Phone: +33.170377661 Registrant
details Registrant Name : Achimuthu Shankar Registrant Organization :
Registrant Street : Obfuscated whois Gandi-63-65 boulevard Massena Registrant City
: Obfuscated whoisGandi-Paris Registrant State/Province : Registrant Postal Code :
75013 Registrant Country : FR Registrant Phone : +33.170377666 Registrant Phone
Ext :
Registrant Fax : +33.143730576 Registrant Fax Ext :
Registrant Email :
04136d4cba6b45b6bcfc44882f209519-2517508@contact.gandi.net Admin details
Admin Name : Achimuthu Shankar Admin Organization :
Admin Street : Obfuscated whois Gandi-63-65 boulevard Massena Admin City :
Obfuscated whoisGandi-Paris Admin State / Province :
Admin Postal Code : 75013 Admin Country : FR Admin Phone : +33.170377666
Admin Phone Ext :
Admin Fax : +33.143730576 Admin Fax Ext :
Admin Email :
04136d4cba6b45b6bcfc44882f209519-2517508@contact.gandi.net Investigation
revealed that Shri Achimuthu Shankar published articles in the website
www.savukku.net against Smt. Mahalakshmi and others which were defamatory in
nature and made it available in the website for public view with the intention to insult
the modesty of Smt. Mahalakshmi, thereby intruded upon her privacy, which causedAdv R.Mahalakshmi vs Commissioner Of Police on 21 July, 2014

damage/injury to her image among public and thereby he committed the offences
punishable u/sec.509 IPC. Shri A.Shankar posted these articles which were
defamatory in nature in the website, by which he caused injury to the character and
moral of Smt. Mahalakshmi and put her into shame or embarrassment in public and
caused nuisance in her day to day life,thereby Shri Shankar committed the offences
punishable u/sec. 4 of Tamil Nadu Prohibition of Harassment of Woman Act, 1998.
Hence, Charge Sheet was filed before the Court of Ld. Addl. Chief Metropolitan
Magistrate, Egmore, Chennai against Shri A.Shankar for the offences punishable
u/sec. 509 IPC and sec. 4 of TNPHW Act, 1998. Investigation further revealed that
ShriA.Shankar, despite knowing the case registered by Cyber Crime, Central Crime
Branch, Chennai based on the orders of the Ld. Chief Metropolitan Magistrate Court,
continued to publish the said defamatory articles in the website www.savukku.net.
Though there were clear cut directions given by the Honble High Court of
Judicature at Madras to block the website www.savukku.net and remove the
defamatory articles, Shri Shankar created various other new websites viz.
www.savukku.in, www.newsavukku.com, www.ctselvam.com, www.ctselvam.in,
www.ctselvam.net, www.newsavukku.org, www.savukkunews.com and
www.savukkuonline.com, with the assistance of ShriPothi and continued posting
various articles including the backup of the already existing articles in these
subsequent websites. These acts of Shri A.Shankar and Shri Pothi Kalimuthu amount
to Contempt of the Honble High Court of Madras and hence this Self Contained
Note is being sent to the Honble High Court of Madras to initiate Contempt
Proceedings against them.
18. Thus, it is seen that Shankar s/o.Aachimuthu, a constable under suspension and one who has
been arrested and released on bail in a CBCID case has repeatedly indulged in brazen acts of
contempt. That such act continues to this present day is borne out by the fact that the website viz.,
www.savukkuonline.com, is presently functional. The registrant's name for the site contemptuously
stands informed as Cyril Thamarai Selvam, which, we may remind, is the name of a sitting Judge of
this Court, as does the admin name and depicts the continuous nature of contempt.
The investigating agency has informed that the payment for the service has been made by Shankar
s/o.Aachimuthu Shankar using his City Bank Credit Card No.4386280017803739. Being of the view
that gross criminal contempt of this Court has been repeatedly and continuously indulged in, this
Court in exercise of powers under Article 215 of the Constitution of India directs the Registrar
(Judicial) of this Court to issue statutory notice of Contempt to Shankar S/o.Aachimuthu, No.12/6,
TNHB Flats, Madhuravoyal, Chennai, returnable in four weeks. Thereafter, the matter may be
placed before My Lord The Honourable The Chief Justice towards being posted before an
appropriate Bench.
21.06.2016 Index:yes Internet:yes gm To
1.The Commissioner of Police, Greater Chennai, Egmore.Adv R.Mahalakshmi vs Commissioner Of Police on 21 July, 2014

2.The Inspector of Police, Cyber Crime, Greater Chennai, Egmore.
3.The Secretary, Ministry of Communication and Information Technology, Department of
Telecommunication, Government of India, New Delhi.
4.The Director (DS-II), Ministry of Communication and Information Technology, Department of
Telecommunications, Government of India, New Delhi.
5.The Group Co-ordinator (Joint Secretary), Cyber Law Division, Department of Information
Technology, Ministry of Communication and Information Technology, Government of India,
Electronic Niketan No.6, Central Government Offices Complex, New Delhi  110 003.
C.T.SELVAM, J gm Pre-delivery order in CRL.O.P.Nos.27389 of 2013, 16652, 16678 of 2014,
Crl.O.P.No.Sr.43843 of 2013 and Contempt Petition No.447 of 2015 21.06.2016Adv R.Mahalakshmi vs Commissioner Of Police on 21 July, 2014

