Dr. Rini Johar & Anr. vs State Of M.P.&Ors.; on 3 June, 2016
Equivalent citations: AIR 2016 SUPREME COURT 2679, 2016 (11) SCC 703,
AIR 2016 SC( CRI) 1025, 2016 (3) AJR 194, (2017) 1 GAU LR 471, (2016) 2 GAU
LT 542, (2016) 3 KER LJ 613, (2016) 5 SCALE 780, (2016) 2 ALD(CRL) 235,
(2016) 3 BOMCR(CRI) 310, (2017) 1 CRIMES 203, 2016 CRILR(SC MAH GUJ)
626, (2016) 163 ALLINDCAS 98 (SC), (2016) 2 GUJ LH 607, (2016) 2 ORISSA
LR 486, (2016) 3 RECCRIR 300, (2016) 2 ALLCRIR 1827, 2016 ALLMR(CRI)
3113, (2016) 3 DLT(CRL) 232, (2016) 3 ALLCRILR 561, (2016) 3 MAD LJ(CRI)
501, (2016) 3 KER LT 502, (2016) 2 CRILR(RAJ) 626, (2016) 64 OCR 903, (2016)
95 ALLCRIC 568, 2016 CRILR(SC&MP) 626, 2017 (1) SCC (CRI) 364, 2016 (3)
KCCR SN 325 (SC)
Author: Dipak Misra
Bench: Shiva Kirti Singh, Dipak Misra
                               1
                                               REPORTABLE
           IN THE SUPREME COURT OF INDIA
           CRIMINAL ORIGINAL JURISDICTION
        WRIT PETITION (CRIMINAL) NO. 30 OF 2015
Dr. Rini Johar & Anr.                       ... Petitioners
                          Versus
State of M.P. & Ors.                        ... Respondents
                       JUDGMENT
Dipak Misra, J.
The petitioner no.1 is a doctor and she is presently pursuing higher studies in United States ofDr. Rini Johar & Anr. vs State Of M.P.&Ors.; on 3 June, 2016

America (USA). She runs an NGO meant to provide services for South Asian Abused Women in
USA. Petitioner no.2, a septuagenarian lady, is a practicing Advocate in the District Court at Pune
for last 36 years. Petitioner no.1 is associated with M/s. Progen, a US company.
Page 1
2. As the facts would unveil, the informant, respondent no.8 herein, had sent an email to the
company for purchase of machine Aura Cam, 6000, which is an Aura Imaging Equipment, in India
and the concerned company sent an email to the respondent making a reference to the petitioner
no.1. Thereafter, the said respondent sent an email asking her to send the address where he could
meet her and have details for making payment. He also expressed his interest to become a
distributor.
3. The informant visited the petitioner no.1 at Pune and received a demo of Aura Cam 6000 and
being satisfied decided to purchase a lesser price machine i.e. “Twinaura Pro” for a total sum of
Rs.2,54,800/-. He paid a sum of Rs.2,50,000/- for which a hand written receipt was given as the
proof of payment. During the course of the said meeting, the 8th respondent expressed his desire to
purchase a laptop of M/s. Progen of which the petitioner no. 1 was the representative. In pursuance
of the discussion, the laptop was given to him who acknowledged it by stating that he owed a sum of
Rs.4,800/- as balance consideration towards the Aura Cam and an amount of Page 2 USD 350
towards the laptop. An assurance was given for remitting the money within a short time. As averred,
the respondent no.8 had never raised any grievance relating either to the machine or the laptop.
Certain transactions between the informant and the US company have been mentioned and the
allegations have been made against the 8th respondent that he represented himself as the sole
distributor in India which was brought to the notice of the concerned police in the State of M.P. by
the competent authority of the company. The said facts really do not have much relevance to the lis
which we are going to adjudicate in the present writ petition.
4. When the matter stood thus, the respondent no.8 filed a complaint before the Inspector General
of Police, Cyber Cell, Bhopal alleging that the petitioner no.1 and Mr. Guy Coggin had committed
fraud of US 10,500. On the basis of the complaint made, FIR no. 24/2012 under Section 420 and 34
of the Indian Penal Code (IPC) and Section 66-D of the Information Technology Act, 2000 (for
brevity, ‘the Act’) was registered against the petitioners by Cyber Police Headquarters, Bhopal, M.P.
The respondent no.2, I.G. Page 3 Cyber Cell, issued an order on 20.11.2012 which is to the following
effect:-
“Cyber state police having registered FIR 24/2012 under S 420, 34 of Indian Penal
Code and 66 D of IT Act search and information the undersigned persons are asked
to go to Pune.
1. R.R. Devendra Sisodia
2. R.R. (Lady) Ishrat Praveen KhanDr. Rini Johar & Anr. vs State Of M.P.&Ors.; on 3 June, 2016

3. RR (Lady) Valari Upadhyay”
5. On 21.11.2012, Dy. S.P. State Cyber Police, Bhopal proceeded to pass the following order:-
“Cyber state police having registered FIR 24/2012 under S 420, 34 Indian Penal Code
and S 66 D of IT Act accused Rini Johar and Gulshan Johar should be arrested and
for that lady constable Ishrat Khan has been deputed with case diary with address
from where they are to be found and arrested and it is ordered that they be brought to
Bhopal. In reference to which you have been given possession of the said case diary.”
6. We have reproduced the said orders in entirety as the same has immense relevance to the relief
sought for by the petitioners.
7. As the narration would unfurl, on 27.11.2012, the petitioners were arrested from their residence at
Pune. Various assertions have been made as regards the legality of the arrest which cover the
spectrum of non-presence of Page 4 the witnesses at the time of arrest of the petitioners,
non-mentioning of date, and arrest by unauthorized officers, etc. It is also asserted after they were
arrested, they were taken from Pune to Bhopal in an unreserved railway compartment marked –
‘viklang’ (handicapped). Despite request, the petitioner no.2, an old lady, was not taken to a doctor,
and was compelled to lie on the cold floor of the train compartment without any food and water.
Indignified treatment and the humiliation faced by the petitioners have been mentioned in great
detail. On 28.11.2012, they were produced before the learned Magistrate at Bhopal and the
petitioner no. 2 was enlarged on bail after being in custody for about 17 days and the petitioner no.1
was released after more than three weeks. There is allegation that they were forced to pay Rs.5 lakhs
to respondent no.3, Deepak Thakur, Dy. S.P. Cyber Cell, Bhopal. On 18.12.2012, chargesheet was
filed and thereafter a petition under Section 482 CrPC has been filed before the High Court for
quashment of the FIR.
8. At this stage, it is pertinent to state that on 19.2.2015 the petitioners filed an application for
discharge and the Page 5 learned Magistrate passed an order discharging the petitioners in respect
of the offence punishable under Section 66-D of the Act. However, learned Magistrate has opined
that there is prima facie case for the offence punishable under Section 66-A(b) of the Act read with
Section 420 and 34 of the IPC.
9. Ordinarily, we would have asked the petitioners to pursue their remedy before the High Court.
But, a disturbing one, petitioners while appearing in person, agonizingly submitted that this Court
should look into the manner in which they have been arrested, how the norms fixed by this Court
have been flagrantly violated and how their dignity has been sullied permitting the atrocities to
reign. It was urged that if this Court is prima facie satisfied that violations are absolutely
impermissible in law, they would be entitled to compensation. That apart, it was contended that no
case is made out against them and the order of discharge is wholly unsustainable. Regard being had
to the said submission, we appointed Mr. Sunil Fernandes as Amicus Curiae to assist the Court.
Page 6Dr. Rini Johar & Anr. vs State Of M.P.&Ors.; on 3 June, 2016

10. In this writ petition, first we shall address to the challenge relating to the validity and legality of
arrest, advert to the aspect whether the petitioners would be entitled to any compensation on the
bedrock of public law remedy and thereafter finally to the justifiability of the continuance of the
criminal proceedings. Be it stated here that this Court on 7.12.2015, taking note of the submissions
of the petitioners that they are not interested to prosecute their petition under Section 482 CrPC
directed that the said petition is deemed to have been disposed of. It is also requisite to note here
that despite efforts being made by the petitioners as well as the State of M.P, respondent no.8, who
belongs to Jabalpur, M.P. could not be served. This Court is inclined to infer that the said
respondent is really not interested to appear and contest.
11. As stated earlier, first we shall advert to the legality of arrest and detention. Mr. Saurabh Mishra,
learned counsel appearing for the State of M.P. has submitted that as the State Government had
already conducted an enquiry in this regard and initiated proceedings against the 3 rd respondent,
the matter should not be adjudicated at this Page 7 stage. We are not disposed to accept the said
submission, for initiation of a disciplinary proceeding or criminal prosecution should not be an
impediment for delineation as regards the violation of procedure of arrest and curtailment of liberty.
12. We consider it imperative to refer to the enquiry made by the State and the findings arrived at by
the enquiry officer. It is asserted in the counter affidavit that the petitioners had made a complaint
to the Lokayukta Police (M.P. Special Police Establishment) alleging that Deepak Thakur,
respondent no.3 herein, demanded a bribe of Rs.10 lakhs for letting them go and pursuant to the
said demand, initially a sum of Rs.2,50,000/- was paid and subsequently a sum of Rs.2,50,000/-
was also given. The Lokayukta Police had already registered a preliminary enquiry no. 33/2015 and
after enquiry submitted an enquiry report dated 18.6.2015 stating that prima facie case had been
made out against Deepak Thakur, Dy. S.P., Cyber Cell, Bhopal, Ishrat Khan, Head Constable, Cyber
Cell, Bhopal, Inderpal, Writer, Cyber Cell Bhopal and Saurabh Bhat, Clerk, Cyber Cell, Bhopal under
Section Page 8 13(1)(d) and Section 13(2) of the Prevention of Corruption Act, 1988 and Section
120B IPC. Based on the said preliminary enquiry report, FIR No. 273/2015 dated 27.3.2015 has
been registered against the accused persons in respect of the said offences and further steps under
the CrPC are being taken. Be it clarified, we are not at all concerned with the launching of said
prosecution and accordingly we shall not advert to the same.
13. It is perceivable that the State in its initial affidavit had stated that the Director General of Police
by its order dated 8.7.2015 had appointed Inspector General of Police, CID to enquire into the
allegations as regards the violation of the provisions enshrined under Section 41-A to 41-C of CrPC.
It needs to be stated here that in pursuance of the order passed by the Director General, an enquiry
has been conducted by Inspector General of Police Administration, CID, Bhopal. It has been styled
as “preliminary enquiry”. The said report dated 19.08.2015 has been brought on record. The
Inquiring Authority has recorded the statement of Ms. Ishrat Praveen Khan. The part of her
statement reads as follows:-
Page 9 “… When I received the order, I requested DSP Shri Deepak Thakur that I was
not in the District Police Force. I do not have any knowledge about
IPC/Cr.P.C./Police Regulation/Police Act and Evidence Act, IT Act as I have notDr. Rini Johar & Anr. vs State Of M.P.&Ors.; on 3 June, 2016

obtained any training in Police Training School, nor do I have any knowledge in this
regard, nor do I have any knowledge to fill up the seizure memo and arrest memo.
Even after the request, DSP Shri Deepak Thakur asked in strict word that I must
follow the order. The duty certificate was granted to me on 26.11.2012, on which
Report No.567 time 16.30 was registered, in which there are clear directions. In
compliance with this order, we reached Kondwa Police Station in Pune Maharashtra
on 27.11.2012 with my team and 2 constables and 1 woman constable were sent to
assist us from there. The persons of the police station Kondwa came to know reaching
Lulla Nagar that the said area does not fall under their police station area so the
police of Kondwa phoning Banwari Police Station got to bring the force for help
Banwari Police Station. I had given the written application in PS Banwari. The entire
team reached the house of Rini Johar and 01 laptop of Dell Company and 1 data card
of Reliance Company were seized. Rini Johar called her mother Gulshan Johar from
the Court furnishing information to her about her custody.
Thereafter, Shri Rini Johar had called up the Inspector General of Police, State Cyber Police Shri
Anil Kumar Gupta. I and my team had taken Miss Rini Johar and Smt. Gulshan in our custody. I
and Constable Miss Hemlata Jharbare conduced robe search of Miss Rini Johar and Smt. Gulshan
Johar. Nothing was found on their body.”
14. He has also recorded the statement of Devender Sisodia, Ms. Vallari Upadhyay, Ms. Hemlata
Jharbare and Page 10 thereafter recorded his findings. The findings arrived at in the preliminary
enquiry read thus:-
“24. Finding of the preliminary inquiry:- It was found during the preliminary enquiry
that Crime No.24/12 had been registered after the inquiry of one written complaint of
the applicant Shri Vikram Rajput, but this complaint inquiry report during the
investigation of the offence has been kept as the relevant evidence. The crime was
registered on 27.11.2012 under Section 420, 34 IPC read with Section 66D IT Act,
2000 against the named accused persons. The offence was to the effect that though
the alleged accused persons obtained Rs.5.00 lakh, they did not supply the camera
etc and they supplied the defective articles. This sale – purchase was conducted
through the online correspondence, due to which the section of IT Act was imposed.
It was found on the preliminary inquiry that Shri Vikram Rajput gave the payment of
Rs.2.50 lakh by the bank draft and the remaining payment by cash. The facts of the
payment and supply are now disputed and the trial of Crime No.24/12 is pending in
the competent Court. Therefore, to give any inquiry finding on it would not be
proper. It is clear from the documents attached to the case diary and the statement of
Shri Deepak Thakur that Shri Deepak Thakur sent 2 notices respectively by the post
and through the Deputy Commissioner, Economic Crime and Cyber Pune
respectively to Miss Rini Johar on 01.06.2012 and 02.07.2012 in the investigation of
the offence, but they did not appear before the Investigator. It has not been written
above both the notices if the notice has been issued under Section 41A of Cr.P.C. It is
also not clear whether or not these both notices were severed to Miss Rini Johar.Dr. Rini Johar & Anr. vs State Of M.P.&Ors.; on 3 June, 2016

25. This case is related to the alleged cheating between two persons in respect of sale
and Page 11 purchase of goods. The maximum sentence in Section 420 is the period
upto 7 years and similarly when the reasons mentioned in Section 41 (1)(B) are not
found, the suspects of the crime should be made to appear for the interrogation in the
investigation issuing notice to them. Justice Late Krishna Ayyer has held in Jolly
George Varghese v. Bank of Cochin1 that “No one shall be imprisoned merely on the
ground of inability to fulfill a contractual obligation”. Section 41(2) of Cr.P.C. grants
power to the Investigator that if the suspect does not appear for the investigation
despite the notice, he can be arrested, though this reason having been mentioned in
the case diary should have been produced before the Magistrate, but no reason for
the arrest has been mentioned in the case diary. No notice has been sent to the old
woman Smt. Gulshan Johar (aged about 70 years), nor has she played any role in
committing any offence. Only the draft of Rs.2.50 lakh had been deposited in her
account. No binding ground has been mentioned in respect of her arrest in the case
diary.” And again:-
“28. It has not been mentioned anywhere in the arrest memo and case diary that the
information of the arrest of both women was furnished to any of their relatives and
friends. It has become clear from the statements that when both the women were
arrested physically they were brought to PS Banwari Pune, where the arrest memo
was prepared. There is the signature of Shri Amol Shetty as the witness of the seizure
memo. Shri Deepak Thakur has stated in his statement that the handwriting of the
seizure memo is of the constable Shri Indrapal. Shri Indrapal did not go as a member
of the arresting persons to Pune. The seizure memo does not have the signature of
AIR 1980 SC 470 Page 12 Amol Shetty as well, which proves prima facie that the
seizure memo was not prepared on 27.11.2012 in Pune. The report no.29/12 dated
27.11.2012 of seeking police help in PS Banwari is recorded, but no information is
recorded at the police station that MP Police are taking by arresting these citizens
with them. As a result, the information of the arrested persons was neither furnished
in the District Police Control Room Pune, nor was it published there. It has also been
clarified in the preliminary inquiry that the accused persons after they were arrested
were not produced before the Local Judge and they were brought to Bhopal by rail.
Miss Ishrat Khan stated that she did not obtain the rail warrant of neither the
policepersons nor the accused during return due to paucity of time.” And finally:-
“As such, the facts of arresting both the suspected women and making seizure memo
searching their houses not fully following the procedure of arrest by the Investigator
and police team have come to the fore in the preliminary enquiry prima facie.”
15. Keeping the aforesaid facts in view, we may refer to the decisions in the field and the
submissions canvassed by Mr. Fernandes, learned Amicus Curiae.
16. In Joginder Kumar v. State of U.P. 2 while considering the misuse of police power of arrest, it
has been opined:-Dr. Rini Johar & Anr. vs State Of M.P.&Ors.; on 3 June, 2016

(1994) 4 SCC 260 Page 13 “No arrest can be made because it is lawful for the police
officer to do so. The existence of the power to arrest is one thing. The justification for
the exercise of it is quite another. … No arrest should be made without a reasonable
satisfaction reached after some investigation as to the genuineness and bona fides of
a complaint and a reasonable belief both as to the person’s complicity and even so as
to the need to effect arrest. Denying a person of his liberty is a serious matter.”
17. In the said case, the Court also voiced its concern regarding complaints of human rights pre and
after arrests and in that context observed:-
“The horizon of human rights is expanding. At the same time, the crime rate is also
increasing. Of late, this Court has been receiving complaints about violations of
human rights because of indiscriminate arrests. How are we to strike a balance
between the two?
A realistic approach should be made in this direction. The law of arrest is one of
balancing individual rights, liberties and privileges, on the one hand, and individual
duties, obligations and responsibilities on the other; of weighing and balancing the
rights, liberties and privileges of the single individual and those of individuals
collectively; of simply deciding what is wanted and where to put the weight and the
emphasis; of deciding which comes first — the criminal or society, the law violator or
the law abider ….” Page 14 After so stating, certain procedural requirements were set
down.
18. In D.K. Basu v. State of W.B.3, after referring to the authorities in Joginder Kumar (supra),
Nilabati Behera v. State of Orissa4 and State of M.P. v. Shyamsunder Trivedi5 the Court laid down
certain guidelines to be followed in cases of arrest and detention till legal provisions are made in
that behalf as preventive measures. The said guidelines read as follows:-
“(1) The police personnel carrying out the arrest and handling the interrogation of the
arrestee should bear accurate, visible and clear identification and name tags with
their designations. The particulars of all such police personnel who handle
interrogation of the arrestee must be recorded in a register. (2) That the police officer
carrying out the arrest of the arrestee shall prepare a memo of arrest at the time of
arrest and such memo shall be attested by at least one witness, who may either be a
member of the family of the arrestee or a respectable person of the locality from
where the arrest is made. It shall also be countersigned by the arrestee and shall
contain the time and date of arrest. (3) A person who has been arrested or detained
and is being held in custody in a police station or interrogation centre or other
lock-up, shall be entitled to have one friend or relative or other person known to him
or having interest (1997) 1 SCC 416 (1993) 2 SCC 746 (1995) 4 SCC 262 Page 15 in his
welfare being informed, as soon as practicable, that he has been arrested and is being
detained at the particular place, unless the attesting witness of the memo of arrest is
himself such a friend or a relative of the arrestee.Dr. Rini Johar & Anr. vs State Of M.P.&Ors.; on 3 June, 2016

(4) The time, place of arrest and venue of custody of an arrestee must be notified by
the police where the next friend or relative of the arrestee lives outside the district or
town through the Legal Aid Organisation in the District and the police station of the
area concerned telegraphically within a period of 8 to 12 hours after the arrest.
(5) The person arrested must be made aware of this right to have someone informed
of his arrest or detention as soon as he is put under arrest or is detained.
(6) An entry must be made in the diary at the place of detention regarding the arrest
of the person which shall also disclose the name of the next friend of the person who
has been informed of the arrest and the names and particulars of the police officials
in whose custody the arrestee is.
(7) The arrestee should, where he so requests, be also examined at the time of his
arrest and major and minor injuries, if any present on his/her body, must be
recorded at that time.
The “Inspection Memo” must be signed both by the arrestee and the police officer effecting the
arrest and its copy provided to the arrestee. (8) The arrestee should be subjected to medical
examination by a trained doctor every 48 hours during his detention in custody by a doctor on the
panel of approved doctors appointed by Director, Health Services of the State or Union Territory
concerned. Director, Health Services should prepare such a panel for all tehsils and districts as well.
Page 16 (9) Copies of all the documents including the memo of arrest, referred to above, should be
sent to the Illaqa Magistrate for his record. (10) The arrestee may be permitted to meet his lawyer
during interrogation, though not throughout the interrogation.
(11) A police control room should be provided at all district and State headquarters, where
information regarding the arrest and the place of custody of the arrestee shall be communicated by
the officer causing the arrest, within 12 hours of effecting the arrest and at the police control room it
should be displayed on a conspicuous notice board.”
19. Mr. Fernandes, learned Amicus Curiae, in a tabular chart has pointed that none of the
requirements had been complied with. Various reasons have been ascribed for the same. On a
scrutiny of enquiry report and the factual assertions made, it is limpid that some of the guidelines
have been violated. It is strenuously urged by Mr. Fernandes that Section 66-A(b) of the
Information Technology Act, 2000 provides maximum sentence of three years and Section 420
CrPC stipulates sentence of seven years and, therefore, it was absolutely imperative on the part of
the arresting authority to comply with the procedure postulated in Section 41-A of the Code of
Criminal Procedure. The Court in Arnesh Kumar v. State Page 17 of Bihar and another6, while
dwelling upon the concept of arrest, was compelled to observe thus:-
“Arrest brings humiliation, curtails freedom and casts scars forever. Lawmakers
know it so also the police. There is a battle between the lawmakers and the police andDr. Rini Johar & Anr. vs State Of M.P.&Ors.; on 3 June, 2016

it seems that the police has not learnt its lesson: the lesson implicit and embodied in
CrPC. It has not come out of its colonial image despite six decades of Independence,
it is largely considered as a tool of harassment, oppression and surely not considered
a friend of public. The need for caution in exercising the drastic power of arrest has
been emphasised time and again by the courts but has not yielded desired result.
Power to arrest greatly contributes to its arrogance so also the failure of the
Magistracy to check it. Not only this, the power of arrest is one of the lucrative
sources of police corruption. The attitude to arrest first and then proceed with the
rest is despicable. It has become a handy tool to the police officers who lack
sensitivity or act with oblique motive.”
20. Thereafter, the Court referred to Section 41 CrPC and analyzing the said provision, opined that a
person accused of an offence punishable with imprisonment for a term which may be less than seven
years or which may extend to seven years with or without fine, cannot be arrested by the police
officer only on his satisfaction that such person had committed the offence. It has been further held
that a (2014) 8 SCC 273 Page 18 police officer before arrest, in such cases has to be further satisfied
that such arrest is necessary to prevent such person from committing any further offence; or for
proper investigation of the case; or to prevent the accused from causing the evidence of the offence
to disappear; or tampering with such evidence in any manner; or to prevent such person from
making any inducement, threat or promise to a witness so as to dissuade him from disclosing such
facts to the court or the police officer; or unless such accused person is arrested, his presence in the
court whenever required cannot be ensured. These are the conclusions, which one may reach based
on facts. Eventually, the Court was compelled to state:-
“In pith and core, the police officer before arrest must put a question to himself, why
arrest? Is it really required? What purpose it will serve? What object it will achieve? It
is only after these questions are addressed and one or the other conditions as
enumerated above is satisfied, the power of arrest needs to be exercised. In fine,
before arrest first the police officers should have reason to believe on the basis of
information and material that the accused has committed the offence. Apart from
this, the police officer has to be satisfied further that the arrest is necessary for one or
the more purposes envisaged by sub-clauses
(a) to (e) of clause (1) of Section 41 CrPC.” Page 19
21. In the said authority, Section 41-A CrPC, which has been inserted by Section 6 of the Code of
Criminal Procedure (Amendment) Act, 2008 (5 of 2009) was introduced and in that context, it has
been held that Section 41-A CrPC makes it clear that where the arrest of a person is not required
under Section 41(1) CrPC, the police officer is required to issue notice directing the accused to
appear before him at a specified place and time. Law obliges such an accused to appear before the
police officer and it further mandates that if such an accused complies with the terms of notice he
shall not be arrested, unless for reasons to be recorded, the police officer is of the opinion that the
arrest is necessary. At this stage also, the condition precedent for arrest as envisaged under Section
41 CrPC has to be complied and shall be subject to the same scrutiny by the Magistrate as aforesaid.Dr. Rini Johar & Anr. vs State Of M.P.&Ors.; on 3 June, 2016

22. We have referred to the enquiry report and the legal position prevalent in the field. On a studied
scrutiny of the report, it is quite vivid that the arrest of the petitioners was not made by following the
procedure of arrest. Section 41-A CRPC as has been interpreted by this Court has not Page 20 been
followed. The report clearly shows there have been number of violations in the arrest, and seizure.
Circumstances in no case justify the manner in which the petitioners were treated.
23. In such a situation, we are inclined to think that the dignity of the petitioners, a doctor and a
practicing Advocate has been seriously jeopardized. Dignity, as has been held in Charu Khurana v.
Union of India7, is the quintessential quality of a personality, for it is a highly cherished value. It is
also clear that liberty of the petitioner was curtailed in violation of law. The freedom of an individual
has its sanctity. When the individual liberty is curtailed in an unlawful manner, the victim is likely to
feel more anguished, agonized, shaken, perturbed, disillusioned and emotionally torn. It is an
assault on his/her identity. The said identity is sacrosanct under the Constitution. Therefore, for
curtailment of liberty, requisite norms are to be followed. Fidelity to statutory safeguards instil faith
of the collective in the system. It does not require wisdom of a seer to visualize that for some
invisible reason, an attempt has been made to corrode the (2015) 1 SCC 192 Page 21 procedural
safeguards which are meant to sustain the sanguinity of liberty. The investigating agency, as it
seems, has put its sense of accountability to law on the ventilator. The two ladies have been arrested
without following the procedure and put in the compartment of a train without being produced
before the local Magistrate from Pune to Bhopal. One need not be Argus – eyed to perceive the
same. Its visibility is as clear as the cloudless noon day. It would not be erroneous to say that the
enthusiastic investigating agency had totally forgotten the golden words of Benjamin Disraeli:
“I repeat …. that all power is a trust – that we are accountable for its exercise – that,
from the people and for the people, all springs and all must exist.”
24. We are compelled to say so as liberty which is basically the splendor of beauty of life and bliss of
growth, cannot be allowed to be frozen in such a contrived winter. That would tantamount to
comatosing of liberty which is the strongest pillar of democracy.
25. Having held thus, we shall proceed to the facet of grant of compensation. The officers of the
State had played with the liberty of the petitioners and, in a way, Page 22 experimented with it. Law
does not countenance such kind of experiments as that causes trauma and pain. In Mehmood
Nayyar Azam v. State of Chhattisgarh8, while dealing with the harassment in custody, deliberating
on the concept of harassment, the Court stated thus:-
“22. At this juncture, it becomes absolutely necessary to appreciate what is meant by
the term “harassment”. In P. Ramanatha Aiyar’s Law Lexicon, 2nd Edn., the term
“harass” has been defined thus:
“Harass.—‘Injure’ and ‘injury’ are words having numerous and comprehensive
popular meanings, as well as having a legal import. A line may be drawn between
these words and the word ‘harass’, excluding the latter from being comprehended
within the word ‘injure’ or ‘injury’. The synonyms of ‘harass’ are: to weary, tire,Dr. Rini Johar & Anr. vs State Of M.P.&Ors.; on 3 June, 2016

perplex, distress tease, vex, molest, trouble, disturb. They all have relation to mental
annoyance, and a troubling of the spirit.” The term “harassment” in its connotative
expanse includes torment and vexation. The term “torture” also engulfs the concept
of torment. The word “torture” in its denotative concept includes mental and
psychological harassment. The accused in custody can be put under tremendous
psychological pressure by cruel, inhuman and degrading treatment.”
26. In the said case, emphasizing on dignity, it has been observed:-
(2012) 8 SCC 1 Page 23 “…..The majesty of law protects the dignity of a citizen in a
society governed by law. It cannot be forgotten that the welfare State is governed by
the rule of law which has paramountcy. It has been said by Edward Biggon “the laws
of a nation form the most instructive portion of its history”. The Constitution as the
organic law of the land has unfolded itself in a manifold manner like a living
organism in the various decisions of the court about the rights of a person under
Article 21 of the Constitution of India. When citizenry rights are sometimes dashed
against and pushed back by the members of City Halls, there has to be a rebound and
when the rebound takes place, Article 21 of the Constitution springs up to action as a
protector….”
27. In the case at hand, there has been violation of Article 21 and the petitioners were compelled to
face humiliation. They have been treated with an attitude of insensibility. Not only there are
violation of guidelines issued in the case of D.K. Basu (supra), there are also flagrant violation of
mandate of law enshrined under Section 41 and Section 41-A of CrPC. The investigating officers in
no circumstances can flout the law with brazen proclivity. In such a situation, the public law remedy
which has been postulated in Nilawati Behra (supra), Sube Singh v. State of Haryana9, Hardeep
Singh v. State of M.P.10, (2006) 3 SCC 178 (2012) 1 SCC 748 Page 24 comes into play. The
constitutional courts taking note of suffering and humiliation are entitled to grant compensation.
That has been regarded as a redeeming feature. In the case at hand, taking into consideration the
totality of facts and circumstances, we think it appropriate to grant a sum of Rs.5,00,000/- (rupees
five lakhs only) towards compensation to each of the petitioners to be paid by the State of M.P.
within three months hence. It will be open to the State to proceed against the erring officials, if so
advised.
28. The controversy does not end here. Mr. Fernandes, learned Amicus Curiae would urge that it
was a case for discharge but the trial court failed to appreciate the factual matrix in proper
perspective. As the matter remained pending in this court for some time, and we had dealt with
other aspects, we thought it apt to hear the learned counsel for the aspect of continuance of the
criminal prosecution. We have narrated the facts at the beginning. The learned Magistrate by order
dated 19.2.2015 has found existence of prima facie case for the offences punishable under Section
420 IPC and Section 66-A(b) of I.T. Act, 2000 Page 25 read with Section 34 IPC. It is submitted by
Mr. Fernandes that Section 66-A of the I.T. Act, 2000 is not applicable. The submission need not
detain us any further, for Section 66-A of the I.T. Act, 2000 has been struck down in its entirety
being violative of Article 19(1)(a) and not saved under Article 19(2) in Shreya Singhal v. Union ofDr. Rini Johar & Anr. vs State Of M.P.&Ors.; on 3 June, 2016

India11. The only offence, therefore, that remains is Section 420 IPC. The learned Magistrate has
recorded a finding that there has been no impersonation. However, he has opined that there are
some material to show that the petitioners had intention to cheat. On a perusal of the FIR, it is clear
to us that the dispute is purely of a civil nature, but a maladroit effort has been made to give it a
criminal colour. In Devendra v. State of U.P.12, it has been held thus:-
“.. it is now well settled that the High Court ordinarily would exercise its jurisdiction
under Section 482 of the Code of Criminal Procedure if the allegations made in the
first information report, even if given face value and taken to be correct in their
entirety, do not make out any offence. When the allegations made in the first
information report or the evidences collected during investigation do not satisfy the
ingredients of an offence, the superior courts would not encourage harassment of a
person in a criminal court for nothing”.
(2015) 5 SCC 1 (2009) 7 SCC 495 Page 26
29. In the present case, it can be stated with certitude that no ingredient of Section 420 IPC is
remotely attracted. Even if it is a wrong, the complainant has to take recourse to civil action. The
case in hand does not fall in the categories where cognizance of the offence can be taken by the court
and the accused can be asked to face trial. In our considered opinion, the entire case projects a civil
dispute and nothing else. Therefore, invoking the principle laid down in State of Haryana v. Bhajan
Lal13, we quash the proceedings initiated at the instance of the 8 th respondent and set aside the
order negativing the prayer for discharge of the accused persons. The prosecution initiated against
the petitioners stands quashed.
30. Consequently, the writ petition is allowed to the extent indicated above. There shall be no order
as to costs.
........................................J. [DIPAK MISRA] ........................................J. [SHIVA KIRTI SINGH]
NEW DELHI June 03, 2016.
1992 Supp. (1) SCC 335 Page 27Dr. Rini Johar & Anr. vs State Of M.P.&Ors.; on 3 June, 2016

