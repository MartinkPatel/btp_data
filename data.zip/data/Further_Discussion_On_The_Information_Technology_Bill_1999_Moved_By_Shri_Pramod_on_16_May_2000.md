Further Discussion On The Information Technology Bill, 1999
Moved By Shri Pramod ... on 16 May, 2000
Title: Further discussion ont the Information Technology Bill, 1999 moved by Shri Pramod Mahajan
on 15-7-2000. (Concluded.) MR. SPEAKER: Now, the House will take up further discussion on the
Information Technology Bill, 1999. Shri Subodh Mohite.
   () :  ,    ,  
  ,        ¡, ¢  ¡ £ ⁄ ¥ ƒ 
      ¥ ƒ £ ƒ ƒ    §  ¡¤ 
ƒ '“  « ƒ  ⁄¡¤  ‹   ›  ﬁƒ 
¡  ¤  '    ﬁƒ  ¡¤   
ﬁ ﬂ   «  ° ›  ﬁ         
ƒ ¤  ƒ–       ƒ   ƒ† 
ƒ  ⁄  ¡¤ '      ' ,     
 ¤            ‡ ¡ 
  ﬁ  ¤       ¡   ﬁ  ¢ - It
is the fourth mode of transportation. When we are calling it as an ocean, telecommunication, print
media, electronic media, computer, Internet, e-Commerce and e-Mail are some of the modern
techniques, which come under Information Technology.     ,   ›
 ¤   ﬁ    ,   ‡ ¡   ﬁ  ﬂ– 
 £   ¢  ¡¤ It is a heterogeneous Bill.     ·  
    ¢ ›  ﬂﬁ¤
 ⁄:  ƒ ¤ ƒ ƒ §-† ¤ We are authorising the signatures by
means of electronics. The second part is cyber laws and crime.        , 
 «         ƒ  › ›   One is
e-commerce. It is also a huge sector. The second is cyber laws and crime. I think, it will be a
homogenous Bill.
   ƒ       ƒ    ﬂ ' ¡ ¤
ƒ   ‡ ¡  There are two parts of implementation. One is literacy
and the second is education.        ' ƒ¡  ¡,
ƒ“- III ƒ¡  '  ‡  ,   ⁄  ¡, 
 ¡, §-µ†  ¡         ¶› ¡¤ 
ƒ¡   °ƒ   ¡¤    ¡¤ ¡ ƒ 
¶¤  ¶       ‹ † › 
ƒ  ,     ‹ƒ  ¤ That person is called an educated
person. That person is actually a manager of the electronics media and another person is called a
literate person. I am making a difference between literacy and education. With due regards 
 ﬂ¡  ﬁ.ƒ•  ‚ ¤     ¡, ‡ ⁄ 
¢  ƒ·    I know everything, his does not mean that I am educated. ‡ ¶ 
     „” ƒ   ƒ † †  ¶› Further Discussion On The Information Technology Bill, 1999 Moved By Shri Pramod ... on 16 May, 2000

¤   ƒ      The second part is about education. 
 ƒ ¶  ƒ·¤ I am quoting an example of Canada. ¡    
ﬁ.ƒ.  ›  ¶ƒ ,  ' ¶ƒ  ,    ' „”
ƒ ¶ƒ  ,  ›   ﬁ.ƒ.  ¶   ﬁ ﬁ
† †  ƒ.ﬁﬂ.›. ¡›“ ¢   £ ﬁ   ﬁ »
ﬁ.ƒ.  ¢  ¤  ﬂ ¡   ƒ  › '   ﬁ   '
…† †  ¶  , ƒ¡  ¤   †  
     ﬁ –  ‡  ¤ There is a section for controlling the crime. I am
not criticising the matter.  ƒ ⁄   ƒ ‰‰  "any Police Officer having the rank of
Dy SP…" ¤  ⁄ ﬁ  ›      † ﬁ ›
 ƒ    ‹ƒ     ›     ›.ﬁ.ƒ.
   ‹  ¤      ‹   † ƒ  
     °› ﬁ›  « ›› ¤   †
†    †  ,     ¶›
'? ﬁ    §           
ﬂ ﬁ¤ ‹   ƒ       †    ƒ¡
ƒ        „” ƒ   ›.ﬁ.ƒ.   ¤
They are not educated in information technology.
 ‡ ¡   ﬁ    ƒ  ƒ· because the Police Department
is a grey Department.  ƒ   ﬁ ¶ƒ ƒ ﬁ.‹§.‹¿. †    
 ¤ ﬁ     What is the preparatory plan to implement the information
technology in the Police Department to have better results. I think, there should be a separate
scheme.
SHRI PRIYA RANJAN DASMUNSI (RAIGANJ): IPS-IT.
   (): ,       ‹§.ƒ.ﬁ.  ‹§..  ¢ 
¤  ƒ   ﬂ       ¤ This should be provided by the
Central Government and there should be proper coordination between the States and the Centre.
,  ' ›  £     £  ,  Àƒ ' 
   ¡ ¤ We are approving the rules and we are recognising the signatures by
means of electronics.        ƒ       ƒ`¿ ,
   ƒ¡    ‡   ‹      ,  
–-–      ‹ƒ  ﬁ,  ƒ  ƒ 
 ﬁ    – '    ¤  ﬂ¡     ƒ
  ,        ﬁ¤
 ,    ﬂ  ﬁ ﬁ ¤  ƒ  › ƒ ›,
¡   ,  ﬁ › ﬁ     £ ﬂ¥¢    ‹
›    ¤   ﬁ ﬁƒ  ﬂ ¡¤  § ‹ ƒ
  §-     ﬂ ,      
›ƒ  ¶ƒ     ƒ ¶ §   ¢  ¤
 ,   £ ﬁ ›ƒ     ‹ƒ › ﬁFurther Discussion On The Information Technology Bill, 1999 Moved By Shri Pramod ... on 16 May, 2000

,  ‡     ƒ¡“  ¤ ‹ƒ  £ ›  ƒ·
 ¤
    ƒ '    ﬂ ¡    ﬂ–   ¤ I
am very happy to speak on this Bill. He is a very young and dynamic Minister.     –
 – ⁄  ¡ £ ⁄ ¡¤         –: 
ƒ     ¡ƒ  ' ' £      
 ¥¥    ƒ¡ ›   ƒ   ƒ 
¤ He is a Minister with a vision. I really appreciate this.
 ,   ƒ ﬁ  ‚ ¢¤  ƒ   §¤ ‹  ƒƒ  ' 
   ‹ ¤       '       ƒ 
       ¤    ƒ  ‚  ¤ ﬁﬂ
  ¥¥   ,     › ¤    
ƒ¡  ›  ¤       ƒ    ¤    ƒ¡ 
 ƒ ƒ-  ¢, ƒ–   ƒ-¡ ‹ £    ƒ-¢ ‹ ¤
  ¥¥       ﬂ   ¤   
› ƒ   ¤ There is certain life of technology.       ƒ 
    ¤        ,   ‚  ¤ There should be
positive criticism.        ¤
 ,   ,     ﬂ¡   ¥¥ 
'  § -ƒ  ¢,      ƒ     ¥ ƒ -ƒ 
ﬁ ¤  ﬂ    ⁄ ﬁ  ﬁ   ¤ I think, cyber space is
now everybody’s baby.
   ﬂ  (⁄):   , ¡ﬂ ƒ¥  ‹
  '  ƒ  ‹  ¤  '       '     ¢
‹ `¿  £ ƒ      `¿   ¢ · ¤   
      ˆ,   ,    ƒ   ¢ ƒ 
 · ƒ,       ,  ƒ   ¤
          ƒ¡“ ﬂ“ ‹ ¤ ¡˜    ·,
ƒ  ‹    ƒ    ‹    ﬁ  · ƒ  ¢¤ 
  ƒ - , '  , ƒ“        ƒ
¢¤ ¡ ﬂ“     ‹   ƒ  ‹  ,    ƒ ﬂ 
⁄  ¤ ƒ '⁄     £      “  
ƒ ¯  '›“  ,  ƒ`¿  ﬁ – –·  ¤
 ·    ﬂ“ ƒ ‹  ⁄· ¤ ¡ﬂ ƒ    
   ƒ  ƒ,      ¤ ¶ ¢    ﬂ  
     ¢     ﬂ £   ‹ «  ƒ¡  ¤ 
ﬁ ¡ ¢      ¤     ﬁ,    ƒ 
 ,      ¤   ¢       Further Discussion On The Information Technology Bill, 1999 Moved By Shri Pramod ... on 16 May, 2000

      ƒ–   ,  '  §     
‹ƒ      ¢       § ‹   ¢
  ‹   ƒ`¿ ƒ  ƒ ƒ'  ›   ¤   ƒ,
  ƒ        ,  ƒ'     ¤
ﬁ ‹ƒ  ƒ    '   ﬂ-  ¤     ‚
¤  ƒ ¢     ¡        ¡ﬂ ƒ
 ‡   ƒ ¤ ¶ ¢  ¡         
 ¯ ,   ¯      ƒ    '  ,
 ‹ '    ƒ¡“    ¡ﬂ ƒ     
  , ‹    -˘   ﬁ    , ¡ﬂ
ƒ  “ ƒ    ƒ     , 
 ¡   §  ,  ƒ ƒ     ' ƒ¡“ ﬁ¡ƒ 
 ƒ§ ¤ ‹ '    ¤ ﬁ   ¢     ‚›  
 ƒ  ﬂ   , ﬂ¤   ' ƒ“   , ƒ  
,  ƒ  ﬁ   ﬂ     §  ﬂ ,   ƒ 
 ‹¤
   ƒ   §,    ¢ ¤        £ 
       ﬁ ¢       ﬂ¡    ﬁ 
ƒ– ﬂ ¤ ƒ–  ‹ƒ ˙    ¥¡ ¤   ' ‹ƒ 
 ¥¡  ﬁ ˘    ¤   ˙ £ ˘   ‰   ¤
 ‰   ‹ƒ §   §¤    ‹' ﬁ '    Àƒ
 ,    ‹'  ' ‹ƒ §   §,     
  §      ‹ƒ    ƒ    ¤ '
'  ›   ƒ  ƒ`¿ ƒ¤  ƒ  '   ¢¤
 ,  ‹ƒ      ¢,   £ – ¤  
    ' › , '  ,  
, '     ‹  ƒ    ﬂ“  ' ‹  ¤
  , ƒ   ,  ƒ  ﬁ   ﬂ     §
 ﬂ ,   ƒ   ‹¤
   ƒ   §,    ¢ ¤        £ 
       ﬁ ¢       ﬂ¡    ﬁ 
ƒ– ﬂ ¤ ƒ–  ‹ƒ ˙    ¥¡ ¤   ' ‹ƒ 
 ¥¡  ﬁ ˘    ¤   ˙ £ ˘   ‰   ¤
 ‰   ‹ƒ §   §¤    ‹' ﬁ '    Àƒ
 ,    ‹'  ' ‹ƒ §   §,     
  §      ‹ƒ    ƒ    ¤ '
'  ›   ƒ  ƒ`¿ ƒ¤  ƒ  '   ¢¤
 ,  ‹ƒ      ¢,   £ – ¤  
    ' › , '  ,  
, '     ‹  ƒ    ﬂ“  ' ‹  ¤Further Discussion On The Information Technology Bill, 1999 Moved By Shri Pramod ... on 16 May, 2000

  ƒ¡   ƒƒ  ‚ ¤     ﬂ ﬂ    
¡ƒ  ‹ƒ  ‹  ﬂ¡¤     ,    ﬁ
ƒ“ ,  ¨   ,   ¨  ‹ƒ  ƒ    ›ƒ
ﬁ.ƒ.    §   '   ¢ ƒ  –ƒ   ¤ 
“    § £  , ¡  ' ¶ ƒ  , ﬁ 
⁄  §   ƒ·¤ ‡ §   ,  ‹ƒ  ⁄ ﬂ 
⁄,  ﬁ  ‹ƒ  , ‹  ⁄   ›  ,  ‹ƒ  
,  ƒ '    ¡¤   ƒ     ‹ ¡,  ›
ƒ'   ¤  ƒ     ﬁ ﬁ ¡    ›
ƒ'    ƒ  £  ¥ƒ ,     › ƒ
ƒ'  “  ¤    ' ƒ  ﬁ ¶ › ƒ  
  ¢ £    ƒ ‹ƒ ,   ƒ     
,   £   , ƒ'   §   ﬁ  ¡ ¤  
ﬁ    -   ƒ' ,   ƒ“ ‹,     ƒ
‹, '“ ƒ ‹, ƒ        ,    ⁄ ﬁ
     ,  ƒ     ƒ  ƒ· ¢¤  ‹ '  
¡, *  ¢  ‹,  ﬂ–     ƒ  ﬂ  ¤    
 , ‹ƒ    ¢,     '  ' ‡ ¡  §  ¶
‹       §   ¡ , ‹ƒ     ¤ ¶ 
  ‹ƒ   ,   , ‹ƒ     ‹,  ƒﬂ¤ 
‡  ¡   ¶  ‹ ,  ¶ ‹ ƒ  ,  
   ƒ ,     ƒ       ,
   - ⁄  ,  -   ‹ ƒ¡ 
 ¡ ⁄ ﬁ ,  ﬂﬂ , ·-·  “  ,
  ƒ § '  » ¡  ¤ ‹ƒ     ˆ 
 ⁄,      ¤    , 
–-  ,   ƒ  ¢ ƒ  ,  ⁄ ﬁ ‹ƒ  ﬂ 
  ¶           ››  ¤       «
  ﬂ * Expunged as ordered by the Chair.
¡, ‹ﬂ   ˆ       ﬂ¤ ‹ƒ  ' ¡  ⁄
ﬁ, ‹ƒ £    ,   ,  ˘˙  ‹ƒ  ƒ  
    ˘    §  §  ,   ' ƒ¡   §
 §       ,  ¶  § , § ¡  §
  ¤  ·   ,   § › §. ﬁ.ƒ.  » 
   ƒ¡ £  ƒ·  ,   “    '  
  § ¡  §   ¢  ¤ ¶  ƒ ‹ƒ  ﬂ 
£   ƒ    ¤
   „„    ‹ƒ  ‹  ¡¤    ‹ƒ
    ƒ “ ‚   ƒ   ,  „„  ‹ƒ 
     “  ‚ ,   ƒ¡“ '   ,    '
 “     “   ,  ' ‹ ƒ   ,   '
  ,   ¡  ¤   ‚  ƒ¡“  Further Discussion On The Information Technology Bill, 1999 Moved By Shri Pramod ... on 16 May, 2000

       “,     §  §   
,   ƒ ' ‹ƒ ¢·  ¥  ﬁ, ⁄ ﬁ¤ ¶       
ƒ· ¤
    (ﬂ ﬂ¥) : ¡ ƒ  , ‹ƒ  '  ¥¡
¢¤
   ﬂ  :     ﬁ   ﬂ¡,    
'  ,  , ¢·   ‡ ‚  ﬁ  ¤   ƒ 
 ¢        ﬂ  ?       
   ,       ¢ ⁄¡,   ƒ  ﬂ  ¤   
,        ,    ¤  ‹ ﬁ  ﬂ ƒ  £
  ¡¤   ÉÉ  ﬁ ‹ƒ    ¡, ‹ƒ  ﬂ– ƒ 
¤      ﬂ,  ‹    ƒ
ƒﬂ   ,      ˆ,  ƒ`¿,   ﬁ ⁄ ,
    ‹ƒ £ ' ⁄ ƒ   ﬂ    ﬂﬁ,  
¢ ¡¤  ¨˚   ﬁ    ‚§ ¤  ¨˚  '  ‚ , ‹
   '  § ¶   ,        ƒ' 
    ƒ ' ¡  §   ƒ  ‹ƒ ¿⁄ ¤   
 ﬂ ¡  '      ﬁ›   , 
     ¶ §  §  ,   ¡      ƒ
 §   ﬁ  ¡  ¡  ƒ,    §  ƒﬁ, 
ƒ'   § ,    ﬁ '  ﬂ  ﬁ,  ﬁ  ƒ  
¡ ¤  ‹ƒ „.”” hrs.  ‹⁄ ﬂ  «     ﬂ ¡¤ ‹ƒ
  ‚   ƒ   ¤  ﬂ ¤    £
   ⁄  ,     £  ﬁ
 ,  ⁄  ¤  ‹ƒ ›   ﬁ 
ﬂ,  ' ƒ ¤   £   ƒ  ﬁ¤   
¡    ¡ ¢ ﬁ     ' ﬂ ¤  ¡  £ ƒ' 
    ¡ ,  ﬂ   ﬁ ƒ    ,  
 ,     › ƒ   ¤ ﬁ  ﬂ
¡  ƒ   Àƒ ‚  ⁄     ﬂ ¤     
§ ƒ   ¡ ,   ¡   ⁄      ¤
  ¡   ﬁ  ¡  ﬁ   ƒ    ,   ,
   ,   ¢-¢ ﬁ-ﬁ '    ¤ Subject to these
conditions which I have referred to and the points which I have raised, I welcome this Bill. 
   ¡ £   '  ¡   ¡ ƒ  ﬁ¤
MR. SPEAKER: The words which you have used " ** ," are unparliamentary and are expunged.
   ﬂ  :   ‡  ƒ·¤  ‹ƒ ﬁƒ  ﬁ¤  ﬁ
‡ ⁄ ¤ ¢    '  ﬂ ¡      ƒ¡ ﬁ ﬁ
,   ⁄ ,    ƒ ¢   ƒ ¡ ﬁ ﬁ ¤Further Discussion On The Information Technology Bill, 1999 Moved By Shri Pramod ... on 16 May, 2000

   ¢  ƒ  ƒ  ¡ £ ‹ƒ ‡    ,
 ﬁ ‹ƒ    ¡¤
SHRI V.P. SINGH BADNORE (BHILWARA): I rise to support the Information Technology Bill,
2000. I think the importance of Information technology does not need to be reiterated. Everybody
knows the importance of Information technology, what returns it is bringing not just to India but to
the world. After the industrial revolution it is the most important thing that has happened or come
to the world and into India. India is really going to the advanced age.
. I will restrict myself to whatever ha been said and the objections that have come from the
Opposition Benches. One of the objections that has come from the Opposition Benches is about the
urgency in this matter and why we are rushing through this Bill.
I would like to say that unless we control and regulate this Information Technology the crimes are
really going to be rampant. An hon. Member was very rightly saying that they are discussing this in
Paris too. Unless we control this, most of the crimes are cropping in India not only from the cyber
cafes, but also from the universities and from the people who are free-lansing. The crimes are not
committed from the internet who are registered, who are like us. It is not coming from us. But they
are coming from the cyber cafes and the responsibility for that has to be ascertained. That is very
important.
The Internet Service Provider has also to be made responsible. Otherwise, there is no responsibility
that has been really fed into the Bill.
Sir, let me give you some examples. It has been a fact that this bouncing is being made into the bank
and you cannot really know where it comes from. Somebody in China can get into a bank’s system in
America and then give the account number because he is hacking into it and transferring that
money. By the time you get to know where it is coming from and where it is happening, thousands of
millions of dollars can be siphoned off. Now, that sort of a thing can happen and that is the cyber
crime. The hon. Members are saying that there is no urgency.
Sir, it was reported in the newspapers also that a hacker got into the system of Bhaba Atomic
Research Centre and we are saying that there is no urgency. Is it not true that data of the Agni
missile was also hacked into? Now, I do not know how much and what information has been hacked
into. Was it ISI or anybody else who have got into it? Now, they are doing it and the hon. Members
(in opposition parties) are saying that there is no urgency.
Now, there is always a chance that even if you have left out something and even if there is a lacuna,
then we can really get amendments in another six or eight months’ time. So, hon. Members, I would
like to say that there is an urgency. This is what I want to stress upon.
It is a fact that Shri Samir Bhatia, who is known all over the world, made billions of rupees. There
are a lot of people who are getting into this. But what we are to be really worried about is the
nefarious and the spurious people who are getting into this technology industry. So, we have comeFurther Discussion On The Information Technology Bill, 1999 Moved By Shri Pramod ... on 16 May, 2000

out with the Information Technology Bill. I congratulate the hon. Minister who has done a good job.
Now, this Bill is not something which has come only into India, it has been studied, and it has been
there in the world. Everybody is trying to put his brain to stop these cyber crimes. So, we have come
out with the Bill. The Information Technology is moving ahead very fast that we will need to come
out with amendments also. So, there is an urgency. This is what I wanted to stress upon.
Sir, with these few words, I would like to thank you for giving me this opportunity to participate in
the discussion.
SHRI SONTOSH MOHAN DEV (SILCHAR): Mr. Speaker, Sir, at the very outset, I convey my thanks
that you called me today to participate in the discussion.
As my colleague, Shri Satyavrat Chaturuvedi has said, neither Shri Pramod Mahajan nor Shri Jaitley
should take that we are against this Bill.
Our late lamented leader, Shri Rajiv Gandhi, gave the first call to the country: "let us go to the new
millennium with technology and more and more Science and Technology".
The Government has come forward with a Bill. In that Bill, Shri Pramod Mahajan has very frankly
admitted that he had to go through it 55 times in drafting this Bill. This shows that the Government
has taken enough, and enough care to see that this Bill is drafted in a proper manner. In a
parliamentary democracy, 542 Members should be given a chance at least to discuss it and pass it.
You are in a hurry—it is not your fault-- and all of us are guilty because most of the time of the
House is spoiled. We understand that you could not bring it at the appropriate time. If you could
have brought this Bill a few days earlier things could have been much better. A message should not
go to the nation that it is a disputed Bill. It is not a disputed Bill. But certain Clauses have been put
in this Bill. You yourself have not accepted Clause 73a and 73b. We appreciate that.
Some of these points and other things are too much on the higher side. That is fair enough. I would
ask my good friend, Shri Jaitley, who is a very renowned lawyer – we are from the field, he is
Delhi-based and his experience is from all over the country through his clients – whether he has
read in the Papers about fifteen days back about what a security man did in Kashmir? On the plea of
searching the house, he went there and raped the lady of that House. The Government has, of
course, taken action. As per the law, he is entitled to go for search and seizure in the Disturbed Area.
In my own district, I have complained to the Home Minister and I have complained to the Prime
Minister about a Superintendent of Police who is doing things which are not befitting of a
Superintendent of Police. As one Member has rightly said, rank is not the qualification. He might
have been promoted from a constable to DSP, but is he in a position to interpret the rules and do
judicious things to a person on the plea that he has done something wrong? No. Some sort of control
should have been there which is not there. Now they want to get this Bill passed, but my request to
the hon. Minister is that he should keep an eye. If these things are misused, we must take prompt
action. Shri Jaitley has again said that a decision by consent is never contested. No. Here is a victim.
I am Managing Director of a private limited company. By being a Member of Parliament, I amFurther Discussion On The Information Technology Bill, 1999 Moved By Shri Pramod ... on 16 May, 2000

outside my business. My brother ousted me from my business and from all my property. Mr.
Speaker had pity on me yesterday. He said: "You are probably annoyed; do not get annoyed". I have
been trying to tell to the Parliament and to the advocate who pleaded the case very very nicely. I told
him that if he had spoken earlier, the things would have been different. But remember that in the
case which I won after one-and-a-half years, one High Court judge gave an Injunction Notice, which
is not justifiable in High Court. The Minister will agree with me though I am not an advocate. Then I
had to go personally out of the way, met the Chief Justice and got justice. The matter was finished
within six hours. If you call the judge and ask what made him to do that, he will say he has a case.
He was going to Manipur, Tripura, here and there, so he had no time. These things are happening
here.
Another thing the Minister has said is that if there is a criminal case, the criminal court will not
judge it. It will go to the High Court or to the upper court. This is not the fact. Today, a Munsif can
stop a Supreme Court order in the country saying that it needs clarification. Again, I am a victim. I
have lost property worth Rs.3 crore. So, what I am telling you is that your perception of law is based
on your theory and practical things in Delhi, but we come from remote areas. In our remote areas,
you must have seen one girl who came from Manipur. She represented Manipur in the last Lok
Sabha and supported your Government. One of her sisters went to get water from the river where
the army men misbehaved with her, and one day she was speaking in this House and crying. She has
not come back here. She was defeated not by the public but by whom, I do not want to go into that.
What I am trying to say is that this Bill is welcome and we want it to be passed. Some old man was in
a hurry and the Government fell. Now this young man is in a hurry. Please do not make a mistake.
Of late, he is losing temper. He must keep his cool. He has seen how our Speaker is managing quite
nicely. He should follow the Speaker. Why does he sometimes lose his temper? There is nothing to
lose temper. Today he has asked one Minister not to answer and within fifteen minutes he gave a
solace to the Minister and said, "Now you can answer". This is how in a democracy we have to
survive.
There should be a give and take. There may be love and hate for some time. You were mentioning
about the love bug. It did not come to my computer. I wanted to see what this love bug is. I do not
know it. I have no idea. I did not like it. My computer is being used by my daughter. This is a Bill in
which you have brought many things.
MR. SPEAKER : I think the hon. Minister Shri Pramod Mahajan is going to reply explaining this
also.
… (Interruptions)
SHRI SONTOSH MOHAN DEV : Thank you Sir. I will not take much time of this House. I will take
just another minute.
What I am saying is that we are totally with you. We want that this Bill should be passed. These are
the things which we have said before you. You keep them in your record. In times of experience, if
you feel that it needs to be changed, kindly come to this House. We will again be there. We want thatFurther Discussion On The Information Technology Bill, 1999 Moved By Shri Pramod ... on 16 May, 2000

it should not be a liability. It should be an asset to you. It has been very rightly pointed out by some
friend.
When I came back from the procession I saw this paper in my table. It must have been from a BJP
supporter. I enquired as to who gave it and I was told that one lady gave it. I was told that it was
understood that I would be speaking and I should go through it. I have gone through it.
SHRIMATI MARGARET ALVA (CANARA): Why only ladies?
SHRI SONTOSH MOHAN DEV: You also gave it. I do not know why a lady gave it to me. …
(Interruptions) I want to read it for the benefit of the House. Hon. Minister Shri Jaitley was saying
yesterday that if we are late by one day, we might miss something. Sometimes you are right. I am
reading this news item :
"A Group of Eight (G8) Conference on cybercrime opened here on Monday (that is in
Paris) to warnings from French leaders that the phenomenon could not be fought by
the Internet industry alone, but needed the help of Governments and police forces.
Touching a sensitive nerve, French Prime Minister Lionel Jospin and Interior
Minister Jean Pierre Chevenement declared that vandalism and crime on the
Internet could not be tackled only by self-regulation, as many people in the industry
contended.
‘New forms of crime are developing, sometimes helped by the technical
characteristics and worldwide dimensions of the net’ Jospin said in a message to the
Conference. ‘They call for a mobilisation and collective response on a global scale.
This is first and foremost responsibility for public authorities in each country.’ "
You are going into that global scale.
Lastly, I want to say that my late lamented leader Shri Rajiv Gandhi, who brought me to this
position, will bless you from heaven today for passing this Bill. This was his dream.
Thank you very much.
 
 ﬂ¢  (–) :  , ‹ƒ ‡    ,  ﬁ
‹ƒ  ¤   ¡ﬂ ƒ¥     ,     ‹ƒ
     ƒ – ‡   ﬂ ¡¤      
  ¡ﬂ ƒ¥   ﬁ    ' ,     
 ﬂ–    ,     ¡¤
, ' '    ƒ   ‹ ƒ¡    – 
 ¤Further Discussion On The Information Technology Bill, 1999 Moved By Shri Pramod ... on 16 May, 2000

         ,    ' ‚   ⁄  ƒ`¿  '
  ¢  ,   '   £   ƒ`¿  ﬁ § ƒ ¤  
ƒﬂ-ƒﬂ, –:-–:   § ¡ ﬁ    ¤    ¡ 
   ƒ   ˆ    ƒ¡     ƒ
ﬁ¤      ƒ¡   ,     
ƒ       ﬂ– ¤          
§  · ƒ  ¤  ‡            ﬁ 
 ﬁ,  ƒ  ﬂﬂ  ﬁ¤     § ¶ ﬂ  ⁄§    
 ‹   § '    ¤     ¡    § 
ƒ   § ƒ      ›ƒ, ﬁ.ƒ.    
ƒ  £          ¤      
' ¡ ,  ¡     »   ¤   ﬂ ƒ   
ﬂ ¤       ' §      ¤
 ‡        ¤ '    ' ƒ     
 ‹  ,   ƒ ƒ¡     ' ⁄  ,    ﬂﬂ 
‹  § ›  ¤  ⁄  ›`¿ ¥ ·  Àƒ  ‹  ﬂ
¤         ﬁ¤   ƒ ƒ ﬂ ¤ ƒ £  ƒ
   –   ƒ '   ﬂ   ﬁ  £   '   
–    £  ƒ ﬂﬂ       , ¶   ﬂ ¤
 ¤
 ˆ“ ﬂ¥(») :   , ‹ƒ ‡ ¡ﬂ ƒ¥ 
ƒ    ,  ﬁ  ‹ƒ    ¡¤ ‹   - ƒ 
‹  ,           ¤    ‚
 ¡   ‹ ¤  ‚    ‹     ,  £
-     ,        £    
 £       ƒ  ⁄· ¤       ¡`¿
,  ¤    ƒ     ⁄ ¡ƒ    ƒ ﬂﬂ 
 ¤ – ﬂ   “   ⁄    , › , ⁄ £
 ¢ ¡         ƒ  ,  -ƒﬂ
 °  ƒ¡  ¤     ‹  '  ¤
ƒ¥`¿- £ £ƒﬂ    ¡ '  ƒ ¶  ¥¡   '
ﬁ,,,›    ¤ ﬁ ¶  › '  ‡   ¤ 
‡ ¡           - ƒ ‚    ‡¥ 
 ,  ƒ     ¢  £ ¡ 
‹ ƒ      ¤ ›    ‡      
£      ,  '    ¤ ﬁ   
      ﬂ  ﬁ   ,    ﬂ  £  ' 
    ¡`¿  , ¢   ﬁ  ¤   ›
ﬁ › ﬁ, ›    ﬁ £   ﬁ › ﬁ ¤
   ﬂ ﬁ  ﬁ ﬁ ,  ‡ ¡   '    ƒ 
  ﬂ  ,  ' ƒ'    ƒ¡     ƒ Further Discussion On The Information Technology Bill, 1999 Moved By Shri Pramod ... on 16 May, 2000

, ﬂ ﬂ ,  ﬂ , ‹  £  ¤    
ƒ  ' ⁄    “ ƒﬂ         ¢, 
        ‹    ' –     ¤   
  ƒ            
  ¤  †   “    †  
£ ›     ƒ   ¤  ƒ  '
ƒﬂ  ﬁ    ‹    ¤      ¤
   £   ƒ  ƒ  £ †  , ›   
   , '  , ƒ   ﬁ¤     § ' 
¤ ﬁ  ƒ ﬂ-‡     ,     £ ƒ 
 ﬂﬁ¤    ¢ ‹ƒ    ¡¤
SHRI V. VETRISELVAN (KRISHNAGIRI): Hon. Speaker, Sir, on behalf of DMK Party, I support the
Information Technology Bill.
Sir, there are a number of instances of hacking into the websites, sending hate mail, etc. This is a
disturbing factor and is a cause for much worry and anxiety. This Bill will enable the
law-enforcement authorities to punish hackers and hate mail senders. With the implementation of
Sankhya Vahini project, we are expected to have a high-speed data network. So, it is fit and proper
that we pass this Bill at the earliest.
Sir, I understand that there are only a handful of countries which have enacted cyber laws. The U.N
was the first to adopt a model law on electronic commerce. With the passage of this I.T. Bill, we
would join this elite club of countries which have passed cyber laws.
At present, in the e-Commerce, there is no provision to give legal recognition for electronic
transactions and other matters relating to that. This Bill proposes to give legal sanctity to digital
signatures, a major requirement for e-Commerce, by recognising certifying authorities to
authenticate e-Signatures and other electronic transactions.
While encouraging e-Commerce, this Bill, as I stated earlier, provides for punishment to those
people who spread computer virus. Sir, the e-Mail "I Love You" has caused huge losses, which were
running into thousands of crores, to the IT world. At present, there is no law in Philippines to tackle
this kind of wrong-doing. Clause 65A of the proposed Bill will take care of all these kinds of
misdeeds. This Bill, if enacted, will become a deterrent against those people.
MR. SPEAKER: Shri Vetriselvan, is it your maiden speech?
SHRI V. VETRISELVAN (KRISHNAGIRI): Yes, Sir.
Rightly, this Bill prescribes a sentence of three years and a penalty up to two lakh rupees for people
tampering with somebody else""s computer source code; and for transmitting obscene information,
the punishment proposed is five years imprisonment and a fine of one lakh rupees. This is a
welcome feature of this Bill.Further Discussion On The Information Technology Bill, 1999 Moved By Shri Pramod ... on 16 May, 2000

The Bill prescribes setting up a Cyber Regulation Appellate Tribunal to try computer-related crimes
and violation of the I.T. Act.
Sir, the accused need not go to the Civil Courts for claiming compensation. That is also a good
feature of the Bill.
Sir, I am a Member of the Standing Committee on Science and Technology. I am happy to find that
most of the amendments suggested by the Committee have been accepted by the Government. I am
also happy to hear that the Government has decided to drop the controversial clause 79 of the
Information Technology Bill.
Sir, I would like to draw the attention of the Government and state that the Bill has come at a time
when India is marching ahead to become the super power in the area of Information Technology.
The present software exports from the country are around four billion dollars and we wish to
achieve exports of 50 billion dollars by the year 2008. Such a legislation would go a long way and
help in achieving our objectives and targets.
MR. SPEAKER: Shri Selvan, you should leave something for the hon. Minister to reply also.
SHRI V. VETRISELVAN: Sir, before I conclude I would like to submit that one of the welcome
features of the Bill is that it provides for electronic governance. The scheme of the Bill is divided into
various chapters. Electronic governance is necessary before electronic commerce can flourish. This
chapter enables the Government departments to accept applications and records in the electronic
form. This would go a long way in ushering in a paperless society.
Sir, with these words, I support this Bill.
 
MR. SPEAKER: Shri P.C.Thomas. He is the last speaker.
SHRI P.C. THOMAS (MUVATTUPUZHA): Sir, I always have the opportunity to be the last speaker
in any discussion! SHRI E.M. SUDARSANA NATCHIAPPAN (SIVAGANGA): Sir, I am also a
Member of the Standing Committee on Science and Technology. I may also be given an opportunity
to speak.
MR. SPEAKER: Most of the recommendations of the Committee have been accepted by the
Government.
SHRI P.C. THOMAS : Sir, I hope, I am not the last speaker.
MR. SPEAKER: Shri Thomas, you are the last speaker.Further Discussion On The Information Technology Bill, 1999 Moved By Shri Pramod ... on 16 May, 2000

SHRI P.C. THOMAS (MUVATTUPUZHA): Sir, I would like to mention just one or two points. First
of all I would like to congratulate the Government for bringing this Bill. In fact, we are sure that
after the passage of this Bill, both the Electronic and the computer media would be much more
acceptable to the business world as well as to the Government of this country. The Bill, though
drafted with care has not been able to take into account all the aspects which the people normally
come across while using the computers for purposes of e-Commerce and e-Governance.
Sir, now in regard to Chapter II where the concept of `digital signature’ has been defined as also the
effect of `digital signature’ has been given, I feel, the scope of this definition has to be extended
further. That is because digital signature is an encrypted form of a mathematical compressed
message. This mathematically compressed message that is encrypted is being operated by a public
as well as a private key by the originator. If the public key is made available and is used, then we get
the identity of the author, the originator; that is the authenticity of the material contained. But I feel,
though the authenticity of the originator, the identity of the originator is clear, yet when the message
is de-encrypted, though it is available mathematically, it has to be made available in a common
language. To that extent it is not given in chapter II where this aspect has been attempted. A fairly
better definition, a better explanation may be necessary for chapter II where this concept of digital
signature is being dealt with.
With regard to the identity of originator, the definition as well as the explanation is good enough.
Integrity of the message also has to be so confirmed. Therefore, the hash result, which produces the
original message when the hash function is executed, is to be explained more in Chapter II.
With regard to encryption, it is felt that the Bill is silent about the requirement of guarantee on
personal financial transactions like credit card transactions. The credit card number should not at
all be open to hacking. It should not be available for any type of hacking. More detailed guidelines
are necessary in this regard. I am not sure whether the rules would provide further explanation in
this regard, and will be wider in scope.
Another point on which the Government has not given clear guidelines is the way in which
permission can be obtained for stronger encryption. On normal 40 bit encryption there is no
necessity for further guidelines. But, for harsher and heavier things, more guidelines may be
necessary in the Act.
This Bill had been discussed in the Standing committee. A lot of suggestions had come from the
Committee and they had been considered. Of course, one or two of those suggestions had not been
accepted. If the Bill is circulated for further scrutiny even at this stage, it can be made more effective
and we would be able to do more justice to this very innovative effort that has been taken by the
Parliament.
   ¢ ¡ﬂ ƒ¥  ( ƒ ) : 
,  ƒ        ¡   ‰     ƒ
      £  ¢ ¤  ﬂ   ‡ ƒ ¢· ‹ƒ   
  ¤   ‹ƒ   '  ,     '   ‹ƒFurther Discussion On The Information Technology Bill, 1999 Moved By Shri Pramod ... on 16 May, 2000

ˆƒ   ƒ  ﬁ    ƒ    £ ƒ    ﬁ ¢· 
  -ƒ    '  ¤ ﬁ  ¢·   § 
    ƒƒ  ⁄ ﬁ,   ƒ¢ ¤ '-'   
  ƒ      ⁄  · ‚  ¤     ƒ
         ‹ƒ   ,  ‹ƒ   ¢¤  ¢·   
ƒ         ‹ƒ   '  ¢¤ ﬁ  ¢ 
 ¢, '  ﬂ  ¢  ‹        ‹ 
 £    ¢  ‡       , -ƒ 
 , ﬂﬂ ‡  ƒ  ¢¤ -  ‡   ' ﬂﬂ    
 ‡   ‹,  “    ‡¤  ‹   
        ƒ ƒ  ƒ   , 
 ƒ     ‹         £    »
‚    ƒ      ‹ƒ    '-'  ‹§ ,  
   ,    § £¿     ¤   ‹ 
    ,     ¡¤
ﬁ     “         ﬂ ¡¤ ‡
§  ƒ   ƒ ¡ ¢ƒ  ¢ £    ‚    ¶ ¡  
   ‰    ¡  £ ƒ¡     ﬁ   ‡·-‡·  
¡    £            ‡   ﬂ–  ¢
ﬁ ‹ ﬁ ﬂ–   '     ¡    ƒ   ¤ 
 ¡  ‹⁄   ¤   ⁄§    £ ‹  
 ,  §   ¤ ﬁ    ﬁ    ¡¤
Sir, my real problem is that I am neither a technocrat nor a lawyer. Half of the legislation talks about
the technology and the other half talks about the law. I am expert of neither this nor that. ﬁ 
      ﬂﬂ  ƒ'  £      ‹ﬁ ,   
  ﬂﬂ     Àﬂ ⁄¤ ' '  ‡     
     ƒ  '    ¢¤ ﬁ ‡  ƒ   ﬂ
   ¡       ¡, ﬁ ¶   “   
,   ﬂ          ¢  £  
 ﬁ            “    ƒ¢    
‹ﬁ £                  ¡
£   ⁄ ﬁ¤ “       ƒ  ,  
ƒ  ¡¤     He was probably the last speaker yesterday, and the
way in which he argued, I think, today’s changed atmosphere of my judges or juries shows that he
was quite successful in convincing all of us   § '    ¤ –-
  ,    ¤    - – ﬂ   ƒ 
 ﬂ¡¤
ﬁ  ﬂ-ƒ   ·     ‹    ¨˙ £ ¨˙  †  
     ƒ          ƒ
  ﬂ ⁄  ¡   ¤           ¢  ¤
 ‹ƒ ¡   ƒ`¿  Clause 73(a) and 73(b) which were much talked and criticised in theFurther Discussion On The Information Technology Bill, 1999 Moved By Shri Pramod ... on 16 May, 2000

media were never part of this original Bill. Now, it was a suggestion by the Standing Committee and
all of us are human beings in the Parliament, and same is the case with the Standing Committee.
They made 36 suggestions, out of which we accepted 34. That means, their score of accepting was to
the tune of over 90 per cent. So, they did an excellent job.
SHRI RUPCHAND PAL (HOOGLY): But it may not be so in respect of other Standing Committees.
SHRI PRAMOD MAHAJAN: Let us see. I do not want to comment on that. I can only say that as far
as the legislation is concerned, I am giving the second Bill which was passed by the Lok Sabha. In
the Semi Conductor Lay Out Design Bill, I have accepted all the suggestions made by the Standing
Committee in toto. So, it is not true that we do not accept the recommendations made by the
Standing Committees. And, I am sure, in the future also, barring one or two cases where the
Government may have different view points, most of the suggestions made by the Standing
Committees on legislation should be treated with respect, and wherever the Government agrees, it
should be accepted. You cannot expect that it should be accepted cent per cent. Then, the laws will
be decided in the Standing Committees and not in Parliament. So, there can be a little difference of
opinion.
I was saying that it was not the part of my Bill for which I am criticised.
The Standing Committee brought it. They have the right to bring it. They have studied and they
thought it was a right thing. So, they brought it. Now what happened to this? On Tuesday, we had
the Cabinet meeting which did not accept Clauses 73 (a) and 73 (b). I read in the newspapers today
that the Government changed their mind because they read a criticism on Sunday morning in the
newspapers. I really do not understand that. It is because on Friday when we went to hon. President
to get his sanction to amendments, Clauses 73 (a) and 73 (b) were not at all there. So, the
atmosphere became a commotion for no reason because the Press thought that we were accepting it.
So, many of my friends sitting here thought that we were accepting something which is draconian in
nature which we never accepted in the Cabinet. It was never circulated to the Parliament. We are not
withdrawing the amendments because we never circulated to you. And we never accepted them. So,
this is the first point which I would like to make it very clear.
Now about Clause 79, ,   ƒ  ƒ   ﬁ ⁄·  ‹ ¡¤ ƒ 
''    ﬂ ƒ ‚   ,    ¤   ˚„-˚¨ 
  ¤  ƒ   ¢ £  ‚  ¢¤   '   
¡   ' ƒ    ,   ƒ     £
⁄ ¥     ƒ ƒ ,    '  ﬂ– 
‡¤ ﬁ      ¡  ƒ  ﬂ– ,   –  , 
   ' ‹    ﬂ ¡  ›       
,    ‹ƒ  ƒ`¿   ‹ƒ ƒ    ,  
  ƒ¡ ƒ ƒ`¿ ¤
The entire police force has to be made computer savvy.. They were not only talking about DSPs, but
even down the line. When I say the electronic complaint will be allowed in a police station, unlessFurther Discussion On The Information Technology Bill, 1999 Moved By Shri Pramod ... on 16 May, 2000

the constable is able to retrieve what has been the complaint, you cannot send from this end and
nobody is getting from that end.   ƒ   ⁄¡    ƒ  £
  ƒ`¿ ,      ƒ`¿   ƒﬁ,    ¤ 
ƒ¡  ¯   ¤
To treat cyber as crimes, the Committee has suggested that there should be a Special Task Force
within police who should know what kind of crime it is. ' ƒ    ƒ¡ 
– ƒ ﬂ,    †ƒ    £ †ƒ  –      ¢
   ¤    §    ,   –    
  , ¡  ‚  ' ﬂ     ,  ¡  ¥ ƒ  
ﬁ   ¶    £    ƒ    ‹ ,      
ƒ  ,  †ƒ    – ,       ,  
 ƒ   ƒ¤ ﬁ   ⁄   ƒ › ¤  ¢-¢
 ﬁ ƒ £ ' ¤ Crime is a crime. Now to deal with crime, if all of us think that in
dealing with crime, we should not give the right to police officer to raid without a search warrant,
then why do you bring it to my poor Technology Bill which has come for the first time? This right
has been given to the police in half a dozen laws.
SHRI VARKALA RADHAKRISHNAN (CHIRAYINKIL): You please refer to Clause 79 sub-clause (2)
where you have stated that if a person is arrested by any officer, he must be produced before an
officer in charge of a police station. That must be Head Constable. So, the person is produced before
Head Constable. It is put in Clause 79 sub-clause (2).
,     ¢    ƒ   '  ⁄ ﬁ ƒ  
   ﬁ,  ,     ,      ,      
  .‹.ƒ..    ¥¥  -   '  ƒ 
,  ƒ    ¤
The Standing Committee brought it. They have the right to bring it. They have studied and they
thought it was a right thing. So, they brought it. Now what happened to this? On Tuesday, we had
the Cabinet meeting which did not accept Clauses 73 (a) and 73 (b). I read in the newspapers today
that the Government changed their mind because they read a criticism on Sunday morning in the
newspapers. I really do not understand that. It is because on Friday when we went to hon. President
to get his sanction to amendments, Clauses 73 (a) and 73 (b) were not at all there. So, the
atmosphere became a commotion for no reason because the Press thought that we were accepting it.
So, many of my friends sitting here thought that we were accepting something which is draconian in
nature which we never accepted in the Cabinet. It was never circulated to the Parliament. We are not
withdrawing the amendments because we never circulated to you. And we never accepted them. So,
this is the first point which I would like to make it very clear.
Now about Clause 79, ,   ƒ  ƒ   ﬁ ⁄·  ‹ ¡¤ ƒ 
''    ﬂ ƒ ‚   ,    ¤   ˚„-˚¨ 
  ¤  ƒ   ¢ £  ‚  ¢¤   '   
¡   ' ƒ    ,   ƒ     £Further Discussion On The Information Technology Bill, 1999 Moved By Shri Pramod ... on 16 May, 2000

⁄ ¥     ƒ ƒ ,    '  ﬂ– 
‡¤ ﬁ      ¡  ƒ  ﬂ– ,   –  , 
   ' ‹    ﬂ ¡  ›       
,    ‹ƒ  ƒ`¿   ‹ƒ ƒ    ,  
  ƒ¡ ƒ ƒ`¿ ¤
The entire police force has to be made computer savvy.. They were not only talking about DSPs, but
even down the line. When I say the electronic complaint will be allowed in a police station, unless
the constable is able to retrieve what has been the complaint, you cannot send from this end and
nobody is getting from that end.   ƒ   ⁄¡    ƒ  £
  ƒ`¿ ,      ƒ`¿   ƒﬁ,    ¤ 
ƒ¡  ¯   ¤
To treat cyber as crimes, the Committee has suggested that there should be a Special Task Force
within police who should know what kind of crime it is. ' ƒ    ƒ¡ 
– ƒ ﬂ,    †ƒ    £ †ƒ  –      ¢
   ¤    §    ,   –    
  , ¡  ‚  ' ﬂ     ,  ¡  ¥ ƒ  
ﬁ   ¶    £    ƒ    ‹ ,      
ƒ  ,  †ƒ    – ,       ,  
 ƒ   ƒ¤ ﬁ   ⁄   ƒ › ¤  ¢-¢
 ﬁ ƒ £ ' ¤ Crime is a crime. Now to deal with crime, if all of us think that in
dealing with crime, we should not give the right to police officer to raid without a search warrant,
then why do you bring my poor Technology Bill which has come for the first time? This right has
been given to the police in half a dozen laws.
SHRI VARKALA RADHAKRISHNAN (CHIRAYINKIL): You please refer to Clause 79 sub-clause (2)
where you have stated that if a person is arrested by any officer, he must be produced before an
officer in charge of a police station. That must be Head Constable. So, the person is produced before
Head Constable. It is put in Clause 79 sub-clause (2).
,     ¢    ƒ   '  ⁄ ﬁ ƒ  
   ﬁ,  ,     ,      ,      
  .‹.ƒ..    ¥¥  -   '  ƒ 
,  ƒ    ¤
   ‡  ¡    ‚ ¤          ‚  ¤
   ﬂ  ( ⁄) :  ƒ ' ,  '   ¡ £  
  ¡    ,   ﬂ  ¤    §›   
‹ ‹ , ¶ ¢  ƒ          ﬂ 
     ‹     ¶   ﬂﬁ¤  ƒ  
ﬂﬁ¤Further Discussion On The Information Technology Bill, 1999 Moved By Shri Pramod ... on 16 May, 2000

 ƒ  : ‹ƒ  ƒ  ¡¤  §      ¶
'     ƒ    ﬂﬁ¤  ƒ  ƒ   ﬂ  
  ƒ  '   ﬂ¤ ‹ '  ƒ ›  ﬂ  
   »  ›    ƒ  ¤ '-'  ›    
 ﬂ     '  They are not using the law.   ›.ﬁ.ƒ.  '
›  »   ¤    ‚ ”” ›  »  
¤     ¤          ﬂﬁ     
      ﬁ  ·ﬂ  ¤ ﬁ   ﬂ  
ƒ    ¤  ﬂ   ƒ·      
    £  ƒ¡  § ƒ   § '  
  ·   › ¤ ¶   ¤   ¡   
ƒ      ¤
There is the Cr.P.C. for the poor citizens but the cyber-savvy people do not have a law.   §
   ¤     , ƒ  ,    ¶ ƒ  
    §  ,  ›   ¤  §  ﬂ–   
,   ﬂ    ¤ ƒ¡ › ﬂ  ¤
 ƒﬂ ƒ () : ¡   › ¤
THE MINISTER OF PARLIAMENTARY AFFAIRS AND MINISTER OF INFORMATION
TECHNOLOGY (SHRI PRAMOD MAHAJAN): I agree. I could have then said, `Why does the
Government of West Bengal not amend the Cr.P.C. and withdraw this right?’  ¡ƒﬂ ƒ
() : ›,     ﬂﬂ   §    ¡ ‹¤ '
         Àƒ  ¡ ‹  ƒ  :    
¤ ›  £  ¡ ‹,          ƒ
‹   ˘  ‹ƒ ¢   ¢ ﬁ ¡   '  ‹ƒ ,  
‡ ' ¤
 ƒ ƒ(  ƒﬂ) :     ¢,  ‹ƒ  ¤
.ƒ.ﬁ.›   '   ¤ …(   )    ﬂﬁ¤
 ¡ƒﬂ ƒ :   `¿     ¡¤ …(   )
 ƒ ƒ : 42     ¢    …(   )
 ¡ƒﬂ ƒ :  – '   ¤ …(   )
 ƒ ƒ : 194 ‰          ¢¤ …(
  )  ‹ ﬂﬂ  ,    ¤ …(   )  ƒ 
⁄  ¤ …(   )
SHRI PRAMOD MAHAJAN: I am now coming to my final point on Clause 79.Further Discussion On The Information Technology Bill, 1999 Moved By Shri Pramod ... on 16 May, 2000

It is a very simple Clause. If I make a mistake, Shri Arun Jaitley is here on this side and Shri Shivraj
Patil is there on that side to correct me. I have said here, `notwithstanding anything contained in
the Criminal Code of Procedure, a DSP-level officer would go.’ Suppose the House in its wisdom said
that we want to delete Clause 79, it would create more problems than solving them because then the
Cr.P.C. would become applicable to cyber crimes and today if I want to send a DSP tomorrow, a
constable would be going. So, it is not in our wisdom to withdraw Clause 79 and take it down to the
level of a constable. That is why I said, `notwithstanding anything contained in Cr.P.C. ‡ 
    '   ›  ﬂ      ¤
SHRI RUPCHAND PAL : Yesterday, when I was speaking, the hon. Minister intervened and gave a
wrong impression about Section 165. Section 165 relates to search warrant and not arrest. Now, he is
trying to equate Clause 79 with Section 165.
THE MINISTER OF STATE OF THE MINISTRY OF INFORMATION AND BROADCASTING AND
MINISTER OF STATE OF THE DEPARTMENT OF DISINVESTMENT (SHRI ARUN JAITLEY): Let
me clarify it, Sir, since this point has been made. He may kindly read Section 41 also. If he reads the
two together, it would mean, arrest and search warrant.
SHRI RUPCHAND PAL : Then again, there is Section 41; there is Section 55(2); and there is Section
165.
SHRI ARUN JAITLEY: Section 41 deals with arrest; Section 165 deals with search warrant. Now,
this provision deals with both.
SHRI RUPCHAND PAL : But when he intervened, he equated Section 165 with Clause 79. He was
misleading the House. It has nothing to do with arrest.
MR. SPEAKER: Let the Minister complete, please.
 ƒ  :  ¡   ˆ  ﬁ –   ¤   
   ƒƒ¡“ ¡ ¤      ¶ § ›  
 ƒƒ¡“ ¡  ¡ƒ ¤  ›  '  '    ‹ 
 ¤      ¡     « ,   «  §
  ƒ¡ ƒ ‹    '  ,  ƒƒ¡“ ¡ ¤  ‹  '
  ⁄§  £  ﬂ   ƒ    ¤  ‡ '
 §   ¤ ¡ƒ ﬂ ƒ   ﬁ ⁄    £ ‚  ¤ 
      ' ‹ ¢¤   ¨˘    ¤
    ƒ   ﬁ ¤
It says:
"Network service provider shall be liable for any offence committed under Section 51
of the Copyright Act, 1957. "Further Discussion On The Information Technology Bill, 1999 Moved By Shri Pramod ... on 16 May, 2000

ƒ     ﬂ ¡        ¨˘ ,    ƒ  '
 ‹,   ¨˘  ,  ¨˘ ,  ƒ  · §
 ,        §   ƒ ƒ¡ 
¡ƒ   ,   ƒ    ƒ ›     
   ƒ      ƒ ›    ﬂﬁ¤
    ﬁ –  “  ﬂ¡¤    .  
  ¤ ﬁ ‹  ‚ ¡     ¢ ﬂ  ƒ
 ,     .  ƒ  ¤ MTNL is a service provider; you
cannot hit the service provider. We cannot ask the service provider how it could provide such a
service where people talk to each other and commit a crime. It cannot be done.
If I have this kind of a law, then nobody will come forward to become an Internet service provider. If
we do not have Internet service provider, we do not have Internet. … (Interruptions) Please have
patience for a minute. I am coming to it.
Now, the Music Association people ask what will happen if somebody is using its music cassette. It is
an infringement of copyright. Copyright Act is there to take care of it. The Internet service provider
should not be punished for that, under this Bill. The Copyright Act exists; we have not repealed the
Copyright Act.
If somebody is misusing the computer and using somebody else’s copyright, then there is a remedy
in the law. … (Interruptions)
SHRI RUPCHAND PAL (HOOGLY): It is not the situation. … (Interruptions)
MR. SPEAKER: Please allow him to complete his reply.
SHRI RUPCHAND PAL (HOOGLY): Sir, I am not opposing it. There is a memorandum from All
India Music Association. … (Interruptions)
SHRI PRAMOD MAHAJAN: I have not completed this point. Please wait for a couple of minutes.
The first thing is that if I include this suggestion in this Bill, I will make this law more draconian. If
somebody is committing a crime under Copyright Act, using somebody else’s CD cassette and if I
punish the Internet service provider for that, I will be making it more draconian.
16.00 hrs. At the same time, I have taken note of your criticism. I would like to say that the Bill
which we have brought before the House basically deals with Indian Evidence Act, Bankers
Evidence Act, RBI Act and IPC. We have kept out the general clauses because it was never amended.
We have not touched the Cr.PC because we are making similar provisions here. We are going to the
core of the law making as far as the fourth generation communication is concerned. But this is not
an end. As a follow up, we have to bring Copyright Act in the digital crime, and we have to amend
the Customs Act, Excise Act, Sales Tax Act etc. In the name of making a comprehensive Bill I cannotFurther Discussion On The Information Technology Bill, 1999 Moved By Shri Pramod ... on 16 May, 2000

bring a Bill which will cover all the aspects of the fourth generation. So, your criticism is well taken.
The remedy which the hon. Member has suggested has been rejected by the Standing Committee
also. The representation of the music companies was sent to the Standing Committee also and they
have rejected it.
   - –  ƒ   ﬂ ¡¤ ‡    ¢· ⁄
, I am sorry to say that in our enthusiasm to deal with crime, we have forgotten the basic features
of this Bill. Nobody discussed e-Governance, and nobody discussed e-Commerce.
     ¡¤       ¡   ' 
   ﬂ ,  ﬂ § ' ,  ﬂ    §  £
-  ¤...(   )
MR. SPEAKER: Shri Varkala Radhakrishnan, let the Minister complete his reply, after that you can
ask for your clarifications.
SHRI PRAMOD MAHAJAN: I would like to make only two small comments. Though the point
`clicks vs. bricks’ raised by Shri Rupchand Pal does not come within the purview of this Bill, I would
like to say that entering into knowledge-based economy does not mean the death of the older
economy. If we want to do e-Commerce, we have to have power, good roads, airports, telecom,
engineering etc., etc. IT needs a large support base. But this is not the issue to be dealt with at this
juncture. Some hon. Member said that in the world average, our internet connection accounts for
only 0.1 per cent. In telephone it is only 2.6 per cent. As far as television goes, it is 30 per cent. But
in two or three years from now, when television, telephone and computer will be connected to one
wire, the penetration rate would be 35 per cent. This percentage may be much less than that of
Sweden and the U.S. But 35 per cent out of one billion accounts for 35 crores which is more than the
entire population of the U.S.   ‹‚  (ƒ`ƒ) : ¡ƒƒ ƒ  
 '  ﬂ  ﬂﬁ¤...(    )  «    '  ﬂ  ﬂﬁ¤
 ƒ  :  ƒ  ﬂ  ﬂﬁ¤...(   )
I would like to refer to the point which Shri Ramdas Athawale has made. We may have taken the
point that he has made very jokingly. Digital device in this country is the biggest and the largest one.
Today, though we say that in the field of IT we are likely to rule the world, but IT is limited to a few
cities or a few States. Our mission is to take IT to the masses. We have to take IT from South to
North and from West to East. We have to take IT from English language to the Indian languages. We
have to take IT in the fields of health, education and governance. If we do that, I am sure from 10
years now we will not only rule the world in IT – for me whether we rule the world in IT or not is not
my primary objective, it is a secondary thing – but we will be able to serve one billion poulation of
this country in a much much better way. This is a very small step in that direction. With these words
I request the House to pass this Bill unanimously.
MR. SPEAKER: Shri Radhkrishnan, are you moving your amendment No.36?Further Discussion On The Information Technology Bill, 1999 Moved By Shri Pramod ... on 16 May, 2000

SHRI VARKALA RADHAKRISHNAN (CHIRAYINKIL): I beg to move:
"That the Bill be circulated for the purpose of eliciting opinion thereon by the 18th
August, 2000. "
MR. SPEAKER: I shall now put amendment No.36 moved by Shri Varkala Radhakrishnan to the
motion for consideration, to the vote of the House The amendment was put and negatived.
MR. SPEAKER: The question is:
"That the Bill to provide legal recognition for transaction carried out by means of
electronic data interchange and other means of electronic communication, commonly
referred to as "electronic commerce", which involve the use of alternatives to
paper-based methods of communication and storage of information, to facilitate
electronic filing of documents with the Government agencies and further to amend
the Indian Penal code, the Indian Evidence Act, 1872, the Banker’s Book Evidence
Act, 1891 and the Reserve Bank of India Act, 1934 and for matters connected
therewith or incidental thereto, be taken into consideration."
The motion was adopted.
MR. SPEAKER: The House shall now take up clause-by-clause consideration of the Bill.
Clause 2                                                Definitions  
MR. SPEAKER: There are Government Amendments to Clause 2. 
Amendments made: 
                page 3,- 
        line 31, for  "computer memory", substitute  "computer memory, micro film, computer generated micro fiche".      (3) 
        page 3,- 
        after line 32, insert  Further Discussion On The Information Technology Bill, 1999 Moved By Shri Pramod ... on 16 May, 2000

‘(ra) "Electronic Gazette" means Official Gazette published in the electronic form’; (4) page 3,-
line 34, for "electronic form", substitute "electronic form or micro film or computer generated micro
fiche"; (5) page 3,-
line 38, for "sound", substitute "sound voice"; (6) Page 3,-
line 39, for "databases", substitute "databases or micro film or computer generated micro fiche". (7)
page 4, line 18, for " intrusion" substitute "unauthorised access"; (8) (Shri Pramod Mahajan) MR.
SPEAKER: The question is:
"That clause 2, as amended, stand part of the Bill.
The motion was adopted.
Clause 2, as amended, was added to the Bill.
Clauses 3 to 7 were added to the Bill.
Clause 8 Publication of Rules, regulation Etc/ om E;ectrpmoc Gazette MR.
SPEAKER: There are Government Amendments to clause 8.
Amendments made:
page 6, line 21, for "Official Gazette in the electronic form", substitute "Official
Gazette or Electronic Gazette"; (9) page 6,-
for lines 22 to 24 substitute, "Provided that where any rule, regulation, order,
bye-law, notification or any other matter is published in the Official Gazette or
Electronic Gazette, the date of publication shall be deemed to be the date of the
Gazette which was first published in any form". (10) (Shri Pramod Mahajan) MR.
SPEAKER: The question is:
"That clause 8, as amended, stand part of the Bill."
The motion was adopted.
Clause 8, as amended, was added to the Bill.
Clauses 9 to 11 were added to the Bill.
Clause 12 Acknowledgement of Receipt Mr. SPEAKER: There is a Government Amendment to
clause 12.Further Discussion On The Information Technology Bill, 1999 Moved By Shri Pramod ... on 16 May, 2000

Amendment made:
Page 7, lines 1 and 2, for "addressee that the acknowledgement" substitute "addressee
that the acknowledgement of receipt of electronic record". (11) (Shri Pramod
Mahajan)   MR. SPEAKER: The question is:
"That clause 12, as amended, stand part of the Bill."
The motion was adopted.
Clause 12, as amended, was added to the Bill.
Clauses 13 to 16 were added to the Bill.
Clause 17 Appointment of Controller And other Officers Amendment made:
Page 8, for lines 36 to 38, substitute, "(3A) The qualifications, experience and terms
and conditions of service of Controller, Deputy Controllers and Assistant Controllers
shall be such as may be prescribed by the Central Government.
"(4) The Head Office and Branch Office of the office of the Controller shall be at such
places as the Central Government may specify, and these may be established at such
places as the Central Government may think fit"; (12) (Shri Pramod Mahajan) MR.
SPEAKER: The question is:
"That clause 17, as amended, stand part of the Bill."
The motion was adopted.
Clause 17, as amended, was added to the Bill.
Clause 18 Functions of Controller Amendment made:
Page 8, after line 41 insert, "(ab) certifying public keys of the Certifying Authorities ";
(13) (Shri Pramod Mahajan) MR. SPEAKER: The question is:
"That clause 18, as amended, stand part of the Bill."
The motion was adopted.
Clause 18, as amended, was added to the Bill.
Clauses 19 to 22 were added to the Bill.Further Discussion On The Information Technology Bill, 1999 Moved By Shri Pramod ... on 16 May, 2000

Clause 23 Renewal of Licence Amendment made:
Page 10, omit lines 20 to 22. (14) (Shri Pramod Mahajan) MR. SPEAKER: The
question is:
"That clause 23, as amended, stand part of the Bill."
The motion was adopted.
Clause 23, as amended, was added to the Bill.
Clauses 24 and 25 were added to the Bill.
Clause 26 Notice of suspension or revocation Of licence Amendment made:
Page 11, after line 7, insert, "Provided that the database containing the notice of such
suspension or revocation, as the case may be, shall be made available through a web
site which shall be accessible round the clock:
Provided further that the Controller may, if he considers necessary, publicise the
contents of database in such electronic or other media, as he may consider
appropriate. "; (15) (Shri Pramod Mahajan) MR. SPEAKER: The question is:
"That clause 26, as amended, stand part of the Bill."
The motion was adopted.
Clause 26, as amended, was added to the Bill.
Clauses 27 to 32 were added to the Bill.
Clause 33 Surrender of Licence Amendment made:
Page 11, after line 41, insert "(2) Where any certifying authority fails to surrender a
lincence under sub-section (1), the person in whose favour a lincence is issued, shall
be guilty of an offence and shall be punished with imprisonment which may extend
upto six months or a fine which may extend upto ten thousand rupees or with both ".
(16) (Shri Pramod Mahajan) MR. SPEAKER: The question is:
"That clause 33, as amended, stand part of the Bill."
The motion was adopted.
Clause 33, as amended, was added to the Bill.Further Discussion On The Information Technology Bill, 1999 Moved By Shri Pramod ... on 16 May, 2000

Clauses 34 to 41 were added to the Bill.
Clause 42 Control of Private key Amendment made:
Page 14 for line 35 substitute "any delay to the Certifying Authority in such manner as
may be specified by the regulations.
Explanation.- For removal of doubts, it is hereby declared that the subscriber shall be
liable till he has informed the Certifying Authority that the private key has been
compromised. " (17) (Shri Pramod Mahajan) MR. SPEAKER: The question is:
"That clause 42, as amended, stand part of the Bill."
The motion was adopted.
Clause 42, as amended, was added to the Bill.
Clause 43 Penalty for demage to Computers, Computer sustem etc. Amendment made:
Page 15, line 18 for "ten lakhs" substitute "One crore". (18) (Shri Pramod Mahajan)
MR. SPEAKER: The question is:
"That clause 43, as amended, stands part of the Bill."
The motion was adopted.
Clause 43, as amended, was added to the Bill.
Clause 44 was added to the Bill.
Clause 45 Amendment made:
Page 16, line 7, for "contravention", substitute "contravention or a penalty not
exceeding twenty-five thousand rupees"(19) (Shri Pramod Mahajan) MR. SPEAKER:
The question is:
"That clause 45, as amended, stand part of the Bill."
The motion was adopted.
Clause 45, as amended, was added to the Bill.
Power to adjudicate Clause 46 Amendments made:Further Discussion On The Information Technology Bill, 1999 Moved By Shri Pramod ... on 16 May, 2000

Page 16, line 16, for "such penalty" substitute "such penalty or award such
compensation" (20) Page 16, for lines 18 and 19, substitute, "(3) No person shall be
appointed as an adjudication officer unless he possesses such experience in the field
of Information Technology and legal or judicial experience as may be prescribed by
the Central Government". (21) (Shri Pramod Mahajan) MR. SPEAKER: The question
is:
"That clause 46, as amended, stand part of the Bill."
The motion was adopted.
Clause 46, as amended, was added to the Bill.
Clauses 47 to 50 were added to the Bill.
Clause 51 Term of Office Amendment made:
Page 17, for lines 6 and 7, substitute, "51. The Presiding Officer of a Cyber Appellate
Tribunal shall hold office for a term of five years from the date on which he enters
upon his office or until he attains the age of sixty five years, whichever is earlier." (22)
(Shri Pramod Mahajan) MR. SPEAKER: The question is, "That clause 51, as
amended, stand part of the Bill."
The motion was adopted.
Clause 51, as amended, was added to the Bill.
Clauses 52 to 56 were added to the Bill.
Clause 57            Appeal to cyber Regulations 
Appellate Tribunal 
Amendments made: 
Page 18, - 
line 2, for "an adjudicating officer" substitute  
"Controller or an adjudicating officer"                                 (23) 
        Page 18, line 7, for "the adjudicating officer", substitute 
        "the Controller or the adjudicating officer"                            (24) 
        Page 18, line 17, for "adjudicating officer", substitute 
        "Controller or adjudicating officer"                                    (25) Further Discussion On The Information Technology Bill, 1999 Moved By Shri Pramod ... on 16 May, 2000

(Shri Pramod Mahajan) 
MR. SPEAKER: The question is: 
"That clause 57, as amended, stand part of the Bill." 
The motion was adopted. 
Clause 57, as amended, was added to the Bill. 
Clauses 58 to 65 were added to the Bill. 
Motion Re: Suspension of Rule 80 (i) 
SHRI PRAMOD MAHAJAN: I beg to move: 
"That this House do suspend clause (i) of rule 80 of the Rules of Procedure and Conduct of Business
in Lok Sabha in so far as it requires that an amendment shall be within the scope of the Bill and
relevant to the subject matter of the clause to which it relates, in its application to Government
amendment No.26 to the Information Technology Bill, 1999 and that this amendment may be
allowed to be moved. "
MR. SPEAKER: The question is:
"That this House do suspend clause (i) of rule 80 of the Rules of Procedure and
Conduct of Business in Lok Sabha in so far as it requires that an amendment shall be
within the scope of the Bill and relevant to the subject matter of the clause to which it
relates, in its application to Government amendment No.26 to the Information
Technology Bill, 1999 and that this amendment may be allowed to be moved."
The motion was adopted.
New Clause 65A Amendment made:
Page 19, after line 44, insert "65A. (1) whoever with the intent to cause or knowing
that he is likely to cause wrongful loss or damage to the public or any person destroys
or deletes or alters any information residing in a computer resource or diminishes its
value or utility or affects it injuriously by any means, commits hacking.
(2) whoever commits hacking shall be punished with imprisonment upto three years,
or with fine which may extend upto two lakh rupees, or with both". (26) (Shri
Pramod Mahajan) MR. SPEAKER: The question is:Further Discussion On The Information Technology Bill, 1999 Moved By Shri Pramod ... on 16 May, 2000

"That new clause 65A be added to the Bill."
The motion was adopted.
New clause 65A was added to the Bill.
Clause 66 Publising of information Which is obscene in electronic form Amendments made:
Page 19, line 49, for "two years", substitute "five years" (27) Page 19, line 50, for
"twenty-five thousand rupees", substitute "one lakh rupees" (28) Page 19, for line 52,
substitute "to ten years and also with fine which may extend to two lakh rupees". (29)
(Shri Pramod Mahajan) MR. SPEAKER: The question is:
"That clause 66, as amended, stand part of the Bill."
The motion was adopted.
Clause 66, as amended, was added to the Bill.
Clause 67 to 77 were added to the Bill.
Clause 78 Network servicde provides not Be liable in certain cases MR. SPEAKER: Shri Rupchand
Pal, are you moving amendment No.38?
SHRI RUPCHAND PAL (HOOGLY): I beg to move:
Page 21, after line 42, insert— "78(2). Notwithstanding anything contained in
sub-section (1), a network service provider shall be liable for any offence committed
under section 51 of the Copyright Act, 1957." (38) But in the light of the assurance
given by the hon. Minister that a suitable amendment will brought about in the
Copyright Act, I withdraw my amendment.
MR. SPEAKER: Is it the pleasure of the House that the amendment moved by Shri
Rupchand Pal be withdrawn?
The amendment was, by leave, withdrawn.
MR. SPEAKER: The question is:
"That clause 78 stand part of the Bill."
The motion was adopted.
Clause 78 was added to the Bill.Further Discussion On The Information Technology Bill, 1999 Moved By Shri Pramod ... on 16 May, 2000

- - - -
Clause 79 Power of poice officer and Other officers to enter,search etc. SHRI RUPCHAND PAL
(HOOGLY): I beg to move:
Page 22, line 6,--
for "without"
substitute "with appropriate and valid" (39) Page 22, after line 11, insert— "(1A) In
case of misuse of power by any police officer the concerned police officer shall be
punished according to the laws of the country." (40)   I am moving these
amendments because the replies given by both the Ministers, the Minister of
Information Technology, Shri Pramod Mahajan and the intervention made by the
eminent lawyer, Shri Arun Jaitley, have not convinced me because the arrests
without warrant is a way …… (Interruptions) We have the experience of FERA and
TADA…..… (Interruptions)
MR. SPEAKER: Shri Rupchand Pal, you have already participated in the discussion.
SHRI RUPCHAND PAL : My amendment is, for the word "without", the words "with appropriate
and valid" should be substituted.
MR. SPEAKER: Are you pressing your amendments?
SHRI RUPCHAND PAL: I have moved my amendments.
MR. SPEAKER: I shall now put amendment Nos.39 and 40 moved by Shri Rupchand Pal to the vote
of the House.
The amendments were put and negatived.
SHRI RUPCHAND PAL (HOOGLY): Sir, what about amendment No.40? I have not spoken on that
amendment.
MR. SPEAKER: You had moved amendment Nos. 39 and 40. You are not permitted to speak now.
… (Interruptions)
MR. SPEAKER: The question is:
"That clause 79 stand part of the Bill."
The motion was adopted.Further Discussion On The Information Technology Bill, 1999 Moved By Shri Pramod ... on 16 May, 2000

Clause 79 was added to the Bill.
Clauses 80 to 85 were added to the Bill.
- - - -
Clause 86 Power of Central Government To make rules  Amendments made:
Page 23, line 15, for "the Official Gazette", substitute "the Official Gazette and in the
Electronic Gazette"; (30) Page 23, after line 28, insert, "(ea) the qualifications,
experience and terms and conditions of service of Controller, Deputy Controllers and
Assistant Controllers under Section 17". (31) (Shri Pramod Mahajan) MR. SPEAKER:
The question is:
"That clause 86, as amended, stand part of the Bill."
The motion was adopted.
Clause 86, as amended, was added to the Bill.
Clause 87 was added to the Bill.
- - -
Clause 88 Power of Controller to Make regulations Amendment made:
Page 25, after line 8, insert "(g) the manner by which the subscriber communicate the
compromise of private key to the certifying Authority under sub-section (2) of section
42". (32) (Shri Pramod Mahajan)   MR. SPEAKER: The question is:
"That clause 88, as amended, stand part of the Bill."
The motion was adopted.
Clause 88, as amended, was added to the Bill Clauses 89 to 93 were added to the Bill.
The First Schedule was added to the Bill The Second Schedule was added to the Bill.
Third Schedule Amendments made:
Page 31,--
line 10, for "or any other form of electro-magnetic storage device", substitute "or any
other form of electro-magnetic data storage device"; (33) Page 31, lines 25 and 26, forFurther Discussion On The Information Technology Bill, 1999 Moved By Shri Pramod ... on 16 May, 2000

"consist of printouts of data stored in an electro-magnetic data storage device,
substitute "consist of printouts of data stored in a floppy, disc, tape or any other
electro-magnetic data storage device". (34)   (Shri Pramod Mahajan) MR. SPEAKER:
The question is:
"That the Third Schedule, as amended, stand part of the Bill."
The motion was adopted.
The Third Schedule, as amended, was added to the Bill.
The Fourth Schedule was added to the Bill.
Clause 1 Short title, extent, commencement And application Amendment made:
Page 1, line 13,--
for "1999" substitute—"2000" (2) (Shri Pramod Mahajan) MR. SPEAKER: The
question is:
"That clause 1, as amended, stand part of the Bill."
The motion was adopted.
Clause 1, as amended, was added to the Bill.
Enacting Formula Amendment made:
Page 1, line 10,--
for "Fiftieth Year" substitute "Fifty-first Year" (1) (Shri Pramod Mahajan) MR.
SPEAKER: The question is:
"That the Enacting Formula, as amended, stand part of the Bill."
The motion was adopted.
The Enacting Formula, as amended, was added to the Bill.
MR. SPEAKER: The question is:
"That the Preamble and the Long Title stand part of the Bill.
The motion was adopted.Further Discussion On The Information Technology Bill, 1999 Moved By Shri Pramod ... on 16 May, 2000

The Preamble and Long Title were added to the Bill.
--- .
SHRI PRAMOD MAHAJAN: Sir, I beg to move:
"That the Bill, as amended, be passed."
MR. SPEAKER: The question is:
"That the Bill, as amended, be passed."
The motion was adopted.
- - -
 
1628 hoursFurther Discussion On The Information Technology Bill, 1999 Moved By Shri Pramod ... on 16 May, 2000

