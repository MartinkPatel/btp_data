Bihar Juvenile Justice (Care and Protection of Children) Rules,
2015
BIHAR
India
Bihar Juvenile Justice (Care and Protection of
Children) Rules, 2015
Rule
BIHAR-JUVENILE-JUSTICE-CARE-AND-PROTECTION-OF-CHILDREN-RULES-2015
of 2015
Published on 1 January 2015• 
Commenced on 1 January 2015• 
[This is the version of this document from 1 January 2015.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
Bihar Juvenile Justice (Care and Protection of Children) Rules, 2015Published vide Notification No.
la010/iz0xk0Lfk0/17/2003-2140-17/2003-2140, date 19.11.2015Last Updated 13th February,
2020la010/iz0xk0Lfk0/17/2003-2140-17/2003-2140. - In exercise of the power conferred by
Section 68 of the Juvenile Justice (Care and Protection of Children) Act, 2000, (No. 56 of 2000) (as
amended from time to time) the State Government of Bihar makes the following Rules:-Chapter  I
Preliminary
1. Short title, extent and commencement.
(1)These rules may be called "The Bihar State Juvenile Justice (Care and Protection of Children)
Rules, 2015".(2)It shall extend to the whole of the state of Bihar.(3)It shall come into force from the
date of its publication in the Official Gazette.
2. Definition.
(1)In these rules, unless the context otherwise requires-(a)"Act" means the Juvenile Justice (Care
and Protection of Children) Act, 2000 (56 of 2000) (as amended from time to
time);(b)"Abandoned" means an unaccompanied and deserted child who is declared abandoned by
the Committee after due inquiry;(c)"Best interest of the child" means a decision taken to ensure the
physical, emotional, intellectual, social, cultural and moral development of juvenile or
child;(d)"Child abuse" means maltreatment which includes any of the following:-(i)Physical, mental,
sexual or emotional maltreatment;(ii)Any act by word or deed which degrades the dignity of theBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

child;(iii)Deprivation of his basic needs for survival;(e)"Child friendly" means any process,
interpretation, attitude, environment and treatment that is humane, considerate and in the best
interest of the child;(f)"Community service" implies service rendered to the society by juveniles in
conflict with law in lieu of or in addition to other judicial remedies and penalties, which is not
degrading and dehumanising; Examples of this may include (only non hazardous part);(i)Cleaning a
park/setting up of a garden;(ii)Serving the elderly in nursing homes or Old Age Homes;(iii)Helping
out at a local hospital or nursing home;(iv)Serving children with disabilities;(v)Community care of
elderly person;(vi)Group work;(vii)Getting involved with Habitat for Humanity;(g)"Detention" in
case of juveniles in conflict with law means "protective custody" in line with the principles of
restorative justice;(h)"Form" means the form annexed to these rules;(i)"Foster care" means the care
and protection of a child in need of care and protection for a stipulated period by a foster parent as
ordered by the Child Welfare Committee;(j)"Group Counselling" means an order under Section 16 of
the Act by the Juvenile Justice Board for the participation of a juvenile in any group counselling
programme organized by the State Government or by any recognized voluntary
organisation;(k)"Individual care plan" is a comprehensive development plan for a juvenile or child
based on age specific and gender specific needs and the case history of the juvenile or child,
prepared in consultation with the juveniles or child's self-esteem, dignity and self-worth and nurture
him into a responsible citizen and accordingly the plan shall address the following needs of a
juvenile or a child:(i)Health needs;(ii)Emotional and psychological needs;(iii)Educational and
training needs;(iv)Leisure, creativity and play;(v)Attachments and relationships;(vi)Protection from
all kinds of abuse, neglect and maltreatment;(vii)Social mainstreaming; and(viii)Follow-up, post
release and restoration.(l)"Institution" means an Observation Home , a Special Home, a Children's
Home or a Shelter Home set up, certified or recognized and registered under Sections 8, 9, 34,
sub-Section (3) of Section 34 and Section 37 of the Act respectively;(m)"Superintendent" means a
person appointed for the control and management of the institution;(n)"Orphan" means a child who
is without parents or without a willing and capable legal or natural guardian;(o)"Place of safety"
means any institution set up and recognized under sub-Section (3) of Section 12 and sub-Section (1)
of Section 16 of the Act for juvenile in conflict with law or children;(p)"Fit person", "Fit institution"
means a person found fit by the competent authority or, an institution found fit by the State
Government on the recommendation of the competent authority as per clauses (h) and (i) of Section
(2) of the Act. This shall be done on a case to case basis for a temporary period of time for that
specific child. These institutions may be registered under any Act;(q)"Registered" means all
institutions or agencies or voluntary organizations providing residential care or any other care to
children in need of care and protection registered under sub-Section (3) of Section 34;(r)"State
Government" means the Government of Bihar;(s)"Street and working children" means children
without ostensible means of livelihood, care, protection and support in accordance with the
provisions laid down under clause (d) (1) of Section 2 of the Act;(t)"Surrendered child" means a
child, who in the opinion of the Committee, is relinquished on account of physical, emotional and
social factors beyond the control of the parent or guardian;(2)All words and expressions defined in
the Act and used, but not defined in these rules, shall have the same meaning as assigned to them in
the Act.Chapter  II Fundamental Principals Of Juvenile Justice And Protection Of ChildrenBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

3. Fundamental principles to be followed in administration of these rules.
(1)The State Government, the Juvenile Justice Board, the Child Welfare Committee or other
competent authorities or agencies, as the case may be, while implementing the provisions of these
rules shall abide and be guided by the principles, specified in sub-rule (2).(2)The following
principles shall, inter alia, be fundamental to the application, interpretation and implementation of
the Act and the rules made hereunder:I. Principle of presumption of innocence. - (a) A juvenile or
child or juvenile in conflict with law is presumed to be innocent of any mala fide or criminal intent
up to the age of eighteen years.(b)Right to presumption of innocence of the juvenile or juvenile in
conflict with law or the child shall be respected throughout the process of justice and protection,
from the initial contact to alternative care, including aftercare.(c)Any unlawful conduct of a juvenile
or a child or a juvenile in conflict with law which is done for survival, or is due to environmental or
situational factors or is done under control of adults, or peer groups, is ought to be covered by the
principles of innocence.(d)The basic components of presumption of innocence are:(i)Age of
innocence. - Age of innocence is the age below which a juvenile or child or a juvenile in conflict with
law cannot be subjected to the criminal justice system. The Beijing Rule (1) clearly lays down that
"the beginning of the age of criminal responsibility shall not be fixed at too low an age level bearing
in mind the facts of mental and intellectual maturity". In consonance with this principle, the mental
and intellectual maturity of juvenile or child or a juvenile in conflict with law below eighteen years is
considered insufficient throughout the world.(ii)Procedural protection of innocence. - All procedural
safeguards that are guaranteed by the Constitution and other statutes to the adults and that go in to
strengthen the juveniles or child's right to presumption of innocence shall be guaranteed to juveniles
or the children or juveniles in conflict with law.(iii)Provisions of Legal aid and Guardian Ad Litem. -
Juveniles in conflict with law have a right to be informed about the accusations against them and a
right to be legally represented. Provisions must be made for guardian ad litem, legal aid and other
such assistance through legal services at State expense. This shall also include such juveniles right to
present his case before the competent authority on his own.II Principle of dignity and worth. - (a)
Treatment that is consistent with the child's sense of dignity and worth is a fundamental principle of
juvenile justice. This principle reflects the fundamental human right enshrined in Article 1 of the
Universal Declaration of Human Rights that all human beings are born free and equal in dignity and
rights. Respect of dignity includes not being humiliated, personal identity, boundaries and space
being respected, not being labelled and stigmatised, being offered information and choices and not
being blamed for their acts.(b)The juveniles or child's right to dignity and worth has to be respected
and protected throughout the entire process of dealing with the child from the first contact with law
enforcement agencies to the implementation of all measures for dealing with the child.III. Principle
of Right to be heard. - Every child's right to express his views freely in all matters affecting his
interest shall be fully respected through every stage in the process of juvenile justice. Children's
right to be heard shall include creation of developmentally appropriate tools and processes of
interacting with the child, promoting children's active involvement in decisions regarding their own
lives and providing opportunities for discussion and debate.IV. Principle of Best Interest. - (a) In all
decisions taken within the context of administration of juvenile justice, the principle of best interest
of the juvenile or the juvenile in conflict with law or child shall be the primary consideration.(b)The
principle of best interest of the juvenile or juvenile in conflict with law or child shall mean for
instance that the traditional objectives of criminal justice, retribution and repression, must give wayBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

to rehabilitative and restorative objectives of juvenile justice.(c)This principle seeks to ensure
physical, emotional, intellectual, social and moral development of a juvenile in conflict with law or
child so as to ensure the safety, well being and permanence for each child and thus enable each child
to survive and reach his or her full potential.V. Principle of family responsibility. - (a) The primary
responsibility of bringing up children, providing care, support and protection shall be with the
biological parents. However, in exceptional situations, this responsibility may be bestowed on
willing adoptive or foster parents.(b)All decision making for the child should involve the family of
origin unless it is not in the best interest of the child to do so.(c)The family - biological, adoptive or
foster (in that order), must be held responsible and provide necessary care, support and protection
to the juvenile or child under their care and custody under the Act, unless the best interest measures
or mandates dictate otherwise.VI. Principle of Safety (no harm, no abuse, no neglect, no exploitation
and no maltreatment). - (a) At all stages, from the initial contact till such time he remains in contact
with the care and protection system, and thereafter, the juvenile or child or juvenile in conflict with
law shall not be subjected to any harm, abuse, neglect, maltreatment, corporal punishment or
solitary or otherwise any confinement in jails and extreme care shall be taken to avoid any harm to
the sensitivity of the juvenile or the child.(b)The state has a greater responsibility for ensuring safety
of every child in its care and protection, without resorting to restrictive measures and processes in
the name of care and protection.VII. Positive measures. - (a) Provisions must be made to enable
positive measures that involve the full mobilization of all possible resources, including the family,
volunteers and other community groups, as well as schools and other mainstream community
institutions or processes, for the purpose of promoting the well-being of the juvenile or child
through individual care plans carefully worked out.(b)The positive measures shall aim at reducing
vulnerabilities and reducing the need for intervention under the law, as well as effective, fair and
humane dealing of the juvenile or child.(c)The positive measures shall include avenues for health,
education, relationships, livelihoods, leisure, creativity and play.(d)Such positive measures must
facilitate the development of identity for the child and provide them with an inclusive and enabling
environment.VIII. Principle of non-stigmatizing semantics, decisions and actions. - The
nonstigmatizing semantics of the Act must be strictly adhered to, and the use of adversarial or
accusatory words, such as, arrest, remand, accused, charge sheet, trial, prosecution, warrant,
summons, conviction, inmate, delinquent, neglected, custody or jail is prohibited in the processes
pertaining to the child or juvenile in conflict with law under the Act.IX. Principle of non-waiver of
rights. - (a) No waiver of rights of the child or juvenile in conflict with law, whether by himself or the
competent authority or anyone acting or claiming to act on behalf of the juvenile or child, is either
permissible or valid.(b)Non-exercise of a fundamental right does not amount to waiver.X. Principle
of equality and non-discrimination. - (a) There shall be no discrimination against a child or juvenile
in conflict with law on the basis of age, sex, place of birth, disability, health, status, race, ethnicity,
religion, caste, cultural practices, work, activity or behaviour of the juvenile or child or that of his
parents or guardians, or the civil and political status of the juvenile or child.(b)Equality of access,
equality of opportunity, equality in treatment under the Act shall be guaranteed to every child or
juvenile in conflict with law.XI. Principle of right to privacy and confidentiality. - The juveniles or
child's right to privacy and confidentiality shall be protected by all means and through all the stages
of the proceedings and care and protection processes.XII. Principle of last resort. -
Institutionalisation of a child or juvenile in conflict with law shall be a step of the last resort after
reasonable inquiry and that too for the minimum possible duration.XIII. Principle of repatriationBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

and restoration. - (a) Every juvenile or child or juvenile in conflict with law has the right to be
re-united with his family and restored back to the same social-economic and cultural status that
such juvenile or child enjoyed before coming within the purview of the Act or becoming vulnerable
to any form of neglect, abuse or exploitation.(b)Any juvenile or child, who has lost contact with his
family, shall be eligible for protection under the Act and shall be repatriated and restored, at the
earliest, to his family, unless such repatriation and restoration is likely to be against the best interest
of the juvenile or the child.XIV. Principle of Fresh Start. - (a) The principle of fresh start promotes
new beginning for the child or juvenile in conflict with law by ensuring erasure of his past
records.(b)The State shall seek to promote measures for dealing with children alleged or recognized
as having impinged the penal law, without resorting to judicial proceedings.Chapter  III Juvenile
In Conflict With Law
4. Juvenile Justice Boards.
- There shall be one or more Juvenile Justice Boards in every district, which shall be constituted by
the State Government as per Section 4 of the Act.
5. Composition of the Juvenile Justice Board.
(a)The Board shall consist of Metropolitan Magistrate or Judicial Magistrate of the first class, as
Principal Magistrate and, two social workers from the district concerned as members of the Board of
whom at least one shall be a woman, forming a Bench:Provided that the Principal Magistrate of the
Board shall assess the pendency of cases before the Board and take such steps, as may be necessary
in the expeditious disposal of the cases.(b)Every such bench shall have the powers conferred by the
Code of Criminal Procedure 1973 (2 of 1974).(c)(i)A Magistrate with special knowledge or training in
child psychology or child welfare shall be designated as the Principal Magistrate of the Board.(ii)In
case the Principal Magistrate with such special knowledge or training is not available, then, the State
Government shall provide for such short-term training in child psychology or child welfare as it
considers necessary.(d)The two social workers, of whom at least one shall be a woman, shall be
appointed by the State Government from a panel of names on the recommendation of the Selection
Committee set up under Rule 89 of these Rules;(e)The State Government shall provide for such
training and orientation in child psychology, child welfare, child rights, national and international
standards for juvenile justice to all members of the Board, as it considers necessary, in accordance
with the schemes and programmes of the State Government/Central Government.
6. Tenure of the Board.
(1)The Board shall have a tenure of three years and the appointment of members shall be
co-terminus with the tenure of the Board.(2)A social worker being a member of the Board shall be
eligible for appointment for a maximum of two consecutive terms.(3)Any re-appointment of the
member of the Board shall be on the basis of his performance appraisal by the District Child
Protection Unit or the State Government and on the recommendation of the Selection Committee
set up under Rule 89 of these Rules and the performance assessment of members of the Board shall
necessarily assess their participation in the proceedings of the Board and contribution in caseBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

disposal;(4)A Member may resign any time, by giving one month's advance notice in writing or may
be removed from his office as provided in Sub-Section (5) of Section 4 of the Act.(5)Any vacancy in
the Board may be filled by appointment of another person from the panel of names prepared by the
Selection Committee, and the person so appointed shall hold office for the remaining term of the
Board.
7. Qualifications for Members of the Board.
(1)A social worker to be selected as a Member of the Board shall be a person not less than 30 years
of age and not more than 65 years of age and have either of the following qualifications, in addition
to a minimum of five years experience and engaged in planning, implementing or administering
measures relating to health, education, child rights and other development activities related to
children preferably:(i)A post-graduate degree in social work/health/education/psychology/child
development or in any social science discipline.(ii)In case suitable candidates having minimum
qualifications as per (i) are not available in the district, Selection Committee can recommend
candidates having (a) graduate degree in subjects mentioned in sub para (i) and experience for at
least five years;(2)Under circumstances where two or more candidates are having similar
qualification and experience, preference shall be given to members belonging to SC/ST
communities.Provided that, in case where eligibility of SC/ST members is the same the decision of
State Level Selection Committee shall be final.(3)No person shall be considered for selection as a
Member of the Board, if he, -(i)has been convicted under any law;(ii)has ever indulged in child
abuse or employment of child labour or any other human rights violations or immoral act;(iii)is
holding such other full time or part time occupation that does not allow him to give necessary time
and attention to the work of the Board;(iv)does not fulfill the qualification and experience
prescribed in the Act and these rules and in such a case the Selection Committee shall, after due
inquiry and on establishment of such fact, reject his application and recommend the name of the
next person from the list of names prepared for filling the vacancies.(4)No two members of the
board shall be in consanguineous or conjugal relationship.
8. Sitting and conveyance allowances.
- The Social Worker members of Board shall be paid such travel and sitting allowance as the state
government may determine.
9. Sittings of the Board.
(a)The Board shall hold its sittings in the premises of an observation home or at any suitable
premise, other than court premises.(b)The state government shall set up by notification in official
gazette, Juvenile Justice Board under Section 4 of the Act in every district, with requisite
infrastructure, human resources and finances for smooth functioning of the Board, as prescribed
under the norms of existing scheme, if any, or as may be determined by the state government.(c)The
premises where the Board holds its sittings shall be child-friendly and shall not look like a Court
room in any manner whatsoever; for example, the Board shall not sit on a raised platform and the
sitting arrangement shall be uniform, and there shall be no witness boxes.(d)The proceedings of theBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

Board shall be like a conference in which the Juvenile Justice Board members, the juvenile, the
parents, the Probation Officer, the Police Officer, the legal representative etc., shall participate in the
proceedings.(e)The Board shall meet on all working days of a week, but the sitting frequency can be
extended by the Principal Magistrate. The State Government may also extend the number of sittings
in a week by a general or special order.(f)A minimum of three-fourth attendance of the Principal
Magistrate and members of the Board is necessary in a year.(g)Every member of the Board shall
attend a minimum of five hours per sitting.
10. Functions of the Board.
(1)The Board shall perform the following functions to achieve the objectives of the Act,
namely:-(a)Adjudicate and dispose cases of juveniles in conflict with law;(b)Take cognizance of
crimes committed under Sections 23 to 28 of the Act;(c)Monitoring institutions for juvenile in
conflict with law and seeking compliance from them in cases of any noticeable lapses and
improvement based on suggestions of the Board;(d)Deal with non-compliance of any order passed
by the Board on the part of concerned government functionaries or functionaries of voluntary
organizations, as the case may be, in accordance with due process of law;(e)Pass necessary direction
to the district authority and police to create or provide necessary infrastructure or facilities so that
minimum standards of justice and treatment are maintained in the spirit of the Act;(f)Maintain
liaison with the Committee in respect of cases needing care and protection;(g)Liaison with Boards in
other districts and other states or union territories to facilitate speedy inquiry and disposal of cases
through due process of law;(h)Take suitable action for dealing with unforeseen situations that may
arise in the implementation of the Act and remove such difficulties in the best interest of the
juvenile;(i)Send monthly and quarterly information about juveniles in conflict with law produced
before them to the District Child Protection Unit, State Child Protection Society/Unit, the State
Government and to the Chief Judicial Magistrate for review under Para (2) of Section 14 of the
Act;(j)Any other function assigned by the State Government from time to time relating with
juveniles in conflict with law;(k)The Board shall initiate action against any media for publishing any
matters relating to the children in conflict with law which would lead to the identification of the
child;(l)The Board shall order to keep the child in an Observation Home or in a place of safety, as
the case may, be if the child could not be released on bail to the care of parents/guardians;(m)The
Board shall ensure that no girl child was taken charge by police between sunset and
sunrise;Provided if the circumstances warrants the police to take charge of a girl child during such
time, the Board should ensure that the girl child was kept under the care of a female fit person or a
relative of the girl child, who shall also be a female fit person or in a place of safety or in an
Observation Home;(n)The Board shall, at any stage during the course of enquiry if satisfied that the
attendance of the child is not essential for the purpose of enquiry, may dispense with his attendance
and proceed with the enquiry in the absence of the child;(o)The Board can also direct the Probation
Officer to conduct social enquiry and furnish the report to the Board and also direct him to cause the
professional/expert opinion on cases pertaining to the psychological/psychiatric problems of the
Child, provided the Board, can also direct the professionals to furnish a special report about the
child in conflict with law;(p)The Department of Pediatrics/Psychiatric medicines of the Medical
colleges/hospitals shall be recognized as nodal agencies for giving professional opinion.Bihar Juvenile Justice (Care and Protection of Children) Rules, 2015

11. Pre and Post-Production action of Police and other Agencies.
(1)As soon as a juvenile alleged to be in conflict with law is apprehended by the police, the concerned
police officer shall inform:(a)the designated Juvenile or the Child Welfare Officer in the nearest
police station to take charge of the matter;(b)the parents or guardian of the juvenile alleged to be in
conflict with law about the apprehension of the juvenile, about the address of the Board where the
juvenile will be produced and the date and time when the parents or guardian need to be present
before the Board;(c)the concerned probation officer, of such apprehension to enable him to obtain
information regarding social background of the juvenile and other material circumstances likely to
be of assistance to the Board for conducting the inquiry.(2)Soon after apprehension, the juvenile
shall be placed under the charge of the Juvenile or Child Welfare Officer from the nearest police
station, who shall produce the juvenile before the Board within twenty four hours as per sub-Section
(1) of Section 10 of the Act and where such Juvenile or the Child Welfare Officer has not been
designated as per provisions laid down under sub- Section (2) of Section 63 of the Act or is not
available for some official reasons, the police officer who had apprehended the juvenile shall
produce him before the Board.(3)The police apprehending a juvenile in conflict with law shall in no
case send the juvenile in lock-up or delay his charge being transferred to the Juvenile or the Child
Welfare Officer from the nearest police station, if such an officer has been designated.(4)A list of all
designated Juvenile or the Child Welfare Officers in a district and members of Special Juvenile
Police Unit with contact details shall be prominently displayed in every police station.(5)For
gathering the best available information it shall be incumbent upon the Police or the Juvenile or the
Child Welfare Officer from the nearest police station, to contact the parents or guardians of the
juvenile and also apprise them of the juvenile`s law breaking behaviour.(6)The police or the
Juvenile or the Child Welfare Officer from the nearest police station, shall also record the social
background of the juvenile and circumstances of apprehension and offence alleged to have been
committed in the case diary of each juvenile, which shall be forwarded to the Board forthwith.(7)The
police or the Juvenile or the Child Welfare Officer from the nearest police station, shall exercise the
power of apprehending the juvenile only in cases of his alleged involvement in serious offences
(entailing a punishment of more than 7 years imprisonment for adults).(8)In such cases where
apprehension apparently seems to be in the interest of the juvenile, the police or the Juvenile or the
Child Welfare Officer from the nearest police station, shall rather treat the juvenile as a child in need
of care and protection and produce him before the Board, clearly explaining the juvenile's need for
care and protection in its report and seek appropriate orders from the Board under rule 13 (1) (b) of
these Rules.(9)For all other cases involving offences of non-serious nature (entailing a punishment
of less than 7 years imprisonment for adults) and cases where apprehension is not necessary in the
interest of the juvenile, the police or the Juvenile or the Child Welfare Officer from the nearest
police station, shall intimate the parents or guardian of the juvenile about forwarding the
information regarding nature of offence alleged to be committed by their child or ward along with
his socioeconomic background to the Board, which shall have the power to call the juvenile for
subsequent hearings.(10)In case the Board is not sitting, the juvenile in conflict with law shall be
produced before the single member of the Board as per the provisions laid down under the
sub-Section (2) of Section 5 of the Act.(11)In dealing with cases of juveniles in conflict with law the
Police or the Juvenile or the Child Welfare Officer from the nearest police station, shall not be
required to register an FIR or file a charge-sheet, except where the offence alleged to have beenBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

committed by the juvenile is of a serious nature such as rape, murder or when such offence is alleged
to have been committed jointly with adults; instead, in matters involving simple offences, the Police
or the Juvenile or the Child Welfare Officer from the nearest police station shall record information
regarding the offence alleged to have been committed by the juvenile in the general daily diary
followed by a report containing social background of the juvenile and circumstances of
apprehension and the alleged offence and forward it to the Board before the first hearing.(12)The
State Government shall recognize only such voluntary organizations that are in a position to provide
the services of probation, counselling, case work, a safe place and also associate with the Police or
the Juvenile or the Child Welfare Officer from the Special Juvenile Police Unit, an d have the
capacity, facilities and expertise to do so as protection agencies that may assist the Police or the
Juvenile or the Child Welfare Officer from the police at the time of apprehension, in preparation of
the report containing social background of the juvenile and circumstances of apprehension and the
alleged offence, in taking charge of the juvenile until production before the Board, and in actual
production of the juvenile before the Board within twenty-four hours.(13)The Police or the Juvenile
or the Child Welfare Officer from the Special Juvenile Police Unit, or the recognized voluntary
organization shall be responsible for the safety and provision of food and basic amenities to the
juveniles apprehended or kept under their charge during the period such juveniles are with
them.(14)When a juvenile is produced before an individual member of the Board, and an order
obtained, such order shall need ratification by the Board in its next meeting.
12. Procedure to be followed in determination of Age.
(1)Except in cases where a juvenile or child appears prima facie to be a juvenile or child, the court or
the Board or the Committee, as the case may be, shall determine the age of such juvenile or child
within a period of thirty days from the date of making of the application for that purpose.(2)The
Court or the Board or the Committee shall decide the juvenility or otherwise of the juvenile or the
child in need of care and protection, prima facie on the basis of physical appearance or documents, if
available, and send him to the observation home or children's home or in prison as the case may
be.(3)Save and except where a juvenile or a child, as the case may be, prima facie appears to be
above 12 years of age, age determination shall be conducted by the court or the Board or the
Committee, as the case may be, by seeking evidence, by obtaining--(a)(i)the matriculation and
equivalent certificate along with copies of attendance record of class VIII attended by the juvenile or
child; or,(ii)the date of birth certificate from the school (other than a play school) first attended; and
in the absence whereof;(iii)the birth certificate given by the Municipal Corporation or a Municipal
Authority or a Panchayat; and(b)only in the absence of either (i) and/or (ii) or (iii) of clause (a)
above, or in case the Court or the Board or the Committee finds it necessary, the medical opinion
will be sought from a duly constituted Medical Board, which will declare the age of the juvenile or
child. In case exact assessment of the age cannot be done, the Court or the Board or, as the case may
be, the Committee, for the reasons recorded by them, may, if to be considered necessary, give
benefit to the child or juvenile by considering his/her age on lower side within the margin of one
year and, while passing orders in such case shall, after taking into consideration such evidence as
may be available or the medical opinion as the case may be, record a finding in respect of his age and
either of the evidence specified in any of the clauses (a) (i), (ii), (iii) or in the absence whereof, clause
(b) shall be proof of the age as regards such child or the juvenile in conflict with law.(4)The dulyBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

constituted Medical Board shall submit medical opinion to the competent authority within one week
from the date of receipt of the order.(5)If the age of a juvenile or child is found to be below 18 years
on the date of offence, on the basis of any of the proof specified in sub-rule (3), the Court or the
Board or, as the case may be, the Committee shall in writing pass an order stating the age and
declaring the status of juvenility or otherwise, for the purpose of the Act and these Rules and a copy
of the order shall be given to such juvenile or the parent/guardian/person concerned.(6)The
provisions contained in this rule shall also apply to those disposed of cases, where the status of
juvenility has not been determined in accordance with the provisions contained in sub rule (3) and
the Act, requiring dispensation of the sentence under the Act for passing appropriate order in the
interest of the juvenile in conflict with law.
13. Post-production processes by the Board.
(1)On production of the juvenile before the Board, a report containing social background of the
juvenile and circumstances of apprehension and offence alleged to have been committed shall be
provided by the concern juvenile/child welfare or police officer, other officers, individuals, agencies
producing the juvenile on the same day. Such report shall be reviewed by the Board, and the Board
shall pass the following order in the first summary inquiry on the same day, namely:-(a)dispose of
the case, if the evidence of his conflict with law appears to be unfounded or where the juvenile is
involved in trivial law breaking;(b)transfer to the Committee, matters concerning juveniles clearly
stated to be in need of care and protection in the police report submitted to the Board at the time of
production of the juvenile;(c)release the juvenile in the supervision or custody of fit persons or fit
institutions or probation officers as the case may be, through an order in Form-I, with a direction to
appear or present a juvenile for an inquiry on a next date;(d)detain the juvenile in an Observation
Home or fit institution pending inquiry, only in cases of juveniles involvement in serious offences as
per an order in Form-II;(e)in all cases of release pending inquiry, the Board shall notify the next
date of hearing, not later than 15 days of the first summary enquiry and also seek social investigation
report from the concerned Probation Officer through an order in Form-III;
14. Enquiry.
(1)The Board shall take the following steps to ensure fair and speedy inquiry, namely:-(a)at the time
of initiating the inquiry, the Board shall satisfy itself that the juvenile in conflict with law has not
been subjected to any ill-treatment by the police or by any other person, including a lawyer or
probation officer and take corrective steps in case of such ill- treatment;(b)in all cases under the Act
the proceedings shall be conducted in as simple a manner as possible and care shall be taken to
ensure that the juvenile, against whom the proceedings have been instituted, is given child-friendly
atmosphere during the proceedings;(c)Every juvenile brought before the Board shall be given the
opportunity to be heard and participate in his inquiry;(d)Cases of petty offences, if not disposed off
by the Special Juvenile Police Unit or at the police station itself, may be disposed of by the Board
through summary proceedings or inquiry within one month, while in cases of serious offences
entailing punishment of 7 years or more, due process of inquiry in detail may follow;(e)Even in cases
of inquiry pertaining to serious offences the Board shall follow the procedure of trial in summons
cases.(2)When witnesses are produced for examination in inquiry relating to a juvenile in conflictBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

with law, the Board shall keep in mind that the inquiry is not to be conducted in the spirit of strict
adversarial proceedings and it shall use the powers conferred by Section 165 of the Indian Evidence
Act, 1872 (1 of 1872) so as to question the juvenile and proceed with the presumptions that favour
the juveniles right to be restored.(3)While examining a juvenile in conflict with law and recording
his statement, the Board shall address the juvenile in a child-friendly manner in order to put the
juvenile at ease and to encourage him to state the facts and circumstances without any fear, not only
in respect of the offence of which the juvenile is accused, but also in respect of the home and social
surroundings and the influence to which the juvenile might have been subjected.(4)The record of
the examination shall be in such form as the Board may consider suitable having regards to contents
of the statement and circumstances in which it was made.(5)The Board may take into account the
report of the police containing circumstances of apprehension and offence alleged to have been
committed and the social investigation report in Form IV prepared by the Probation officer or the
voluntary organization on the orders of the Board as per Form III, along with the evidence produced
by the parties for arriving at a conclusion about the juvenile.(6)Every inquiry by the Board shall be
completed within a period of four months from the date of commencement of the case and only in
exceptional cases involving transnational criminality, large number of accused and inordinate delay
in production of witnesses, the period of inquiry may be extended by two months on recording of
reasons by the Board.(7)In all other cases except where the nature of alleged offence is serious, delay
beyond four to six months shall lead to the termination of the proceedings.(8)Where the
proceedings are delayed beyond six months on account of serious nature of the offence alleged to
have been committed by the juvenile, the Board shall send a periodic report of the case to the
District Judge stating the reason for delay as well as steps being taken to expedite the matter.
15. Legal Aid.
(1)The proceedings before the Board shall be conducted in non-adversarial environment, but with
due regard to all the due process guarantees such as right to counsel and free legal aid.(2)Bihar State
Legal Services Authority shall nominate panel of lawyers as per the directions of National Legal
Services Authority (NALSA) to facilitate the legal services to juvenile in conflict with law. Their
services may also include to obtain relief in cases of abuse or exploitation of the child.(3)The Board
shall ensure that the Legal Officer in the District Child Protection Unit and the State Legal Aid
Services Authority shall extend free legal services to all juvenile in conflict with law.(4)The Legal
Officer in the District Child Protection Unit and the State Legal Aid Services Authority shall be
under an obligation to provide legal services sought by the Board.(5)The Board may also deploy the
services of the student, legal services volunteers and nongovernmental organization volunteers in
Para-legal tasks such as contacting the parents of juveniles in conflict with law and gathering
relevant social and rehabilitative information about the juveniles.
16. Completion of Inquiry and Dis-positional Alternatives.
(1)The Board shall complete every inquiry within the stipulated time of four months and on
recording a finding about juveniles involvement in the alleged offence, pass one of the seven
dis-positional orders enumerated in Section 15 of the Act.(2)Before passing an order, the Board shall
obtain a social investigation report prepared by the probation officer or by a recognized voluntaryBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

organization ordered to do so by the Board, and take the findings of the report into account.(3)All
dis-positional orders passed by the Board shall necessarily include an individual care plan in Form
XXI for the concerned juvenile in conflict with law, prepared by a probation officer on the basis of
interaction with the juvenile and his family where possible.(4)Where the Board decides to release
the juvenile after advice and admonition or after participation in group counseling or orders him to
perform community service, necessary direction may also be made by the Board to the District or
State Child Protection Society/Unit or the State Government for arranging such individual
counselling, group counselling and community service.(5)Where the Board decides to release the
juvenile in conflict with law on probation and place him under the care of the parent or guardian or
fit person, the person in whose custody the juvenile is released may be required to submit a written
undertaking in Form V for the good behaviour and well-being of the juvenile for a maximum period
of three years.(6)The Board may order release of a juvenile in conflict with law on execution of a
personal bond without surety in Form VI.(7)In the event of placement of a juvenile in conflict with
law in care of a fit institution or special home, the Board shall keep in mind that the fit institution or
special home is located nearest to the place of residence of the juveniles parent or guardian.(8)The
Board, where it releases a juvenile in conflict with law on probation and places him under the care of
parent or guardian or fit person or where the juvenile is released on probation and places him under
the care of fit institution, may order that the juvenile be placed under the supervision of a probation
officer. The period of supervision shall be a maximum of three years.(9)Where the Board decides
that a juvenile in conflict with law ought to be treated as a child in need of care and protection, it
shall make necessary orders for production of such juvenile before the nearest Committee for
suitable care, protection and rehabilitation.(10)Where it appears to the Board that the juvenile in
conflict with law has not complied with probation conditions, it may order the juvenile to be sent for
detention in a Special Home.(11)Where a juvenile in conflict with law who has attained the age of
sixteen years and the offence committed by him is of such a serious nature that in the satisfaction of
the Board, it is neither in the interest of the juvenile himself nor in the interest of other juveniles of
the special home, the Board may order the juvenile to be kept in a place of safety and in a manner
considered most appropriate by it.(12)The State Government shall make arrangement for complying
with the detention of special category of juveniles in conflict with law in place of safety other than
the special home.(13)In no case, the period of detention shall exceed beyond the maximum period
provided in clause (g) of sub-Section (1) of Section 15 of the Act.
17. Institutions for juveniles in conflict with law.
(1)The State Government, either by itself or under an agreement with the recognized voluntary
organization, shall set up separate observation homes or place of safety and special homes for boys
and girls in every district or in group of districts as per requirement.(2)The observation homes and
special homes shall set up separate residential facilities for boys and girls with a classification and
segregation up to the age of 11 years, 12-15 years and 16 years and above.(3)Every institution shall
keep a copy of the Act, the rules made by the State, for use of staff, juveniles and children residing
therein.(4)The State Government shall develop an Operational Manual.(5)All facilities and services
for juveniles in conflict with law shall be made available and maintained as per the provisions of the
Act and the State Rules.Bihar Juvenile Justice (Care and Protection of Children) Rules, 2015

18. Release.
(1)The Superintendent shall maintain a roster of the cases of juveniles in conflict with law to be
released on the expiry of the period of stay as ordered by the Board.(2)Each case shall be placed
before the Management Committee set up under Rule 62 of these rules by the concerned
superintendent, probation officer, child welfare officer or case worker, for ensuring proper release
and social mainstreaming of the juvenile post- release.(3)The release shall be as per the pre-release
and post release plan prepared under the individual care plan and reviewed from time to time by the
management committee set up under Rule 62 of these rules and in all cases of release, necessary
action and preparation shall be initiated well before the time of release and shall include preparation
for post release follow up.(4)Timely information of the release of a juvenile and of the exact date of
release shall be given to the parent or guardian and the parent or guardian shall be invited to come
to the institution to take charge of the juvenile on that date.(5)If the parent or guardian, as the case
may be, fails to come and take charge of the juvenile on the appointed date, the juvenile shall be
taken to his parent or guardian by the escort of the institution; and in case of a girl, she shall be
escorted by a female escort, who shall hand over her custody to her parent/guardian.(6)At the time
of release or discharge, a juvenile shall be provided with a set of clothing and essential toiletries.(7)If
the juvenile has no parent or guardian, he may be sent to an Aftercare Home/Child Welfare
committee for appropriate direction, or in the event of his employment, to the person who has
undertaken to employ the juvenile.(8)The Superintendent of a girl's institution may, subject to the
consent of the girl and the approval of the Board, help the girl with her social re-integration by way
of sending a girl above the age of eighteen years to an after care home or helping her with some
vocation or gainful employment or, helping her settle into family life as per the procedure laid down
by the state government from time to time.(9)The Superintendent shall order the discharge in Form
VII of any juvenile whose detention period has come to an end and inform the Board and Director of
Social Welfare within seven days of the action taken and if the date of release falls on a Sunday or a
public holiday, the juvenile may be discharged on the preceding day with an entry to that effect
being made in the register of discharge. The Superintendent shall be liable for disciplinary action
including initiation of departmental proceeding, if he/she fails to release the juvenile on the date of
such release or implement the order.(10)The Superintendent shall in appropriate cases, order the
payment of subsistence money, at such rates as may be fixed from time to time, by the State
Government, and the railway or road, or both, fares, as the case may be.(11)In deserving cases, the
Superintendent may provide the juvenile with such small tools, as may be necessary to start a work
or business subject to such maximum cost as may be fixed by the institution which shall also form
part of the post-release plan.(12)Where a Juvenile in Conflict with law has no place to go after
release or in order to complete the course and requests for stay in the institution after the period of
his/her stay is over, the Superintendent may, subject to the approval of the competent authority,
allow his/her to stay till the time some other suitable arrangements are made; or may be transferred
to an After Care Home.
19. Procedure to be followed in respect of Sections 21, 22, 23, 24, 25 and 26
of the Act.Bihar Juvenile Justice (Care and Protection of Children) Rules, 2015

(1)In the event of violation of provisions laid down under Section 21 of the Act,-(a)The
Board/Committee shall take cognizance of such violation by print or electronic media and shall
initiate necessary inquiry and pass appropriate orders as per provisions contained in sub-Section (2)
of Section 21 of the Act; and;(b)where the National or the State Commission for Protection of Child
Rights takes suo motu cognizance of violation under Section 21 of the Act, it shall inform the District
or the State Child Protection Unit of the concerned district and the State directing them to initiate
necessary action through the Board.(2)In the event of an escape of a juvenile in conflict with law or a
child, the following action shall be taken within twenty-four hours,-(a)The Superintendent of the
institution shall immediately send a report to the area Police Station or Special Juvenile Police Unit
along with the details and description of the juvenile or child, with identification marks and a
photograph, with a copy to the Board/Committee, District Child Protection Unit and other
authorities concerned;(b)The Superintendent of institutions other than shelter homes or
drop-in-centre shall send the guards or concerned staff in search of the juvenile, at places like
railway stations, bus stands and other places where the juvenile is likely to go;(c)The parents or
guardians, if any, shall be informed immediately about such escape;and(d)The Superintendent of
the institution other than a shelter home or drop-in-centre shall hold an inquiry about such escape
and send his report to the Board or Committee and the authorities concerned and the report shall be
placed before the Management Committee set up under Rule 62 of these rules in the next meeting
for review.(3)The offences against a juvenile in conflict with law or a child specified in Sections 23,
24, 25 and 26 shall be either bailable or non-bailable besides being cognizable under the provisions
of the Code of Criminal Procedure, 1973 (2 of 1974) and the procedures shall apply on the Police, the
Board and the concerned authorities and functionaries accordinglyChapter  IV Child In Need Of
Care And Protection
20. Child Welfare Committee.
- There shall be a Child Welfare Committee in every district, which shall be constituted by the State
Government through a notification in the Official Gazette as per sub-Section (1) of Section 29 of the
Act.
21. Composition of the Child Welfare Committee.
(1)The Committee shall consist of a Chairperson and four other members, from the district
concerned, of whom at least one shall be a woman and one from among the members belonging to
SC/ST communities.(2)The Chairperson and members of the Committee shall be appointed on the
recommendation of a Selection Committee set up by the State Government, for the purpose under
Rule 89.(3)The Selection Committee, while selecting the Chairperson and Members of the
Committee, shall ensure that none of them are from any voluntary organization running specialized
adoption agency or child care institution or Child line.(4)The State Government shall provide for
such training and orientation in child psychology, child welfare, child rights, socialization and
rehabilitation, national and international standards for child protection or juvenile justice and the
relevant legal system to the Chairperson and all the members of the Committee as it considers
necessary.Bihar Juvenile Justice (Care and Protection of Children) Rules, 2015

22. Tenure of the Committee.
(1)The Committee shall have a tenure of three years and the tenure of Chairperson and Members
shall be co-terminus with the tenure of the Committee.(2)The Chairperson and a member of the
Committee may be eligible for re-appointment for a maximum of two consecutive
terms.(3)Extension of the tenure of members of the Committee shall be on the basis of their
performance appraisal by the District Child Protection Unit or the State Government and on the
recommendation of the Selection Committee.(4)With a view to ensuring continuity on completion of
the tenure of a Committee, the State Government shall constitute a new Committee before the
expiry of the term of the existing Committee; where after the existing Committee shall handover all
records and information to the newly formed Committee.(5)The Chairperson and Members may
resign at any time by giving one month's notice in writing or may be removed from office as
provided in sub-Section (4) of Section 29 of the Act.(6)Any casual vacancy in the Committee may be
filled by appointment of another person from the panel of names prepared by the Selection
Committee, and shall hold office for the remaining term of the Committee.
23. Qualifications for Chairperson and Members of the Committee.
(1)A person to be selected as a Chairperson or Member of the Committee shall be a person not less
than 30 years of age and not more than 65 years of age and have either of the following
qualifications, in addition to a minimum of five years experience and engaged in planning,
implementing or administering measures relating to health, education, child rights and other
development activities related to children preferably:-(i)A post-graduate degree in social
work/psychology/child development/education/ sociology/law/criminology or in any social science
discipline.(ii)In case suitable candidates having minimum qualifications as per (i) are not available
in the district, Selection Committee can recommend candidates having (a) graduate degree in
subjects mentioned in sub para (1) and experience for at least five years;(iii)A teacher, doctor or
retired government servant who has been involved in work related to children.(2)Amongst
shortlisted members, a person with higher educational qualification and experience will be selected
as Chairperson of the Committee.(3)No person shall be considered for Selection as a Chairperson or
Member of the Committee, if he,(i)has a previous conviction record;(ii)has been involved in any
immoral act or in an act of child abuse or employment of child labour;(iii)is holding such full-time
occupation that may not allow him to give necessary time and attention to the work of the
Committee as per the Act and these rules;(iv)does not fulfill the qualification and experience
prescribed in the Act and the rules made there under, and in such a case the Selection Committee
shall after due inquiry and on establishment of such fact, reject his application and recommend the
name of the next person from the list of names prepared for filling the vacancies.(4)No two
members shall be in consanguineous or conjugal relationship.
24. Sitting and conveyance allowances.
- The Chairperson and Members of the Committee shall be paid such travel and sitting allowance, as
the State Government may determine.Bihar Juvenile Justice (Care and Protection of Children) Rules, 2015

25. Sitting of the Committee.
(1)The Committee shall hold its sittings in the premises of the Children's Home or, at a place in
proximity to the Children's Home or, at a suitable premise in any institution running under the
Act.(2)On receiving information about child or children in need of care and protection, if
circumstances are such that the child or children cannot be produced before the Committee, the
Committee may move out to reach the child or children and hold its sitting at a place that is
convenient for such child or children.(3)The premises where the Committee holds its sittings shall
be child-friendly and shall not look like a court room in any manner whatsoever; for example, the
Committee shall not sit on a raised platform and the sitting arrangement shall be uniform and there
shall be no witness boxes.(4)The Committee shall meet at least a minimum of three days a week,
which may be extended by the State Government depending on case and pendency of work.(5)A
minimum of three-fourth attendance of the Chairperson and Members of the Committee is
necessary in a year.(6)Every member of the Committee shall attend a minimum of five hours per
sitting during the official working hours which may be extended by the state government depending
on the pendency of the work.
26. Functions and Powers of the Committee.
- The Committee shall perform the following functions to achieve the objectives of the Act,
namely:-(a)Take cognizance of and receive child produced before the Committee;(b)Decide on the
matters brought before the Committee at the earliest ;(c)Reach out to such children in need of care
and protection who are not in a position to be produced before the Committee, being in difficult
circumstances, with support from the District Child Protection Unit or State Child Protection
Society/Unit or the State Government;(d)Conduct necessary inquiry on all issues relating to and
affecting the safety and well being of the child;(e)Direct the Child Welfare Officers or Probation
Officers or non-governmental organizations to conduct social inquiry and submit a report to the
Committee;(f)Prepare individual care plan for the children;(g)Ensure necessary care and protection
to the child, including immediate shelter;(h)Ensure appropriate rehabilitation and restoration,
including passing necessary directions to parents or guardians or fit persons or fit institutions in this
regard, in addition to follow-up and coordination with District Child Protection Unit or State
Adoption Resource Agency and other agencies;(i)Direct the Superintendent of children's
home/shelter homes/open shelters/drop-in centres to receive children requiring shelter and
care;(j)Document and maintain detailed case record along with a case summary of every case dealt
by the Committee;(k)Ensure a child-friendly environment for children;(l)Recommend 'fit
institutions' to the State Government for the care and protection of children;(m)Declare 'fit persons'
for temporary period for specific cases;(n)Declare a child legally free for adoption;(o)Keep
information about and take necessary follow-up action in respect of missing children in their
jurisdiction;(p)Maintain liaison with the Board in respect of cases needing care and
protection;(q)Visit each institution where children are kept and sent for care and protection and
specialized adoption agency at least once in three months to review the condition of children in
institutions, with support of the State Government and suggest necessary action;(r)Monitor
associations and agencies within their jurisdiction that deal with children in order to check the
exploitation and abuse of children;(s)Co-ordinate with the Education, Health, Police, LabourBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

Department and other agencies involved in the care and protection of children with the support of
District Child Protection Unit or State Child Protection Unit or State Government;(t)Liaison and
network with the corporate sector and non-governmental organisations for any of the above,
including for social inquiry, restoration and rehabilitation, as and when required; and(u)Maintain a
suggestion box to encourage inputs from children and adults alike and take necessary action.(v)The
Committee may, with the help of District Child Protection Unit or any NGO, maintain a list of
various governmental, non-governmental, corporate and community agencies for facilitating the
rehabilitation and social reintegration of the child;(w)Liaison with Committees in other districts and
other concerned bodies to facilitate speedy inquiry and restoration or rehabilitation of the
child;(x)Prepare and send monthly report about child and any other related matter as and when
required, to the District Child Protection Unit and the State Child Protection Unit;(y)The CWC can
issue order to the local authority to issue the birth certificate of the abandoned child after
conducting necessary enquiries;(z)Any other function assigned by the State Government from time
to time relating with children in need to care and protection.
27. Procedure in relation to Committee.
(1)The quorum for the meeting shall be three members attending, which may include the
Chairperson.(2)Any decision taken by an individual member, when the Committee is not sitting,
shall require ratification by the Committee in its next sitting.(3)The Committee shall send a copy of
every order passed by it to the District Child Protection Unit for necessary compliance and
follow-up.(4)The Committee shall take into consideration the age, developmental stage, physical
and mental health, opinion of the child and the recommendation of the child welfare officer or
caseworker, prior to disposal of cases.(5)For final disposal of a case, the order of the Committee
shall be signed by at least two members, including the Chairperson.
28. Production of a Child before the Committee.
(1)A child in need of care and protection shall be produced before the Committee within twenty-four
hours, excluding journey time, by one of the following persons-(a)any police officer or Special
Juvenile Police Unit or a designated police officer;(b)any public servant;(c)Child line, a registered
voluntary organization or by such other voluntary organization or an agency as may be recognized
by the State Government;(d)social worker;(e)any public spirited citizen; or(f)by the child
himself.(2)Whenever the above mentioned person/s takes charge of child in need of care &
protection, the information shall be given to the police station or Child line as soon as possible,
giving details of child, the situation from which rescued, the time at which the person took charge of
the child including the place. The person taking charge of the child shall also give his details like
name, address and organization for which he is working and other relevant details of members of
rescue team.(3)In case of a child under two years of age, who is medically unfit, the person or the
organization shall send a written report along with the photograph of the child to the Committee
within twenty-four hours and produce the child before the Committee as soon as the child is
medically fit along with a medical certificate to that effect.(4)The Committee can suo motu take
cognizance of cases brought to its notice and reach out to a child in need of care and protection
where necessary and the District or the State Child Protection Unit or the State Government shallBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

provide necessary support and assistance to the Committee for carrying out such functions.(5)In
case the Committee is not sitting, the child may be produced before the single member of the
Committee as per the provisions laid down under sub-Section (2) of Section 30 of the Act for being
placed in safe custody of parent or guardian or fit person or fit institutions, as the case may be, till
such time that the child can be produced before the Committee.(6)In case the single member is also
not accessible, or that the hours are odd, the child shall be taken by any non-governmental
organisation or Child line or Police to an appropriate institution for children registered under the
Act with all the necessary documents, and be placed in such institution till the time of production
before the Committee.(7)The concerned institution shall inform the Chairperson or a member of the
Committee about such child and produce the child before the Committee within twenty four hours
and in such cases, it may not be necessary for the person who brings a child in need of care and
protection to an institution to be present at the time of production of the child before the
Committee. If the institution is Government Children Home, the child may be produced during the
next sitting of the committee.(8)Whoever produces a child before the Committee may submit a
report on the circumstances under which the child came to their notice and efforts made by them in
informing the police and the missing persons squad and in cases where a recognized voluntary
organization or any police personnel produce a child before the Committee, they shall also submit a
report on the efforts made by them for tracing the family of the child.(9)Any general medical or
gynaecological examination of child shall not be a pre-requisite for production of the child before
the Committee or admission in an institution.(10)The Committee shall facilitate the filing of a police
complaint and First Information Report in cases of missing children as well as matters of violence,
exploitation and abuse of children and arrange for required legal aid through the Legal Officer in the
District Child Protection Unit or District or State Legal Aid Services Authority or voluntary
organizations.(11)Each Committee shall send monthly and quarterly information about children in
need of care and protection received by them to the District and State Child Protection Society/Unit
or State Government.(12)Child shall be provided a child-friendly environment during the
proceedings of the Committee.(13)The Committee shall have an empanelled list of lawyers, social
workers and mental health experts who may assist the Committee in dealing with cases of abused
children and who may also interface with the Public Prosecutor or Assistant Public Prosecutor to
facilitate legal services to the abused children, when the cases relating to such children are taken up
in regular criminal courts. As far as possible, the public prosecutor or Assistant public prosecutor
may preferably be a female in case of girl child.(14)Every possible effort shall be made to trace the
family with support from the District Child Protection Unit, and assistance of recognized voluntary
organizations, Child line or police may also be taken.(15)The Committee shall send the child to the
designated place of safety, with age and gender appropriate facilities, pending inquiry and in such
eventuality, the State Government shall provide transport or make necessary budgetary allocations
for such expenses based on the actual fare.(16)The child may be escorted by the police officer in
plain clothes or representative of the voluntary organization or by any other arrangement as
considered appropriate by the Committee with support from the District Child Protection Unit and
in case of a girl child, a female escort shall accompany the child.(17)A list of all recognized child care
institutions along with their capacity and appropriate facilities as prescribed under Section 34 of the
Act, a list of all child related resource services and a list of contact details of all Child Welfare
Committees across the country shall be provided to the Committee by State Government.(18)The
Committee may, while making an order in Form VIII placing a child under the care of a parent,Bihar Juvenile Justice (Care and Protection of Children) Rules, 2015

guardian or fit person pending inquiry or at the time of restoration, as the case may be, direct such
parent, guardian or fit person to enter into an undertaking in Form IX.(19)Whenever the Committee
orders a child to be kept in an institution, it shall forward to the Superintendent of such institution a
copy of the order of short term placement pending inquiry, in Form X with particulars of the home
and parents or guardian and previous record.(20)Whenever the Committee orders a child to be kept
in a fit institution as part of restoration under clause (f) of sub-Section (3) of Section 39 of the Act, it
shall forward a copy of its order of restoration in Form XI to the Superintendent of such
institution.(21)(a)The Committee should also satisfy that, the child has not been subjected to any
harassment either by the Police or by any other person, who takes charge of the child for the
purpose of bringing before the Child Welfare Committee.(b)The Committee may release the child to
the care of parents/guardian with without surety till such time the final disposition in made.(c)The
Committee shall conduct the proceeding in an informal way to ensure that child's interest is of
paramount importance.(d)The Committee shall initiate action against any media for publishing any
matter relating to the children in need of care and protection, which would affect the interest of the
child.(e)The Committee shall enquire the child in need of care and protection and shall record the
statements in accordance with the procedure as laid down in the Code of Criminal Procedure,
1973.(f)The Committee shall, if at any stage during the course of the enquiry is satisfied that the
attendance of the child is not essential for the purpose of enquiry, dispense with his attendance and
proceed with the enquiry in the absence of child.(22)The child shall be placed in an institution
closest to where his parents or guardians belong as far as possible, unless the child has been
subjected to abuse or exploitation by parents or guardians.
29. Procedure for inquiry.
(1)When a child is brought before the Committee, the Committee shall assign the case to a social
worker or probation officer or case worker or child welfare officer for conducting the inquiry
through and order in Form XII.(2)The Committee shall direct the concerned person or organization
about the details or particulars to be enquired into for developing an individual care plan and
suitable rehabilitation.(3)All inquiries conducted by a probation officer or case worker or child
welfare officer shall be as per Form XIII and must provide an assessment of the family situation of
the child in detail, and explain in writing whether it will be in the best interest of the child to restore
him to his family.(4)The inquiry must be completed within four months or within such shorter
period as may be fixed by the Committee. Provided that the Committee may, in the best interest of
the child and for the reasons to be recorded in writing, extend the said period under special
circumstances.(5)After completion of the inquiry, if, the child is under orders to continue in the
children's home, the Committee shall direct the Superintendent of the home to submit quarterly
progress report of such child and produce the child before the Committee for an annual review of
the progress.
30. Children's Home.
(1)The State Government itself or in association with voluntary organizations, shall set up separate
homes for children in need of care and protection, in the manner specified below:(a)All children's
homes shall be registered as child care institutions under sub Section (3) of Section 34 of the ActBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

and rule 74 of these rules;(b)All Children's home shall be certified as per the procedure laid down in
Rule 73;(c)All children's homes shall report to the concerned Committee about every child in need
of care and protection received by them;(d)Separate children's homes shall be set up for boys and
girls in the age group 06 to 18 years;(e)Every children's home shall include separate facilities for
children in the age group of 0-5 years with appropriate facilities for the infants;(f)Children in the
age group of 6 to 18 years shall be further segregated into three groups of 6 to 10 years, 11 to 15 years
and 16 to 18 years.(2)Each children's home shall be a comprehensive child care centre with the
primary objective to promote an integrated approach to child care by involving the community and
local Non-Governmental Organizations through the Management Committee set up under Rule 56
of these rules and the District Child Protection Unit or State Child Protection Society/Unit or the
State Government shall make an annual performance review of functioning of the children's homes
run by the state government or by any recognized voluntary organization, besides the regular
reviews.(3)The activities of such centre shall focus on:(a)preparing and following individual care
plans for every child, with rights based approach, specifically addressing the child's physical and
mental health, emotional needs, education, skill development, protection and special needs if
any;(b)family based non-institutional services, such as, foster family care, adoption and
sponsorship;(c)specialized services in situations of conflict or disaster and for juvenile or children
affected by terminal or incurable disease to prevent neglect by providing family counselling,
nutrition, health interventions, psycho-social interventions and sponsorship;(d)emergency outreach
service through child line (toll free Help Line no. 1098);(e)linkages with Integrated Child
Development Services to cater to the needs of children below six years;(f)linkages with organizations
and individuals who can provide support services to children;(g)opportunities to volunteers willing
to provide various services for children;(h)ensure that the child develop positive attitudes towards
the family and creates a linkage with family; and arrange group counselling
31. Shelter Home.
(1)For children in urgent need of care and protection, such as street children and run-away children,
the State Government shall support creation of requisite number of shelter homes or drop-in-
centres (open shelters) through the voluntary organizations.(2)Shelter homes shall
include:(a)short-stay homes for children needing temporary shelter, care and protection for a
maximum period of one year,(b)transitional facilities for providing immediate care and protection
to a child for a maximum period of four months,(c)24 hour drop-in-centres running for children
needing day care or night shelter facility.(3)The shelter homes or drop-in-centres shall have the
minimum facilities of boarding and lodging, besides the provision for fulfillment of basic needs in
terms of clothing, food, health care and nutrition, safe drinking water and sanitation.(4)There shall
be separate shelter homes for girls and boys as per Rule 41(2)(d) of these rules.(5)All shelter homes
shall provide requisite facilities for education, vocational training, counselling and recreation or
make arrangements for it in collaboration with voluntary organisations or corporate sector.(6)The
Committee, Special Juvenile Police Unit, public servants, Child Line, voluntary organizations, social
workers and the children themselves may refer a child to such shelter homes.(7)All shelter homes
shall submit a report of children using the shelter home facility along with a photograph of the child
to the Committee, the missing persons bureau or special juvenile police unit and the District Child
Protection Unit or the State Child Protection Unit.(8)The services of officer-in-charge, child welfareBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

officer, social worker shall be provided for the proper care, protection, development, rehabilitation
and reintegration needs of children in shelter homes.(9)No child shall ordinarily stay in a shelter
home for more than a year except in special circumstances with the approval of the Committee.
32. Guidelines for prevention of sexual abuse of children.
- The State Government, the Juvenile Justice Board, the Child Welfare Committee, other competent
authorities and agencies shall, in the best interest of children, ensure that every person, school or
such other educational institutions abide by the guidelines issued from time to time by Central
Government and state Government.Chapter  V Rehabilitation And Social Reintegration
33. Rehabilitation and Social Reintegration.
- The primary aim of rehabilitation and social reintegration is to help children in restoring their
dignity and self-worth and mainstream them through rehabilitation within the family where
possible, or otherwise through alternate care programmes and long-term institutional care shall be
of last resort.
34. Adoption.
(1)The primary aim of adoption is to provide a child who cannot be cared for by his biological
parents with a permanent substitute family.(2)For all matters relating to adoption, the guidelines
issued by the Central Adoption Resource Authority and notified by the Central Government under
sub-Section (3) of Section 41 of the Act, shall apply.(3)In case of orphaned and abandoned children
the following procedure shall apply, namely:-(a)Wherever a Specialized Adoption Agency receives
an abandoned child, it shall, within twenty four hours inform the matter to the police
station.(b)Specialized Adoption Agencies shall produce all orphaned and abandoned children who
are to be declared legally free for adoption before the Committee within twenty-four hours of
receiving such children, excluding the time taken for journey;(c)A child becomes eligible for
adoption when the Committee has completed its inquiry and declares the child legally free for
adoption;(d)Such declaration shall be made in Form XIV;(e)A child must be produced before the
Committee at the time of declaring such child legally free for adoption;(f)Whenever intimation is
received by the police about an abandoned infant, the police shall take charge of the infant and
arrange to provide immediate medical assistance and care;(g)Subsequently, the child shall be placed
in a specialized adoption agency or recognized and certified children's home or in a paediatric unit
of a Government hospital followed by production of the child before the Committee within twenty
four hours;(h)Carry out procedure for declaring a child abandoned and certifying him legally free for
adoption:-(i)in case of an abandoned child, the recognized agency shall within twenty four hours,
report and produce the child before the Committee with the copy of the report filed with the police
station in whose jurisdiction the child was found abandoned;(ii)the Committee will institute a
process of inquiry, which shall include a thorough inquiry conducted by the Probation Officer or
Child Welfare Officer, as the case may be and who shall give report in Form XIII to the Committee
containing the findings within one month;(iii)there shall be a declaration by the specialized
adoption agency, stating that there has been no claimant for the child even after making notificationBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

in at least one leading national newspaper and one regional language newspaper for children below
two years of age and for children above two years, an additional television or any other prevalent
mode or radio announcement and notification to the missing persons squad or bureau shall be
made;(iv)the steps stated in (iii) shall be taken within a period of sixty days from the time when the
child is found in case of a child below two years of age and in case of children above two years of age,
this period shall be four months;(v)the period of notification shall run concurrently with the inquiry
to be conducted and report submitted under clause (ii) of this sub-rule;(vi)The Committee shall
declare the child legally free for adoption on completion of the process of inquiry, including
declaration of the specialized adoption agency made under clauses (ii) and (iii) of this
sub-rule;(vii)No child above seven years who can understand and express his opinion shall be
declared free for adoption without his consent recorded before Child Welfare Committee.(4)In case
of surrendered child the following procedure shall apply, namely:-(a)A surrendered child is one who
had been declared as such after due process of inquiry by the Committee and in order to be declared
legally free for adoption, a 'surrendered' child shall be any of the following:(i)born as a consequence
of non-consensual relationship;(ii)born of an unwed mother or out of wedlock;(iii)a child in whose
case one of the biological parents is dead and the living parent is incapacitated to take care;(iv)a
child where the parents or guardians are compelled to relinquish him due to physical, emotional and
social factors beyond their control;(b)serious efforts shall be made by the Committee for counselling
the parents, explaining the consequences of adoption and exploring the possibilities of parents
retaining the child and if, the parents are unwilling to retain, then, such children shall be kept
initially in foster care or arranged for their sponsorship;(c)if the surrender is inevitable, a deed of
surrender in Form XV shall be executed on a non-judicial stamp paper in the presence of the
Committee.(d)the adoption agencies shall wait for completion of two months reconsideration time
given to the biological parent or parents after surrender;(e)in case of a child surrendered by his
biological parent or parents, the document of surrender shall be executed by the parent or parents
before the Committee;(f)after due inquiry, the Committee shall declare the surrendered child legally
free for adoption in Form XIV as the case may be after a sixty days' reconsideration period as per
Central Adoption Resource Agency guidelines.(5)For the purposes of Section 41 of the Act, 'court'
implies a civil court, which has jurisdiction in matters of adoption and guardianship and may
include the court of the district judge, family courts and civil court.
35. Foster Care.
(1)For children who cannot be placed in adoption, order shall be issued by the competent authority
in Form XVII for carrying out foster care, as given in sub-Section (2) of Section 42 of the Act under
the supervision of a probation officer or case worker or social worker, as the case may be, and the
period of foster care shall depend on the need of the child.(2)State Government shall design its own
foster care programme or adopt any guideline or programme or scheme as may be prescribed or
notified by the central government so as to reduce institutionalisation of children and enable a
nurturing family environment for every child.(3)The State Government shall consult the Boards or
Committees, non-governmental organizations, academicians and organizations working on
alternative care for children in developing the foster care programme.(4)De-institutionalisation of
children and placing them in foster care shall be made with the concurrence of the Child Welfare
Committee.Bihar Juvenile Justice (Care and Protection of Children) Rules, 2015

36. Criteria for selection of families for foster care.
(1)In case of the children covered under Rule 35 of these rules, the following criteria shall apply for
selection of families for foster care, namely:-(a)foster parents should have stable emotional
adjustment within the family;(b)foster parents should have an income in which they are able to
meet the needs of the child and are not dependent on the foster care maintenance payment;(c)the
monthly family income shall be adequate to take care of foster children and approved by the
Committee;(d)medical reports of all the members of the family residing in the premises should be
obtained including checks on Human Immune Deficiency Virus (HIV) and Hepatitis B to determine
that they are medically fit;(e)the foster parents should have experience in child caring and the
capacity to provide good child care;(f)the foster parents should be physically, mentally and
emotionally stable;(g)the home should have adequate space and basic facilities;(h)the foster care
family should be willing to follow rules laid down including regular visits to paediatrician,
maintenance of child health and their records;(i)the family should be willing to sign an agreement
and to return the child to the specialized adoption agency whenever called to do so;(j)the foster
parents should be willing to attend training or orientation programmes;(k)the foster parents should
be willing to take the child for regular (at least once a month in the case of infants) checkups to a
paediatrician approved by the agency; and(l)Single parents cannot be given foster care of children of
the opposite sex, having age difference less than 20 years.(2)There shall be no discrimination in
selection of foster-parents on the basis of caste, religion, ethnic status, disability, or health status
and the best interest of the child shall be paramount in deciding foster care placement.(3)The foster
parents shall be declared 'fit persons' by the Committee before placing the child as per the
provisions laid down in clause (i) of Section 2 of the Act after thorough assessment done by the
Child Welfare Officer or Social Worker as per Form XVI.
37. Pre-adoption Foster Care.
- In case of pre-adoption foster care, the provisions contained in sub-Section (1) of Section 42 and
the corresponding guidelines notified under Subsection (3) of Section 41 of the Act, shall apply.
38. Sponsorship.
(1)The State Government shall prepare sponsorship programme in consultation with the Non
Governmental Organizations, Child Welfare Committees, other relevant government agencies and
the corporate sector.(2)The State Government, with the help of District or State Child Protection
Society/Unit shall identify families and children at risk and provide necessary support services in
the form of sponsorship for child's education, health, nutrition and other developmental
needs.(3)The children's homes and special homes shall promote sponsorship programmes as laid
down in Section 43 of the Act.(4)The institutions receiving sponsorship, shall maintain proper and
separate accounts of all the receipts and payments for the programme.(5)The Board or the
Committee shall make an order in Form XVIII for support to a juvenile or child through
sponsorship and send a copy to the District or State Child Protection Unit or the State Government
for appropriate action.Bihar Juvenile Justice (Care and Protection of Children) Rules, 2015

39. After Care Organisation.
(1)The state Government shall set up an after care programme for care of juveniles or children after
they leave special homes and children's homes with the objective to facilitate their transition from
an institution-based life to mainstream society for social re-integration.(2)After care programmes
shall be made available for persons up to age group of 18-21 years, who have no place to go to or are
unable to support themselves, for the purpose of Section 44 of the Act and this rule.(3)Once the
Board or the Committee passes an order in Form XIX for placing a juvenile or a child completing 18
years of age under the after care programme, a copy of such order shall be sent to the District and
the State Child Protection Unit and the Director of Social Welfare, who shall be responsible for
arranging aftercare. A copy of information shall be made available to the superintendent of the
concerned home.(4)The Board of the Committee shall have jurisdiction over persons placed in after
care programme.(5)The objective of these organizations shall be to enable such children to adapt to
society and during their stay in these transitional homes these children will be encouraged to move
away from an institution based life to a normal one.(6)All juveniles or children enrolled into an after
care programme must be considered a beneficiary in all appropriate schemes and programmes run
by the state government on priority basis.(7)The key component of the programme shall
include:-(a)community group housing on a temporary basis for groups of young persons aged 18-21
years;(b)imparting vocational training, job oriented training and encouragement to contribute
towards the rent or other expenses of the accommodation and maintenance;(c)encouragement to
gradually sustain themselves without state support and move out of the group home to stay in a
place of their own after saving sufficient amount through their earnings;(d)provision for a peer
counsellor to stay in regular contact with these groups to discuss their rehabilitation plans and
provide creative outlets for their energy and to tide over crisis periods in their life.(8)Loans may be
arranged for the youth in an after care programme aspiring to set up entrepreneurial activities on
the basis of an application made by them and after due verification of the need for such a loan, and
necessary professional advice and training shall be made available to the youth in the after care
programme in this regard.(9)The After Care Organization shall facilitate for the issuance of the
documents such as Voter's ID Card, Aadhar card, Bank Savings Account, Residence Certificate, etc.
in the name of the person enrolled into the after care programme.
40. Linkages and co-ordination.
(1)The State government shall establish effective linkages between various government, non
government, corporate and other community agencies for facilitating the rehabilitation and social
reintegration of juvenile or children through the Board or the Committee as the case may be.(2)The
Government shall identify the roles and responsibilities of each department at State or district levels
for effective implementation of the Act and the rules and inform them through a notification.(3)The
State Government shall arrange for appropriate training and sensitization of functionaries of these
departments from time to time in coordination with any appropriate agency.(4)The State
Government through State or District Child Protection Unit shall develop effective networking and
linkages with local non-governmental organizations for specialized services and technical assistance
like vocational training, education, health care, nutrition, mental health intervention, drug
de-addiction, legal aid services etc.(5)Voluntary participation of organization of retired persons,Bihar Juvenile Justice (Care and Protection of Children) Rules, 2015

social workers, health, personnel shall be encouraged, to organize workshops, cultural programme,
sports, camps counselling and recreational services.Chapter  VI Standards Of Care And
Institutions
41. Physical infrastructure.
(1)The homes for juveniles in conflict with law and children in need of care and protection shall
function from separate premises.(2)The accommodation in each institution shall be as per the
following criteria, namely:-(a)Observation Home or Place of Safety:(i)Separate observation homes
for girls and boys;(ii)Classification and segregation of juveniles according to their age group
preferably 7-11 years, 12-15 years and 16-18 years, giving due consideration to physical and mental
status and the nature of the offence committed.(b)Special Home:(i)Separate special Home for girls
above the age of 10 years and boys with further segregation in the age group of 11 to 15 and 16 to 18
years;(ii)Classification and segregation of juveniles on the basis of age and nature of offences and
their mental and physical status.(iii)The State Government shall notify a 'Place of Safety' to
accommodate juveniles who have been referred by the Board under Section 16 of the Act, in such
manner as prescribed from time to time.(c)Children's Home:(i)Separate facilities for children in the
age group of 0-5 years with appropriate facilities for infants.(ii)Separate children's homes for boys
and girls in the age group of 6 to 18 years with a further classification and segregation of girls and
boys in the age group of 6 to 10 years, 11 to 15 years and 16 to 18 years;(d)Shelter Home:(i)Separate
shelter homes for girls and boys;(ii)Classification and segregation of girls and boys in the age group
of 6 to 10 years, 11 to 15 and 16 to 18 years.(3)The building or accommodation for an institution with
50 juveniles or children may include space for:-(i)2 Dormitories or living room,(ii)2
Classrooms,(iii)Sickroom/First aid room,(iv)Kitchen and Dining Hall, Store(v)Recreation room or
hall, Library,(vi)Bathrooms, toilets/latrines,(vii)Counselling and guidance room(viii)Office
rooms,(ix)Superintendent's room,(x)Workshop,(xi)Residence for Superintendent,(xii)Rooms for
Juvenile Justice Board/Child Welfare Committee,(xiii)Play ground of sufficient area according to
the total number of juveniles or children.(4)The Superintendent shall stay within the institution and
will be provided with quarters and in case he is not able to stay in the home for legitimate reasons
(prior written permission of Director, Social Welfare shall be obtained) and in such case any other
senior staff member of the in situation shall stay in the institution and be in a position to supervise
the overall care of the children or juvenile and, take decisions in the case of any crisis or
emergency.(5)(i)the standards of accommodation as per the norms laid down in Rule 41(3) shall be
observed to the extent possible and shall include a minimum of following facilities:(a)Dormitory or
living rooms: 40 Sq. ft. per juvenile or child.(b)Toilet and bathrooms: at least one for every 8
children.(c)Classroom: 300 Sq. ft for each classroom for 25 children.(d)Sickroom/First aid room:
375 Sq. ft for each room.(e)Workshop: 75 Sq. ft. per juvenile or child.(f)Play ground: Sufficient play
ground area shall be provided in every institution according to the total number of juveniles in
institution(ii)there shall be proper and smooth flooring for preventing accidents;(iii)There shall be
adequate lighting, ventilation, heating and cooling arrangements, safe drinking water and clean
toilets, in terms of gender, age appropriateness and accessibility to persons with disability.(iv)All
institutions under the Act shall make provision of first aid kit, fire extinguishers in kitchen,
dormitories, store rooms, counselling room, periodic review of electrical installations, proper
storage and inspection of articles of food stuffs, stand-by arrangements for water storage andBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

emergency lighting.(6)The Observation Homes and Special Homes shall be child-friendly and in no
way shall they look like a jail or lock-up.
42. Clothing and Bedding.
- The clothing and bedding shall be as per the scale and climatic conditions. The requirements of
each juvenile or child and the minimum standards for clothing and bedding are laid down in
Schedule-I of these rules (The State Government may make changes in minimum standard as per
the needs of a child or a juvenile).
43. Sanitation and Hygiene.
- Every institution shall have the following facilities, namely:-(a)sufficient treated drinking water;
water filters shall be installed;(b)sufficient water for bathing and washing clothes, maintenance and
cleanliness of the premises;(c)proper drainage system;(d)arrangements for disposal of
garbage;(e)protection from mosquitoes by providing mosquito nets;(f)annual pest
control;(g)sufficient number of well lit and airy toilets and bathrooms in the proportion of at least
one for 8 children;(h)sufficient space for washing;(i)clean and fly proof kitchen and separate area
for washing utensils;(j)sunning of bedding and clothing;(k)maintenance of cleanliness in the sick
room/ first aid room/Medical Centre.
44. Daily Routine.
(1)Every institution shall have a daily routine for the juveniles or children developed in consultation
with the Children's Committees, which shall be prominently displayed at various places within the
institution.(2)The daily routine shall provide, inter alia, for a regulated and disciplined life, personal
hygiene and cleanliness, physical exercise, yoga, educational classes, vocational training, organized
recreation and games, moral education, group activities, prayer and community singing and special
programmes for Sundays and holidays.
45. Nutrition and Diet Scale.
- The following nutrition and diet scale shall be followed by the institutions, namely:-(a)the children
shall be provided four meals in a day including breakfast;(b)the menu shall be prepared with the
help of a nutritional expert or doctor to ensure balanced diet and variety in taste as per the
minimum nutritional standard and diet scale set out in Schedule II of these rules;(c)every
institution under this Act shall strictly adhere to the minimum nutritional standard and diet scale
specified in Schedule II (The State Government may make changes in minimum standard as per the
needs of a child or a juvenile);(d)Juveniles or children may be provided special meals on holidays
and festivals;(e)Infants and sick juveniles or children shall be provided special diet according to the
advise of the doctor on their dietary requirement.Bihar Juvenile Justice (Care and Protection of Children) Rules, 2015

46. Medical Care.
- Every institution shall-(a)maintain a medical record of each juvenile or child on the basis of
monthly medical check-up and provide necessary medical facilities;(b)ensure that the medical
record includes weight and height record, any sickness and treatment, and other physical or mental
problem;(c)have arrangement for the medical facilities, including a doctor on call available on all
working days for regular medical check-ups and treatment of juveniles or children;(d)have sufficient
medical equipments to handle minor health problems including first aid kit with stock of emergency
medicines and consumables;(e)train all staff in handling first aid;(f)tie-up with local Primary Health
Centre, government hospital, medical colleges, other hospitals, clinical psychologists and
psychiatrists and mental health institutes for regular visits by their doctors and interns and for
holding periodic health camps within the institutions;(g)make necessary arrangements made for the
immunization coverage and maintain proper records in respect thereof;(h)take preventive measures
against out break of contagious or infectious diseases;(i)set up a system for referral of cases with
deteriorating health or serious cases to the nearest civil hospital or recognized treatment
centres;(j)keep sick children under constant medical supervision;(k)admit a juvenile or child
without insisting on a medical certificate at the time of admission;(l)arrange for a medical
examination of each juvenile or child admitted in an institution by the Medical Officer within twenty
four hours and in special cases or medical emergencies immediately;(m)arrange for a medical
examination of the juvenile or child by the Medical Officer at the time of transfer within twenty four
hours before transfer;(n)not carry out any surgical treatment on any juvenile or child without the
previous consent of his parent or guardian, unless either the parent or guardian cannot be found
and the condition of the juvenile or child is such that any delay shall, in the opinion of the medical
officer, involve unnecessary suffering or injury to the health of the juvenile or child, or otherwise
without obtaining a written consent to this effect from the superintendent of the
institution;(o)provide or arrange for regular counselling of every juvenile or child and ensure
specific mental health interventions for those in need of such services, including separate rooms for
counselling sessions within the premises of the institution;(p)refer such children who require
specialized drug abuse prevention and rehabilitation programme, to an appropriate centre
administered by qualified personnel where these programmes shall be adopted to the age, gender
and other specifications of the concerned child.
47. Mental Health.
(1)A mental health record of every juvenile or child shall be maintained by the concerned
institutions.(2)Both mileu-based interventions that is creating an enabling environment for children
and individual therapy are must for every child and shall be provided in all institutions.Explanation.
- For the purpose of this sub-rule, mileu based intervention is a process of recovery, which starts
through providing an enabling culture and environment in an institution so as to ensure that each
child's abilities are discovered and they have choices and right to take decisions regarding their life
and thus, they develop and identify beyond their negative experiences and such intervention has a
critical emotional impact on the child.(3)The environment in an institution shall be free from abuse,
allowing juveniles or children to cope with their situation and regain confidence.(4)All persons
involved in taking care of the juveniles or children in an institution shall participate in facilitating anBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

enabling environment and work in collaboration with the therapists.(5)Individual therapy is a
specialized process and each institution shall make provisions for it as a critical mental health
intervention.(6)Every institution shall have the services of trained counsellors or collaboration with
external agencies such as child guidance centres, psychology and psychiatric departments or similar
government and non-governmental agencies, for specialized and regular individual therapy for
every juvenile or child in the institution.(7)A mental health care plan shall be developed for every
juvenile or child by the child welfare officers in consultation with mental health experts associated
with the institution and integrated into the individual care plan of the concerned juvenile or
child.(8)The recommendations of mental health experts shall be maintained in every case file and
integrated into the care plan for every child.(9)All care plans shall be produced before the
Management Committee set up under Rule 56 of these rules every month and before the Child
Welfare Committee every quarter.(10)No juvenile or child shall be administered medication for
mental health problems without a psychological evaluation and diagnosis by appropriately trained
mental health professionals.
48. Education.
(1)Every institution shall provide formal, non-formal and life skill education to all juveniles or
children according to the age and ability, both inside the institution or outside, as per the
requirement.(2)There shall be a range of educational opportunities including, mainstream inclusive
schools, bridge school, open schooling, non formal education and learning and input from special
educators where needed.(3)Wherever necessary, extra coaching shall be made available to school
going children in the institutions by encouraging volunteer services or tying up with coaching
centers.
49. Vocational Training.
(1)Every institution shall provide gainful and market oriented income generating vocational training
to juveniles or children.(2)The institutions shall develop networking with recognized Institute of
Technical Instruction, Jan Shikshan Sansthan, Government and Private Organization or
Enterprises, Agencies or nongovernmental organizations with expertise or placement
agencies.(3)Superintendent of the institution shall make reasonable efforts for placement of
children of 16-18 years of age as an apprentice.
50. Recreation facilities.
(1)A provision of guided recreation shall be made available to all juveniles or children in the
institutions.(2)It shall include indoor and outdoor games, music, television, picnics and outings,
cultural programmes and library.(3)Every institution shall provide materials, toys, games in
sufficient quantity to all children for recreational activities.Bihar Juvenile Justice (Care and Protection of Children) Rules, 2015

51. Institutional Management of juveniles or children.
(1)The following procedure shall be followed in respect of the newly admitted juvenile:(a)receiving
and search. The girl juvenile or child shall be searched by a female member of the staff, and both the
girl and boy shall be searched with due regard to decency and dignity;(b)disinfection and storing of
juveniles personal belongings and other valuables, entry of belongings in a separate register;(c)bath
and haircut (unless prohibited by religion);(d)issue of toiletry items, new set of clothes, bedding and
other outfit and equipment (as per scales);(e)medical examination and treatment where necessary
and in case of every juvenile suspected to be suffering from contagious or infectious diseases, mental
ailments or addiction;(f)segregation in specially earmarked dormitories or wards or hospitals in
case of a child suffering from contagious disease requiring special care and caution;(g)attending to
immediate and urgent needs of the juveniles like appearing in examinations, interview, letter to
parents, personal problems and verification by the superintendent of age of juvenile as per order of
the Board or the Committee.(2)Every newly admitted juvenile or child shall be allotted a case
worker from amongst the probation officers or child welfare officers or professionally trained social
workers or counsellors attached to the institution or professionally trained voluntary social workers
or counsellors.(3)Every newly admitted juvenile shall be familiarized with the institution and its
functioning and shall receive orientation in the following areas:(a)personal health, hygiene and
sanitation;(b)institutional discipline and standards of behaviour, respect for elders and
teachers;(c)daily routine, peer interaction, optimum use of developmental opportunities;
and(d)rights, responsibilities and obligations within the institution.(4)The designed officer shall
enter the name of the juvenile or child in the Admission Register and allocate appropriate
accommodation facility.(5)The photograph shall also be taken immediately for records and the case
worker or probation officer or welfare officer shall begin the investigation and correspondence with
the person, the juvenile or child might have named.(6)The Superintendent shall see that the
personal belongings of the juvenile or child received by the institution is kept in safe custody and
recorded in the Personal Belonging Register and the item must be returned to the juvenile or child
when he leaves the institution.(7)The educational level and vocational aptitude of the juvenile
admitted, may be assessed on the basis of test and interview conducted by the teacher, the workshop
supervisor and other technical staff and necessary linkages may also be established with outside
specialists and community-based welfare agencies, psychologist, psychiatrist, child guidance clinic,
hospital and local doctors, open school or Jan Sikshan Sansthan.(8)A case history of the juvenile or
the child admitted to an institution shall be maintained as per Form XX, which shall contain
information regarding his social-cultural and economic background and this information may
invariably be collected through all possible and available sources, including home, parents or
guardians, employer, school, friends and community.(9)A well conceived programme of pre-release
planning and follow up of cases discharged from special homes shall be organized in all institutions
in close collaboration with existing governmental and voluntary welfare organizations.(10)In the
event of a juvenile or child leaving the institution without permission or committing an offence
within the institution, the information shall be sent by the Superintendent of the concerned
institution to the police and the family, if known; and the detailed report of circumstances along
with the efforts to trace the juvenile or child where the juvenile or child is missing, shall be sent to
the Board or the Committee, as the case may be.(11)An individual care plan for every juvenile or
child in institutional care shall be developed with the ultimate aim of the child being rehabilitatedBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

and re-integrated based on their case history, circumstances and individual needs and the individual
care plan shall be based on following guidelines:(a)the Superintendent along with the child welfare
officer or case worker, or social worker shall prepare an individual care plan for every child in an
institution within one month of his admittance as per Form XXI;(b)all care plans shall include a
plan for the juveniles or child's restoration, rehabilitation, reintegration and follow-up;(c)the care
plan shall be reviewed quarterly by the Management Committee set up under rule 62 of these rules
for appropriate development and rehabilitation including options for release or restoration to family
or sponsorship or foster care or adoption;(d)juveniles or children shall be consulted while
determining their care plan;(e)continuity of care plan shall be ensured in cases of transfer or
repatriation or restoration.
52. Prohibited Articles.
- No person shall bring into the institution the following prohibited articles, namely:(a)fire-arms or
other weapons, whether requiring license or not (like knife, blades, lathe, spears and
swords);(b)alcohol and spirit of any description;(c)bhang, ganja, opium or other narcotics or
psychotropic substances;(d)tobacco, cigarette, gutkha; or(e)any other article specified in this behalf
by the State Government by a general or special order.
53. Articles found on search and inspection.
(1)The Superintendent shall see that every juvenile received in the institution is searched, without
adversely affecting the dignity of the juvenile, his personal belongings inspected and money or any
valuables found with the juvenile is kept in the safe custody of the
Superintendent/officer-in-charge.(2)The girls shall be searched by a female member of the staff and
both the girls and boys shall be searched with due regard to decency and dignity.(3)In every
institution, a record of money, valuables and other articles and found with a juvenile shall be
maintained in the "Personal Belongings Register".(4)The entries made in the Personal Belongings
Register, relating to each juvenile, shall be read over to juvenile in the presence of a witness, whose
signature shall be obtained in token of the correctness of such entries and it shall be countersigned
by the Superintendent.
54. Disposal of articles.
- The money or valuables belonging to a juvenile received or retained in an institution shall be
disposed of in the following manner, namely:(a)on an order made by the competent authority in
respect of any juvenile, directing the juvenile to be sent to an institution, the Superintendent shall
deposit such juveniles money together with the sale proceeds in the manner laid down from time to
time in the name of the juvenile;(b)the juveniles money shall be kept with the Superintendent and
valuables, clothing, bedding and other articles, if any, shall be kept in safe custody;(c)when such
juvenile is transferred from one institution to another, all his money, valuables and other articles,
shall be sent along with the juvenile to the Superintendent of the institution to which he has been
transferred together with a full and correct statement of the description and estimated value
thereof;(d)at the time of release of such juvenile, the valuables and other articles kept in safeBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

custody and the money deposited in name of the juvenile shall be handed over to the juvenile or the
child himself or the parent or guardian, as the case may be, with an entry made in this behalf in the
register and signed by the Superintendent;(e)when a juvenile in an institution dies, the valuable and
other articles left by the deceased and the money deposited in the name of the juvenile shall be
handed over by the Superintendent to any person who establishes his claim thereto and executes an
indemnity bond;(f)a receipt shall be obtained from such person for having received such valuables
and other articles and the amount;(g)if no claimant appears within a period of six months from the
date of death or escape of such juvenile, the valuables and other articles and amount shall be
disposed of as per the decision taken by Management Committee set up under Rule 56 of the rules.
Any money shall be deposited in the Fund as described in Section 61 of the Act.
55. Maintenance of case file.
(1)The case file of each juvenile and child shall be maintained in the institution containing the
following information;(a)report of the person or agency who produced the juvenile before the
Board;(b)Superintendent's, probation officer's or child welfare officer's, counsellors and
caseworker's reports;(c)information from previous institution, if any;(d)report of the initial
interaction with the juvenile, information from family members, relatives, community, friends and
miscellaneous information;(e)source of further information;(f)observation reports from staff
members;(g)regular health status reports from Medical Officer, drug de-addiction progress reports,
progress reports vis-à-vis psychological counselling or any other mental health intervention, where
applicable;(h)Intelligence Quotient (I.Q) testing, aptitude testing, educational or vocational
tests;(i)social history;(j)summary and analysis by case-worker and Superintendent;(k)instruction
regarding training and treatment programme and about special precautions to be taken;(l)leave and
other privileges granted;(m)special achievements and violation of rules, if any;(n)quarterly progress
reports;(o)individual care plan, including pre-release programme, post release plan and followup
plan as prescribed in Form XXI;(p)leave of absence or release under supervision;(q)final
discharge;(r)follow-up reports;(s)annual photograph;(t)case history duly filled in prescribed Form
XX;(u)follow-up report of post release cases as per direction of the competent authority if any;
and;(v)remarks.(2)All the case files maintained by the institutions and the Board or Committee
shall, as far as possible, be computerized and networked so that the data is centrally available to the
State and the District Child Protection Unit and the State Government.
56. Management Committee.
(1)Every institution shall have a Management Committee for the management of the institution and
monitoring the progress of every juvenile and child, constituted through an order of the concerned
District Child Protection Unit.(2)In order to ensure proper care and treatment as per the individual
care plans, a juvenile or child shall be grouped on the basis of age, nature of offence or kind of care
required, physical and mental health and length of stay order.(3)The Management Committee shall
consist of the following persons:(i)District Child Protection Officer (District Child Protection Unit)-
Chairperson(ii)Superintendent- Member-Secretary(iii)Probation officer or child welfare officer or
Case Worker- Member(iv)District Medical Officer-Member(v)Psychologist or counsellor-
Member(vi)Workshop supervisor or Instructor in Vocation-Member(vii)Teacher-Bihar Juvenile Justice (Care and Protection of Children) Rules, 2015

Member(viii)Social Worker Member of Juvenile Justice Board or Child Welfare Committee-
Member(ix)A Juvenile or child representative from each of the Children's Committees (on a
monthly rotation basis to ensure representation of juveniles of children from all age
groups)-Member(x)A representative from senior citizen forum and/or Resident welfare Association-
Member(xi)One Non-government organization Representative-Member(4)Where voluntary
organization are involved in providing professional and technical services like education, vocational
training, psychosocial care, mental health intervention and legal aid, the Management Committee
may invite four representatives of such voluntary organization as a special invitee to the
Management Committee meetings.(5)In the district where District Child Protection Unit is not
constituted, the District Magistrate shall be the Chairperson of this committee.(6)(a)The
Management Committee shall meet as frequently as possible but at least once in every three months
to consider and review;-(i)custodial care or care in the institution, housing, area of activity and type
of supervision or interventions required;(ii)medical facilities and treatment;(iii)food, water,
sanitation and hygiene conditions;(iv)mental health interventions with the juveniles and
children;(v)individual problems of juveniles and children, provision of legal aid services and
institutional adjustment, leading to the quarterly review of individual care plans;(vi)vocational
training and opportunities for employment;(vii)education and life skills development
programmes;(viii)social adjustment, recreation, group work activities, guidance and
counselling;(ix)review of progress, adjustment and modification of residential programmes to the
needs of the juveniles and children;(x)planning post-release or post-restoration rehabilitation
programme and follow-up for a period of two years in collaboration with aftercare
services;(xi)pre-release or pre-restoration preparation;(xii)release or restoration;(xiii)post release
or post-restoration follow-up;(xiv)minimum standards of care, including infrastructure and services
available;(xv)daily routine;(xvi)community participation and voluntarism in the residential life of
children such as education, vocational activities, recreation and hobby;(xvii)oversee that all registers
as required under the Act and rules are maintained by the institution, check and verify these
registers, duly stamped and signed in the monthly review meetings;(xviii)matters concerning the
Children's Committees;(xix)any other matter which the Superintendent may like to bring up.(b)The
Superintendent shall file a quarterly progress report of every juvenile or child in the case file and
send a copy to the District Child Protection Unit and Board or Committee, as the case may be.(7)The
Management Committee shall set up a complaint and redressal mechanism in every institution and
a Children's Suggestion Box shall be installed in every institution at a place easily accessible or
rooms or dormitories of the children.(8)(a)The Children Suggestion Box, whose key shall remain in
the custody of the Chairperson of the Management committee, shall be checked every week by the
Chairperson of the Management committee or his representative from District Child Protection
Unit, in the presence of the members of the Children's Committees.(b)If there is a problem or
suggestion that requires immediate attention, the Chairperson of the Management Committee shall
call for an emergency meeting of the Management Committee to discuss and take necessary
action.(c)The quorum for conducting the emergency meetings shall be five members, including two
members of Children's Committees, Chairperson of the Management Committee, Member of Child
Welfare Committee or the Board as the case may be and the Superintendent of the institution.(d)In
the event of a serious allegation or complaint against the Superintendent of the institution, he shall
not be part of the emergency meeting and another available member of the Management Committee
shall be included in his place.(e)All suggestions received through the suggestion box and actionBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

taken as a result of the decisions made in the emergency meeting or action required to be taken shall
be placed for discussion and review in the quarterly meeting of the Management Committee.(9)A
Children's Suggestion Book shall be maintained in every institution where the complaints and action
taken by the Management Committee are duly recorded and such action and follow up shall be
communicated to the Children's Committees after quarterly meeting of the Management
Committee.(10)The Board or Committee shall review the Children's Suggestion Book at least once in
six months.
57. Children's Committees.
(1)Superintendent of every institution for juveniles or children shall facilitate the setting up of
Children's Committee for three different age group of children, viz., 6-10 years, 11-15 years and 16-18
years and these Children's Committee shall be constituted solely by children. There may be cleaning
and hygiene committee, education and vocational training committee, sports and cultural
committee, recreational committee etc.(2)Such Children's Committee shall be encouraged to
participate in following activities.-(a)improvement of the condition of the institution;(b)reviewing
the standards of care being followed;(c)preparing daily routine and diet scale;(d)developing
educational, vocational and recreation plans;(e)supporting each other in managing
crisis;(f)reporting abuse and exploitation by peers and caregivers;(g)creative expression of their
views through wallpapers or newsletters or paintings or music or theater;(h)management of
institution through the Management Committee.(3)The Superintendent shall ensure that the
Children's Committees meet every month and maintain a register for recording its activities and
proceedings, and place it before the Management Committee in their quarterly meetings.(4)The
Superintendent shall ensure that the Children's Committees are provided with essential support and
materials including stationary, space and guidance for effective functioning.(5)The local voluntary
organization or counsellor may support the Children's Committees in the following:-(a)selecting
their leaders;(b)conducting the monthly meetings;(c)developing rules for the functioning of
Children's Committees and following it;(d)maintaining records and Children's Suggestion Book and
other relevant documents;(e)any other innovative activity.(6)The Management Committee shall
seek a report from the Superintendent on the setting up and functioning of the Children's
Committees, review these reports in their quarterly meetings and take necessary action where
required.
58. Rewards and Earnings.
- The rewards to a juvenile or child, at such rates as may be fixed by the management of the
institution from time to time, shall be granted by the Superintendent as an encouragement to steady
work and good behaviour and at the time of release, the reward shall be handed over after obtaining
a receipt from the parent or the guardian who comes to take charge of the juvenile or child or
juvenile or child himself.Bihar Juvenile Justice (Care and Protection of Children) Rules, 2015

59. Visits to and communication with juveniles or children.
(1)The parents and relatives of the juveniles or children shall be allowed to visit at least twice in a
month or in special cases, more frequently at the discretion of the Superintendent as per the visiting
hours laid down by him, except where parents or relatives or guardian have been found to be
responsible for subjecting the juvenile or child to violence, abuse and exploitation.(2)The receipt of
letters by the juveniles or children of the institution shall not be restricted and they shall have
freedom to write as many letters as they like at all reasonable times and the institution shall ensure
that where parents, guardians or relatives are known, at least one letter is written by the juvenile or
children every month for which the postage shall be provided by the institution.(3)The
Superintendent may peruse any letter written by or to the juvenile or children, and may for the
reasons that he considers sufficient refuse to deliver or issue the letter and forward it to the
Committee after recording his reasons in a book maintained for the purpose.(4)The Superintendent
shall, in special circumstances or as per orders of the Board or Committee, allow a juvenile or child
to make telephonic communication with his parents or guardians or relatives.
60. Death of a juvenile or child.
- On the occurrence of any case of death or suicide in an institution the procedure to be adopted
shall be as under: -(1)In the event of an unnatural death or suicide of a juvenile or child in an
institution it is imperative for the institution to ensure that an inquest and post-mortem
examination is held at the earliest.(2)In case of natural death or due to illness of a juvenile or child,
the Superintendent shall obtain a report of the Medical Officer stating the cause of death and a
written intimation about the death shall be given immediately to the State Government, nearest
Police Station, the Board or Committee, the State Commission for the Protection of Child Rights,
District Child Protection Unit or State Child Protection Unit or any other concerned authority and
the parents or guardians or relatives of the juvenile or child.(3)Whenever a sudden or violent death
or death from suicide or accident takes place, immediate information shall be given by the case
worker or probation officer or welfare officer to the Superintendent and the Medical Officer and the
Superintendent shall immediately inform the nearest police station, Board or Committee and
parents or guardians or relatives of the deceased juvenile or child.(4)If a juvenile or child dies within
twenty four hours of his admission to the institution, the Superintendent of the institution shall
report the matter to the Officer in charge of the Police Station having jurisdiction and the District
Medical Officer or the nearest Government Hospital and the parents or guardians or relatives or
such juvenile or child without delay.(5)The Superintendent shall also immediately give intimation to
nearest Magistrate empowered to hold inquests and to the Board or as the case may be the
Committee.(6)The Superintendent and the Medical Officer at the institution shall record the
circumstance of the death of the child and send a report to the concerned Magistrate, the Officer in
charge of the police station having jurisdiction, the Committee and the District Medical Officer or
the nearest government hospital where the dead body of the juvenile or child is sent for
examination, inspection and determination of the cause of death and the Superintendent and the
Medical Officer shall also record in writing their views on the cause of the death and submit it to the
concerned Magistrate and the Officer in charge of the police station having jurisdiction.(7)The
Superintendent and the Medical Officer shall make themselves available for any inquiries initiatedBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

by the police or the Magistrate concerning the cause of death and other details regarding such
juvenile or child.As soon as the inquest is held, the body shall be handed over to the parents or
guardian or relatives or, in the absence of any claimant, the last rites shall be performed under the
supervision of the Superintendent in accordance with the known religion of the juvenile or child.
61. Abuse and exploitation of the juvenile or child.
(1)Every institution shall ensure the observance of the Protocol for prevention and protection of
children from abuse, exploitation and neglect and maltreatment within the institutions, as
prescribed by the State Government from time to time.(2)Superintendent of the institution shall
ensure that there is no abuse, neglect and maltreatment and this include the staff being aware of
what constitutes abuse, neglect and maltreatment as well as early indicators of abuse, neglect and
maltreatment and how to respond to these.(3)The following action shall be taken in the event of any
physical, sexual or emotional abuse, including neglect of juveniles and children in an institution by
those responsible for care and protection:-(i)the incidence of abuse and exploitation or any crime
must be reported by any staff member of the institution immediately to the Superintendent;(ii)when
an allegation of physical, sexual or emotional abuse comes to the knowledge of the Superintendent,
a report shall be placed before the Board or Committee, who in turn, shall order for special
investigation.(iii)the Board or Committee shall direct the local police station or Special Juvenile
Police Unit to register a case, take due cognizance of such occurrences and conduct necessary
investigations;(iv)the Board or Committee shall take necessary steps to ensure completion of all
inquiry and provide protection, legal aid as well as counselling to the juvenile or child victim;(v)the
Board or Committee shall transfer such a juvenile or child to another institution or place of safely or
fit person;(vi)in the event of any other crime committed in respect of juveniles or children in
institutions, the Board or committee shall take cognizance and arrange for necessary investigation
to be carried out by the local police station or Special Juvenile Police Unit;(vii)the superintendent of
the institution shall also inform the chairperson of the Management Committee and place a copy of
the report of the incident and subsequent action taken before the Management Committee in its
next meeting;(viii)the Board or Committee may consult Children's Committee set up in each
institution to enquire into the fact of abuse and exploitation as well as seek assistance from relevant
voluntary organizations, child rights experts, mental health experts or crisis intervention centres in
dealing with matters of abuse and exploitation of juveniles or children in an institution.
62. Mode of dealing with Child suffering from dangerous diseases or mental
health problems.
(1)When a child kept in an institution under the provisions of the Act or under care of a fit person or
a fit institution is found to be suffering from a disease or physical or mental health problems
requiring prolonged medical treatment or is found addicted to a narcotic drug or psychotropic
substance, the child shall be transferred by an order of the competent authority to an approved place
set up for the purpose for the remainder of the term for which he has to be kept in custody under the
order of the competent authority or for such period as may be certified by medical officer to be
necessary for the proper treatment of the child.(2)Where it appears to the authority ordering the
transfer of the child under sub rule (1) above that the child is cured of disease or physical or mentalBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

complaint the child is still liable to be kept in custody, order the person having charge to send to the
institution or fit person from which or from whom he was transferred or if the child's is no longer
required to be kept in home, order him to be discharged.(3)Where action has been taken under
sub-rule (1) in the case of a child suffering from an infectious or contagious disease, the authority
empowered under the sub rule before restoring the said child to his parent or to the guardian, as the
case may be, where it is satisfied that such action will be in the interest of the said child, call upon
parents or the guardian, as the case may be, to satisfy it that such parents or guardian not re-infect
the child.(4)Where there is no organization either within the jurisdiction of the competent authority,
or nearby District or State for care and protection of juveniles or children suffering from serious
psychiatric or physical disorder and infection, as required under Section 58 of the Act, the child or
the juvenile shall be referred to a suitable place or institution, as it may deem fit to cater to the
special needs of such juveniles or children.
63. Leave of absence of a juvenile or child.
(1)A juvenile or child in an institution may be allowed to go on leave of absence or released under
supervision for examination or admission, special occasions like marriage or emergencies like death
or accident or serious illness in the family.(2)While the leave of absence for short period generally
not exceeding seven days excluding the journey time may be recommended by the Superintendent,
but granting of such leave shall be by the Board or Committee.(3)The parents or guardian of the
juvenile or the Superintendent on behalf of the juvenile or child may submit an application to the
Board or Committee requesting for relieving the juvenile or child on leave, stating clearly the
purpose for the leave and the period of leave.(4)While considering the application of leave of
absence, the Board or Committee shall hear the juvenile or child or the parents or guardians of the
juvenile or child and if the Board or Committee considers that granting of such leave is in the
interest of the juvenile or child, appropriate order shall be made and the Board or Committee may
call for a report from the probation officer or child welfare officer in case the preliminary
information gathered from the juvenile or child or concerned parent or guardian is not sufficient for
the purpose.(5)While issuing orders sanctioning the leave of absence or relieving under supervision,
as the case may be, the competent authority shall mention the period of leave and the conditions
attached to the leave order, and if any of these conditions are not complied with during the leave
period, the juvenile or child may be called back to the institution.(6)The parent or guardian shall
arrange to escort the juvenile or child from and to the institution and where this is not possible, the
Superintendent may arrange to escort the juvenile or child to the place of the family and back. In
case the parents or guardian is willing to arrange escort but does not have requisite financial means,
the Superintendent shall arrange for the traveling expenses as admissible under the rules.(7)If the
juvenile or child runs away from the family during the leave period, the parent or guardian is
required to inform the Superintendent of the institution immediately, and try to trace the juvenile or
child and if found, the juvenile or child shall be brought back to the institution immediately.(8)If the
juvenile or child is not found within twenty four hours, the Superintendent shall report the matter to
the nearest police station and missing person's bureau, but no adverse disciplinary action shall be
taken against the juvenile or child and procedure laid down under the Act shall be followed.(9)If the
parent or guardian does not take proper care of the juvenile or child during the leave period or does
not bring the juvenile or child back to the institution within the stipulated period, such leave may beBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

refused on later occasions.(10)If the juvenile or child does not return to the institution on expiry of
the sanctioned leave, the Board or Committee shall refer the case to police for taking charge of the
juvenile and bring him back to the institution.(11)The period of such leave shall be counted as a part
of the period of stay in the institution and the time which elapses after the failure of a juvenile to
return to the institution within the stipulated period, shall be excluded while computing the period
of his stay in the institution.
64. Inspection.
(1)The State Government shall constitute State, District or City level inspection committee on the
recommendation of Selection Committee, constituted under Rule 89 of these rules, for a period of 3
years.(2)The inspection committee shall visit and oversee the conditions in the institutions and
appropriateness of the processes for safety, well being and permanence, review the standards of care
and protection being followed by the institutions, look out for any incidence of violation of child
rights, look into the functioning of the Management Committee and Children's Committees set up
under Rules 56 and 57 of these rules and give appropriate directions.(3)The team shall also make
suggestions for improvement and development of the institution.(4)The team shall consist of seven
members with representation from the Judiciary/State Government, local authority, the Board or
Committee, the State Commission for the Protection of Child Rights or the State Human Rights
Commission, medical and other experts, voluntary organizations and reputed social workers.(5)The
inspection shall be carried out at least once in every three months.(6)The inspection visit shall be
carried out by not less than three members.(7)The team shall visit the institutions either by prior
intimation or make a surprise visit.(8)The team shall interact with the children during the visits to
the institution, to determine their well being and uninhibited feedback.(9)The follow up action on
the findings and suggestion of the children shall be taken by all concerned authorities.(10)The
action taken report, finding and suggestions from the Inspection Committee shall be sent to the
District Child Protection Unit and the State Government.
65. Social Audit.
(1)The State Government shall monitor and evaluate the implementation of the Act annually by
reviewing matters concerning establishment of Board or Committee or Special Juvenile Police Unit
where required, functioning of Board or Committee or Special Juvenile Police Unit, functioning of
institutions and staff, functioning of adoption agencies, child friendly administration of juvenile
justice and any other matter concerning effective implementation of the Act in the State.(2)The
Social audit shall be carried out with support and involvement of organizations working in the field
of mental health, child care and protection and public accountability.
66. Restoration and Follow-up.
(1)The order for restoration of the juvenile or child shall be made by the Board or Committee on the
basis of a fair hearing of the juvenile or child and his parents or guardian, as well as on the reports of
the Probation Officers or Child Welfare Officers or non-governmental organizations directed by the
Board or Committee to conduct the home study and any other relevant document or report broughtBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

before the Board or Committee for deciding the matter.(2)The Board or Committee shall send a
copy of the restoration order along with a copy of the order for escort as per Form XXII to the
District Child Protection Unit or State Government who shall provide funds for restoration of the
juvenile or child.(3)Every restoration shall be planned for as part of the individual care plans
prepared by the case-workers or counsellors or child welfare officers or probation officer, as the case
may be, and shall be based on the review and recommendations of the Management Committee set
up under Rule 56 of these rules.(4)Besides police, the Board or Committee may seek collaboration
with non-governmental organizations to accompany juveniles or children back to their family for
restoration.(5)In case of girls, the juvenile or child shall necessarily be accompanied by female
escorts.(6)The expenses incurred on restoration of a juvenile or child, including travel and other
incidental expenses, shall be borne by the District Child Protection Unit or State Government, if
directed by the competent authority.(7)When a juvenile or child expresses his unwillingness to be
restored back to the family, the Board or Committee shall make a note of it in its records in writing
and such juvenile or child shall not be coerced or persuaded to go back to the family, particularly if
the social investigation report of the child welfare officer or probation officer establishes that
restoration to family may not be in the best interest of the juvenile or child or, if the parents or
guardians refuse to accept the juvenile or child back.(8)A follow-up plan shall be prepared as part of
the individual care plan by the Child Welfare Officers or Probation Officers or non-governmental
organizations assigned by the Board or Committee to assist in restoration of the child.(9)A quarterly
follow up report shall be submitted to the Board or Committee by the concerned Child Welfare
Officer or Probation Officer or non-governmental organization for a period of two years with a copy
to the superintendent of the institution from where the juvenile or child is restored.(10)The follow
up report shall clearly state situation of the juvenile or child post restoration and the juveniles or
child's needs to be met by State Government in order to reduce further vulnerability of the juvenile
or child.(11)The Superintendent shall file the follow up report in the case-file of the juvenile or child
and place the report before the Management Committee set up under Rule 56 of these rules in its
next meeting.(12)The Superintendent shall also send a copy of the follow up reports to the District
Child Protection Unit.(13)Where a follow up in not possible due to unavailability of government
functionaries or non-governmental organizations, the concerned District Child Protection Unit shall
provide necessary assistance and support to the concerned Board or Committee.
67. Visitor's Book.
(1)A Visitor's Book shall be maintained, in every institution, in which the person visiting the home
shall record the date of his visit with remarks or suggestions, which he may think proper.(2)The
Superintendent shall forward a copy of every such entry to the District Child Protection Unit or
Director of Social Welfare, with such remarks as he may desire to offer in explanation or otherwise;
and thereon, the designated authority shall issue such orders as he may consider necessary.
68. Maintenance of Registers.
- The Superintendent shall maintain in his office, registers and forms, as required by the Act and as
specified by these rules made thereunder and the list of registers or files or books to be maintained
shall minimally comprise of,-(a)Admission and discharge register;(b)SupervisionBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

register;(c)Medical file or medical report;(d)Nutrition diet file;(e)Stock register;(f)Log
book;(g)Order book;(h)Meeting book;(i)Cash book;(j)Budget statement file;(k)Inquiry report
file;(l)Individual case file with individual care plan;(m)Children's suggestion book;(n)Visitor's
book;(o)Staff movement register;(p)Personal belongings register;(q)Minutes register of
Management Committee;(r)Minutes register of Children's Committees;(s)Attendance register for
staff and juveniles or children;(t)complaint & action taken report register; and(u)rewards &
punishment register of inmates.
69. Personnel or Staff of a Home.
(1)The personnel strength of a home and the number of posts in each category shall be determined
by the State Government.(2)The institutional organizational set up shall be fixed in accordance with
the size of the home, the capacity, workload, distribution of functions and requirements of
programmes.(3)The whole-time staff in a home may consist of Superintendent, Probation Officer (in
case of Observation home or Special home), Case Workers (in case of Children's home or shelter
home or after care organization), Counsellor, Educator, Vocational Training Instructor, Medical
Staff, Administrative staff, Care Takers, volunteers, store keeper, cook, helper, washerman, safai
karamchari, gardener as required.(4)The part-time staff, shall include Psychiatrist, Psychologist,
Occupational therapist, and other professionals as may be required from time to time.(5)The staff of
the home shall be subject to control and overall supervision of the Superintendent who by order,
shall determine their specific responsibilities and shall keep the concerned authority informed of
such orders made by him from time to time.(6)The duties and responsibilities of the staff under the
Superintendent shall be fixed in keeping with the statutory requirements of the Act.(7)The staff shall
be appointed in accordance with the rules prescribed by the State Government.(8)The suggested
staffing pattern for an institution with a capacity of 50 juveniles or children could be as mentioned
below:-
Sl. Staff/Personnel No. of Posts
1 Officer-in-Charge (Superintendent) 1
2 Counsellor 1
3 Probation Officer or Case Worker 1
4 House Mother or House Father (one for every 25children) 2
5 Educator (voluntary or part time) 1
6 PT Instructor cum Yoga Trainer (voluntary orpart time) 1
7 Doctor (voluntary or part time) 1
8 Art and Craft-cum- Music Teacher (voluntary orpart time) 1
9 Paramedical staff 1
10 Store-keeper cum Accountant 1
11 Cook 1
12 Helper 1
13 Housekeeping staff 2Bihar Juvenile Justice (Care and Protection of Children) Rules, 2015

14 Security Guards 3
Total 18
(9)In case of institutions housing infants or children up to 12 years of age or physically or mentally
challenged ones provision for ayahs and paramedical staff shall be made as per the need.
70. Duties and responsibilities of Superintendent of an institution.
(1)The Superintendent shall have the primary responsibility of maintaining the institution and shall
stay within the institutional premises to be readily available as and when required by the juvenile or
children and the staff and in case where an accommodation is not available within the institutional
premises, the Superintendent shall stay at a place in close proximity to the institution till such time
that such an accommodation is made available within the institution.(2)The general duties and
functions of the Superintendent shall include:(a)compliance with provisions of the Act and the rules
and orders made there under;(b)compliance with the orders of the Board or Committee;(c)providing
homely atmosphere of love, affection, care, development and welfare for juveniles or
children;(d)maintaining minimum standards of care in the institution.(e)proper maintenance of
buildings and premises;(f)security measures and periodical inspection, including daily inspection
and rounds of the institution, proper storage and inspection of food stuffs as well as food being
served;(g)supervision and monitoring of juveniles or children's discipline and well
being;(h)planning, implementation and coordination of all institutional activities, programmes and
operations, including training and treatment programmes or correctional activities as the case may
be;(i)prompt action to meet emergencies including regular fire drills and evacuation
plan;(j)ensuring accident and fire preventive measures within the institutional premises;(k)stand by
arrangements for water storage, power plant, emergency lighting;(l)careful handling of plants and
equipments;(m)segregation of a juvenile or child suffering from contagious or infectious
diseases;(n)observance and follow up of daily routine;(o)filling of monthly report of juvenile or child
in the case file;(p)organize local and national festivals in the institution;(q)organize recreational
activities including trips or excursions or picnics for juveniles or children;(r)preparation of budget
and control over financial matters;(s)allocation of duties to personnel;(t)supervision over office
administration, including attending to personnel welfare and staff discipline;(u)prompt, firm and
considerate handling of all disciplinary matters;(v)organize the meetings of the Management
Committee and provide necessary support;(w)maintenance of all documents and registers required
under the Act and the rules;(x)liaison, coordination and cooperation with the District Child
Protection Unit or State Government as and when required; and(y)coordination with the legal
officer in the District Child Protection Unit to ensure that every juvenile is legally represented and
provided free legal aid and other necessary support or, where the District Child Protection Unit has
not been set up, services of the District or State Services Authority shall be made
available.(z)organize children committee meetings and provide necessary support.(3)The
Superintendent also have the other duties like:-(i)to ensure the Rights of child in all possible
manner within the frame of these rules and regulations;(ii)he shall exercise control over the staff
and shall issue instructions for the smooth and effective functioning of the institutions;(iii)the
Superintendent shall ensure that all the staff are discharging their duties in accordance with the
rules and regulations and the children are provided with quality and quantity of food, educational
and vocational training in accordance with the aptitude and need base of the children, control overBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

budget and accounts, financial management of the institution, propose plan and non-plan schemes
for the further development of the institution;(iv)the Superintendent of the institution shall be the
custodian of important confidential documents, deeds, agreements, personal files of staff, valuable
articles of children etc;(v)the Superintendent shall be responsible for safe drinking water, proper
sanitary and hygienic conditions in the institution, proper health care of children/juveniles
etc;(vi)the Superintendent shall pay surprise visits at least once in fortnight during night and ensure
that the institutional management is in control and vigil during night;(vii)the Superintendent shall
nurture a congenial relationship among inmates and convene the meetings of various committees
and conduct the proceedings and supervise that the decisions of the Committees are implemented
effectively;he(viii)shall be responsible for evolving a rehabilitation plan for every child.
71. Duties of Deputy Superintendent.
- The duties and responsibilities of Deputy Superintendent will be as follows:-(a)Custodian of
placement orders.(b)Supervision of food preparation, food distribution and maintenance of related
records etc.(c)To conduct open house meeting with children and staff to encourage children's
participation in the activities.(d)To conduct interviews with parents of children and regulation of
communication of children with outsiders.(e)To facilitate the children to participate in seminars,
cultural programmes, meetings etc.(f)Monitor the application of positive reinforcement/cognitive
restructuring, prepare a status report in consultation with the house parents or wardens.(g)To
monitor the supply of external eatables if any supplied to children by parents.(h)Custodian of
clothing and bedding being supplied to Children's Home.(i)Organization of camps, picnics, cultural
programmes, extra- curricular activities like Scouts, Red Cross work etc(j)To see that the protective
and developmental rights of children are ensured.(k)Ensuring that the children's need of food and
cloth are met as per standard..(l)Ensuring the cleanliness of the premises and maintenance of
physical infrastructure including provisions of water and electricity etc.(m)Any other duties and
responsibilities assigned by the Superintendent. In the absence of the post of Deputy
Superintendent the work shall be performed by the Superintendent.Chapter  VII Miscellaneous
72. Recognition of fit persons or fit institution.
(1)Any individual who is willing temporarily to receive a juvenile or child in need of care, protection
or treatment for a period as may be necessary, may be recognized by the competent authority as a fit
person after due verification of their credentials and reputation.(2)Any suitable place or institution,
the manager of which is willing temporarily to receive a juvenile or child in need of care and
protection for a period as may be necessary, may be recognized by the State Government as a fit
institution on the recommendation of the competent authority.(3)An institution recognized as a fit
institutions shall,?(a)meet the standards of care laid down in the Act and the rules made
thereunder;(b)have the capacity and willingness to meet the standards of care laid down in the Act
and the rules;(c)receive and provide basic services for care and protection of the juveniles and
children;(d)prevent subjection of juvenile or child to any form of cruelty or exploitation or neglect;
and(e)abide by the orders of the competent authority.(4)A list of fit institutions approved by the
State Government shall be kept in the office of the Board and the Committee.(5)A fit institution with
collateral branches may send the juvenile or child placed therein by an order of the competentBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

authority to any of its branches after seeking permission from the competent authority.(6)Before
declaring any person as a fit person or recommending an institution as a fit institution, the
competent authority shall hold due enquiry and only on being satisfied, recognition shall be given.
73. Certification or recognition and transfer of Management of Institutions
and After Care Organizations.
(1)Any organization requiring certification under the Act shall make an application together with a
copy each of the rules, bye-laws, articles of association, list of members of the society or the
association running the organization, office bearers and a statement showing the status and past
record of specialized child care services provided by the organization, to the State Government,
along with a copy to competent authority. The state government shall after getting verified the
provisions made by the organization for the boarding and lodging, general health, educational
facilities, vocational training and treatment services may grant certification or recognition for a
maximum period of 3 years at a time, under Sections 8, 9, 34, 37, 41 or 44 of the Act, as the case may
be, on the condition that the organization shall comply with the standards or services as laid down
under the Act and the rules framed there under, from time to time and to ensure an all round
growth and development of juvenile or child placed under its charge.(2)Any organization desiring
recognition under the Act shall make an application to the District Child Protection Unit or any
other authority prescribed by the State Government from time to time. The competent authority,
within a month of receipt of the application, shall after due inquiry, recommend or advise the state
government for such recognition.(3)The State Government may, transfer the management of any
State run institution under the Act to a voluntary organization, who has the capacity to run such an
institution; and certify or recognize the said voluntary organization as a fit institution to own the
requisite responsibilities under a Memorandum of Understanding for a specified period of
time.(4)The State Government may, if dissatisfied with the conditions, rules, management of the
organization certified or recognized under the Act, at any time, by notice served on the manager of
the organization, declare that the certificate or recognition of the organization, as the case may be,
shall stand withdrawn as from a date specified in the notice and from the said date, the organization
shall cease to be an organization certified or recognized under Sections 8, 9, 34, 37,41 or 44 of the
Act, as the case may be:Provided that the concerned organization shall be given an opportunity of
making a representation in writing, within a period of thirty days, against the grounds of withdrawal
of certificate or recognition of that organization.(5)The decision to withdraw or to restore the
certificate or recognition of the organization may be taken, on the basis of a thorough investigation
by the District Child Protection Unit or any other authority prescribed by the State
Government.(6)On the report of the District Child Protection Unit or such other authority, the
Officer in- charge of the institution shall be asked to show cause so as to give an explanation within
thirty days.(7)When an organization ceases to be an organization, certified or recognized under
Sections 8, 9, 34, 37,41 or 44 of the Act, the juvenile or the child kept therein shall, be transferred to
some other institution of like nature, certified or recognized under Sections 8, 9, 34, 37, 41 or 44 of
the Act or discharged, in accordance with the provisions of the Act and the rules relating to their
discharge and transfer by giving intimation of such discharge or transfer to the Board or the
Committee, as the case may be.Bihar Juvenile Justice (Care and Protection of Children) Rules, 2015

74. Registration under the Act.
(1)All institutional care services for children in need of care and protection, whether run by
Government or voluntary organization, shall get themselves registered under sub-Section (3) of
Section 34 of the Act.(2)All such institutions shall make an application together with a copy each of
rules, bye-laws, memorandum of association, list of governing body, office bearers, balance sheet of
past three years, statement of past record of social or public service provided by the institution or
organization to the State Government, who shall after verifying that provisions made in the
institution or organization for the care and protection of children, health, education, boarding and
lodging facilities, if any, vocational facilities and scope of rehabilitation, may issue a registration
certificate to such organization under sub-Section (3) of Section 34 of the Act and as per this rule.
75. Grant in aid to certified or recognized organization.
(1)An organization certified or recognized or registered under Sections 8, 9, 34, 37, 41 or 44 of the
Act may during the period of certification or recognition in force, may apply for grants in aid to the
State Government for maintenance of children received by them under the provision of Act and for
expenses incurred on their education, treatment, vocational development and rehabilitation; and
the government may sanction the amount as per availability of funds.(2)The grants-in-aid shall not
be admissible if the organization is receiving grant in aid under Orphanage Control Board or from
foreign sources.(3)In case of transfer of management of government run homes under Sections 8, 9,
34, 37, 44, sub Section (3) of Section 34, sub Section (4) of Section 44 of the Act to a voluntary
organization, the same budget which the Government was spending on that home, shall be given to
the voluntary organization as grant-in-aid under the Memorandum of Understanding signed
between both the parties describing their role and obligations.
76. Admission of outsiders.
(1)No stranger shall be admitted to the premises of the institution, except with the permission of the
Superintendent or on an order from the Board or Committee.(2)In special cases, where parents or
guardians have travelled a long distance from another state or district, the Superintendent shall
allow parents or guardians entry into the premises and a meeting with their children, provided they
possess proper identification and are not reported to have subjected the juvenile or child to abuse
and exploitation.
77. Identity Photos.
(1)On admission to a home established under the Act, every juvenile or child shall be
photographed.(2)One photograph shall be kept in the case file of the juvenile or the child, one shall
be fixed with the index card, a copy shall be kept in an album serially numbered with the negative in
another album, and a copy of the photograph shall be sent to the Board or Committee as the case
may be, as well as to the District or State Child Protection Unit.(3)In case of a child missing from an
institution or in case of lost children received by an institution, a photograph of the child withBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

relevant details shall be sent to the missing person's bureau and the local police station.
78. Police Officers to be in plain clothes.
- While dealing with a juvenile or a child under the provisions of the Act and the rules made there
under, except at the time of arrest, the Police Officer shall wear plain clothes and not the police
uniform to maintain friendly atmosphere.
79. Prohibition on the use of handcuffs and fetters.
- No child or the juvenile in conflict with law dealt with under the provisions of the Act and the rules
made there under shall be handcuffed or fettered.
80. Procedure to be followed by a Magistrate not empowered under the Act.
(1)When any juvenile or child is produced before a Magistrate other than Board or Committee, and
the Magistrate is of the opinion that such person is a juvenile or child, he shall record his reasons
and send the juvenile or child to the appropriate competent authority.(2)In case of a juvenile
produced before a Magistrate not empowered under this Act, such Magistrate shall direct the case to
be transferred to the Board for inquiry and disposal.(3)In case of a child in need of care and
protection produced as a victim of a crime before a Magistrate not empowered under the Act, such
Magistrate shall transfer the matter concerning care and protection, rehabilitation and restoration
of the child to the appropriate Committee.
81. Transfer.
(1)During the inquiry, if it is found that the juvenile or child hails from a place outside the
jurisdiction of the Board or Committee, the Board or Committee shall order the transfer of the
juvenile or child and send a copy of the order to the State Government or State or District Child
Protection Unit, provided that:(i)such transfer is in the best interest of the juvenile or child;(ii)no
child shall be transferred or proposed to be transferred only on the ground that the child has created
problems or, has become difficult to be managed in the existing institution or, is suffering from a
chronic or terminal illness or, on account of disability;(iii)Such transfer shall only take place after
the completion of evidence and cross examination that may be required in a legal proceeding
involving a juvenile or child and the reasons for and circumstances of such transfer are recorded in
writing.(2)The State Government or State or District Child Protection Unit shall
accordingly:-(i)send the information of transfer to the appropriate competent authority having
jurisdiction over the area where the child is ordered to be transferred by the Board or Committee;
and(ii)send a copy of the information to the Superintendent of the institution where the child is
placed for care and protection at the time of the transfer order.(3)On receipt of copy of the
information from the State Government or State or District Child Protection Unit, the
Superintendent shall arrange to escort the child at government expenses to the place or person as
specified in the order.(4)On such transfer, case file and records of the juvenile or child shall be sentBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

along with the juvenile or child.
82. Procedure for sending a juvenile or child outside the jurisdiction of the
competent authority.
(1)In the case of a juvenile or a child whose ordinary place of residence lies outside the jurisdiction
of the competent authority, and if the competent authority considers it necessary to take action
under Section 50 of the Act, it shall direct a probation officer or case worker or child welfare officer,
as the case may be, to make enquiries as to the fitness and willingness of the relative or other person
to receive the juvenile or the child at the ordinary place of residence, and whether such relative or
other fit person can exercise proper care and control over the juvenile or the child.(2)Where a
juvenile or child is ordered to be sent to the ordinary place of residence or to a relative or fit person,
execution of a bond by the juvenile or child without any surety, in Form VI, is necessary along with
an undertaking by the said relative or fit person in Form V or Form IX as the case may be.(3)Any
breach of a bond or undertaking or of both given under sub rule (2) of this rule, shall render the
juvenile liable to be brought before the competent authority, who may make an order directing the
juvenile to be sent to an institutional home.(4)Any juvenile or a child, who is a foreign national and
who has lost contact with his family shall also be entitled for protection.(5)The Juvenile or the child,
who is a foreign national, shall be repatriated, at the earliest, to the country of his origin in
coordination with the respective Embassy or High Commission.(6)The Board or Committee shall
keep the Ministry of External Affairs informed about repatriation of every juvenile or child of foreign
nationality carried out on the orders of the Board or Committee.(7)A copy of the order passed by the
competent authority under Section 50 of the Act shall be sent to-(a)The probation officer or child
welfare officer who was directed to submit a report under sub-rule (1) of this rule;(b)The Probation
Officer or child welfare officer, if any, having jurisdiction over the place where the juvenile or the
child is to be sent;(c)The competent authority having jurisdiction over the place where the juvenile
or the child is to be sent;(d)The relative or the person who is to receive the juvenile or the child,;
and(e)The approved escort by fax or any other instantaneous mode of communication.(8)During the
pendency of the order under sub-rule (6) of this rule, the juvenile or the child shall be sent by the
competent authority to an observation home or children's home as the case may be.(9)Where the
competent authority considers it expedient to send the juvenile or the child back to his ordinary
place of residence under Section 50, the competent authority shall inform the relative or the fit
person, who is to receive the juvenile or the child accordingly and shall invite the said relative or fit
person to come to the home, to take charge or the juvenile or the child on such date, as may be
specified by the competent authority.(10)The competent authority inviting the said relative or fit
person under sub rule (8) of this rule may also direct, if necessary, the payment to be made by the
Superintendent of the home, of the actual expenses of the relative or fit person's journey both ways,
by the appropriate class and the juveniles or child's journey from the home to his ordinary place of
residence, at the time of sending the juvenile or the child.(11)If the relative or the fit person fails to
come to take charge of the juvenile or the child on the specified date, the juvenile or the child shall
be taken to his ordinary place of residence by the escort as decided by the competent authority and
in the case of a girl, at least one escort shall be a female.Bihar Juvenile Justice (Care and Protection of Children) Rules, 2015

83. State Child Protection Unit.
(1)The state government shall set up an office of a State Child Protection Unit with such officials and
employees as it considers necessary.(2)Functions of the State Child Protection Unit:- Besides the
overall implementation of various provisions of the Act and supervision and monitoring of the
agencies and institutions setup under the Act, the Unit shall be responsible for, but not limited to,
the following specific functions:(a)set up, support and monitor the District Child Protection
Units;(b)represent as a member in the Selection Committee for appointment of members of Boards
or Committees;(c)prepare annual budget and facilitate for necessary and timely allocation of funds
to the Child Welfare Committee, Juvenile Justice Boards, District Child Protection Units, Juvenile
homes, or any other institutions or agencies to ensure their effective functioning.(d)documentation
of all data related to children and units established under the Act, publishing such reports as
required from time to time, development of IEC (Information, Education, Communication)
materials or other such materials for awareness and sensitization, including documentary, materials
on website, posters, brochures etc;(e)network and coordinate with all government departments
(state and central) to build inter-sectoral linkages on child protection issues, including departments
dealing with health, education, social welfare, welfare child labour, child marriage, trafficking,
abuse, child rights, police, judiciary, HIV/AIDS etc. The Unit shall coordinate with any other state
units in the State so created for the welfare and protection of children, including State level
Adoption Coordinating Agency, State Adoption Resource Agency, Child Line, etc;(f)network and
coordinate with NGOs and civil society organizations working on the issues related to children,
including the processing of the NGO's and civil society organisation's application for recognition,
certification, registration or grant-in-aid;(g)training and capacity building of all personnel
(Government and Non Government) working under the Act and development of training manuals
and curriculum, development of a list of resource persons and publication of such materials and
manuals for distribution among the stakeholders;(h)establish minimum standards of Care and
ensure its implementation in all institutions set up under the Act;(i)review of the functioning of
Committees;(j)formulation and implementation of such schemes and programmes necessary for
implementation of the provisions of the Act and any scheme of the Central Government, as the case
may be, including non-institutional services such as adoption, foster care, after care programme,
sponsorship etc;(k)to accomplish capacity building, awareness, documentation, survey, studies or
impact assessment and such other programmes in association with research and training
institutes;(l)to provide necessary inputs to the Department of Social Welfare or the concerned
Department responsible for the implementation of the Act by any other name, as and when required
for effective policy planning, formulation and implementation.
84. District Child Protection Unit.
(1)The State Government shall constitute a District Child Protection Unit in every district with such
officials and employees as it considers necessary.(2)Functions of the District Child Protection Unit -
Besides the overall implementation of various provisions of the Act and supervision and monitoring
of the agencies and institutions set up under the Act, the District Child Protection Unit shall be
responsible for, but not limited to, the following specific functions,-(i)work under the overall
guidance from the State Child Protection Unit and implement the directions issued from the StateBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

Government from time to time;(ii)support to district level units such as Juvenile Justice Board,
Child Welfare Committee, District Advisory Board, Special Juvenile Police Unit, children's
institutions, juvenile homes, etc. and facilitate to set up their offices with adequate infrastructure,
funding and staff;(iii)performance appraisal of the Board members and the Committee and send the
report to the State Government;(iv)The screening of the applications and verifications of the
credentials of the applicants for the selection of social members of the Juvenile Justice Board, Child
Welfare Committee, District Advisory Board and Inspection Committee as per the criteria laid down
in the Act and these rules by a three-member Screening Committee comprising of District
Magistrate, an senior officer representing Education or Health Department and Assistant Director
Child Protection of the District Child Protection Unit. The member Secretary of the Screening
Committee will be Assistant Director Child Protection of the District Child Protection Unit of the
concerned district. The District Child Protection Unit will send all such applications with the
remarks of the Screening Committee.(v)Committee members, Advisory Board/Inspection Team
members and process all such applications as directed by the State Child Protection Unit or the
State Government from time to time.(vi)identify and maintain data base of such children in need of
care and protection through survey, campaigns or such other methods as may by necessary and like
them to agencies for protection, emergency services, care, restoration or rehabilitation;(vii)network
and coordinate with all government departments to build inter-sectoral linkages on child rights
issues, including Departments of Health, Education, Social Welfare, Welfare, Urban Development,
Backward classes & Minorities, Youth Sports and Culture, Police, Judiciary, Labour, State AIDS
Control Society, among others through monthly meetings;(viii)network and coordinate with civil
society organizations working under the Act;(ix)implement family based non-institutional services
including sponsorship, foster care, adoption and after care;(x)identify families at risk and children
in need of care and protection;(xi)assess the number of children in difficult circumstances and
creating district specific database to monitor trends and patterns of children in difficult
circumstances;(xii)periodic and regular mapping of all child related services in the district for
creating a resource directory and making the information available to the Committees and Boards
from time to time;(xiii)ensure setting up of District, Block and Village level Child Protection
Committees for effective implementation of programmes as well as discharge of its
functions;(xiv)facilitate transfer of children at all levels for either their restoration to their families
or placing the child in long or short-term rehabilitation through institutionalization, adoption, foster
care and sponsorship;(xv)supporting State Adoption Resource Agency in implementation of family
based non institutional services at district level;(xvi)develop parameters and tools for effective
monitoring and supervision of agencies and institution in the district in consultation with experts in
child welfare;(xvii)supervise and monitor all institutions or agencies providing residential facilities
to children in district;(xviii)train and build capacity of all personnel (Government and Non
government) implementing the Act to provide effective services to children;(xix)organize quarterly
meeting with all stakeholders at district level including Child line, Specialized Adoption Agencies,
Superintendent of homes, non government organizations and members of public to review the
progress and implementation of the Act; and(xx)liaison with the state Child Protection Unit, State
Adoption Resource Agency at State level and District Child Protection Unit of other districts.Bihar Juvenile Justice (Care and Protection of Children) Rules, 2015

85. Special Juvenile Police Unit.
(1)The State Government shall constitute special Juvenile Police Unit at the district level to handle
cases related to juvenile in conflict with law and the children in need of care and protection.(2)The
Special Juvenile Police Unit shall also coordinate with all the police stations in the District, Special
Juvenile Police Units established in other districts and the District Child Protection Unit.(3)The
Special Juvenile Police Unit at the district level shall consist of Special Juvenile Police Officer (not
below the rank of Deputy Superintendent of Police) along with two paid social worker (one woman)
and all the Juvenile-cum-Child Welfare Officers of the district.(4)A police officer shall be designated
as Child Welfare Officer in all the police stations of the district, who shall sensitively handle the
cases of children and report the matter to Special Juvenile Police Unit in the District.(5)The Special
Juvenile Police Unit may associate recognized voluntary organizations, Gram Sabha, Panchayat or
Child Line to assist the Unit under the guidance of the Special Juvenile Police Officer in a manner
which may help him/her in the care and protection of children, including social investigation,
counselling, care, restoration and rehabilitation.(6)The District Child Protection Unit or State Child
Protection Unit or any other designated training institute shall provide regular training and such
orientation as may be necessary, to the Special Juvenile Police Officers and other persons associated
with the handling of child related matters. It shall be mandatory for the Special Juvenile Police
Officers and Child Welfare Officer to undertake the trainings.(7)In case there is any contradiction
between the provisions of the juvenile Justice (Care and Protection of children) Act, 2000 (as
amended in 2006) and the Rule framed there under on the one hand and other provisions of the
Bihar Police Act, 2007 or any other Rules made there under or any Manual or Official Directions, it
shall be decided in the best interest of the child.(8)The Special Juvenile Police Units shall
particularly seek assistance from Gram Sabha, Panchayat, voluntary organizations recognised as
protection agencies by the State Government for the purpose of assisting Special juvenile Police
Units and local Police Stations at the time of apprehension, in preparation of necessary reports, for
taking charge of juveniles until production and at the time of production before the Board as per
rule 11(12) of these rules.(9)The Superintendent of Police in a district shall head the Special Juvenile
Police Unit and oversee its functioning from time to time.(10)A Nodal Officer from Police not less
than the rank of Inspector General of Police shall be designated in each State to coordinate and
upgrade role of police on all issues pertaining to care and protection of children or juveniles under
Act.(11)Any police officer found guilty, after due inquiry, of torturing a child, mentally or physically,
shall be liable to be removed from service, besides being prosecuted for the offence.
86. Honorary or Voluntary Welfare Officers and Probation Officers.
- To augment the existing probation service, honorary or voluntary welfare officers and probation
officers may be appointed from the voluntary organization and social workers found fit for the
purpose by the competent authority and their services may also be co-opted into the
implementation machinery by the orders of the competent authority.Bihar Juvenile Justice (Care and Protection of Children) Rules, 2015

87. Disqualification for officer-in-charge, probation officer or case worker and
other care givers and staff.
(1)The Superintendent, Probation officer or case worker and other care givers and staff shall not
employ a juvenile or child under their supervision or care and protection for their own purpose or
take any private service from them.(2)Any report of physical, sexual or emotional abuse of a juvenile
or a child in an institution or outside, by a caregiver, shall hold them liable for disqualification after
due inquiry.
88. Training of Personnel.
(1)The State Government with the help of the State Child Protection Unit, shall organize regular
training and capacity building of personnel involved in the implementation of the Act and the rules
made thereunder, in keeping with their statutory responsibilities and specific jobs requirements,
either itself or in collaboration with training and research institutes.(2)The training programme
shall include-(a)orientation and training or the newly-recruited officials, staff, care givers, officials,
members, Police etc;(b)refresher training courses and skill enhancement programmes for all care
givers once a year;(c)staff conferences, seminars, workshops.
89. Selection Committee and its composition.
(1)The State Government shall constitute a Selection Committee by notification in the official
gazette, for a period of three years, consisting of the following seven members, namely:(a)a retired
Judge of a high court or a retired district Judge or a person who has served as Secretary to the
Government of Bihar and has retired from active service to be nominated as the Chairperson.(b)one
representative from the department concerned not below the rank of Director as the
Member-Secretary.(c)one representative from a reputed non-governmental organization, working
on the child rights issues but not running any child care institution;(d)two representatives from the
Academic bodies concerned with social work, psychology, sociology, child development,
gender/women studies, education, law, criminology and with experience or working on children's
issues;(e)a representative of the State Commission for Protection of Child Rights or the State
Human Rights Commission;(f)one Government official from SC/ST communities, not below the
rank of Joint Secretary, to be nominated by the State Government.(2)The selection committee shall
hold its sittings as per requirement and the member secretary shall be responsible for organizing
such a sitting.(3)Any member of the selection committee may resign any time giving in writing to
the state government. Any vacancy so arising from resignation shall be immediately filled preferably
within 4 weeks as per the composition of the selection committee and tenure of such a member shall
be co-terminus with the remaining period of the selection committee.
90. Functions of the Selection Committee.
(1)The Selection Committee shall select and recommend a panel of names to the State Child
Protection Unit or State Government for appointment as members of the Juvenile Justice Board, theBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

Chairperson and Members of the Child Welfare Committee, the non official members of the State
Advisory Board or District or City Level Inspection Committee/Advisory Board.(2)The Selection
Committee shall take into consideration the panel of names recommended by the District Child
Protection Unit. For any State level Committee or Board, the State Child Protection Unit shall
recommend the names to the Selection Committee. The Selection Committee may prescribe the
manner for processing application for selection including a personal interview with the short-listed
applications.(3)The panel of names so recommended by the Selection Committee shall be
considered by the State Government to fill in any vacancies, which may arise during the tenure of
the Board, Committee or the Unit.(4)Applications of appointment in the Board or committee shall
be invited through public advertisement in the prescribed format.(5)In making appointment of
members of the Board or Committee, the Selection Committee shall take into consideration the
applications received in this regard in response to a public advertisement to this effect by the
District or State Child Protection Unit or the State Government.(6)In the event of any complaint
against a member of the Board or Committee, the Selection Committee shall hold necessary inquiry
and recommend termination of appointment of such member to the State Child Protection Unit or
State Government, if required.(7)The Selection Committee, at the time of recommending names for
appointment as member of Board or Committee shall also prepare a panel of names for each Board
or Committee to fill in vacancies, which may arise during the tenure of the Board or
Committee.(8)In the event of a vacancy in the Board or Committee, the District Child Protection
Unit shall inform the State Child Protection Unit or State Government for filling up such
vacancy.(9)The State Child Protection Unit or State Government shall fill the vacancies on the basis
of the panel of names recommended by the Selection Committee.
91. Advisory Boards.
(1)The State Government shall constitute Advisory Board at State, District and City levels for a
period of 3 years.(2)The State Government shall constitute the State Advisory Board consisting
of:-(a)The Chief Secretary-Chairperson;(b)Principal Secretary, Department of Social
Welfare-Convenor(c)Secretary or its representative from the departments of Health, Education,
Police, Law, Labour, and Building Construction Department;(d)Chairperson of the Selection
Committee(e)Two representatives from NGOs working in the field of child
welfare;(f)Representatives from Legal Services Authority.(3)The functions of the State Advisory
Board shall be;(i)to advise the government on matters relating to the establishment and
maintenance of the homes,(ii)to advise on creation and management of the Fund as prescribed
under Section 61 of the Act,(iii)to inspect various provisions, facilities and services such as food,
clothes, medicine, education, vocational training, economic and social rehabilitation for the children
in institution and their rates.(iv)Any other matter considered necessary for policy, planning and
implementation of any scheme for the benefit of the children(v)Inter-departmental coordination at
the apex level.(4)The State Government shall constitute District Advisory Board consisting of;(a)The
District Magistrate-Chairperson,(b)Civil Surgeon- Member,(c)District Superintendent of Education-
Member,(d)Head of the District Child Protection Unit-Convener(e)Two representatives from
NGOs.(5)All the Advisory Boards shall hold at least two meetings in a year.(6)The District or City
level Advisory Board constituted in terms of sub-Section (3) of Section 62 of the Act shall also
function as the inspection committee under Section 35 of the Act.(7)The Advisory Boards shallBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

inspect the various institutional or non-institutional services in their respective jurisdictions; and
the recommendations made by them, shall be considered by the State Government.(8)The State
Government, through the Selection Committee constituted under Rule 99 of these rules, shall
recommend a panel of names for the non-official members of the State, District and City level
Advisory Boards.(9)The termination, resignation, or other vacancy with regard to the non-official
members, caused in an advisory board and appointment of new members therein shall be done in
the same manner as is done in case of the competent authority.
92. Juvenile Justice Fund.
(1)The State Government shall create a Fund at the State level under Section 61 of the Act to be
called the 'Juvenile Justice Fund' (herein under referred to as the Fund) for the welfare and
rehabilitation of the juvenile or the child dealt with under the provisions of the Act.(2)In addition to
donations, contributions or subscriptions coming under Sub-Section (2) of Section 61, the Central
Government/ State Government shall also make contribution to the Fund(3)There shall be an
autonomous and non-profit body registered under the Societies Registration Act, 1860 and the
management and administration of the Fund shall be under the State Advisory Board, constituted
under Section 62.(4)The Fund shall be applied, -(a)To formulate and implement programmes and
schemes necessary for the welfare, rehabilitation and restoration of juveniles or children;(b)To pay
grant-in-aid to non- governmental organizations;(c)To meet the expenses of State Advisory Board
and its purpose;(d)To do all other things that are incidental and necessary for the above
purpose.(5)The assets of the Fund shall include all such grants and contributions, recurring or
nonrecurring, from the Central Government and State Government or any other statutory or non
statutory bodies set up by the Central or State Government as well as the voluntary donations from
any individual or organization.(6)The regular accounts shall be kept of all money and properties,
and all incomes and expenditure of the Fund and shall be audited by a registered firm of Chartered
Accountants, or any other recognized authorities as may be appointed by the Board.(7)All contracts
and other assurances shall be in the name of the board of management and signed on their behalf by
the secretary-cum-treasurer and one member of the board of the management authorized by it for
the purpose.(8)All withdrawals shall be made by cheques or requisitions, as the case may be, signed
by the secretary-cum-treasurer and in the case of amount exceeding rupees ten thousand, they shall
be signed duly by the secretary-cum-treasurer and a member of the board of management to be
nominated by the State Advisory Board.(9)The board of management shall invest for the time being
the proceeds of sale or other disposal of property, as well as any money or property not immediately
required to be used to serve the objective of the Fund, in any one or more of the modes of
investment authorized by law for the investment of trust moneys as the board of management may
think proper.
93. Pending Cases.
(1)No Juvenile in conflict with law or a child shall be denied the benefits of the Act and the rules
made there under.(2)All pending cases which have not received finality shall be dealt with and
disposed of in terms of the provisions of the Act and the rules made there under.(3)Any juvenile in
conflict with law, or a child shall be given the benefits under sub rule (1) of this rule, and it is herebyBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

clarified that such benefits shall be made available to all those accused who were juvenile or a child
at the time of commission of an offence, even if they cease to be a juvenile or a child during the
pendency of any inquiry or trial.(4)While computing the period of detention or stay or sentence of a
juvenile in conflict with law or of a child, all such period which the juvenile or the child has already
spent in custody, detention, stay or sentence of imprisonment shall be counted as a part of the
period of stay or detention or sentence of imprisonment contained in the final order of the court or
the Board.
94. Openness & Transparency.
(1)All Children's homes shall be open to visitors with the permission of the Officer-in-charge and the
Committee or Officer-in-charge as the case may be, may consider appropriate to allow
representatives of local self-government, voluntary organizations, social workers, researchers,
medicos, academicians, prominent personalities, media and any other persons as visitors, as the
Officer-in-charge considers appropriate keeping in view the security, welfare and the interest of the
children.(2)The Officer-in-charge of the home shall encourage active involvement of local
community in improving the conditions in the homes, if, the members of the community want to
serve the institution or want to contribute through their expertise.(3)The officer-in-charge shall
maintain a visitors book and the remarks of the visitors given therein shall be considered by the
advisory inspecting authority.(4)While visiting an institution, the visitors will not say or do anything
that undermines the authority of the Officer-in-charge or is in contravention of the Act or rules or
impinges on the dignity of the children.(5)Notwithstanding anything contained in the above
sub-rules it shall be lawful for the officer in charge to refuse permission when he thinks that such
visit will be prejudicial to the interest of the inmates or the running of homes.(6)The visitors may be
allowed to visit observation homes and special homes with the permission of the competent
authority.
95. Disposal of records or documents.
- The records or documents in respect of a juvenile or a child or a juvenile in conflict with law shall
be kept in a safe place for a period of seven years and no longer, and thereafter be destroyed in
consultation with the Board or the Committee, or the Child Protection Unit, as the case may be.
96. Disposed of cases of juveniles in conflict with law.
(1)The State Government or as the case may be the Board may, either suo motu or on an application
made for the purpose, review the case of a person or a juvenile in conflict with law, determine his
juvenility in terms of the provisions contained in the Act and rule 12 of these rules and pass an
appropriate order in the interest of the juvenile in conflict with law under Section 64 of the Act, for
the immediate release of the juvenile in conflict with law whose period of detention or
imprisonment has exceeded the maximum period provided in Section 15 of the said Act.(2)For the
purpose aforementioned a Review Committee will be constituted by the State Government which
will submit its recommendation after reviewing the matter.Bihar Juvenile Justice (Care and Protection of Children) Rules, 2015

97. Protection of action taken in good faith.
- No suit or legal proceedings shall lie against any functionary under the Act including the members
of the voluntary organization and social worker, in respect of anything which is done in good faith or
intended to be done in pursuance of the Act during the performance of the duties assigned to them.
98. Repeal and Saving.
(1)The Bihar Juvenile Justice (Care and Protection of Children) Rules, 2012 in hereby
repealed.(2)Nothing contained in these rules shall be deemed to affect any act done or order issued
in pursuance of the Bihar Juvenile Justice (Care and Protection of Children) Rules, 2012 before
these rules come into force.
Schedule 1
Clothing, bedding, toiletries and other articles (rule 48)(1)Juvenile or children shall be provided
with the following articles:
Bedding
Sl No. Article Quantity to be provided per child
1 Towels 4 per year
2 Cotton Bed Sheets 2 per 2 year
3 Pillow (Cotton Stuffed) 1 per 2 year
4 Pillow Covers 2 per 2 year
5 Woollen blankets 2 per 2 years
6 Cotton Durry 2 per 2 years
7 Cotton filled quilt 1 per 2 year (in cold regions)
8 Mattress 1 per 2 years
9 Mosquito Net 1 per 2 years
Clothing for girls
1Skirts & Blouse or Salwar Kameez or Halfsari
with blouses and petticoats5 sets per year for girls
depending on age andregional
preferences
2 Banyans (1 Metre each) 6 per year for younger girls
3 Brassieres 6 per year for older girls
4 Panties (1 Metre Cloth each) 6 per year
5 Sanitary Towels 12 packs per year for older girls
6 Woollen Sweaters 2 in 2 years ( in cold regions)
7 Woollen Shawls 1 in 2 years (in cold regions)
Clothing for boysBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

1 Shirts 5 sets per year
2 Shorts 5 sets per year for younger boys
3 Pants 5 sets per year of older boys
4 Vest 4 set per year
5 Underwear 4 set per year
6 Woollen Jerseys 2 in 2 years (for cold regions)
7 Scarfs 2 in 2 years (for cold regions)
Miscellaneous
Articles
1 Slippers 1 pair per year
2 Shoes 1 pair per year
3 School Uniform2 sets per year for children attending
outsideschools
4 School shoes1pair per year for children attending
outsideschools
5School Bag and
Stationery1 set per year for children attending
outsideschools
6 Handkerchiefs 6 per year
Note. - In addition to the clothing specified above, each child shall be provided, once in three years,
with a suit consisting of one white shirt, one pair of khaki shorts or pants, one pair of white canvas
shoes and one blazer (for cold regions) for use during ceremonial occasions. In the case of girls it
shall be one white half sari or one salwar kameez or one white skirt and one white bolouse, a pair of
white convas shoes and a blazer (for cold regions).(2)In every hospital attached to the institution
where there is provision for in patient cots the following scale has to be followed:
Sl Night clothing & bedding Scale for supply
1 Mattress One per bed per 3 years
2 Cotton Bed Sheets Four per bed per year
3 Pillows One per bed per two year
4 Pillows Covers Four per bed per year
5 Woollen blankets One per bed per 2 year
6 Pyiamas and loose shirts (Hospital type forboys) 3 Pairs per child per year
7 Skirts and blouses or salwar kameez for girls 3 Pairs per child per year
8 Cotton durryOne per bed per three years
Note:
Note. - (i) When a child is admitted as an in patient in the institution Hospital, the Institution
Doctor shall issue the in patient with the hospital clothing, the clothes on body being preserved duly
washed and handed back an the time of the child's discharge from the hospital.(ii)Each child shall
be provided with kit Box or a Locker as per convenience and necessity.(iii)The Superintendent shall
make arrangement for two-tier bed system in place or conventional cots, as per convenience and
necessity.(3)Toiletry: Every resident to the Home shall be issued with oil, soap and other materialBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

for in accordance with the following scales:
Hair oil for grooming the hair 100 mgs per month
Toilet soap or carbolic soap 1 large bar per month
Tooth Paste and brush 1 Brush per 3 months 50 gms paste per month
Comb 1 Per Year
Note. - (a) For washing of cloth and towels, bed-sheet etc, the following scale may be
followed:(i)Washing Soap 1 Soap for one month (125gms)(ii)Whitening/bleaching agent to the
extent required only for white clothing Provided, however, the hospital clothing is not mixed with
other clothing at the time of washing and if necessary, the Superintendent can issue the above items
separately for washing of hospital clothing.(b)The children attending school outside the institution
may be issued with one additional bar of washing soap (100 gms) per head per month for washing
their school uniform.(4)The following items shall be provided for maintaining the Homes in a
healthy and sanitary condition:
Sl
No.Item Scale of supply
1 Broom Stick 25 to 40 Nos per month depending on the area ofthe institution
2 DDT spary As per the institution Doctor's advice
3Effective bugs killing
agentAs required
4Phenyl and cleaning acid
(daily)Depending on the area of lavatories to becleaned as per
institution Doctor's advice
II
Nutrition and Diet Scale (rule 44)
Sl Name of the articles of diet Scale per head per day
1 Rice/Wheat/Ragi/Jowar600 Gms (700 Gms for 16-18 yrs age) of
whichatleast 100 gms to be either wheat
or ragi or jower
2 Dal/Rajma/Chana 120 Gms
3 Edible Oil 25 Gms
4 Onion 25 Gms
5 Salt 25 Gms
6 Turmeric 05 Gms
7 Coriander Seed Powder 05 Gms
8 Ginger 05 Gms
9 Garlic 05 Gms
10 Tamarind/Mango Powder 05 Gms
11 Milk (at breakfast) 150 ml
12 Dry Chillies 05 GmsBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

13 Vegetables Leafy 100 Gms
14 Vegetables Non Leafy 130 Gms
15 Curd or Butter Milk 100 Gms/Ml
16Jaggery & Ground Nut Seeds or
Paneer(vegetarian only)60 Gms each (100 Gms for paneer) Once
in a week
17 Sugar 40 Gms
Following items for
50 Children per day
18 Pepper 25 Gms
19 Jeera Seeds 25 Gms
20 Black Gramdall 50 Gms
21 Mustard Seeds 50 Gms
22 Ajwain Seeds 50 Gms On
Chicken Day for
10kg. of Chicken
23 Garam Masala 10 Gms
24 Kopra 150 Gms
25 Khas Khas 150 Gms
26 Groundnut Oil 500 Gms
For Sick Children
27 Bread 500 GmsMl
28 Milk 500  
Other Items
29 LP Gas for Cooking only  
Instructions:(2)Variation in Diet(a)Three varieties of dal i.e., Toor (Tuvari), Moong (Green Gram)
and Chana (Bengal Gram) may be issued alternatively.(b)The Superintendent may also arrange to
substitute chicken with fish at his discretion, provided that there is no extra expenditure to
Government.(c)On non-vegetarian days, vegetarian children shall be issued with either 60 Gms of
Jaggery and 60 Gms of Groundnut seeds per head in the shape of laddus or any other sweet dish or
100 gms paneer.(d)Potatoes shall be issued in lieu or vegetables once in a week.(e)Leafy vegetables
such as Fenugreek(Methi), Spinach (Palak), Sarson (Mustard leaves) Gongura Thotkaura or any
other saag etc., may also be issued once in a week. If a kitchen garden is attached to any institution
leafy vegetables, in addition to drumstick trees, curry leaves trees and coriander leaves, should be
grown and issued and the Superintendent should try to issue variety of vegetables and see that the
same vegetable is not repeated for at least a period of one week.(f)The Superintendent may make
temporary alternations in the scale of diet in individual cases when considered necessary by him, or
on the institution Doctor's advice subject to the condition that the scale laid down is not
exceeded.(3)Meal Timing and Menu. - (a) Breakfast after 8:00 am(i)Upma or chapattis made of
Wheat or Ragi or any other dish.(ii)Chutneys from Gongura or fresh curry leave or fresh coriander
or Coconut and putnadal etc., dal/vegetable may be issued as a dish.(iii)Milk(iv)Any seasonal fruitBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

in sufficient quantity(b)Lunch at 1:00 P.M. and Dinner After 7:00 P.M.(i)Rich/Chapattis or
combination of both(ii)Vegetable Curry(iii)Sambar or Dal(iv)Butter Milk or curd(4)Others. - (a)
Depending on the season, the Superintendent shall have the discretion to alter the time for
distribution of food.(b)On the advise of the Institution Doctor, every sick who is prevented from
taking regular food, on account of his ill, health, may be issued with medical diet, as indicated in diet
scale.(c)Extra diet for nourishment like milk, eggs, sugar and fruits shall be issued to the children on
the advice of the institution Doctor in addition to the regular diet, to pick up weight or for other
health reasons and for the purpose of calculation of the daily ration, the sick children shall be
excluded from the day's strength.(d)On the following national and festival occasions, sweet dishes
may be distributed to all the children at the Home at the rate fixed by the Commissioner from time
to time.
1. Republic Day (26th January)
2. Ambedkar's Birthday (14th April)
3. Independence Day (15th August)
4. Mahatma Gandhi's Birth Day (2nd October)
5. Children's Day (14th November)
6. Child Rights Day (20th November)
7. Dussehra (Vijayadasami)
8. Deepavali
9. Ramzan (Id-Ul-Fitr)
10. Bakrid (Id-Ul-Zuha)
11. Christmas (25th December)
The States may specify additional festivals depending upon local preferences.Form-I[Rule
12(6)(c)]Supervision OrderWhen the juvenile is placed under the care of a parent, guardian or other
fit person/fit institution Profile No. .............................of .................20 .... Whereas (name of the
juvenile) has this day found to have committed an offence and has been placed under the care of
(name) ............................................. (address) ........................................................................................
on executing a bond by the said ............................................................. and the Board is satisfied that
it is expedient to deal with the said juvenile by making an order placing him/her under supervision.
It is hereby ordered that the said juvenile be placed under the supervision ofBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

................................................................................................... probation officer/case worker, for a
period of ............................................. subject to the following conditions:-
1. that the juvenile along with the copies of the order and the bond executed
by the said .............................................................................. shall be produced
before the probation officer/caseworker named therein .....................................
2. That the juvenile shall be submitted to the supervision of the aforesaid
probation officer/case worker.
3. That the juvenile shall reside at ........................... for a period of ............. .
4. That the juvenile shall not be allowed to quit the district jurisdiction of
............... without the permission of the probation officer/case worker.
5. That the juvenile shall not be allowed to associate with bad characters.
6. That the juvenile shall live honestly and peacefully; and will go to school
regularly/endeavour to earn an honest livelihood.
7. That the juvenile shall attend the attendance centre regularly.
8. That the person under whose care the juvenile is placed shall arrange for
the proper care, education and welfare of the juvenile.
9. That the preventive measures will be taken by the person under whose
care the juvenile is placed to see that the juvenile does not commit any
offence punishable by any law in India.
10. That the juvenile shall be prevented from taking narcotic durgs or
psychotropic substances or any other intoxicants.
11. That the directions given be the probation officer/case worker from time
to time, for the due observance of the conditions mentioned above, shall be
carried out.
Dated this .................................day of ..............................20 .........(signature)Principal Magistrate,
Juvenile Justice BoardAdditional, conditions, of any may be inserted by the Juvenile Justice
BoardForm-II[Rule 12(6)(d)]Order of detention under Sub-Section.................of Section.................,
Sub-Section ................of Section ...................... and Sub-Section ..........................................ofBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

Section..........................................ToThe Officer in charge........................................................Whereas
on the ...................................................... day of ...................................... 20
.......,.....................................(name of the juvenile), son/daughter of ......................, aged ................,
residing at ...................................... being found in Profile No. .......................................................to be
juvenile in conflict with law/section ........................ is order by me .......................... Principal
Magistrate, Juvenile Justice Board under section .................................. of Juvenile Justice Act, 2000
to be kept in the Observation Home/Special Home/.......................................................... for a period
of .....................................................This is to authorize and require you to receive the said juvenile;
into your charge, and to keep him/her in the Observation Home/ Special
Home/............................................... for the aforesaid order to be carried into execution according to
law.Given under my hand and the seal of Juvenile JusticeBoard This ..................................day of
......................................... 20............(signature)Principal Magistrate, Juvenile Justice
BoardEncl:Copy of the judgment, if any, or orders, particulars of home and case history and
individual care plan, if any:Strike which is not required.Form-IIIOrder Of Social
Investigation/inquiry[Rule 12(1) and 12(6) (e)]To Probation Officer/Case Worker/Person-in-charge
of Voluntary Organization/Case Worker Whereas a report/complaint under section
......................................... of the Juvenile Justice (Care and Protection of Children) Act, 2000 has
been received from ....................................... in respect of ................................................ (name of the
juvenile), son/daughter of ........................................................... approximate age ...........................
residing at .........................................................................................., who has been produced before
the Board.You are hereby directed to enquire into the social antecedents family background and
circumstances of the alleged offence by the said juvenile and submit your social investigation report
on or before ............................. or within such time allowed to you by the Board.You are also hereby
directed to consult an expert in child psychology, psychiatric treatment or counselling for their
expert opinion if necessary and submit such report along with your Social Investigation
Report.Dated this ........................... day of ......................... 20.......(signature)Principal Magistrate,
Juvenile Justice BoardForm IV[Rules 13(5) and 80(1)(a) and (2)]Social Investigation ReportSl.
No..........................Submitted to the Juvenile Justice Board .......................................
(address)Probation Department/Concerned State Government Authority/Voluntary Organisation
......................................................... (Signature and Stamp)Profile No.Under section:Title of
Profile:Police Station:Nature of offence
charge:........................................................................................................................
Name Religion
Father's Name Caste
Permanent Address Year of birth
Last address before apprehension Age
 Sex
...........................................................................................................................Previous
institutional/case history and individual care plan, if anyFamily
Members of family Name Age Health Education OccupationMonthly
earningsDisabilitiesAny other
e.g. Social
habitsBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

Father         
Step- Father         
Mother         
Stepmother         
Siblings         
Any other legal
guardian/ relative        
If married, relevant
particulars........................................................................................................................Other near
relatives or agenciesInterested
............................................................................................................Attitude towards religion
normalAnd ethical code of the home etc. ..............................................................................Social and
economic status .......................................................................................Delinquency record of
members of family ............................................................................................................Present living
conditions ..........................................................................................Relationship between parents/
Parents and children especially With the juvenile under investigation
...........................................................................Other factors of importance if any
..............................................................................Juveniles HistoryMental condition(Present and
past) ..................................................................Physical condition(Present and past)
..................................................................Habits, interests(moral,recreational
etc.).................................................................Outstanding characteristics and Personality traits
........................................................................Companions and their influence
......................................................Truancy from home, if any
.............................................................................................School (attitude towards school, Teachers,
class mates and vice-versa)..............................................................................................Work record
(jobs held, reasons for leaving, Vocational interests, attitude towards job or employers)
.........................Neighbourhood and neighbours report .............................................Parent's attitude
towards discipline In the home and child's reaction ....................................................Any other
remarks.............................................................................................Result of InquiryEmotional
factorsPhysical conditionIntelligenceSocial and economic factorsReligious factorsSuggested causes
of the problemsAnalysis of the case including reasons for delinquencyOpinion of experts
consultedRecommendation regarding treatment and its Plan by Probation OfficerSignature of the
Probation Officer/Case WorkerForm V[Rules 15(5) and 92 (2)]Undertaking/bond to be Executed a
Parent/guardian/ Relative/fit Person Whose Care a Juvenile is PlacedWhereas I ..............................
being the parent, guardian, relative or fit person under whose care ......................................... (name
of the juvenile) has been ordered to be placed by the Juvenile Justice Board
.............................................................. have been directed by the said Board to execute an
undertaking/bond with surety in the sum of Rs. .............../- (Rupees
.........................................................................) or without surety. I hereby bind myself on the said
........................................... or being placed under my care. I shall have the said
............................................ properly taken care of and I do further bind myself to be responsible for
the good behaviour of the said ........................................................... and to observe the following
conditions for a period of ......................................... years w.e.f.................................................Bihar Juvenile Justice (Care and Protection of Children) Rules, 2015

1. that I shall not charge my place of residence without giving previous
intimation in writing to the Juvenile Justice Board through the Probation
Officer/Case Worker;
2. that I shall not remove the said juvenile from the limits of the jurisdiction of
the Juvenile Justice Board without previously obtaining the written
permission of the Board;
3. that I shall send the said juvenile daily to school/to such vocation as is
approved by the Board unless prevented from so doing by circumstances
beyond my control;
4. that I shall send the said juvenile to an Attendance Centre regularly unless
prevented from doing so by circumstances beyond my control;
5. that I shall report immediately to the Board whenever so required by it;
6. that I shall produce the said juvenile in my care before the Board, if he/she
does not follow the orders of Board or his/her behaviour is beyond control;
7. that I shall render all necessary assistance to the probation Officer/Case
Worker to enable him to carry out the duties of supervision;8. in the event of
my making default herein, I undertake to produce myself before the Board for
appropriate action or bind myself, as the case may be, to forfeit to
Government the sum of Rs .................... (Rupees
.......................................................................).
Dated this ........................................... day of ...........................20.Signature of person executing the
Undertaking/Bond.(Signed before me)Principal Magistrate, Juvenile Justice BoardAdditional
conditions, if any, by the Juvenile Justice Board may be entered numbering them properly;(Where a
bond with sureties is to be executed add)I/We....................................................of
....................................... (Place of residence with full particulars) hereby declare myself/ourselves as
surety/sureties for the aforesaid ...........................(name of the person executing the
undertaking/bond) to adhere to the terms and conditions of this undertaking/bond. In case of
....................................(name of the person executing the bond) making fault therein, I/We hereby
bind myself/ourselves jointly or severally to forfeit to government the sum of Rs. ................/-
(Rupees .........................................................................) dated this the .............. day of
...........................20 .................... in the presence of ........................................................................
.Signature of Surety(ties)(Signed before me)Principal Magistrate, Juvenile Justice BoardForm
VI[Rules 15(6) And 92 (2)]Personal Bond By Juvenile/childPersonal Bond to be singed byBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

juvenile/child who has been ordered under Clause .............................................................. of
Sub-Section.................................... of Section ...........................of the Act.Whereas, I
................................................ inhabitant of ..................... (give full particulars such as house
number, road, village/town, tehsil, district, state) ............................................... have been ordered to
be sent back/restored to my native place by the Juvenile......................................................Justice
Board/ Child Welfare Committee ...................................................... under Section ............................
of the Juvenile Justice (Care and Protection of Children) Act, 2000 on my entering into a personal
bond under sub rule .................. of Rule ............. and sub rule .......... of Rule ........... of these Rules to
observe the conditions mentioned herein below. Now, therefore, I do solemnly promise to abide by
these conditions during the period ..................................................I hereby bind myself as follows:
1. That during the period ...................... I shall not ordinarily leave the village/
town/district to which I am sent and shall not ordinarily return to
...................... or go anywhere else beyond the said district without the prior
permission of the Board/Committee;
2. That during the said period I shall attend school/vocational training in the
village/town or in the said district to which I am sent;
3. That in case of my attending school/vocational training at any other place
in the said district I shall keep the Board/Committee informed of my ordinary
place of residence.
I hereby acknowledge that I am aware of the above conditions which have been read over/explained
to me and that I accept the same.(Signature or thumb impression of the juvenile/child)Certified that
the conditions specified in the above order have been read over/explained to (Name of
Juvenile/Child)........................................... and that he/she has accepted them as the conditions
upon which his/her period of detention/placement in safe custody may be revoked. Certified
accordingly that the said juvenile/child has been released/relieved on the ........................................
.Signature and Designation of the certifying authorityi.e. Officer-in-charge of the institutionForm
VII[Rule 17(9)]Discharge OrderI .............................................name and designation of the
discharging authority ......................................................................... State Government/Union
Territory Administration, do by this order permit ......................................................................
son/daughter of ..................................................... residence ................................... Profile Number
..................................... Who was ordered to be detained/placed in a observation home/special
home/after care home by the Juvenile Justice Board ........................ under section ...... of the
Juvenile Justice (Care and Protection of Children) Act, 2000, for a term of .................. on the
............. day of ...............20......... and who is now in the .............. home, at ..................... to be
discharged from the said ............................ home and supervision and the authority of
............................................ during the remaining period of stay.This order is granted subject to the
conditions hereon, upon the breach of any of which it shall be liable to be revoked.Bihar Juvenile Justice (Care and Protection of Children) Rules, 2015

Dated Signature and Designation of ReleasingAuthority.
Place:  
Conditions:
1. The discharged person shall proceed to ............................................... and
live under the supervision and authority of ........................................... until the
expiry of the period of his/her detention unless the remission is sooner
cancelled.
2. He/She shall not, without the consent of the ..................................... remove
himself/herself from that place or any other place, which may be named by
the said ..............................................................
3. He/She shall obey such instruction as he/she may receive from the said
.............................................. with regard to punctual and regular attendance at
school/vocation or otherwise.
4. He/She shall attend the Attendance Centre located at ............................
regularly.
5. He/She shall abstain from committing any offence and shall lead a sober
and industrious life to the satisfaction of ..............................................
6. In the even of his/her committing a breach of any of the above conditions
the remission of the period of detention hereby granted shall be liable to be
cancelled and on such cancellation he/she shall be dealt with under sub
section (3) of section 59 of the Juvenile Justice (Care and Protection of
Children) Act, 2000.
I hereby acknowledge that I am aware of the above conditions which have been read over/explained
to me and that I accept the same.(Signature or mark of the released juvenile)Certified that the
conditions specified in the above order have been read over/explained to (Name of
Juvenile/child).......................................... and that he/she has accepted them as the conditions upon
which his/her period of detention may be revoked.Certified accordingly that the said juvenile/child
has been discharged on the .................................................Signature and Designation of the
certifying authorityi.e. Officer-in-charge of the institutionForm VIII[Rule 27(18)]Supervision
OrderWhen the Child is placed under the case of a parent/guardian or other fit person Case No.
..............................of ....................................20.....Whereas (name of the child)
..................................................... has this day been found to be in need of care and protection, and
has been placed under the care and supervision of (name) ............................................... (address)Bihar Juvenile Justice (Care and Protection of Children) Rules, 2015

................................................... on executing a bond by the said ...........................................................
and the Committee is satisfied that it is expedient to deal with the said child by making an order
placing him/her under supervision.It is hereby ordered that the said child be placed under the
supervision of (name) ...........................................(address) ................................. ....................... for a
period of ............................ subject to the following conditions that:
1. the child along with the copies of the order and the bond, if any, executed
by the said ............................................ shall be produced before the
Committee as and when required by the person executing the bond.
2. the child shall be placed under the supervision of the aforesaid
parent/guardian/fit person
3. the child shall reside at .................................. for a period of ...............
4. the child shall not be allowed to quit the district jurisdiction of
...........................within the permission of the Committee.
5. the child shall go to school regularly/endeavour to earn an honest
livelihood.
6. the person under whose care the child is placed shall arrange for the
proper care education and welfare of the child.
7. the child shall not be allowed to associate with undesirable characters and
shall be prevented from coming in conflict with law.
8. the child shall be prevented from taking narcotic drugs or psychotropic
substances or any other intoxicants.
9. the directions given by the Committee from time to time, for the due
observance of the conditions mentioned above, shall be carried out.
Dated this ............................day of .............................20....................(Signature)Chairperson, Child
Welfare Committee• Additional conditions, if any may be inserted by the Child Welfare
CommitteeForm IX[Rules 27(18) and 92(2)]Undertaking By The Parent Or 'Fit Person' To Whom
Child Is RestoredI ...................................................... resident of House no. ................................
Street ....................... Village/Town ....................... District ....................... State ............................ Do
hereby declare that I am willing to take charge of (name of the child) ...........................................Aged
............. under the orders of the Child Welfare Committee .................................... subject to the
following terms and conditions:(i)If his/her conduct is unsatisfactory I shall at once inform theBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

Committee.(ii)I shall do my best for the welfare and education of the said child as long as he/she
remains in my charge and shall make proper provision for his/her maintenance.(iii)In the event of
his/her illness, he/she shall have proper medical attention in the nearest hospital.(iv)I undertake to
produce him/her before the competent authority as and when required.Date this ....................day of
.....................SignatureSignature and address of witness (es)(Signed before me)Chairperson, Child
Welfare CommitteeForm X[Rule 27 (19)]Order of Short Term Placement Pending Inquiry
Name of the child : 
Sex : 
Father's Name : 
Mother's Name : 
Address : 
Date of receiving by Organization/Institution : 
Produced by : 
This is to authorize and direct you to receive the said child in your charge, and keep her/him in the
Shelter Home/Children's home for care and protection under section 33 (1) of the Juvenile Justice
(Care and Protection of Children) Act, 2000.Next Date:(Signature)Chairperson/MemberChild
Welfare CommitteeForm XI[Rule 27(20)]Order Of Restoration Of A Child To An InstitutionToThe
Officer-in-ChargeWhereas on the ............................... Day of ........................20 ......... (name of the
child) ......................................................., son/daughter of ....................................... aged .........
residing at ...................................................................................... being in care and protection under
section 33 (4) of the Juvenile Justice (Care and Protection of Children) Act, 2000 is ordered by the
Child Welfare Committee ....................................................., to be kept in the children's
Home/Shelter Home ............................................................. for a period of ..................................
.This is to authorize and require you to receive the said child in your charge, and to kept him/her in
the Children's Home/Shelter Home ............................... for the aforesaid order to be carried into
execution according to law.Given under my hand and the seal of Child Welfare Committee.This
..........................day of .......................................20.(Signature)Chairperson/MemberChild Welfare
CommitteeEncl:Copy of the orders, particulars of home and previous record, case-history and
individual care plan, whichever is applicable:Form XII[Rule 28 (1)]Order For EnquiryToChild
Welfare Officer/Person in charge of Voluntary Organization/Social Worker/Case
Worker________________________________________________________________________________________Whereas
a report under section .......................... of the Juvenile Justice (Care and Protection of Children) Act,
2000 has been received from ........................................... in respect of (name of the child)
.....................................aged (approximate), ......................., son/daughter of
....................................residing at..................................................., who has been produced before the
Committee under section .......................... of the Juvenile Justice (Care and Protection of Children)
Act, 2000.You are hereby directed to enquire into the social and family background of the said child
and submit your inquiry report on or before ................................ or within such time allowed to you
by the Committee.You are also hereby directed to consult an expert in child psychology, psychiatric
treatment or counselling for their expert opinion if necessary and submit such report along with
your Inquiry Report.You are hereby directed to enquire into the character and social antecedents of
the said juvenile and submit your social investigation report on or beforeBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

............................................................................................... or within such time allowed to you by the
Board/Committee.Dated this ............................day of ..............................
20.............(Signature)Chairperson/MemberChild Welfare CommitteeSealForm XIII[Rules 28(3);
33(3) (h)(ii); and 33(4)(f); 80(1)(a) and (2)]Format For Inquiry Report
Sl. No.............................
Produced before the Child WelfareCommittee........................(address)
Case No.
Concerned Government Department/VoluntaryOrganisation
Category of child in need of care andprotection:
Name Religion
Father's Name Caste
Permanent Address Year of birth
Address of last residence Age Sex
Previous institutional/case history andindividual care plan, if any
Family
Members of family Name Age Health Education OccupationMonthly
earningsDisabilitiesAny other
e.g. Social
habits
Father         
Step- Father         
Mother         
Stepmother         
Siblings         
Any other legal
guardian/ relative        
If married, relevant particularsOther near relatives or agencies
interested_______________________________________________________________Attitude
towards religion, normal and ethical code of the home
etc._______________________________________________________Social and
economic
status___________________________________________________________Delinquency
record of members of family____________________________________________Present
living
conditions_____________________________________________________________Relationship
between parents/parents and children especiallywith the said
child__________________________________________________________________Other
factors of importance if
any_____________________________________________________Child's
HistoryMental condition(Present and past)_________________________________
_________________________________Physical condition(Present and
past)___________________________Bihar Juvenile Justice (Care and Protection of Children) Rules, 2015

_______________________________________Habits, interests(moral, recreational
etc)_______________________
______________________________________Outstanding characteristics and Personality
traits_______________________________________________________________________________________Companions
and their
influence_______________________________________________________Truancy
from home, if
any____________________________________________________________________________School
(attitude towards school, teachers, class mates and
vice-versa_____________________________________________________________________Work
record (jobs held, reasons for leaving Vocational interests, attitude towards job or
employers)_____________________________________Neighbourhood and neighbour's
report_______________________________________Parent's attitude towards discipline
In the home land child's
reaction___________________________________________________________Any
other remarksResult of InquiryEmotional factorsPhysical conditionIntelligenceSocial and economic
factorsReligious factorsReasons for child's need for care and protectionOpinion of experts
consultedRecommendation of Child Welfare Officer/Case-Worker/Social Worker regarding
psychological support, rehabilitation and reintegration of the child and suggested planSignature of
the Child Welfare Officer/Case Worker/Social WorkerForm XIV[Rule 33 (3) (d)]Order For
Declaring Child Legally Free For Adoption
1. In exercise of the powers vested in the Child Welfare
Committee____________ constituted under sub-section______ of
section_____ of the Juvenile Justice (Care and Protection of Children) Act,
2000 and sub-rule____ of rule___ of these rules, minor
_____________________ born on (date) ________ placed in custody of
Specialised Adoption Agency (name & address) ___________________,
_______________________ vide order ___________ dated ____________ of
the Chairperson, Child Welfare Committee __________________________,
has been declared legally free for adoption on the basis of details furnished
through:
(a)Inquiry/home study conducted by Child Welfare Officer/Social Worker/Case-
Worker(b)Document of surrender executed by the parents(s) and surrender deed signed in the
presence of the Committees under sub-rules__________ of rule______ of these
rules.(c)Declaration submitted by the specialised Adoption agency under sub-rules____ of rule
______ of these rules.Bihar Juvenile Justice (Care and Protection of Children) Rules, 2015

2. _____________________________________ (name of the Specialised
Adoption Agency) shall fulfill all conditions specified in Juvenile Justice
(Care and Protection of Children ) Act, 2000 and the rules relating thereto and
furnish a copy of adoption decree/guardianship order in respect of the minor
as may by required by Committee and the concerned Department of the State
Government of _________.
Date:  
Place: Chairperson/MemberChild Welfare Committee
For completion by the Specialised Adoption Agency.i. I have read and understood Chapters III and
IV of Juvenile Justice (Care and Protection of Children) Act, 2000 and the rules thereunder and
agree to abide/be bound by the same while placing said minor in adoption.ii. I further declare that
the particulars stated in the declaration submitted by me on ________________ are true and
correct. In case they are found to be false or incorrect, the Committee has right to suspend this
Release Order for (name of the minor)_______________ and ask for production of said minor
before the Committee.
Date:  
Place: Child Welfare Officer/Social Worker
Form XV[Rule 33 (4) (c)]Deed Of
SurrenderI______________________________________d/o or
s/o__________________________________ residing at
____________________________________________________________________
am not in a position due to social reasons/due to being single/ill/disabled to take care of my child
(name, if any) ________________________________ approximate age__________ years.
I am explained the consequences of surrendering my child by the Child Welfare Officer/Social
Worker (name) ________________ and the Child Welfare Committee ___________ . In full
knowledge of all these facts, I am surrendering my child before the Committee today, dated
_____________. Within two months from this stated date if I do not revise my decision to take
back my child and do not approach the said Committee for the same, the Committee shall declare
my child legally free for adoption and I shall have no further claim on my child.Signature of
parent/guardianDateThat I _______________________________ Child Welfare
Officer/Social Worker have explained the procedure and the consequences of surrendering the child
to the concerned parent/guardian on (date) ___________.Signature of Child Welfare
Officer/Social workerDate(Signed before me)Chairperson/MemberChild Welfare CommitteeForm
XVI[Rule 35 (3)]
A.Foster Carer's Assessment  
1.Agency Details  
 Name of the Agency  
 Address  
 Telephone  
 Fax  Bihar Juvenile Justice (Care and Protection of Children) Rules, 2015

 E-mail  
 Name of the Social Worker  
 Tel  
 Date__________________ (Form Completed)  
2.Details of the Applicant  
 Surname  
 Full Name  
 Date of Birth  
 Religion  
 Language (s) spoken at home  
 Occupation  
 (a) Nature of Work  
 (b) Hours of WorkAddressTelephone  
3.Description of a preferred childThe type of child, the
foster-carer would consider (To befilled after a full discussion
with the Foster-carer) 
 Age RangeUnder 2
years3-6
years7-12
years16-18
years
Sl. No. Type of placement Duration
(i) Pre adoption  
(ii) Emergency  
(iii) Short term  
(iv) Assessment  
(v) Long term  
The Child an applicant can care for (pleaseTick)
A child who is:
i. Neglected
ii. Orphaned
iii. With Physical impairment
iv. Mental impairment
v. Hearing impairment
vi. Speech impairment
vii. Special Education needs
viii. Learning difficulties
ix. Physical abuse
x. Sexual abuse
xi. Who does not relate easily
xii.Bihar Juvenile Justice (Care and Protection of Children) Rules, 2015

Who needs control/may defy
authority
xiii. Born of rape/incest
xiv.Whose parent (s) is suffering from
disease
xv. Whose parent (s) is HIV positive
xvi. Whose parent (s) are AIDS patient
xvii. Whose parent (s) is alcoholic
xviii. Drug addicts
xix. Are in jail
xx. Relinquished
xxi. Belong to another caste
xxii. Are of different religion
4. Profile of the family
Brief Family Profile
Name Gender Approx.Age Occupation Education Relationship with the applicant
      
      
      
(Give details of personalities, family life, experiences etc, Also highlight specific qualities of the
family that can match with a child's needs. The details should facilitate initial identification of a
potential match with a specific child.) Accommodation (House) (Details of type, size, own/ rented
space, amenities etc.) Neighbourhood (Details of composition, amenities and facilities, public
transport etc.)
5. Verification of applicant's identity
Place of residencePeriod of stayNationalityMarital status (date/length of marriage)Has either of the
applicant had a previous marriage? DetailsIf children from previous marriage? DetailsSpecify
documents seen with date
6. Career History
(Details of education, employment, voluntary work, part-time work, leisure activities)
7. Agency Inquiries:
Medical checkPolice checkEmployerBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

8. Personal references (from 2 persons)
This section to be completed after interviews with two references; information gathered through
these interviews should include:• Length of time known• Relationship to the applicant• Provide
evidence on the applicant's ability to perform the tasks involved in____• Caring for children•
Providing a safe and caring environment• Applicant as a neighbour• Interests, talents,
personalityAssessment of the social worker for these referencesB. Home Study ReportA Home Study
Report of the foster carer(s) being a crucial document being prepared by the social worker of the
Specialised Adoption Agency based on the information collected by the format given above should
broadly include the following information:• Social Status and family background• Description of the
home• Standard of living as it appears in the home• Current relations amongst the members in the
home• Status of development of the children already in the home• Employment and economic
status• Health details• Details of facilities of education, medical, vocational trainings available in the
neighbourhood• Reasons for wanting a child in foster care• Attitudes of the grandparents and other
relatives• Anticipated plans for the foster child• Legal status of the foster carer(s)• Willingness to
undergo trainingC. Details Of Applicant(S)
1. Background. - Family structure with details of parents and siblings,
significant details of other family members, childhood experiences, etc.
2. Relationship. - If couple- Length of married life, what qualities does each
applicant bring to the partnership, what makes the relationship positive for
each other? Within the relationship how do applicants cope with
problems/stress/anger? How do applicants support each other? What is each
applicant's assessment of how the Foster placement will affect his or her
relationship?
3. Decision making. - How is decisionmaking exercised in this relationship
and how does each of the applicants view this? Is there wider extended
family involvement in the couple's decision making process? If so, how will
this affect the child to be placed?
What are the strengths and vulnerabilities of this partnership?• Children• Children and their
parents' relationships• Children's attitude and readiness for a foster placement sibling. Describe
each child and their temperament, any special talent and need, how children have been involved in
preparation etc.
4. Applicants support networks. - Give a general picture of support systems
currently used by the applicants including expended family, friends,
neighbours, religious activities, community groups etc. including details of
the location etc.Bihar Juvenile Justice (Care and Protection of Children) Rules, 2015

5. Other significant members of the family. - Living in the house or not. Their
relationship to the applicants, how much time they spent within the home,
their attitude to the proposed placement. How important is their acceptance
of placement to the applicants.
6. Description of the family life style. - Outline what family considers
important e.g. how important are religious and cultural practices. How is
affection show in the family? How do the members spend their time? What
expectations family members have with regard to personal space? What
value is placed on education/hobbies and leisure activities that the whole
family undertakes?
7. Parenting capacities. - Experience of the applicants of caring and working
with children. Describe their adjustment to parenthood. What is their
understanding of how children develop?
Using their own childhood experiences what patterns of parenting would they repeat and what
would they change? What is their understanding of their own parenting strengths/potentials and
about their parenting skills to meet the needs of individual child? To what extent they would expect
other family members to be involved in parenting of their children/placed children.How will they
ensure that a child will be safe from physical sexual abuse in their family and within wider support
networks?
8. Managing Unacceptable Behaviour. - What are the rules in the household?
How do the applicants show approval/disapproval? What are the discipline
measures that they use? Their attitude towards punishment?
What do they anticipate would be the issues and difficulties for themselves and for their own
children and for their support network? What do they anticipate would be the issues and difficulties
for the child? Which changes do they anticipate would be needed in their lifestyle?Social Workers
assessment. - It should provide an analysis of all the information collected through the format and
its significance with regard to the capacity of the applicant to carryout fostering task:(What skills do
the applicants have in relating to and working with children? How well will the applicant work with
the agency, with biological parents? What are the strengths and resources of the applicants and
which are the areas where they may experience difficulty? Also the point of disagreement between
the social worker and the applicants should be recorded here.)Recommendations of the Child
Welfare Officer/Social Worker(Signature)Form XVII[Rule 34 (1)]Order Of Foster Care
PlacementThe child (name and address)________________
______________________________ approximate age __________ d/o or s/o Mr.
___________________________________ and Mrs.
___________________________ or Ms. _____________________________ is in needBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

of care and protection of a family. Mr. _______________________________ and Mrs.
__________________________ or Ms.______________________________ resident of
(complete address and contact numbers)______________________________
________________________________________________________ is/are declared fit
person/persons for foster-care placement of the child based on the home study report of the Child
Welfare Officer/Social Worker Ms./Mr.______________________________ of the
organization (address)______________________________________________.The child
(name) _______________________________________ is placed in foster care for a period
of _____________________________ (days/months), under the supervision of the aforesaid
Child Welfare Officer/Social Worker (name and contact)
____________________________.Chairperson/MemberChild Welfare CommitteeForm
XVIII[Rule 43 (5)]Order Of Sponsorship PlacementThe juvenile/child (name and address)
________________________________________ approximate age _____________d/o
or s/o Mr. _____________________________ and Mrs. _____________________ or
Ms. _______________________________________ has been identified by the
State/District Child Protection Unit as a juvenile/child at risk needing urgent care and protection.
On the basis of the Inquiry Report submitted by the State/District Child Protection Unit/Child
Welfare Officer/Social Worker it is established that the said juvenile/child needs sponsorship
support for education/health/nutrition/other developmental
needs__________________________________ (please specify). The State/District Child
Protection Unit is hereby directed to release Rs. ______ per month/Rs._______ as one time
sponsorship support to the said juvenile/child for a period of _________ (days/month) and
carryout necessary follow up.State/District Child Protection Unit is also directed to clearly lay down
the terms and conditions for sponsorship support and follow up.Pricipal Magistrate, Juvenile
Justice Board/Chairperson/Member, Child Welfare CommitteeCopy to: State/District Child
Protection Unit or concerned Department of the State GovernmentForm XIX[Rule 44(4)]Order Of
After Care PlacementThe juvenile/child (name)
______________________________________________d/o or s/o
______________________________ has /will be completing 18 years of age on
(date)__________. She/he is still in need of care and protection for the purpose of rehabilitation
and reintegration. She/he is placed in (name of organization) ______________ for providing
aftercare. The in-charge of the organization is directed to admit the child and providing all possible
opportunities for her/his rehabilitation and reintegration in its truest sense. The person shall be
provided all these opportunities maximum till the age of 21 years only or till reintegration in the
society, whichever is earlier. The in-charge will send half yearly report on the status of the
child/youth to the Child Welfare Committee.The State/District Child Protection Unit is hereby
directed to arrange for aftercare for the said juvenile/child for a period of _______ (days/month)
and carryout necessary follow up. The State/District Protection Unit is also directed to clearly lay
down the terms and conditions for aftercare programme and carryout necessary follow up.Principal
Magistrate, Juvenile Justice Board/Chairperson/Member, Child Welfare CommitteeCopy to:
State/District Child Protection Unit or concerned Department of the State GovernmentForm
XX[Rule 57(8) and 61(1) (t)]Case History Form For Children In Need Of Care Fand Protection
   Bihar Juvenile Justice (Care and Protection of Children) Rules, 2015

Case/Profile No.
_______________
Date & Time
_________________
A. Personal Data
1. Name
2. Male/Female (tick the appropriate category)
3. ( a) age at the time of admission  
 (b) present age:  
4. Category:  
 • Separated from family  
 • Abandoned/deserted  
 • Victim of exploitation and violence (givedetail)  
 • Run-away  
 • Any other  
5. Religion Hindu(OC/BC/SC/ST)  
  Muslim/Christian/Other(pl.
specify) 
6.Location of
ResidenceUrban/Sub-urban/Rural/Slum/industrial/Other
(pl. specify)
7. Native District & State:
8. Description of the Housing:
 (i) Concrete building Tiled house/Hut/On
thestreet/Others (please specify)
 (ii) Three bed room/two-bed room/one-bed
room/noseparate bed room
 (iii) Owned/rental
9.By whom the juvenile was brought before
theChild Welfare Committee:
 (i) Police-Local Police/Special Juvenile
PoliceUnit/Railway Police/Women Police
 (ii) Probation Officers
 (iii) Social Welfare Organization
 (iv) Social Worker
 (v) Parent (s)/Guardian (s) (please specify
therelationship)
 (vi) Child himself/herself
10. Reasons for leaving the familyBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

 (i) Abuse by parent(s) guardian(s)
/stepparents(s)
 (ii) In search of employment
 (iii) Peer group influence
 (iv) Incapacitation of parents
 (v) Criminal behaviour of parents
 (vi) Separation of parents
 (vii) Demise of parents
 (viii) Poverty
 (ix) Others (please specify)
11. Types of abuse met by the child
 (i) Verbal abuse
–Parents/siblings/employers/others (pl.
specify)
 (ii) Physical abuse
 (iii)
Sexualabuse-Parents/siblings/employers/others
(pl. specify)
 (iv) Others –Parents/siblings/Employers/others
(pl. specify)
12. Types of ill-treatment met by the child.
 (i) Denial of food
–parents/siblings/employers/other(pl. specify)
 (ii) Beaten
mercilessly–parents/siblings/employers/other
(pl. specify)
 (iii) Causing injury
–parents/siblings/employers/other (pl. specify)
 (iv) Other parents/siblings/employers/other
(pl.specify)
13. Exploitation faced by the child
 (i) Extracted work without payment
 (ii) Little (low) wages with longer duration
ofwork
 (iii) Other (pl. specify)
14. Health status of the child before admission.
 (i) Respiratory disorders -present/not
known/absent
 (ii) Hearing impairment - present/notBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

known/absent
 (iii) Eye diseases -present/not
known/absent
 (iv) Dental disease -present/not
known/absent
 (v) Cardiac diseases -present/not
known/absent
 (vi) Skin disease -present/not
known/absent
 (vii) Sexually transmitted diseases -present/not
known/absent
 (viii) Neurological disorders -present/not
known/absent
 (ix) Mental handicap -present/not
known/absent
 (x) physical handicap -present/not
known/absent
 (xi) Other (pl. specify) -present/not
known/absent
15.With whom the child was staying prior
toadmission
a. Parent(s) – Mother/Father/Both
b. Guardian(s) – Relationship
c. Friends
d. On the street
e. Night shelter
f. Orphanages/Hostels/Similar Homes
g. Other (pl. specify)
16. Visit of the parents to meet the child
a.Prior to institutionalization
–Frequently/Occasionally/Rarely/Never
b.After institutionalization
–Frequently/Occasionally/Rarely/Never
17. Visit of the child to his family
a.Prior to
institutionalization–Frequently/Occasionally/Rarely/During
festival times/Duringsummer
holidays/Whenever fallen sick/Never
b. After institutionalization
–Frequently/Occasionally/Rarely/DuringBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

festival times/Duringsummer
holidays/Whenever fallen sick/Never
18. Correspondence with parents –
 (i) Prior to institutionalization
–Frequently/Occasionally/Rarely/During
festival times/Duringsummer
holidays/Whenever fallen sick/Never
 (ii) After institutionalization
–Frequently/Occasionally/Rarely/During
festival times/Duringsummer
holidays/Whenever fallen sick/Never
B. Childhood History (up to the age of 12years)
19. Diet of Mother during pregnancy
a. Taken nutritious diet  
b. Ordinary diet  
c. Inadequate food intake  
20. Health during pregnancy
a. Mother infected with contagious diseases  
b. Mother consumed/used contraceptives  
c. Intake of antibiotics  
d. No such details available  
e.   
21. Birth details
a. Normal delivery/prolonged delivery/caesarian
b. Under weight/normal weight/over weight
22. Details of immunization provided  
23. Details of handicap/disability  
 (i) Hearing impairmentBy birth/After
accident/diseases
 (ii) Speech impairmentBy birth/After
accident/diseases
 (iii) Physical handicap/disabilityBy birth/After
accident/diseases
 (iv) Mental Handicap/disabilityBy birth/After
accident/diseases
 (v) Other (Please specify)  
C. Family Details
24. Household Composition
S. No. Name & Relationship Age Sex Education Occupation IncomeBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

1 2 3 4 5 6 7
       
Health History of Mental illness Handicap/Disability Habit Socialization
8 9 20 11 12
     
25. Type of family.- Nuclear family /Joint family/ Broken family
 (i) Father & MotherCordial/ Non cordial/ Not
known
 (ii) Father & ChildCordial/ Non cordial/ Not
known
 (iii) Mother & ChildCordial/ Non cordial/ Not
known
 (iv) Father & SiblingsCordial/ Non cordial/ Not
known
 (v) Mother & SiblingsCordial/ Non cordial/ Not
known
 (vi) Juvenile & SiblingsCordial/ Non cordial/ Not
known
26. Relationship among the family members:
27. History of crime committed by family members:
Sl. No. RelationshipNature of
crimeArrest if any
madePeriod of
confinementPunishment
awarded
1. Father     
2. Step-father     
3. Mother     
4. Step-mother     
5. Brother(a)(b)(c)(d)     
6. Sister(a)(b)(c)(d)     
7. Child     
8.Others (uncle/aunty/
grandparents)    
28. Properties owned by the family:
 (i) Landed properties (pl.specify the area)
 (ii) Household articles-Crows/cattle/Bull
 (iii) Vehicles-two wheeler/three wheeler/four
wheeler(lorry/bus/car/tractor/jeep)
 (iv) Others (please specify)
29 . Marriage details of family members:
 (i) Parents Arranged/Special Marriage/Local UnionBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

 (ii) Brothers Arranged/Special Marriage/Local Union
 (iii) Sisters Arranged/Special Marriage/Local Union
30. Social activities of family members:
 (i) Participate in social and religious functions
 (ii) Participate in cultural activities
 (iii) Does not participate in social and religious function
 (iv) Not known
31. Parental care towards juvenile beforeadmission:
 (i) Over protection
 (ii) Affectionate
 (iii) Attentive
 (iv) Not affectionate
 (v) Not attentive
 (vi) Rejection
D. Adolescence History (Between 12 and 18 years)
32. puberty
 Early
 Middle age
 Late
33. Details of delinquent behaviour if any
 (i) Stealing
 (ii) Pick pocketing
 (iii) Arrack selling
 (iv) Drug pedalling
 (v) Petty offences
 (vi) Violent crime
 (vii) Rape
 (viii) None of the above
 (ix) Others (Please specify)
34. Reason for delinquent behaviour
 (i) Parental neglect
 (ii) Parental overprotection
 (iii) Parents criminal behaviour
 (iv) Parents influence (negative)
 (v) Peer group influence
 (vi) To buy drugs/ alcohol
 (vii) Others (pl.specify)Bihar Juvenile Justice (Care and Protection of Children) Rules, 2015

35. Habits
 A B
 (i) Smoking (i) Watching TV/movies
 (ii) Alcohol consumption (ii) Playing indoor/outdoor games
 (iii) Drug use (specify) (iii) Reading books
 (iv) Gambling (iv) Religious activities
 (v) Begging(v)
Drawing/painting/acting/singing
 (vi) Any other (vi) Any other
E. Employment Details
 Employment details of the juveniles prior toentry into the
Home:
S. No. Details of employment Duration Wages earned
(i) Cooly   
(ii) Rag picking   
(iii) Mechanic   
(iv) Hotel work   
(v) Tea shop work   
(vi) Shoe Polish   
(vii) Household works   
(viii) Others (Pl specify)   
36. Details of income utilization:
 (i) Sent to family to meet family need
 (ii) For dress materials
 (iii) For gambling
 (iv) For prostitution
 (v) For alcohol
 (vi) For drug
 (vii) For smoking
 (viii) Savings
37. Details of savings
 (i) With employers
 (ii) With friends
 (iii) Bank/post Office
 (iv) Others (pls specify)
38. Duration of working hours
 (i) Less than six hoursBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

 (ii) Between six and eight hours
 (iii) More than eight hours
F. Educational Details
39.The details of education of the juvenileprior to the admission to
Children's Home
 (i) Illiterate
 (ii) Studied up to V Standard
 (iii) Studied above V Std but below VIII Standard
 (iv) Studied above VIII Std but below X Standard
 (v) Studied above X Standard
40. The reason for leaving the school
 (i) Failure in the class last studied
 (ii) Lack of interest in the school activities
 (iii) Indifferent attitude of the teachers
 (iv) Peer group influence
 (v) To earn and support the family
 (vi) Sudden demise of parents
 (vii) Rigid school atmosphere
 (viii) Absenteeism followed by running away from school
 (ix) Other (pls specify)
41. The details of the school in which studiedlast:
 (i) Corporation/Municipal/Panchayat Union
 (ii) Government/SC welfare School/BC Welfare School
 (iii) Private management
 (iv) Convents
42. Medium of instruction:
 Hindi/English/Urdu/Tamil/Malayalam/Kannada/Telugu Other
language (please specify)
43.After admission to Children's Home, theeducational attainment
from the date of admission till date:
 No. of years Class studiedPromoted/
detained
44.Vocational training undergone from the dateof admission into
Children's Home till date.
 No. of yearsName of
Vocational
TradeProficiency
Attained
45. Extra curricular activities developed formthe date of admissionBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

into the Children's Home till date.
 (i) Scout
 (ii) Sports (please specify)
 (iii) Athletics (please specify)
 (iv) Drawing
 (v) Painting
 (vi) Others (pl.specify)
G. Medical History
46. Height and weight at the time of admission:-
47. Physical condition:
48. Medical History of child (gist):
49. Medical History of parent/guardian (gist):
50. Present Health Status of the Child:
Sl. No. Annual Observation 1st Quarter 2nd Quarter 3rd Quarter 4th Quarter
1. Date of review     
2. Height     
3. Weight     
4. Nutritious diet given     
5. Stress disease     
6. Dental     
7. ENT-Tonsils     
8. External eye problem: vision     
Left     
Right     
51.Height and Weight Charr:
Date, Month & Year Height Admissible weight Actual weight
    
    
    
    
    
    
    
    
    
    
H.Social HistoryBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

52.Details of friendship prior to admission intoChildren' s Home:
 (i) Co-workers
 (ii) School/Classmate
 (iii) Neighbours
 (iv) Others (pl. specify)
53.Majority of the friends are
 (i) Educated
 (ii) Illiterate
 (iii) The same age group
 (iv) Older in age
 (v) Younger in age
 (vi) Same sex
 (vii) Opposite sex
54.Details of membership in group (pleasespecify details)
 (i) Associated with cine fans association
 (ii) Associated with religious group
 (iii) Associated with arts and sports club
 (iv) Associated with gangs
 (v) Associated with voluntary social service league
 (vi) Others (please specify)
55.The position of the child in thegroups/league
 (i) Leader
 (ii) Second level leader
 (iii) Middle level functionary
 (iv) Ordinary member
56.Purpose of taking membership in the group:
 (i) For social service activities
 (ii) For leisure time spending
 (iii) For pleasure seeking activities
 (iv) For deviant activities
 (v) Others (please specify)
57.Attitude of the group/league
 (i) Respect the social norms and follow the rules
 (ii) Interested in violating the norms
 (iii) Impulsive in violating the rules
58.The location/meeting point of the groups
 (i) Usually at fixed placeBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

 (ii) Places are changed frequently
 (iii) No specific places
 (iv) Meeting point is fixed conveniently
59.The reaction of the society when the childfirst came out of the family
 (i) Supportive
 (ii) Rejection
 (iii) Abuse
 (iv) Ill-treatment
 (v) Exploitation
60.The reaction of the police towards children
 (i) Passionate
 (ii) Cruel
 (iii) Abuse
 (iv) Exploitation
 (v) III-treatment
61.The response of the general public towardsthe child
 History Of The Child(Gist)
 (i) Education
 (ii) Health
 (iii) Vocational training
 (iv) Extra curricular activities
 (v) Others
 Suggestion of Child Welfare Officer/Probation Officer afterorientation to juvenile/child and the
response towardsorientation.
 Follow up by Child Welfare Officer/ProbationOfficer/Case-Worker/Social Worker Quarterly
Review of CaseHistory by Management Committee
Superintendent/Welfare Officer/probation OfficerForm XXI[Rules 57(11)(A), 61(1)(O) And
80(1)(K)]Individual Care Plan
Individual
care plan for
each child
shall
beprepared
following the
principle of
the best
interest of
thechild. In
preparing
individualBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

care plan the
care options
in
thefollowing
order of
preferences
shall be
considered:-
(i) Preserving the biological family
(ii) Kinship Care
(iii) In-country adoption
(iv) Foster Care
(v) Inter-country Adoption
(vi) Institutional Care
 Case/profile No...................of 20---------(year) of the Board/Committee Admission No.
 Date of Admission:
A. Personal Details
1. Name of the Child:
2. Age:
3. Sex: Male/Female
4. Father's/Mother's name:
5. Nationality:
6. Religion/Caste:
7. Educational attainment:
8. Summary of Case History:
 Health needs
 Emotional and psychological support needed
 Educational and Training needs
 Leisure, creativity and play
 Attachments and Relationships
 Religious beliefs
 Protection from all kinds of abuse, neglect and maltreatment
 Social mainstreaming
 Follow-up post release/restoration
B. Fortnightly Progress Report Of Probationer
Part One
1. Name of the Probation Officer/Case-Worker
2. For the month ofBihar Juvenile Justice (Care and Protection of Children) Rules, 2015

3. Registration No.
4. Competent Authority
5. Profile No.
6. Name of the Child
7. Date of Supervision Order
8. Address of the Child
9. Period of Supervision
Part Two
 Places
ofinterview......................................................................................................................................................Date......................................................................................................................................................
1. Where the child is residing?
2. Progress made in any educational/trainingcourse.
3. What work he/she is doing and his/her monthlyaverage earning, if employed.
4. Savings kept in the Post Office.
5. Savings Bank Account in his/her name.
6. Remarks on his/her general conduct and progress
7. Whether property cared for?
Part Three
1. Any proceedings before the competent authorityof or
 (a) Variation of conditions of bond
 (b) Change of residence
 (c) Other matters
2. Period of supervision completed on..........................................................
3. Result of supervision with remarks (if any)
4.Name and Addresses of the parent or guardian orfit person under whose care the juvenile is to live after
thesupervision is over.
 Date of report ____________Signature of theProbation Officer/Case Worker________
C. Pre-Release Report
 Tick whichever is applicable.
 Final Release {|
 
| Transfer| {||-||}|-| 1.| Details of place oftransfer and concerned authority responsible in the place
oftransfer/release|-| 2.| Details of placementof the juvenile/child in different institutions|-| 3.|
Training undergoneand skills acquired|-| 4.| Final progress reportof the officer-in-charge/probation
officer/ child welfareofficer/case worker/ social worker (to be attached)|-| 5.| Date
ofrelease/transfer|-| 6.| Date of repatriation|-| 7.| Requisition forescort if required|-| 8.|
Identification ofescort|-| 9.| Recommendedrehabilitation plan including possible placements|-| 10.|
Sponsorshiprequirement and report, if applicable|-| 11.| Identification ofProbation Officer/
Case-worker/ social worker/non-governmentalorganization for post-release follow-up|-| 12.|Bihar Juvenile Justice (Care and Protection of Children) Rules, 2015

Memorandum ofUnderstanding with non-governmental organization identified forpost-release
follow-up|-| 13.| Identification ofsponsorship agency/individual sponsor for the child post-release,if
any|-| 14.| Memorandum ofUnderstanding between the sponsoring agency and individualsponsor|-|
15.| Details of SavingsAccount of the child, if any|-| 16.| Details of child'searnings and belongings if
any|-| 17.| Details ofawards/rewards due to the child if any|-| 18.| Opinion of the child|-| 19.| Any
other information|-| Note:- Pre-releasereports shall be prepared 6 months prior to the date
ofrelease/transfer of juvenile/ child and shall take into accountthe recommendations of the last
review report and all otherrelevant information.|-| D .| Post-ReleaseReport|-| 1.| Status of
BankAccount: Closed/ Transferred|-| 2.| Earnings andbelongings of the child: handed over to the
child or his/herparents/guardians-Yes/ No|-| 3.| First interactionreport of the probation
officer/child welfare officer/ caseworker/social worker/non-governmental organisation identified
forfollow-up with the child post-release|-| 4.| Placement of thejuvenile/child if any|-| 5.| Family's
behaviourtowards the child|-| 6.| Social milieu of thechild, particularly attitude of neighbours/
community|-| 7.| How is the childusing the skills acquired?|-| 8.| Whether the child hasbeen
admitted to a school or vocation? Give date and name of theschool/ institute/ any other agency|-|
9.| Report of second andthird follow-up interaction with the child after two months andsix months
respectively|}Form XXII[Rule 73 (2)]Escort Order
Case No........................... In the matter of Boy/Girl Child
..........................................  
 Aged about .........year takenCharged for solecustody underSection 33(3)
of theJuvenileJustice Act 2000
The Parents of the boy/girl child are reported to be residing at:He/She therefore be sent under
supervision of a proper police/non-governmental organization escort to the
........................................................................................For tracing and for handing over to the
parents or close relatives of the said Boy Child/Girl Child residing at the aforesaid address or at
other place which may be shown by the Child, if no such parents or relative are traced or if traced
but they are unwilling to take charge of the boy/girl be kept in the custody of the Superintendent
............................................... Children's Home and the said Boy/Girl child be produced before the
concerned Child Welfare Committee for further orders.OrdersPending Escort, the said Boy/Girl
Child shall remain in Children's Home, residing at present at
............................................................................ The State/District Child Protection Unit, or Police
Department or non-governmental organization/Child line shall positively make immediate
arrangement not less than 15 days from the date of receipt of this order by him and send the said
Boy Child/Girl Child at his/her aforesaid place of residence.Dated this ..................................... day of
........................20........Chairperson/MemberChild Welfare CommitteeCC to:
1. The Superintendent, Children's Home,.
2. The State/District Child Protection Unit or non governmental organization
or Child line.
Ref.: 1. Order of admission of minor ................born on ................Profile No............Bihar Juvenile Justice (Care and Protection of Children) Rules, 2015

