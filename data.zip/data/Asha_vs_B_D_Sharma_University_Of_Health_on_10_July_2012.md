Asha vs B.D.Sharma University Of Health ... on 10 July, 2012
Equivalent citations: AIR 2012 SUPREME COURT 3396, 2012 (7) SCC 389,
2012 AIR SCW 4073, 2012 (5) AIR BOM R 340, (2012) 116 ALLINDCAS 13 (SC),
(2012) 5 ALL WC 5150, (2012) 4 ESC 513, (2012) 4 MAD LW 681, (2012) 5
SERVLR 379, (2012) 6 SCALE 287, (2012) 3 CIVILCOURTC 814, AIR 2012 SC
(CIV) 2370, (2012) 2 WLC(SC)CVL 464, (2012) 3 SCT 457, 2012 (19) ADJ 37
NOC, 2012 (95) ALR SOC 20 (SC)
Author: Swatanter Kumar
Bench: Ranjan Gogoi, Swatanter Kumar
                                                                             REPORTABLE
                        IN THE SUPREME COURT OF INDIA
                        CIVIL APPELLATE JURISDICTION
                       CIVIL APPEAL NO.  5055  OF 2012
                  (Arising out of SLP (C) No. 7440 of 2012)
Asha                                                       … Appellant
                                   Versus
Pt. B.D. Sharma University of Health
Sciences & Ors.                                            …Respondents
                               J U D G M E N T
Swatanter Kumar, J.
1. Leave granted.
2. Admission to the medical courses (MBBS and BDS) has been consistently a subject of judicial
scrutiny and review for more than three decades. While this Court has enunciated the law and put to
rest the controversy arising in relation to one facet of the admission and selection process to the
medical courses, because of ingenuity of the authorities involved in this process, even more complex
and sophisticated set of questions have come up for consideration of the Court with the passage of
time. One can hardly find any infirmities, inaccuracies or impracticalities in the prescribed scheme
and notifications in regard to the process of selection and grant of admission. It is the arbitrary and
colourable use of power and manipulation in implementation of the schedule as well as the
apparently perverse handling of the process by the concerned persons or the authorities involved, in
collusion with the students or otherwise, that have rendered the entire admission process faulty andAsha vs B.D.Sharma University Of Health ... on 10 July, 2012

questionable before the courts. It is the admissions granted arbitrarily, discriminately or in a
manner repugnant to the regulations dealing with the subject that have invited judicial catechism.
With the passage of time, the quantum of this litigation has increased manifold.
3. Thus, it is both the need of the hour and the demand of justice that this Court clarifies its decision
and states the principles with greater precision so as to ensure elimination of colourable abuse and
arbitrary exercise of power in the process of selection and admission to these professional courses
by all concerned.
4. Therefore, in our view, though the present appeal arises from very simple facts, yet it raises
questions of considerable importance and application. These questions are bound to arise
repeatedly not only before this Court, but even before the High Courts. Therefore, it is imperative for
us to formulate the questions and answer them in accordance with law.
5. The questions are :-
a) Is there any exception to the principle of strict adherence to the Rule of Merit for
preference of courses and colleges regarding admission to such courses?
b) Whether the cut-off date of 30th September of the relevant academic year is a date
which admits any exception?
c) What relief the courts can grant and to what extent they can mould it while
ensuring adherence to the rule of merit, fairness and transparency in admission in
terms of rules and regulations?
d) What issues need to be dealt with and finding returned by the court before passing
orders which may be more equitable, but still in strict compliance with the
framework of regulations and judgments of this court governing the subject?
6. The appellant cleared her Secondary examination (medical stream) with 75% marks and was
eligible for taking medical entrance examination as she fulfilled the requisite criteria to take that
exam. Pt. B.D. Sharma University (for short ‘the University’) issued a notification/advertisement for
the entrance examination for MBBS, BDS and BAMS to be held in the first week of May, 2011. The
appellant applied for the same in the Backward Class ‘B’ (for short ‘BCB’) and dependent of Ex-
Serviceman (ESM) category. Her application was accepted and roll number was issued to her. The
date of the examination was fixed for 12th June, 2011 by the University. The appellant was declared
successful in the entrance examination having secured 832 marks. The appellant was at serial
number 13 of the ESM category. All concerned were informed that the first counseling for allotment
of seats was to be held on 14th -15th July, 2011. In this counseling, the appellant was not admitted to
MBBS Course as she was lower in merit. Consequently, she took admission in the BDS Course on
that very day. Thereafter, a declaration was made by the respondents that the second counseling for
allotment of seats in the MBBS course would be held on 20th September, 2011. The appellant again
participated in the counseling but her name and roll number was not declared by the respondentsAsha vs B.D.Sharma University Of Health ... on 10 July, 2012

for the said admissions. However, when the list of allocation of seats was displayed, it came to light
that though the appellant had not been admitted to the MBBS Course, candidates who ranked below
her in the merit list, including the respondent no.3, Vineeta Yadav, who had obtained 821 marks and
was at serial number 14 of the ESM Category, had been given admission to the MBBS Course.
7. On the above facts, the learned Single Judge of the High Court of Punjab and Haryana at
Chandigarh, observed that according to the respondents, the ‘appellant left the counseling place’
without appearing before the Counseling Board. Resultantly, her candidature was not considered for
admission to the MBBS course under the ESM category and the candidate next in merit was given
the admission. It was the opinion of the Court that it would be too far fetched to accept that the
appellant, though was physically present at the time of taking of attendance, thumb impressions and
photography, did not respond to the call for counseling at the relevant time. Further, the Court
observed that no reason whatsoever could be seen for absence of the appellant at the relevant
moment from the record before the Court. In view of the fact that the appellant had filed the writ
petition within a week of the second counseling, the Court accepted the facts averred in the writ
petition and directed the respondents to admit the appellant to the MBBS course while further
directing that it would be open for the respondents to see that admission of other students lower in
merit is not cancelled, if so permissible and possible under the relevant Rules.
8. Upon appeal, the Division Bench of that Court upset the judgment of the learned Single Judge
and held as under:-
“We find that such directions could not have been issued on the basis of possibilities.
In view the process of counseling, we find that the writ petitioner herself has failed to
appear before the counseling board at the relevant time. It is not that she has not got
admission. She is pursuing BDS course at Rohtak whereas, the other two candidates
are pursuing their courses at PGI Rohtak and Medical College Agroha. At this stage,
to disturb the entire admission process would not in the interest of academics when
there is no substantive allegation in respect of admission process.” 3 9. The Division
Bench also noticed the contention of the respondents that the appellant was a student
of the same college and other candidates were even outstation, thus it was possible
that the appellant was not present when the call for her name was made, may be due
to her negligence or carelessness.
4 10. The Court also observed that since there was no allegation of mala fides against
any member of the Counseling Board and there also being no allegations of
misconduct and favouritism, the conclusion arrived at by the learned Single Judge
was not sustainable in law.
5 11. The moot question which falls for consideration of this Court in view of the
divergent views taken by the Single Judge and the Division Bench of the High Court
is whether the decision of the learned Single Judge is based on inferences or
assumptions or whether it was a reasonable conclusion which the Court could arrive
at in view of the pleadings of the parties and the relevant rules in force.Asha vs B.D.Sharma University Of Health ... on 10 July, 2012

6 12. Notification for the second counseling was issued on 26th August, 2011. The
second counseling was to be held for admission to MBBS and BDS courses in
Government Aided Medical Dental Colleges in the State of Haryana on 20th
September, 2011 in the Office of the Director, Pandit B.D. Sharma University of
Health Sciences, PGI, Rohtak, as per the schedule given therein.
13. The notification inter alia also stated:-
| Date            |Reporting Time   |Category         |Rank            |
|20.09.2011       |8.00 A.M.        |General          |01 to 704       |
|                 |                 |(Common Merit    |                |
|                 |                 |List)            |                |
|                 |                 |SC               |01 to 65        |
|                 |                 |BCA              |01 to 144       |
|                 |                 |BCB              |01 to 150       |
|                 |                 |PH               |01              |
|                 |                 |ESM              |01 to 30        |
|                 |                 |FF               |01              |
14. In furtherance to this notification, there is no dispute to the fact that the
appellant, who was at Sr. No. 13 of ESM category, had appeared before the
authorities and marked her attendance in the attendance sheet on 20th September,
2011. It is interesting to note that the same sheet had been signed by the candidates
to mark their presence even on 15th July, 2011, when the first counseling was held.
The appellant had also signed on 15th July, 2011 and, as already noticed, was given admission to the
BDS course.
15. Another important aspect which needs to be noticed at this stage is the original merit list which
has been produced before us. This merit list relates to the date of first counseling, i.e., 15th July,
2011. According to the respondents, the appellant had been given admission to the BDS course but
in this merit list the column for signature in front of her name is empty. This document does not
have any of the members of the Board or any candidate specifying the date of this counseling.
Therefore, we would take it that this document is dated and relates to the proceedings of 15th July,
2011. If that be so, it is difficult to understand as to how the appellant was given admission to the
BDS course on 15th July, 2011 when nothing is noted in front of her name. It does not even say,
whether she was given admission to MBBS or BDS course. Interestingly, in the remark column, the
members of the Board have noted the candidates who have already been given admission to a
college or who were not interested in BDS course or who had vacated the seat of BDS. The merit list
for admission dated 20th September, 2011 has not been placed on record. There is no explanation
available from the records produced before us, as to why this has not been done. It has also not been
clarified in the affidavit filed on behalf of respondent Nos. 1 and 2.Asha vs B.D.Sharma University Of Health ... on 10 July, 2012

11 16. We may notice that in the writ petition before the High Court the appellant had specifically
averred that she was present in the second counseling at the time of attendance and even
subsequent thereto. However, despite such presence, her name and roll number were not declared
by the respondents for the purpose of admission to the MBBS course. However, the list of successful
candidates revealed that candidates of merit lower to her had been admitted to the MBBS course.
According to her, she instantly raised her claim and even submitted a representation upon the
respondents but to no avail. Paragraphs 7 to 9 of the writ petition read as follows :
“7. That the respondents have decided to take second counseling and the date for
second counseling was fixed for 20.09.2011. The petitioner again participated in the
second counseling but her name and roll number was again not declared by the
respondents for the said admission in the MBBS course.
8. That after the date of second counseling, the petitioner was shocked to know that
one Vinita Yadav daughter of Sh. Arvind Kumar Yadav Roll No. 126038 having the
same category i.e. BCB-
ESM and having 821 marks which is lower then the marks secured by the petitioner got admission
in MBBS Course conducted by the respondents. The petitioner has visited the office of the
respondent just after getting the information that a candidate who is lower in merit/marks got
admission in MBBS Course and requested the respondents that this is totally illegal and
discriminatory on the part of them that they are giving admission to a candidate who is having lesser
marks than the petitioner but the respondents have not considered her genuine claim and legal
rights and willfully ignored the request of the petitioner.
9. That the petitioner has not continuously visited the office of the respondents and raised her voice
for her genuine claim for the admission in MBBS Course and she has specifically mentioned that a
candidate having lesser marks as compared to the petitioner has got admission in MBBS course but
in vain. The petitioner submitted a representation before the respondents mentioning everything
about the incident but the respondents have not considered her request. A true typed copy of the
representation is attached herewith as ANNEXURE P-3.”
17. In the reply filed on merits by the respondents, these paragraphs were dealt with in a most casual
manner and no specific denial was made. Paragraphs 7 to 9 of the reply read as under:-
“7. That in reply to Para No. 7 of the petition averments made in Para No. 3 and 4 of
the preliminary submissions are reiterated here.
8. That in reply to Para No. 8 of the petition it is submitted that since the Petitioner
left the counseling place without appearing before the counseling board her
candidature was not considered for admission to MBBS course under ESM category
and the Respondent No. 3 who was next in merit than the Petitioner got the
admission in MBBS course under ESM category. Averments made in Para No. 3 and
4 of the preliminary submissions are also reiterated here.Asha vs B.D.Sharma University Of Health ... on 10 July, 2012

9. That Para No. 9 of the writ petition is wrong and denied.
The Petitioner has never approached to the answering Respondents with regard to her admission in
MBBS course after 2nd counseling as claimed in this para. However, in any case she is not entitled
for admission to MBBS Course under ESM category in present circumstances in view of facts
mentioned in Para No. 2, 3 & 4 of the preliminary submissions.”
18. From a bare reading of the reply filed by the respondents, it is clear that there is no specific
denial of the above-noted averments made by the appellant. It is a settled principle of the law of
pleadings that an averment made by the appellant is expected to be specifically denied by the
replying party. If there is no specific denial, then such averment is deemed to have been admitted by
the respondent. In the present case, it is evident that the above-noted averments in the writ petition
were relevant and material to the case. In fact, the entire case of the appellant hinged on these three
paragraphs of the writ petition. It was thus, expected of the respondents to reply these averments
specifically, in fact to make a proper reference to the records relevant to these paragraphs. In view of
the omission on part of the respondents to refer to any relevant records and failure to specifically
deny the averments made by the appellant, we are of the considered view that the appellant has
been able to make out a case for interference.
19. Not only this, if the averments made in paragraph 9 are correct and the appellant had
instantaneously raised her claim before the respondents, followed by making of the representation,
we see no reason why the claim of the appellant could not be settled at that time or in any case in the
subsequent counseling held on 30th September, 2011, where the appellant was admittedly present.
The attendance sheet produced before us shows that the appellant was present on all the three days.
Even the records produced by the respondents before the Court support the case of the appellant.
20. The appellant filed the writ petition before the High Court without any undue delay and on 4th
November, 2011, the judgment by the court was passed in her favour. The cumulative effect of the
above factual matrix, the pleadings of the parties and the expeditious manner in which the appellant
had taken action before the authorities and then before the court and pursued her remedies,
persuade the Court to believe that the case of the appellant is truthful. The cases of the present kind
are not required to be tested by us on the touchstone of stringent principles of burden of proof
applicable to criminal jurisprudence. As already mentioned, it was the obligation of the respondents
to specifically deny the averments made by the appellant and to produce the relevant records to
show that the stand taken by them is worthy of credence. Having failed to do so, they cannot shift
the burden upon the appellant and expect this Court to believe that a student of the same college,
would disappear at the relevant time of counseling after having marked her presence at the
counseling.
21. It is not necessary for the appellant to plead and prove mala fides, misconduct or favouritism and
nepotism on the part of the parties concerned. Failure to do the same could be an error, intentional
or otherwise, but in either event, we see no reason why the appellant should be made to suffer
despite being a candidate of higher merit.Asha vs B.D.Sharma University Of Health ... on 10 July, 2012

22. At this stage, we may refer to certain judgments of the Court where it has clearly spelt out that
the criteria for selection has to be merit alone. In fact, merit, fairness and transparency are the ethos
of the process for admission to such courses. It will be travesty of the scheme formulated by this
Court and duly notified by the states, if the Rule of Merit is defeated by inefficiency, inaccuracy or
improper methods of admission. There cannot be any circumstance where the Rule of merit can be
compromised. From the facts of the present case, it is evident that merit has been a casuality. It will
be useful to refer to the view consistently taken by this Court that merit alone is the criteria for such
admissions and circumvention of merit is not only impermissible but is also abuse of the process of
law. Ref. Priya Gupta Vs. State of Chhatisgarh & Anr. [CA @ SLP(C) No. 27089 of 2011, decided on
8th May, 2012], Harshali v. State of Maharashtra and Others [(2005) 13 SCC 464], Pradeep Jain v.
UOI [1984 (3) SCC 654], Sharwan Kumar and Others v. Director of Health Services and Another
[1993 Supp (1) SCC 632], Preeti Srivastava v. State of MP [(1999) 7 SCC 120], Guru Nanak Dev
University v. Saumil Garg and Others [2005 (13) SCC 749], AIIMS Students’ Union v. AIIMS and
Others [(2002) 1 SCC 428].
16 23. It is true that the notification dated 26th August, 2011 had clearly stated that the candidate
should appear before the second Counseling Board well in time along with all the original
documents and that the photograph and thumb impression of the candidate would be taken at the
time of the counseling. The notification stated the reporting time as 8.00 a.m. The exact time when
the candidates of each category i.e. General, SC, PH (MS), EMS and FF were to be present was
nowhere stated. In other words all candidates were required to be present at 8.00 a.m.. It cannot be
disputed that the appellant was present at that time and undisputedly she had marked her presence
in the attendance register. She admittedly participated in the photography and taking of thumb
impressions held by the concerned authority. However, her absence at the crucial time of counseling
is the essence of dispute in the present case.
17 24. Adherence to the schedule is the obligation of the authorities and the students both. The
prescribed schedule is to be maintained stricto sensu by all the stakeholders because if one party
adheres to the schedule and others do not or there is some kind of lack of communication or
omission to make proper announcements and maintain proper records for such counseling,
disastrous results can follow, of which the present case is an apt example.
18 25. The Court cannot ignore the fact that these admissions relate to professional courses and the
entire life of a student depends upon his admission to a particular course. Every candidate of higher
merit would always aspire admission to the course which is more promising. Undoubtedly, any
candidate would prefer course of MBBS over BDS given the high-competitiveness in the present
times, where on a fraction of a mark, the admission to course could vary. Higher the competition,
greater is the duty on the part of the concerned authorities to act with utmost caution to ensure
transparency and fairness. It is one of their primary obligations to see that a candidate of higher
merit is not denied seat to the appropriate course and college, as per his preference. We are not
oblivious of the fact that the process of admissions is a cumbersome task for the authorities but that
per se cannot be a ground for compromising merit. The concerned authorities are expected to
perform certain functions, which must be performed in a fair and proper manner i.e. strictly in
consonance with the relevant rules and regulations.Asha vs B.D.Sharma University Of Health ... on 10 July, 2012

26. Strict adherence to the time schedule has again been a matter of controversy before the courts.
The courts have consistently taken the view that the schedule is sacrosanct like the rule of merit and
all the stakeholders including the concerned authorities should adhere to it and should in no
circumstances permit its violation. This, in our opinion, gives rise to dual problem. Firstly, it
jeopardizes the interest and future of the students. Secondly, which is more serious, is that such
action would be ex- facie in violation of the orders of the court, and therefore, would invite wrath of
the courts under the provisions of the Contempt of Courts Act, 1971. In this regard, we may
appropriately refer to the judgments of this Court in the cases of Priya Gupta (supra), State of Bihar
v. Sanjay Kumar Sinha & Ors. [(1990) 4 SCC 624], Medical Council of India v. Madhu Singh & Ors.
[(2002) 7 SCC 258], GSF Medical and Paramedical Association v. Association of Management of Self
Financing Technical Institutes and Anr. [2003 (12) SCC 414], Christian Medical College v. State of
Punjab and Others [(2010) 12 SCC 167].
27. The judgments of this Court constitute the law of the land in terms of Article 141 of the
Constitution and the regulations framed by the Medical Council of India are statutorily having the
force of law and are binding on all the concerned parties. Various aspects of the admission process
as of now are covered either by the respective notifications issued by the State Governments,
prospectus issued by the colleges and, in any case, by the regulations framed by the Medical Council
of India. There is no reason why every act of the authorities be not done as per the procedure
prescribed under the Rules and why due records thereof be not maintained.
28. This proposition of law or this issue is no more res integra and has been firmly stated by this
Court in its various judgments which may usefully be referred at this stage. Ref. State of M.P. v.
Gopal D. Tirthani and Others [(2003) 7 SCC 83], State of Punjab v. Dayanand Medical College &
Hospital and Ors. [AIR 2001 SC 3006], Bharati Vidyapeeth v. State of Maharashtra and Another
[(2004) 11 SCC 755], Chowdhury Navin Hemabhai and Others v. State of Gujarat and Others [(2011)
3 SCC 617], Harish Verma and Others v. Ajay Srivastava and Another [(2003) 8 SCC 69].
29. In the prospectus issued by the respondents, Chapter 9 dealt with the method of selection and
admission. Clause 3.1 stated that it was mandatory for the qualified candidates to appear before the
Counseling Board in person. No relaxation was to be given to the candidates who were unable to
appear before the Counseling Board on the fixed dates. Further, it was stated in the prospectus that
at the time of the counseling, the candidates would be required to exercise their choice for the
institution and the course. The allotment of the seats would be made according to the merit and
preference exercised by the candidates at the time of counseling. During the subsequent counseling
the Course/Institution would be allotted as per the merit of the candidates depending on the
availability of seats.
30. All these clauses are in accordance with the regulations framed by the Medical Council of India
or the notifications issued by the concerned State Government. Relaxation of the Rule of Merit for
reason of non-appearance is not permissible. In the present case, there is no dispute that the
appellant was present at the place and on the date of the second counseling but the dispute relates to
her absence at the particular time when her name was called out for the purpose of counseling. As
far as this issue is concerned, we have already expressed the opinion that there is no substance inAsha vs B.D.Sharma University Of Health ... on 10 July, 2012

the defence taken by the respondents and the appellant should be entitled to the relief prayed for.
However, the question that immediately follows is whether any mid-term admission can be granted
after 30th September of the concerned academic year, that being the last date for admissions. The
respondents before us have argued with some vehemence that it will amount to a mid-term
admission which is impermissible, will result in indiscipline and will cause prejudice to other
candidates. Reliance has been placed upon the judgments of this Court in Medical Council of India
v. Madhu Singh and Others [(2002) 7 SCC 258], Ms. Neelu Arora and Another v. Union of India and
Others [(2003) 3 SCC 366], Aman Deep Jaswal v. State of Punjab and Others [(2006) 9 SCC 597],
Medical Council of India v. Naina Verma and Others [(2005) 12 SCC 626], Mridul Dhar and Another
v Union of India and Others [(2005) 2 SCC 65], Medical Council of India v Madhu Singh and Others
[(2002) 7 SCC 258].
31. There is no doubt that 30th September is the cut-off date. The authorities cannot grant
admission beyond the cut-off date which is specifically postulated. But where no fault is attributable
to a candidate and she is denied admission for arbitrary reasons, should the cut-off date be
permitted to operate as a bar to admission to such students particularly when it would result in
complete ruining of the professional career of a meritorious candidate, is the question we have to
answer. Having recorded that the appellant is not at fault and she pursued her rights and remedies
as expeditiously as possible, we are of the considered view that the cut-off date cannot be used as a
technical instrument or tool to deny admission to a meritorious students. The rule of merit stands
completely defeated in the facts of the present case. The appellant was a candidate placed higher in
the merit list. It cannot be disputed that candidates having merit much lower to her have already
been given admission in the MBBS course. The appellant had attained 832 marks while the students
who had attained 821, 792, 752, 740 and 731 marks have already been given admission in the ESM
category in the MBBS course. It is not only unfortunate but apparently unfair that the appellant be
denied admission. Though there can be rarest of rare cases or exceptional circumstances where the
courts may have to mould the relief and make exception to the cut-off date of 30th September, but
in those cases, the Court must first return a finding that no fault is attributable to the candidate, the
candidate has pursued her rights and legal remedies expeditiously without any delay and that there
is fault on the part of the authorities and apparent breach of some rules, regulations and principles
in the process of selection and grant of admission. Where denial of admission violates the right to
equality and equal treatment of the candidate, it would be completely unjust and unfair to deny such
exceptional relief to the candidate. [Refer Arti Sapru and Others v. State of J & K and Others [(1981)
2 SCC 484]; Chavi Mehrotra v. Director General Health Services [(1994) 2 SCC 370]; and Aravind
Kumar Kankane v. State of UP and Others [(2001) 8 SCC 355].
25 32. We must hasten to add at this stage that even if these conditions are satisfied, still, the court
would be called upon to decide whether the relief should or should not be granted and, if granted,
should it be with or without compensation.
33. This brings us to the last phase of this case as to what relief, if any, the appellant is entitled to.
Having returned a finding on merits in favour of the appellant, the Court has to grant relief to the
appellant even, if necessary, by moulding the relief appropriately and in accordance with law. This
Court must do complete justice between the parties, particularly, where the legitimate right of theAsha vs B.D.Sharma University Of Health ... on 10 July, 2012

appellant stands frustrated because of inaction or inappropriate action on the part of the concerned
respondents. In fact, normally keeping in view the factual matrix of this case, we would have
directed the admission of the appellant to the MBBS course in the academic year 2011-2012 and
would further have directed the respondents to pay compensation to the appellant towards the
mental agony and expense of litigation and the valuable period of her life that stands wasted for
failure on the part of the respondents to adhere to the proper procedure of selection and admission
process. May be the Court would have granted this relief subject to some further conditions.
However, we are unable to grant this relief to the appellant in its totality for reason of her own
doing. She has completely faulted in pursuing her academic course in accordance with the Rules and
like a diligent student should do. In the reply filed on behalf of respondent Nos.1 and 2, it has been
stated that as per the Dental Council of India Norms, minimum required attendance is 75 per cent in
Theory as well as in Practical of each subject individually for issuance of roll numbers in the BDS
course. Undoubtedly, the appellant was admitted to the BDS course and she was expected to
complete her academic course in terms of the Norms of Dental Council of India. It is also not
disputed before us and, in fact, was confirmed to us on behalf of the Medical Council of India and
the respondent University that the course for the first year of both, BDS and MBBS, is more or less
the same. Except one paper of Anatomy, rest of the subjects and papers are more or less similar
particularly for the first six months. If the appellant had pursued the BDS course to which she was
admitted diligently and had attended all the lectures, she might have been eligible to pursue her
MBBS course in continuation thereto. We are not recording any finding in this behalf as, in our
opinion, the appellant is not entitled to this particular relief, as already indicated, and for the same
she has to blame none else but herself.
34. In the reply, the respondents have specifically explained by the figures on record that the
appellant had attended only 28 per cent to 42 per cent lectures (minimum being 28% and maximum
42%) instead of the required 75 per cent and as such she has not even pursued her BDS course
properly. The table given in the reply reads as under :
|S.No. |Name of Deptt.     |Practical             |Theory                 |
|      |                   |Lect.  |Lec.   |%age   |Lect.  |Lec.    |%age   |
|      |                   |Deliv. |Attnd. |       |Deliv. |Attnd.  |       |
|1.    |Prosthodontics     |95     |22     |23%    |Nil    |Nil     |Nil    |
|2.    |Dental Anatomy     |93     |31     |33%    |95     |28      |29%    |
|3.    |Dental Material    |Nil    |Nil    |Nil    |35     |13      |37%    |
|4.    |Anatomy            |125    |39     |31%    |86     |25      |29%    |
|5.    |Physiology         |30     |09     |30%    |94     |27      |28%    |
|6.    |Biochemistry       |32     |12     |37%    |59     |25      |42%    |
35. From the above data, it is clear that the appellant has miserably failed to pursue her BDS course
in accordance with Rules and, thus, she has not fulfilled even the pre-requisites for MBBS course,
assuming that the BDS and MBBS courses are similar for the first six months. In these
circumstances and finding that the appellant is at fault to this limited extent, we are of the
considered view that the only relief the appellant can be granted in the present appeal is a direction
to the respondents to give the appellant admission to the MBBS course not in the academic yearAsha vs B.D.Sharma University Of Health ... on 10 July, 2012

2011-12 but in the current academic year i.e. 2012-2013, that too, subject to the condition that she
will pursue her MBBS course right from the beginning without any advantage of her course in the
BDS. If any examinations have been held in the meanwhile, it shall be deemed that she had not
appeared in those examinations and be treated as such for all intent and purpose. While giving her
admission to the MBBS course, preferably and if it is permissible, admission of none of the other
candidates to the MBBS course may be disturbed. If for whatever reasons, it is not possible to do so,
in that event, the candidate last in the merit who has been granted admission to the MBBS course
shall be transferred to the BDS course and appellant shall be admitted to the MBBS course. We also
direct that such candidate would not be required to commence her/his BDS course from the
beginning provided the candidate has satisfied the attendance requirements of the Dental Council of
India.
36. Now, we shall proceed to answer the questions posed by us in the opening part of this judgment.
ANSWERS
a) The rule of merit for preference of courses and colleges admits no exception. It is an absolute rule
and all stakeholders and concerned authorities are required to follow this rule strictly and without
demur.
b) 30th September is undoubtedly the last date by which the admitted students should report to
their respective colleges without fail. In the normal course, the admissions must close by holding of
second counseling by 15th September of the relevant academic year [in terms of the decision of this
Court in Priya Gupta (supra)]. Thereafter, only in very rare and exceptional cases of unequivocal
discrimination or arbitrariness or pressing emergency, admission may be permissible but such
power may preferably be exercised by the courts. Further, it will be in the rarest of rare cases and
where the ends of justice would be subverted or the process of law would stand frustrated that the
courts would exercise their extra-ordinary jurisdiction of admitting candidates to the courses after
the deadline of 30th September of the current academic year. This, however, can only be done if the
conditions stated by this Court in the case of Priya Gupta (supra) and this judgment are found to be
unexceptionally satisfied and the reasons therefor are recorded by the court of competent
jurisdiction.
c) & d) Wherever the court finds that action of the authorities has been arbitrary, contrary to the
judgments of this Court and violative of the Rules, regulations and conditions of the prospectus,
causing prejudice to the rights of the students, the Court shall award compensation to such students
as well as direct initiation of disciplinary action against the erring officers/officials. The court shall
also ensure that the proceedings under the Contempt of Courts Act, 1971 are initiated against the
erring authorities irrespective of their stature and empowerment.
Where the admissions given by the concerned authorities are found by the courts to be legally
unsustainable and where there is no reason to permit the students to continue with the course, the
mere fact that such students have put in a year or so into the academic course is not by itself a
ground to permit them to continue with the course.Asha vs B.D.Sharma University Of Health ... on 10 July, 2012

37. With all humility, we reiterate the request that we have made to all the High Courts in Priya
Gupta’s case (supra) that the courts should avoid giving interim orders where admissions are the
matter of dispute before the Court. Even in case where the candidates are permitted to continue
with the courses, they should normally be not permitted to take further examinations of the
professional courses. The students who pursue the courses under the orders of the Court would not
be entitled to claim any equity at the final decision of the case nor should it weigh with the courts of
competent jurisdiction.
38. Besides providing the above answers to the questions, we also issue the following directions to
put the matters to rest beyond ambiguity and to ensure that the authorities act in accordance with
law :
(a) From the records of this case, it is clear that two different records are being
maintained at the time of counseling.
Firstly, the attendance register and thereafter photography and thumb impressions are taken and,
secondly, the Committee maintains a record of the counseling where the students are actually given
a specific college/course of his/her preference. We direct that the second set of records shall be
maintained more accurately. It shall not only contain the signatures of the candidate and the
Committee members but also the date and time when the candidate is given a seat and it shall also
be signed by the candidate with the course clearly written by the Committee and signed by the
candidate in the remarks column.
(b) The essence of all the judgments dealing with this issue is to nurture discipline, fairness and
transparency in the selection and admission process and avoid prejudice to any of the stake-holders.
Thus, while we expect the authorities to be perfect, fair and transparent in the discharge of their
duties, we make it clear that the students who adopt malpractices in collusion with the authorities or
otherwise for seeking admissions and if their admissions are found to be irregular or faulty in law by
the courts, they shall normally be held responsible for paying compensation to such other
candidates who have been denied admission as a result of admission of the wrong candidates.
(c) The law requires adherence to a settled protocol in the process of selection and grant of
admission. None should be able to circumvene or trounce this process, with or without an ulterior
motive. The courts are duty bound to ensure that litigation relating to academic courses,
particularly, professional courses should not be generated for want of will on the part of the stake
holders to follow the process of selection and admission fairly, transparently and without
exploitation.
(d) Keeping in mind the hard reality that there are number of petitions filed in each High Court of
the country, on the one hand challenging the admissions on varied grounds while, on the other,
praying for grant of admission on merit to the respective professional courses of MBBS/BDS, the
Court cannot lose sight of the fact that the career of the meritorious youth is at stake. These are
matters relating to adherence to the rule of merit and when its breach is complained of, the judiciary
may be expected to deal with the said grievances preferentially and effectively. The diversity of ourAsha vs B.D.Sharma University Of Health ... on 10 July, 2012

country and the fact that the larger population lives in rural areas and there being demand for
consistent increase in the strength of qualified medical practitioners, we are of the considered view
that such cases, at least as of now and particularly for a specific period of the year require higher
priority in the heavy business of court cases. We are not oblivious of the fact that the Hon’ble Judges
of the High Court are working under great pressure and with some limitations. However, we would
still make a request to the Hon’ble Chief Justices of the respective High Courts to direct listing of all
medical admission cases before one Bench of the Court as far as possible and in accordance with the
Rules of that Court. It would further be highly appreciable if the said Bench is requested to deal with
such cases within a definite period, particularly during the period from July to October of a
particular year. We express a pious hope that our request would weigh with the Hon’ble Chief
Justices of the respective High Courts as it would greatly help in serving the ends of justice as well as
the national interest.
39. For the reasons afore-recorded and with the directions as mentioned above, we direct the
respondents to grant admission to the appellant to the MBBS course in the current academic year
subject to the condition that she will pursue her MBBS course right from its beginning and to the
conditions afore-noticed. However, in the facts and circumstances of the case, we award no costs.
Appeal is disposed of accordingly.
.…................................J. [Swatanter Kumar] .…................................J. [Ranjan Gogoi] New Delhi;
July 10, 2012Asha vs B.D.Sharma University Of Health ... on 10 July, 2012

