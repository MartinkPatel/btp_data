Gajoo vs State Of Uttarakhand on 13 September, 2012
Author: Swatanter Kumar
Bench: Fakkir Mohamed Ibrahim Kalifulla, Swatanter Kumar
                                                                             REPORTABLE
                        IN THE SUPREME COURT OF INDIA
                       CRIMINAL APPELLATE JURISDICTION
                      CRIMINAL APPEAL NO. 1856 OF 2009
Gajoo                                       … Appellant
                                   Versus
State of Uttarakhand                        … Respondent
                               J U D G M E N T
Swatanter Kumar, J.
1. The present appeal is directed against the judgment of the High Court of Uttarakhand at Nainital
dated 7th April, 2008 passed in Criminal Appeal No. 757 of 2001.
2. We may notice the facts giving rise to the present appeal which in any case fall within a narrow
compass. One Smt. Taradevi, the deceased was married to one Gajaram. From this marriage, she
had two children namely Rampal and Guddu (PW4). After the unfortunate death of her husband
Gajaram, she used to live with her younger son Guddu. The elder son Rampal was married and had
been living separately with his family though in the same village. Gajoo, the accused/appellant, is
the brother-in-law of deceased Taradevi i.e. her husband’s younger brother. He was also staying
separate, though near the house of Taradevi. After the demise of her husband, there were some
disputes regarding the division of property between the deceased, on the one hand, and her elder
son, Rampal and brother-in-law, Gajoo on the other. The dispute was related to the agricultural
land. It is stated that Gajoo and Rampal both did not want to give any land to Taradevi.
3. On the night of 1st July, 1987, a ‘Satyanarayan Katha’ had been organised by Chetu Ram at his
house in the village Kotda Kalyanpur. A number of residents of the village had gone to attend the
Katha. PW2, Asharam and PW3, Kewalram along with other people were returning back to their
homes at midnight. On their way back both PW2 and PW3 heard moaning sounds when they
reached near the house of Taradevi. PW2 and PW3 were carrying their torches and in the light of the
torches they saw that accused Gajoo was armed with a Daranti, Ext. 2 with which he was hitting the
deceased and accused Rampal had held her down, in the Aangan (courtyard) of her house. On being
challenged, both these witnesses were threatened by Gajoo stating that they should go away from
there. These two witnesses are stated to have neither raised any alarm nor disclosed the incident to
anyone. The next morning, information of the incident was given by PW4 to his maternal uncleGajoo vs State Of Uttarakhand on 13 September, 2012

Bhadu Ram, who was examined as PW1. Upon receiving information, the matter was reported by
PW1 to the police in the morning of 2nd July, 1987. PW1 had lodged the written report vide Ext.
Ka-1 at Police Station, Sahaspur at about 10.30 in the morning. On the basis of Ext. Ka-1, the FIR, a
Check Report, Ext. Ka-16, was prepared. Sub-Inspector Brahma Singh, PW6 started investigation in
the matter. He reached the place of incident and did Panchayatnama of the corpse of Taradevi. After
performing autopsy on the body of the deceased, vide Ext. Ka-6, he noticed that there were wounds
on the corpse and prepared a Report Ext. Ka-8. Then he sent the body for post-mortem examination
to Dehradun. Blood stained soil, Ext-3 and plain soil samples, Ext-4 were collected from the spot,
and a site plan, Ext. Ka-12 was prepared. Dr. U.K. Chopra of Doon Hospital on 3rd July, 1987
prepared the Post-Mortem Report, Ext. Ka-10 and found the following injuries on the body of the
deceased;
“(i) Incised wound 4 cm x ½ cm muscle deep, 1 cm below the chin.
(ii) Incised wound 5 cm x 1 cm muscle deep, 2 cm below injury No.
1.
(iii) Three abraded contusions in the middle of the neck, sizes 1.5 cm x 1 cm; 2 cm x 1 cm; 1.5 cm x 1
cm.
(iv) Abrasion 3 cm x 2 cm on the back of the left elbow.
(v) Abrasion 3 cm x 2 cm on the back of the shoulder.
(vi) Abrasion 4 cm x 3 cm on the back of the right lumber region.”
4. Dr. Chopra in his report Ext. Ka-10 also recorded the following findings:
“On internal examination, under injury No. (iii) sub cutaneous tissue in the middle of
the neck found congested. Hyoid bone found fractured. The larynx and trachea were
found congested. Both lungs were found congested.”
5. PW2 and PW3 who were examined as eye-witnesses have fully supported the case of the
prosecution. As already noticed, according to them, when they were on their way back from the
house of Chetu Ram after taking part in ‘Satyanarain Katha’, they heard the cries of deceased,
Taradevi. When they reached near the house of Taradevi, in the light of torches that they were
carrying, they saw that Gajoo and Rampal were throttling her in the Aangan (courtyard) of her
house and Gajoo was holding Daranti, Ext. 2 in his hands. When they tried to intervene, they were
threatened. PW5, Gudru has proved recovery of Ext. 2 which was used in the crime and recovery
memo, Ext. Ka-11 was prepared. After the death of his mother, PW4, Guddu, minor son of the
deceased had gone to his uncle’s house to inform him about his mother’s death and thereafter, his
uncle lodged the report to the police. He stated that he too had gone to attend the Katha at the house
of Chetu Ram and in the morning, when he returned, he saw his mother dead. He partly supportedGajoo vs State Of Uttarakhand on 13 September, 2012

the case of prosecution as he affirmed that there was a dispute with regard to the land between his
mother and uncle Gajoo, but stated that he did not know as to who had killed his mother.
Investigation Officer, PW6, in the witness box narrated the entire case of the prosecution and the
investigation conducted by him.
6. The Investigating Officer filed the report before the Court in terms of Section 172(3) of the
Criminal Procedure Code, charging the accused/appellant Gajoo and Rampal, both under Section
302 Indian Penal Code, 1860 (for short ‘IPC’). They faced trial before the Court of Sessions Judge
and were convicted for the offence under Section 302 IPC vide judgment dated 2nd July, 1990. The
trial court awarded life imprisonment to the accused Gajoo, as the accused Rampal had died during
the pendency of the appeal.
7. Aggrieved by the judgment of the trial court, the accused preferred an appeal before the High
Court which came to be dismissed vide judgment dated 7th April, 2008. The High Court confirmed
both the judgment of conviction and order of sentence passed by the trial court, giving rise to the
present appeal.
8. While impugning the judgment under appeal and praying for an order of acquittal, the learned
counsel appearing for the appellant has primarily and with some emphasis contended that;
1. PW2 and PW3, the so-called eye-witnesses, are not genuine and are related to PW1. Their
presence at the place of occurrence is doubtful.
2. With the motive of grabbing the entire land, PW1 has falsely implicated both the accused.
3. There are clear and material contradictions between the medical and oral evidence i.e. Ext. Ka-10
and statements of PW2 and PW3, and even the cause of death is not clear, which essentially must go
to the benefit of the accused.
4. The Daranti and blood stained pyjama which were recovered, were not sent for FSL examination
and no serological report was obtained.
9. In support of his contention, the learned counsel for the appellant had laid a lot of emphasis on
the statement of PW4. According to him, PW4 had not completely stated the case of the prosecution,
and therefore, the accused was entitled to acquittal.
10. In the cross-examination, PW4 has made certain statements which no doubt, do not support the
case of the prosecution. He stated that he had not given the names of the murderers to his uncle.
The statement of PW4 has to be read collectively along with the statement of PW1, PW2 and PW3.
PW4 was a minor, when he saw his mother dead in the year 1987. His statement was recorded on
22nd January, 1990 i.e. more than two and a half years after the date of occurrence. We are unable
to see any serious contradictions or untruthfulness in the statement of this witness. Even if his
statement has to be evaluated as it is on record, he had stated the facts that when he returned from
the house of Chetu Ram after attending the Katha, he saw his mother lying dead and thereafter heGajoo vs State Of Uttarakhand on 13 September, 2012

went and informed his uncle who subsequently lodged the report with the police the next morning
and in view of the statement of PW2 and PW3, the accused were arrested. We fail to understand as
to what advantage the accused intends to draw from this statement of PW4. It was not the case of
the prosecution that PW4 was an eye-witness or had seen the accused persons murdering his
mother. The trial court, on that behalf had recorded that in view of the death of his mother as well as
the co-accused, his elder brother, Rampal, he might not have stated certain facts correctly before the
Court. We do not see any reason for making such a remark in the judgment. There are no material
or other contradictions in the statements of these four witnesses. PW2 is stated to be related to PW1
who in turn is related to the deceased. Also, PW3 is related to the deceased. Thus, according to the
submission on behalf of the accused all of them become interested witnesses who have attempted to
falsely implicate the appellant. The statement of these witnesses, therefore, cannot be relied upon,
they being relatives and interested witnesses of the deceased and other witnesses.
11. We are not impressed with this argument. The appreciation of evidence of such related witnesses
has been discussed by this Court in its various judgments. In the case of Dalip Singh v. State of
Punjab [(1954 SCR 145], while rejecting the argument that witnesses who are close-relatives of the
victim should not be relied upon, the Court held as under:-
“26. A witness is normally to be considered independent unless he or she springs
from sources which are likely to be tainted and that usually means unless the witness
has cause, such as enmity against the accused, to wish to implicate him falsely.
Ordinarily, a close relative would be the last to screen the real culprit and falsely
implicate an innocent person. It is true, when feelings run high and there is personal
cause for enmity, that there is a tendency to drag in an innocent person against whom
a witness has a grudge along with the guilty, but foundation must be laid for such a
criticism and the mere fact of relationship far from being a foundation is often a sure
guarantee of truth. However, we are not attempting any sweeping generalisation.
Each case must be judged on its own facts. Our observations are only made to combat
what is so often put forward in cases before us as a general rule of prudence. There is
no such general rule. Each case must be limited to and be governed by its own facts.”
12. Similar view was taken by this Court in the case of State of A.P. v. S. Rayappa and Others [(2006)
4 SCC 512]. The court observed that it is now almost a fashion that public is reluctant to appear and
depose before the court, especially in criminal cases and the cases for that reason itself are dragged
for years and years. The Court also stated the principle that, “by now, it is a well-established
principle of law that testimony of a witness otherwise inspiring confidence cannot be discarded on
the ground that he being a relation of the deceased is an interested witness. A close relative who is a
very natural witness cannot be termed as interested witness. The term interested postulates that the
person concerned must have some direct interest in seeing the accused person being convicted
somehow or the other either because of animosity or for some other reasons.”
13. This Court has also taken the view that related witness does not necessarily mean or is equivalent
to an interested witness. A witness may be called ‘interested’ only when he or she derives some
benefit from the result of litigation; in the decree in a civil case, or in seeing an accused personGajoo vs State Of Uttarakhand on 13 September, 2012

punished. {Ref. State of Uttar Pradesh v. Kishanpal and Others [(2008) 16 SCC 73]}
14. In the case of Darya Singh & Ors. v. State of Punjab [AIR 1965 SC 328], the Court held as under:-
“6....On principle, however, it is difficult to accept the plea that if a witness is shown
to be a relative of the deceased and it is also shown that he shared the hostility of the
victim towards the assailant, his evidence can never be accepted unless it is
corroborated on material particulars.”
15. Once, the presence of PW2 and PW3 is shown to be natural, then to doubt their statement would
not be a correct approach in law. It has unequivocally come on record through various witnesses,
including PW4, that there was a ‘Satyanarayan Katha’ at the house of Chetu Ram which was
attended by various villagers. It was on their way back at midnight when PW2 and PW3 had seen the
occurrence in dark with the help of the torches that they were carrying. The mere fact that PW2
happens to be related to PW1 and to the deceased, would not result in doubting the statement of
these witnesses which otherwise have credence, are reliable and are duly corroborated by other
evidence. In such cases, it is only the members of the family who come forward to depose. Once it is
established that their depositions do not suffer from material contradictions, are trustworthy and in
consonance with the above-stated principles, the Courts would not be justified in overlooking such
valuable piece of evidence.
16. Coming to the next submission on behalf of the accused that there is contradiction between the
ocular and medical evidence, it is contended that according to PW2 and PW3, the deceased was
killed by use the of Daranti that the accused/appellant Gajoo was carrying, while according to the
medical evidence, the death resulted from asphyxia. This argument is based upon misreading of the
evidence. PW2 and PW3 had seen in the dark i.e. in the limited light of the torches that they were
carrying, that Rampal was holding the deceased while Gajoo was inflicting injuries on her body with
the help of Daranti. As per the Post Mortem Report, Ext. Ka-10, two injuries have been noticed
under the chin which are; incised wound 4 cm x ½ cm muscle deep, incised wound 5 cm x 1 cm
muscle deep and the second injury is just below the first injury. Injury No. (iii) recorded in the post
mortem report is very material. According to the doctor, there were three abraded contusions of
different sizes, in the middle of the neck. The doctor has specifically recorded that both lungs were
congested, the larynx and trachea were found congested and the expert judgment of the doctor
based on these factors was that death occurred due to asphyxia because of strangulation.
17. Rampal was pushing down the deceased on the earth in the Aangan while Gajoo had inflicted the
injuries. The injuries evidently were inflicted by accused Gajoo holding Daranti in one hand and
holding the neck of the deceased with the other hand. It was the pressing of her neck and body to the
earth by both the accused of much greater strength than the deceased, that resulted in her death.
18. We have also noticed that there is no variation between the medical evidence and the ocular
evidence, and once they are co-jointly read, it does not falsify either the statement of the witnesses,
PW2 and PW3 or the Post-Mortem Report, Ext. Ka-10. In fact, both of them must be read as
complimentary to each other. Even if for the sake of argument we assume that there is someGajoo vs State Of Uttarakhand on 13 September, 2012

variation, still, it would be so immaterial and inconsequential that it would not give any benefit to
the accused. It is a settled principle by a series of decisions of this Court that while appreciating the
variation between the medical evidence and ocular evidence, primacy is given to the oral evidence of
the witnesses. Reference can be made to the judgments of this Court in the case of Kapildeo Mandal
and Ors. v. State of Bihar [(2008) 16 SCC 99], State of U.P. v. Krishan Gopal [(1998) 4 SCC 302],
Bhajan Lal @ Harbhajan Singh & Ors. v. State of Haryana [(2011) 7 SCC 421].
19. Now, we turn to the last submission on behalf of the accused that no serologist report was
obtained in relation to the Daranti, Ext. 2 and blood stained pyjama, Ext. Ka 5, and therefore, the
prosecution case should fail. This argument does not impress us at all. No doubt both these exhibits
were not sent to the laboratory for obtaining serologist report, but the absence thereof per se would
not give any advantage to the accused. This is merely a defect in investigation. A defective
investigation, unless affects the very root of the prosecution case and is prejudicial to the accused,
should not be an aspect of material consideration by the court. PW5 has duly proved the recovery of
Daranti, Ext. 2 and the blood stained pyjama, Ext. Ka 5 and has duly stood the test of
cross-examination in court. Both these articles were recovered by the investigating officer Brahma
Singh, PW6 and the recoveries have been duly established before the court. The recoveries having
been proved and the case of the prosecution being duly supported by two eye-witnesses, PW2 and
PW3 and two witnesses, PW4 and PW5 who were present immediately after the occurrence, have
proved the case of the prosecution beyond any reasonable doubt.
20. In regard to the defective investigation, this Court in the case of Dayal Singh and Others. v. State
of Uttaranchal [2012 (7) SCALE 165] while dealing with the cases of omissions and commissions by
the investigating officer, and duty of the Court in such cases held as under:-
“22. Now, we may advert to the duty of the Court in such cases. In the case of Sathi
Prasad v. The State of U.P. [(1972) 3 SCC 613], this Court stated that it is well settled
that if the police records become suspect and investigation perfunctory, it becomes
the duty of the Court to see if the evidence given in Court should be relied upon and
such lapses ignored. Noticing the possibility of investigation being designedly
defective, this Court in the case of Dhanaj Singh @ Shera & Ors. v. State of Punjab
[(2004) 3 SCC 654], held, “in the case of a defective investigation the Court has to be
circumspect in evaluating the evidence. But it would not be right in acquitting an
accused person solely on account of the defect; to do so would tantamount to playing
into the hands of the investigating officer if the investigation is designedly defective.”
23. Dealing with the cases of omission and commission, the Court in the case of Paras
Yadav v. State of Bihar [AIR 1999 SC 644], enunciated the principle, in conformity
with the previous judgments, that if the lapse or omission is committed by the
investigating agency, negligently or otherwise, the prosecution evidence is required to
be examined de hors such omissions to find out whether the said evidence is reliable
or not. The contaminated conduct of officials should not stand in the way of
evaluating the evidence by the courts, otherwise the designed mischief would be
perpetuated and justice would be denied to the complainant party.Gajoo vs State Of Uttarakhand on 13 September, 2012

In the case of Zahira Habibullah Sheikh & Anr. Vs. State of Gujarat & Ors. [(2006) 3 SCC 374], the
Court noticed the importance of the role of witnesses in a criminal trial. The importance and
primacy of the quality of trial process can be observed from the words of Bentham, who states that
witnesses are the eyes and ears of justice. The Court issued a caution that in such situations, there is
a greater responsibility of the court on the one hand and on the other the courts must seriously deal
with persons who are involved in creating designed investigation. The Court held that legislative
measures to emphasize prohibition against tampering with witness, victim or informant have
become the imminent and inevitable need of the day. Conducts which illegitimately affect the
presentation of evidence in proceedings before the Courts have to be seriously and sternly dealt
with. There should not be any undue anxiety to only protect the interest of the accused. That would
be unfair, as noted above, to the needs of the society. On the contrary, efforts should be to ensure
fair trial where the accused and the prosecution both get a fair deal. Public interest in proper
administration of justice must be given as much importance if not more, as the interest of the
individual accused. The courts have a vital role to play. (Emphasis supplied)
24. With the passage of time, the law also developed and the dictum of the Court emphasized that in
a criminal case, the fate of proceedings cannot always be left entirely in the hands of the parties.
Crime is a public wrong, in breach and violation of public rights and duties, which affects the
community as a whole and is harmful to the society in general.
25. Reiterating the above principle, this Court in the case of National Human Rights Commission v.
State of Gujarat [(2009) 6 SCC 767], held as under:
“The concept of fair trial entails familiar triangulation of interests of the accused, the
victim and the society and it is the community that acts through the State and
prosecuting agencies. Interest of society is not to be treated completely with disdain
and as persona non grata. The courts have always been considered to have an
overriding duty to maintain public confidence in the administration of justice—often
referred to as the duty to vindicate and uphold the ‘majesty of the law’. Due
administration of justice has always been viewed as a continuous process, not
confined to determination of the particular case, protecting its ability to function as a
court of law in the future as in the case before it. If a criminal court is to be an
effective instrument in dispensing justice, the Presiding Judge must cease to be a
spectator and a mere recording machine by becoming a participant in the trial
evincing intelligence, active interest and elicit all relevant materials necessary for
reaching the correct conclusion, to find out the truth, and administer justice with
fairness and impartiality both to the parties and to the community it serves. The
courts administering criminal justice cannot turn a blind eye to vexatious or
oppressive conduct that has occurred in relation to proceedings, even if a fair trial is
still possible, except at the risk of undermining the fair name and standing of the
judges as impartial and independent adjudicators.”
26. In the case of State of Karnataka v. K. Yarappa Reddy [2000 SCC (Crl.) 61], this Court
occasioned to consider the similar question of defective investigation as to whether anyGajoo vs State Of Uttarakhand on 13 September, 2012

manipulation in the station house diary by the Investigating Officer could be put against the
prosecution case. This Court, in Paragraph 19, held as follows:
“19. But can the above finding (that the station house diary is not genuine) have any
inevitable bearing on the other evidence in this case? If the other evidence, on
scrutiny, is found credible and acceptable, should the Court be influenced by the
machinations demonstrated by the Investigating Officer in conducting investigation
or in preparing the records so unscrupulously? It can be a guiding principle that as
investigation is not the solitary area for judicial scrutiny in a criminal trial, the
conclusion of the Court in the case cannot be allowed to depend solely on the probity
of investigation. It is well- nigh settled that even if the investigation is illegal or even
suspicious the rest of the evidence must be scrutinised independently of the impact of
it. Otherwise the criminal trial will plummet to the level of the investigating officers
ruling the roost. The court must have predominance and pre-eminence in criminal
trials over the action taken by the investigation officers. Criminal Justice should not
be made a casualty for the wrongs committed by the investigating officers in the case.
In other words, if the court is convinced that the testimony of a witness to the
occurrence is true the court is free to act on it albeit the investigating officer's
suspicious role in the case.”
27. In Ram Bali v. State of Uttar Pradesh [(2004) 10 SCC 598], the judgment in Karnel Singh v.
State of M.P. [(1995) 5 SCC 518] was reiterated and this Court had observed that ‘in case of defective
investigation the court has to be circumspect while evaluating the evidence. But it would not be right
in acquitting an accused person solely on account of the defect; to do so would tantamount to
playing into the hands of the investigation officer if the investigation is designedly defective’.
28. Where our criminal justice system provides safeguards of fair trial and innocent till proven
guilty to an accused, there it also contemplates that a criminal trial is meant for doing justice to all,
the accused, the society and a fair chance to prove to the prosecution. Then alone can law and order
be maintained. The Courts do not merely discharge the function to ensure that no innocent man is
punished, but also that a guilty man does not escape. Both are public duties of the judge. During the
course of the trial, the learned Presiding Judge is expected to work objectively and in a correct
perspective. Where the prosecution attempts to misdirect the trial on the basis of a perfunctory or
designedly defective investigation, there the Court is to be deeply cautious and ensure that despite
such an attempt, the determinative process is not sub-served. For truly attaining this object of a ‘fair
trial’, the Court should leave no stone unturned to do justice and protect the interest of the society as
well.
29. This brings us to an ancillary issue as to how the Court would appreciate the evidence in such
cases. The possibility of some variations in the exhibits, medical and ocular evidence cannot be ruled
out. But it is not that every minor variation or inconsistency would tilt the balance of justice in
favour the accused. Of course, where contradictions and variations are of a serious nature, which
apparently or impliedly are destructive of the substantive case sought to be proved by the
prosecution, they may provide an advantage to the accused. The Courts, normally, look at expertGajoo vs State Of Uttarakhand on 13 September, 2012

evidence with a greater sense of acceptability, but it is equally true that the courts are not absolutely
guided by the report of the experts, especially if such reports are perfunctory, unsustainable and are
the result of a deliberate attempt to misdirect the prosecution. In Kamaljit Singh v. State of Punjab
[2004 Cri.LJ 28], the Court, while dealing with discrepancies between ocular and medical evidence,
held, “It is trite law that minor variations between medical evidence and ocular evidence do not take
away the primacy of the latter. Unless medical evidence in its term goes so far as to completely rule
out all possibilities whatsoever of injuries taking place in the manner stated by the eyewitnesses, the
testimony of the eyewitnesses cannot be thrown out.”
30. Where the eye witness account is found credible and trustworthy, medical opinion pointing to
alternative possibilities may not be accepted as conclusive. The expert witness is expected to put
before the Court all materials inclusive of the data which induced him to come to the conclusion and
enlighten the court on the technical aspect of the case by examining the terms of science, so that the
court, although not an expert, may form its own judgment on those materials after giving due regard
to the expert’s opinion, because once the expert opinion is accepted, it is not the opinion of the
medical officer but that of the Court. {Plz. See Madan Gopal Kakad v. Naval Dubey & Anr. [(1992) 2
SCR 921:
(1992) 3 SCC 204]}.”
21. The present case, when examined in light of the above principles, makes it clear
that the defect in the investigation or omission on the part of the investigating officer,
cannot prove to be of any advantage to the accused. No doubt the investigating officer
ought to have obtained serologist’s report both in respect of Ext. 2 and Ext. 5 and
matched it with the blood group of the deceased. This is a definite lapse on the part of
the investigating officer which cannot be overlooked by the Court, despite the fact
that it finds no merit in the contention of the accused.
22. For the reasons afore-recorded, we dismiss this appeal being without any merit.
However, we direct the Director General of Police, Uttarakhand, to take disciplinary
action against Sub-Inspector, Brahma Singh, PW6, whether he is in service or has
since retired, for such serious lapse in conducting investigation.
23. The Director General of Police shall take a disciplinary action against the said
officer and if he has since retired, the action shall be taken with regard to
deduction/stoppage of his pension in accordance with the service rules. The ground
of limitation, if stated in the relevant rules, will not operate as the inquiry is being
conducted under the direction of this Court.
………...….…………......................J. (Swatanter Kumar) ………...….…………......................J. (Fakkir
Mohamed Ibrahim Kalifulla) New Delhi, September 13, 2012Gajoo vs State Of Uttarakhand on 13 September, 2012

