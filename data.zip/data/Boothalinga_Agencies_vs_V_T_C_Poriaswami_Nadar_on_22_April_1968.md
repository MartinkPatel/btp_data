Boothalinga Agencies vs V. T. C. Poriaswami Nadar on 22 April,
1968
Equivalent citations: 1969 AIR 110, 1969 SCR (1) 65, AIR 1969 SUPREME
COURT 110
Author: V. Ramaswami
Bench: V. Ramaswami, J.C. Shah, G.K. Mitter
           PETITIONER:
BOOTHALINGA AGENCIES
        Vs.
RESPONDENT:
V. T. C. PORIASWAMI NADAR
DATE OF JUDGMENT:
22/04/1968
BENCH:
RAMASWAMI, V.
BENCH:
RAMASWAMI, V.
SHAH, J.C.
MITTER, G.K.
CITATION:
 1969 AIR  110            1969 SCR  (1)  65
 CITATOR INFO :
 R          1971 SC 170  (9)
ACT:
Indian  Contract Act (9 of 1872) s. 56-Contract  entered  in
contravention  of  licence terms--Doctrine  of  frustration-
"self  induced  frustration"--If  applies  to--Imports   and
Exports (Control) Act (18 of 1947) s. 5--Contract entered in
contravention   of   licence  terms  before   amendment   in
1960--Whether statutory order breached--Sale if contravening
cl. 5(4) of 1955 order.
HEADNOTE:
The appellant entered into a contract to sell certain  goods
to  the  respondent  which he was  importing  under  'actual
users' licence.  Under the terms of the licence the sale  ofBoothalinga Agencies vs V. T. C. Poriaswami Nadar on 22 April, 1968

the,  goods  was  prohibited  and was  to  be  utilised  for
consumption  by the importer.  The goods arrived,  and  were
cleared  by  the appellant.  The respondent  filed  a  suit,
which was contested by the appellant on the ground that  the
contract was illegal, and, therefore, void.  The trial court
decreed the suit holding that the contravention of the terms
of licence entailed only an administrative penalty, the sale
could  not be held to be prohibited by law and the  contract
was  a legal contract The High Court upheld the decree.   In
appeal, this Court :
HELD: The appeal must be allowed.
(i)  The  licence  was  granted by  virtue  of  a  statutory
notification issued under the Defence of India Rules.   The;
notification authorises the licensing officer to impose  one
or  more  conditions  prescribed  by  that  order  and   the
licensing  officer has therefore power to impose  conditions
in  the  licence,  issued  by  him,  but  if  the   licensee
contravenes  the  conditions imposed by the  licence  it  is
merely  a contravention of the conditions of a  licence  and
not a contravention of the provisions of s. 5 of the Imports
and  Exports (Control) Act, Section 5 of Act was amended  by
the   Amending  Act   4  of  1960  much  after  the   present
controversy,  so as to include contravention of a  condition
of a licence granted under any order as an offence under  s.
5  of the Act.  Therefore on the material date a  breach  of
the condition of a licence was not tantamount to a breach of
the statutory order within the meaning of s. 5 of the Act 18
of 1947.
[73H; 74A-D]
East  India Commercial Co. Ltd., Calcutta, v. The  Collector
of Customs, Calcutta, [1963] 3 S.C.R. 338, followed.
(ii) The  goods  which arrived at the Indian  Port  on  13th
December  1955  were governed by the provisions  of  Imports
(Control) Order, 1955 which came into force on 7th  December
1955.  Clause 5(4) of the 1955 order expressly provided that
the licensee shall comply with all the conditions imposed or
deemed to be imposed under that clause.  Therefore the  sale
of the imported goods would be a direct contravention of cl.
5(4) and under s. 5 of the Act any contravention of the  Act
or any order made or deemed to have been made under the  Act
was  punishable  with  imprisonment or  fine  or  both.   In
consequence,  even though the contract was enforceable  when
it  was  entered,  the performance of  the  contract  became
impossible or unlawful when the 1955 Order came into  force,
and  so the contract became void under s. 56 of  the  Indian
Contract Act. [75B-D]
66
The doctrine of frustration of contract is really an  aspect
or  par;  of the law of discharge of contract by  reason  of
supervening impossibility or illegality of the act agreed to
be  done and hence comes within the purview of s. 56 of  the
Indian  Contract Act.  It should be noticed than s. 56  lays
down a rule of positive law and does not leave the matter toBoothalinga Agencies vs V. T. C. Poriaswami Nadar on 22 April, 1968

be  determined according to the intention of  ,,he  parties.
In English law the question of a frustration of contract has
been  treated  by  courts as  it  question  of  construction
depending  upon  the  true  intention  of  the  parties   In
contrast, the statutory provisions contained in s. 56 of the
Indian  Contract  Act lay down a positive rule  of  law  and
English   authorities   cannot  therefore   be   of   direct
assistance, though they have persuasive value in showing how
English  courts  have  approached and  decided  cases  under
similar circumstances. [75G; 77H; 78A-B]
Denny. Mott and Dickson Ltd. v. James B. Fraser & Co., Ltd.,
[1944]  A.C.  265; British Movietonews Ltd.  v.  London  and
District  Cinemas  Ltd. [1951] 1 K.B. 190; House  of  Lords,
[1952] A.C. 166 at 185, referred to.
(iii)The  licensing  authority  could  have  given   written
permission  for  disposal  of  goods  under  cl.  1  of  the
notification  but the condition imposed in the  licence,  in
the  present case was a special condition imposed under  cl.
(v)  of paragraph (a) of the notification and there  was  no
option given tinder this clause for the licensing  authority
to modify the condition of the licence prohibiting  disposal
of the goods. [78D-E]
(iv) The  appellant  was  not  under  obligation,  to   have
purchased the gooods from the open market and supplied it to
the respondent.  Under the contract the quality of the goods
to be sold was of specific description as described therein.
The  doctrine of frustration of contract cannot apply  where
the  event which is alleged to have frustrated the  contract
arises from the act or election of a party, i.e., to a "self
induced  frustration".  This principle could not be  applied
to the present case for there was no choice or election left
to  the appellant to supply the goods other thin  under  the
terms of the contract. [78G; 79C-D]
Maritime  National Fish, Limited v. Ocean Trawels,  Limited,
[1935] A.C. 524, referred to.
JUDGMENT:
CIVIL APPELLATE JURISDICTION : Civil Appeal No. 479 of 1965. Appeal from the judgment and
decree dated March 16, 1962 of the Madras High Court in Appeal No. 367 of 1958. H. R. Gokhale
and S. Balakrishnan, for the appellant. R. Thiagarajan and T.R. Sangameswaran, for respondent No.
2. The Judgment of ;the Court was delivered by Ramaswami, J. This appeal is brought, by
certificates from the judgment of the Madras High Court dated March 16, 1962 in A.S. No. 367 a
1958.
The appellant carries on business in the manufacture and sale of coffee powder. He was for this
purpose importing chicory under actual user's licence issued by the Government. The consignment
of chicory in question was a consignment of 24 3/4 tons495 cases which arrived at Madras port by
"S. S. Alwaki" in December, 1955. Exhibit B-9 was the licence under which the consignment wasBoothalinga Agencies vs V. T. C. Poriaswami Nadar on 22 April, 1968

imported. The goods were cleared by the appellant on December 20, 1955. The case of the
respondent was that the appellant agreed to sell the consignment to him under Ex. A-1 dated
November 26, 1955 after taking an advance of Rs. 7,500/-. The contract was, however, entered into
in the name of the first defendant and P.W. 2 acted as a broker in the transaction. The respondent
paid another sum of Rs. 20,000/on December 23, 1955 after the goods arrived and were cleared on
the representation that the delivery would be given in one month. Defendant No. 1 executed a letter,
Ex. A-2 in this connection but thereafter owing to rise in prices the appellant committed a default.
The suit was contested by the first defendant on the ground that the contract was illegal and
therefore void. The case of the second defendant was that he had nothing to do with the contract
entered into between the plaintiff and the first defendant and, in any case, the contract for sale of
chicory was illegal and void ab initio as contravening the provisions of the licence granted to him for
the import of chicory. The trial court held, upon examination of the evidence, that both defendants 1
and 2 undertook with the plaintiff to fulfil the terms of the contract.On the question of legality of the
contract the trial court held that as the contravention of the terms of the licence by the sale of the
imported goods would entail only an administrative penalty, the sale cannot be held to be prohibited
by law and the contract was therefore a legal contract binding on both the parties. The trial court
found that the date of the breach of the contract February 14, 1956 and granted a decree in favour of
the plaintiff against both the defendants for a sum of Rs. 35,640/-. Two appeals were filed in the
Madras High Court against the judgment of the trial court-A.S. No. 367 of 1958 by the second
defendant and A.S. No. 363 of 1959 by the first defendant. The appeals were heard together by the
High Court which by its judgment dated March 16, 1962 allowed the appeal of the first
defendant-A.S. No. 363 of 1959 and dismissed the suit as against him. As regards the appeal filed by
the 2nd defendant the High Court reduced the amount of damages to the sum of Rs. 23,265/-. The
High Court agreed with the finding of the trial Judge that the contract for the sale of imported
chicory was entered into by the respondent directly with the second defendant and the second
defendant was liable for its breach. As regards the legality of the contract, the High Court took the
view that it could not be regarded as a contract prohibited by any law and so it was valid and binding
between the parties and the plaintiff could properly sustain an action for damages for it-, breach.
The High Court further held that the real contract which the plaintiff had entered into was with the
second defendant and the first defendant was only a dummy in whose name the contract was
entered into for ulterior reasons. The first question to be considered in this appeal is whether the
contract was in violation of the restrictions placed by the Imports and Exports (Control) Act, 1947
and the notifications issued thereunder and in consequence whether it was void and illegal and
whether a claim for breach of such a contract is maintainable. It is -necessary at this stage to refer to
the terms of the licence, Ex. B-9 and to the relevant provisions of the statutes and the notifications.
Exhibit B-9 was issued on September 29, 1955 and reads as follows :
'Messrs. Boothalinga Agencies, of 2/21, Dr. Vasudevan Road, Madras-10, are hereby
authorised to import the goods of which particulars are given below
1. Country from which consigned. Soft currency licensing.Boothalinga Agencies vs V. T. C. Poriaswami Nadar on 22 April, 1968

2. Country of origin.-Area/Not valid for South Africa.
3. Description of goods.Chicory.
4. Serial number and part of the I.T.C. Schedule 79. V/IV.
5. Quantity.-24 3/4 tons.
6. Approximate value c.i.f. (in words) rupees thirty two thousand and two only (in
figures) Rs. 32,002.
7. Period of shipment : Valid up to 31st March 1956 from the date of issue.
8. Limiting factor for purposes of clearance through Customs.
Quantity/value Both.
This licence is granted under Government of India, late Ministry of Commerce Notification No.
23-ITC/43, dated the 1st July 1943, as continued in force by the Imports and Exports (Control) 1947
(XVIII of 1947) and is without prejudice to the application of any other prohibition or regulation
affecting the importation of the goods which may be in force at the time of their arrival.
This licence is issued subject to the condition that the goods will be utilised only for consumption as
raw material or accessories in the licence holder's factory and that no portion thereof will be sold to
any party. (Signed) For Chief Controller of Imports.
This licence was granted under Government of India, late Commerce Department Notification No.
23. ITC/43 dated July 1, 1943 made under Rule 84(3) of the Defence of India Rules which was
intended to "prohibit bringing into British India by sea, land or air from any place outside India of
any goods of the description specified in the schedule (hereto annexed) except the following........"
Sub-Clause Xll:-Any goods of the description specified in Part IV of the Schedule which are covered
by a special licence issued by an Import Trade Controller appointed in this behalf by the Central
Government."
Imported chicory is one of the goods described in Part IV. The effect of the )notification is that if
there is a special licence for the importing of chicory there would be no prohibition against its
import. Sections 3, 4 and 5 of the Imports and Exports (Control) Act, 1947 provided for the
continuance of the notifications previously issued under the Defence of India Rules. Sections 3, 4
and 5 of that Act are to the following effect "3. Powers to prohibit or restrict imports and exports.-(I)
The Central Government may, by order published in the Official Gazette, make provision for
prohibiting, restricting or otherwise controlling, in all cases or in specified classes of cases, and
subject to such exceptions, if any, as may be made by or under the order,-Boothalinga Agencies vs V. T. C. Poriaswami Nadar on 22 April, 1968

(a) the import, export, carriage coastwise or shipment as ships' stores of goods of any
specified description;
(b) the bringing into any port or place in British India of goods of any specified
description intended to be taken out of British India without being removed from the
ship or conveyance in, which they are being carried.
(2) All goods to which any order under sub-
section (1) applies shall be deemed to be goods of which the import or export has been prohibited or
restricted under section 19 of the Sea Customs Act, 1878, and all .lm15 the provisions of that Act
shall have effect accordingly, except that section 183 'thereof shall have effect as if for the word
'shall' therein the word 'may' were substituted. (3) Notwithstanding anything contained in the
aforesaid Act, the Central Government may, by order published in the Official Gazette, prohibit,
restrict or impose conditions on the clearance, whether for home consumption or for shipment
abroad, of any goods or class of goods imported into British India.
4. All orders made under rule 84 of the Defence of India Rules or that rule as continued in force by
the Emergency Provisions (Continuance) Ordinance, 1.946, and in force immediately before the
commencement of this Act shall, so far as they are not inconsistent with ,the provisions of this Act,
continue in force and be deemed to have been made under this Act.
5. If any person contravenes any order made or deemed to have been made under this Act, he shall,
without prejudice to any confiscation or penalty to which he may be liable under the provisions of
the Sea Customs Act, 1878, as applied by sub-section (2) of section 3, be punishable with
imprisonment for a term which may extend to one year, or with fine, or with both."
On March 6, 1948 the Central Government issued a notification under sub-r. (3) of r. 84 of the
Defence of India Rules which -reads as follows :
"No. 2-ITC/48-In exercise of the, powers conferred by sub-s. (1) and sub-s. (3) of s. 3
of the Imports and Exports (Control) Act, 1947 (XVIII of 1947) the Central
Government is pleased to make the following order, namely,
(a) Any officer issuing a licence under clauses VIII to XIV of the Notification of the
Government of India in the late Department of Commerce No. 23-ITC/43 dated the
1st July 1943 may issue the same subject to one or more of the conditions stated
below :
(i) That goods covered by the licence shall not be disposed of or otherwise dealt with
or without the written permission of the licens-
ing authority or any person duly authorised by it.Boothalinga Agencies vs V. T. C. Poriaswami Nadar on 22 April, 1968

(ii) That the goods covered by the licence on importation shall not be sold or distributed at a price
more than that which may be .specified in any directions attached to the, licence.
(iii) That the applicant for a licence shall execute a bond for complying the terms subject to which a
licence may be granted.
(iv) That the licence shall not be transferable except in accordance with the permission of the
licensing authority or a person duly authorised by it.
              (v)   That   such  other  conditions  may   be
              imposed   which   the   licensing    authority
              considers    to   be   expedient   from    the
administrative point of view and which are not inconsistent with the provisions of the said Act.
(b) Where a licensee is found to have contravened the order or the terms and conditions embodied
in or accompanying a licence, the appropriate licensing authority or the Chief Controller of Imports
may notify him that, without prejudice to any penalty to which he may be liable under the Imports
and Exports (Control) Act 1947 (XVIII of 1947) or any other enactment for the time being in force,
he shall either permanently or for a specified period, be refused any further licence for import of
goods.
(c) Where an Importer is found guilty of contravention of the proviso to the said notification or of
any orders or terms or conditions embodied in or accompanying a licence or an application for a
license or any other import trade control rules or regulations duly promulgated the appropriate
licensing authority or the Chief Controller of Imports may notify him that, without prejudice to any
penalty to which he may be liable under the Imports & Exports (Control) Act 1947 (XVIII of 1947) or
any other enactment for the time being in force, he shall either perma- nently or for a specified
period be refused any license for import of goods."
By S. 4 of Act 4 of 1960 there was an amendment of certain provisions of the Imports and Exports
(Control) Act, 1947 (Act XVIII of 1947). By s. 4 of the Amending Act the words "Or any condition of
a licence granted under any such order"
were introduced after the clause "any order made or deemed to have been made
under this Act."
On December 7, 1955, the Imports (Control) Order was promulgated by the Central Government in
exercise of the powers conferred by ss. 3 and 4A of the Imports and Exports (Control) Act, 1947.
Clause 3 of this Order prohibited import of goods except in accordance with a licence issued by
specified authorities. Clause 5 authorised imposition of conditions under which goods could be
imported. Clause 5 provides as follows :
"Conditions of Licence.-(1) The licensing authority issuing a licence under this Order
may issue the same subject to one or more of the conditions stated below :Boothalinga Agencies vs V. T. C. Poriaswami Nadar on 22 April, 1968

(i) that the goods covered by the licence shall not be disposed of, except in the
manner prescribed by the licensing authority, or otherwise dealt with, without the
written permission of the licensing authority or any person duly authorised by it;
(ii) that the goods covered by the licence on importation shall not be sold or
distributed at a price exceeding that which may be specified in any directions
attached to the licence;
(iii) that the applicant for a licence shall execute a bond for complying with the terms
subject to which a licence may be granted. (2) A licence granted under this Order may
contain such other conditions, not inconsistent with the Act or this Order, as the
licensing authority may deem fit. (3) It shall be, deemed to be a condition of every
such licence, that :
(i) no person shall -transfer and no person shall acquire by transfer any licence issued
by the licensing authority except under and in accordance with the written
permission of the authority which granted the licence or of any other person
empowered in this behalf by such authority;
(ii) that the goods for the import of which a licence is granted shall be the property of
the licensee at the time of import and thereafter upto the time of clearance through
Customs;
(iii) the goods for the import of which a licence is granted shall be new goods unless
otherwise stated in the licence. (4) The licensee shall comply with all condition
imposed or deemed to be imposed under this clause."
Notification No. 23. ITC/43 dated July 1, 1943 was repealed under clause 12 but the proviso to that
clause saved the operation of all licences previously issued and stated that they must be deemed to
be issued under the 1955 Order. Clause 12 reads as follows :
"12. Repeals- The Orders contained in the notifications specified in Schedule IV are
hereby repealed :
Provided that anything done or any action taken, including any appointment made or
licence issued under any of the aforesaid Orders, shall be deemed to have been done
or taken under the corresponding provision of this Order.
Schedule IV Notifications repealed
1. Notification No. 23-ITC/43, dated the 1st July, 1943 issued by the late Department
of Commerce, as amended.Boothalinga Agencies vs V. T. C. Poriaswami Nadar on 22 April, 1968

2. Notification No. 2-ITC/48, dated 6th March, 1948, issued by the late Ministry of
Commence.
On the basis of these provisions it was contended by Mr. Gokhale on behalf of the appellant that the
contract which is the sabject-matter of the suit was unlawful and the respondent cannot claim
damages for breach of such a contract. It was not disputed by Mr. Gokhale that the contract between
the parties was entered into on November 26, 1955 before the coming into force of the Imports
(Control) Order. It was nevertheless argued that a breach of the conditions of the licence was
punishable under s. 5 of Act XVIII of 1947 as it stood at the relevant time and therefore the contract
was illegal and no claim for the breach thereof was maintainable. The contention of the appellant
was that the contravention of the terms of the licence issued, under the notification dated March 6,
1948 was a contravention of the notification itself within the meaning of s. 5 of Act XVIII of 1947
and was punishable. We are unable to accept this argument as correct. It is clear that s. 5 before its
amendment only penalised the contravention of any order made or deemed to have been made
under the Act. It is true that a licence was granted by virtue of a statutory notification dated March
6, 1948 issued under the Defence of India Rules and later deemed to have been issued under Act
XVIII of 1947. Notification No. 23-ITC/43, dated July 1, 1943 merely provides that no goods shall be
imported except the goods covered by special licences issued by an authorised, OSup. C. I./68-6
,officer. Notification No. 2-ITC/48, dated March 6, 1943 authorises the licensing officer to impose,
one or more conditions prescribed by that order and the licensing officer has therefore power to
impose conditions in the licence issued by him, but if the licensee contravenes the conditions
imposed by the licence it is difficult to hold that it is not merely a contravention of the ,conditions of
a licence but there is contravention of the terms of the notification and so the provisions of s. 5 of
Act XVIII of 1947 are attracted. Reference was made on behalf of the appellant to the amendment
made of s. 5 of Act XVIII of 1947 by the Amending Act 4 of 1960. By the Amending Act s. 5 of Act
XVIII of 1947 was amended so as to include contravention of a condition of a licence granted under
any order as an offence under s. 5 of the Act. It is not, however permissible, in the circumstances of
the present case, to construe the language of s. 5 of the parent Act with the aid of the Amending Act
(Act 4 of 1960). It is not possible for us to accept the contention of Mr. Gokhale that the Amending
Act of 1960 is something in the nature ,of a Parliamentary exposition of the meaning of s. 5 as it
stood in the parent Act. It follows therefore that on the material, date a breach of the condition of- a
licence was not tantamount to a breach of the statutory order within the meaning of s. 5 of Act XVIII
of 1947. The view that we have expressed is borne out by the decision of this Court in East India
Commercial Co. Ltd. Calcutta v. The Collector of Customs, Calcutta(1) in which it was held by the
majority judgment that an infringement of the condition of a licence was not equivalent to an
infringement of the two ,orders dated July 1, 1943 and March 6, 1948 i.e., Nos. 23-ITC/43 and
2-ITC/48 made under the Imports and Exports (Control) Act, 1947 and therefore the provisions of s.
167(8) of the Sea Customs Act were not attracted. We accordingly reject the argument of Mr.
Gokhale on this aspect of the case.
We pass on to consider the next contention put forward on behalf of the appellant, namely, that in
any event the imports (Control) Order, 1955 had come into force on December 7, 1955 and the
performance of the contract became illegal after that date. It was pointed out that the goods arrived
at the Madras port on December 13, 1955 and were cleared on December 20, 1955. Reference wasBoothalinga Agencies vs V. T. C. Poriaswami Nadar on 22 April, 1968

made to the conditions imposed in the licence, Ex. B-9. that "the goods will be utilised only for
consumption as raw material or accessories in the licence holder's factory and that no portion
thereof will be sold to any party". It was contended that the appellant would be committing an
offence under s. 5 of Act XVIII of 1947 if he sold the goods to the respondent in pursuance of the
contract as the condition of the (1) [1963] 3 S.C.R. 338.
licence would be violated. In our opinion, the argument of the appellant is well-founded and must be
accepted as correct. It is manifest that the disposal of the imported chicory which arrived at Madras
port on December 13, 1955 was governed by the provisions of the Imports (Control) Order, 1955
which came into force on December 7, 1955. Clause 5(4) of the 1955 Order expressly provides that
the licensee shall comply with all the conditions imposed or deemed to be imposed under that
clause. Therefore the sale of the imported goods would be a direct contravention of cl. 5(4) and
under s. 5 of the Imports and Exports (Control) Act, 1947 any contravention of the Act or any order
made or deemed to have been made under the Act is punishable with imprisonment up to one year
or fine or both. In consequence, even though the contract was enforceable on November 26, 1955
when it was entered into, the performance of the contract became impossible or unlawful after
December 7, 1955 and so the contract became void under s. 56 of the Indian Contract Act after the
coming into force of the Imports (Control) Order, 1955. Section 56 of the Indian Contract Act states :
"An agreement to do an Act impossible in itself is void.
A contract to do an Act which, after the contract is made, becomes impossible, or, by
reason of some event which the promisor could not prevent, unlawful, becomes void
when the act becomes impossible, or unlawful. Where one person has promised to do
something which he knew, or, with reasonable diligence, might have known, and
which the promisee did not know to be impossible or unlawful, such promisor must
make compensation to such promisee for any loss which such promisee sustains
through the nonperformance of the promise."
The doctrine of frustration of contract is really an aspect or part of the law of discharge of contract
by reason of supervening impossibility or illegality of the act agreed to be done and hence comes
within the purview of s. 56 of the Indian Contract Act. It should be noticed that s. 56 lays down a
rule of positive law and does not leave the matter to be determined according to the intention of the
parties. In English Law a case of supervening illegality is treated as an instance of frustration of
contract. In Metropolitan Water Board v. Dick, Kerr & Co., Ltd(1), under a contract made in (1)
[1918] A.C. 119, July 1914, a reservoir was to be constructed and to be completed in six years from
1914 subject to a proviso that if the contractors should be impeded or obstructed by any cause the
engineer should have power to grant an extension of time. Under the powers conferred by the
Defence of the Realm Acts and Regulations, the contractors were obliged to cease work on the
reservoir by order of the Ministry of Munitions in 1916. The House of Lords held that the contract
was frustrated by supervening impossibility, and that the provision for extending the time did not
apply to the prohibition by the Ministry. Lord Finlay, L.C. said that the interruption was "of such a
character and duration that it vitally and fundamentally changed the conditions of the contract, and
could not possibly have been in the, contemplation of the parties to the contract when it was made."Boothalinga Agencies vs V. T. C. Poriaswami Nadar on 22 April, 1968

In a subsequent case-Denny, Mott and Dickson Ltd. v. James B, Fraser & Co., Ltd.(1) a contract for
the sale and purchase of timber contained an option for the appellants to purchase a timber-yard
(which was meanwhile let to them) if the contract was terminated on notice given by either party. By
the Control of Timber (No. 4) Order, 1939, further trading transactions under the contract became
illegal, but in 1941 the appellants gave notice to terminate the contract, and also to exercise their
option to purchase the timber-yard. The House of Lords held that the option to purchase was
dependent on the trading agreement, that the 1939 Order had operated to frustrate the contract, and
that, consequently, the option to purchase lapsed upon the frustration since it arose only if the
contract was terminated by notice. At page 274 of the Report, Lord Wright made the following
observations "It is now I think well settled that where there is frustration a dissolution of a contract
occurs automatically. It does not depend, as does rescission of a contract on the ground of
repudiation or breach, on the choice or election of either party. I t depends on what actually has
happened on its effect on the possibility of performing the contract. Where, as generally happens,
and actually happened in the present case, one party claims that there has been frustration and the
other party contests it, the court decides the issue and decides it ex post facto on the actual
circumstances of the case. The data for decision are, on the one hand, the terms and construction of
the contract, read in the light of the then existing circumstances, and on the other hand the events
which have occurred............. I find the theory of the basis of the rule in Lord Sumner's pregnant
statement (loc. cit.) that the doctrine of frustration is really a de- vice by which the rules as to abso-
(1) [1944] A.C, 265.
lute contracts are reconciled with the special exception which justice demands. Though it has been
constantly said by high authority, including Lord Sumner,, that the explanation of the rule is to be
found in the theory that it depends on an implied condition of the contract, that is really no
explanation. It only pushes back the problem a single stage. It -leaves the question what is the
reason for implying a term. Nor can I reconcile that theory with the view that the result does not
depend on what the parties might, or would as hard bargainers, have agreed. The doctrine is
invented by the court in order to supplement the defects of the actual contract. The parties did not
anticipate, fully and completely, if at all, or provide, for what actually happened."
In the recent case of British Movietonews Ltd. v. London and District Cinemas Ltd.(1), Denning; L.J.
in the Court of Appeal took the view that "the court really exercises a qualifying power-a power to
qualify the absolute, literal or wide terms of the contract-in order to do what is just and reasonable
in the new situation". "The day is gone," the learned Judge went on to, say, "when we can excuse an
unforeseen injustice by saying to the sufferer 'it is your own folly, you ought not to have passed that
form of words. You ought to have put in a clause to protect yourself.' We no longer credit a party
with the foresight of a Prophet or his lawyer with the draftsmanship of a Chalmers. We realise that
they have their limitations and make allowances accordingly. It is better thus. The old maxim
reminds us that he who clings to the letter clings to the dry and barren shell and misses the truth
and substance of the matter. We have of late paid heed to this warning, and we must pay like heed
now." The decision of the Court of Appeal was reversed by the House of Lords(2) and Viscount
Simon expressed disapproval of the view taken by Denning, L.J. At page 184 of the Report, Viscount
Simon said:Boothalinga Agencies vs V. T. C. Poriaswami Nadar on 22 April, 1968

"The principle remains the same. Particular applications of it may greatly vary and
theoretical lawyers may debate whether the rule should be regarded as arising fro m
implied term or because the basis of the ,contract no longer exists. In any view, it is a
question of construction as Lord Wright pointed out in Constantine's case and as has
been repeatedly asserted by other masters of law."
In English Law therefore the question of frustration of con- tract has been treated by courts as a
question of construction (1) [1951] 1 K.B. 190 (2) [1957] A.C. 166 at 184.
depending upon the true intention of the parties. In contrast, the statutory provisions contained in
S. 56 of the Indian Contract Act lay down a positive rule of law and English authorities cannot
therefore be of direct assistance, though they have persuasive value in showing how English courts
have approached and decided cases under similar circumstances.
Counsel on behalf of the respondent, however, contended that the contract was not impossible of
performance and the appellant cannot take recourse to the provisions of s. 56 of the Indian Contract
Act. It was contended that under cl. 1 of the Import Trade Control Order No. 2-ITC/48, dated March
6, 1948 it was open to the appellant to apply for a written permission of the licensing authority to
sell the chicory. It is not shown by the appellant that he applied for such permission and the
licensing authority had refused such permission. It was therefore maintained on behalf of the
respondent that the contract was not impossible of performance. We, do not think there is any
substance in this argument. It is true that the licensing authority could have given written
permission for disposal of the chicory under, cl. 1 of Order No. 2-ITC/48, dated March 6, 1948 but
the condition imposed in Ex. B-9 in the present case is a special condition imposed under cl. (v) of
paragraph (a) of Order No. 2-ITC/48, dated March 6, 1948 and there was no option given under this
clause for the licensing authority to modify the condition of licence that " the goods will be utilised
only for consumption as raw material or accessories in the licence holder's factory and
-that no portion thereof will be sold to any party". It was further argued on behalf of the respondent
that, in any event, the appellant could have purchased chicory from the open market and supplied it
to the respondent in terms of
-the contract. There is no substance in this argument also. Under the contract the quality of chicory
to be sold was chicory of specific description"Egberts Chicory, packed in 495 wooden cases, each
case containing 2 tins of 56 1b. nett". The delivery of the chicory was to be given by "S. S. Alwaki" in
December, 1955. It is manifest that the contract, Ex. A-1 was for sale of certain specific goods as
described therein and it was not open to the appellant to supply chicory of any other description.
Reference was made on behalf of the respondent to the decision in Maritime National Fish, Limited
v. Ocean Trawlers, Limited(1). In that case, the respondents chartered to the appellants a steam
trawler fitted with an otter trawl. Both parties knew at the time of the contract that it was illegal to
use an otter trawl without a licence from the, Canadian government. Some months later the
appellants applied for licences for five trawlers which they were operating, including (1) [1935] A.C.
524.Boothalinga Agencies vs V. T. C. Poriaswami Nadar on 22 April, 1968

the respondents' trawler. They were informed that only three licences would be granted, and were
requested to state for which of the three trawlers they desired to have licences. They named three
trawlers other than the respondents', and then claimed that they were no longer bound by the
charter-party as its object had been frustrated. It was held by the Judicial Committee that the failure
of the contract was the result of the appellants' own election, and that there was therefore no
frustration of the contract. 'We think the principle of this case applies to the Indian law and the
provisions of s. 56 of the Indian Contract Act cannot apply to a case of "self-induced frustration". In
other words, the doctrine of frustration of contract cannot apply where the event which is alleged to
have frustrated the contract arises from the act or election of a party. But for the reasons already
given, we hold that this principle cannot be applied to the present case for there was no choice or
election left to the appellant to supply chicory other than under the terms of the contract. On the
other hand, there was a positive prohibition imposed by the licence upon the appellant not to sell
the imported chicory to any other party but he was permitted to utilise it only for consumption as
raw material in his own factory. We, are accordingly of the opinion that Counsel for the respondent
has been unable to make good his argument on this aspect of the case.
For the reasons expressed we hold that this appeal should be allowed and the decree of the Madras
High Court in A.S. No. 367 of 1958 should be set aside and the suit brought by the respondent
should be dismissed in its entirety. We do not propose to make any order as to costs in this appeal.
Y.P.                       Appeal allowed.Boothalinga Agencies vs V. T. C. Poriaswami Nadar on 22 April, 1968

