District Bar Association Dehradun vs Ishwar Shandilya on 28
February, 2020
Equivalent citations: AIR 2020 SUPREME COURT 1412, AIRONLINE 2020 SC
263, (2020) 4 SCALE 445
Author: M. R. Shah
Bench: M. R. Shah, Arun Mishra
                                                          1
                                                                                   REPORTABLE
                                       IN THE SUPREME COURT OF INDIA
                                        CIVIL APPELLATE JURISDICTION
                            SPECIAL LEAVE PETITION (CIVIL) NO. 5440 OF 2020
                                      [@ DIARY NO. 1476 OF 2020]
          District Bar Association, Dehradun
          through its Secretary                                                  .. Petitioner
                                                        Versus
          Ishwar Shandilya & Ors.                                                .. Respondents
                                                  JUDGMENT
M. R. Shah, J.
1. Feeling aggrieved and dissatisfied with the impugned judgment and order dated 25.09.2019
passed by the High Court of Uttarakhand at Nainital in Writ Petition (PIL) No. 31 of 2016, the
District Bar Association, Dehrarun, through its Secretary, has preferred the present SLP. That by the
impugned judgment and order, the High Court in the writ petition (PIL) filed by the private
respondent herein has issued the following directions:
“The District Bar Associations of Dehradun, Haridwar and Udham Singh Nagar shall,
forthwith, withdraw their call for a strike, Reason:
and start attending Courts on all working Saturdays. All the District Bar Associations
in the State shall forthwith refrain from abstaining from Courts because of
condolence references for family members of Advocates, or for other reasons. In caseDistrict Bar Association Dehradun vs Ishwar Shandilya on 28 February, 2020

they do not start attending Courts, as directed hereinabove, the District Judges
concerned shall submit their respective reports to the High Court for it to consider
whether action should be initiated against the errant Advocates under the Contempt
of Courts Act.
The Bar Council of India shall at the earliest, and in any event within three months
from today, take action against the recalcitrant Bar Associations pursuant to its
show-cause notice dated 12.07.2019, and ensure that these Bar Associations desist
from continuing such strikes/boycott of Courts.
The Uttarakhand State Bar Council shall, within a period of four weeks from today,
initiate disciplinary action against the office bearers of the aforesaid District Bar
Associations for their having given a call for illegal strikes/boycott of Courts on
Saturdays in the judgeship of Dehradun, Haridwar and Udham Singh Nagar.
The District Judges of these districts shall ensure that Courts function on Saturdays,
and sufficient cases are listed and are disposed of by Courts, under their judgeship,
on all working Saturdays.
The Commissioner of Police/Senior Superintendent of Police, of the concerned
districts, shall, as and when requested by the District Judge or a Judicial Officer,
regarding the possibility of Court proceedings being impeded because of
strike/boycott of Courts by Advocates, forthwith provide necessary police protection
to ensure smooth functioning of Courts, and thereby prevent any impediment to
Court proceedings because of strikes/boycott by Bar Associations/Advocates.
The High Court is requested to consider taking appropriate measures to ensure
functioning of Courts on Saturdays, that judicial work is not hampered by such illegal
strikes/boycott of Courts and wholly unjustified condolence references, and that the
Circular issued by it earlier on 12.03.2019 is implemented.”
2. From the impugned judgment and order passed by the High Court, it appears that the Advocates
in the entire District of Dehradun, in several districts of Haridwar and Udham Singh Nagar district
in the State of Uttarakhand have been boycotting the Courts on all Saturdays for the past more than
35 years. As the strikes are seriously obstructing the access to justice to the needy litigants,
respondent No. 1 was compelled to approach the High Court by way of Writ Petition (PIL). Having
noted from the information sent by the High Court to the Law Commission that with respect to the
State of Uttarakhand for the years 2012- 2016 showed that in Dehradun district, the Advocates were
on strike for 455 days (on an average 91 days per year) and in Haridwar district it is 515 days (about
103 days per year), the High Court was of the opinion that on all such working days on account of
strikes and the conduct of the Advocates in boycotting Courts, it has affected the functioning of the
Courts and it contributes to the ever-mounting pendency of the cases, and therefore aforesaid
directions have been issued by the High Court.District Bar Association Dehradun vs Ishwar Shandilya on 28 February, 2020

3. Feeling aggrieved and dissatisfied with the impugned judgment and order passed by the High
Court, the District Bar Association, Dehradun has preferred the present SLP.
4. Shri Mahabir Singh, learned Senior Advocate appearing on behalf of the petitioner has
vehemently submitted that the High Court has not properly appreciated and considered the fact that
the right to go on strike/boycott courts is a fundamental right to Freedom of Speech and Expression
guaranteed under Article 19(1)(a) of the Constitution of India.
4.1 It is vehemently submitted by the learned Senior Advocate appearing on behalf of the petitioner
that the strike is a mode of peaceful representation to express the grievances by the lawyers’
community in absence of no other forum is available.
4.2 It is further submitted by the learned Senior Advocate appearing on behalf of the petitioner that
the High Court ought to have held that the protection conferred by Section 48 of the Advocates Act
is for any act done in good faith and therefore the directions issued by the High Court to take action
against the Advocates on strike would be contrary to the protection conferred by Section 48 of the
Advocates Act.
5. The learned Senior Advocate appearing on behalf of the petitioner has stated at the Bar that, as
such, the Bar Association has already withdrawn the strike and/or boycotting Courts on all
Saturdays, his statement is taken on record.
6. Having heard the learned Senior Advocate appearing on behalf of the petitioner and considering
the impugned judgment and order passed by the High Court, more particularly, the directions
issued by the High Court, which are reproduced hereinabove, we are of the firm opinion that the
High Court is absolutely justified in issuing such directions. As such, the directions issued by the
High Court are absolutely in consonance with the decisions of this Court in the cases of Ex-Capt.
Harish Uppal v. Union of India (2003) 2 SCC 45; Common Cause, A Registered Society v. Union of
India (2006) 9 SCC 295 and Krishnakant Tamrakar v. State of M.P. (2018) 17 SCC 27.
6.1 In the case of Ex-Capt. Harish Uppal (supra), this Court has specifically observed and held that
the lawyers have no right to go on strike or even token strike or to give a call for strike. It is also
further observed that nor can they while holding Vakalat on behalf of clients, abstain from
appearing in courts in pursuance of a call for strike or boycott. It is further observed by this Court
that it is unprofessional as well as unbecoming for a lawyer to refuse to attend the court even in
pursuance of a call for strike or boycott by the Bar Association or the Bar Council. It is further
observed that an Advocate is an officer of the court and enjoys a special status in the society;
Advocates have obligations and duties to ensure the smooth functioning of the court; they owe a
duty to their clients and strikes interfere with the administration of justice. They cannot thus disrupt
court proceedings and put interest of their clients in jeopardy.
6.2 While considering the role of the Bar Councils, it is observed in paragraphs 25 and 26 of the
aforesaid decision as under:District Bar Association Dehradun vs Ishwar Shandilya on 28 February, 2020

“25. In the case of Supreme Court Bar Assn. v. Union of India [(1998) 4 SCC 409] it
has been held that professional misconduct may also amount to contempt of court
(para 21). It has further been held as follows: (SCC pp. 444-46, paras 79-80) “79. An
advocate who is found guilty of contempt of court may also, as already noticed, be
guilty of professional misconduct in a given case but it is for the Bar Council of the
State or Bar Council of India to punish that advocate by either debarring him from
practice or suspending his licence, as may be warranted, in the facts and
circumstances of each case. The learned Solicitor-General informed us that there
have been cases where the Bar Council of India taking note of the contumacious and
objectionable conduct of an advocate, had initiated disciplinary proceedings against
him and even punished him for ‘professional misconduct’, on the basis of his having
been found guilty of committing contempt of court. We do not entertain any doubt
that the Bar Council of the State or Bar Council of India, as the case may be, when
apprised of the established contumacious conduct of an advocate by the High Court
or by this Court, would rise to the occasion, and take appropriate action against such
an advocate. Under Article 144 of the Constitution ‘all authorities, civil and judicial,
in the territory of India shall act in aid of the Supreme Court’. The Bar Council which
performs a public duty and is charged with the obligation to protect the dignity of the
profession and maintain professional standards and etiquette is also obliged to act ‘in
aid of the Supreme Court’. It must, whenever facts warrant, rise to the occasion and
discharge its duties uninfluenced by the position of the contemner advocate. It must
act in accordance with the prescribed procedure, whenever its attention is drawn by
this Court to the contumacious and unbecoming conduct of an advocate which has
the tendency to interfere with due administration of justice. It is possible for the High
Courts also to draw the attention of the Bar Council of the State to a case of
professional misconduct of a contemner advocate to enable the State Bar Council to
proceed in the manner prescribed by the Act and the Rules framed thereunder. There
is no justification to assume that the Bar Councils would not rise to the occasion, as
they are equally responsible to uphold the dignity of the courts and the majesty of law
and prevent any interference in the administration of justice. Learned counsel for the
parties present before us do not dispute and rightly so that whenever a court of
record records its findings about the conduct of an advocate while finding him guilty
of committing contempt of court and desires or refers the matter to be considered by
the Bar Council concerned, appropriate action should be initiated by the Bar Council
concerned in accordance with law with a view to maintain the dignity of the courts
and to uphold the majesty of law and professional standards and etiquette. Nothing is
more destructive of public confidence in the administration of justice than incivility,
rudeness or disrespectful conduct on the part of a counsel towards the court or
disregard by the court of the privileges of the Bar. In case the Bar Council, even after
receiving ‘reference’ from the Court, fails to take action against the advocate
concerned, this Court might consider invoking its powers under Section 38 of the Act
by sending for the record of the proceedings from the Bar Council and passing
appropriate orders. Of course, the appellate powers under Section 38 would be
available to this Court only and not to the High Courts. We, however, hope that suchDistrict Bar Association Dehradun vs Ishwar Shandilya on 28 February, 2020

a situation would not arise.
80. In a given case it may be possible, for this Court or the High Court, to prevent the
contemner advocate to appear before it till he purges himself of the contempt but that
is much different from suspending or revoking his licence or debarring him to
practise as an advocate. In a case of contemptuous, contumacious, unbecoming or
blameworthy conduct of an Advocate-on-Record, this Court possesses jurisdiction,
under the Supreme Court Rules itself, to withdraw his privilege to practise as an
Advocate-on-Record because that privilege is conferred by this Court and the power
to grant the privilege includes the power to revoke or suspend it. The withdrawal of
that privilege, however, does not amount to suspending or revoking his licence to
practise as an advocate in other courts or tribunals.” Thus a Constitution Bench of
this Court has held that the Bar Councils are expected to rise to the occasion as they
are responsible to uphold the dignity of courts and majesty of law and to prevent
interference in administration of justice. In our view it is the duty of the Bar Councils
to ensure that there is no unprofessional and/or unbecoming conduct.
This being their duty no Bar Council can even consider giving a call for strike or a call for boycott. It
follows that the Bar Councils and even Bar Associations can never consider or take seriously any
requisition calling for a meeting to consider a call for a strike or a call for boycott. Such requisitions
should be consigned to the place where they belong viz. the waste-paper basket. In case any
Association calls for a strike or a call for boycott the State Bar Council concerned and on their failure
the Bar Council of India must immediately take disciplinary action against the advocates who give a
call for strike and if the Committee members permit calling of a meeting for such purpose, against
the Committee members. Further, it is the duty of every advocate to boldly ignore a call for strike or
boycott.
26. It must also be noted that courts are not powerless or helpless. Section 38 of the Advocates Act
provides that even in disciplinary matters the final appellate authority is the Supreme Court.
Thus even if the Bar Councils do not rise to the occasion and perform their duties by taking
disciplinary action on a complaint from a client against an advocate for non-appearance by reason of
a call for strike or boycott, on an appeal the Supreme Court can and will. Apart from this, as set out
in Ramon Services case [(2001) 1 SCC 118 : 2001 SCC (Cri) 3 : 2001 SCC (L&S) 152] every court now
should and must mulct advocates who hold vakalats but still refrain from attending courts in
pursuance of a strike call with costs. Such costs would be in addition to the damages which the
advocate may have to pay for the loss suffered by his client by reason of his non-appearance.” 6.3 In
the aforesaid decision, this Court took note of the resolution dated 29.09.2002 passed by the Bar
Council of India, by which it was resolved, inter alia, to constitute the Grievance Redressel
Committees at the Taluk/Sub-Division or Tehsil levels, at the District level, High Court and
Supreme Court levels.
Thereafter, this Court further observed that merely holding strikes as illegal would not be sufficient
in the present-days situation nor would it serve any purpose.District Bar Association Dehradun vs Ishwar Shandilya on 28 February, 2020

Some concrete joint action is required to be taken by the Bench and the Bar to see that there are no
strikes any more. That, thereafter, this Court directed that (a) all the Bar Associations in the country
shall implement the resolution dated 29.09.2002 passed by the Bar Council of India, and (b) under
Section 34 of the Advocates Act, the High Courts would frame necessary rules so that appropriate
actions can be taken against defaulting advocate/advocates.
6.4 Despite the law laid down by this Court in the aforesaid decisions and even the concern
expressed by this Court against the strikes by the lawyers, things did not improve and again the
issue of lawyers going on strikes came to be considered in the case of Common Cause, A Registered
Society (supra) and this Court in paragraph 4 of that judgment, held as under:
“4. The Constitution Bench has, in Ex Capt. Harish Uppal case [(2003) 2 SCC 45]
culled out the law in the following terms: (SCC pp. 64 & 71-74, paras 20-21 & 34-36)
“20. Thus the law is already well settled. It is the duty of every advocate who has
accepted a brief to attend trial, even though it may go on day to day and for a
prolonged period. It is also settled law that a lawyer who has accepted a brief cannot
refuse to attend court because a boycott call is given by the Bar Association. It is
settled law that it is unprofessional as well as unbecoming for a lawyer who has
accepted a brief to refuse to attend court even in pursuance of a call for strike or
boycott by the Bar Association or the Bar Council. It is settled law that courts are
under an obligation to hear and decide cases brought before them and cannot
adjourn matters merely because lawyers are on strike. The law is that it is the duty
and obligation of courts to go on with matters or otherwise it would tantamount to
becoming a privy to the strike. It is also settled law that if a resolution is passed by
Bar Associations expressing want of confidence in judicial officers, it would amount
to scandalising the courts to undermine its authority and thereby the advocates will
have committed contempt of court. Lawyers have known, at least since Mahabir
Singh case [Mahabir Prasad Singh v. Jacks Aviation (P) Ltd., (1999) 1 SCC 37] that if
they participate in a boycott or a strike, their action is ex facie bad in view of the
declaration of law by this Court. A lawyer's duty is to boldly ignore a call for strike or
boycott of court(s).
Lawyers have also known, at least since Ramon Services case [Ramon Services (P) Ltd. v Subhash
Kapoor, (2001) 1 SCC 118 : 2001 SCC (Cri) 3 : 2001 SCC (L&S) 152] , that the advocates would be
answerable for the consequences suffered by their clients if the non-appearance was solely on
grounds of a strike call.
21. It must also be remembered that an advocate is an officer of the court and enjoys special status
in society. Advocates have obligations and duties to ensure smooth functioning of the court. They
owe a duty to their clients. Strikes interfere with administration of justice. They cannot thus disrupt
court proceedings and put interest of their clients in jeopardy.
***District Bar Association Dehradun vs Ishwar Shandilya on 28 February, 2020

34. One last thing which must be mentioned is that the right of appearance in courts is still within
the control and jurisdiction of courts. Section 30 of the Advocates Act has not been brought into
force and rightly so. Control of conduct in court can only be within the domain of courts. Thus
Article 145 of the Constitution of India gives to the Supreme Court and Section 34 of the Advocates
Act gives to the High Court power to frame rules including rules regarding condition on which a
person (including an advocate) can practise in the Supreme Court and/or in the High Court and
courts subordinate thereto. Many courts have framed rules in this behalf. Such a rule would be valid
and binding on all. Let the Bar take note that unless self-restraint is exercised, courts may now have
to consider framing specific rules debarring advocates guilty of contempt and/or unprofessional or
unbecoming conduct, from appearing before the courts. Such a rule if framed would not have
anything to do with the disciplinary jurisdiction of the Bar Councils. It would be concerning the
dignity and orderly functioning of the courts. The right of the advocate to practise envelops a lot of
acts to be performed by him in discharge of his professional duties. Apart from appearing in the
courts he can be consulted by his clients, he can give his legal opinion whenever sought for, he can
draft instruments, pleadings, affidavits or any other documents, he can participate in any conference
involving legal discussions, he can work in any office or firm as a legal officer, he can appear for
clients before an arbitrator or arbitrators etc. Such a rule would have nothing to do with all the acts
done by an advocate during his practice. He may even file vakalat on behalf of a client even though
his appearance inside the court is not permitted. Conduct in court is a matter concerning the court
and hence the Bar Council cannot claim that what should happen inside the court could also be
regulated by them in exercise of their disciplinary powers. The right to practise, no doubt, is the
genus of which the right to appear and conduct cases in the court may be a specie. But the right to
appear and conduct cases in the court is a matter on which the court must and does have major
supervisory and controlling power. Hence courts cannot be and are not divested of control or
supervision of conduct in court merely because it may involve the right of an advocate. A rule can
stipulate that a person who has committed contempt of court or has behaved unprofessionally and
in an unbecoming manner will not have the right to continue to appear and plead and conduct cases
in courts. The Bar Councils cannot overrule such a regulation concerning the orderly conduct of
court proceedings. On the contrary, it will be their duty to see that such a rule is strictly abided by.
Courts of law are structured in such a design as to evoke respect and reverence to the majesty of law
and justice. The machinery for dispensation of justice according to law is operated by the court.
Proceedings inside the courts are always expected to be held in a dignified and orderly manner. The
very sight of an advocate, who is guilty of contempt of court or of unbecoming or unprofessional
conduct, standing in the court would erode the dignity of the court and even corrode its majesty
besides impairing the confidence of the public in the efficacy of the institution of the courts. The
power to frame such rules should not be confused with the right to practise law. While the Bar
Council can exercise control over the latter, the courts are in control of the former. This distinction
is clearly brought out by the difference in language in Section 49 of the Advocates Act on the one
hand and Article 145 of the Constitution of India and Section 34(1) of the Advocates Act on the
other. Section 49 merely empowers the Bar Council to frame rules laying down conditions subject to
which an advocate shall have a right to practise i.e. do all the other acts set out above. However,
Article 145 of the Constitution of India empowers the Supreme Court to make rules for regulating
this practice and procedure of the court including inter alia rules as to persons practising before this
Court. Similarly Section 34 of the Advocates Act empowers High Courts to frame rules, inter alia toDistrict Bar Association Dehradun vs Ishwar Shandilya on 28 February, 2020

lay down conditions on which an advocate shall be permitted to practise in courts. Article 145 of the
Constitution of India and Section 34 of the Advocates Act clearly show that there is no absolute right
to an advocate to appear in a court. An advocate appears in a court subject to such conditions as are
laid down by the court. It must be remembered that Section 30 has not been brought into force, and
this also shows that there is no absolute right to appear in a court. Even if Section 30 were to be
brought into force control of proceedings in court will always remain with the court. Thus even then
the right to appear in court will be subject to complying with conditions laid down by courts just as
practice outside courts would be subject to conditions laid down by Bar Council of India. There is
thus no conflict or clash between other provisions of the Advocates Act on the one hand and Section
34 or Article 145 of the Constitution of India on the other.
35. In conclusion, it is held that lawyers have no right to go on strike or give a call for boycott, not
even on a token strike. The protest, if any is required, can only be by giving press statements, TV
interviews, carrying out of court premises banners and/or placards, wearing black or white or any
colour armbands, peaceful protect marches outside and away from court premises, going on
dharnas or relay fasts, etc. It is held that lawyers holding vakalats on behalf of their clients cannot
refuse to attend courts in pursuance of a call for strike or boycott. All lawyers must boldly refuse to
abide by any call for strike or boycott. No lawyer can be visited with any adverse consequences by
the Association or the Council and no threat or coercion of any nature including that of expulsion
can be held out. It is held that no Bar Council or Bar Association can permit calling of a meeting for
purposes of considering a call for strike or boycott and requisition, if any, for such meeting must be
ignored. It is held that only in the rarest of rare cases where the dignity, integrity and independence
of the Bar and/or the Bench are at stake, courts may ignore (turn a blind eye) to a protest,
abstention from work for not more than one day. It is being clarified that it will be for the court to
decide whether or not the issue involves dignity or integrity or independence of the Bar and/or the
Bench. Therefore in such cases the President of the Bar must first consult the Chief Justice or the
District Judge before advocates decide to absent themselves from court. The decision of the Chief
Justice or the District Judge would be final and have to be abided by the Bar. It is held that courts
are under no obligation to adjourn matters because lawyers are on strike. On the contrary, it is the
duty of all courts to go on with matters on their boards even in the absence of lawyers. In other
words, courts must not be privy to strikes or calls for boycotts. It is held that if a lawyer, holding a
vakalat of a client, abstains from attending court due to a strike call, he shall be personally liable to
pay costs which shall be in addition to damages which he might have to pay his client for loss
suffered by him.
36. It is now hoped that with the above clarifications, there will be no strikes and/or calls for
boycott. It is hoped that better sense will prevail and self-restraint will be exercised. The petitions
stand disposed of accordingly.” The Court also dealt with the role of Bar Councils on the following
terms: (SCC pp. 66-68, paras 25-26) “25. In the case of Supreme Court Bar Assn. v. Union of India
[(1998) 4 SCC 409 : AIR 1998 SC 1895 : 1998 AIR SCW 1706] it has been held that professional
misconduct may also amount to contempt of court (para 21). It has further been held as follows:
(SCC pp. 444-46, paras 79-80) ‘79. An advocate who is found guilty of contempt of court may also,
as already noticed, be guilty of professional misconduct in a given case but it is for the Bar Council of
the State or Bar Council of India to punish that advocate by either debarring him from practice orDistrict Bar Association Dehradun vs Ishwar Shandilya on 28 February, 2020

suspending his licence, as may be warranted, in the facts and circumstances of each case. The
learned Solicitor General informed us that there have been cases where the Bar Council of India
taking note of the contumacious and objectionable conduct of an advocate, had initiated disciplinary
proceedings against him and even punished him for “professional misconduct”, on the basis of his
having been found guilty of committing contempt of court. We do not entertain any doubt that the
Bar Council of the State or Bar Council of India, as the case may be, when apprised of the
established contumacious conduct of an advocate by the High Court or by this Court, would rise to
the occasion, and take appropriate action against such an advocate. Under Article 144 of the
Constitution “all authorities, civil and judicial, in the territory of India shall act in aid of the
Supreme Court”. The Bar Council which performs a public duty and is charged with the obligation to
protect the dignity of the profession and maintain professional standards and etiquette is also
obliged to act “in aid of the Supreme Court”. It must, whenever facts warrant, rise to the occasion
and discharge its duties uninfluenced by the position of the contemnor advocate. It must act in
accordance with the prescribed procedure, whenever its attention is drawn by this Court to the
contumacious and unbecoming conduct of an advocate which has the tendency to interfere with due
administration of justice. It is possible for the High Courts also to draw the attention of the Bar
Council of the State to a case of professional misconduct of a contemnor advocate to enable the State
Bar Council to proceed in the manner prescribed by the Act and the rules framed thereunder. There
is no justification to assume that the Bar Councils would not rise to the occasion, as they are equally
responsible to uphold the dignity of the courts and the majesty of law and prevent any interference
in the administration of justice. Learned counsel for the parties present before us do not dispute and
rightly so that whenever a court of record records its findings about the conduct of an advocate
while finding him guilty of committing contempt of court and desires or refers the matter to be
considered by the Bar Council concerned, appropriate action should be initiated by the Bar Council
concerned in accordance with law with a view to maintain the dignity of the courts and to uphold the
majesty of law and professional standards and etiquette. Nothing is more destructive of public
confidence in the administration of justice than incivility, rudeness or disrespectful conduct on the
part of a counsel towards the court or disregard by the court of the privileges of the Bar. In case the
Bar Council, even after receiving “reference” from the Court, fails to take action against the advocate
concerned, this Court might consider invoking its powers under Section 38 of the Act by sending for
the record of the proceedings from the Bar Council and passing appropriate orders. Of course, the
appellate powers under Section 38 would be available to this Court only and not to the High Courts.
We, however, hope that such a situation would not arise.
80. In a given case it may be possible, for this Court or the High Court, to prevent the contemnor
advocate to appear before it till he purges himself of the contempt but that is much different from
suspending or revoking his licence or debarring him to practise as an advocate. In a case of
contemptuous, contumacious, unbecoming or blameworthy conduct of an Advocate-on-Record, this
Court possesses jurisdiction, under the Supreme Court Rules itself, to withdraw his privilege to
practise as an Advocate-on-Record because that privilege is conferred by this Court and the power to
grant the privilege includes the power to revoke or suspend it. The withdrawal of that privilege,
however, does not amount to suspending or revoking his licence to practise as an advocate in other
courts or tribunals.’ Thus a Constitution Bench of this Court has held that the Bar Councils are
expected to rise to the occasion as they are responsible to uphold the dignity of courts and majesty ofDistrict Bar Association Dehradun vs Ishwar Shandilya on 28 February, 2020

law and to prevent interference in administration of justice. In our view it is the duty of the Bar
Councils to ensure that there is no unprofessional and/or unbecoming conduct. This being their
duty no Bar Council can even consider giving a call for strike or a call for boycott. It follows that the
Bar Councils and even Bar Associations can never consider or take seriously any requisition calling
for a meeting to consider a call for a strike or a call for boycott. Such requisitions should be
consigned to the place where they belong viz. the waste-paper basket. In case any Association calls
for a strike or a call for boycott, the State Bar Council concerned and on its failure the Bar Council of
India must immediately take disciplinary action against the advocates who give a call for strike and
if the committee members permit calling of a meeting for such purpose, against the committee
members. Further, it is the duty of every advocate to boldly ignore a call for strike or boycott.
26. It must also be noted that courts are not powerless or helpless. Section 38 of the Advocates Act
provides that even in disciplinary matters the final Appellate Authority is the Supreme Court. Thus
even if the Bar Councils do not rise to the occasion and perform their duties by taking disciplinary
action on a complaint from a client against an advocate for non-appearance by reason of a call for
strike or boycott, on an appeal the Supreme Court can and will. Apart from this, as set out in Ramon
Services case [Ramon Services (P) Ltd. v. Subhash Kapoor, (2001) 1 SCC 118 : 2001 SCC (Cri) 3 :
2001 SCC (L&S) 152] every court now should and must mulct advocates who hold vakalats but still
refrain from attending courts in pursuance of a strike call, with costs. Such costs would be in
addition to the damages which the advocate may have to pay for the loss suffered by his client by
reason of his non-appearance.” Apart from reiterating the above law, we do not propose to take any
further action. The contempt notices stand discharged.” 6.5 While considering the issue of
delay/speedy disposal, in case of Krishnakant Tamrakar (supra), this Court had the occasion to
consider how uncalled for frequent strikes obstructs the access to justice and what steps are
required to remedy the situation. In the aforesaid decision, it is observed by this Court that access to
speedy justice is a part of the fundamental rights under Articles 14 and 21 of the Constitution of
India. This Court was of the opinion that one of the reasons/root cause for delay is uncalled for
strikes by the lawyers. In the aforesaid decision, this Court also took note of 266 th Law Commission
Report, in which there was a reference to the strikes by the lawyers in the Dehradun and Haridwar
districts itself. In the aforesaid decision, this Court also took note of the recommendations made by
the Law Commission. This Court further observed that since the strikes are in violation of the law
laid down by this Court, the same amounts to contempt and at least the office bearers of the
Associations who give call for the strikes cannot disown their liability for contempt. In paragraphs
41 to 50, this Court held as under:
“41. We may also deal with another important aspect of speedy justice. It is well
known that at some places there are frequent strikes, seriously obstructing access to
justice. Even cases of persons languishing in custody are delayed on that account. By
every strike, irreversible damage is suffered by the judicial system, particularly
consumers of justice. They are denied access to justice. Taxpayers' money is lost on
account of judicial and public time being lost. Nobody is accountable for such loss
and harassment.
42. Dr Ambedkar in his famous speech on 25-11-1949 had warned:District Bar Association Dehradun vs Ishwar Shandilya on 28 February, 2020

(CAD Vol. 11) “The first thing in my judgment we must do is to hold fast to
constitutional methods of achieving our social and economic objectives. It means we
must abandon the bloody methods of revolution. It means that we must abandon the
method of civil disobedience, non-cooperation and satyagraha. When there was no
way left for constitutional methods for achieving economic and social objectives,
there was a great deal of justification for unconstitutional methods. But where
constitutional methods are open, there can be no justification for these
unconstitutional methods. These methods are nothing but the Grammar of Anarchy
and the sooner they are abandoned, the better for us.”
43. The above warning of the Constitution-maker needs to be adhered to at least by
the legal fraternity. The Bar has the tradition of placing their professional duty of
assisting the access to justice above every other consideration. How is the situation to
be tackled.
Competent authorities may take a final call.
44. In Harish Uppal v. Union of India [Harish Uppal v. Union of India, (2003) 2 SCC 45] , this Court
held that lawyers have no right to go on strike or to give a call for boycott of courts nor can they
abstain from the courts. Calls given by Bar Association or Bar Council for such purpose cannot
require the court to adjourn the matters. Strike or abstaining from court is unprofessional. Even
though more than 15 years have passed after the said judgment was rendered, the judgment of this
Court is repeatedly flouted and no remedial measures have been adopted. Regulation of right of
appearance in courts is within the jurisdiction of the courts. This Court also asked the Law
Commission to suggest appropriate changes in the regulatory framework for the legal profession
[Mahipal Singh Rana v. State of U.P., (2016) 8 SCC 335 : (2016) 4 SCC (Civ) 1 : (2016) 3 SCC (Cri)
476 : (2016) 2 SCC (L&S) 390] . The Law Commission has submitted 266th Report [Ed.:
On The Advocates Act, 1961 (Regulation of Legal Profession)] . The problem
continues seriously affecting the rule of law.
45. In Mahipal Singh Rana [Mahipal Singh Rana v. State of U.P., (2016) 8 SCC 335 :
(2016) 4 SCC (Civ) 1 : (2016) 3 SCC (Cri) 476 :
(2016) 2 SCC (L&S) 390] , this Court noted that the High Courts can frame rules to
lay down conditions on which advocates can be permitted to practise in courts. An
advocate can be debarred from appearing in court even if the disciplinary jurisdiction
for misconduct is vested with the Bar Councils [Mahipal Singh Rana v State of U.P.,
(2016) 8 SCC 335, paras 20, 30 to 35] . This Court requested the Law Commission to
look into all relevant aspects relating to regulation of legal profession [Mahipal Singh
Rana v. State of U.P., (2016) 8 SCC 335, para 58] .
46. The Law Commission, accordingly, examined the relevant aspects relating to regulation of the
legal profession. The Law Commission in its 266th Report found that such conduct of the advocatesDistrict Bar Association Dehradun vs Ishwar Shandilya on 28 February, 2020

affects functioning of courts and particularly it contributes to pendency of cases. It analysed the data
on loss of working days on account of call of strikes. The analysis is as follows:
“7.2. In the State of Uttarakhand, the information sent by the High Court for the
years 2012-2016 shows that in Dehradun District, the advocates were on strike for
455 days during 2012- 2016 (on an average, 91 days per year). In Haridwar District,
515 days (103 days a year) were wasted on account of strike.
7.3. In the case of the State of Rajasthan, the High Court of Judicature at Jodhpur
saw 142 days of strike during 2012-
2016, while the figure stood at 30 for the Jaipur Bench. In Ajmer District Courts, strikes remained
for 118 days in the year 2014 alone, while in Jhalawar, 146 days were lost in 2012 on account of
strike.
7.4. The case of Uttar Pradesh appears to be the worst. The figures of strike for the years 2011-2016
in the subordinate courts are alarmingly high. In the State of Uttar Pradesh, the District Courts have
to work for 265 days in a year. The period of strike in five years period in worst affected districts has
been as Muzaffarnagar (791 days), Faizabad (689 days), Sultanpur (594 days), Varanasi (547 days),
Chandauli (529 days), Ambedkar Nagar (511 days), Saharanpur (506 days) and Jaunpur (510 days).
The average number of days of strike in eight worst affected districts comes to 115 days a year. Thus,
it is evident that the courts referred to hereinabove could work on an average for 150 days only in a
year.
7.5. In this regard, the situation in subordinate courts in Tamil Nadu had by no means, been better.
The High Court of Tamil Nadu has reported that there are 220 working days in a year for the courts
in the State. During the period 2011-2016, districts like Kancheepuram, 687 days (137.4 days per
year); Kanyakumari, 585 days (117 days per year); Madurai, 577 days (115.4 days per year);
Cuddalore, 461 days (92.2 days per year); and Sivagangai, 408 days (81.6 days per year), were the
most affected by strike called by advocates.
7.6. As per the responses received from the High Courts of Madhya Pradesh and Odisha, the picture
does not emerge to be satisfactory.
7.7. The Commission noted that the strike by advocates or their abstinence from the court were
hardly for any justifiable reasons. It could not find any convincing reasons for which the advocates
resorted to strike or boycott of work in the courts. The reasons for strike call or abstinence from
work varied from local, national to international issues, having no relevance to the working of the
courts. To mention a few, bomb blast in Pakistan school, amendments to Sri Lanka's Constitution,
inter-State river water disputes, attack on/murder of advocate, earthquake in Nepal, to condole the
death of their near relatives, to show solidarity to advocates of other State Bar Associations, moral
support to movements by social activists, heavy rains, or on some religious occasions such as
shraadh, Agrasen Jayanti, etc. or even for kavi sammelan.District Bar Association Dehradun vs Ishwar Shandilya on 28 February, 2020

7.8. The Commission is of the view that unless there are compelling circumstances and the approval
for a symbolic strike of one day is obtained from the Bar Council concerned, the advocates shall not
resort to strike or abstention from the court work.”
47. Thereafter, the Law Commission referred to observations in the judgment of this Court in Harish
Uppal case [Harish Uppal v. Union of India, (2003) 2 SCC 45] that there should be no strikes by the
Bar except in rarest of rare situations which should also not exceed one day. The Bar Councils were
called upon to take appropriate action in the matter. The Law Commission noted that the strikes
were continuing and causing great obstruction to the access to justice. It was observed: (Report No.
266) “8.3. In spite of all these, the strikes have continued unabated. The dispensation of justice must
not stop for any reason. The strike by lawyers have lowered the image of the courts in the eyes of the
general public. The Supreme Court has held that right to speedy justice is included in Article 21 of
the Constitution. In Hussainara Khatoon (1) v. State of Bihar [Hussainara Khatoon (1) v. State of
Bihar, (1980) 1 SCC 81 :
1980 SCC (Cri) 23] ; and in some other cases, it was held that the litigant has a right
to speedy justice. The lawyers' strike, however, result in denial of these rights to the
citizens in the State.
8.4. Recently, the Supreme Court while disposing of the criminal appeal of Hussain v.
Union of India [Hussain v. Union of India, (2017) 5 SCC 702 : (2017) 2 SCC (Cri)
638] deprecated the practice of boycotting the Court observing that:
‘27. One other aspect pointed out is the obstruction of court proceedings by uncalled
for strikes/abstaining of work by lawyers or frequent suspension of court work after
condolence references. In view of judgment of this Court in Harish Uppal v. Union of
India [Harish Uppal v. Union of India, (2003) 2 SCC 45] , such suspension of work or
strikes is clearly illegal and it is high time that the legal fraternity realises its duty to
the society which is the foremost. Condolence references can be once in a while
periodically say once in two/three months and not frequently. Hardship faced by
witnesses if their evidence is not recorded on the day they are summoned or impact
of delay on undertrials in custody on account of such avoidable interruptions of court
proceedings is a matter of concern for any responsible body of professionals and they
must take appropriate steps. In any case, this needs attention of all authorities
concerned—the Central Government/State Governments/Bar Councils/Bar
Associations as well as the High Courts and ways and means ought to be found out to
tackle this menace. Consistent with the above judgment, the High Courts must
monitor this aspect strictly and take stringent measures as may be required in the
interests of administration of justice.’ 8.5. In Ramon Services (P) Ltd. v. Subhash
Kapoor [Ramon Services (P) Ltd. v. Subhash Kapoor, (2001) 1 SCC 118 : 2001 SCC
(Cri) 3 : 2001 SCC (L&S) 152] , the Apex Court observed that if any advocate claims
that his right to strike must be without any loss to him, but the loss must only be
borne by his innocent client, such a claim is repugnant to any principle of fair play
and canons of ethics. Therefore, when he opts to strike or boycott the Court he mustDistrict Bar Association Dehradun vs Ishwar Shandilya on 28 February, 2020

as well be prepared to bear at least the pecuniary loss suffered by the litigant client
who entrusted his brief to that advocate with all confidence that his cause would be
safe in the hands of that advocate.”
48. Examining other aspects of the regulation of legal profession, the Law Commission
recommended review of regulatory mechanism of the Advocates Act as follows: (Report No. 266)
“17.1. There is a dire necessity of reviewing the regulatory mechanism of the Advocates Act, not only
in matters of discipline and misconduct of the advocates, but in other areas as well, keeping in view
the wide expanse of the legal profession being involved in almost all areas of life. The very
constitution of the Bar Councils and their functions also require the introduction of a few provisions
in order to consolidate the function of the Bar Councils in its internal matters as well.”
49. Since the strikes are in violation of law laid down by this Court, the same amount to contempt
and at least the office-bearers of the associations who give call for the strikes cannot disown their
liability for contempt. Every resolution to go on strike and abstain from work is per se contempt.
Even if proceedings are not initiated individually against such contemnors by the court concerned or
by the Bar Council concerned for the misconduct, it is necessary to provide for some mechanism to
enforce the law laid down by this Court, pending a legislation to remedy the situation.
50. Accordingly, we consider it necessary, with a view to enforce fundamental right of speedy access
to justice under Articles 14 and 21 and law laid by this Court, to direct the Ministry of Law and
Justice to present at least a quarterly report on strikes/abstaining from work, loss caused and action
proposed. The matter can thereafter be considered in its contempt or inherent jurisdiction of this
Court. The Court may, having regard to the fact situation, hold that the office-bearers of the Bar
Association/Bar Council who passed the resolution for strike or abstaining from work, are liable to
be restrained from appearing before any court for a specified period or until such time as they purge
themselves of contempt to the satisfaction of the Chief Justice of the High Court concerned based on
an appropriate undertaking/conditions. They may also be liable to be removed from the position of
office-bearers of the Bar Association forthwith until the Chief Justice of the High Court concerned so
permits on an appropriate undertaking being filed by them. This may be in addition to any other
action that may be taken for the said illegal acts of obstructing access to justice. The matter may also
be considered by this Court on receipt of a report from the High Courts in this regard. This does not
debar report/petition from any other source even before the end of a quarter, if situation so
warrants.” 6.6 In spite of the law laid down by this Court in the aforesaid decisions, this Court time
and again deprecated the lawyers to go on strikes, the strikes were continued unabated. Even in the
present case, the advocates have been boycotting the courts on all Saturdays, in the entire district of
Dehradun, in several parts of the district of Haridwar and Udham Singh Nagar district of the State
of Uttaranchal.
Because of such strikes, the ultimate sufferers are the litigants. From the data mentioned in the
impugned judgment and order, things are very shocking. Every month on 3-4 Saturdays, the
Advocates are on strike and abstain from working, on one pretext or the other. If the lawyers would
have worked on those days, it would have been in the larger interest and it would have achieved the
ultimate goal of speedy justice, which is now recognized as a fundamental right under Articles 14District Bar Association Dehradun vs Ishwar Shandilya on 28 February, 2020

and 21 of the Constitution. It would have helped in early disposal of the criminal trials and therefore
it would have been in the interest of those who are languishing in the jail and waiting for their trial
to conclude. When the Institution is facing a serious problem of arrears and delay in disposal of
cases, how the Institution as a whole can afford such four days strike in a month.
6.7 Now, so far as the submission on behalf of the petitioner that to go on strike/boycott courts is a
fundamental right of Freedom of Speech and Expression under Article 19(1)(a) of the Constitution
and it is a mode of peaceful representation to express the grievances by the lawyers’ community is
concerned, such a right to freedom of speech cannot be exercised at the cost of the litigants and/or
at the cost of the Justice Delivery System as a whole. To go on strike/boycott courts cannot be
justified under the guise of the right to freedom of speech and expression under Article 19(1)(a) of
the Constitution. Nobody has the right to go on strike/boycott courts. Even, such a right, if any,
cannot affect the rights of others and more particularly, the right of Speedy Justice guaranteed
under Articles 14 and 21 of the Constitution. In any case, all the aforesaid submissions are already
considered by this Court earlier and more particularly in the decisions referred to hereinabove.
Therefore, boycotting courts on every Saturday in the entire District of Dehradun, in several districts
of Haridwar and Udham Singh Nagar district in the State of Uttarakhand is not justifiable at all and
as such it tantamounts to contempt of the courts, as observed by this Court in the aforesaid
decisions. Therefore, the High Court is absolutely justified in issuing the impugned directions. We
are in complete agreement with the view expressed by the High Court and the ultimate conclusion
and the directions issued by the High Court. Therefore, the present Special Leave Petition deserves
to be dismissed and is accordingly dismissed. We further direct all concerned and the concerned
District Bar Associations to comply with the directions issued by the High Court impugned in the
present SLP in its true spirit. It is directed that if it is found that there is any breach of any of the
directions issued by the High Court in the impugned judgment and order, a serious view shall be
taken and the consequences shall follow, including the punishment under the Contempt of Courts
Act.
7. As observed hereinabove, in spite of the decisions of this Court in the cases of Ex-Capt Harish
Uppal (supra), Common Cause, A Registered Society (supra) and Krishnakant Namrakar (supra)
and despite the warnings by the courts time and again, still, in some of the courts, the lawyers go on
strikes/are on strikes. It appears that despite the strong words used by this Court in the aforesaid
decisions, criticizing the conduct on the part of the lawyers to go on strikes, it appears that the
message has not reached. Even despite the resolution of the Bar Council of India dated 29.09.2002,
thereafter, no further concrete steps are taken even by the Bar Council of India and/or other Bar
Councils of the States. A day has now come for the Bar Council of India and the Bar Councils of the
States to step in and to take concrete steps. It is the duty of the Bar Councils to ensure that there is
no unprofessional and unbecoming conduct by any lawyer. As observed by this Court in the case of
Ex-Capt. Harish Uppal (supra), the Bar Council of India is enjoined with a duty of laying down the
standards of professional conduct and etiquette for Advocates. It is further observed that this would
mean that the Bar Council of India ensures that advocates do not behave in an unprofessional and
unbecoming manner. Section 48 of the Advocates Act gives a right to the Bar Council of India to give
directions to the State Bar Councils. It is further observed that the Bar Associations may be separate
bodies but all advocates who are members of such associations are under disciplinary jurisdiction ofDistrict Bar Association Dehradun vs Ishwar Shandilya on 28 February, 2020

the Bar Councils and thus the Bar Councils can always control their conduct. Therefore, taking a
serious note of the fact that despite the aforesaid decisions of this Court, still the lawyers/Bar
Associations go on strikes, we take suo moto cognizance and issue notices to the Bar Council of
India and all the State Bar Councils to suggest the further course of action and to give concrete
suggestions to deal with the problem of strikes/abstaining the work by the lawyers. The Notices may
be made returnable within six weeks from today. The Registry is directed to issue the notices to the
Bar Council of India and all the State Bar Councils accordingly.
…………………………..J. (ARUN MISHRA) …………………………..J. (M. R. SHAH) New Delhi, February
28, 2020District Bar Association Dehradun vs Ishwar Shandilya on 28 February, 2020

