Antony Babu vs State Of Tamil Nadu on 16 August, 2019
Author: M.Sathyanarayanan
Bench: M.Sathyanarayanan, B.Pugalendhi
                                                                           H.C.P(MD)No.132 of 2019
                          BEFORE THE MADURAI BENCH OF MADRAS HIGH COURT
                                            DATED : 16.08.2019
                                                  CORAM:
                          THE HONOURABLE MR.JUSTICE M.SATHYANARAYANAN
                                              and
                             THE HONOURABLE MR.JUSTICE B.PUGALENDHI
                                        H.C.P(MD)No.132 of 2019
                Antony Babu                                         ... Petitioner
                                                     Vs.
                1.State of Tamil Nadu,
                  Represented by the Principal Secretary to Government,
                  Home, Prohibition and Excise Department,
                  Fort St.George,
                  Chennai – 600 009.
                2.The District Collector and District Magistrate,
                  Tirunelveli District,
                  Tirunelvlei.
                3.The Superintendent of Prison,
                  Central Prison,
                  Palayamkottai,
                  Tirunelveli.                                      ... Respondents
                Prayer: Habeas Corpus Petition filed under Article 226 of the Constitution
                of India praying for the issuance of a Writ of Habeas Corpus to call for the
                entire records connected with the detention order passed in M.H.S.Confdl
                No.14/2019 dated 21.01.2019 on the file of the second respondent herein
                and quash the same and direct the respondents to produce the detenu or
                body of the detenu namely Antony Babu aged about 29 years, S/o.Francis,
                now detained at Central prison, Palayamkottai, before this Court and set
                him at liberty forthwith.
http://www.judis.nic.inAntony Babu vs State Of Tamil Nadu on 16 August, 2019

                1/10
                                                                     H.C.P(MD)No.132 of 2019
                          For Petitioner    : N.Pragalathan
                          For Respondents   : Mr.K.Dinesh Babu,
                                                       Additional Public Prosecutor
                                                  *****
                                                ORDER
(Order of the Court was made by B.PUGALENDHI, J.) The detenu himself is the petitioner herein
and challenging the impugned order of detention dated 21.01.2019 passed by the second
respondent, branding him as a Goodna under the provisions of Section 3[1] of the Tamil Nadu
Prevention of Dangerous Activities of Boot leggers, Cyber Law Offenders, Drug Offenders, Forest
Offenders, Goondas, Immoral Traffic Offenders, Sand Offenders, Sexual Offenders, Slum Grabbers
and Video Pirates Act, 1982 (Tamil Nadu Act 14/1982), he has filed the present habeas corpus
petition.
2.A perusal of the grounds of detention dated 21.01.2019, passed by the second respondent herein,
would disclose that the detenu, viz., Antony Babu came to the adverse notice to the Suthamalai
Police Station in Crime No.348 of 2018, which has been registered for the offence under Sections
341, 294 (b), 307 and 506 (ii) IPC. http://www.judis.nic.in
3. The grounds on which the detenu was detained are that on 05.01.2019 at about 8.00 hours at
Suthamalai Bazar, while the complainant Vasantha was going by walk, the detenu waylaid her,
scolded her in filthy language and also humiliated her. The complainant out of fear shouted and on
hearing the noise, the public who were standing near by rushed to the spot. The detenu threatened
the public by brandishing a knife over his head and on seeing this act, the public got panic and the
shop owners closed the shop and due to this incident, the normal traffic and routine life of the
common public came to a standstill. On the complaint of Vasantha, a case in Crime No.8 of 2019
was registered against the detnu on the file of the Suthamalai Police Station, for the offence
punishable under Sections 341, 294(b), 506(ii) IPC and under Section 4 of Tamil Nadu Prohibition
of Harassment of Women, 2002 was also registered. Being satisfied that the acts of the detenu are
prejudicial to the maintenance of piece and public order, the second respondent has branded the
petitioner as Goonda as contemplated under Section 2(f) of the Tamil Nadu Act 14 of 1982 and
passed the detention order. Challenging, the order of detention, this Habeas Corpus Petition has
been filed by the detenu.
4.The learned Counsel appearing for the petitioner would submit that a bail application filed by the
detenu in the ground case was pending http://www.judis.nic.in and there was no real and imminent
possibility of the detenu coming out on bail and the detaining authority arrived at the subjective
satisfaction, relying upon the bail granted to some other person that in similar cases in due course
bail would be granted. On the documents relied upon by the detaining authority, the similar case is
nowhere similar to the detenu's case and further, the documents of the similar case were also not
provided to the detenu. He also submitted that his representation was not considered by theAntony Babu vs State Of Tamil Nadu on 16 August, 2019

authorities and therefore, prays for quashment of the order of detention passed by the second
respondent.
5.Per Contra Mr.K.Dinesh Babu, learned Additional Government Pleader appearing for the State
would submit that a bail application was moved before the Judicial Magistrate, Cheranmahadevi
was dismissed and the detenu has filed another bail application before the Sessions Court,
Tirunelveli in CrMP No.505 of 2019 and the same was pending. However, in similar such offence,
the bail was granted and considering the same, the detaining authority has rightly invoked the order
of detention. He would further submit that the representation sent by the petitioner dated
28.01.2019 was also duly forwarded to the Government on 12.02.2019 and on the same day, the said
representation was rejected. As such there is no illegality in the order of detention, warranting
intervention of this Court and hence, prays for dismissal of this petition. http://www.judis.nic.in
6.This Court has considered the rival submissions and also perused the entire materials placed
before it.
7.The detenu made a representation on 28.01.2019 and the same was received by the detaining
authority from the Central Prison, Palayamkottai on 29.01.2019 and the representation was sent to
the Government along with remarks on 12.02.2019 and the decision was taken by the Government
on the same day, i.e., on 12.02.2019.
8.The detaining authority in his grounds of detention has informed the detenu that he has right to
make representation against the order of detention to the detaining authority as well as to the
Government and the Advisory Board. It is also informed that if any such representation is received
by the detaining authority before approval of the detention order, by the Government, such
representation will be duly considered by the detaining authority.
9.As per the counter affidavit filed by the detaining authority as well as the performa filed by the
Under Secretary to Government, the representation was made on 28.01.2019 through Central Prison
and the same was received by the detaining authority on 29.01.2019, within 12 days from the date of
detention i.e., on 21.01.2019. http://www.judis.nic.in
10.The detaining authority has not considered the representation, though he received the said
representation prior to the approval accorded by the Government under Section 3(3) of the Act. The
detaining authority without considering the representation, forwarded the representation to the
Government along with remarks on 12.02.2019 and the same was disposed of by the Government on
12.02.2019. Even excluding the Government Holidays, still there is a delay of 9 days in considering
the said representation.
11.Though the learned Additional Public Prosecutor insists that there is no delay on the part of the
Government, since the Government received the representation on 12.02.2019, disposed of the
representation on the very same day, there is no detail available either in the counter affidavit or in
the proforma for the delay of 9 days in forwarding the said representation to the Government.
Article 22(5) of the Constitution of India, casts legal obligation on the Government to consider theAntony Babu vs State Of Tamil Nadu on 16 August, 2019

detenu's representation as early as possible. There should be no slackness, indifference and callous
attitude in consideration of the representations of the persons who are detained. Any unexplained
delay would be breach of constitutional imperative and it would render the continued detention of
the detenu as illegal. Every day delay in dealing with the representation http://www.judis.nic.in has
to be explained and the explanation offered must be reasonably indicating that there was no
slackness or indifference.
12. In Rekha vs. State of Tamil Nadu, reported in 2011 (5) SCC 244, the Honourable Supreme Court
has held that the procedural safeguards are required to be zealously watched and enforced by the
Courts of law and their rigour cannot be allowed to be diluted on the basis of the nature of the
alleged activities undertaken by the detenu.
13. In Sumaiya vs. The Secretary to Government, reported in 2007 (2) MWN (Cr.) 145, a Division
Bench of this Court has held that the unexplained delay of three days in disposal of the
representation made on behalf of the detenu would be sufficient to set aside the order of detention.
14. In Tara Chand vs. State of Rajasthan and others, reported in 1980 (2) SCC 321, the Honourable
Supreme Court has held that any inordinate and unexplained delay on the part of the Government
in considering the representation renders the very detention illegal. http://www.judis.nic.in
15.In this case, though the representation was made on 28.01.2019, there is a slackness in
forwarding the representation to the Government and there are no particulars available for the
delay. Moreover, though the detaining authority received the representation, prior to the order of
approval, he did not consider the representation and forwarded the representation only on
12.02.2019, after 9 days and therefore, the detention order is liable to be set aside.
16.In the result, the Habeas Corpus Petition is allowed by setting aside the Order of Detention
passed by the second respondent herein, namely, The District Collector and District Magistrate,
Tirunelveli District and Tirunelveli M.H.S.Confdl No.14 of 2019, dated 21.01.2019. the detenu,
namely, Antony Babu, aged about 29 years, who is now detained at Central Prison, Palayamkottai is
directed to be released forthwith unless his presence [or] custody [or] detention is required in
connection with any other case/proceedings.
                                                             [M.S.N., J.]    [B.P., J.]
                                                                     16.08.2019
                Index    : Yes / No
                Internet : Yes / No
                dsk
http://www.judis.nic.in
                ToAntony Babu vs State Of Tamil Nadu on 16 August, 2019

                  1.The Principal Secretary to Government,
                   Home, Prohibition and Excise Department,
                   Fort St.George,
                   Chennai – 600 009.
2.The District Collector and District Magistrate, Tirunelveli District, Tirunelvlei.
3.The Superintendent of Prison, Central Prison, Palayamkottai, Tirunelveli.
4.The Additional Public Prosecutor, Madurai Bench of Madras High Court, Madurai.
http://www.judis.nic.in M.SATHYANARAYANAN, J.
and B.PUGALENDHI, J.
dsk 16.08.2019 http://www.judis.nic.inAntony Babu vs State Of Tamil Nadu on 16 August, 2019

