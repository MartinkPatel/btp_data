Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister
Of State Of ... on 27 June, 2019
Author: Ranjit More
Bench: Ranjit More, Bharati H. Dangre
                               1                        Marata(J) final.doc
       IN THE HIGH COURT OF JUDICATURE AT BOMBAY
              CIVIL APPELLATE JURISDICTION
      PUBLIC INTEREST LITIGATION NO. 175 OF 2018
Dr. Jishri Laxmnarao Patil,                       ]
Member the Indian Constitutionalist               ]
Council, Age 39 years, Occu : Advocate,           ]
Having office at C/o 109/18,                      ]
Esplanade Mansion, M. G. Road,                    ]
Mumbai 400023. ...Petitioner                      ]..Petitioner.
         Versus
1.       The Chief Minister                   ]
         of State of Maharashtra, Mantralaya, ]
         Mumbai - 400 032.                    ]
                                              ]
2.       the Chief Secretary,                 ]
         State of Maharashtra, Mantralaya,    ]
         Mumbai - 400 032.                    ]..Respondents.
                                   WITH
           CIVIL APPLICATION NO. 6 OF 2019
                           IN
      PUBLIC INTEREST LITIGATION NO. 175 OF 2018
Gawande Sachin Sominath.                   ]
Age 32 years, Occ : Social Activist,       ]
R/o Plot No. 64, Lane No. 7, Gajanan Nagar ]
Garkheda Parisar, Aurangabad.              ]..Applicant.
         IN THE MATTER BETWEEN
Dr. Jishri Laxmnarao Patil,                       ]
Member the Indian Constitutionalist               ]
Council, Age 39 years, Occu : Advocate,           ]
Having office at C/o 109/18,                      ]
Esplanade Mansion, M. G. Road,                    ]Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Mumbai 400023.                                    ]..Petitioner.
patil-sachin.
::: Uploaded on - 27/06/2019              ::: Downloaded on - 28/06/2019 05:25:16 :::
                                2                       Marata(J) final.doc
                 Versus
1.       The Chief Minister                    ]
         of State of Maharashtra, Mantralaya, ]
         Mumbai - 400 032.                     ]
                                               ]
2.       The Chief Secretary,                  ]
         State of Maharashtra, Mantralaya,     ]
         Mumbai - 400 032.                     ]
                                               ]
3.       Anandrao S. Kate,                     ]
         Address at Shoop no. 12               ]
         Building no. 26, A,                   ]
         Lullbhai Compound,                    ]
         mumbai-400043                         ]
                                               ]
4.       Akhil Bhartiya Maratha                ]
         Mahasangh,                            ]
         Reg. No. 669/A,                       ]
         Though. Dilip B Jagatap               ]
         ts Office at.5, Navalkar              ]
         Lane Prarthana Samaj                  ]
         Girgaon, Mumbai-04                    ]
                                               ]
5.       Vilas A. Sudrik,                      ]
         265, "Shri Ganesh Chalwal,            ]
         Juie Aunty Compound                   ]
         Santosh Nagar, Gaorgaon (E)           ]
         Mumbai-64                             ]
                                               ]
6.       Ashok Patil                           ]
         A/G/001, Mehdoot Co-op Society,       ]
         Mahada Vasahat Thane, 4000606         ]
                                               ]
7.       Dr. Kanchan Patil-Vadgaon             ]
         B-502, Silverstar Residency Sector-18 ]
         Kamote, Panvel-410206                 ]
                                               ]
8.       Subhash Balu Salekar,                 ]Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

         At 32/2, Shri. Ganesh Soc,            ]
         Hanuman Nagar, B. Park                ]
         Site Vikroli (W) Mumbai-799           ]
patil-sachin.
::: Uploaded on - 27/06/2019             ::: Downloaded on - 28/06/2019 05:25:16 :::
                                3                       Marata(J) final.doc
9.       Pandurang D. Shelakar          ]
         53 Dhulgaon, at Post Dhulgaon  ]
         Tal. Yeola Dist. Nashik 401    ]
                                        ]
10. Nitesh Narayan Rane,                ]
    Bungalow Pion Estate Juhu           ]
    Tara Road, Santacruz, (W)           ]
    Mumbai- 54                          ]
                                        ]
11. Lakshaman M. Misal,                 ]
    Yashwant Complex A. Wing            ]
    Room No. 508 Near shankwshwar       ]
    Vidyalaya Road, Dombivali Thane, 43.]
                                        ]
12. Pravin A Nikam                      ]
    Plot No. 28 Sulbha Nagar,           ]
    Yeola , Tal Yeola Dist Nashik       ]
                                        ]
13. Vipul C. Mane                       ]
    61,/402, MHB Colony                 ]
    Dindsohhi Magar, Malad              ]
    Mumbai-97                           ]
                                        ]
14. Vinod L. Pokharkar                  ]
    3, plot no. 21 Skylark Society      ]
    Sector 15, Koparkhairne,            ]
    Navi Mumbai-43,                     ]
                                        ]
15. Dilip M. Patil                      ]
    244/9, Laxmi Narayan Nagar          ]
    Murkh Saink Vasahat                 ]
    Kolhapur, 416006                    ]
                                        ]
16. Sandip P. Pol,                      ]
    Krashnai 2/7, Market Yard           ]
    Satara 15001                        ]
                                        ]
17. Vivek R. Kurade,                    ]Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

    Ashtavinayak colony                 ]
    Vidyanagar Karad, Dist Satara,      ]
                                        ]
patil-sachin.
::: Uploaded on - 27/06/2019             ::: Downloaded on - 28/06/2019 05:25:16 :::
                                4                        Marata(J) final.doc
18. Vinod S. Sable                        ]
    602 A, Wing, Nikanth Nityanand Road,]
    Panvel Navi Mumbai 410106             ]
                                          ]
19. Krishna B. Naik                       ]
    601, D. Annanya Dr, Raikar Marg,      ]
    Mahim, Mumbai- 16                     ]
                                          ]
20. Ankush S. Kadam                       ]
    SS-3, Room No. 724 Sec-18             ]
    Kopar Khairane, Navi Mumbai           ]
                                          ]
21. Santosh P. Raijadhav,                 ]
    15, Satyam Shivam CHS OPP.            ]
    HP Petrol Pump Badlapur East Thane ]
                                          ]
22. Shahed Ali Ansari                     ]
    B-96, 9th Floor, Mithal Tower B Wing, ]
    Nariman Point, Mumbai-40023           ]
                                          ]
23. Akhil Maratha Federation              ]
    Reg No. MH/MUM//2379-2015             ]
    GBBD Thr. Shri. Shashikant Pawar,     ]
    Navalkar Lane, Prathana Samaj,        ]
    Girgaon Mumbai -04,                   ]
                                          ]
24. Maharashtra Public Service            ]
    Commission (MPSC)                     ]
    Main office 5 7 8 Floor,
                  th th  th
                                          ]
    Cooprej Telephone Exchange building,]
    MahatrshiKarve Marg,                  ]
    Mumbai-400023                         ]
                                          ]
25. Gawande Sachin Sominath,              ]
    Age: 32 years, Occu: Social Activist ]Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

    R/o: Plot No.64, Lane No.7,           ]
    Gajanan Nagar,                        ]
    Garkheda Parisar Aurangabad           ]...RESPONDENTS
                                   WITH
patil-sachin.
::: Uploaded on - 27/06/2019              ::: Downloaded on - 28/06/2019 05:25:16 :::
                                5                       Marata(J) final.doc
           CIVIL APPLICATION NO. 7 OF 2019
                           IN
      PUBLIC INTEREST LITIGATION NO. 175 OF 2018
Ravindra s/o Bhanudas Kale.                      ]
Age 39 years, Occu : Social activist             ]
R/o : Plot No. 64, Lane no. 7, Gajanan           ]
Nagar, GarkhedaParisar, Aurangabad.              ]..Applicant.
         IN THE MATTER BETWEEN
Dr. Jishri Laxmnarao Patil,                      ]
Member the Indian Constitutionalist              ]
Council, Age 39 years, Occu : Advocate,          ]
Having office at C/o 109/18,                     ]
Esplanade Mansion, M. G. Road,                   ]
Mumbai 400023.                                   ]..Petitioner.
         Versus
1.       The Chief Minister                   ]
         of State of Maharashtra, Mantralaya, ]
         Mumbai - 400 032.                    ]
                                              ]
2.       The Chief Secretary,                 ]
         State of Maharashtra, Mantralaya,    ]
         Mumbai - 400 032.                    ]
                                              ]
3.       Anandrao S. Kate,                    ]
         Address at Shoop no. 12              ]
         Building no. 26, A,                  ]
         Lullbhai Compound, Munkurd,          ]
         mumbai-400043                        ]
                                              ]Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

4.       Akhil Bhartiya Maratha               ]
         Mahasangh,                           ]
         Reg. No. 669/A,                      ]
         Though. Dilip B Jagatap              ]
         Its Office at.5, Navalkar            ]
         Lane Prarthana Samaj                 ]
         Girgaon, Mumbai-04                   ]
                                              ]
patil-sachin.
::: Uploaded on - 27/06/2019             ::: Downloaded on - 28/06/2019 05:25:16 :::
                                6                       Marata(J) final.doc
5.       Vilas A. Sudrik,                      ]
         265, "Shri Ganesh Chawal,             ]
         Juie Aunty Compound                   ]
         Santosh Nagar, Gaorgaon (E)           ]
         Mumbai-64                             ]
                                               ]
6.       Ashok Patil                           ]
         A/G/001, Mehdoot Co-op Society,       ]
         Mahada Vasahat Thane, 4000606         ]
                                               ]
7.       Dr. Kanchan Patil-Vadgaon             ]
         B-502, Silverstar Residency Sector-18 ]
         Kamote, Panvel-410206                 ]
                                               ]
8.       Subhash Balu Salekar,                 ]
         At 32/2, Shri. Ganesh Soc,            ]
         Hanuman Nagar, B. Park                ]
         Site Vikroli (W) Mumbai-799           ]
9.       Pandurang D. Shelakar               ]
         53 Dhulgaon, at Post Dhulgaon       ]
         Tal. Yeola Dist. Nashik 401         ]
                                             ]
10.      Nitesh Narayan Rane,                ]
         Bungalow Pion Estate Juhu           ]
         Tara Road, Santacruz, (W)           ]
         Mumbai- 54                          ]
                                             ]
11.      Lakshaman M. Misal,                 ]
         Yashwant Complex A. Wing            ]
         Room No. 508 Near shankwshwar       ]
         Vidyalaya Road, Dombivali Thane, 43.]
                                             ]
12.      Pravin A Nikam                      ]
         Plot No. 28 Sulbha Nagar,           ]Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

         Yeola , Tal Yeola Dist Nashik       ]
                                             ]
13.      Vipul C. Mane                       ]
         61,/402, MHB Colony                 ]
         Dindsohhi Magar, Malad              ]
         Mumbai-97                           ]
                                             ]
patil-sachin.
::: Uploaded on - 27/06/2019             ::: Downloaded on - 28/06/2019 05:25:16 :::
                                7                      Marata(J) final.doc
14. Vinod L. Pokharkar                       ]
    3, plot no. 21 Skylark Society           ]
    Sector 15, Koparkhairne,                 ]
    Navi Mumbai-43,                          ]
                                             ]
15.      Dilip M. Patil                      ]
         244/9, Laxmi Narayan Nagar          ]
         Murkh Saink Vasahat                 ]
         Kolhapur, 416006                    ]
                                             ]
16.      Sandip P. Pol,                      ]
         Krashnai 2/7, Market Yard           ]
         Satara 15001                        ]
                                             ]
17.      Vivek R. Kurade,                    ]
         Ashtavinayak colony                 ]
         Vidyanagar Karad, Dist Satara,      ]
                                             ]
18.      Vinod S. Sable                      ]
         602 A, Wing, Nikanth Nityanand Road,]
         Panvel Navi Mumbai 410106           ]
                                             ]
19.      Krishna B. Naik                     ]
         601, D. Annanya Dr, Raikar Marg,    ]
         Mahim, Mumbai- 16                   ]
                                             ]
20.      Ankush S. Kadam                     ]
         SS-3, Room No. 724 Sec-18           ]
         Kopar Khairane, Navi Mumbai         ]
                                             ]
21.      Santosh P. Raijadhav,               ]
         15, Satyam Shivam CHS OPP.          ]
         HP Petrol Pump Badlapur East Thane ]
                                             ]
22.      Shahed Ali Ansari                   ]Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

         B-96, 9 Floor, Mithal Tower B Wing, ]
                th
         Nariman Point, Mumbai-40023         ]
                                             ]
23.      Akhil Maratha Federation            ]
         Reg No. MH/MUM//2379-2015           ]
         GBBD Thr. Shri. Shashikant Pawar,   ]
         Navalkar Lane, Prathana Samaj,      ]
         Girgaon Mumbai -04,                 ]
patil-sachin.
::: Uploaded on - 27/06/2019            ::: Downloaded on - 28/06/2019 05:25:16 :::
                                8                       Marata(J) final.doc
                                           ]
24. Maharashtra Public Service             ]
    Commission (MPSC)                      ]
    Main office 5th 7th 8th Floor,         ]
    Cooperage Telephone Exchange           ]
    building,                              ]
    MahatrshiKarve Marg,                   ]
    Mumbai-400023                          ]
                                           ]
25. Ravindra s/o Bhanudas Kale.            ]
    Age 39 years, Occu : Social activist ]
    R/o : Plot No. 64, Lane no. 7, Gajanan ]
    Nagar, GarkhedaParisar, Aurangabad. ]..RESPONDENTS
                         WITH
           CIVIL APPLICATION NO. 8 OF 2019
                           IN
      PUBLIC INTEREST LITIGATION NO. 175 OF 2018
Ramesh Shekhnath Kere.                           ]
Age 40 years, Occu : Social activist             ]
R/o : New Hanuman Nagar, Galli No.4,             ]
Plot No. 94,GarkhedaParisar, Aurangabad.         ]..Applicant.
         IN THE MATTER BETWEEN
Dr. Jishri Laxmnarao Patil,                      ]
Member the Indian Constitutionalist              ]
Council, Age 39 years, Occu : Advocate,          ]
Having office at C/o 109/18,                     ]
Esplanade Mansion, M. G. Road,                   ]
Mumbai 400023.                                   ]..Petitioner.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

         Versus
1.       The Chief Minister                   ]
         of State of Maharashtra, Mantralaya, ]
         Mumbai - 400 032.                    ]
                                              ]
2.       The Chief Secretary,                 ]
         State of Maharashtra, Mantralaya,    ]
         Mumbai - 400 032.                    ]
patil-sachin.
::: Uploaded on - 27/06/2019             ::: Downloaded on - 28/06/2019 05:25:16 :::
                                9                       Marata(J) final.doc
                                                 ]
3.       Anandrao S. Kate,                       ]
         Address at Shoop no. 12                 ]
         Building no. 26, A,                     ]
         Lullbhai Compound, Munkurd,             ]
         mumbai-400043                           ]
                                                 ]
4.       Akhil Bhartiya Maratha                  ]
         Mahasangh,                              ]
         Reg. No. 669/A,                         ]
         Though. Dilip B Jagatap                 ]
         Its Office at.5, Navalkar               ]
         Lane Prarthana Samaj                    ]
         Girgaon, Mumbai-04                      ]
                                                 ]
5.       Vilas A. Sudrik,                        ]
         265, "Shri Ganesh Chawal,       ]
         Juie Aunty Compound                   ]
         Santosh Nagar, Gaorgaon (E)           ]
         Mumbai-64                             ]
                                               ]
6.       Ashok Patil                           ]
         A/G/001, Mehdoot Co-op Society,       ]
         Mahada Vasahat Thane, 4000606         ]
                                               ]
7.       Dr. Kanchan Patil-Vadgaon             ]
         B-502, Silverstar Residency Sector-18 ]
         Kamote, Panvel-410206                 ]
                                               ]
8.       Subhash Balu Salekar,                 ]
         At 32/2, Shri. Ganesh Soc,            ]
         Hanuman Nagar, B. Park                ]
         Site Vikroli (W) Mumbai-799           ]Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

9.       Pandurang D. Shelakar                   ]
         53 Dhulgaon, at Post Dhulgaon           ]
         Tal. Yeola Dist. Nashik 401             ]
                                                 ]
10. Nitesh Narayan Rane,                         ]
    Bungalow Pion Estate Juhu                    ]
    Tara Road, Santacruz, (W)                    ]
    Mumbai- 54                                   ]
                                                 ]
patil-sachin.
::: Uploaded on - 27/06/2019             ::: Downloaded on - 28/06/2019 05:25:16 :::
                                10                   Marata(J) final.doc
11. Lakshaman M. Misal,                 ]
    Yashwant Complex A. Wing            ]
    Room No. 508 Near shankwshwar       ]
    Vidyalaya Road, Dombivali Thane, 43.]
                                        ]
12. Pravin A Nikam                      ]
    Plot No. 28 Sulbha Nagar,           ]
    Yeola , Tal Yeola Dist Nashik       ]
                                        ]
13. Vipul C. Mane                       ]
    61,/402, MHB Colony                 ]
    Dindsohhi Magar, Malad              ]
    Mumbai-97                           ]
                                        ]
14. Vinod L. Pokharkar                  ]
    3, plot no. 21 Skylark Society      ]
    Sector 15, Koparkhairne,            ]
    Navi Mumbai-43,                     ]
                                        ]
15. Dilip M. Patil                      ]
    244/9, Laxmi Narayan Nagar          ]
    Murkh Saink Vasahat                 ]
    Kolhapur, 416006                    ]
                                        ]
16. Sandip P. Pol,                      ]
    Krashnai 2/7, Market Yard           ]
    Satara 15001                        ]
                                        ]
17. Vivek R. Kurade,                    ]
    Ashtavinayak colony                 ]
    Vidyanagar Karad, Dist Satara,      ]
                                        ]
18. Vinod S. Sable                      ]Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

    602 A, Wing, Nikanth Nityanand Road,]
    Panvel Navi Mumbai 410106           ]
                                        ]
19. Krishna B. Naik                     ]
    601, D. Annanya Dr, Raikar Marg,    ]
    Mahim, Mumbai- 16                   ]
                                        ]
20. Ankush S. Kadam                     ]
    SS-3, Room No. 724 Sec-18           ]
    Kopar Khairane, Navi Mumbai         ]
patil-sachin.
::: Uploaded on - 27/06/2019        ::: Downloaded on - 28/06/2019 05:25:16 :::
                                11                          Marata(J) final.doc
21. Santosh P. Raijadhav,                ]
    15, Satyam Shivam CHS OPP.           ]
    HP Petrol Pump Badlapur East Thane ]
                                         ]
22. Shahed Ali Ansari                    ]
    B-96, 9 Floor, Mithal Tower B Wing, ]
            th
    Nariman Point, Mumbai-40023          ]
                                         ]
23. Akhil Maratha Federation             ]
    Reg No. MH/MUM//2379-2015            ]
    GBBD Thr. Shri. Shashikant Pawar,    ]
    Navalkar Lane, Prathana Samaj,       ]
    Girgaon Mumbai -04,                  ]
                                         ]
24. Maharashtra Public Service           ]
    Commission (MPSC)                    ]
    Main office 5 7 8 Floor,
                  th th  th
                                         ]
    Cooprej Telephone Exchange building,]
    MahatrshiKarve Marg,                 ]
    Mumbai-400023                        ]
                                         ]
25. Ramesh Shekhnath Kere.               ]
    Age 40 years, Occu : Social activist ]    ]
    R/o : New Hanuman Nagar,             ]
    Galli No.4, Plot No. 94,             ]
    GarkhedaParisar, Aurangabad.         ]..RESPONDENTS.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                                    WITH
           CIVIL APPLICATION NO. 17 OF 2019
                           IN
      PUBLIC INTEREST LITIGATION NO. 175 OF 2018
Shri Haribhai Rathod,                      ]
Age 65 years, Occu :                       ]
R/at A-201, Banjara Hills, near Ashok Nagar]
Police Station, Mulund (W),                ]..Intervener.
patil-sachin.
::: Uploaded on - 27/06/2019               ::: Downloaded on - 28/06/2019 05:25:16 :::
                                12                          Marata(J) final.doc
                 IN THE MATTER BETWEEN
Dr. Jaishri Laxmnarao Patil,                       ]
Member the Indian Constitutionalist                ]
Council, Age 39 years, Occu : Advocate,            ]
Having office at C/o 109/18,                       ]
Esplanade Mansion, M. G. Road,                     ]
Mumbai 400023.                                     ]..Petitioner.
         Versus
1.       The Chief Minister                   ]
         of State of Maharashtra, Mantralaya, ]
         Mumbai - 400 032.                    ]
                                              ]
2.       The Chief Secretary,                 ]
         State of Maharashtra, Mantralaya,    ]
         Mumbai - 400 032.                    ]..Respondents.
                                    WITH
                   WIRT PETITION NO. 937       OF 2017
Sayed Saleem Syed Ali.                             ]
Age : 55 years, Occu : Ex-MLA (Beed)               ]
R/o Bundalpura, Beed, Tq.&Dist Beed.]              ]..Petitioner.
         VersusDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

1.       The State of Maharashtra                  ]
         Through the Secretary,                    ]
         General Administration Department,        ]
         Mantralaya, Mumbai- 400032.               ]
         (Copy to be served on G.P.,               ]
         High Court of Judicature of Bombay)       ]
                                                   ]
2.       Minority Development                      ]
         Department,                               ]
         Through its Secretory,                    ]
         Government of Maharashtra,                ]
         Mantralaya, Mumbai - 400032.              ]
patil-sachin.
::: Uploaded on - 27/06/2019               ::: Downloaded on - 28/06/2019 05:25:16 :::
                                13                          Marata(J) final.doc
3.       Social Justice and Special                ]
         Assistance Department,                    ]
         Through its Secretary,                    ]
         Government of Maharashtra,                ]
         Mantralaya Mumbai - 400032.               ]..Respondents.
                               WITH
                 CIVIL APPLICATION NO. 11 OF 2019
                                IN
                  WRIT PETITION NO. 937 OF 2017
Sayed Saleem Syed Ali.                             ]
Age : 55 years, Occu : Ex-MLA (Beed)               ]
R/o Bundalpura, Beed, Tq.&Dist Beed.]              ]..Applicant.
     In the matter between :-
Sayed Saleem Syed Ali.                             ]
Age : 55 years, Occu : Ex-MLA (Beed)               ]
R/o Bundalpura, Beed, Tq.&Dist Beed.]              ]..Petitioner.
         Versus
1.       The State of Maharashtra                  ]
         Through the Secretary,                    ]
         General Administration Department,        ]
         Mantralaya, Mumbai- 400032.               ]
         (Copy to be served on G.P.,               ]Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

         High Court of Judicature of Bombay)       ]
                                                   ]
2.       Minority Development                      ]
         Department,                               ]
         Through its Secretory,                    ]
         Government of Maharashtra,                ]
         Mantralaya, Mumbai - 400032.              ]
                                                   ]
3.       Social Justice and Special                ]
         Assistance Department,                    ]
         Through its Secretary,                    ]
         Government of Maharashtra,                ]
         Mantralaya, Extension Building,           ]
         Mumbai - 400032.                          ]..Respondents.
patil-sachin.
::: Uploaded on - 27/06/2019               ::: Downloaded on - 28/06/2019 05:25:16 :::
                                14                          Marata(J) final.doc
                                    WITH
                    WRIT PETITION NO.1208 OF 2019
Syed Saleem Syed Ali                               ]
R/o. Bundalpura, Beed,                             ]
Taluka & Dist-Beed                                 ]...Petitioner
         Versus
1.       The State of Maharashtra                  ]
         through the Secretary,                    ]
         General Administration Department,        ]
         Mantralaya, Mumbai-400 032.               ]
                                                   ]
2.       Minority Development                      ]
         Department                                ]
         through its Secretary,                    ]
         Government of Maharashtra,                ]
         Mantralaya, Mumbai-400 032.               ]
                                                   ]
3.       Social Justice and Special                ]
         Assistance Department,                    ]
         Through its Secretary,                    ]
         Government of Maharashtra                 ]
         Mantralaya, Extension Building,           ]Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

         Mumbai- 400 032.                          ]...Respondents.
                           WITH
            WRIT PETITION NO.2126 OF 2019
Rajesh A. Takale                         ]
R/o: Panan Co-operative Housing Society, ]
Ambegaon, Pathar Bharti Vidyapeeth,      ]
Survey No.28/21/1, Pune-411 046.         ]...Petitioner
         Versus
The State of Maharashtra                           ]
Through its Chief Secretary,                       ]
Mantralaya, Mumbai - 431 032.                      ]...Respondent.
patil-sachin.
::: Uploaded on - 27/06/2019               ::: Downloaded on - 28/06/2019 05:25:16 :::
                                15                          Marata(J) final.doc
                                WITH
                    WRIT PETITION NO.2668 OF 2019
Vaibhav Dhondiram Kadam                            ]
R/at-Ganesh Plaza, Burud Lane, Yeola,              ]
Tal.Yeola, Dist-Nashik, Pin-423401                 ]...Petitioner
                 Versus
The State of Maharashtra                           ]
Through its Chief Secretary,                       ]
Mantralaya, Mumbai-431 032                         ]...Respondent
                                    WITH
                    WRIT PETITION NO.3846 OF 2019
1.       Mohammad Sayeed Noori                ]
         Shafi Ahmed R/o Mugal House,         ]
         Ali Umer Street Pydhonie, Mandvi,    ]
         B.P. Lane, Mumbai-400 003.           ]
                                              ]
2.       Mohammad Khaleel Lur                 ]
         Rehman Noori Siddique                ]
         R/at, 23, 2 Floor, 4A6 HajiDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                    nd
                                              ]
         Yusuf Manzil Abdullah Mansion,       ]
         3 Sankli Street, Madan Pura,
          rd
                                              ]
         Mumbai Central, Mumbai-400008        ]
                                              ]
3.       Sayed Jameel Jaimiyan                ]
         R/o Janimiya Husain Syed Qasre Garib]
         Nawaz House No.3-1-10510             ]
         K.G.N. Road, Dukkhi Nagar, Old Jalna ]
         Qasre Garib, Nawaz, Jalna-431203     ]
                                              ]
4.       Mohammed Farid Amir Shaikh           ]
         S/o Mohammed Amir Shaikh             ]
         O/at Qarmar Apartment,               ]
         Ground Floor, Shop No.1,             ]
         Behind Massah Bakery, Naya Nagar, ]
         Mira Road, District-Thane.           ]
patil-sachin.
::: Uploaded on - 27/06/2019               ::: Downloaded on - 28/06/2019 05:25:16 :::
                                16                          Marata(J) final.doc
5.       Zahid Hussain Mohammad         ]
         Ramzan Ansari                  ]
         R/o. 4359, Lane No.4, Near Imam]
         Ahmad Raza Chowk,              ]
         Islampura Deopur, Jaihind Colony,
                                        ]
          Dhule                         ]
                                        ]
6.       Ansari Hamid Akhtar Akhtar     ]
         Mohd.                          ]
         Sadique, R/o Plot No.42, MHADA ]
         Plot, Noor Bag. MIG, Malegaon, ]
         Nashik, Malegaon-03            ]
                                        ]
7.       Khatib Mukhimoddin Hamidoddin ]
         R/o. Roza Moholla, Kaij Beed.  ]...Petitioners
                 Versus
1.       The State of Maharashtra                ]
         Through its Chief Secretary,            ]Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

         G.A.D. Mantralaya, Mumbai.              ]
                                                 ]
2.       The Secretary,                          ]
         Minorities Development Department, ]
         Government of Maharashtra,              ]
         Mantralaya, Mumbai-400032.              ]
                                                 ]
3.       The Secretary,                          ]
         Social Justice and Special Asst. Dept., ]
         Government of Maharashtra               ]
         Mantralaya, Extension Building,         ]
         Mumbai-400 032                          ]
                                                 ]
4.       Maharashtra State Backward              ]
         Class Commission, Pune.                 ]
                                                 ]
5.       Maharashtra Public Services             ]
          Commission                             ]
         Through its Secretary,                  ]
         51/2, 7 & 8 Floor, M.K.Marg
                 th   th
                                                 ]
         Telephone Nigam Building,               ]
         Cooperage, Mumbai-400 021.              ]
patil-sachin.
::: Uploaded on - 27/06/2019               ::: Downloaded on - 28/06/2019 05:25:16 :::
                                17                           Marata(J) final.doc
6.       Union of India                   ]
         Through its Joint Secretary,     ]
         Ministry of Social Justice &     ]
         Empowerment                      ]
         (Department of Social Justice &  ]
         Empowerment), New Delhi          ]
                                          ]
7.       National Commission for Socially ]
         & Educationally Backward         ]
         Classes Through its Secretary,   ]
         New Delhi.                       ]...Respondents.
                               WITH
                  WRIT PETITION NO. 10755 OF 2017
1.       Mrunal Dhole Patil                    ]Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

         Age 33 years, Occu: Social Work,      ]
         R/o Shivneri, Mantrki Park,           ]
         Kotharud, Pune - 411038               ]
                                               ]
2.       Mahadev R Andhale.                    ]
         Age 63 years, Occu: Advocate,         ]
         Presently R/o Shivneri, Mantrki Park, ]
         Kotharud, Pune - 411038               ]..Petitioners.
                 Versus
1.       The State of Maharashtra                   ]
         Through its Principal Secretary,           ]
         Social Justice and Special                 ]
         Assistance Department,                     ]
         Mantralaya,Mumbai - 32.                    ]
                                                    ]
2.       Shri. Sambhaji Baburao Mhase-,             ]
         Patil (Former high court judge)            ]
         and Chairman of the Commission             ]
                                                    ]
3.       Dr. Sajerao Baburao Nimase,                ]
                                                    ]
4.       Prof.Shri. Chandrashekhar                  ]
         Bhagwantrao Deshpande,                     ]
patil-sachin.
::: Uploaded on - 27/06/2019                ::: Downloaded on - 28/06/2019 05:25:16 :::
                                18                          Marata(J) final.doc
                                                   ]
5.       Prof. Rajabhau Narayan Karape,            ]
                                                   ]
6.       Dr. Bhushan Vasantrao Kardile,            ]
                                                   ]
7.       Dattatray Dagadu Balsaraf,                ]
                                                   ]
8.       Dr. Suvarna Tukaram Raval,                ]
                                                   ]
9.       Dr. Pramod Govindrao Yeole,               ]
                                                   ]
10. Dr. Sudhir Devmanrao Thakare,                  ]
         ]
                                                   ]
11. Shri. Rohidas Vithal Jadhav,                   ]
    No. 2 to 11 all having their                   ]
    office address at Maharashtra                  ]
    State Commission for Backward,                 ]Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

    Class, 305, 3rd Floor,                         ]
    New Administrative Building,                   ]
    Opp, Council Hall, Pune - 411001               ]...Respondents.
                                    WITH
                   WRIT PETITION NO. 11368 OF 2016
Jamiat Ulama-I-Hind.                               ]
Through its president of Maharashtra Unit          ]
-Shri. Siddiqui Nadim Abdul Mustaqim,              ]
Age 45 years, Occu: Business and                   ]
Agriculture, R/o: 77-7, Ziandulabedin Bldg,        ]
Ibrahim Rahmatullah Rd, Bhendi Bazar,              ]
Mumbai - 3                                         ]...Petitioner
         Versus
1.       The State of Maharashtra                  ]
         Through its Chief Secretary,              ]
         General Administration Department,        ]
         Mantralaya, Mumbai.                       ]
                                                   ]
patil-sachin.
::: Uploaded on - 27/06/2019               ::: Downloaded on - 28/06/2019 05:25:16 :::
                                19                          Marata(J) final.doc
2.       The Secretary,                            ]
         Minorities Development Department,        ]
         Government of Maharashtra,                ]
         Mantralaya, Mumbai - 400032.              ]
                                                   ]
3.       the Secretary,                            ]
         Social Justice and Spl. Assistance        ]
         Department,                               ]
         Government of Maharashtra,                ]
         Mantralaya, Mumbai - 400032.              ]
                                                   ]
4.       Maharashtra State Backward                ]
         Class Commission,Pune.                    ]..Respondents.
                           WITH
         PUBLIC INTEREST LITIGATION NO. 19 OF 2019Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

KAILAS KHANDBAHALE                                 ]
Age: 30 Years; Occ.: Researcher                    ]
and social worker;                                 ]
Residing at House No. 27,                          ]
Trimbak Road Shivaji Chowk,                        ]
Mahirawani, Tal & Dist. Nashik - 412213            ]...Petitioner.
         Versus
1.       The State of Maharashtra,                 ]
         Through its Chief Secretary,              ]
         Mantralaya, Mumbai - 431032.              ]
                                                   ]
2.       The Principal Secretary, Social           ]
         Justice and Special Assistance            ]
         Dep. Government of Maharashtra            ]
         Mantralaya, Hutatma Rajguru               ]
         Chowk,Madam Cama road,                    ]
         Nariman Point, Mumbai - 32.               ]...Respondents.
                                    WITH
patil-sachin.
::: Uploaded on - 27/06/2019               ::: Downloaded on - 28/06/2019 05:25:16 :::
                                20                          Marata(J) final.doc
         PUBLIC INTEREST LITIGATION NO.105 OF 2015
Shri.Anil Shankar Thanekar                         ]
R/at 801, jai Bholenath Niwas,                     ]
Ganesh Nagar, Shivai Nagar,                        ]
Pokhran Road, Thane-400 606.                       ]...Petitioner
         Versus
1.       The Chief Minister,                       ]
         State of Maharashtra, Mantralaya,         ]
         Mumbai- 400 032.                          ]
                                                   ]
2.       The Chief Secretary                       ]
         State of Maharashtra, Mantralaya,         ]
         Mumbai - 400 032.                         ]...Respondents
                                    WITHDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

             CIVIL APPLICATION NO.130 OF 2014
                             IN
         PUBLIC INTEREST LITIGATION NO.105 OF 2015
Muslim Satyashodhak Mandal                         ]
O/At Plot No.6, Budhani Estate,                    ]
Kondwa (Budruk), Pune-411 048                      ]...Applicant/
                                                       Intervener
IN THE MATTER OF :
Shri.Anil Shankar Thanekar            ]
Room No.2, Hamam House, Fort, Mumbai. ]
                 Versus
Hon. Chief Minister, M.S. & Ors.,                  ]
Mantralaya, Mumbai.                                ]...Respondent
                                    WITH
patil-sachin.
::: Uploaded on - 27/06/2019               ::: Downloaded on - 28/06/2019 05:25:16 :::
                                21                          Marata(J) final.doc
             CIVIL APPLICATION NO.131 OF 2014
                             IN
         PUBLIC INTEREST LITIGATION NO.105 OF 2015
Akhil Bhartiya Maratha Mahasangha                  ]
Through its Secretary                              ]
Reajendra Namdeo Kondhare                          ]
Add : Prataprao Mane Sabhagraha,                   ]
5, Navalkar Lane, Prarthana Samaj,                 ]
Mumbai-400 004.                                    ]...Applicant/
                                                       Intervener
IN THE MATTER OF :
Shri.Anil Shankar Thanekar                         ]...Petitioner
          Versus
1.   The Chief Minster,                            ]Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

     State of Maharashtra,                         ]
     Mantralaya, Mumbai-32.                        ]
                                                   ]
2.       The Chief Secretary,                      ]
         State of Maharashtra,                     ]
         Mantralaya, Mumbai-32.                    ]...Respondents
                                    WITH
             CIVIL APPLICATION NO.17 OF 2017
                              IN
      PUBLIC INTEREST LITIGATION NO.105 OF 2015
Mr.Aziz Abbas Pathan                  ]
R/at 9, Golden Park, Shankar Nagar,   ]
Takli Road, Dwarika Nashik            ]...Applicant/
                                          Intervener
IN THE MATTER OF :
Shri.Anil Shankar Thanekar                         ]...Petitioner
          Versus
1.   The Chief Minster,                            ]
     State of Maharashtra,                         ]
     Mantralaya, Mumbai-32.                        ]
patil-sachin.
::: Uploaded on - 27/06/2019               ::: Downloaded on - 28/06/2019 05:25:16 :::
                                22                          Marata(J) final.doc
2.       The Chief Secretary,                      ]
         State of Maharashtra,                     ]
         Mantralaya, Mumbai-32.                    ]...Respondents
                                    WITH
              CIVIL APPLICATION NO.18 OF 2017
                             IN
         PUBLIC INTEREST LITIGATION NO.105 OF 2015
P.A. Inamdar                                       ]
R/o.963, Nana Peth Pune-411 002.                   ]...Applicant/
                                                       Intervener
IN THE MATTER OF :Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Shri.Anil Shankar Thanekar                          ]...Petitioner
          Versus
1.   The Chief Minster,                            ]
     State of Maharashtra,                         ]
     Mantralaya, Mumbai-32.                        ]
2.       The Chief Secretary,                      ]
         State of Maharashtra,                     ]
         Mantralaya, Mumbai-32.                    ]...Respondents
                           WITH
              CIVIL APPLICATION NO.15 OF 2017
                             IN
         PUBLIC INTEREST LITIGATION NO.105 OF 2015
1.       Afsarullah Abdul Waheed Usmani ]
         R/at, A-101 Aziza Mahal, Amrut Nagar ]
         Opp. Nasim Bagh Shadi Mahal Hall, ]
         Mumbrai, Thane-400612                ]
                                              ]
2.       Shabbir Gulam Gaus Deshmukh ]
         R/at 13, Bhimabai Kapse Bldg.,       ]
         Quresh Nagar, Kurla (E),             ]
         Mumbai-400 070                       ]...Applicants/
patil-sachin.
::: Uploaded on - 27/06/2019               ::: Downloaded on - 28/06/2019 05:25:16 :::
                                23                          Marata(J) final.doc
IN THE MATTER OF :
Shri.Anil Shankar Thanekar                         ]...Petitioner
                 Versus
1.       The Chief Minster,                        ]
         State of Maharashtra,                     ]
         Mantralaya, Mumbai-32.                    ]
                                                   ]
2.       The Chief Secretary,                      ]
         State of Maharashtra,                     ]
         Mantralaya, Mumbai-32.                    ]...RespondentsDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                                    WITH
              CIVIL APPLICATION NO.16 OF 2017
                             IN
         PUBLIC INTEREST LITIGATION NO.105 OF 2015
The Minority Welfare Organisation         ]
Dhule, O/at 40 Gaon Road, Avishkar Colony,]
Plot No.35, Anum Palace, Dhule            ]
Maharashtra-424001                        ]...Applicant/
                                             Intervener
IN THE MATTER OF :
Shri.Anil Shankar Thanekar                         ]...Petitioner
          Versus
1.   The Chief Minster,                            ]
     State of Maharashtra,                         ]
     Mantralaya, Mumbai-32.                        ]
                                                   ]
2.       The Chief Secretary,                      ]
         State of Maharashtra,                     ]
         Mantralaya, Mumbai-32.                    ]...Respondents
patil-sachin.
::: Uploaded on - 27/06/2019               ::: Downloaded on - 28/06/2019 05:25:16 :::
                                24                       Marata(J) final.doc
                         WITH
            CIVIL APPLICATION NO.20 OF 2017
                           IN
      PUBLIC INTEREST LITIGATION NO.105 OF 2015
Mr.Asif Shaikh Rasheed               ]
O/at 747, MHB Colony,                ]
Malegaon, Maharashtra                ]...Applicant/
                                         Intervener
IN THE MATTER OF :
Shri.Anil Shankar Thanekar                      ]...Petitioner
                 Versus
1.       The Chief Minster,                     ]
         State of Maharashtra,                  ]
         Mantralaya, Mumbai-32.                 ]Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                                                ]
2.       The Chief Secretary,                   ]
         State of Maharashtra,                  ]
         Mantralaya, Mumbai-32.                 ]...Respondents
                           WITH
              CIVIL APPLICATION NO.19 OF 2017
                             IN
         PUBLIC INTEREST LITIGATION NO.105 OF 2015
1.       Maratha_Muslim Aarakshan Kruti      ]
         Samiti Maharashtra, Aurangabad      ]
         Through its Secretary,              ]
         Shri.Rajendra S/o Dashrathrao       ]
         Datey Patil,R/at N-11, C-1-4/6,     ]
         Patilwadi,Gajanan Nagar, HUDCO,     ]
         Aurangabad-431 001.                 ]
         District-Aurangabad                 ]
                                             ]
2.       Shri.Shaikh Masood Shaikh           ]
         Maheboob                            ]
         Vice President of Maratha-Muslim    ]
         Aarakshan Kruti Samiti Maharashtra, ]
         Aurangabad, R/o.Plot No.178/B,      ]
         Near Teen Mandir, Aref Colony,      ]
         Aurangabad-431 001.                 ]
patil-sachin.
::: Uploaded on - 27/06/2019            ::: Downloaded on - 28/06/2019 05:25:16 :::
                                25                          Marata(J) final.doc
                                            ]
3.       Shri.Kishor Ganpatrao Chavan       ]
         Vice President of Maratha-Muslim   ]
         Aarakshan Kruti Samiti Maharashtra ]
         Aurangabad, R/o. House No.4-5-81, ]
         Bamboo Market, Jadhav Mandi,       ]
         Aurangabad-431 001.                ]
         Dist-Auragabad                     ]...Applicant/
                                                Intervener
IN THE MATTER OF :
Shri.Anil Shankar Thanekar                         ]...Petitioner
                 Versus
1.       The Chief Minster,                        ]
         State of Maharashtra,                     ]Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

         Mantralaya, Mumbai-32.                    ]
                                                   ]
2.       The Chief Secretary,                      ]
         State of Maharashtra,                     ]
         Mantralaya, Mumbai-32.                    ]...Respondents
                                    WITH
              CIVIL APPLICATION NO.78 OF 2016
                             IN
         PUBLIC INTEREST LITIGATION NO.105 OF 2015
1.       The State of Maharashtra                  ]
         Through Chief Secretary                   ]
         to the Government, Mantralaya             ]
         Mumbai                                    ]
                                                   ]
2.       The Principal Secretary                   ]
         to the Government                         ]
         Social Justice & Special Asst. Dept.,     ]
         Mantralaya, Mumbai.                       ]...Applicants
patil-sachin.
::: Uploaded on - 27/06/2019               ::: Downloaded on - 28/06/2019 05:25:16 :::
                                26                          Marata(J) final.doc
IN THE MATTER OF :
1.       Shri.Anil Shankar Thanekar            ]
                                               ]
2.       Shri.Sanjeet Shukla                   ]
         197/8, Kamal Kunj, R.G. Shulka Marg, ]
         Sion East, Mumbai- 400 022            ]...Petitioner
              Versus
1.       The State of Maharashtra              ]
         through Chief Secretary to the        ]
         Government Mantralaya, Mumbai.        ]
                                               ]
2.       The Principal Secretary to the        ]
         Government                            ]
         Social Justice and Special Asst.Dept. ]
         Mantralaya, Mumbai.                   ]...Respondents
                                    WITHDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

              CIVIL APPLICATION NO.79 OF 2016
                             IN
         PUBLIC INTEREST LITIGATION NO.105 OF 2015
1.       The State of Maharashtra                  ]
         Through Chief Secretary                   ]
         to the Government, Mantralaya             ]
         Mumbai                                    ]
                                                   ]
2.       The Principal Secretary                   ]
         to the Government                         ]
         Social Justice & Special Asst. Dept.,     ]
         Mantralaya, Mumbai.                       ]...Applicants
IN THE MATTER OF :
1.   Shri.Anil Shankar Thanekar                    ]
                                                   ]
2.       Shri.Sanjeet Shukla                       ]...Petitioner
              Versus
1.       The State of Maharashtra                  ]
         through Chief Secretary to the            ]
         Government Mantralaya, Mumbai.            ]
                                                   ]
patil-sachin.
::: Uploaded on - 27/06/2019               ::: Downloaded on - 28/06/2019 05:25:16 :::
                                27                            Marata(J) final.doc
2.       The Principal Secretary to the              ]
         Government                                  ]
         Social Justice and Special Asst. Dept.      ]
         Mantralaya, Mumbai.                         ]...Respondents
                                    WITH
              CIVIL APPLICATION NO.59 OF 2016
                             IN
         PUBLIC INTEREST LITIGATION NO.105 OF 2015
Sarjerao Tayappa Patil                               ]...Applicant/
                                                         Intervener
IN THE MATTER OF :
1.   Shri.Anil Shankar Thanekar                      ]...Petitioner
                 VersusDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

1.       Chief Minister                              ]
         State of Maharashtra, Mantralay,            ]
         Mumbai-400 032.                             ]
                                                     ]
2.       Chief Secretary                             ]
         State of Maharashtra,                       ]
         Mantralay, Mumbai-400 032.                  ]...Respondents
                            WITH
      PUBLIC INTEREST LITIGATION NO.126 OF 2019
Rajaram Tukaram Kharat                    ]
R/at: Room No.301,                        ]
Jai Sainath Co-operative Housing Society, ]
Mohanand Nagar, Manjarli Road,            ]
Badlapur (W), Dist-Thane                  ]...Petitioner
                 Versus
1.       The State of Maharashtra                    ]
         through the Principal Secretary,            ]
         Social Justice Dept., Mantralaya,           ]
         Mumbai-400 032.                             ]
patil-sachin.
::: Uploaded on - 27/06/2019                 ::: Downloaded on - 28/06/2019 05:25:16 :::
                                28                            Marata(J) final.doc
2.       The Maharashtra State Backward ]
         Class Commission, Mumbai-400 032. ]...Respondents
                                    WITH
             CIVIL APPLICATION NO.129 OF 2014
                             IN
         PUBLIC INTEREST LITIGATION NO.126 OF 2019
Akhil Bhartiya Maratha Mahasangha                    ]
Through its Secretary                                ]
Rajendra Namdeo Kondhare,                            ]
Add: Prataprao Mane Sabhagraha,                      ]
5, Navalkar Lane, Prarthana Samaj,                   ]
Mumbai-400 004                                       ]...Applicant/
                                                     IntervenerDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

IN THE MATTER BETWEEN :
Rajaram Tukaram Kharat                               ]...Petitioner
                 Versus
1.       The State of Maharashtra          ]
         through the Principal Secretary,  ]
         Social Justice Dept., Mantralaya, ]
         Mumba-400 032.                    ]
                                           ]
2.       The Maharashtra State Backward ]
         Class Commission, Mumbai-400 032. ]...Respondents
                                    WITH
             CIVIL APPLICATION NO.135 OF 2014
                             IN
         PUBLIC INTEREST LITIGATION NO.126 OF 2019
P.A. Inamdar                                         ]
R/o.963, Nana Peth, Pune-411 002                     ]       ...Applicant/
                                                             Intervener
patil-sachin.
::: Uploaded on - 27/06/2019                 ::: Downloaded on - 28/06/2019 05:25:16 :::
                                29                        Marata(J) final.doc
IN THE MATTER BETWEEN :
Rajaram Tukaram Kharat                           ]...Petitioner
          Versus
1.   The State of Maharashtra              ]
     through the Principal Secretary,      ]
     Social Justice Dept., Mantralaya,     ]
     Mumba-400 032.                        ]
                                           ]
2.       The Maharashtra State Backward ]
         Class Commission, Mumbai-400 032. ]...Respondents
                           WITH
         PUBLIC INTEREST LITIGATION NO.140 OF 2014
Ketan Tirodkar                                   ]
402, Vasantkunj, Dr.Ambedkar Road,               ]Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Hindu Colony, Dadar East,                        ]
Mumbai-400 014                                   ]...Petitioner
                 Versus
State of Maharashtra                             ]
Via Hon'ble Chief Minister,                      ]
Mantralaya, Mumbai-400 032.                      ]...Respondent
                           WITH
             CIVIL APPLICATION NO.109 OF 2014
                             IN
         PUBLIC INTEREST LITIGATION NO.140 OF 2014
Shiv Sangram                             ]
R/at 41, North Kasaba, Solapur-413 007   ]
Through                                  ]
a)    Shri Vinayakrao T. Mete            ]
      National President                 ]
      R/at C/703, Venus Building,        ]
      Bhakti Park, Wadala, Mumbai-400 037]
patil-sachin.
::: Uploaded on - 27/06/2019             ::: Downloaded on - 28/06/2019 05:25:16 :::
                                30                      Marata(J) final.doc
b)       Shri.Dnyaneshwar Bhambre              ]
         General Secretory                     ]
         R/at Daul, Tal-Sindkheda              ]
         Dhule-413 007.                        ]...Applicant
IN THE MATTER OF :
Shri.Ketan Tirodkar                            ]...Petitioner
          Versus
State of Maharashtra                           ]...Respondent
                           WITH
             CIVIL APPLICATION NO.110 OF 2014
                             IN
         PUBLIC INTEREST LITIGATION NO.140 OF 2014
Maratha Hithvardhak Sangh                      ]
O/at : Dist-Satara Through its Secretary,      ]Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Shri.D.T. Pawar                                ]...Applicant/
                                               Intervener
IN THE MATTER OF :
Shri.Ketan Tirodkar                            ]...Petitioner
          Versus
State of Maharashtra                           ]...Respondent
                           WITH
             CIVIL APPLICATION NO.122 OF 2014
                             IN
         PUBLIC INTEREST LITIGATION NO.140 OF 2014
Shri.Naresh Govind Vaze                        ]
Matruchhaya Building Room No.2,                ]
Property No.81/1 Behind Vedant Tower,          ]
Tulinj Nallasopara (E), Pin-401209             ]...Applicant/
                                               Intervener
IN THE MATTER OF :
Shri.Ketan Tirodkar                            ]...Petitioner
          Versus
State of Maharashtra                           ]...Respondent
patil-sachin.
::: Uploaded on - 27/06/2019           ::: Downloaded on - 28/06/2019 05:25:17 :::
                                31                        Marata(J) final.doc
                           WITH
             CIVIL APPLICATION NO.138 OF 2014
                             IN
         PUBLIC INTEREST LITIGATION NO.140 OF 2014
Akhil Bhartiya Maratha Mahasangha                ]
Through its Secretary                            ]
Rajendra Namdeo Kondhare                         ]
Add: Prataprao Mane Sabhagraha,                  ]
5, Navalkar Lane, Prathana Samaj                 ]
Mumbai - 400 004.                                ]...Applicant/
                                                 Intervener
IN THE MATTER BETWEEN:
Shri.Ketan Tirodkar                              ]...Petitioner
          Versus
State of Maharashtra                             ]...RespondentDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                           WITH
             CIVIL APPLICATION NO.139 OF 2014
                             IN
         PUBLIC INTEREST LITIGATION NO.140 OF 2014
P.A. Inamdar                                     ]
Age 69 years, Occupation : Business              ]
& Social Worker, r/o : 963, Nana peth,           ]
Maharashtra Pune 411002                          ]...Applicant/
                                                 Intervener
IN THE MATTER BETWEEN:
Shri.Ketan Tirodkar                              ]...Petitioner
          Versus
State of Maharashtra                             ]...Respondent
                           WITH
             CIVIL APPLICATION NO.144 OF 2014
                             IN
         PUBLIC INTEREST LITIGATION NO.140 OF 2014
Ketan Tirodkar                                   ]
402, Vasantkunj, Dr.Ambedkar Road,               ]
Hindu Colony, Dadar East,                        ]..Applicant/
Mumbai-400 014                                   ]   Petitioner
patil-sachin.
::: Uploaded on - 27/06/2019             ::: Downloaded on - 28/06/2019 05:25:17 :::
                                32                          Marata(J) final.doc
                 Versus
State of Maharashtra                               ]
Via Hon'ble Chief Minister,                        ]
Mantralaya, Mumbai-400 032.                        ]       ...Respondent
                           WITH
              CIVIL APPLICATION NO.22 OF 2015
                             IN
         PUBLIC INTEREST LITIGATION NO.140 OF 2014
Maratha Swaraj Sangh Maharashtra                   ]
O/at Harishikesh, Near Datta Sai Mandir,           ]
100 Feet Road, Sangli, Dist-Sangli.                ]
Through its President                              ]
Shri.Mahadev D. Salunkhe                           ]...Applicant/Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                                                   Intervener
IN THE MATTER BETWEEN:
Shri.Ketan Tirodkar                                ]...Petitioner
          Versus
State of Maharashtra                               ]...Respondent.
                           WITH
              CIVIL APPLICATION NO.23 OF 2015
                             IN
         PUBLIC INTEREST LITIGATION NO.140 OF 2014
Shri.Naresh Govind Vaze                            ]
Matruchhaya Building, Room No.2,                   ]
Property No.81/1, Behind Vedant Tower,             ]
Tulinj Nallasopara-401209                          ]...Applicant/
                                                        Intervener
IN THE MATTER BETWEEN:
Shri.Ketan Tirodkar                                ]...Petitioner
          Versus
State of Maharashtra                               ]...Respondent
                                    WITH
patil-sachin.
::: Uploaded on - 27/06/2019               ::: Downloaded on - 28/06/2019 05:25:17 :::
                                33                     Marata(J) final.doc
             CIVIL APPLICATION NO.112 OF 2016
                             IN
         PUBLIC INTEREST LITIGATION NO.140 OF 2014
Shri.Vinod Narayan Patil                      ]
R/at 'Devgigi, G-20,                          ]
Town Centre, CIDCO, Aurangabad.               ]...Applicant/Intv.
IN THE MATTER BETWEEN:
Shri.Ketan Tirodkar                           ]...Petitioner
           Versus
State of Maharashtra                          ]...Respondent
                           WITH
             CIVIL APPLICATION NO.113 OF 2016
                           WITH
         PUBLIC INTEREST LITIGATION NO.140 OF 2014Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Shri.Vinod Narayan Patil                      ]
Age 36 years, Occu : Business, r/at           ]
Devgiri, G-20, town Centre,                   ]
CIDCO, Aurangabad.                            ]...Applicant/
                                                  Intervener
IN THE MATTER BETWEEN :
Shri.Ketan Tirodkar                           ]...Petitioner
     Versus
State of Maharashtra                          ]...Respondent
                            WITH
          CIVIL APPLICATION (ST) NO.21408 OF 2018
                             IN
         PUBLIC INTEREST LITIGATION NO.140 OF 2014
Shri Ketan Tirodkar                           ]...Applicant/
                                                 Intervener
IN THE MATTER BETWEEN:
Shri.Ketan Tirodkar                           ]...Petitioner
          Versus
State of Maharashtra                          ]...Respondent
patil-sachin.
::: Uploaded on - 27/06/2019          ::: Downloaded on - 28/06/2019 05:25:17 :::
                                34                       Marata(J) final.doc
                           WITH
         PUBLIC INTEREST LITIGATION NO.149 OF 2014
The Indian Constitutionalist Council            ]
Through its Secretary,                          ]
Dr.Laxmanrao Kisanrao Patil                     ]
C/o 109/18, Esplanade Mansion,                  ]
Mahatma Gandhi Road, Mumbai-23.                 ]...Petitioner
         Versus
1.       The Chief Minster of                   ]
         State of Maharashtra                   ]
         Mantralaya, Mumbai-32                  ]
                                                ]
2.       The Chief Secretary                    ]
         State of Maharashtra, Mantralaya       ]
         Mumbai-32.                             ]...RespondentsDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                           WITH
             CIVIL APPLICATION NO.121 OF 2014
                             IN
         PUBLIC INTEREST LITIGATION NO.149 OF 2014
Maratha Hithvardhak Sangh                       ]
O/At Powai Naka, Satara                         ]
Through its President Shri.D.K. Pawar           ]...Applicant/
                                                     Intervener
IN THE MATTER between :
The Indian Constitutionalist Council            ]
Through its Secretary                           ]
Dr.Laxmanrao Kisanrao Patil                     ]
C/o 109/18, Esplanade Mansion,                  ]
Mahatma Gandhi Road, Mumbai-23.                 ]...Petitioner
         Versus
1.       The Chief Minster of                   ]
         State of Maharashtra                   ]
         Mantralaya, Mumbai-32                  ]
patil-sachin.
::: Uploaded on - 27/06/2019            ::: Downloaded on - 28/06/2019 05:25:17 :::
                                35                          Marata(J) final.doc
2.       The Chief Secretary                       ]
         State of Maharashtra, Mantralaya          ]
         Mumbai-32.                                ]...Respondents
                                    WITH
             CIVIL APPLICATION NO.140 OF 2014
                             IN
         PUBLIC INTEREST LITIGATION NO.149 OF 2014
Akhil Bhartiya Maratha Mahasangha ]
through its Secretary Rajendra Namdeo  ]
Kondhare,Add:Prataprao Mane Sabhagraha ]
5, Navalkar Lane, Prathana Samaj       ]
Mumbai-400 004.                        ]..Applicant/
                                          Intervener.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

IN THE MATTER between :
The Indian Constitutionalist Council               ]
Through its Secretary                              ]
Dr.Laxmanrao Kisanrao Patil                        ]
C/o 109/18, Esplanade Mansion,                     ]
Mahatma Gandhi Road, Mumbai-23.                    ]...Petitioner
         Versus
1.       The Chief Minster of                      ]
         State of Maharashtra                      ]
         Mantralaya, Mumbai-32                     ]
                                                   ]
2.       The Chief Secretary                       ]
         State of Maharashtra, Mantralaya          ]
         Mumbai-32.                                ]...Respondents
                                    WITH
patil-sachin.
::: Uploaded on - 27/06/2019               ::: Downloaded on - 28/06/2019 05:25:17 :::
                                36                       Marata(J) final.doc
             CIVIL APPLICATION NO.141 OF 2014
                             IN
         PUBLIC INTEREST LITIGATION NO.149 OF 2014
Mr.Shahed Ali Inayat Ali Ansari                 ]
R/at 302, Appaji Dham Building II,              ]
Shree Complex, Adharwadi Jail Road,             ]
Kalayn (W).                                     ]..Applicant/
                                                     Intervener
IN THE MATTER between :
The Indian Constitutionalist Council            ]
Through its Secretary                           ]
Dr.Laxmanrao Kisanrao Patil                     ]
C/o 109/18, Esplanade Mansion,                  ]
Mahatma Gandhi Road, Mumbai-23.                 ]...Petitioner
         Versus
1.       The Chief Minster of                   ]Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

         State of Maharashtra                   ]
         Mantralaya, Mumbai-32                  ]
                                                ]
2.       The Chief Secretary                    ]
         State of Maharashtra, Mantralaya       ]
         Mumbai-32.                             ]...Respondents
                           WITH
             CIVIL APPLICATION NO.141 OF 2016
                             IN
         PUBLIC INTEREST LITIGATION NO.149 OF 2014
Mr.Shivaji Hindurao Patil                       ]
R/at Deval Complex Opp. Hotel Chinar,           ]
Vishrambag, Sangli.                             ]...Applicant/
                                                      Intervener
IN THE MATTER between :
The Indian Constitutionalist Council            ]
Through its Secretary                           ]
Dr.Laxmanrao Kisanrao Patil                     ]
C/o 109/18, Esplanade Mansion,                  ]
Mahatma Gandhi Road, Mumbai-23.                 ]...Petitioner
patil-sachin.
::: Uploaded on - 27/06/2019            ::: Downloaded on - 28/06/2019 05:25:17 :::
                                37                       Marata(J) final.doc
         Versus
1.       The Chief Minster of                   ]
         State of Maharashtra                   ]
         Mantralaya, Mumbai-32                  ]
                                                ]
2.       The Chief Secretary                    ]
         State of Maharashtra, Mantralaya       ]
         Mumbai-32.                             ]...Respondents
                           WITH
        PUBLIC INTEREST LITIGATION NO. 181 OF 2018
Dilip Madhukar Patil,                           ]
Age 54 years, Occu : business,                  ]
Resding at 244/9, Laxminarayan Nagar            ]
Gur Market Yard, Karveer,                       ]Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Kolhapur, Maharashtra 416005                    ]...Petitioner.
         Versus
1.       The State of Maharashtra               ]
         Through its Chief Secretary,           ]
         Mantralaya, Mumbai-32                  ]
                                                ]
2.       The Principal Secretary                ]
         Social Justice and Spl. Assitance deptt]
         Government of Maharashtra,             ]
         Hutatma Rajguru Chowk,                 ]
         Madam Cama Road, Nariman Point, ]
         Mumbai-32.                             ]...Respondents
                           WITH
        PUBLIC INTEREST LITIGATION NO. 185 OF 2018
Dr. Sudhir Ranade,                              ]
Secretary, Vishwa Hindu parishad,               ]
Kokan Division, Residing at , 203, Arihant      ]
Tower, Shivaji Nagar, Navpada,                  ]
Thane (west), Thane 400602                      ]...Petitioner.
patil-sachin.
::: Uploaded on - 27/06/2019            ::: Downloaded on - 28/06/2019 05:25:17 :::
                                38                      Marata(J) final.doc
         Versus
1.       The State of Maharashtra           ]
                                            ]
2.       The Additional Chief Secretary     ]
         Admin Reform O&M Minority Dev.     ]
         Government of Maharashtra,         ]
         Hutatma Rajguru Chowk,             ]
         Madam Cama Road, Nariman Point, ]
         Mumbai-32.                         ]
                                            ]
3.       Minorities Development Department, ]
         room No. 701, 708, 714 and 715,    ]
         7 Floor, Mantralaya, Hutatma
          th
                                            ]
         Rajguru Chowk, Madam Cama Road ]Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

         Nariman Point, Mumbai-32.          ]
                                            ]
4.       The Secretary                      ]
         Social Justice & Spl. Assistance,  ]
         Government of Maharashtra,         ]
         Hutatma Rajguru Chowk,             ]
         Madam Cama Road, Nariman Point, ]
         Mumbai-32.                         ]...Respondents
                           WITH
           CIVIL APPLICATION No. 143 OF 2014
                            IN
        PUBLIC INTEREST LITIGATION NO. 185 OF 2018
P. A. Inamdar,                                 ]
Age 69 years, Occu : Business                  ]
and Social worker, R/o : 963, Nana Peth,       ]..Applicant/
Pune-411002 Maharashtra                        ] Intervener.
IN THE MATTER Between
Dr. Sudhir Ranade,                             ]
Secretary, Vishwa Hindu parishad,              ]
Kokan Division, Residing at , 203, Arihant     ]
Tower, Shivaji Nagar, Navpada,                 ]
Thane (west), Thane 400602                     ]...Petitioner.
patil-sachin.
::: Uploaded on - 27/06/2019           ::: Downloaded on - 28/06/2019 05:25:17 :::
                                39                          Marata(J) final.doc
         Versus
1.       The State of Maharashtra           ]
                                            ]
2.       The Additional Chief Secretary     ]
         Admin Reform O&M Minority Dev.     ]
         Government of Maharashtra,         ]
         Hutatma Rajguru Chowk,             ]
         Madam Cama Road, Nariman Point, ]
         Mumbai-32.                         ]
                                            ]
3.       Minorities Development Department, ]
         room No. 701, 708, 714 and 715,    ]
         7 Floor, Mantralaya, HutatmaDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

          th
                                            ]
         Rajguru Chowk, Madam Cama Road ]
         Nariman Point, Mumbai-32.          ]
                                            ]
4.       The Secretary                      ]
         Social Justice & Spl. Assistance,  ]
         Government of Maharashtra,         ]
         Hutatma Rajguru Chowk,             ]
         Madam Cama Road, Nariman Point, ]
         Mumbai-32.                         ]...Respondents
                                    WITH
         PUBLIC INTEREST LITIGATION NO.201 OF 2014
1.       Save Democracy Foundation           ]
         Through its Chief Coordinator       ]
         Mr.Sanjay Sonawani, R/o.Pune        ]
                                             ]
2.       Shri.Mrunal Dhole-Patil Both having ]
         office at Shivneri, Mantri Park,    ]
         Kothrud, Pune-38.                   ]
                                             ]
3.       Comrade Gowardhan Gholap            ]
         R/o. "Vishw Prabha", Dehade Ves Rd, ]
         Wambori, Taluka-Rahuri,             ]
         Dist-Ahmednagar                     ]
patil-sachin.
::: Uploaded on - 27/06/2019               ::: Downloaded on - 28/06/2019 05:25:17 :::
                                40                           Marata(J) final.doc
4.       Mr.Mahadev R. Andhale                      ]
         R/o. Plot No.35, Lane No.5,                ]
         Ambika Nagar, Mukundwadi                   ]
         Aurangabad.                                ]...Petitioners.
         Versus
1.       State of Maharashtra                       ]
         Through its Chief Secretary,               ]
         Govt. of Maharashtra                       ]
         Mantralaya, Mumbai-32                      ]Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                                                    ]
2.       Principal Secretary                        ]
         Social Justice & Special Asst. Dept.       ]
         Govt. of Maharashtra, Mantralaya,          ]
         Mumbai-32.                                 ]
                                                    ]
3.       Advocate General                           ]
         Govt. of Maharashtra                       ]
         O/at High Court, Annex Building,           ]
         Fort, Mumbai-400 001                       ]...Respondents.
                           WITH
              CIVIL APPLICATION NO.45 OF 2017
                             IN
         PUBLIC INTEREST LITIGATION NO.201 OF 2014
IN THE MATTER BETWEEN :
Prof. Dr.S.M. Dahiwale                           ]
Age : 73 years,                                  ]
Occu : Professor and Head (Retd),                ]
Department of Sociology                          ]
University of Pune R/o. D-/A-4,                  ]
Clarion Park,, Aundh, Pune-411 007               ]     ...Applicant
                                            (Proposed Intervener)
AND
1.  Save Democracy Foundation                       ]
    A registered NGO,                               ]
    Through its Chief Coordinator                   ]
    Mr.Sanjay Sonawani, Age 51 Years,               ]
    R/o.Pune, Office-R/o Pune Dist, Pune            ]
patil-sachin.
::: Uploaded on - 27/06/2019                ::: Downloaded on - 28/06/2019 05:25:17 :::
                                41                           Marata(J) final.doc
                                              ]
2.       Shri.Mrunal Dhole-Patil Both having ]
         Age 30 years, Occu : Social Worker   ]
         Both having office at Shivneri,      ]
         Mantri Park, Kothrud, Pune-38.       ]
                                              ]
3.       Comrade Gowardhan Gholap             ]
         Age 55 yrs, Occu:Business &          ]
         Social Work (Member-Communist        ]
         Party of India) R/o. "Vishw Prabha", ]
         Dehade Ves Rd, Wambori, Tal-Rahuri, ]
         Dist-Ahmednagar                      ]Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                                              ]
4.       Mr.Mahadev R. Andhale                ]
         Age 62 years, Occu : Advocate,       ]
         High court, Bench at Aurangabad,     ]
         R/o. Plot No.35, Lane No.5,          ]
         Ambika Nagar, Mukundwadi             ]
         Aurangabad.                          ]...Petitioners.
         Versus
1.       State of Maharashtra                       ]
         Through its Chief Secretary,               ]
         Govt. of Maharashtra                       ]
         Mantralaya, Mumbai-32                      ]
                                                    ]
2.       Principal Secretary                        ]
         Social Justice & Special Asst. Dept.       ]
         Govt. of Maharashtra, Mantralaya,          ]
         Mumbai-32.                                 ]
                                                    ]
3.       Advocate General                           ]
         Govt. of Maharashtra                       ]
         O/at High Court, Annex Building,           ]
         Fort, Mumbai-400 001                       ]...Respondents.
                           WITH
            CIVIL APPLICATION NO. 46 OF 2017
                             IN
         PUBLIC INTEREST LITIGATION NO.201 OF 2014
patil-sachin.
::: Uploaded on - 27/06/2019                ::: Downloaded on - 28/06/2019 05:25:17 :::
                                42                        Marata(J) final.doc
IN THE MATTER BETWEEN :
1.   Prof. R. Raosaheb Kasabe,                 ]
     Age 75 yrs, Occu ; Pensioner/             ]
     Social Worker, R/o Nashik naka,           ]
     Nashik, Dist Nashik,                      ]
                                               ]
2.       Prof. Dr. D K. Gosavi, Age 72 years,  ]
         Occu ; Pensioner/ Social Worker,      ]
         R/o Nashik naka, Nashik, Dist Nashik, ]
                                               ]Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

3.       Laxman Gaikwad, Age 65 yrs,           ]
         Occu : Writer, R/o Nashik naka,       ]
         Nashik,                               ]..Applicants.
                                          (Proposed Intervener)
AND
1.  Save Democracy Foundation                 ]
    A registered NGO,                         ]
    Through its Chief Coordinator             ]
    Mr.Sanjay Sonawani, Age 51 Years,         ]
    R/o.Pune, Office-R/o Pune Dist, Pune      ]
                                              ]
2.       Shri.Mrunal Dhole-Patil Both having ]
         Age 30 years, Occu : Social Worker   ]
         Both having office at Shivneri,      ]
         Mantri Park, Kothrud, Pune-38.       ]
                                              ]
3.       Comrade Gowardhan Gholap             ]
         Age 55 yrs, Occu:Business &          ]
         Social Work (Member-Communist        ]
         Party of India) R/o. "Vishw Prabha", ]
         Dehade Ves Rd, Wambori, Tal-Rahuri, ]
         Dist-Ahmednagar                      ]
                                              ]
4.       Mr.Mahadev R. Andhale                ]
         Age 62 years, Occu : Advocate,       ]
         High court, Bench at Aurangabad,     ]
         R/o. Plot No.35, Lane No.5,          ]
         Ambika Nagar, Mukundwadi             ]
         Aurangabad.                          ]...Petitioners.
         Versus
patil-sachin.
::: Uploaded on - 27/06/2019             ::: Downloaded on - 28/06/2019 05:25:17 :::
                                43                           Marata(J) final.doc
1.       State of Maharashtra                       ]
         Through its Chief Secretary,               ]
         Govt. of Maharashtra                       ]
         Mantralaya, Mumbai-32                      ]
                                                    ]
2.       Principal Secretary                        ]
         Social Justice & Special Asst. Dept.       ]
         Govt. of Maharashtra, Mantralaya,          ]
         Mumbai-32.                                 ]Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                                                    ]
3.       Advocate General                           ]
         Govt. of Maharashtra                       ]
         O/at High Court, Annex Building,           ]
         Fort, Mumbai-400 001                       ]...Respondents.
                                    WITH
         PUBLIC INTEREST LITIGATION NO.209 OF 2014
                           WITH
              CIVIL APPLICATION NO.28 OF 2015
                             IN
         PUBLIC INTEREST LITIGATION NO.209 OF 2014
Shri.Dilip Prabhakar Aloni                          ]
R/at: 501, Cirrus-B,                                ]
Cosmos Paradise, Devdaya Nagar                      ]
Thane (W)-400 606                                   ]...Petitioner
         Versus
1.       State of Maharashtra              ]
         Through The Chief Secretary,      ]
         State Govt. of Maharashtra        ]
         Mantralaya, Mumbai-32             ]
                                           ]
2.       Social Justice&Special Asst. Dept.]
         State Government of Maharashtra   ]
         Through its Secretary,            ]
         Social Justice & Welfare Dept.,   ]
         Mantralaya, Mumbai-32.            ]
                                           ]
patil-sachin.
::: Uploaded on - 27/06/2019                ::: Downloaded on - 28/06/2019 05:25:17 :::
                                44                          Marata(J) final.doc
3.       Minority Development Dept.,               ]
         State Govt. of Maharashtra                ]
         Through Secretary,                        ]
         Minority Development Dept,                ]
         Mantralaya, Mumbai-32.                    ]
                                                   ]
4.       Maharashtra State Commission              ]
         For Backward Classes Through              ]Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

         Secretary of the said Commission,         ]
         Mantralaya, Mumbai-32                     ]
                                                   ]
5.       Maharashtra State Minorities              ]
         Commission Through Secretary              ]
         of the said Commission                    ]
         Mantralaya, Mumbai-32.                    ]...Respondents
                                    WITH
     PUBLIC INTEREST LITIGATION (ST) NO.1914 OF 2019
1.       Mr.Mahadev R. Andhale                     ]
         R/o. Nerul Sector, 22                     ]
         Thane Belapur Road, New Bombay            ]
                                                   ]
2.       Kamalakar Sukhdeo Darode                  ]
         @ Darwade                                 ]
         Krishna Apartment, Sector-6,              ]
         Kamothe, Navi Mumbai-400 209              ]...Petitioners
                 Versus
1.       State of Maharashtra                      ]
         Through The Chief Secretary,              ]
         State Govt. of Maharashtra                ]
         Mantralaya, Mumbai-32                     ]
                                                   ]
2.       Principal Secretary                       ]
         Social Justice & Special Asst. Dept.,     ]
         Government of Maharashtra,                ]
         Mantralaya, Mumbai.                       ]
                                                   ]
patil-sachin.
::: Uploaded on - 27/06/2019               ::: Downloaded on - 28/06/2019 05:25:17 :::
                                45                           Marata(J) final.doc
3.       Advocate General                           ]
         Govt. of Maharashtra,                      ]
         O/at High Court, Annex Building,           ]
         Fort, Mumbai-400 001.                      ]...Respondents
                                    WITH
  PUBLIC INTEREST LITIGATION (ST) NO.36115 OF 2018Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Ajinath Tulsiram Kadam                              ]
S.No.48/2, Kranti Nagar Near,                       ]
Anand Park Bus Stop,                                ]
Wadgaon Sheri, Pune-411 014                         ] ...Petitioner
         Versus
1.       State of Maharashtra               ]
         Through The Chief Secretary,       ]
         State Govt. of Maharashtra         ]
         Mantralaya, Mumbai-32              ]
                                            ]
2.       The Principal Secretary            ]
         Social Justice & Special Asst. Dept]
         State Government of Maharashtra    ]
         Mantralaya, Mumbai-32.             ]
3.       The National Commission for         ]
         Backward Classes, Trikoot-1,        ]
         Bhikaji Cama Place,                 ]
         RK Puram, New Delhi-110066.         ]
                                             ]
4.       The Maharashtra State Backward ]
         Classes Commission, 3rd Floor, 307, ]
         New Administrative Building,        ]
         Opp. Council Hall, Pune-411001      ]...Respondents
patil-sachin.
::: Uploaded on - 27/06/2019                ::: Downloaded on - 28/06/2019 05:25:17 :::
                                46                       Marata(J) final.doc
            ORDINARY ORIGINAL CIVIL JURISDICTION
             WRIT PETITION (LD.) NO. 4100 OF 2018
Shri.Sanjeet Shukla                             ]
of Mumbai an adult Indian Inhabitant,           ]
Authorized Representative of                    ]
Youth For Equality, residing at 197/8           ]
Kamal Kunj, R. G. Shukla Marg,                  ]
Sion (East), Mumbai - 400 022.                  ]...Petitioner.
                 VersusDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

The State of Maharashtra                        ]
Through Government Pleader,                     ]
Original Side, High Court Bombay.               ]..Respondent.
                            WITH
           NOTICE OF MOTION (LD.) NO. 739 OF 2018
                             IN
            WRIT PETITION (LD.) NO. 4100 OF 2018
Shri.Sanjeet Shukla                             ]
of Mumbai an adult Indian Inhabitant,           ]
Authorized Representative of                    ]
Youth For Equality, residing at 197/8           ]
Kamal Kunj, R. G. Shukla Marg,                  ]
Sion (East), Mumbai - 400 022.                  ]...Applicant.
IN THE MATTER BETWEEN:-
Shri.Sanjeet Shukla                             ]
of Mumbai an adult Indian Inhabitant,           ]
Authorized Representative of                    ]
Youth For Equality, residing at 197/8           ]
Kamal Kunj, R. G. Shukla Marg,                  ]
Sion (East), Mumbai - 400 022.                  ]...Petitioner.
                 Versus
The State of Maharashtra                        ]
Through Government Pleader,                     ]
Original Side, High Court Bombay.               ]..Respondent.
patil-sachin.
::: Uploaded on - 27/06/2019            ::: Downloaded on - 28/06/2019 05:25:17 :::
                                47                       Marata(J) final.doc
                              WITH
       CHAMBER SUMMONS (LD.) NO. 42 OF 2019
                                IN
         WRIT PETITION (LD.) NO. 4100 OF 2018
Prafull Pratap Pawar,                      ]
Age : 51 years, Occupation : Social Worker ]
and Journalist, Residing at Flat No. 4,    ]
Plot No. 47B, Neera Mohan Society,         ]
Sector 3, Shree Nagar,                     ]
Thane (West) 400604                        ]...Applicant.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

IN THE MATTER BETWEEN:-
Shri.Sanjeet Shukla                             ]
of Mumbai an adult Indian Inhabitant,           ]
Authorized Representative of                    ]
Youth For Equality, residing at 197/8           ]
Kamal Kunj, R. G. Shukla Marg,                  ]
Sion (East), Mumbai - 400 022.                  ]...Petitioner.
                 Versus
The State of Maharashtra                        ]
Through Government Pleader,                     ]
Original Side, High Court Bombay.               ]..Respondent.
                            WITH
           CHAMBER SUMMONS (LD.) NO. 41 OF 2019
                             IN
            WRIT PETITION (LD.) NO. 4100 OF 2018
Vaibhav Dhodiram Kadam,                         ]
Age : 29 years, Occupation : Advocate           ]
An Adult, Indain Inhabitant,                    ]
Residing at Ganesh Plaza, BURUD Lane,           ]
Yeola, Taluka : Yeola,                          ]
District Nashik, Pin 423401.                    ]...Applicant.
patil-sachin.
::: Uploaded on - 27/06/2019            ::: Downloaded on - 28/06/2019 05:25:17 :::
                                48                          Marata(J) final.doc
IN THE MATTER BETWEEN:-
Shri.Sanjeet Shukla                                ]
of Mumbai an adult Indian Inhabitant,              ]
Authorized Representative of                       ]
Youth For Equality, residing at 197/8              ]
Kamal Kunj, R. G. Shukla Marg,                     ]
Sion (East), Mumbai - 400 022.                     ]...Petitioner.
                 Versus
The State of Maharashtra                           ]
Through Government Pleader,                        ]Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Original Side, High Court Bombay.                  ]..Respondent.
                              WITH
        NOTICE OF MOTION (LD.) NO. 67 OF 2019
                                IN
         WRIT PETITION (LD.) NO. 4100 OF 2018
Shri.Sanjeet Shukla                   ]
of Mumbai an adult Indian Inhabitant, ]
Authorized Representative of          ]
Youth For Equality, residing at 197/8 ]
Kamal Kunj, R. G. Shukla Marg,        ]
Sion (East), Mumbai - 400 022.        ]...Applicant.
IN THE MATTER BETWEEN:-
Shri.Sanjeet Shukla                                ]
of Mumbai an adult Indian Inhabitant,              ]
Authorized Representative of                       ]
Youth For Equality, residing at 197/8              ]
Kamal Kunj, R. G. Shukla Marg,                     ]
Sion (East), Mumbai - 400 022.                     ]...Petitioner.
                 Versus
The State of Maharashtra                           ]
Through Government Pleader,                        ]
Original Side, High Court Bombay.                  ]..Respondent.
                                    WITH
patil-sachin.
::: Uploaded on - 27/06/2019               ::: Downloaded on - 28/06/2019 05:25:17 :::
                                49                           Marata(J) final.doc
      CHAMBER SUMMONS (LD.) NO. 59 OF 2019
                                IN
         WRIT PETITION (LD.) NO. 4100 OF 2018
Balasaheb Asaram Sarate,                   ]
Age 51 years, Occu : Professor,            ]
Add : Flat No. 702, Valle Vista Apartment, ]
Bawdhan, Pune -411028.                     ]...Applicant.
IN THE MATTER BETWEEN:-
Shri.Sanjeet Shukla                                 ]
of Mumbai an adult Indian Inhabitant,               ]
Authorized Representative of                        ]
Youth For Equality, residing at 197/8               ]Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Kamal Kunj, R. G. Shukla Marg,                      ]
Sion (East), Mumbai - 400 022.                      ]...Petitioner.
                 Versus
The State of Maharashtra                            ]
Through Government Pleader,                         ]
Original Side, High Court Bombay.                   ]..Respondent.
                                WITH
                WRIT PETITION (LD.) NO. 4128 OF 2018
1.       DR. Uday Govindraj Dhople,                 ]
          an adult, Indian inhabitant,              ]
         residing at A/304/305, Yogi Paradise,      ]
         Yogi Nagar, Borivali West,                 ]
          Mumbai-400092                             ]
                                                    ]
2.       Dr. Girish Thakur Dewnanym,                ]
         Indian Inhabitant, Residing at 501,        ]
         Ross Queen, 15th Road,                     ]
         Khar, Mumbai - 400052.                     ]...Petitioners.
                 Versus
1.       The State of Maharashtra                   ]
         Through its Chief Secretary,               ]
         State of Maharashtra, Mantralya,           ]
         Mumbai.                                    ]
patil-sachin.
::: Uploaded on - 27/06/2019                ::: Downloaded on - 28/06/2019 05:25:17 :::
                                50                         Marata(J) final.doc
                                            ]
2.       Competent Authority,               ]
         Commissioner, State Common         ]
         Entrance Test, Address : State     ]
         Common Entrance Test Cell,         ]
         New Excelsior Cinema Building,     ]
         8 Floor, A. K. Nayak Marg,
          th
                                            ]
         Fort, Mumbai , Maharashtra-400001. ]..Respondents.
                                WITHDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                 NOTICE OF MOTION NO. 17 OF 2019
                                 IN
                WRIT PETITION (LD.) NO. 4128 OF 2018
1.       DR. Uday Govindraj Dhople,               ]
          an adult, Indian inhabitant,            ]
         residing at A/304/305, Yogi Paradise,    ]
         Yogi Nagar, Borivali West,               ]
          Mumbai-400092                           ]
                                                  ]
2.       Dr. Girish Thakur Dewnanym,              ]
         aged about 51 years,                     ]
         Indian Inhabitant, Residing at 501,      ]
         Ross Queen, 15th Road,                   ]
         Khar, Mumbai - 400052.                   ]...Applicants.
IN THE MATTER BETWEEN :-
1.       Dr. Uday Govindraj Dhople,               ]
          an adult, Indian inhabitant,            ]
         residing at A/304/305, Yogi Paradise,    ]
         Yogi Nagar, Borivali West,               ]
          Mumbai-400092                           ]
                                                  ]
2.       Dr. Girish Thakur Dewnanym,              ]
         aged about 51 years,                     ]
         Indian Inhabitant, Residing at 501,      ]
         Ross Queen, 15th Road,                   ]
         Khar, Mumbai - 400052.                   ]...Petitioners.
                 Versus
patil-sachin.
::: Uploaded on - 27/06/2019              ::: Downloaded on - 28/06/2019 05:25:17 :::
                                51                           Marata(J) final.doc
1.       The State of Maharashtra           ]
         Through its Chief Secretary,       ]
         State of Maharashtra, Mantralya,   ]
         Mumbai.                            ]
                                            ]
2.       Competent Authority,               ]
         Commissioner, State Common         ]
         Entrance Test, Address : State     ]
         Common Entrance Test Cell,         ]
         New Excelsior Cinema Building,     ]
         8 Floor, A. K. Nayak Marg,Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

          th
                                            ]
         Fort, Mumbai , Maharashtra-400001. ]..Respondents.
                                 WITH
             NOTICE OF MOTION NO. 565 OF 2018
                                   IN
             WRIT PETITION (LD.) NO. 4128 OF 2018
1.       DR. Uday Govindraj Dhople,            ]
          an adult, Indian inhabitant,         ]
         residing at A/304/305, Yogi Paradise, ]
         Yogi Nagar, Borivali West,            ]
          Mumbai-400092                        ]
                                               ]
2.       Dr. Girish Thakur Dewnanym,           ]
         Indian Inhabitant, Residing at 501,   ]
         Ross Queen, 15 Road,
                         th
                                               ] ..Applicants/
         Khar, Mumbai - 400052.                ] Petitioners.
                 Versus
1.       The State of Maharashtra           ]
         Through its Chief Secretary,       ]
         State of Maharashtra, Mantralya,   ]
         Mumbai.                            ]
                                            ]
2.       Competent Authority,               ]
         Commissioner, State Common         ]
         Entrance Test, Address : State     ]
         Common Entrance Test Cell,         ]
         New Excelsior Cinema Building,     ]
         8th Floor, A. K. Nayak Marg,       ]
         Fort, Mumbai , Maharashtra-400001. ]..Respondents.
patil-sachin.
::: Uploaded on - 27/06/2019                ::: Downloaded on - 28/06/2019 05:25:17 :::
                                52                           Marata(J) final.doc
                                WITH
                 CHAMBER SUMMONS NO. 1 OF 2019
                                 IN
                WRIT PETITION (LD.) NO. 4128 OF 2018Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Kashinath Jaggannath Thakur,                        ]
Age : 38 years, Occu : Advocate and                 ]
Social Worker, Address : Koletiwadi,                ]
Post Nagothane, Tal : Pen                           ]
District : Raigad - 402106.                         ]..Applicant.
IN THE MATTER BETWEEN :-
1.       DR. Uday Govindraj Dhople,                 ]
          an adult, Indian inhabitant,              ]
         residing at A/304/305, Yogi Paradise,      ]
         Yogi Nagar, Borivali West,                 ]
          Mumbai-400092                             ]
                                                    ]
2.       Dr. Girish Thakur Dewnanym,                ]
         aged about 51 years,                       ]
         Indian Inhabitant, Residing at 501,        ]
         Ross Queen, 15th Road,                     ]
         Khar, Mumbai - 400052.                     ]...Petitioners.
                 Versus
1.       The State of Maharashtra           ]
         Through its Chief Secretary,       ]
         State of Maharashtra, Mantralya,   ]
         Mumbai.                            ]
                                            ]
2.       Competent Authority,               ]
         Commissioner, State Common         ]
         Entrance Test, Address : State     ]
         Common Entrance Test Cell,         ]
         New Excelsior Cinema Building,     ]
         8 Floor, A. K. Nayak Marg,
          th
                                            ]
         Fort, Mumbai , Maharashtra-400001. ]..Respondents.
patil-sachin.
::: Uploaded on - 27/06/2019                ::: Downloaded on - 28/06/2019 05:25:17 :::
                                53                           Marata(J) final.doc
                                    WITH
      CHAMBER SUMMONS (Ld.) NO. 58 OF 2019
                                INDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

         WRIT PETITION (LD.) NO. 4128 OF 2018
Balasaheb Asaram Sarate,                   ]
Age 51 years, Occu : Professor,            ]
Add : Flat No. 702, Valle Vista Apartment, ]
Bawdhan, Pune -411028.                     ]...Applicant.
IN THE MATTER BETWEEN :-
1.       DR. Uday Govindraj Dhople,                 ]
          an adult, Indian inhabitant,              ]
         residing at A/304/305, Yogi Paradise,      ]
         Yogi Nagar, Borivali West,                 ]
          Mumbai-400092                             ]
                                                    ]
2.       Dr. Girish Thakur Dewnanym,                ]
         aged about 51 years,                       ]
         Indian Inhabitant, Residing at 501,        ]
         Ross Queen, 15th Road,                     ]
         Khar, Mumbai - 400052.                     ]...Petitioners.
                 Versus
1.       The State of Maharashtra           ]
         Through its Chief Secretary,       ]
         State of Maharashtra, Mantralya,   ]
         Mumbai.                            ]
                                            ]
2.       Competent Authority,               ]
         Commissioner, State Common         ]
         Entrance Test, Address : State     ]
         Common Entrance Test Cell,         ]
         New Excelsior Cinema Building,     ]
         8 Floor, A. K. Nayak Marg,
          th
                                            ]
         Fort, Mumbai , Maharashtra-400001. ]..Respondents.
                                    WITH
patil-sachin.
::: Uploaded on - 27/06/2019                ::: Downloaded on - 28/06/2019 05:25:17 :::
                                54                      Marata(J) final.doc
                    WRIT PETITION NO.3151 OF 2014Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Shri.Sanjeet Shukla                            ]
Advocate, Bombay High Court,                   ]
Authorized Representative of                   ]
Youth For Equality                             ]
P-91, South Extension, Part-II,                ]
New Delhi-110 049                              ]...Petitioner
                 Versus
1.       The State of Maharashtra           ]
         G. P. High Court Bombay.           ]
                                            ]
2.       The Secretary                      ]
         Minorities Development Department ]
         Government of Maharashtra          ]
         Mantralaya, Mumbai-400 032         ]
                                            ]
3.       The Secretary                      ]
         Social Justice & Special Assistant ]
         Department, Government of          ]
         Maharashtra, Mantralaya,           ]
         Extension Bldg.,Mumbai-400 032.    ]
                                            ]
4.       Maharashtra State Reserve          ]
         Backward Class Commission, Mumbai ]...Respondents
                           WITH
          CHAMBER SUMMONS NO.225 OF 2016
                             IN
             WRIT PETITION NO.3151 OF 2014
Shri. Kishore Jagannathrao Shitole   ]
Resident of Senanager, Beed Bypass,  ]
Aurangabad - 431010                  ]...Intervener
                                       /Applicant
IN THE MATTER BETWEEN :-
Shri.Sanjeet Shukla                            ]
Advocate, Bombay High Court,                   ]
Authorized Representative of                   ]
Youth For Equality, P-91, South Extn           ]
Part-II, New Delhi-110 049                     ]...Petitioner
patil-sachin.
::: Uploaded on - 27/06/2019           ::: Downloaded on - 28/06/2019 05:25:17 :::
                                55                      Marata(J) final.docDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                  Versus
1.       The State of Maharashtra           ]
         G. P. High Court Bombay.           ]
                                            ]
2.       The Secretary                      ]
         Minorities Development Department ]
         Government of Maharashtra          ]
         Mantralaya, Mumbai-400 032         ]
                                            ]
3.       The Secretary                      ]
         Social Justice & Special Assistant ]
         Department, Government of          ]
         Maharashtra, Mantralaya,           ]
         Extension Bldg.,Mumbai-400 032.    ]
                                            ]
4.       Maharashtra State Reserve          ]
         Backward Class Commission, Mumbai ]...Respondents
                                WITH
                CHAMBER SUMMONS (ld.) NO.71 OF 2017
                                 IN
                   WRIT PETITION NO. 3151 OF 2014
Sambhaji Bajaba Thokal                         ]
R/o : B-14, Shivshakti Mumbai Co-Op            ]
Housing Society Ltd., Sec-17, Vashi,           ]
Navi Mumbai - 400 703                          ]...Applicant
                                               (Intervener)
         IN THE MATTER BETWEEN :-
Shri.Sanjeet Shukla                            ]
Advocate, Bombay High Court,                   ]
Authorized Representative of                   ]
Youth For Equality                             ]
P-91, South Extension, Part-II,                ]
New Delhi-110 049                              ]...Petitioner
                  Versus
patil-sachin.
::: Uploaded on - 27/06/2019           ::: Downloaded on - 28/06/2019 05:25:17 :::
                                56                          Marata(J) final.doc
1.       The State of Maharashtra           ]Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

         G. P. High Court Bombay.           ]
                                            ]
2.       The Secretary                      ]
         Minorities Development Department ]
         Government of Maharashtra          ]
         Mantralaya, Mumbai-400 032         ]
                                            ]
3.       The Secretary                      ]
         Social Justice & Special Assistant ]
         Department, Government of          ]
         Maharashtra, Mantralaya,           ]
         Extension Bldg.,Mumbai-400 032.    ]
                                            ]
4.       Maharashtra State Reserve          ]
         Backward Class Commission, Mumbai ]...Respondents
                                    WITH
         CHAMBER SUMMONS NO.32 OF 2017
                         IN
          WRIT PETITION NO. 3151 OF 2014
Akhil Maratha Federation          ]
a charitable trust registered under                ]
the provisions of the Maharashtra Public           ]
Trusts Act, 1950 and having its registered         ]
office address at :                                ]
5, Navalkar Lane, Prarthana Samaj,                 ]
Mumbai - 400 004                                   ]...Applicant
                                                   (Intervener)
IN THE MATTER BETWEEN :-
Shri.Sanjeet Shukla                                ]
Advocate, Bombay High Court,                       ]
Authorized Representative of                       ]
Youth For Equality                                 ]
P-91, South Extension, Part-II,                    ]
New Delhi-110 049                                  ]...Petitioner
                 Versus
patil-sachin.
::: Uploaded on - 27/06/2019               ::: Downloaded on - 28/06/2019 05:25:17 :::
                                57                    Marata(J) final.docDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

1.       The State of Maharashtra           ]
         G. P. High Court Bombay.           ]
                                            ]
2.       The Secretary                      ]
         Minorities Development Department ]
         Government of Maharashtra          ]
         Mantralaya, Mumbai-400 032         ]
                                            ]
3.       The Secretary                      ]
         Social Justice & Special Assistant ]
         Department, Government of          ]
         Maharashtra, Mantralaya,           ]
         Extension Bldg.,Mumbai-400 032.    ]
                                            ]
4.       Maharashtra State Reserve          ]
         Backward Class Commission, Mumbai ]...Respondents
         AND
Akhil Maratha Federation                    ]
A charitable trust registered under the     ]
provisions of the Maharashtra Public Trusts ]
Act, 1950 and having its registered office ]
address at :     5, Navalkar Lane,          ]
Prarthana Samaj, Mumbai - 400 004           ]...Proposed
                                          Respondent
                             WITH
        WRIT PETITION (LD.)       NO. 4269 OF 2018
Vishnuji p. Mishra                      ]
of Mumbai an adult Indian Inhabitant,   ]
Residing at Bldg. No.29, 1 floor,
                          st
                                        ]
Plot No. 290, Owners Colony, GTB Nagar, ]
Sion Koliwada, Mumbai - 400 037.        ]..Petitioner.
                 Versus
The State of Maharashtra                     ]
Through G. P. Original Side                  ]
High Court Bombay.                           ]..Respondent
patil-sachin.
::: Uploaded on - 27/06/2019         ::: Downloaded on - 28/06/2019 05:25:17 :::Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                                58                        Marata(J) final.doc
                               WITH
          PUBLIC INTEREST LITIGATION NO.06 OF 2019
1.       Doodhnath Vishveshwar Saroj          ]
         Add: 22/23, Liberty Shopping Center, ]
         Hill Road, Bandra West, Mumbai-50. ]
                                              ]
2.       Ameen Mustafa Idrisi                 ]
         Add: Gala No.2, Sangam Society,      ]
         Pandit Lal Tiwari Road,              ]
         Kandivali (W), Mumbai-67             ]...Petitioners
                 Versus
1.       State of Maharashtra                    ]
         Through Government Pleader,             ]
         PWD, Annexe Building,                   ]
         Behind High Court Building,             ]
         Fort, Mumbai.                           ]
                                                 ]
2.       Union of India                          ]
         Through Joint Secretary,                ]
         Ministry of law & Justice,              ]
         Aykar Bhawan, M.K. Road,                ]
         Marine Lines, Mumbai-21.                ]
                                                 ]
3.       Chief Secretary,                        ]
         4th Floor, Mantralaya,                  ]
         M.V. Karve Marg, Backbay,               ]
         Mumbai-400 021.                         ]...Respondents
                           WITH
         PUBLIC INTEREST LITIGATION NO.969 OF 2019
1.       Dr.Roshani Sanjay Manek                 ]
         R/at C-3003, Ashford Royale Tower,      ]
         S Samuel Street, Link Road,             ]
         Nahur-West, Bhandup-West,               ]
         Mumbai-400 078                          ]
                                                 ]
2.       Mrs.Varsha Sanjay Manek                 ]
         R/at C-3003, Ashford Royale Tower,      ]
         Link Road, Nahur-West,                  ]
         Bhandup(W),Mumbai-400 078               ]...Petitioners
patil-sachin.
::: Uploaded on - 27/06/2019             ::: Downloaded on - 28/06/2019 05:25:17 :::Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                                59                       Marata(J) final.doc
                 Versus
1.       State of Maharashtra                   ]
         Through its Chief Secretary,           ]
         State of Maharashtra,                  ]
         Mantralaya, Mumbai.                    ]
                                                ]
2.       Competent Authority                    ]
         Commissioner, State Common             ]
         Entrance Test Add: State Common        ]
         Entrance Test Cell, New Excelsior      ]
         Cinema Building, 8th Floor,            ]
         A.K. Nayak Marg, Fort, Mumbai          ]
         Maharashtra-400 001.                   ]...Respondents.
Appearances in Appellate Side matters :
Mr. Gunratan Sadavarte a/w Mr.Arun D. Nagarjun,Mr.Anil
D.Sabale, Mr.Siddhart J.Bhosale and Mr. Ankush Govindrao
Gavale for petitioner in PIL No. 175 of 2018 and PIL
No.149/2014
Mr. Y. H. Muchhala, Sr. Adv, I/by Mr. Musaddique Momin,
Tauseef Sayyed for the Petitioner in W.P.No.937/2017 and W.P.
No.1208/2019
Mr. Ashish Gaikwad a/w. Bhavana R. Khichi, Prabhakar Ranshur
for the Petitioner in WPST.No.2126/2019. And for R.Nos.14, 25
AND 28 in PIL No.175/2018.
Mr. Ranjeet Thorat, Sr. Adv. A/w. Firoz Barucha I/by. Rajesh A
Tekale for the Petitioner in WPST.No.2668/2019.
Mr. S.B.Talekar I/by. M/s.Talekar and Associates for the
Petitioners in W.P.No. 11368/2016 and WPST.No.3846/2019.
Mr. J.G.Ardwad(Reddy) a/w.Mr.Arvind Aswani for the Petitioner
in PIL NO. 201/2014 and WPST. No.10755/2017.
Mr. Rajesh A. Tekale a/w.Mr. Ramesh Dube Patil a/w Ankur
Pahade, Vivek Joshi, Khushbu Marwadi and Prasad Dube Patil I/
by Jay and Co. for Petitioner in PIL.No.19/2019 and Respondent
no.3 in PIL/175/18.
patil-sachin.
::: Uploaded on - 27/06/2019            ::: Downloaded on - 28/06/2019 05:25:17 :::Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                                60                      Marata(J) final.doc
Mr. Ashish Mehta for the Petitioner in PIL.No.105/2015.
Mr. Santosh Parad for the Petitioner in PIL.No.126/2009
Ms. Aparna D. Vhatkar for the Petitioner in PIL.No.140/2014
Mr. Prasad Dhakephalkar,Sr.Adv. I/by.Mr.Abhijit Patil for the
Petitioner in PIL.No.181/2018 and Respondent No.23 in PIL. No.
175/2018.
Mr. C. N. Chavan for the Petitioner in PIL.No.185/2014.
Mr. D.P. Aloni in person in PIL.No.209/2014.
Mr. Rahul Agrawal for the Petitioner in PILST.No.1914/2019.
Mr. Rafique Dada, Sr. Advocate alongwith Mr.Mihir Desai,Sr.
Adv. a/w. Mr. Ashish Gaikwad i/by. Ms. Pooja Thorat a/w Ms.
Bhavana Khichi for petitioner in PILST No. 36115/2018.
Mr. Mukul Rohatgi, Special Counsel, Mr. Paramjeet Singh
Patwalia, Special Counsel, Mr.Nishant Katneshwarkar, Special
Counsel, Mr. V. A. Thorat, Senior Counsel, Mr. A. Y. Sakhare,
Senior Counsel, Smt. G. R. Shastri, Addl. G.P, Mr. P. P. Kakade,
AGP, Mr. Vaibhav Sugdare, Ms. Prachi Tatake, Mr. Akshay
Shinde, B Panel AGP and Rohan S.Mirpury, Deepak Salvi,
Ms.Misha Rohatgi, Ms. Harshika Varma, for the Respondent-
State
Mr. Vineet Naik,Sr. Adv. A/w. Sukand Kulkarni, Ashish Gaikwad
i/by.Mr. Sandeep Dere for Respondent No.28 in PIL/175/18.
Mr. Rajiv Chavan,Sr.Adv. a/w Priyanka Chavan, Anupama
Pawar,Sumangala Yadav and Rajesh Tekale I/by.Sachin Pawar
for for respondent no.15 in PIL/175/18.
Mr. Yogesh P. Morbale a/w. Abhijit Tambe, Chalak for the
Applicant in CAI.Nos.06/2019 and 07/2019 in PIL.No.175/2018.
Mr. Nasir Mohammed for the Applicant in CAI.No.08/2019 in
PIL.No.175/2018.
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019           ::: Downloaded on - 28/06/2019 05:25:17 :::
                                61                      Marata(J) final.doc
Mr.Ashish Gaikwad a/w. Bhavana R. Khichi, Prabhakar Ranshur
for R.Nos.14, 25 AND 28 in PIL No.175/2018 and for the
Petitioner in WPST.No.2126/2019.
Ms. Vijayalaxmi Khopade for the Applicant in CAI.No.17/2019.
Mr. A.A.Siddiqui for the Applicant in CAI. No.16/2017 in PIL. No.
105/2015.
Mr. Parag Vyas for UOI in PIL No.126/2009.
Mr. Nilesh Wable for Respondent No. 4 in PIL.No.175/2018.
Mr. D. W. Bhosale for respondent no.5 in PIL/175/18.
Mr.A.R.Singh a/w. S.R.Singh for Respondent No. 6 (UOI).
Mr. Rameshwar N. Gite a/w. Ankit Chaturvedi, Rohit Gorade,
Avanti Inamdar for respondent no.7 in PIL/175/18.
Mr. V. P. Patil I/by Vaibhav Kadam for respondent no.9 in
PIL/175/18.
Mr. Gajanan Shinde a/w Sambhaji Kharatmol for Respondent
No. 10 in PIL/175/18.
Mr. Abhijit Desai a/w.Ms. Divya Parab for respondent No.11 in
PIL/175/18.
Mr. Sanjeev B. Dere a/w. Suchita Pawar for Respondent No.12
in PIL.No.175/2018.
Mr. Sachin Pawar for Respondent No. 13 in PIL.No.175/2018.
Mr. Jitendra P. Patil for Respondent No.18 in PIL.No.175/2018.
Mr.Dilip Shinde for Respondent No.20 in PIL.No.175/2018.
Mr. Sandeep Salunke for respondent no.21 in PIL/175/18.
Mr. Satish Mane Shinde a/w V. M. Thorat, Ms.Pooja Thorat and
Patil for Respondent no.23 in PIL/175/18.
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019           ::: Downloaded on - 28/06/2019 05:25:17 :::
                                62                      Marata(J) final.doc
Mr. Vitthal Ghumde I/by. Rajan Gaikwad for Respondent No.26
in PIL.No.175/2018.
Mr.Sachin D. Kadam for Respondent No.29 in PIL No.175/2018.
Mr.S.D.Rupwate for Respondent No.30 in PIL.No.175/2018.
Ms.Leena Patil a/w. Mr.Akshay R. Kapadia for Respondent
No.31.
Mr. Sanjeev R.Singh a/w. Jyoti S. Agrawal for Respondent No.1
in PIL.No.19/2019 and W.P.No.3846/2019.
Appearances in Original Side matters :
Mr. Arvind Datar, Sr. Adv. and Mr. Pradeep Sancheti, Sr.
Advocate a/w Mr. Darshit Jain, Mr.Prathamesh Kamat, Kanchan
Dube and Neha Yadav, Pallavi Bali I/by Mr. Ashish U. Mishra for
petitioner in WPL/4100/18 and W.P.(OS) No.3151/2014.
Mr. S.G.Anney, Sr.Adv. A/w. Pooja Patil, Premlal Krishnan,
Sankalp Anantwar, Anurag Mankar, Rishi Alwa, Dinesh Bhatia,
I/by. M/s. Pan India Legal Services LLP for Petitioners in
WPL.No.4128/2018 and NMW Nos.565/2018, 17/2019,
45/2019.
Mr. Ejaj Naqvi for the Petitioner in PIL.(OS)No.06/2019
Mr. S.T. Manek for the Petitioner in WPL 969/2019
Mr. Ramesh Dube Patil a/w Ankur Pahade, Vivek Joshi, Khushbu
Marwadi and Prasad Dube Patil I/by Jay and Co. for
Applicant/Intervenor in CHSW.NO.01/2019.
Mr. Mukul Rohatgi, Special Counsel, Mr. Paramjeet Singh
Patwalia, Special Counsel, Mr. Nishant Katneshwarkar, Special
Counsel, Mr. V. A. Thorat, Senior Counsel, Mr. A. Y. Sakhare,
Senior Counsel, Smt. G. R. Shastri, Addl. G.P, Mr. P. P. Kakade,
AGP, Mr. Vaibhav Sugdare, Ms. Prachi Tatake, Mr. Akshay
Shinde, B Panel AGP and Rohan S.Mirpury, Deepak Salvi,
Ms.Misha Rohatgi, Ms. Harshika Varma, for the Respondent-
State.
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019           ::: Downloaded on - 28/06/2019 05:25:17 :::
                                  63                         Marata(J) final.doc
Mr. V. M. Thorat a/w. P. V. Thorat, Anukul Seth, Aditya Bhagat
for Applicant in CHSWL.No.58/2018 and CHSWL.NO59/2019.
Mr. Rajiv Chavan, Sr. Advocate a/w Priyanka Chavan, Anupama
Pawar, Sumangala Yadav and Rajesh Tekale I/by Sachin Pawar
for Applicant/Intervenor in CHSWL.No.41/2019 in WPL.
No.4100/2018.
                          Coram : RANJIT MORE &
                                  SMT. BHARATI H. DANGRE, JJ.
                Reserved on : 26th March 2019
            Pronounced on : 27th June 2019
JUDGMENT [Per Ranjit More, J.]
1                Every democracy is challenged by the complex task
of providing social justice to sections that have been
traditionally discriminated against, while ensuing that such
affirmative action does not hinder opportunities offered to the
rest of the population. The caste system deeply embodied in
Indian society is accused of widespread discrimination on
basis of descent and birth.           Successive Governments have
sought to redress this inequity through policy of affirmative
action, which is perceived as policies formulated with a view
to increase opportunities for the disadvantaged class.                       The
Constitution itself has endeavored to rectify discrimination
against group of people often loosely referred to as "Other
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                ::: Downloaded on - 28/06/2019 05:25:17 :::
                                     64                            Marata(J) final.doc
Backward Class" through Articles 15, 16, 335 and 340. The
absence of precise definition of this term, resulted in
development of a method to identify them and determine who
exactly comprised the Other Backward Class. This vexatious
issue persisted since the Constitution came into force and has
perplexed the Indian Judicial System since long. At times, this
issue has inflamed this country and coined a new terminology
of 'Reverse discrimination'.
                 Seven         decades   since   the    enactment            of     the
Constitution, alas this issue of identification of the Backward
classes and the power of State to have recourse to the
enabling provision under Article 15(4) and 16(4) still continues
to be a contentious issue. The Maratha community, perceived
as a dominant community in the State of Maharashtra
indulged into state wide agitations staking their demand for
reservation and privileges under the Constitution and it
reached its peak in the year 2017-2018.                        The community
carried out massive marches, where 15 to 20 lakh persons
participated and it is reported that 57 marches were held
across the State between August 2016 to December 2016.
After the community took to the streets, the State brought an
Ordinance for the first time in the year 2014 granting
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                      ::: Downloaded on - 28/06/2019 05:25:17 :::
                                65                           Marata(J) final.doc
reservation to the said community in jobs and in the field of
education. The said Ordinance was then translated into an Act
No.I of 2015, which was brought before this Court and the
enactment conferring the benefit on the community came to
be stayed.           The State Government then set up a backward
class Commission to ascertain the social and educational
status of the community. Though the community is politically
well represented, the various reports including the report of
the Committee headed by Justice Gaikwad Commission
suggest that huge chunks of Maratha is still deprived of basic
facilities. The report of research study carried out by Gokhale
Institute of Economics disclose that 40% of the total farmers
who committed suicide were Marathas and this report is a
reflection of the agrarian crisis in the State and since most of
the Marathas are agriculturists, it brings forth the financial
distress faced by the community. In the backdrop of the said
scenario, the youth of this community is looking towards
reservation as a solution to their progress and march towards
cities and that is the reason why the community joined hands
to track their demand.              Amidst this scenario, the State
Government declared 72,000 Government jobs open and this
declaration was met with allegations and counter allegations,
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                ::: Downloaded on - 28/06/2019 05:25:17 :::
                                 66                               Marata(J) final.doc
giving rise to a political debate and the issue of reservation to
Maratha is kept alive and has been brought before us through
these bunch of petitions.           The State witnessed mixed reaction
to the claim of Marathas which came to be objected by the
Other Backward Classes as they are anxious that their share is
being eaten up by the newly created class and again, there
are open category candidates who are apprehensive that
merit would receive a set back.                  The emergent situation
makes us think whether we have lost the battle of annihilation
of castes proposed by our founding fathers.                           Our whole
anxiety as a Constitutional Court is to assure a social harmony
as perceived by the Constitution.               We are duty bound to act
impartially, uninfluenced by the outside forces and make a fair
decision within the framework of the Constitution and the
existing laws and that is what we propose to do while dealing
with the flaring issue in the State as on today.
2                The present batch of writ petitions pose a challenge
to the Maharashtra State Reservation for Seats for Admission
in Educational Institutions in the State and for appointments in
the public services and posts under the State (for Socially and
Educationally            Backward    Classes)    SEBC        Act,      2018        i.e.
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:17 :::
                                        67                           Marata(J) final.doc
Maharashtra Act No.LXII of 2018 (for short 'SEBC Act'). Since
common issues are involved in this batch of petitions and
some of the petitions assailing the Constitutional validity of
the enactment as well as its provisions and other writ petitions
seeking implementation of the said Act, we have clubbed all
the writ petitions, heard them together and they are being
decided by this common judgment.                    The grounds of challenge
raised in the petitions assailing the validity of the enactment
are more or less similar.                    We would, however, make a
reference to the factual aspects involved in three lead
petitions and make a reference to the question of law involved
in all the writ petitions in a cumulative manner.
                 We would first refer to the Public Interest Litigation
No.175 of 2018 filed by Dr. Jishri Laxmanrao Patil, Member
Indian Constitutionalist Council.                 The petitioner in the said
petition is a practicing Advocate and Member of a non
profitable organization known as 'Indian Constitutionalist
Council' having its office in Mumbai.                    The said petition is
instituted by her with the claim that she does not have any
personal interest in the matter but since the said enactment,
according to the petitioner, is a fraud played on the
Constitution          of       this   country,   by hiking      the      reservation
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                        ::: Downloaded on - 28/06/2019 05:25:17 :::
                                 68                             Marata(J) final.doc
available in the Sate of Maharashtra from 52% to 68% and
thereby crossing the barrier of the ceiling limit of 50%
imposed by the Hon'ble Apex Court in case of in case of Indra
Sawhney Versus Union of India1. The petition proceeds to
state that the quota which is reserved for the Maratha
community affects the seats in general pool of candidates and
therefore, it is claimed that it does not identify itself as a
reservation under Articles 15 and 16 of the Constitution. The
said reservation is also clamped as nothing but a desperate
attempt by the political parties to appease the vote bank. The
petition proceeds to state that the said enactment is a
culmination of long pending demand for reservation by
Marathas and this is done without enough supportive data so
as to justify an extra ordinary situation.              The petitioner has
placed reliance on the judgment of the Rajasthan High Court
whereby 5% reservation was conferred on Gujjars and four
other castes and the Rajasthan High Court was pleased to
quash the Rajasthan Special Backward Classes (Reservation of
Seats       in    Educational   Institutions   in    the      State      and         of
appointments and post in services under the State Act, 2015)
and according to the petition, the Hon'ble Apex Court, by its
1 1992(3) SCC 217
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                   ::: Downloaded on - 28/06/2019 05:25:17 :::
                                   69                            Marata(J) final.doc
order dated 13th November 2017 was pleased to restrain the
State Government from taking any action or decision on the
administrative side or in any manner, conferring the benefit of
reservation which will have the result of crossing the total
reservation beyond 50%.
                 During the pendency of the petition before this
Court, subsequent events occurred resulting into enlarging the
scope of petition and a relief came to be sought to quash and
set aside the reservation of Maratha community in the
advertisement             published    by   Maharashtra       Public       Service
Commission on 10th December 2018 bearing Advertisement
No.50 of 2018. Further, a relief is also sought to quash and
set aside the Government Resolution dated 5 th December
2018 issued by the General Administrative Department (GAD)
fixing the roster point of SEBC reservation i.e. Maratha
Reservation in the public services. The present PIL, therefore,
seeks a relief of issuance of writ in the nature of mandamus to
stop the discrimination of the open category/open pool
candidates at the hands of State of Maharashtra (to the extent
of 68%) which amounts to breach of Article 14, 16, 21 of the
Constitution of India.
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:18 :::
                                      70                           Marata(J) final.doc
                 While         the   petition   was       pending,           several
applications for Intervention came to be instituted in the said
writ petition seeking relief of impleading the applicants as
party respondent as the applicants sought to justify the
impugned enactment by the State legislature.                                On 10th
December 2018, this Court was pleased to allow the
applications for intervention as the learned counsel appearing
for the petitioner had conveyed his No Objection.                                  The
petitioner was directed to add all the applicants as party
respondents and to serve the copy of PIL on the newly added
respondents to the said applicants.                   As a result, all the
applicants/intervenors supporting the impugned legislation are
impleaded as party respondents from respondent no.3 to
respondent no.31. The Chief Minister of State of Maharashtra
and the Chief Secretary of State of Maharashtra are also
respondents in the said petition.
3                The second lead petition to which we would make a
reference with Writ Petition (L) No.4128 of 2018 filed by
Dr.Uday Govindraj Dhople and others. The said petition is filed
in representative capacity on behalf of all similarly situated
medical         students/medical          aspirants   who       are      adversely
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                      ::: Downloaded on - 28/06/2019 05:25:18 :::
                                71                         Marata(J) final.doc
affected by the impugned SEBC Act of 2018.                 The said writ
petition inter alia, seek quashment of the SEBC Act, 2018 after
examining its validity,legality and propriety. In the alternative,
a writ in the nature of certiorari as prayer for, for quashing
and setting aside Section 2(j), section 3(2) and section 3(4),
Section 4, Section 5 and Section 9(2), 10, 12 of the impugned
Act after examining its legality and propriety.
                 A bold statement is made in the petition to the
effect that the reservation system has become a tool of
convenience for politicians and government in power to
secure their vote bank.        The petition proceeds to state that
the Maratha community was never treated as a backward
community and on earlier occasions, their claim was rejected.
the Mandal Commission rejected the said demand. The said
petition places heavy reliance on the judgment of the Hon'ble
Apex court in case of M.R.Balaji and others Vs. State of
Mysore,2 where the Apex Court had laid down the permissible
and legitimate limit in reservation and held that special
provisions improperly made under Article 15(4) and under
Article 16(4) beyond the permissible and legitimate limits
would be liable to be challenged as fraud on the Constitution
2 AIR 1963 SC 649
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019              ::: Downloaded on - 28/06/2019 05:25:18 :::
                                  72                           Marata(J) final.doc
and it was clarified that Article 15(4) is an enabling provision,
it does not impose an obligation but merely leaves it to the
discretion of the appropriate government to take suitable
action, if necessary. It is alleged that the Maratha community
has been agitating for reservation since past several years
and it is only on account of the public pressure mounting on
the government, the reservation is provided by the impugned
enactment.
4                The grievance set out in the petition is about the
medical         profession     and    how   adversely       the      impugned
enactment is going to affect the future of young medical
aspirants.         Reservation contemplated under the enactment,
according to the petitioner, has reduced the number of seats
falling in the kitty of open category candidates and the
petition proceeds to give the statistics. It is also alleged that
the chance of open category student securing a seat in Post
Graduation is minimized by the 16% reservation for Maratha
community and the impugned enactment seriously prejudices
the chances of the open candidates in all fields of education
as well as service.
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                  ::: Downloaded on - 28/06/2019 05:25:18 :::
                                73                         Marata(J) final.doc
                 The further ground of challenge is that the SEBC
Act was passed presumably based on the recommendations of
Justice Gaikwad Commission Report. However, the said report
is not based on any empirical data and severe criticism is
hurled about the inadequacy of the data base and absence of
disclosure of target group to examine and conclude that
Maratha community is socially and educationally backward.
The scathing criticism further proceeds to state that a
community which was found not to be socially or educationally
backward for over 60 years, is now declared so, without any
change in circumstances. The petition also alleges non-
application of mind to an important aspect as to which
communities or class or group of citizens would constitute the
SEBC and the Commission has ignored all other castes and
have addressed itself only to the social and educational
backwardness of Maratha community.            Such an approach is,
therefore, questioned as arbitrary and discriminatory and the
SEBC Act is assailed as a colourable piece of legislation. It is
also alleged that the enabling provisions enumerated in the
Constitution under Article 15(4) and 16(4) empowers the State
to identify and recognize the compelling interest and confer
assistance to the socially and educationally backward class of
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019              ::: Downloaded on - 28/06/2019 05:25:18 :::
                                      74                           Marata(J) final.doc
citizens and these enabling provisions have to be exercised
with great caution, keeping in mind the efficiency which is
held to be constitutional limitation on the discretion of the
State in making reservation as indicated by Article 335. It is
also alleged that on pure assumption, without any empirical
data, the population of Maratha in the State of Maharashtra is
estimated as 32% though the 2001 census or 2011 census do
not give any figures of Maratha population and therefore,
according to the petition, there is no data available with the
respondents to indicate inadequate access of education or
inadequate representation in the services to this community
due to backwardness.
5                The impugned enactment is alleged to have an
effect of stratifying the society of class based on communal
line and the said legislation is further frowned upon as this can
never be the intention or scope of equality clause or of the
special         provisions     for        advancement      of      socially        and
educationally backward class of citizens.                       The impugned
provisions of the SEBC Act, 2018 are also alleged to be
violative of basic structure and fundamental values of
Constitution articulated in the preamble and encapsulated in
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                      ::: Downloaded on - 28/06/2019 05:25:18 :::
                                     75                          Marata(J) final.doc
Article 14, 16 and 19. Creation of separate class of Maratha
community outside the OBC class and then bestowing them
with special and separate benefits apart from the OBC class is
also severely criticized in the petition. A concession is offered
to the effect that if at all the State has reached the verifiable
and justified conclusion that Maratha community is in fact,
socially and educationally backward, then, in that case at the
highest, they would form part of the Other Backward Class
instead of providing a separate reservation.
                 Chamber Summons No.1 of 2019 is moved in the
Writ Petition by one Kashinath Jagannath Thakur, who is an
Advocate by profession and also a social worker belonging to
Maratha community. Relief is sought to implead him as party
respondent.             Further, there is also a Chamber Summons
moved by Balasaheb A. Sarate, who claims to be a researcher
of Maratha reservation and a professor of Economics and also
a social worker.               He supports the impugned enactment and
seeks impleadment as a party respondent in the said writ
petition.
6                The third lead petition which poses an extensive
challenge to the findings of the backward class commission
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:18 :::
                                      76                               Marata(J) final.doc
and its report which is the basis of the impugned legislation, is
Writ Petition No.4100 of 2018 filed by one Sanjeet Shukla, an
authorized representative of the organization known as 'Youth
for Equality' which claims to be a constitute of professionals
and young persons working in different organizations. It is the
same petitioner who had filed a Writ Petition No.3151 of
2014            challenging    the        ordinance     promulgated             by      the
Government of Maharashtra in the year 2014.                              The petition
proceeds to state that a detailed interim order was passed by
this Court on 14th November 2014 staying the operation and
implementation of the ordinance dated 9th July 2014 and the
Government Resolution providing for 16% reservation in
favour of Maratha community. The petition proceeds to state
that the said order was challenged by the State Government
before the Hon'ble Apex Court in SLP which was dismissed by
an order dated 18th December 2014. Thereafter, the State of
Maharashtra had enacted the ESBC Act of 2014 which
contained a provision of 16% reservation for the education
and socially backward class in which Maratha community is
included. Since the Ordinance and the new enactment were
identical, the High Court on 7th April 2016 also stayed the
operation and implementation of the ESBC Act of 2014. The
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                          ::: Downloaded on - 28/06/2019 05:25:18 :::
                                        77                               Marata(J) final.doc
petition         proceeds         to   state     that     thereafter         the      State
Government             issued      a     notification    on     4th    January         2017
constituting            the      Maharashtra          State       Backward             Class
Commission and on 4th May 2017, the Court recorded the said
statement of the State Government.                                The Commission
thereafter prepared a report and recommended reservation in
favour of the Maratha community which is the foundation of
the SEBC Act of 2018. The State Government tabled the bill
for providing reservation to Maratha community before the
State assembly on or about 29th November 2018 and it is
alleged that the said Bill was passed without any discussion,
despite the fact that the report by the Commission for
Backward class was not shared or tabled before the State
assembly.          The         State   Government           thereafter         issued         a
notification stating that the Governor had approved the SEBC
Act of 2018.            It is alleged that the non-tabling of MSBCC's
report          violated       Section      15   of   the      Maharashtra            State
Commission for Backward Classes Act, 2005.                               The said writ
petition also formulates more or less the same grounds which
we have reproduced above in the other two writ petitions.
Certain additional grounds are formulated in the petition and
one of the ground is that the impugned Act is passed without
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                            ::: Downloaded on - 28/06/2019 05:25:18 :::
                                     78                           Marata(J) final.doc
complying with the requirements of the Constitution 102 nd
Amendment Act of 2018 and particularly without complying
with clause (9) of Article 338-B and also there is no
compliance with Article 342-A as no notification is issued by
the President.
                 The petition further proceeds to state that Maratha
community            is    a   powerful    community      in    the      State         of
Maharashtra with proved dominance in Government Service,
education, politics, sugar cooperatives etc, and in fact, in
second          Backward        Class    Commission     Report        dated       31 st
December            1980       (Mandal    Commission      Report),         Maratha
community has categorized the community as forward Hindu
community. Similarly, the National Commission of Backward
Class report dated 25th February 2000 categorized Maratha as
socially advanced and prestigious community and not only
this, the MSBCC (Bapat Commission Report) dated 25 th July
2008 also rejected the demand of Maratha community to be
included in the Other Backward Class. The petition proceeds
to give the details in form of a table as to how many medical
colleges in the State are owned by the stalwarts from Maratha
community and the petition also contains a list of the Chief
Ministers of the State of Maharashtra and a positive assertion
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:18 :::
                                  79                          Marata(J) final.doc
is made that most of the Chief Ministers of this State belong to
Maratha community.              The petition also contains a list of
cooperative sugar factories being headed in the capacity as
Chairman by the persons from Maratha community.                               The
petitioner          further    makes   a   claim     that       Maharashtra
Government does not have any data of the population of
Marathas and therefore, they have been quoting inconsistent
numbers.            The estimate of Marathas to be 30% of the
population as is the basis of the report, according to the
petition, is evidently wrong when the established quantum of
other sections of the population is taken into account.                       The
claim of Maratha being a backward category is looked by the
petitioner as a result of the regressive tactics adopted by the
Maratha community by staging dharna and agitations with a
demand of grant of reservation to them.                 The petition also
give a detailed analysis of the report of the commission and
alleges that the study carried out is patently unscientific and
completely unreliable.           The small sample size of 46,629 is
objected to as a biased sample as out of the total number of
families surveyed included 29,813 Maratha families and since
64% of the sample size is of Maratha community, the end
result according to the petitioner, has to be in favour of
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                 ::: Downloaded on - 28/06/2019 05:25:18 :::
                                    80                           Marata(J) final.doc
Maratha.          Reliance is placed on the judgment of Rajasthan
High Court in Writ Petition No.1645 of 2016 which had set
aside the reservation of Gujjar and one of the ground being
that the sample study did not follow the proportional formula
and for a sample of a caste, the index of population was not
taken into           consideration.     It is also       alleged that the
Commission has failed to carve out extra-ordinary condition of
backwardness of the said community.
                 Apart from the three lead petitions which we have
referred to above, there are several other writ petitions which
pose more or less similar challenge on more or less similar
grounds in these three writ petitions and we restrain ourselves
from making reference to the said grounds as raised in the
other petitions.
7                The       State   Government     has       filed      affidavit
responding to the challenge posed in the petitions and we
would make reference to one such affidavit filed in Writ
Petition (L) No.4100 of 2018. The said affidavit is filed by
Shivaji Raghunath Daund working as Secretary, GAD dated
16th January 2018. The impugned enactment is justified to
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:18 :::
                                 81                           Marata(J) final.doc
be warranted by extra-ordinary circumstances which are set
out in the affidavit to be :-
     (a)        Gradual deterioration in educational and social
                 backwardness of Marathas
     (b)        Deterioration in income as well as desperation of
                 families to survive,
     (c)        Substantial backlog in services under the State.
     (d)        Increase in the number of suicides as a result of
                form indebtness and shift to manual labour
     (e)        Inability to raise standard of living as a result of
                 adverse conditions.
                 The affidavit highlights the quantifiable data in
relation to the population of Maratha and extensively deal
with the features of the said MSBCC report. It also makes a
reference to the history of the Maratha community and
proceeds to state that the State Government had placed the
summary of the report of the Commission along with its
recommendations, before both the Houses of the legislature
as contemplated under Section 15 of the MSBCC Act 2005.
The affidavit also deals with the contention of the earlier
ESBC Act 2014 and proceeds to state that as per Section
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                 ::: Downloaded on - 28/06/2019 05:25:18 :::
                                  82                             Marata(J) final.doc
18(1) of the impugned Act, on and from the date of coming
into force of the said enactment, the ESBC Act of 2014 and
2014 Ordinance is repealed by the legislature and the
earlier petition No.3151 of 2014 is rendered infructuous and
the interim order in effective. The affidavit also proceeds to
highlight the methodology adopted by the Commission and
the bulky exercise carried out with the assistance of five
agencies and the Commission being assisted by the experts
in analyzing the data i.e. Professor Ambadas Mohite - Senior
Acamedic Consultant, YCMOU, Regional Centre, Amravati,
Dr. Omprakash Jadhav, Assistant Statistics, Dr. Babasaheb
Ambedkar University, Aurangabad and Dr. Sudhir Gavhane,
Aurangabad.             It also makes reference to the information
provided to the Commission by various departments of the
Government including the GAD, Social Justice and Special
Assistance           Department,      Labour,     Agriculture,           School
Education, Higher and Technical Education etc.
                 Detail affidavits in support of Chamber Summons
are also filed by the applicants/newly added respondents.
One such affidavit by Prakash Shankar Bhosale who belong
to Maratha community highlights the history of the Maratha
community.            There are several affidavits filed in support of
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:18 :::
                                  83                          Marata(J) final.doc
the intervention application which highlights the status of
the Maratha community, its historical background and also
the present social status of the community.
8                We have carefully perused the writ petitions,
affidavits, applications for interventions/chamber summons
and supporting affidavits. After hearing the learned counsel
appearing for the respective parties, we broadly capitulate
the points for our consideration and we have proceeded to
deal with the said points under the following major heads :
(I)              Arguments of the parties.
(II)             Conspectus of the matter including the legislative
scheme of the impugned Enactment.
(III)            Whether       the    impugned    Act       of      2018           is
constitutionally invalid on account of lack of legislative
competence on the following sub-heads:-
        (a)     The subsisting interim order passed by the Bombay
                High Court in Sanjeet Shukla vs. State of
                Maharashtra (WP 3151/2014) thereby granting
                stay to a similar enactment and ordinance of the
                State, which is pending for adjudication before this
                Court.
        (b)     The 102nd (Constitution) Amendment, 2018 deprives
                the State legislature of its power to enact a
patil-sachin.
::: Uploaded on - 27/06/2019                 ::: Downloaded on - 28/06/2019 05:25:18 :::
                                         84                             Marata(J) final.doc
                legislation            determining        the        Socially           andDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                Educationally Backward Class and conferring the
                benefits on the said class in exercise of its enabling
                power          under    Article   15(4)     and       16(4)       of     the
                Constitution.
       (C)      The limitation of 50% set out by the Constitution
                bench in Indra Sawhney in form of constitutional
                principle do not permit reservation in excess of 50%.
(IV)             Whether the State has been able to establish the
social and educational backwardness and inadequacy of
representation             of     the        Maratha   community             in     public
employment on the basis of the report of MSBCC under the
Chairmanship of Justice Gaikwad on the basis of quantifiable
and contemporaneous data ?
(V)              Scope of Judicial Review for interference in the
findings, conclusions and recommendation of the MSBCC.
(VI)             Whether the reservation carved out for Maratha
community by the State Government in form of impugned
legislation satisfies the parameters of reasonable classification
under Article 14 of the Constitution ?
(VII)            Whether the ceiling of 50% laid down by the
Hon'ble Apex Court in case of Indra Sawhney vs. Union of
India, is to be taken as a constitutional principle and deviation
thereof violates the basic tenet of equality enshrined in the
Constitution ?
patil-sachin.
::: Uploaded on - 27/06/2019                           ::: Downloaded on - 28/06/2019 05:25:18 :::
                                        85                               Marata(J) final.doc
(VIII)           Whether the State is able to justify existence of
exceptional          circumstances            or    extra-ordinary         situation          to
exceed the permissible limit of 50% within the scope of
guiding principles laid down in Indra Sawhney ?
(IX)             Whether         in     the        backdrop      of     the      findings,
conclusions and recommendations of the MSBCC report,Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

whether the State Government has justified exercise of its
enabling         power         under    Article      15(4)    and      16(4)       of     the
Constitution ?
(X)              Summary of conclusions.
(I) - ARGUMENTS OF RESPECTIVE PARTIES
                 We have extensively heard the respective counsel
appearing for the petitioners and we would make a brief
reference to the submissions advanced by the learned counsel
for the petitioners.
9                We have heard Dr. Sadavarte, learned counsel
appearing for the petitioner in PIL No.175 of 2018. Apart from
relying on the grounds mentioned in the writ petition, Shri
Sadavarte has extensively advanced his submissions before
us opposing the impugned legislation.                                 He invited our
attention to the judgment delivered by the Hon'ble Apex Court
patil-sachin.
::: Uploaded on - 27/06/2019                            ::: Downloaded on - 28/06/2019 05:25:18 :::
                                    86                             Marata(J) final.doc
in Abdul Khader and others vs State of Mysore 3. He
would submit that the very basis of classification based on
caste is the root of all the maladies and Shri Sadavarte would
vociferously argue that after almost 7 decades, after coming
into force of Indian Constitution, the democracy in this
country, is totally based on caste politics and not on the
intellectual leadership. He expresses that Maratha communityDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

has given 12 Chief Ministers to this State and in spite of this, it
is unfortunate that the State of Maharashtra is categorizing
this class as 'backward'.               He would further submit that the
present reservation is attempting to destroy the basic
structure of the Constitution.             Shri Sadavarte has also placed
heavy reliance on the Division Bench judgment in form of an
interim order in the earlier round of litigation when a similar
attempt by the State Government to enact a similar legislation
by providing 16% reservation to Maratha did not find favour
with this Court and an interim stay was granted to the
implementation of the ordinance and the enactment of 2014
which came to be upheld by the Supreme Court. Further, Shri
Sadavarte          would       submit    that   the   Division        Bench        had
considered the arguments in extenso about the special
3 AIR 1953 SCC 355
patil-sachin.
::: Uploaded on - 27/06/2019                      ::: Downloaded on - 28/06/2019 05:25:18 :::
                                      87                          Marata(J) final.doc
circumstances which were sought to be put forth for
classifying Marathas as socially and educationally backward
and he would submit that the Court concluded that prima
facie there was no case at all for classifying Marathas as
socially and educationally backward classes by completely
ignoring the reports made by the National Commission for
backward classes and the Mandal Commission and also JusticeDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Bapat Commission Report. On the issue as to whether prima
facie case has been made out for justifying increase in
percentage of reservations from 52% to 68% in education and
in public employment, according to Shri Sadavarte, the
Division Bench had categorically held that there is a ceiling
limit of 50% on reservations under Article 15(4) and 16(4) and
that is a binding rule and not a mere rule of prudence and this
rule may be relaxed only in extra ordinary situations and for
extra       ordinary           reasons.   However,   the      Division        Bench
concluded that neither the Rane Committee nor the State
Government had placed before it any material to justify the
existence of any exceptional or extra ordinary circumstances
so as to cross the ceiling and the burden which ought to have
been discharged by the State was not discharged by it. On
the other hand, it had categorically held that material on
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:18 :::
                                88                      Marata(J) final.doc
record suggest that Maratha is a politically dominant class and
there is no element of social oppression and/or social
discrimination or atleast social segregation of this community.
No attempt has been made on the part of the State to
establish exceptional circumstances which prompted the State
to exceed the ceiling of reservation by such a wide margin.
Thus, according to Shri Sadavarte, the said order though inDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

the nature of an interim order, still governs the field and when
the Apex Court has refused to intervene, the exercise by the
State to bring a new legislation with the same avowed object
and this time through a fact finding submitted by a new
commission i.e. Justice Gaikwad Commission cannot wipe out
the observations made by the Division Bench. This, according
to him, is no less than a fraud played on the Constitution. He
would vehemently submit that the creation of new class under
Section 2(j) of the SEBC Act 2018 is nothing but a misnomer,
since it contemplate socially and educationally backward class
which is nothing but the Other Backward Class.                          Shri
Sadavarte further submits that the constitution of a new
Commission is an eye-wash. He however, submits that with
the Constitution coming into force and with two National
Commissions and several State Backward Class Commission
patil-sachin.
::: Uploaded on - 27/06/2019           ::: Downloaded on - 28/06/2019 05:25:18 :::
                                 89                          Marata(J) final.doc
being constituted, none of the commissions have identified
Maratha as backward and rather the attempts by the
community to categorize it as backward have failed.                           He
submits that the Commission has misdirected itself by making
wrong reference and it resulted into wrong conclusions. He is
also extremely critical of the findings of the                 Commission
which recorded that Maratha is a backward class and oneDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

instance to cite, he would submit that there is a report on
suicide of farmers but he would categorically submit that
there is data to demonstrate that it is not only the Maratha
farmers who have committed suicide but since it is an
agrarian crisis and Marathas happen to be the cultivators,
resultantly, their number is high. He would also submit that
the calculation of marks by the backward class commission
and allotting 21.5 marks to Maratha community out of 25
marks so as to stake its claim of backwardness is also
misleading. The said analysis according to Shri Sadavarte, is
merely hypothetical.           Apart from the judgment in case of
Balaji, Shri Sadavarte has also placed reliance on the following
judgments :
     1)         1963 Supp. (1) SCR 439/AIR 1963 SC 649 M.R. Balaji
patil-sachin.
::: Uploaded on - 27/06/2019                ::: Downloaded on - 28/06/2019 05:25:18 :::
                                 90                           Marata(J) final.doc
      2)        Order of Bombay High Court - Coram: Mohit Shah, CJ
                and M.S. Sonak, J. dated 14/11/2015 (Writ Petition
                NO.3151/2014)
      3)        Order of Bombay High Court-Coram: Mohit Shah, CJ
                and G.S. Kulkarni., J. dated 07/04/2015
      4)        (2006) 8 SC 212 M. Nagraj & Ors.
      5)        (2018) 10 SC 396 Jarnail Singh & Ors.
      6)        (1972) 1 SCC 660-The State of AP and Ors V/s.U.S.V.
                BalaramDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

      7)        (2005) 1 SCC 394 - E.V. Chinnaiah vs. State of Andhra
                Pradesh
      8)        (1992) Suppl (3) SCC 217-Indra Sawhney & Ors.
      9)        (2017) 10 SCC 706 - Himangni Enterprises Vs.
                Kamaljeet Singh Ahluwalia.
      10)       State of Rajasthan Vs. Ganga Sahay Sharma
      11)       Dr. K.Krishna Murthy & ors Vs. Union of India & Anr
                Writ Petition (Civil) No.356 of 1994.
10               In support of the petitioners in W.P.No.4128/2018,
we have heard learned Senior Counsel Shri Aney. He would
assail the SEBC Act 2018 on the following legal reasons :-
(1)      Absence of legislative competence.
(2)      Impermissible classification
(3)      Violation of basic structure
(4)      Terms of reference and absence of relevant data.
patil-sachin.
::: Uploaded on - 27/06/2019                 ::: Downloaded on - 28/06/2019 05:25:18 :::
                                91                           Marata(J) final.doc
                 Apart from the challenge to the vires of the Act, he
has also mounted a challenge to Sections 2(j), 3(2), 3(4), 5, 9,
10 and 12 of the impugned Act.              As far as the issue of
legislative competence is concerned, Shri Aney would submit
that legislative competency of a State legislature is not
necessarily to be tested only by ascertaining whether the
subject matter of legislation fall within the competence of a
State legislature. He would submit that the subject enactmentDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

is in exercise of an enabling power conferred on the State
under Article 15(4), 15(5) as well as Article 16(4), 16(4A) and
16(4B) of the Constitution. He would further submit that the
102nd Amendment introduced in the Constitution has inserted
Article 338B and Article 342A. By insertion of Article 338B, a
provision is introduced in the Constitution for establishment of
National Commission for socially and educationally backward
classes and the said Commission has received a constitutional
status.         Further, the said amendment is significant since it
inserts Article 342A by which socially and educationally
backward class is introduced in the Constitution. A definition
of socially and educationally backward class is also provided
under Article 366(26C).          Shri Aney would submit that the
Constitution now contains a provision as to who would be
patil-sachin.
::: Uploaded on - 27/06/2019                ::: Downloaded on - 28/06/2019 05:25:18 :::
                                     92                           Marata(J) final.doc
comprising of a "socially or educationally backward class" and
it is only through the mechanism of Section 342A, a person
can be said to be deemed to be belonging to socially and
educationally backward class in relation to a particular State.
He would submit that this SEBC is now placed on par with
Scheduled Caste and Scheduled Tribe and comparison of
Article 341 and 342 with Article 342A would disclose that after
insertion of the said Article in the Constitution with effect fromDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

15th August 2018,               this particular class will receive its
recognition only in the manner set out in the Constitution i.e.
Article 342A.              According to him,        the Constitution had
recognized three classes for the purpose of extending benefits
of reservation i.e. Scheduled Caste, Scheduled Tribe and Other
Backward           Classes     of    Citizens   who      are      socially        and
educationally backward so far as Article 15 is concerned or
who are not adequately represented in service under                                the
State as far as Article 16 is concerned.                   By the impugned
legislation, the State has created a fourth clause SEBC which
is alien to the Constitution and after 102 nd Amendment to the
Constitution, a SEBC would be entitled to claim reservation
only if he travels the path and gains an entry in the manner
set out under Article 342A.              By virtue of the said provision,
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:18 :::
                                      93                                Marata(J) final.doc
according to the learned senior counsel, the State has lost its
legislative competency to enact on the said subject or to
recognize          and         declare    a   person      to     be     socially        and
educationally backward.
                 Shri Aney would submit that social and educational
backwardness is but an aspect of backwardness and must fall
within the OBC classification.                 Thus, according to him, the
State legislature has exceeded its legislative competenceDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

inasmuch as its Constitution does not empower the State
either by virtue of Article 15 or 16 to carve out a separate
class outside the already existing socially and educationally
backward class/Other Backward Class.                           The learned senior
counsel would submit that if the State is of the opinion that
Maratha community is in fact socially, culturally, economically
and educationally backward, then, at the highest, it would be
part of 'OBC' as intrinsically the object of special reservation
to the SEBC as to ameliorate the social and educational
backwardness, which is collectively to be found in the existing
OBC category and therefore, according to him, it was not open
for the legislation to provide for a special reservation by
coining a new terminology known as SEBC and this amounts
to unreasonable classification having no nexus to the object
patil-sachin.
::: Uploaded on - 27/06/2019                           ::: Downloaded on - 28/06/2019 05:25:18 :::
                                94                       Marata(J) final.doc
sought to be achieved i.e. delivering benefits contemplated
under Article 15(4) and 16(4).      Apart from this ground, Shri
Aney would press into service the most important facet of the
matter i.e. by making a provision of 16% reservation for
Maratha community, the reservation in State of Maharashtra
has reached a mark as high as 68% and this is exceeding 50%
as mandated by various judgments of the Apex Court and to
that extent, the said reservation is       unconstitutional.               HeDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

would submit that right from the judgment of the Hon'ble
Apex Court in case of Balaji (supra) till the latest judgment in
relation to Jats in Rajasthan and Gujjars in Gujarat, the ceiling
of 50% continues to exist and for a span of approximately 56
years, the position of law is settled and to dilute it, requires a
strenuous effort and unless the small window provided in the
judgment of Indra Sawhney i.e. extra ordinary situation and
exceptional circumstances is satisfied, the enactment of the
State is liable to be struck down as violating the mandate laid
down by the Hon'ble Apex Court.        He would further submit
that it is axiomatic that the State with an intention to extend
the benefits to Maratha community has enacted a legislation
by captioning the said category as socially and educationally
backward class, but leaving the class open only for one
patil-sachin.
::: Uploaded on - 27/06/2019            ::: Downloaded on - 28/06/2019 05:25:18 :::
                                     95                            Marata(J) final.doc
community i.e. Maratha and this is nothing but practicing
inequality.         Shri Aney would submit that the basic structure of
the Constitution, has, as its key stone the equality principle as
enshrined in Article 14 and polity contemplated in the
Constitution for the Indian Nation is a classless, casteless
equal society and to achieve this objective, the Constitution
has abolished caste system and treats all religion equally and
all these aspects are very well picturised in the preambleDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

itself.     The learned senior counsel would claim that the said
policy of reservation exclusively to Maratha community in
excess of the ceiling limit prescribed by the Apex Court is
anathema to the Constitution.                 He would further submit that
the impugned act is an assault on the equality principle by
attempting to stratify the society and by creating a new class
of SEBC, it has destroyed the attempt of the Constitution
makers to create a nation which he has described in Tagore's
immortal words "Where the world has not been broken into
fragments by narrow domestic walls".                  He would faintly refer
to the report of the Commission and the terms of reference
and       absence         of   quantifiable    data   though        he     candidly
submitted that the said issue would be in great depth dealt
with by the learned senior counsel Shri Sancheti.                         He would
patil-sachin.
::: Uploaded on - 27/06/2019                      ::: Downloaded on - 28/06/2019 05:25:18 :::
                                     96                          Marata(J) final.doc
place reliance in case of State of Andhra Pradesh Vs.
U.S.V. Balram4, where it is held that the proper approach
should be to see whether relevant data and material referred
to in the report of the Commission justify its conclusions. As
far as the individual provisions are concerned, the learned
senior counsel has mounted his attack on Section 4 of the
impugned Act being violative of Articles 13, 32, 226 and 227.
Further,        according      to   the   learned   senior       counsel,         theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

contradictory provisions of the impugned Act are evidenced
from plain reading of Sections, 2, 3 and 5 on one hand, for the
purpose of providing reservation the legislature seeks to
extend the benefits available to SC/ST and OBC vis-a-vis the
creamy layer distinction. However, for the purpose of section
5, the legislature seeks to hold SEBC Maratha community as a
separate and distinct from OBC.                 Thus, according to the
learned counsel, the State legislature has chosen to approbate
and reprobate by framing provisions to only selectively
benefits the Maratha community. He would also further assert
that Section 2(j) which defines the term 'SEBC' is also violating
the essence of Article 14 as the legislature is attempting to
create a class of Marathas within the already existing class of
4 1972 (1) scc 660
patil-sachin.
::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:18 :::
                                     97                                Marata(J) final.doc
OBC and has sought to bestow benefits upon this newly
created class, over and above the benefits already conferred
on the OBC and by artificially even creating a class, the
legislature           has      further     brought        down           number             of
seats/educational              opportunities     available          to      the      open
category.          The provisions of Section 5 of the impugned
enactment is canvassed as a colourable exercise of power as
it indirectly increases the maximum cap of reservation and itDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

is settled position of law that what cannot be done directly
cannot be done indirectly. Shri Aney has placed on record the
judgment          delivered      by      the   High     Court       of    Gujarat           at
Ahmedabad in Public Interest Litigation No.108 of 2016 along
with connected matters challenging the Gujarat Ordinance
No.1 of 2016 providing for reservation of seats in educational
institutions in the State and of appointments of post in
services under the State in favour of economically weaker
sections of unreserved categories.                        He has also placed
reliance on a Division Bench Judgment of High Court of
Judicature of Rajasthan at Jodhpur in Captain Gurvinder
Singh Vs. State of Rajasthan (Criminal Writ Petition
No.1645 of 2016) where the Rajasthan High Court dealt with a
challenge to a notification dated 16 th October 2015 issued by
patil-sachin.
::: Uploaded on - 27/06/2019                          ::: Downloaded on - 28/06/2019 05:25:18 :::
                                      98                          Marata(J) final.doc
the State and the Rajasthan Special Backward Classes
(Reservation of Seats in Educational Institutions in the State
and of Appointments and Posts in service under the State) Act
of 2015). By the said Act of 2015, five castes, including Gujar
caste, earlier falling in the category of OBC and getting benefit
of reservation have been brought in the category of special
backward class to provide 5% reservation exceeding the
ceiling of 50%.                The Division Bench of the Rajasthan HighDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Court dealt with the report of the State Backward Class
Commission and recorded perversity and inadequacy in the
report and concluded that the extra ordinary circumstances
enumerated to make out an exceptional case did not exist and
the report was not based on quantifiable data.                       Resultantly,
the report of the Commission and the Act of 2015 were struck
down.
                 The learned senior counsel would thus urge this
Court to deal with the situation sternly and submit that the
Constitution makers surely did not visioned the country where
merit would take a back seat. He would submit that the State
legislation has hurt the constitutional fabric by creating stratas
and if it was so desirous of bringing a new class apart from the
caste and class, held entitled for reservation in Part-III of the
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:18 :::
                                       99                          Marata(J) final.doc
Constitution           by       inserting   a   new   amendment              in     the
Constitution.                  The learned Senior counsel in all fairness,
would submit that he personally has no quarrel that the
Maratha community requires protection. However, protection
cannot be claimed by way of a right, as reservation according
to him, is not a privilege and the privilege or concession can
only confined within the limits set out by the Constitution.                         He
however, submits that there is no distinction drawn by theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Commission as to what should be the reservation for
employment and what would be the reservation                                 for the
purposes of education. No empirical data is produced so as to
justify the said reservation and in this backdrop of the facts,
the learned senior counsel would pose a question as to
whether the findings of the Commission are germane and
based on these findings, if the State has proceeded and
enacted a legislation which violates the concept of equality
enshrined in the Constitution, can it be sustained ?
11               The learned senior counsel Shri Datar representing
the petitioner in Writ Petition No.4100 of 2019 also assails the
impugned enactment on the ground of lack of legislative
competence. He would elaborate that after the verdict of the
patil-sachin.
::: Uploaded on - 27/06/2019                      ::: Downloaded on - 28/06/2019 05:25:18 :::
                                 100                          Marata(J) final.doc
Constitution Bench judgment in Indra Sawhney vs. Union
of India (supra) which is subsequently followed in a series of
judgments, the 50% ceiling limit of reservation can be crossed
only by the Parliament in exercise of its constituent power
under Article 368 by amending the Constitution itself.                  To cite
an example, he would submit that the constituent power was
invoked and Article 16(4B) came to be inserted in the
Constitution which enabled the 50% ceiling limit to be crossedDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

for     the      Scheduled     Caste/Scheduled     Tribe      category          in
implementing the carry-forward rule and subsequently this
amendment was upheld in case of M. Nagaraj Vs. Union of
India5.         Shri Datar would heavily rely on the observations of
the Hon'ble Apex Court in Nagaraj (supra) where it has been
held that it is not competent for the State to obliterate the
constitutional requirement of ceiling limit of 50% and in case if
it is breached, the structure of equality of opportunity in
Article 16 would collapse.            According to Shri Datar, this
judgment is further affirmed by the Apex Court in case of
Jarnail Singh v/s Lachhmi Narain Gupta 6. The learned
counsel would also rely upon the speech of Dr. B.R. Ambedkar
5   2006 (8) SCC 212.
6 2018(10) SCC 396
patil-sachin.
::: Uploaded on - 27/06/2019                ::: Downloaded on - 28/06/2019 05:25:18 :::
                                 101                             Marata(J) final.doc
in the constituent assembly where he had categorically voiced
that reservation should be confined to a minority seat and the
words of the founding fathers of the Constitution were relied
upon by the Constitution Bench in Indra Sawhney (supra).
He      further       submits   that   the   extra     ordinary         situation
contemplated by Indra Sawhney are confined only to "far-flung
and remote areas where a particular class is out of main
stream of national life". He emphatically submits that no suchDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

situation is demonstrated by the State in enacting the said
legislation where it has exceeded the limit of 50% and that
too, by margin of 18%. He would also reiterate the arguments
advanced by the learned senior counsel Shri Aney as to the
effect of the 102nd Amendment to the Constitution whereby
Article 342A has been inserted and the term "socially and
educationally backward classes" finds a meaning assigned in
the Constitution itself under Article 366 (26C) to mean such
backward classes which are so deemed under Article 342A
and according to him, the backward classes can now only be
notified by the President and since this amendment has come
into effect from 15th August 2018, declaration of any
caste/class as SEBC without the presidential notification
according to the learned counsel, is unconstitutional.
patil-sachin.
::: Uploaded on - 27/06/2019                   ::: Downloaded on - 28/06/2019 05:25:18 :::
                                      102                           Marata(J) final.doc
                 Shri Datar would submit that no doubt there is a
presumption of constitutionality in favour of a statute.
However, this presumption is not available if it can be shown
that the law or the surrounding circumstances on which the
classification is based, did not warrant such a classification
and      the      statute      has   indulged   itself    into     an      invidious
discrimination amongst citizens similarly situated. Shri Datar
would also heavily rely on the earlier round of litigationDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

instituted by the very same petitioner where the Ordinance
was stayed by the High Court after a full fledged hearing and
though it was a judgment delivered at interim stage, it
contained detailed reasons and findings.                    He would further
submit that though the observations are prima facie and
tentative. It was not open to the State to pass an enactment
without removing               the basis of the judgment.                He would
emphasize that it is settled legal position of law that the
legislature cannot overrule or reverse any judgment or order
made in exercise of judicial power without removing the basis
of the decision, and according to him, by now the position of
law is no more res integra that legislative overruling of a
decision        is    constitutionally     impermissible.           In    order       to
substantiate his argument, he would place reliance on a
patil-sachin.
::: Uploaded on - 27/06/2019                      ::: Downloaded on - 28/06/2019 05:25:18 :::
                                    103                             Marata(J) final.doc
Constitution Bench judgment of the Apex Court in case of
Cauvery Water Disputes Tribunal7 and submits that this
prohibition even applies to an interim order.                     As far as the
report of the backward class commission is concerned, Shri
Datar would submit that the identification of backward class
can only be done based on objective social and other criteria
and the Hon'ble Apex Court has approved of 11 criteria
formulated by the Mandal Commission for identifying socialDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

and educational backwardness.                  To the contrary, he would
submit that the Gaikwad Commission did not formulate any
comprehensive              and   objective    criteria   to     determine           the
backward stages of Maratha community, nor did it notify the
criteria prior to collection of data which would have enabled
effective participation by the citizens in the inquiry. He would
thus criticize the methodology adopted by the Commission
and submit that it suffered the back-leash of "fair and
adequate individuals". It is                 further submitted            that the
Commission did not carry out comparative analysis and unlike
Scheduled Caste/Scheduled Tribe reservation, 'backwardness"
being a relative term, must be judged by the general level of
advancement of the entire population and if the Marathas are
7 1993 (Supp) 1 SCC (II)
patil-sachin.
::: Uploaded on - 27/06/2019                      ::: Downloaded on - 28/06/2019 05:25:18 :::
                                    104                          Marata(J) final.doc
not backward from 1980 till 2012, they cannot suddenly
become backward on the basis of a random study based on a
minimal sample.                Lastly, he would urge that there is no
material         to    support    inadequate   representation            for     the
Marathas and this could have been established only by
producing quantifiable data. He also submits that inadequacy
of representation cannot be a basis for treating Marathas as
backward and he would also emphasize on the aspect ofDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

"efficiency in administration" and submit that requirement of
Article 335 has been held to be equally applicable to backward
class.      He would request us to derive the analogy from the
verdict of Hon'ble Apex Court in case of Ram Singh vs.
Union of India,8 2015(4) SCC 697, where the Apex Court
struck down reservation made for the Jat community and he
request us to apply the same parameters laid down by the
Highest Court for Maratha community. Conclusively, he would
urge that the impugned enactment is a legislation meant for a
specific community or class and it is nothing but a class
legislation which is not permissible. Even for the sake of
argument, if it is accepted that Maratha Community is socially
and educationally backward, still, according to the learned
8 2015(4) SCC 697
patil-sachin.
::: Uploaded on - 27/06/2019                   ::: Downloaded on - 28/06/2019 05:25:18 :::
                                105                            Marata(J) final.doc
counsel, there is no justification for creating a separate class
exclusively means for this community and this according to
him, has resulted in discrimination as against Other Backward
Class and at the most, they will have to share the same
compartment as the Other Backward Classes i.e. into 27 %
category and mandated by Indra Sawhney (supra).
12               The learned counsel Shri Talekar appearing for theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

petitioner in Writ Petition No.3846 of 2019 has focussed his
argument on the 102nd (Constitution) Amendment.                         He has
placed on record the report of the Select Committee on the
123rd Amendment Bill 2017 and also the Rajya Sabha and Lok
Sabha debates. Based on the said material, he submits that
the said amendment introduced a National Commission of
Backward Classes as a permanent commission and confers
constitutional status on it.         He would invite our attention to
Article 338B and specifically sub-Article (5) which cast a duty
on the commission to investigate and monitor all matters
relating to safeguards provided for socially and educationally
backward classes under the Constitution or under any other
law for the time being in force or under any order of the
Government and to evaluate the working of such safeguards.
patil-sachin.
::: Uploaded on - 27/06/2019                 ::: Downloaded on - 28/06/2019 05:25:18 :::
                                    106                             Marata(J) final.doc
He would place heavy reliance on sub-clause (7) of the newly
inserted Article 338-B            and submit that where the National
Commission has conducted an inquiry and investigation in
relation to any matter with which any State Government is
concerned, a copy of such report is to be forwarded to the
State Government which shall cause it to be lead before the
legislature         of    the   State    along   with     the      Memorandum
explaining the action taken or proposed to be taken on theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

recommendation relating to the State and the reasons for non-
acceptance, if any, of such recommendation. He would also
emphasize that by virtue of sub-article (9), every State
Government is duty bound to consult the Commission on all
major policy matters affecting the socially and educationally
backward classes. In the light of this provision introduced with
effect from 15th August 2018, Shri Talekar would submit that it
was not permissible for the State Legislature to confer the
status of SEBC on Maratha in absence of consultation with the
National Commission for backward class.                    According to him,
insertion of Article 342-A into the Constitution has changed
the entire spectrum and he would strenuously argue that the
power to specify the social and educationally backward
classes in relation to the State now vests only in the President
patil-sachin.
::: Uploaded on - 27/06/2019                      ::: Downloaded on - 28/06/2019 05:25:18 :::
                                107                           Marata(J) final.doc
who may with respect to any State or Union territory, and if it
is the State, in consultation with the Governor, by public
notification specify such class and by virtue of sub-article (2),
it is only the Parliament, who may by law include or exclude
from the list of social and educationally backward classes. His
submission is therefore,          that without by-passing the said
procedure, it is not competent for any State to enlist any class
as SEBC and the present enactment completely ignores ArticleDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

342A. The consultation with the National Commission is also
by-passed and according to him, the inclusion/exclusion of a
particular caste is a major policy decision and in terms of
Constitution of the National Commission for backward classes,
under Article 338B, it was imperative for the State to consult
the Commission.
                 As per Shri Talekar, the power is now conferred only
on the President to make a list of SEBC and he would invite
our attention to the Central list of OBCs prepared in the year
1992 prior to which only one State list of OBCs in Maharashtra
was in existence. As per him, Article 342A is to be read to to
lead to the only possible inference that in case of State list,
only the President is empowered to specify the SEBC in the
said list subsequent to 15th August 2018 and it is only the
patil-sachin.
::: Uploaded on - 27/06/2019                ::: Downloaded on - 28/06/2019 05:25:18 :::
                                108                            Marata(J) final.doc
President who is empowered to include and exclude any class
from the said list whereas as far as central list is concerned,
according to Shri Talekar, it is the President who is empowered
to specify by public notification, those persons who shall be
for the purposes of constitution deemed to be "socially and
educationally backward class" in relation to that State but in
case of such a list, it is only the Parliament which is
empowered to include or exclude and nobody else canDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

undertake that exercise.             Shri Talekar has relied upon the
Debates and the amendments which were suggested to assist
us in interpreting Article 342A in the aforesaid manner.                        He
would emphatically argue that on coming into force of Article
342A, the power of the State Government stands eclipsed and
it was not open for the State backward Class Commission to
examine into backwardness of Maratha community and for
this very reason, the enactment which is based on the said
report, enacted by the State legislature also cannot survive.
As far as the terminology "mean" introduced in Article
366(26C), he could place reliance on the judgment of Punjab
Land Development and reclamation corporation Ltd,
Chandigarh Vs. Presiding Officer, Labour Court ,9 which
9 1993 SCC 682
patil-sachin.
::: Uploaded on - 27/06/2019                 ::: Downloaded on - 28/06/2019 05:25:19 :::
                                          109                             Marata(J) final.doc
throws light on the interpretation of the term "mean".                                    He
would also place reliance on the judgment of the Apex Court in
case E.V. Chinnaiah vs. State of Andhra Pradesh 10. Shri
Talekar         has    also      placed        on   record   the      compilation           of
documents evidencing the consultation with the National
Commission of Scheduled Tribes, whenever a Tribe is included
or excluded from the Scheduled Tribe order and with the
assistance of the said documents, he submits that it isDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

mandatory to have consultation with the National Commission
for backward classes which is now conferred a constitutional
status by the recent amendment.
13               Apart from this, Shri Talekar has placed on record
the     reports        of      Justice    Khatri     Committee,         Justice       Bapat
Committee and Rane Committee.                           The substratum of his
argument based on this report is that the Khatri Committee
and Bapat Committee did not find favour with Marathas as a
backward class and the Rane Committee Report is subject
matter of litigation before this Court. He would invite our
attention to the terms of reference of the Commission and
also to the questionnaire that was circulated                                     seeking
10 2005(1) SCC 394
patil-sachin.
::: Uploaded on - 27/06/2019                            ::: Downloaded on - 28/06/2019 05:25:19 :::
                                  110                              Marata(J) final.doc
response from the subject respondents and he would make a
statement that the members of the Commission have
recorded dissenting opinion.             According to him, the entire
exercise carried out by the State Government through the
Commission was to satisfy the long pending of Maratha
Community to be treated as 'backward' and it did not stop
here, and the State Government conferred largesse on the
said community in an undeserving manner by granting themDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

reservation to the exclusion of OBCs, unmindful of the fact
that the permissible limit of reservation is being exceeded. On
the contrary, he submits that he represents the petitioner
who belong to Muslim community which was held backward by
Sacchar Committee and also by a subsequent committee
under the Chairmanship of Mohd-Ul-Fitr.                 An Ordinance was
promulgated by the Governor in the year 2014 granting 5%
reservation to the Muslim community but this ordinance was
never converted into an enactment and was permitted to
lapse.          This according to him, reflects the approach of the
State       Government         towards   the   Muslims        -     a     minority
community.             Shri Talekar would, therefore, seek relief of
striking down the enactment and for conferring reservation to
the Muslim community in terms of the Ordinance which had lapsed.
patil-sachin.
::: Uploaded on - 27/06/2019                   ::: Downloaded on - 28/06/2019 05:25:19 :::
                                   111                         Marata(J) final.doc
14                We have also extensively heard the learned senior
counsel Shri Pradeep Sancheti representing the petitioner in
Writ Petition No.4100 of 2018.           Shri Sancheti canvassed his
argument to a limited issue i.e. Maharashtra State Backward
Class Commission (Gaikwad Commission Report). He opened
his argument by inviting our attention to the four earlier
reports i.e. two National Commission Reports and two State
Commission Reports and on the basis of the said reports, heDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

would question the very propriety of the State Government to
refer the claim of Maratha community to another State
backward Class Commission. He had produced before us the
comparative analysis of the said reports and highlighted the
discrepancies in the present report specifically on the
parameters of the sample, size and methodology adopted by
the present Commission. Shri Sancheti would submit that for
grant of reservation, three pre-requisites are to be examined
and focused upon i.e. (i) backwardness (ii) inadequate
representation and (iii) efficiency in administration and unless
and until all these three pre-requisites are satisfied, there is no
scope for any reservation. Shri Sancheti has invited attention
to the terms of reference of the Commission which include to
define          'extra-ordinary   circumstances'     or     'extra-ordinary
patil-sachin.
::: Uploaded on - 27/06/2019                 ::: Downloaded on - 28/06/2019 05:25:19 :::
                                       112                           Marata(J) final.doc
situations'. He would further submit that the data base for the
MSEB's report and the sample size of 43,692 individuals
amounts to less than 0.2% of the total population of the State
of approximately 11.5 crore. This data base is minor in size
and according to Shri Sancheti, would not lead to a
quantifiable          data     for    the   purposes    of    determining            the
backwardness. More soever, he submits that more than 68%
of persons surveyed are Maratha. The sample size, accordingDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

to him, is also inadequate for the reason that survey was
based mostly on rural population and only 950 urban families
(2.6% of the sample) were surveyed. He is also critical of the
fact      that      1,95,000         representations    were       hypothetically
considered as if 10 lakh people were surveyed and this is
complete eyewash to suggest that the survey included 10 lakh
people.         He submits that when on earlier occasion, Mandal
Commission had considered Maratha as 'forward', and the
Bapat Commission had deemed it not fit to include Marathas
in OBC, there is no sufficient material brought on record to
justify categorization of Maratha as SEBC which is nothing but
Other Backward Class. There is no explanation in the report of
the Committee as to why the record and data earlier collected
by the Commission is not referred to or what was a
patil-sachin.
::: Uploaded on - 27/06/2019                       ::: Downloaded on - 28/06/2019 05:25:19 :::
                                    113                            Marata(J) final.doc
distinguishing           and    distinct   material   available         with      this
Commission.
                 Mr. Sancheti is also highly critical of the means of
collection of data as the report proceeds to state that five
organizations were entrusted the task of conducting the
survey. On what basis the organizations have been selected
and      whether         they   are   independent      and      not      politically
connected is also not established. These five agencies wereDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

nominated by the Government and surprisingly one Mr.
Balasaheb Sarate from Aurangabad who is an intervenor
supporting the Maratha reservation and who was in the
forefront demanding such a reservation is one of the agencies
who have been selected by the Government and with this
factual background, Mr. Sancheti would pose a question about
the impartiality and fairness of the survey being conducted by
these agencies. Further, the Commission also did not follow
proper procedure for publication invited suggestions before
framing the parameters and those parameters framed by the
MSBCC are not in synchronization with the parameters already
formulated by Mandal Commission.                  On account of the fact
that the sample size chosen is very small there is likelihood of
huge variation according to Shri Sancheti and unless the
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:19 :::
                                  114                            Marata(J) final.doc
sample drawn covers the entire State and is of a reliable size,
according to the learned counsel, it is bound to show highly
variable statistics. According to Shri Sancheti, statistics is an
unruly horse and unless controlled and guided with tight
leash.          He further submits that under the guise of new
commission, an attempt is to circumvent the interim orders
passed by this Court, knowing very well that the methodology
adopted by Rane Committee and its finding did not find favourDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

in the High Court. Shri Sancheti has also tendered before us
the comparative analysis of the marking system adopted by
the Bapat Commission, Mandal Commission and he also
invited our attention to the various parameters in social
backwardness, economic backwardness as well as educational
backwardness which has resulted into no quantifiable data.
Backwardness, per se, according to him, is not a ground for
reservation but a quantifiable data collected and analyzed by
objective         methodology,    can   only   lead       to    a     claim      for
reservation.           Further, according to him, the second most
criteria and the tenet of granting reservation i.e. inadequate
representation and the efficiency of administration (merit) has
not been considered and analyzed at all by the Commission.
Shri Sancheti is also not ready to accept the population of
patil-sachin.
::: Uploaded on - 27/06/2019                   ::: Downloaded on - 28/06/2019 05:25:19 :::
                                115                          Marata(J) final.doc
Maratha derived by the Commission to be 30%, which
according to him, is a completely flawed one. Mathematically,
he submits that if the Scheduled Caste population                     is 13%,
Scheduled Tribe population is 11%, population of OBC as per
Mandal Commission is 52% and if Maratha is added to be
30%, it would take the total population to 116%                        to the
exclusion of the other communities like Jains, Muslims,
Christians, Sikhs etc. The Maratha population estimate of 30%Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

of the Commission, according to Shri Sancheti, is completely
arbitrary, unsubstantial and unreliable.           The rural Maratha
population is estimated by the report to be 26.6% and the
report proceeds on the basis that Marathas are largely found
in rural areas, yet the report concludes Maratha population as
30% even without surveying the urban population. Thus, the
estimated population is highly hypothetical according to Shri
Sancheti.           The Commission has completely excluded the
minority classes of citizens whose chunk of population is 10%
and the other open classes which are not included in any
reservation category which is approximately 5%.
15               Another aspect which Shri Sancheti has invited our
attention, which according to him, of great relevance is the
patil-sachin.
::: Uploaded on - 27/06/2019               ::: Downloaded on - 28/06/2019 05:25:19 :::
                                  116                         Marata(J) final.doc
dominance of Maratha community. He has placed reliance on
the affidavits which would demonstrate that most of the Chief
Ministers of this State belong to Maratha community who
claims to be a backward community.             Further, the affidavits
placed on record in relation to the Chairman of Sugar Co-
operatives, Management of Medical Colleges, Chairman of
District Central Co-operative Bank, agricultural marketing
boards, demonstrate that Maratha community was much partDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

of the main stream and this aspect is completely overlooked
by the commission.             This was however, noted by the High
Court in its interim order dated 11th November 2014 and was
one of the predominant factor for arriving at a conclusion
which was prima facie recorded by the Court that Maratha is
not a backward community.              Apart from this, the learned
counsel submits that the earlier commissions i.e. Mandal
Commission, Khatri Commission and Bapat Commission has
found Maratha distinct from Kunbi caste and the findings
recorded by these Commissions that these two castes is one
and the same is an absurd finding.               In any contingency,
according to Shri Sancheti, no case for extra ordinary situation
has been made out by the State and merely because there
were agitations, can be no ground for creation of a separate
patil-sachin.
::: Uploaded on - 27/06/2019                ::: Downloaded on - 28/06/2019 05:25:19 :::
                                117                          Marata(J) final.doc
class.          Based on the fallacious percentage of Maratha
population, the MSBCC has suggested for 12 and 13%
reservation to Marathas but the State Government adopted
16% reservation without any logic or basis. He submits that
undue haste has been shown and after the report was signed
on 13th November 2018, it was placed before the Cabinet on
18th November 2018 and 29th November 2018, the bill was
passed by legislative assembly which was only in form ofDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

summary since the huge bulk of annexures were not even
printed or considered by the officials of the State and the
impugned enactment came into force on 30th November 2018.
Another ground on which the reporters subjected to criticism
by Shri Sancheti is that the Commission relied on experts for
the analysis and inputs who appear to be from Maratha
community and this included Professor Ambadas Mohite, Dr.
Omprakash Jadhav, Dr. Sudhir Gavhane.              It also relied upon
three other experts who are from Maratha community and two
of the agencies chosen for collecting data are headed by
Marathas. Further, the allegation is also levelled that faulty
method of           awarding point was applied for Marathas in the
survey and the MSBCC leased its premise on data analysis
which is a mathematical impossibility and if this data analysis
patil-sachin.
::: Uploaded on - 27/06/2019               ::: Downloaded on - 28/06/2019 05:25:19 :::
                                    118                              Marata(J) final.doc
is taken for any consideration, then all the communities in
Maharashtra would qualify as backward, since as per the
MSBCC criteria to be categorized as 12.5 marks and other
open category has scored 19.5 marks in the same study as
per the same criteria and in fact, they are also then entitled to
be categorized as SEBC. Shri Sancheti would submit that it is
evident that there is no case at all made out for backwardness
in education or inadequate representation in employment andDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

the quantifiable data collected by the Commission is neither
sufficient nor credible to consider the case of backwardness of
Marathas and no extra-ordinary situation/circumstances are
established to justify separate 16% reservation by creating a
separate class by exceeding 50% limit only on the premise
that there would be unrest amongst OBC who are enjoying
reservation for last three decades or more.                              For these
aforesaid          submissions,         Shri   Sancheti        would      pray        for
quashment of the impugned Act.
16               We      have    also     heard   the     weighty        arguments
advanced by the learned senior counsel Shri. V.A. Thorat
representing           the     State    Government.       In    his     articulately
formulated arguments he invited our attention to the positive
patil-sachin.
::: Uploaded on - 27/06/2019                       ::: Downloaded on - 28/06/2019 05:25:19 :::
                                    119                            Marata(J) final.doc
concept of reservation which is a facet of affirmative action
adopted by the Indian constitution. According to him it is an
obligation cast on every State to safeguard the interest of
deprived community, classes of citizen in order to achieve the
object of equality. He has painstakingly invited us through the
various provisions contained in the Indian constitution with a
special emphasis on its preamble. According to the learned
senior counsel the aim of any civilized society should be toDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

secure dignity of every individual and according to him this is
not      possible        without   affording   equality      of     status       and
opportunity. Shri Thorat would submit that the dignity of an
individual is dented in direct proportion to his deprivation of
the equal access to social means and when equal opportunity
to grow is denied, the democratic foundation is shaken. He
has invited our attention to the highlights of the said
enactment in form of definition of "socially and educationally
backward class" defined in Section 2(G). He would further
submit that, Section 4(1)(a) & (b) provides for reservation of
seats           for   admission     in   educational       institutions          and
appointments in public services to the extent of 16% &
Section 4(2) applies principle of Creamy Layer, thereby
ensuring that the reservation would be available only to those
patil-sachin.
::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:19 :::
                                120                        Marata(J) final.doc
persons who are below the creamy layer. According to him,
Section 7 of the enactment is inconsonance with the
provisions of Article 16(4A) & 16(4B), the validity of which has
been affirmed by the Hon'ble Apex Court in case of Nagaraj
Vs. Union of India. He highlighted that the said enactment
do no provide any political reservation. He has also invited our
attention to the Bill accompanying the said enactment.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

17               Learned counsel has dealt with the arguments on
behalf of the petitioner assailing the constitutional validity of
the impugned enactment, and in his distinctive style he has
dealt by those arguments one by one. Learned counsel would
submit that, the contention of petitioners that reservation
beyond 50% is impermissible in view of Indra Sawhney (supra)
and the judgment in case of Nagraj (supra) and his compelling
argument is that the petitioners have completely misread,
misinterpreted and misapplied the said judgments. Shri.
Thorat would assert that neither article 15 or 16 provides for
any cap on the percentage of reservation, leave aside the cap
of 50% and in fact article 15(4) and 16(4) are mere enabling
provisions under which the State is under obligation as welfare
State to have an affirmative action in respect of upliftment of
patil-sachin.
::: Uploaded on - 27/06/2019             ::: Downloaded on - 28/06/2019 05:25:19 :::
                                121                      Marata(J) final.doc
backward classes of citizen and to take possible measures for
their advancement. According to the learned senior counsel
after a long emerging debate by this time the position of law
is settled that Article 15(4) and 16(4) are not exceptions to
article 15(1) and article 16 (1) respectively, but they are
enabling provisions. He would placed reliance on the judgment
delivered by Justice Jeevan Reddy (majority) in the case of
Indra Sawhney and the judgment of P.B. Sawant J. and S.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Ratanvel Pandian J. (concurring). He would invite our attention
to the passages of judgment in Indra Sawhney from the
majority view and specifically paragraph 713 where reference
is made to the seven judges judgment in case of State of
Kerala Vs. N.M. Thomas11. He rest his arguments on
Paragraph 810 of the said judgment where it is categorically
expressed that "while 50% shall be the rule, it is necessary
not to put out of consideration certain extraordinary situations
inherent in the great diversity of this county and the people. It
might happen that in far-flung and remote areas the
population inhabiting those areas might, on account of there
being out of main stream of national life and in view of
condition peculiar to and characteristical to them, need to be
11 (1976) 2 SCC 310
patil-sachin.
::: Uploaded on - 27/06/2019           ::: Downloaded on - 28/06/2019 05:25:19 :::
                                122                            Marata(J) final.doc
treated in a different way, some relaxation in the strict rule
may become imperative. In doing so, extreme caution is to be
exercised and special case made out." Relying on the said
connote Shri. Thorat would submit that reference to the far-
flung area is merely illustrative and not conclusive. He would
also invite our attention to the concurring judgment, which
resonate the majority view. He placed reliance on the
following judgments to support his submission that limit ofDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

reservation up to 50% is not conclusive and static but flexible
and depends on the facts and circumstances of each case and
further depend on the compelling reasons of backwardness
and inadequacy of representation to the weaker section.
Those judgments are as follows:-
         i)      K.C. Vasantkumar Vs. The State of Karnataka
                 (1985) Supp. SCC 714.
         ii)     State of Kerala Vs. N.M. Thomas (1976) 2 SCC 310.
         iii)    M. Nagraj Vs. Union of India (2006) 8 SCC 212.
         iv)     Ashok Kumar Thakur Vs. Union of India (
                 2008) 6  SCC Page 1.
         v)      E.V. Chinnaiah Vs. The State of Andhra Pradesh
                 (2005) 1 SCC 394.
         vi)     Jarnailsingh & ors. Vs. Lachhmi Narain Gupta (2018)
                 10 SC 396.
         vii)    S.V Joshi Vs. The State of Karnataka (2012) 7 SCC
                 Page 41.
patil-sachin.
::: Uploaded on - 27/06/2019                 ::: Downloaded on - 28/06/2019 05:25:19 :::
                                       123                                Marata(J) final.doc
18               Learned counsel Shri. Thorat in his eloquent style
has analyzed the nine Judges Constitution bench judgment in
Indra Sawhney (Supra) which according to him undisputedly
leads to the conclusion               that there is no constitutional bar to
the reservation exceeding more than 50%. According to him,
the judgment if read in its correct perspective and in
benevolence of advancing the cause under Article 15 and 16Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

by the State, does not provide any fetter on the State's power
to exceed reservation more than 50% in a deserving case. A
caution, according to the learned counsel, is only of providing
valid grounds in order to justify reservation in excess of 50%.
He would emphatically submit that, before passing the
impugned enactment prescribing 16% reservation for Maratha
community            by        categorizing   it   as      SEBC,       all     necessary
safeguards have been taken into consideration and the State
has justified the said enactment by bringing on record the
exceptional and extraordinary circumstances necessitating the
reservation in excess of 50%. He also rebutted the contention
of other side that the impugned legislation is politically
motivated and he would submit that, it is not open to attribute
motives to the legislature.
patil-sachin.
::: Uploaded on - 27/06/2019                            ::: Downloaded on - 28/06/2019 05:25:19 :::
                                124                        Marata(J) final.doc
19               Learned counsel also dealt with the argument of
legislative competency advanced by Shri. Datar learned senior
counsel and Shri. Talekar specifically in the backdrop of Article
342A being introduced by the 102 nd Amendment which was
brought into force on 15 th August 2018. He would reason that
the argument that after the amendment now only the
parliament and/or the President can specify socially and
educationally backward classes is a misconception. He wouldDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

invite our attention to the statement of objects and reasons
accompanying the 123rd Amendment Bill 2017 which proposed
to create a National Commission for backward classes with the
constitutional status at par with the National commission for
Scheduled Caste and National Commission for Scheduled
Tribes. Learned counsel would submit that historically there
was a central list of other backward classes published by the
Ministry of Welfare New Delhi dated 10 th September 1993,
which came to be amended from time to time and this central
list relates to the reservation of 27% in civil posts and services
under the Government of India in favour of other backward
classes. In the light of this factual scenario learned counsel
would submit that since there were two lists in existence, the
State's power to identify the backward classes within its State
patil-sachin.
::: Uploaded on - 27/06/2019             ::: Downloaded on - 28/06/2019 05:25:19 :::
                                           125                               Marata(J) final.doc
is not curtailed by the amendment and there is no bar on the
power of the State to legislate providing reservation to the
identified backward classes.                     He would make a reference to
the report of Select Committee on the 123 rd Amendment Bill
2017, which has been placed on record by the learned counsel
Shri. Talekar.            He would also invite our attention to the
comments             of        the   department           of     Social      Justice        and
Empowerment in the compilation submitted by Shri. TalekarDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

and      he      would          vociferously      spell        out   the     intention         in
introducing 123rd Amendment Bill and he would advance the
following prepositions in this regard:-
A)       Constitutional Amendment does not affect or alter the
powers or functions of the State Backward Class Commission.
B)       The power of inclusion or exclusion of backward classes
in State Backward Class list shall remain unchanged.
C)       Clause 9 of Article 338-B does not in any way interfere
with the power of the State Government to prepare its own
list. The classes included in the said backward list do not
automatically come into the central list of OBC's.
D)       The      summary            of    the    report        reveal      that      several
amendments were rejected since it was a view of the
Government of India that the amendment does not seek any
patil-sachin.
::: Uploaded on - 27/06/2019                               ::: Downloaded on - 28/06/2019 05:25:19 :::
                                126                           Marata(J) final.doc
change in the power of the State or in the status of the State
Backward Class Commission.
E)       The terms 'list' clearly refers to the list to the services of
Government of India and not to the State list.
                 Conclusively on this point, Shri Thorat would submit
that the said insertion in the Constitution no way affects the
legislative competence of the State legislature to bring an
enactment identifying the socially and educationally backward
classes within the State. and therefore it has not affected the
legislative competence of the State. Shri. Thorat also dealtDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

with the submission advanced by Shri. Datar to the effect that
the impugned enactment nullifies the judgment in case of
Sanjeet Shukla Vs. The State of Maharashtra (supra). His
submission is to the effect that the said judgment is rendered
at an interim stage on the basis of pleadings filed for interim
relief and the observations are merely prima facie subject to
the further orders. The reliance on the judgment of Cauvery
Water Dispute Tribunal12 according to Shri. Thorat is
misconceived and according to him the observations were
made in the peculiar facts and circumstances and therefore
this judgment does not lay down general proposition of law.
12 1993)Supp (1)SCC 96,
patil-sachin.
::: Uploaded on - 27/06/2019                ::: Downloaded on - 28/06/2019 05:25:19 :::
                                127                         Marata(J) final.doc
He would on the other hand rely upon the judgment in the
case of Medical Council of India Vs. The State of Kerala
(2018) SCC Online SC 1468, to support his submission that
the constitutional provision permit removal of defect in a
judgment and any such removal by the statute cannot be said
to nullify the judgment and/or overrule the same.
20               Learned senior counsel would further submit that
the impugned enactment of 2018 is based on substantive
quantifiable data collated by the MSBCC constituted under theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Act of 2005 and this Commission, according to Shri. Thorat,
was competent to look into the aspect of backwardness of any
class of citizens and their inclusion or exclusion in the list of
backward class. According to him, the Commission has
threadbare examined the aspect of backwardness of Maratha
community and only upon ascertaining quantifiable data and
on considering exceptional or extraordinary situation, it has
recommended inclusion of the community in the backward
class. He would further submit that by undertaking the said
exercise, the objection in Sanjeet Shukla raised about no
quantifiable data being provided by the State stands removed
and not there was no legal impediment in the enactment of
patil-sachin.
::: Uploaded on - 27/06/2019              ::: Downloaded on - 28/06/2019 05:25:19 :::
                                       128                                 Marata(J) final.doc
SEBC Act of 2018.                     Shri. Thorat would also dispel the
contention of his rival that Commission's report is contrary to
the earlier report of the Commission. He would submit that the
Commission has appointed expert agencies of highest repute
such as Gokhale Institute, Rambhau Mahalgi etc and has also
obtained         report        from    the        Labour    Commissioner               about
Mathadi's,          Dabbewalas          as    well    as      several        educational
institutions, universities, APMC's etc. He would also submit
that, the Commission has conducted an exhaustive research
and      analyzed          resolutions       of    784     Grampanchayats,                andDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

approximately 1,95,714 individual representations. It has also
analyzed old and contemporaneous record related to social
backwardness of Maratha and collected sample data of rural
and urban areas collated by five agencies. It has examined
the habitation, facilities, type of housing, provision for drinking
water, availability of jobs, ratio of employment, literacy rate,
percentage of admission in educational institutions at all
levels, dropout percentage and ratio of graduates/degree
holders. Shri. Thorat has also highlighted that the Commission
has looked into the statistics demonstrating that 23.56%
suicides are committed by Maratha farmers which is depictive
of depravement of Maratha community. Shri. Thorat would
patil-sachin.
::: Uploaded on - 27/06/2019                             ::: Downloaded on - 28/06/2019 05:25:19 :::
                                129                      Marata(J) final.doc
however disagree with the submissions of his rivals to the
effect that Maratha and Kunbi are one and the same and he
submit that some observations of the Commission dealing
with the Maratha and Kunbi cannot be read in isolation so as
to contend that Maratha should be included in Kunbi and he
would request us to read the report as a whole so as to
understand these recommendations on the basis of analysis
made on voluminous material, reports, records etc. At the end
of his submission, Shri. Thorat would deal with the contention
of counsel for petitioners that the impugned Act violates theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

basic structure of the Constitution. He submit that, the said
contention has no merit. The doctrine of violation of basic
structure, according to Shri. Thorat applies to change brought
by the constitutional amendment pursuant to Article 368 of
the Constitution and he would submit that even otherwise
there is no violation of basic constitutional tenets of equality
so as to allege violation of basic structure and none of the
axioms like secularism, federalism etc, have been violated by
the impugned legislation. On the other hand, by the said
enactment, the State has sought to take affirmative steps in
favour of a disadvantaged section of society identified by the
Commission to be socially and educationally backward. Shri.
patil-sachin.
::: Uploaded on - 27/06/2019           ::: Downloaded on - 28/06/2019 05:25:19 :::
                                130                          Marata(J) final.doc
Thorat would submit that, the concept of basic structure is
evolved as a safeguard in exercise of constituent power and
not legislative power, as exercise of legislative power is
controlled by factors like legislative competence, violation of
fundamental rights or other provisions of the Constitution and
therefore, he would critically assail the submissions advanced
by the learned counsel Shri. Datar and Shri. Aney.                 He would
submit that there is always a presumption in favour of
constitutionality and the burden to prove otherwise is on the
person who alleges it. According to him, there is no seriousDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

challenge to the lack of legislative competence of the State in
enacting the Act of 2018 except the argument in relation to
article 342 A which he has already dealt with. He would place
reliance on following judgments to contend that the scope of
judicial review to interfere with the legislation is limited.
         i)      Nayar Service Society Vs. Dr. T. Beermasthan & ors.
                 (2009) 5 SCC Page 545.
         ii)     Namit Sharma Vs. Union of India (2013) 1 SCC 745.
         iii)    Benoy Viswam Vs. Union of India (2017)7 SCC 59.
         iv)     Vikramsingh Vs. Union of India (2015) 9 SCC 502.
21               The submission advanced by learned counsel Shri.
Thorat is echoed by the learned senior counsel Shri. Mukul
patil-sachin.
::: Uploaded on - 27/06/2019               ::: Downloaded on - 28/06/2019 05:25:19 :::
                                  131                         Marata(J) final.doc
Rohatgi. Learned senior counsel has taken us through the
Constitution bench judgment in Indra Sawhney (supra) in
great detail.            He would submit that Justice Jeevan Reedy
delivered the judgment for himself and three other Hon'ble
Judges to form the majority view and Justice Pandian and
Justice Sawant has taken a concurring             view.       According to
Shri. Rohatgi, there is no bar imposed in the constitutional
scheme regarding percentage to which the affirmative action
by State should be scaled and therefore, the argument that
there exists a ceiling of 50% is dubbed as baseless argument
by Shri. Rohatgi. He would strenuously submit before us thatDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

the door is not completely shut by the majority view and a
window is kept open, by way of illustration in a far-flung and
remote areas, the population inhabiting those areas being out
of main stream of national life, with conditions peculiar to and
characterstical to them and it is in this situation inherent in
the great diversity of this country, Justice Jeevan Reddy has
expressed that some relaxation in the strict rule may become
imperative. Learned counsel submit that it is no doubt true
that this power and relaxation is to be exercised with extreme
caution only when a special case is made out. He would thus
submit that the situations contemplated for deviations are not
patil-sachin.
::: Uploaded on - 27/06/2019                ::: Downloaded on - 28/06/2019 05:25:19 :::
                                        132                              Marata(J) final.doc
exhaustive but only illustrative and he would cite an example
of transgender which have now gained status into the society
by categorizing them as "Backward." He would submit that,
the Constitution of India which is an organic and living
document            involving         dynamic    concepts          never        intended
truncating the power of State conferred under Article 15 (4)
and 16 (4) which came to be introduced as special provisions.
Shri. Rohatgi would also submit that the observation made in
the judgment in case of Nagraj (supra), to the effect that in
Indra Sawhney (supra) majority has held that the rule of 50%
laid down in Balaji is binding rule and not a mere rule ofDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

prudence itself is not a correct analysis of the majority view in
Indra Sawhney. He would submit that, Nagaraj (supra) was
followed in S.V. Joshi (supra) where quantifiable data was
directed to be collected before exceeding limit of 50%. As
regards 102nd (Constitution) Amendment introducing                                  Article
342 A, Shri. Rohatgi would assert that the said amendment is
inserted        w.e.f.         15th   August    2018     and       a    socially        and
educationally backward class concept is inserted in the
Constitution along with the definition contained in Article 366
(26 C). He would further submit that the distinction between
the newly introduced Article and the Article 341 and 342 is
patil-sachin.
::: Uploaded on - 27/06/2019                           ::: Downloaded on - 28/06/2019 05:25:19 :::
                                   133                             Marata(J) final.doc
very apparent and sub clause 2 of Article 342 A enables the
Parliament to include or exclude from the "central list" of a
socially and educationally backward classes specified in
notification         issued    under    clause   (1).       In     socially       and
educationally backward class, Shri. Rohatgi would submit that
the words used in the clause should be read in reference to
the context otherwise it would be leading to absurd result. He
would rely on the judgment in case of Printers (Mysore Ltd.
& Anr) Vs. Assistant Commercial Tax Officer & ors.                               13
                                                                                      to
support his submission. He would also invite our attention to
the historical background for introduction and conferment ofDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

benefits on the Other Backward Classes after the Mandal
Commission's report and he further submit that identification
of the backward classes was a regime left to the respective
State since they are more acquainted and familiar with its
population and their status. According to Shri. Rohatgi after
the Mandal Commission report,               a central list for respective
State was prepared and this list continue to exist as on today
apart from the list of Other Backward Classes prepared by the
respective State. He would further submit that merely
because the constitution is amended, the existence of list
13(1994) 2 SCC 434
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:19 :::
                                       134                            Marata(J) final.doc
prepared by the State is not wiped out automatically and
particularly when the judgment in Indra Sawhney (supra) left it
to the respective States to determine the backwardness of its
citizens and even directed for constitution of Backward Class
Commission             for     each    State      and    this      direction         was
implemented by all States by constituting backward class
commissions to identify backwardness within its jurisdiction. In
such circumstances he would submit that it would be
premature to hold that Article 341 & 342 on one hand and
Article 342 A on the other are analogous and intended to
operate in the similar fashion.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

22               Shri. Rohatgi was supported in his arguments by
learned senior counsel Shri.Parmjeet Singh Patwalia and after
inviting        our     attention      to   the   constitutional          framework
contained in Article 15 (4) and 16 (4) he would submit that
merely being placed in the list of backward class do not entitle
a community to reap the benefits for reservation unless the
State proactively decide to reserve certain percentage for
those classes listed as backward. According to the counsel,
the SEBC Act of 2018 carve out a quota for Maratha
community by virtue of Section 4 and determination of their
patil-sachin.
::: Uploaded on - 27/06/2019                        ::: Downloaded on - 28/06/2019 05:25:19 :::
                                       135                              Marata(J) final.doc
social and educational backwardness is backed by the
empirical study based on scientific methodology conducted by
the Backward Class Commission constituted by the State in
terms of direction issued in Indra Sawhney (supra). He would
rely upon the parameters laid down by the Hon'ble Apex Court
in identifying backward class and specifically social, economic
and educational backwardness. He would also support Shri.
Rohatgi and take his argument further in relation to article 342
A and submit that the said provision is prospective in
operation and possibly when the power is so exercised, the
issue about State legislature lacking competence can beDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

examined, but according to him it is premature stage when
the provision is not yet implemented and till then the power of
the      State      to     identify    backward       classes        would        remain
unfettered. He would also place heavy reliance on the report
of the MSBCC which record reasons for classification and also
record a finding of the Maratha community being not
adequately represented and in the words of Shri. Singh when
the power of the State remains intact at this stage, it could be
appropriately dealt with if the contingency contemplated
under article 342 A occurs at a future point of time and the
President         notifies     certain      classes     to     be      socially        and
patil-sachin.
::: Uploaded on - 27/06/2019                          ::: Downloaded on - 28/06/2019 05:25:19 :::
                                136                             Marata(J) final.doc
educationally backward.
23               Shri. Rafiq Dada, learned senior counsel has also
advanced his submissions in support of the State legislation
and has justified the State's stand that it possesses legislative
competence to enact SEBC Act of 2018.                   He would strongly
oppose          the    arguments   of   counsel   for     petitioners         that
reservation to the extent of 50% has to be read in Article 15 &
16 of the Constitution and that the same can be crossed only
by Parliament in exercise of constituent power under Article
368. Shri. Dada would also snub the proposition of hisDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

opponent that 50% is the ceiling for reservation and on the
other hand he would categorically submit that by the 103 rd
(Constitution) Amendment Act rule of 50% is nullified since
now the reservation in favour of Economically Backward
Classes (EWS) is sought to be introduced in the Constitution
itself, bypassing the ceiling limit of 50%. Shri. Dada would
submit that historically in Maharashtra two statutes are
already in existence which provide for reservation, namely.
Reservation in Public Services Act 2001 and Reservation in
Private Professional Institutions Act 2006.              He would submit
that the National Commission for backward Class Act, 1993
patil-sachin.
::: Uploaded on - 27/06/2019                  ::: Downloaded on - 28/06/2019 05:25:19 :::
                                137                      Marata(J) final.doc
was enacted by the Parliament and the Maharashtra State
Backward Class Commission Act was enacted in 2005 by the
Maharashtra legislature. He would submit that the National
Commission of Backward Classes repeal Act 2018 cannot ipso
facto repeal the MSBCC Act of 2005 and it in no way abridges
the provisions of the Maharashtra Act of 2005.              Shri. Dada
would submit that the State has taken a decision to grant
reservation in services in State based on its finding that
Maratha community is not adequately represented in the
services under the State and this conclusion is based on
empirical data collected by the Backward Class CommissionDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

with an estimate of 30% of Maratha population in the State.
Learned counsel would submit that in the matter of "Adequacy
of representation" of a community, it is the opinion of the
State that is material and this opinion cannot be substituted
with the opinion/conclusion proposed by the petitioners. He
would place reliance on the catena of judgment as the nature
and scope of judicial review on the decision arrived at by the
State which lay down the proposition of law that sufficiency of
reasons for an executive action is not subject matter of judicial
review. Shri. Dada would submit that, the Gaikwad report was
duly examined by the State Government and it concurred with
patil-sachin.
::: Uploaded on - 27/06/2019           ::: Downloaded on - 28/06/2019 05:25:19 :::
                                138                        Marata(J) final.doc
its recommendations which are otherwise binding on the
State. The Commission has dedicated entire chapter IX for the
topic i.e. "Inadequacy of Maratha community in services under
the State." Shri. Dada would place reliance on the judgment of
Hon'ble Apex Court in Ashoka Kumar Thakur Vs. Union of
India14.          The Hon'ble Apex Court observed in the said
judgment that the Parliament is invested with the power of
legislation and it is deemed to have taken into consideration
all the relevant circumstances while passing the legislation of
this nature. On this ground the prayer to declare 27%
reservation provided in the Act to be illegal or that the Act wasDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

liable to be struck down was rejected. In light of the said
principle of law, Shri. Dada would submit that sufficiency of
reason in formation of opinion by the State cannot be gone
into by the Courts.
24               Shri. Dada has also canvassed that the scope of
judicial review in respect of report such as that of Gaikwad
report is limited and though the report is not completely
beyond judicial scrutiny, he would submit that it is not open
for the Courts to substitute their own opinion with the opinion
14 (2008) 6 SCC page 1
patil-sachin.
::: Uploaded on - 27/06/2019             ::: Downloaded on - 28/06/2019 05:25:19 :::
                                   139                          Marata(J) final.doc
drawn by the body of experts. He further submit that the
commission is statutory body, vested with wide ranging power
including collection of data and identification of backward
classes on basis thereof. The Court can only ascertain where
there is relevant quantifiable data which is contemporaneous
and that no irrelevant/ extraneous factors have been taken
into consideration before arriving at a decision. He would
submit that the court would not sit on the commission's report
as the Appellate Court so as to re-appreciate the evidence or
substitute its opinion. He would place reliance on the
judgment expounding said provision in the case of BariumDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Chemicals Ltd. Vs. Company Law Board15. Shri Dada is
also highly critical of the fact that the petitioners have
proposed to substitute their own analysis and conclusion to
that of Gaikwad report which is untenable in law and he would
allege that petitioners have sought to draw their own
conclusions and the understanding is faulty as they are
comparing two or more different types of surveys. He would
submit          that      the   methodology   adopted          by      Gaikwad
Commission is elaborate, scientific, accurate and proper and it
need not be compared with other earlier commissions. Heavy
15 (1966) Supp SCR 311
patil-sachin.
::: Uploaded on - 27/06/2019                  ::: Downloaded on - 28/06/2019 05:25:19 :::
                                      140                             Marata(J) final.doc
reliance was placed by Shri. Dada on the judgment in case of
Ram Singh Vs. Union of India, 2015 (4) SCC 697.
                 He would asseverate that an overview of the
functioning            of      Gaikwad   commission       would        validate        its
credibility and would put the allegations to rest.                             He has
painstakingly taken us through the report right from the terms
of reference, the data collected by Commission through
various agencies including Gramsabhas, Commissioner of
Labour, Collector & Commissioners of Revenue, survey by
NABARD, General Administration Department in respect of
employees of Class-I and Class-IV.                 He would also invite ourDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

attention         to    the      selection   of   areas    of    survey        to     the
questionnaires and the data collated in tabular form. He also
rebut the contention of the petitioners that the report is
prepared with the sole ulterior motive of providing reservation
to Maratha community and that it has overlooked the earlier
report that had rejected the claim of this community. Shri.
Dada would further submit that on collection and analysis of
data when the Commission has identified Maratha as socially
and educationally backward class, there is no restriction put
on by the Constitution on making separate sub categories
under broader SEBC's category on the basis of purpose of
patil-sachin.
::: Uploaded on - 27/06/2019                        ::: Downloaded on - 28/06/2019 05:25:19 :::
                                   141                             Marata(J) final.doc
reservation and benefits to be conferred. He would further
submit that there are already six sub categories existing in the
OBC reservation in the State.
                 Shri. Dada would also carve out "extraordinary
situation and exceptional circumstances" in the State to
provide reservation beyond 50% to SEBC category wherein
Maratha community is included. He would list the said factors
which have been taken cognizance of by Gaikwad commission
to the following effect.
        (A)     Farmers suicide an agricultural distress.
        (B)     Daughters of farmers committing suicide.
        (C)     Gokhale report and Government data on farmersDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                suicide.
        (D)     Fragmentation       of    land     holding         marginalized
                farmers.
        (E)     No reason as to how from 1952 onwards reservation
                in favour of Maratha community disappeared.
        (F)     Inclusion of Maratha community in list of backward
                class by Kalelkar commission and its exclusion from
                first list of OBC without any reason.
        (G)     Earlier        commissions        discarding               Maratha
                communities       claim    without        support          of     any
                quantifiable      data     and         the        extraordinary
                circumstances deteriorating social status of the
                Maratha community of the said factors have been
                highlighted by Shri. Dada to the following effect.
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:19 :::
                                   142                            Marata(J) final.doc
  1)            Regional disparity elaborated by committee's like
                Dandekar committee 1992, Kelkar Committee 2013.
  2)            Non adherence to Nagpur pact and protection under
Article 371 to Marathwada and Vidarbha Region.
  3)            Relatively more social and educational backwardness.
  4)            Non industrialized region.
  5)            Dependency on agriculture drought prone areas.
  6)            Largest proportion of farmers suicide in the region
                from      Maratha community
  7)            Being ruled by Nizams of Hyderabad which remained
                underdeveloped and continues to be so.
25               According to Shri. Dada, different commissions
have faltered in the manner of conducting inquiry and
consequently             representation   of   Maratha       community             for
reservation was wrongly rejected. He would submit that SEBC
Act 2018 also complies with the twin conditions, namely,
classification being founded on intelligible differentia and theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

differentia having rational nexus with the object sought to be
achieved. In support of his submissions he would place
reliance on the judgment of Apex Court in the matter of In Re
Special Courts Bill,16 wherein Hon'ble Apex Court has carved
out the principles in relation to Article 14 and ruled that all
16 AIR 1979 SC 478
patil-sachin.
::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:19 :::
                                      143                             Marata(J) final.doc
persons similarly circumstanced shall be treated alike both in
privileges conferred and liabilities imposed and it is held that
it    is    permissible        for   the    State     to    create       reasonable
classification provided it is rational and not arbitrary, and
based on some qualities or characteristics which are found in
all the persons grouped together and not in others who have
left out, but those qualities or characteristics must have
reasonable relation to the object of legislation.
26               We have also heard the learned senior counsel Shri.
Vineet Naik who represent Respondent No. 28 in PIL No.
175/2018,           namely,     Akhil      Bhartiya     Maratha          Mahasangh
registered as non governmental organization established with
an object to identify the socio economic problems of Maratha
community. Shri. Naik would advance his submissions on the
'extraordinary circumstances' carved out in judgment in IndraDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Sawhney (supra). He has taken us through all the earlier
reports of Commission to dispel the submission of the
petitioners and to deal with their arguments that on all earlier
occasions the various commissions have declared Maratha as
forward community.               He would submit that, all the earlier
commissions has erred in excluding the Maratha community
patil-sachin.
::: Uploaded on - 27/06/2019                        ::: Downloaded on - 28/06/2019 05:25:19 :::
                                      144                               Marata(J) final.doc
from       reservation         and    this   itself      is    an      extraordinary
circumstance. As far as Mandal commission is concerned, he
submits that, it has fallen into grave and serious error in
holding Maratha community as forward Hindu caste.                                       He
further submit that, census of India 1931 Volume VIII Part-II
Bombay           Presidency      specifically    record           that          Maratha
community is a Hindu intermediate community and this is
synonymous to backward classes as observed by the Hon'ble
Apex Court in Indra Sawhney (supra). He would further refer to
the report of NCBC where request was made to consider
Maratha as a backward community based on the presumption
that Maratha was a synonym of Kunbi in the central list of
backward classes. According to the learned senior counsel, the
report not only denies the request for inclusion of Maratha in
central list of backward classes as synonym of Kunbi but travel
a step ahead and declare Maratha as socially developed andDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

prestigious community and this finding is without any basis,
quantifiable data and/or any material on record. Learned
counsel further makes a reference to Bapat commission report
submitted in the year 2008. He submit that though in
substance the report is in favour of inclusion of Maratha in
OBC, final decision by way of voting speaks to the contrary. He
patil-sachin.
::: Uploaded on - 27/06/2019                          ::: Downloaded on - 28/06/2019 05:25:19 :::
                                145                            Marata(J) final.doc
therefore invited our attention to the findings recorded by the
individual members of the commission and according to him,
three of the members have recorded their findings in favour of
Maratha community and the dissent note of Shri. Devgaonkar,
Shri. Deshpande and Shri. Laxman Gaikwad is in favour of
inclusion of Maratha in SEBC and not to include them in OBC.
According to him, this report does not consider any data of
educational backwardness and inadequacy of representation
in Government services. This Commission according to Shri.
Naik is not a statutory Commission and hence its report is not
binding. Further, he makes a reference to the Rane Committee
which came to be appointed to study and procure the
quantifiable data pertaining to the social, educational and
economical            backwardness   of   Maratha       community             and
inadequacy of representation in the State public services. He
would also place reliance on the Statement of Objects andDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Reasons (SOR) of the 2014 Ordinance as well as ESBC Act of
2015.
27               Shri. Naik has also highlighted the important facet
of the Gaikwad Commission's report which spell out the
extraordinary circumstances, namely, 'population quantum
patil-sachin.
::: Uploaded on - 27/06/2019                 ::: Downloaded on - 28/06/2019 05:25:19 :::
                                      146                            Marata(J) final.doc
vis-a-vis reservation percentage'. According to him the figures
available on record would indicate that as per 2011 census,
State       population         is   around   11.24      crore     out     of     which
3,68,83,000/- is the population of OBC's (VJNT, OBC, SBC).
Further the Ministry of Social Justice and Empowerment has
given State wise percentage of population of OBC in India and
for Maharashtra which is 33.08%. If the SC, ST population is
22% then Gaikwad Commission has recorded that population
of Maratha is 30%. Therefore, in terms of the population
according to Shri. Naik if one makes out that almost 85% in
the State is of backward classes and ceiling of 50% for this
85% population would be traversity of justice and would harm
the spirit of the policy of reservation and this according to him
has      been       rightly     captured     by   the    Commission            as     an
extraordinary and exceptional circumstance emerging in the
State warranting reservation of 16% in favour of MarathaDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

community. Further, according to him, the quantifiable data
collected by Gaikwad Commission as regards the State Public
employment would disclose that 4.62% jobs per 100 youths
are available and if the average recruitment per year is not
more than 5%, 5% of the 4.62% jobs per 100 youths get
translated into 0.23% i.e. almost less than 1 job per 100 youth
patil-sachin.
::: Uploaded on - 27/06/2019                       ::: Downloaded on - 28/06/2019 05:25:19 :::
                                         147                          Marata(J) final.doc
and now in this scenario if there is reservation of 50% in the
matter of public employment it is further brought down to
0.12%, available for remaining 5% forward youth classes. This
again according to Shri. Naik is an exceptional situation. Shri.
Naik would vehemently argue that, Maratha have been
erroneously kept out of the purview of reservation, which they
otherwise deserve and they have agitated for their rights for a
considerably long time. He would further submit that,
comprehensive                  report    compiled    by       Justice        Gaikwad
Commission is meritorious and trustworthy since it is backed
by quantifiable data. He also placed reliance on the various
reports relied upon by the Commission prepared by Gokhale
Institute of Politics and Economics, Pune in the year 2016
reporting on farmers suicide, sugarcane cutters, Mathadi
Hamal and Female domestic workers. These reports according
to Shri. Naik are self eloquent and depict the poverty and theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

harshness faced by Maratha community. In absence of any
avenues in State Public employment the Maratha community
has preferred to work as Mathadi Hamal or sugarcane cutters
since the holding size of the agricultural land of Maratha
population is minimal and the data reveals that 12%                                     of
Marathas are landless and those holding below 5 Acres, the
patil-sachin.
::: Uploaded on - 27/06/2019                        ::: Downloaded on - 28/06/2019 05:25:19 :::
                                   148                             Marata(J) final.doc
percentage is almost 80%. He also drives a comparison of this
community with Vanjari community which is already included
in the list of De-Notified and Nomadic Tribe for the benefit of
reservation. The report on farmers suicide according to Shri
Naik also indicates suicide by farmers pertaining to this
community as significantly high numbers and the reasons
attributable are economic and social backwardness, debt,
small/low yield lands.            By drawing our attention to said
reports, Shri Naik would submit that, Gaikwad Commission as
rightly made a reference to the said reports apart from
collecting quantifiable data and according to learned senior
counsel the isolation of Maratha community for last 70 years
is also an instance of extraordinary situation and exceptional
circumstance which would justify the reservation being
permitted to exceed the ceiling limit of 50%.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

28               We have also heard the learned senior counsel Shri.
Dhakephalkar             who   represent   the    petitioner        in     PIL     No.
181/2018 which seeks direction to implement the reservation
in favour of Maratha in the category of SEBC.                                    Shri.
Dhakephalkar would urge that the Commission has collected
contemporaneous data by involving scientific method and he
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:20 :::
                                  149                            Marata(J) final.doc
stressed on the methodology of the Commission which
involved supply of questionnaires, personal visits, collection of
data in form of resolutions from Gram Panchayats etc.                             By
comparing the data collected by Gaikwad Commission as
against the data collected in case of Ram Singh Vs. Union
of India (supra), Shri. Dhakephalkar would submit that in
Ram Singh's case in case of Jat reservation, eleven indicators
broadly under three heads i.e. social, economical and
educational were applied and these parameters were evolved
on the basis of Mandal Commission report. However, Gaikwad
Commission has in fact applied 25 parameters and reached at
a conclusion by testing the social, educational and economical
backwardness of Maratha community. Shri. Dhakephalkar
would also argue on the similar lines as Shri. Naik and submit
that the reservation of Maratha has to be proportionate to its
population. He would submit that the backwardness ofDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Maratha community is mostly on account of low social position
of Maratha community in the traditional caste hierarchy of
Hindu society and it is further aggravated by lack of
educational           advancement      among   major       section        of     the
community.            However,   inadequacy      of     representation             in
Government services and in the field of trade, commerce and
patil-sachin.
::: Uploaded on - 27/06/2019                   ::: Downloaded on - 28/06/2019 05:25:20 :::
                                 150                               Marata(J) final.doc
industry has further worsen their position in the social strata.
Shri. Dhakephalkar has placed reliance on the observations of
the Hon'ble Apex Court in the case of State of Andhra
Pradesh Vs. U.S.V Balaram17 wherein Hon'ble Apex Court
dealt with the criticism leveled that, the Commission had used
personal         knowledge     for    the   purpose       of     characterizing
particular group as backward and the Hon'ble Apex Court has
observed that it is inevitable and there is nothing illegal or
improper in doing so since the very object of the Commission
in touring various areas and visits to huts and habitation is to
find out the actual living condition. He would submit that the
information should be gathered by the Commission openly
and not in a clandestine manner and it is only on personal visit
to the area, the accurate picture can be ascertained and the
personal         impression    gathered     by   the      members           of     the
Commission have been utilized to augment various otherDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

material gathered and then it cannot be said that report of the
Commission suffers from the vice that they imported personal
knowledge. He also makes a reference to the research carried
out by various institutions which is relied upon by the
Commission which has been independently looked into the
17 AIR (1972) SC 1375
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:20 :::
                                      151                          Marata(J) final.doc
said report, applied its mind and then arrived at a conclusion.
Shri. Dhakephalkar would focus on the methodology and the
selection of subjects to arrive at a conclusion that the Maratha
community is backward. He would also make a reference to
the      report        of      Professor   Rajabhau    Karpe        Member           of
Maharashtra State Backward Commission who has carried out
detail analysis of the Maratha community and assisted the
Commission in arriving at a finding which is based on
quantifiable data.
29               In support of the reservation in favour of Maratha,
we have also heard learned senior counsel Shri. Arif Bookwala
who has filed Chamber Summons in Writ Petition No.
4100/2018. Apart from raising objection to the locus of the
petitioner and requesting the Court to not to entertain the
petition since the basic ingredient of entertaining the petitionDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

namely the locus, cause of action and irreparable loss to the
petitioner is not set out. Shri. Bookwala has attributed
malafides to the organization of the petitioner and submit
that, the said petition deserves to be rejected as it has made
blatantly false statements. Shri. Bookwala has briefly invited
our attention to the history of Maratha community including
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:20 :::
                                         152                                Marata(J) final.doc
the reservation provided to this community in 1902 and also
recognition          of    this       community      as      intermediate            by     the
Government of Bombay. According to Shri. Bookwala, the
resolution         covered            228     intermediate        communities              and
Maratha community is included at Serial No. 149.                                    Learned
senior counsel further make a reference to the Government
Resolution          dated        18th    May     1959      conferring         educational
benefits and facilities to the families having annual income
below Rs. 900/- and domiciled in the State of Maharashtra.
According to him, Maratha community was entitled to the said
benefit as it was purely based on economical criteria and this
action of the State was in fact endorsed by the Hon'ble Apex
Court in case of M.R. Balaji Vs. State of Mysore. However,
it was only subsequently this class was completely and
conveniently forgotten for conferment of reservation benefits.
Shri.      Bookwala            also     make    a   reference         to     the     MandalDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Commission's report which was submitted on 13.12.1982
which did not consider the case of Maratha community on the
contrary the Commission was depriving population quantum
of OBC made a passing reference to the Maratha community
as forward Hindu community without any basis and supporting
data. Shri. Bookwala has placed on record the judgment of the
patil-sachin.
::: Uploaded on - 27/06/2019                              ::: Downloaded on - 28/06/2019 05:25:20 :::
                                   153                            Marata(J) final.doc
Indian Law Reports (Madras Series) in case of Maharaj of
Kolhapur Vs. S. Sundaram Ayyar and 15 others which
traced the history of Maratha community.
                 The learned senior counsel has also focused on the
report of the Commission as an expert body and according to
him, the composition of the Commission justified its existence
since the expert in the field of social scientific research came
to be involved. According to Shri. Bookwala, the Commission
conducted           sample     survey   in   conformity       with      the      pre-
determined criteria which require objective study of the
Maratha community with comparison to State averages. Public
hearings were also conducted by the Commission in all
regions of the State and it extended to 21 districts head
quarters with pre-intimation of public news widely published in
newspaper.           According to Shri Bookwala, a Panel of experts
prepared format of codification of data and that is how theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Commission applied statistical tools and techniques and
tabulated the data in graphical forms in consultation with the
expert in the field. Learned senior counsel has distinguished
the methodology adopted by Gaikwad Commission as against
the earlier commissions and submit that the role of statistical
experts in working of this Commission is of great significance.
patil-sachin.
::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:20 :::
                                          154                                Marata(J) final.doc
The statistical expert sorted out the data on the parameters
for final weightage and scaling and the statistical expert Dr.
Sudhir Gavhane assisted the Commission in allotting the
marks and the Officers form the Maharashtra State Statistical
Department actually participated in codifying the said data.
Learned          senior         counsel        in    substratum          advances            the
submission that the report of the commission suffers from no
lacunae and is full proof report assessing the data collected in
a very scientific way. The said report is praised by the learned
senior counsel in terms of its working, compliances and the
clear understanding and approach to the issue.
                 The           learned     counsel         would         speculate           the
catastrophic situation if 35 Million population from one
community is suddenly added to group of 20 million existing
OBC's having about 300 castes and these communities would
be left high and dry if such huge population is added to theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

existing OBC. He would submit that, the highest farmers
suicide         in   the        community           reflects   its     plight      and       the
extraordinary situation and exceptional circumstances would
justify the exceeding of limit of 50% if at all it exists. He would
also deal with the argument of his opponent that minuscule
data was used by the Commission and that the Commission
patil-sachin.
::: Uploaded on - 27/06/2019                               ::: Downloaded on - 28/06/2019 05:25:20 :::
                                    155                           Marata(J) final.doc
did not follow terms of reference. He would also deal with the
submission of his opponent on the finding of the Commission
report point to point and concluded by submitting that the
report of the Commission calls for no interference as the
parameters of judicial review are not at all attracted to call for
an interference in the said report.
30               We have heard the learned Senior Advocate Shri.
A.Y. Sakhare assisted by Advocate Akshay Shinde and
Advocate          Rohan        Mirpury   representing     the      State,       who
specifically focus on the report of the Maharashtra State
Backward Classes Commission. Shri. Sakhare specifically
responded to the submissions advanced by the learned senior
counsel Shri. Sancheti. He would submit that the Constitution
of India aims at achieving the social, economic and political
justice and equality of status amongst all citizens. According
to him the State is duty bound to secure adequate means ofDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

livelihood to all the citizens and to promote with special care
the educational and economic interest of the weaker sections
of the people and in particular of the scheduled castes and
scheduled tribes and they need to be protected from social
injustice and exploitation of all forms.              Shri. Sakhare would
patil-sachin.
::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:20 :::
                                        156                           Marata(J) final.doc
submit that the impugned legislation is thus to be looked at as
an endeavour to provide opportunities to these weaker
sections who are backward in the field of education and also in
public employment. According to him, the legislation aims to
bring these classes in the main stream of nation's life. He
thereafter took us through the report in the backdrop of the
catena of judgments delivered on the issue as to how
backwardness of classes is to be identified. He placed reliance
on the Judgment of Apex Court in Indra Sawhney and he also
highlights the report of the Commission which is based on the
analysis undertaken by the experts in the backdrop of
voluminous material collected from the field. He submitted
that the composition of the commission is not challenged nor
there is any challenge to authenticity of data which inspires
confidence. According to him, in terms of Indra Sawhney,
the jurisdiction to determine as to who belongs to theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

backward class is best left to the discretion of the State and it
is permissible for the State to appoint a Commission
comprising of experts in the field and this Commission is
empowered to derive a method for their identification and the
discretion should be left to the expert body to determine the
parameters            as       laid   down   by   the   authoritative           judicial
patil-sachin.
::: Uploaded on - 27/06/2019                        ::: Downloaded on - 28/06/2019 05:25:20 :::
                                   157                            Marata(J) final.doc
pronouncements. He submitted that, the scope of judicial
review in the decision of the commission is minuscule if the
report is based on contemporaneous and quantifiable data.
Shri. Sakhare invited our attention to historical background of
the community and also to the reports of various Commissions
constituted by the State and the two National Commissions
and the manner in which the community was dealt. In this
context, he submitted that the present Commission which is
constituted initially under the Chairmanship of                     Justice S.B.
Mhase (Retd.) and subsequently being replaced by Justice
M.G. Gaikwad (Retd.) is in accordance with the provisions of
the MSBCC Act, 2005. He would submit that the Chairman of
the Commission has a wider experience and apart from this,
the       Commission           comprised   of   Social        Scientist         Shri.
Chandrashekhar Bhangwanrao Deshpande, who was earlier
member of the MSBCC from 2004 to 2008 and 2008 to 2011.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Further, the Commission also included Shri. Sudhir Deomanrao
Thakre, who belongs to the Indian Administrative Service and
his educational qualification was a part of the Commission.
Further, it comprised of Dr. Sarjerao Bhaurao Nimase, Mr.
Rohidas Vitthal Jadhav and Prof. Rajabhau Narayan Karape,
experts in Modern Indian History, and the Peasant Movement
patil-sachin.
::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:20 :::
                                      158                           Marata(J) final.doc
in Maharashtra.                He would then invite our attention to the
methodology and procedure adopted by the Commission
which included the data collection through sample survey and
purposive sampling. He would also invite our attention to the
Common Questionnaire through which the data was collected
by      the     Commission          which    extended       to     collection         of
information about status of the family, level of the education
of family, the occupation of the family, type of residential
accommodation of the family. The Questionnaire also focused
on ascertaining the nature of social, Educational and Economic
Status of persons including the age of marriage, remarriage of
widow/widower etc. Shri. Sakhare also submitted that the
Commission conducted public hearings in all parts of the State
excluding the tribal Districts and total number of persons who
were heard were 1,97,522.                   The Commission also received
representations from individuals Grampanchayats, electedDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

representatives independent organizations and called for
opinion of experts. Apart from this, in order to ascertain the
educational status of the community, information was called
from the Directorate of Higher & Technical Education, Director
of Medical Education and all Universities in the State of
Maharashtra including Agricultural Universities. In order to
patil-sachin.
::: Uploaded on - 27/06/2019                      ::: Downloaded on - 28/06/2019 05:25:20 :::
                                   159                               Marata(J) final.doc
ascertain the status of employment, information was collected
from State Government, Semi-Governmental and autonomous
organizations. According to Shri. Sakhare, the Commission has
kept in mind the principles set out by the Hon'ble Apex Court
while interpreting Article 15 and 16 of the Constitution of India
in order to fix the parameters to determine the social,
educational and economic backwardness of the community
and the Commission considered 26 contemporary parameters
to ascertain social backwardness. According to Shri. Sakhare,
the educational level of the community at different levels like
the Primary Level, Secondary Level, Higher Secondary Level,
UG/ PG Level and Technical Courses came to be examined. As
far as economic backwardness is concerned, according to Shri.
Sakhare, nine parameters were applied and after this detailed
survey,         the     Commission      has    concluded          that       Maratha
Community suffers from Economic Backwardness. He alsoDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

invited our attention to the marking system adopted and the
marks secured by the said class by applying the parameters of
social, educational and economic backwardness. He would
then submit that the Commission has arrived at a conclusion
that      the     Maratha      population     is   30%      in     the     State       of
Maharashtra and for the said principle, it has relied upon the
patil-sachin.
::: Uploaded on - 27/06/2019                       ::: Downloaded on - 28/06/2019 05:25:20 :::
                                      160                                  Marata(J) final.doc
Population Census Report of 1931, the report of the Planning
Department of the State which had undertaken survey of
population of Marathas in the State in the year 2013-14 and
came to the conclusion that Maratha Population is 32%.
Reliance is also placed on the Census Report of 2011 and also
the report of Social Justice Department of Government of India
where the population of OBC is ascertained. According to him,
the survey conducted by the Rural Development Department
through Gokhale Institute of Economics and Politics, Pune
which had undertaken caste wise census, except SC & ST
population in Rural Maharashtra has been collected. Based on
this data, the Committee then proceeded to ascertain the in
adequate           representation          of     this    community             in    public
employment and made recommendation on the quantum of
reservation to be provided.                     After the thorough trail of the
report of the commission, Shri. Sakhare would submit that theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

analysis of the report by the petitioner is completely
misconstrued one. As far as sample is concerned, he would
submit that the                allegations          that sample size is                    not
representative            of   the   entire        State      data      is     misleading
statement and rather the commission indulged itself in the
purposive sampling method and the data is weighed against
patil-sachin.
::: Uploaded on - 27/06/2019                             ::: Downloaded on - 28/06/2019 05:25:20 :::
                                161                         Marata(J) final.doc
the State average. As far as the objection of non-inclusion of
Mumbai city in the sample survey is concerned, he would
submit that when urban area sample survey, one Municipal
Corporation and one Municipal Council from each revenue
division is decided on the basis where the Maratha Population
has migrated and settled in Konkan Region and Thane was
selected as the Municipal Corporation and therefore, Mumbai
has not been included. Shri. Sakhare has submitted that the
petitioner has no expertise and no basis for questioning the
credibility of efficacy of the exercise undertaken by the
distinguished experts in the field. He would reiterate that the
Commission has also taken into account the usual argument
about efficiency of the administration being            affected to the
said issue. Shri. Sakhare placed reliance on the following
judgments of the Hon'ble Apex Court :
(1)      Bir Singh V. Delhi Jal Board & ors. (2018) SCC 312.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

(2)      Ramsing V. Union of India (2015) 4 SCC 697.
(3)      State of Andhra Pradesh V. U.S.V. Balram
         (1972) 1 SCC 660.
(4)      Barium Chemicals v. Company Law Board
         (1966) Supp. SCR 311.
(5)      Ahmedabad Mill Owners' Association etc. v. Textile
         Labour Association & ors. AIR 1966 SC 497.
patil-sachin.
::: Uploaded on - 27/06/2019              ::: Downloaded on - 28/06/2019 05:25:20 :::
                                     162                                 Marata(J) final.doc
6)       Basavaiah (Dr. V. Dr. H.L. Ramesh & Ors.(2010)
         8 SCC 372.
                 The first two judgments are relied upon by him in
support of the submission that if quantifiable data is collected,
then the State can base its decision on it.                           The remaining
judgments have been relied upon to support his submission of
limited scope of the Judicial review to interfere in the finding
of an expert body.
                 Shri. Sakhare has also placed on record the extract
from the "Research Methodology Methods and Techniques by
Shri. C.R. Kothari and Gaurav Garg as well as the extract from
"Statistical         Methods       by     Dr.   S.P.    Gupta"         for     Sampling
Techniques           and       submit   that    the     research         methodology
adopted by the Commission is based on scientific method and
is guided by the well acclaimed standards of research
methodology, which is based on empirical evidence, itsDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

consideration, critical scrutiny resulting into probabilistic
predictions. The learned senior counsel has also placed heavy
reliance on the "scientific analysis of the data of sample
survey" conducted by five research institutions.                              He would
submit that if Annexure 6 accompanying the report is perused,
one would understand the methodology adopted by the
patil-sachin.
::: Uploaded on - 27/06/2019                           ::: Downloaded on - 28/06/2019 05:25:20 :::
                                     163                          Marata(J) final.doc
Commission and its conclusion. He would thus urge that the
report of the commission calls for no interference.
31               Learned senior Advocate Shri. Mihir Desai also
advanced his submission in PIL WP (St) No. 36115/2018,
Ajinath Tulshiram Kadam Vs. The State of Maharashtra.
He would advance more or less similar argument to those
counsel who              preceded him and argued in support of the
legislation.          He would place on record data overall literacy
rate in Marathwada Region in 1901 and also the literacy rate
of this community in 1911 which is based on the Maharashtra
State Gazetteers               Department and he also placed on record
the report of the Gokhale Institute of Politics and Economics,
Pune. He would submit that impugned Enactment which is
piece of legislation which came to be enacted under Article 15
(4) and Article 16 (4) which needs to be upheld since it isDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

based on relevant data in form of the report of the commission
which is carved out extraordinary situation and exceptional
circumstances to exceed reservation beyond 50% in the State.
32               We have heard Shri Tekale and Shri Gaikwad,
learned Advocated representing respondent no.3 in PIL 175 of
patil-sachin.
::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:20 :::
                                       164                          Marata(J) final.doc
2018.           We    have     also     heard   Ms.Khopade           representing
intervenor Shri Haribhau Rathod in PIL No.175 of 2018.                              We
have also extensively heard Advocate Patil, counsel for
petitioner in WP No. 2126 of 2018 who has posed a challenge
to Section 4(3) of the Act and would submit that the Backward
Class Commission cannot create a separate class.                                   Shri
Gaikwad has traced the history of the community and its
social placement in the community. He has attempted to
justify the reservation provided to Maratha community which
is declared as socially and educationally backward and he
would submit that it is a fact that Maratha community was not
able to advance and the Gaikwad Commission has now
collected a quantifiable data in respect of the backwardness of
this community. He would also submit that the benefit of
reservation cannot be denied to this community merely on the
basis of the bar created by the Supreme court and theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

exceptional circumstances warrant and justify the action of
the State in providing 16% reservation to the said community.
He has also placed on record the State/Union Territory wide
percentage of population of OBC in India in the year 2011-12
in the form of the NSSO Report no. 563 (employment and
unemployment) and according to him, the percentage of OBC
patil-sachin.
::: Uploaded on - 27/06/2019                      ::: Downloaded on - 28/06/2019 05:25:20 :::
                                165                           Marata(J) final.doc
in Maharashtra is 33.8. He would justify the report of the
Commission which has spelled out a case of inadequate
representation. The statement made by Shri Tekale is,
however, to the effect that the Maratha community is entitled
to be included in the list of OBCs and the benefits availed to
the OBCs should be extended to them.
(II) - CONSPECTUS OF THE MATTER
33               Before embarking upon the core issue involved in a
group of petitions about the validity of the SEBC Act of 2018
thereby categorizing Marathas as 'Socially and Educationally
Backward Class' and conferring 16% reservation in their
favour, we would embark upon the history of this community
in brief.
                 The facts brought before us in regard to the history
of Maratha community is not seriously disputed by the partiesDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

and history of this community is reflected in the affidavit filed
by the State Government as well as the affidavits filed by the
intervenors supporting the impugned enactment. The MSBCC
Commission has also extensively referred to the history of the
community.
patil-sachin.
::: Uploaded on - 27/06/2019                ::: Downloaded on - 28/06/2019 05:25:20 :::
                                       166                           Marata(J) final.doc
34               As per the "Tribes and Castes of the Central
Provinces of India" by R.V. Russell of the Indian Civil service
Superintendent of Ethnography, Central Provinces published
by Macmillian & Co. Limited, Volume IV, Maratha is the military
caste of southern India which manned the armies of Shivaji
and of the Peshawa and other princess of the Maratha
confederacy.               In   the    Central   Provinces,       the      Marathas
numbered 34,000 persons in 1911 of whom Nagpur contained
9,000, Wardha 8,000. In Berar, their strength was 60,0000,
the total of combined province being 94,000.                         The caste is
found in large numbers in Bombay and Hyderabad and in
1901, the Indian census table shows a total of not less than
five millions persons belonging to it.
                 Marathas are marathi speaking people found on the
Deccan Plateau throughout the State of Maharashtra.                                 The
Marathas are a caste formed from military service andDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

according to Russell, it seems probable that they sprang
mainly from the peasant population of Kunbis, though at what
period, they were formed into a separate caste has not yet
been        determined.         This    community       are      cultivators          by
profession and once upon a time, land owners.                             The early
history of Marathas is a tale of rise and fall in the importance
patil-sachin.
::: Uploaded on - 27/06/2019                       ::: Downloaded on - 28/06/2019 05:25:20 :::
                                     167                             Marata(J) final.doc
of the dynasties ruling the various regions.                     Over the time,
center of political influence shifted from South Godavari Basin
to the Krishna Valley.              From 1300s onwards,              the Maratha
territories held territories under Muslim Kings and paid tribute
to them. Feuds among the local Muslim kingdoms and later
confrontation with Mughal dynasty which was eager to extend
its power to Deccan, allowed Maratha Chieftains to become
independent. A successful revolt of Shivaji, a Maratha Prince
who fought against Muslim Bijapur, overlords in the name of
establishing          Hindu      Kingdom.       The    local      Muslim         rulers
weakened by their fights with the Mughals succumbed to the
guerrilla attacks of of Shivaji's light infantry and cavalry. After
the death of Shivaji, the Maratha ranks were split between the
claimants to his throne and his son Shahu set up his capital at
Satara and appointed Chief Minister with the title 'Peshwa'.
The title and office became hereditary and in a short period ofDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

time,       Peshwas            became     the   leading     Maratha          dynasty
themselves. The Peshwas rose to be a powerful military force
supported by Maratha Confederacy and was assisted by loyal
chieftains including the house of Bhonsla, Sindhia, Holkar and
Gaikwad,etc.            Peshwas extended their territories all the way
North to Punjab and with the defeated Panipat battle in 1761,
patil-sachin.
::: Uploaded on - 27/06/2019                       ::: Downloaded on - 28/06/2019 05:25:20 :::
                                168                          Marata(J) final.doc
their era diminished.          In fighting among the confederacy
members after the death of Peshwa led to the entry of East
India Company into the succession disputes among the
Marathas. The British fought three wars with Marathas. At the
end of the third war in 1818, the British routed the Peshwas
and abolished their position and directly incorporated vast
areas of Maratha territory into the British Empire as a part of
Bombay Presidency.
                 In 1960, the modern state of Bombay was divided
into linguistic states of Maharashtra with Bombay as its capital
and Gujarat.
35               The material placed before us disclose the term
'Maratha' is used in overlapping senses i.e. within the Marathi
speaking region, it refers to single dominant Maratha caste or
to the group of Maratha and Kunbi caste, outside Maharashtra,Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

and it loosely designates the entire regional population whose
dialect is Marathi. Broadly, 'Maratha' caste is a largely rural
caste of peasant cultivators which formed the bulk of the
Maharashtrian society together with other Kunbi peasant
caste.          According to Jeremy Black, British historian at the
University of Exeter, 'Maratha caste is a coalescence of
patil-sachin.
::: Uploaded on - 27/06/2019               ::: Downloaded on - 28/06/2019 05:25:20 :::
                                          169                           Marata(J) final.doc
peasants, shepherds, iron-workers etc. as a result of serving in
military.        By      19th Century, the term 'Maratha' gained entry
under different captions in the British Administrative records.
The 1901 census listed three groups of Maratha Kunbi caste -
Maratha, Maratha-kunbis and Konkan Maratha. According to
Steele,         in    the      earlier    19th   century,   Kunbis,        who       were
agriculturists and Marathas who claimed Rajput descendants
and Kshatriya status were distinguished by their customs
related to widow remarriage.                     The term 'Maratha' gradually
came to denote an endogenous caste.
36                   The linkage between Maratha and Kunbi has always
been a matter of research and reveal that the Marathas and
Kunbis have the same origin - although these two are treated
as two different communities currently on a social level. The
Kunbi origin of Maratha has been explained in detail byDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Professor Richard Eaton by University of Arizona and Professor
Steward Gordon.                 The kunbis who served the Muslim rules,
prospered, and overtime adopted different customs and
started identifying as Maratha. Eaton cites an example of the
Holkar          family      that originally       belonged      to     the     Dhangar
(Shepherd) caste but was given a Maratha identity. The other
patil-sachin.
::: Uploaded on - 27/06/2019                          ::: Downloaded on - 28/06/2019 05:25:20 :::
                                    170                            Marata(J) final.doc
example is given by Professor Susanne Bayly of Cambridge
University         i.e.    of   Bhonslas   who   originated         among          the
populations of the Deccany tiller plainsmen who were known
by name 'kunbi' and 'Maratha'. Iravati Karve, Anthropologist,
University of Pune has described how Maratha caste was
generated from Kunbis who simply started calling themselves
"Maratha". She asserts that Maratha, kunbi and Mali are the
three main farming communities of Maharashtra - the
difference being that,               Marathas and kunbis were "dry
farmers", whereas the Mali farmed throughout the year.
Professor Cynthia Talbot from the University of Texas quotes
"when a Kunbi prospers he becomes Maratha".
                 The allegation in the petition is to the effect that
the Maratha community was a part of the core State politics
of Maharashtra since its inception in 1960.                           The Indian
National Congress was the preferred party of Maratha/KunbiDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

community and it enjoyed overwhelming support from the
Maratha dominated sugar co-operatives and thousands of
other co-operative organizations involved in rural agricultural
economy of the State.                This domination by the Maratha
community of the co-operative institutions assisted it in
gaining control over the rural economy, which enabled them
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:20 :::
                                    171                         Marata(J) final.doc
in turn to control the politics from village level upto the
assembly. The economic superiority also assisted this group in
setting         up       several   private   educational          institutions.
Resultantly, the State has many Maratha Chief Ministers,
Ministers, Officials as well as leadership in local municipal
councils and panchayats. It is out of context to mention that
10 out of 16 Chief Ministers of Maharashtra hailed from
Maratha community.
                 The present position of the said caste is described
by Russell in his compilation of "Tribes and Castes" in the
following words :-
         "The Marathas present be somewhat melancholy
         spectacle of an impoverished aristocratic class
         attempting to maintain some semblance of their former
         position, though they no longer have the means to do
         so. They flourished during the two or three centuries of
         almost continuous war and become a wealthy and
         powerful caste but they find difficulty in turning their
         hands to the arts of peace. Sir, R. Craddock writes of
         them in Nagpur :Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

               ......... A considerable of Government political
         pensioners are Marathas. Many of them own villages
         or hold tenant land, but as a rule they are extravagant
         in their living and several of the old Maratha nobility
         have fallen very much. The sons are brought upto no
         employment and daughters are married with lavish
         pomp and show. The native army does not attract
         them but few are educated well enough for dignified
         post in civil employment. It is a question whether
         their pride of race will give way before the necessity
         of earning their livelihood soon enough for them to
         maintain or regain their former position. The humbler
         members of the caste find their employment as petty
patil-sachin.
::: Uploaded on - 27/06/2019                  ::: Downloaded on - 28/06/2019 05:25:20 :::
                                       172                              Marata(J) final.doc
         contractors or traders, private servants, government
         peons, sowers, and hangers-on in the retinue of the
         most important families".
37               It is this Maratha community which is conferred
with      the     privilege      of    being    classified      as     'socially       and
economically             backward        by     the    Gaikwad            Commission
constituted by the State of Maharashtra and the impugned
enactment confers reservation of 16% to this community.
The State Government and the respondents who support the
reservation heavily rely on two notifications reserving seats in
public employment, first one being issued in the year 1902 by
Rajeshree Shahu Maharaj often referred                        to as the father of
the concept of reservation in the country and it provided
reservation to Maratha community as a backward class. In the
resolution         dated       23rd    April   1942     issued        by     the      then
Government of India, about 228 communities were declaredDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

as intermediate and backward class and Maratha is included
at Serial No.149 of the said list.
                 Subsequently, the Government of Bombay, Political
and Service Department issued a resolution on 1st November
1950, thereby superseding the Government Resolution dated
23rd April 1942 and directing that existing classification of the
communities             in     the    State    of   Bombay         into     advanced,
patil-sachin.
::: Uploaded on - 27/06/2019                          ::: Downloaded on - 28/06/2019 05:25:20 :::
                                173                        Marata(J) final.doc
intermediate and backward classes should be cancelled. After
re-organization of the State, the Government of Bombay
prepared a list of Other Backward Classes in Old Bombay State
which was printed in the year 1959.          In this list, the caste
'Kunbi-Tillori' appears at Sr.No.87.      However, the Maratha
caste did not find any place.
                 The Government of Maharashtra, Education and
Social Welfare Department by its resolution dated 13 th October
1967, prepared a list of backward classes pertaining to the
whole State of Maratha and Kunbi appeared at Sr.No.83. The
Government Circular dated 19th February 1986 contained a list
of Other Backward Classes and Kunbi (Sub-Caste) Leva Kunbi,
Leva Patil and Leva Patidar appeared at Sr.No.83.
38               The social status of this community was subjectDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

matter of assessment by the Backward Class Commissions
constituted by the State. It also came to be scrutinized by the
Second National Backward Class Commission i.e. Mandal
Commission. As it is a well known fact that the First National
Backward Class Commission popularly known as Kalelkar
Commission which was appointed by the Central Government
in view of demand of reservation in favour of the Other
patil-sachin.
::: Uploaded on - 27/06/2019             ::: Downloaded on - 28/06/2019 05:25:20 :::
                                    174                          Marata(J) final.doc
Backward Classes in view of Article 340 of the Constitution
based its report on caste and the Chairman of the Commission
himself addressed a letter to the President of India fairly
pleading for rejection of the report recommending the
reservations and remedies based on caste would not be in the
interest of justice.           The Central Government was not satisfied
with the said report in determining the criteria for identifying
backward classes under Article 15(4). In the mean time, the
Government of Maharashtra                appointed a Committee under
the Chairmanship of Shri B.D. Deshmukh who was directed to
go into the question of reservation of seats and allied matters
relating to recruitment of backward classes and Government
services.          The Second National Backward Class popularly
known as Mandal Commission which was appointed in the
year 1978 to determine the criteria for defining socially andDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

educationally backward class identified 128 communities as
'backward' and 94 of them classified as 'most backward' but
the Marathas came to be identified as 'forward'. The Special
request made for inclusion of Marathas as synonym of 'Kunbi'
in the Central list of backward classes was taken up for
consideration and on 22nd February 2000, the Commission
rendered its advise through the Central Government under
patil-sachin.
::: Uploaded on - 27/06/2019                   ::: Downloaded on - 28/06/2019 05:25:20 :::
                                175                           Marata(J) final.doc
Section 9(1) of the NCBC Act and rejected the request on the
ground that Maratha is not a synonym of Kunbi and it do not
deserve to be included in the Central list of backward classes
as the community is not socially backward but on the
contrary, it is socially advanced and a prestigious community.
The Khatri Commission was constituted in 1995 by the State
of Maharashtra which submitted its report in absence of the
President Shri Khatri but the Commission by majority view
held that Marathas may not be included as 'Kunbis' in the list
of Other Backward Classes but it opined that people who have
entered as 'Kunbi-Maratha' or Maratha-Kunbi should get
benefit of Kunbi caste and accordingly, certificates in their
names should be issued.              The Government of Mahrashtra
accepted the recommendation of the Commission by issuing
Government Resolution on 1st June 2004.                         Resultantly,Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Maratha-Kunbi and Kunbi-Maratha in addition to the earlier
recognized caste Kunbi (Leva Kunbi, Leva Patil and Leva
Patidar) came to be recognized as Other Backward Classes.
On 23rd August 2004, Bapat Commission came to be appointed
to include Maratha community in Other Backward Class. The
majority view of the Commission by 4 - 2 resolved on 25 th July
2008 that it would not be proper to include Maratha
patil-sachin.
::: Uploaded on - 27/06/2019                ::: Downloaded on - 28/06/2019 05:25:20 :::
                                        176                            Marata(J) final.doc
community in Other Backward Classes from the view point of
principles of social justice and a negative report was
submitted.           After receipt of this report, the Government of
Maharashtra constituted a Committee under the Chairmanship
of Shri Narayan Rane, the then Minister (Industries Ports and
Employment and Self Employment) to consider the report of
the Bapat Commission and to make recommendations.                                     The
Committee concluded that the findings recorded by Bapat
Commission were not based on quantifiable data and decided
not to accept the 22nd Report of the Bapat Commission.                                      It
independently              collected       contemporary       quantifiable           data
relating to the community and concluded and Maratha
community             is       socially,   educationally     and       economically
backward.             It requested the State to include Maratha
community in Other Backward Class                       and to give separateDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

16% reservation on the basis of the population of Maratha i.e.
the quantifiable data.
                 It is also to be noted that when the State enacted
the Maharashtra State Public Services Act of 2001 and also
the Maharashtra Private Professional Educational Institutions
Act of 2006, it did not provide any reservation either in
services or in the educational field to the said community. The
patil-sachin.
::: Uploaded on - 27/06/2019                         ::: Downloaded on - 28/06/2019 05:25:20 :::
                                    177                            Marata(J) final.doc
demand of             Maratha community to provide reservation in
public employment and in the field of education was on the
rise and in light of the Rane Committee Report, which
contained positive recommendation, the State took a policy
decision and translated it into a legislation to provide 16%
reservation to Maratha community without disturbing                                the
existing reservation and this was extended to the educational
institutions and to the posts in public services under the State.
The Governor of Maharashtra on 9 th July 2014 promulgated the
Maharashtra State Reservation (of seats for admissions in
educational institutions in the State and for appointments or
posts in the public services under the State) for Educationally
and Socially Backward Category (ESBC) Ordinance, 2014.
This was replaced by ESBC Act of 2014 (Maharashtra Act No.I
of 2015). The constitutional validity of the said ordinance andDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

the enactment was assailed before this Court and by an order
dated 7th April 2015, this Court was pleased to stay the
implementation of the said Act.
39               Thereafter,   a     reference      was       made         to      the
Maharashtra             Backward     Class   Commission              under         the
Chairmanship of Late Justice S.B. Mhase (Retd) by the State
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:20 :::
                                       178                              Marata(J) final.doc
Government on 4th January 2017 with the following terms of
reference:-
      (1)       Determine         the       contemporary              criteria         and
                parameters to be adopted in ascertaining the social,
                educational        and      economic           backwardness               of
                Marathas for extending the benefit of reservation
                under the constitutional provision keeping in focus
                the various judgments of the Courts, reservation
                laws and constitutional mandate.
      (2)       Define the exceptional circumstances and extra-
                ordinary       situation    applied      for     the     benefits         of
                reservation in the contemporary scenario.
      (3)       Scrutinize and inspect the quantifiable data and
                other information which the State has submitted to
                the Court to investigate backwardness of Maratha
                community
      (4)       Determine the representation of Marathas in State/
                Employment and ;
      (5)       Ascertain       the    proportion     of     the     population           of
                Maratha community in the State by collecting the
                information available under various sources.
                 However, as the Commission was in progress,Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Justice S.B. Mhase expired and therefore, by notification dated
2nd November 2017, Justice Gaikwad (Retd) took over the reins
of the Commission. The Commission was constituted in terms
patil-sachin.
::: Uploaded on - 27/06/2019                          ::: Downloaded on - 28/06/2019 05:25:20 :::
                                       179                               Marata(J) final.doc
of Act 2005 and comprised of 11 Members and included a
Member           Secretary.          It    comprised      of     Social       Scientists,
statisticians socialists, analyst to interpret the sample survey
data and information and collate the findings with other
temporary surveys undertaken in the State by the said
departments, Government agencies, previously constituted
constituents           of      the   Maharashtra       State       Backward          Class
Commission, so as to analyse that the historical data, case
studies and submit its report in terms of the reference.
Commission submitted the report to the State Government on
15th November 2018 and it, inter alia, came to the conclusion
that Maratha class of citizens in the State are socially,
educationally and economically backward and are eligible to
be included in the backward class category on the basis of
their      backwardness.                  The   Commission          considered           the
backwardness of this community qua its representation in
public          employment,          presence     in   higher        and      technical,
academic institutions as teachers and students and assessed
its social status as well as educational and economic statusDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

through sample survey and by allocation of a weightage of
marks.
patil-sachin.
::: Uploaded on - 27/06/2019                           ::: Downloaded on - 28/06/2019 05:25:20 :::
                                   180                            Marata(J) final.doc
40                Relying on the report of the Commission, Bill No.
LXXVIII of 2018 to provide for reservation of seats for
admissions in educational institutions in the State and for
reservation of posts for appointments in public services was
introduced. The Bill incorporated the recommendation of the
Commission and we reproduce the same as under :
                (A)       Backwardness -
                (1)    Maratha class of citizens in the State are socially,
                Educationally and Economically Backward as the
                community obtained weightage of 21.5 marks out of the
                maximum 25.
                (2)     Maratha class of citizens are eligible to be
                included in the backward class category on the basis of
                their backwardness.
                (B)     Representations in public employment -
                        Representation of Marathas in the State Public
                Employment in Higher Grade of A, B, C and D is found to
                be inadequate not only as a proportion of their State
                population share of around 30% but also because of
                inadequacy in the number of graduates which is the
                minimum educational qualification for these grade of
                public posts.
                (C)      Presence in Higher and technical,               academic
                institutions as teachers and students :-
                (1)     Presence of Maratha community in pursuant of
                academic career as professors and such others positions
                of academic excellence is very marginal. On an averageDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                4.30% academic and teaching posts are occupied by
                persons of Maratha community which is having 30%
                population across the State.
                (2)     Lack of conventional degree level education in
                landing them in lowly labour oriented employment such
                as mathadis, hamals, dabewalas, etc.
patil-sachin.
::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:20 :::
                                    181                             Marata(J) final.doc
                (3)     Low earning and livelihood engagements of
                seasonal requiring temporary or permanent migration to
                urban ghettos which impacts the smooth schooling and
                school attendance by their children.
                (D)       Computation of Maratha population :-
                        The average Maratha population proportion taking
                the base of various population censuses, a special survey
                taken up by the Planning Department of the State
                (32.14%), the special survey taken up by the Rural
                Development Department of the State Government,
                Social, Economic and Castes survey information of the
                Rural Development Department of the Government of
                India (27%) and the findings of sample survey of the
                Maharashtra State Backward Class Commission confirmed
                the average of 30% Maratha population against the total
                State population.
                (E)       Social Status of Marathas :-
                (1)      Around 76.86% of Maratha families have been
                found to be engaged in agriculture and agricultural labour
                for their livelihood.
                (2)    Around 65% of Marathas are in Government or
                Semi Government Services. Most of these positions are
                occupied in the Group-D State Services.
                (3)     Around 70% of the Maratha families are found to
                be residing in kachcha dwellings.
                (4)    Only 35.39% of the Maratha                  families       have
                personal tap water connections.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                (5)     Around 31.79% of Maratha families are found to
                be relying on traditional sources of firewood, cow dung
                and agricultural wastage as the fuel for the cooking in
                domestic use.
                (6)     During the period 2013-18, a total of 2152
                (23.56%) Maratha farmers have committed suicides as
                against the total farmers suicides 13.368.
                (7)    The impact of archive social traits, practices,
                customs and traditions are still found to be prevalent
                amongst Maratha community.
patil-sachin.
::: Uploaded on - 27/06/2019                      ::: Downloaded on - 28/06/2019 05:25:20 :::
                                    182                            Marata(J) final.doc
                (8)     As to the perception towards different kind of
                backwardness, 73% Marathas feel that they have been
                infected by all the 3 types of backwardness i.e. social,
                educational and economic.
                (9)     The rampant migration of Marathas from rural to
                urban areas has been found to be picked up in last ten
                years as revealed from the survey of the Maharashtra
                State Backward Class Commission.      A member from
                around 21% Maratha families have migrated to urban
                areas in search of livelihood landing them in labour
                intensive lowly occupations like Mathadi, Hamal,
                Dabbewala, Maid servant, Port workers etc. This clearly
                indicated the depleting social status of Marathas in
                Contemporary context.
                (10)     Status of a women in any community is most
                significant parameter of the social backardness or
                forwardness of the social class. In this regard, persuasion
                of physical labour led activities or occupation or
                employment for livelihood earnings has been found to be
                most dominant component to gauze the social
                backwardness of the community. It found in the survey
                that 88.81% of Maratha women are involved in physical
                labour for earning livelihood, of course not including the
                physical domestic work they perform for the family.
                        Looking to the significance of this important
                parameter as to the female in the community engaged in
                physical labour for livelihood or wages or occupation orDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                employment in assessing the social backwardness of the
                community, the Maharashtra State Backward Class
                Commission has allocated weightage of three marks to
                this parameter which has been specified to be at least 5%
                more of the State Average Percentage of female engaged
                in the physical labour.
                (F)       Educational Status of Marathas :-
                        The    Maharashtra    State    Backward     Class
                Commission has assessed and evaluated the educational
                status of Marathas through the sample survey and has
                allocated a weightage of 8 marks out of total 25 marks for
                the educational backwardness of the community. There
                are 13.42% illiterates, 35.31% primary educated,
                432.79% H.S.C and S.S.C. 6.71% under graduates and
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:20 :::
                                    183                            Marata(J) final.doc
                post graduates and 0.77% technical and professional
                qualified amongst Maratha community.
                (G)       Economical Status of Maratha :-
                (1)    Around 93% of Maratha families have an annual
                income of 1,00,000 which is much below the average
                income of middle class families. It reflects the subdued
                economic status of Maratha community.
                (2)     The percentage of Below Poverty Line (B.P.L)
                families amongst the Marathas as per survey has been
                found to be 37.28% against the State average of 24.2%.
                (3)      The percentage of landless and marginal farmers
                (lands ownership less than 2.5 acres) is found to be
                around 71% amongst the Maratha families whereas the
                percentage of big farmers holding about 10 acres of land
                is only 2.7%.
                (H)     Extra-ordinary situations and circumstances for
                crossing of 50% limit of reservations
                (1)      The Maharashtra State Backward Commission has
                come to the conclusion that an extra-ordinary situation
                has developed in the State with regard to the reservationDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                allocation     and     the     emerging     extra-ordinary
                circumstances, particularly after having declared Maratha
                community with 30% proportion of the State population
                as a socially and educationally backward on the basis of
                the quantifiable data and its consequential entitlement to
                the Constitutional reservation benefits. The existing limit
                of 50% reservation for State Public Employment and the
                admissions to the State educational institutions will have
                to be reconsidered on the background of the extra
                ordinary situation and exceptional circumstances.
                (2)     After declaring Marathas a socially, educationally
                and economically backward class of the citizens, the total
                percentage of the state population entitled to the
                constitutional benefits and advantages as listed under the
article 15(4) and the article 16(4) will be around 85%.
                This is a compelling extra-ordinary situation demanding
                extra-ordinary solution within the constitutional frame
                work.
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:20 :::
                                  184                             Marata(J) final.doc
                         Added to that, the judicial verdicts have
                categorically pronounced that the reservation policy
                frame and constitutional mandate as regards SCs and STs
                is so sacrosanct that there is no need of quantifiable data
                or its verification whatsoever.      It has also to be in
                proportion to their population needing no distinction to be
                made as regards adequate vis-a-vis proportionate as to be
                done in case of reservations to other backward class of
                citizens. Therefore, the scenario that emerges would be to
                accommodate remaining 63% (85% - 22%) backward
                class population in remaining 29% reservation allocation
                as condition by the ceiling of 50%. This is an extra-
                ordinary situation and exceptional circumstances
                emerging in the State.
                (3)      As per the total census figures 4.62% jobs are
                available per 100 youth in public services. As the
                average recruitment per year is not more than 5% of the
                total job in the State, the availability ratio goes down to
                0.23% less than 1 job per 100 eligible youth. If this job
                scenario is restricted in a manner that only 5% of 0.23%
                i.e. 0.12 jobs per recruitment year will be available to
                95% population and remaining 0.12 jobs to a populationDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                of 5% unreserved class of forward citizenry youth is a
                mockery of the reservation principle in state public
                employment, a constitutionally treachery with the
                backward class of youth aspiring for public employment.
                This extra-ordinary situation warrants the enhancement of
                the reservation percentage beyond 50%.
                (4)     Keeping 50% ceiling intact but allowing more and
                more class of citizenry to be accommodated in 50%,
                rather only in 27% reservation quota is in a way favouring
                the miniscule forward class of the society to enjoy their
                age old social and educational dominance in perpetuity
                again at the cost of majority class of population.
                (5)     The Marathas are the most sufferers of not
                allowing the breach of 50% reservation limit on one hand
                and tagging them with the Forward Class of Citizens to
                face the unequal competition with them on the other
                hand. They, in fact, had been included in backward
                category before independence and till the year 1952 even
                after independence being included in Intermediate Caste
                Category, an old version of the new incarnation of Socially
                and Educationally Backward Class of Citizen (SEBC).
patil-sachin.
::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:20 :::
                                  185                            Marata(J) final.doc
                (6)     While most of the other Caste groups then
                included in the intermediate caste category along with
                the Marathas or even those not finding place in the
                intermediate caste category then have been now included
                in the existing list of backward classes, the Marathas had
                been excluded without any reasoning and tagged with
                Forward Class of Citizens to face a stiff unequal
                competition. The consequences are there to see as much
                as the Marathas are not able to obtain adequate
                proportion of either the State Public Employment posts or
                adequate number of admission to the higher and
                technical educational institutions, most of them being
                concerned by the Forward Classes and even by the
                reserved category candidates competition for merit
                quota. Now, after a long gap, the deprived Maratha
                community is on the verge of getting re-included in the
                backward class category. However, the backward class
                communities already included in the OBC list, if abruptly
                asked to share their well-established entitlement ofDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                reservations with a 30% Marathas Citizenry, it would
                certainly be a catastrophic scenario creating an extra
                ordinary situation and exceptional circumstances which if
                not swiftly and judiciously addressed, may lead to
                unwarranted repercussions in the well set harmonious co-
                existence culture of the State.
                        Thus, an urgent need to give due justice to a duly
                recognized new backward class of citizenry; Marathhas
                who have already been suffering a double jeopardy for
                decades and now expecting a justice and ensuring
                already included backward communities that they will not
                be deprived of their reservation advantages and benefits,
                is certainly an extra ordinary situation and has created
                exceptional circumstances which cannot be harmoniously
                resolved unless the ceiling of 50% imposed on the
                reservation is reconsidered.       This is the only way
                available in the contemporary situation to harmoniously
                resolve the exceptional circumstances being faced by the
                State.
                Based on above findings as well as other conclusions
                drawn by the said Commission, the Commission has
                recommended as under :-
                 (1)    The Maratha Class of Citizens is declared as
                 Socially and Educationally Backward Class of Citizens
patil-sachin.
::: Uploaded on - 27/06/2019                   ::: Downloaded on - 28/06/2019 05:25:20 :::
                                 186                            Marata(J) final.doc
                (SEBC) and has inadequate         representation          in the
                services under the State.
                (2)    Maratha Class of Citizens having been declared
                Socially and Educationally Backward Class of Citizens
                are entitled to reservation benefits and advantages
                enshrined in the Article 15(4) and 16(4) of the
                Constitution of India.
                (3)   Looking to the exceptional circumstances and
                extra ordinary situations generated on declaring
                Maratha Class of Citizens as Socially and Educationally
                Backward and their consequential entitlement to the
                reservation benefits, the Government may take an
                appropriate decision within the constitutional provisions
                to address the emerging scenario in the State.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

41               Report of the Commission formed the basis for the
Bill which was accompanied with the Statements of Objects
and Reasons (SOR) and it made reference to the enabling
power of the State under Clause (4) of Article 15 of the
Constitution which enabled the State to make any special
provision for advancement of socially and educationally
backward class of citizens and it also made reference to
clause (5) of Article 15 which enabled the State to make
special provisions by law for advancement of SEBC, insofar as
such special provisions relate to their admission to educational
institutions including private educational institutions, whether
aided or unaided by the State.             It also made reference to
clause (4) of Article 16 of the Constitution which enabled the
patil-sachin.
::: Uploaded on - 27/06/2019                  ::: Downloaded on - 28/06/2019 05:25:20 :::
                                   187                            Marata(J) final.doc
State to make provision             for reservation of appointments of
posts in favour of any backward class of citizens, which in the
opinion of the State is not adequately represented in the
services under the State.            After reproducing the conclusions
derived by the Commission and making a reference to its
recommendations, the Statements of Objects and Reasons
proceeds to state as follows :
                 9.          The Government of Maharashtra hasDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                 considered the report, conclusions, findings and
                 recommendations of the said Commission. On the
                 basis of the exhaustive study of the said
                 Commission on various aspects regarding the
                 Marathas, like public employment, education, social
                 status, economical status, ratio of population, living
                 conditions, small size of land holdings by families,
                 percentage of suicide of farmers in the State, type
                 of works done for living, migration of families, etc.,
                 analysed by data, the Government is of opinion
                 that:-
                      (a)    the Maratha Community is socially and
                      educationally backward and a backward class
                      for the purposes of Article 15(4) and (5) and
article 16(4), on the basis of quantifiable data
                      showing     backwardness,      inadequacy       in
                      representation by the said commission :
                         (b)   having regard to the exceptional
                         circumstances and extraordinary situation
                         generated on declaring Maratha as socially
                         and    educationally     backward    and    their
                         consequential entitlement to the reservations
                         benefits and also having regard to the
                         backward class communities already included
                         in the OBC list, if abruptly asked to share their
                         well established entitlement of reservation
                         with a 30% of Maratha citizenry, it would be a
patil-sachin.
::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:20 :::
                                    188                            Marata(J) final.doc
                         catastrophic       scenario     creating     an
                         extraordinary     situation   and    exceptional
                         circumstances, which if not swiftly and
                         judiciously     addressed,    may     lead    to
                         unwarranted repercussions in the well
                         harmonious co-existence in the State, it is
                         expedient to relax for the percentage of
                         reservation by exceeding the limit of 50%, for
                         advancement of them, without disturbing the
                         existing fifty-two percent reservation currently
                         applicable in the State, only for those who are
                         not in creamy layer;
                          (c) it is expedient to provide for 16 per cent.
                          of reservation to such category :Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                          (d) It is expedient to make special provision,
                          by law, for the advancement of any Socially
                          and Educationally Backward Classes of
                          citizens, in so far as admission to educational
                          institutions,    other   than   the    minority
                          educational institutions, is concerned but
                          such special provisions shall not include the
                          reservation of seats for election to the Village
                          Panchayats,       Panchayat    Samitis,     Zilla
                          Prishadas, Municipal Councils, Municipal
                          Corporations, etc;
                          (e) It is expedient to provide for reservation
                          to such category in admissions to educational
                          institutions including private educational
                          institutions whether aided or unaided by the
                          State, other than minority educational
                          institutions referred to in clause (1) of article
                          30 of the Constitution; and in appointments in
                          public services and posts under the State,
                          excluding reservations in favour of Scheduled
                          Tribes candidates in the Scheduled Areas of
                          the State under Fifth Schedule to the
                          Constitution of India, as per the notification
                          issued on the 09th June 2014 in this behalf;
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:21 :::
                                        189                             Marata(J) final.doc
                          (f) by providing reservation to the Maratha
                          community, the efficiency in administration
                          will not be affected, since the Government is
                          not diluting the standard of educational
                          qualification for direct recruitment for this
                          category and there will definitely be
                          competition     amongst     them   for  such
                          recruitment; and
                          (g) to enact a suitable law for the above
                          purposes.
                       In view of the above, the State Government is
                 of the opinion that the persons belonging to such
                 category below the Creamy Layer need special helpDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                 to advances further, in the contemporary period, so
                 that they can move the a stage of equality with the
                 advanced sections of the society, whereform they
                 can proceed on their own.
                 10. The Bill            seeks   to      achieve          the      above
                 objectives.
42               Considering the report, conclusions, findings and
recommendations                  and    on   examining           various         aspects
pertaining          to     the    Maratha    community,            including          their
participation in public employment and education, their social
and economic status, ratio of population, living conditions,
small size of land holdings by families, percentage of suicide
of farmers in the State, migration of families etc, the
Government formed an opinion which is reflected in the
Statement of Objects and Reasons of the SEBC 2018 Act. The
Bill was introduced by the State Government on 29 th
patil-sachin.
::: Uploaded on - 27/06/2019                          ::: Downloaded on - 28/06/2019 05:25:21 :::
                                           190                              Marata(J) final.doc
November 2018 and it was unanimously passed by both the
houses of the State legislature on 29 th November 2018. On
30th November 2018, the Hon'ble Governor of Maharashtra
accorded his assent to the Bill granting 16% reservation to
Maratha community.
                 The question which falls for our consideration                               in
the group of petitions listed before us is the identification of
Maratha community as a 'Backward Class' and providingDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

reservation of seats to the said class for admission in
educational institutions and to the posts for appointments in
public services by categorizing the community as "Socially
and Educationally Backward Classes of Citizens".
            SALIENT FEATURES OF THE SEBC ACT, 2018
43               The Maharashtra Act referred to as SEBC Act 2018
is an enactment to provide reservation of seats for admission
in educational institutions in the State and for reservation of
posts for appointment in public service and the posts in the
State to the socially and educationally backward classes of
citizens        (SEBC)         in   the     State    of   Maharashtra             for    their
advancement              and        for    matters    connected            therewith          or
incidental thereto. The enactment contains the following
definition :-
patil-sachin.
::: Uploaded on - 27/06/2019                              ::: Downloaded on - 28/06/2019 05:25:21 :::
                                  191                             Marata(J) final.doc
Section 2(i) and 2(j) reads thus :
                 (i)  "reservation" means the reservation of seats, for
                 admission in educational institutions and of posts for
                 appointments in the public services and posts to the
                 members of Socially and Educationally Backward
                 Classes of Citizens (SEBC) in the State ;
                 (j)     "Socially and Educationally Backward Classes of
                 Citizens (SEBC)" includes the Maratha Community
                 declared to be Educationally and Socially Backward
                 Category (ESBC)in pursuance of the Maharashtra State
                 Reservation (of seats for admission in educational
                 institutions in the State and for appointments or posts
                 in the public services under the State) for EducationallyDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                 and Socially Backward Category (ESBC) Act, 2014.
Section 3 reads thus:
                 3. (1) This Act shall apply to all the direct recruitments,
                 appointments made in public services and posts in the
                 State except,--
                        (a) the super specialized posts in Medical,
                        Technical and Educational field ;
                        (b) the posts to be filled by transfer or deputation
                        ;
                        (c) the temporary appointments of less than
                        forty-five days duration;
                        and
                        (d) the post which is single (isolated) in any cadre
                        or grade.
                 (2) This Act shall also apply, for admission in
                 educational institutions including private educational
                 institutions, whether aided or un-aided by the State,
                 other than the minority educational institutions referred
                 to in clause (1) of article 30 of the Constitution of India.
                 (3) The State Government shall, while entering into or
                 renewing an agreement with any educational institution
                 or any establishment for the grant of any aid as
                 provided in the explanation to clauses (d) and (e) of
section 2, respectively, incorporate a condition for
                 compliance with the provisions of this Act, by such
                 educational institution or establishment.
patil-sachin.
::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:21 :::
                                    192                             Marata(J) final.doc
                 (4) For the removal of doubts it is herby declared that
                 nothing in this Act shall affect the reservation provided
                 to the Other Backward Classes under the Maharashtra
                 State Public Services (Reservation for Scheduled
                 Castes, Scheduled Tribes, De-notified Tribes (Vimukta
                 Jatis), Nomadic Tribes, Special Backward Category and
                 Other Backward Classes) Act, 2001 and the
                 Maharashtra      Private      Professional    Educational
                 Institutions (Reservation of seats for admission for
                 Scheduled Castes, Scheduled Tribes, De-notified Tribes
                 (Vimukta Jatis), Nomadic Tribes and Other Backward
                 Classes) Act, 2006.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                 Crucial section is section 4 which reads thus
                 4. (1) Notwithstanding anything contained in any
                 judgment, decree or order of any Court or other
                 authority, and subject to the other provisions of this
                 Act,-
                          (a) sixteen per cent. of the total seats in
                          educational      institutions   including     private
                          educational institutions, whether aided or un-
                          aided by the State, other than minority
                          educational institutions referred to in clause (1) of
article 30 of the Constitution of India ; and
                          (b) sixteen per cent. of the total appointments in
                          direct recruitment in public services and posts
                          under the State, shall be separately reserved for
                          the Socially and Educationally Backward Classes
                          (SEBC) including the Maratha Community :
                 Provided that, the above reservation shall not be
                 applicable to the posts reserved in favour of the
                 Scheduled Tribes candidates in the Scheduled Areas of
                 the State under the Fifth Schedule to the Constitution of
                 India as per the notification issued on the 9th June 2014
                 in this behalf.
                 (2) The principle of Creamy Layer shall be applicable
                 for the purposes of reservation to the Socially and
                 Educationally Backward Classes (SEBC) under this Act
                 and reservation under this Act shall be available only to
                 those persons who are below Creamy Layer.
patil-sachin.
::: Uploaded on - 27/06/2019                      ::: Downloaded on - 28/06/2019 05:25:21 :::
                                 193                           Marata(J) final.doc
                 Explanation.--For the purposes of this sub-section, the
                 expression "Creamy Layer" means the person falling in
                 the category of Creamy Layer as declared by the
                 Government in the Social Justice and Special Assistance
                 Department, by general or special orders issued in this
                 behalf, from time to time.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Section 5 further declare that notwithstanding anything
contained in Section 4, the claims of students or members
belonging to SEBC, shall also be considered for allotment on
unreserved seats and appointments in public services and
posts which are to be filled on the basis of merit and whether
a student or member belonging to such classes is selected on
the basis of merit, the number of seats and appointments
reserved for SEBC shall not, in an way, be affected. Section 7
provides for carrying forward of the reserved vacancies upto
five years of direct recruitment and sub-section n(2) classifies
that where the vacancy is carried forward, it shall not be
counted against the quota of the vacancies reserved for the
concerned classes of persons for the recruitment year to
which it is carried forward. Section 8 casts a responsibility on
the authorities of ensuring the compliance of the provisions of
the Act and Section 9 imposes a penalty for acting in
contravention or in a manner which would defeat the purpose
of the Act. Section 16 provides for a Savings clause and reads
patil-sachin.
::: Uploaded on - 27/06/2019                 ::: Downloaded on - 28/06/2019 05:25:21 :::
                                    194                             Marata(J) final.doc
thus :-
                 16. (1) The provisions of this Act shall not apply to the
                 cases in which selection process has already been
                 initiated before the commencement of this Act, and
                 such cases shall be dealt with in accordance with the
                 provisions of law and the Government orders as theyDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                 stood before such commencement.
                 Explanation.--For the purposes of this section, the
                 selection process shall be deemed to have been
                 initiated where, under the relevant service rules,--
                          (i) recruitment is to be made on the basis of
                          written test or interview only, and such written
                          test or the interview, as the case may be, has
                          started ; or
                          (ii) recruitment is to be made on the basis of
                          both, written test and interview and such written
                          test has started.
                 (2) The provisions of this Act shall not apply to
                 admissions in educational institutions and the cases in
                 which the admission process has already been initiated
                 before the commencement of this Act and such cases
                 shall be dealt with in accordance with the provisions of
                 law and the Government orders, as they stood before
                 such commencement.
                 Explanation.--For the purposes of this section, the
                 admission process shall be deemed to have initiated
                 where,--
                          (i) admission is to be made on the basis of any
                          entrance test, and procedure for such entrance
                          test has started ; or
                          (ii) in case of admission to be made other than on
                          the basis of entrance test, the last date for filling
                          up the application form is lapsed.
Section 18 set out the provision of repeal and saving and it is
declared that on commencement of the Act, the SEBC Act of
patil-sachin.
::: Uploaded on - 27/06/2019                      ::: Downloaded on - 28/06/2019 05:25:21 :::
                                           195                              Marata(J) final.doc
2014 shall stand repealed.                      This is coupled with the saving
clause in form of sub-section (2).Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

44               This impugned Enactment is assailed before us.
(III) Whether                  the        impugned         Act        of       2018          is
constitutionally                invalid         on    account        of      legislative
competence on the following sub-heads:-
      (a)       Subsisting interim order passed by the
                Bombay High Court in the writ petition filed by
                Sanjeet Shukla (WP No.3151 of 2014)
      (b)       Whether the 102nd Constitution Amendment
                deprives the State legislature of its power to
                enact a legislation determining the SEBC and
                conferring the benefits on the said community
                under its enabling power ?
      (c)       The limit of 50% laid down in Indra Sawhney
                being an accepted constitutional principle,
                reservation in excess of 50% can be provided
                only in exercise of the constituent power of
                the Parliament.
45               There         is     a    presumption        in     favour         of     the
constitutionality of the enactment and burden to prove an
enactment to be constitutionally invalid is on the person who
attacks its validity.
                 Learned counsel for the petitioners have bifurcated
the      argument          of       legislative      competency         on     the       State
patil-sachin.
::: Uploaded on - 27/06/2019                             ::: Downloaded on - 28/06/2019 05:25:21 :::
                                196                           Marata(J) final.doc
legislature into three issues.       The first issue being raised by
Mr. Datar is that in the wake of the interim order passed by
the Bombay High Court in case of Sanjit Shukla dealing withDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

the reservation of Marathas and Muslim community in the
year 2014 is a binding precedent and since the substratum of
the judgment is not removed, the present enactment is in the
teeth of the interim order. Shri Datar has placed reliance on
the judgment in case of Cauvery Water Disputes Tribunal
(supra) in support of his submission that even an interim
order is binding and since the State has not removed the base
of the judgment, the power which the State legislature has
arrogated          to itself overrides the binding precedent of this
Court. Per contra, learned counsel Shri Thorat has submitted
that Sanjeet Shukla is a judgment rendered at an interim
stage on the basis of pleadings so filed for interim relief and
the observations made by the Court are prima facie. The said
judgment, according to Shri Thorat, is based on a prima facie
observation and according to him, the power to legislate is
distinct and separate from being ultra vires of the Constitution
or otherwise invalid.          He would submit that it is settled
position of law that it is always permissible to remove a defect
in a judgment and if such defect is removed, the statute
patil-sachin.
::: Uploaded on - 27/06/2019                ::: Downloaded on - 28/06/2019 05:25:21 :::
                                   197                               Marata(J) final.doc
cannot be said to nullify a judgment or over-rule the same. He
would place reliance on a judgment of the Hon'ble Apex Court
in case of Medical Council of India Vs. State of Kerala18,Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

to the effect that it is permissible under the Constitution to
remove a defect in the judgment and legislature has a power
to retrospectively amend the laws and remove the causes of
ineffectiveness or invalidity on which the judgment is based.
46               We have carefully considered the said submissions
of the respective counsel. We have noted that the State has,
on earlier occasion, enacted a similar legislation, classifying
the Maratha as Educationally and Socially Backward classes
(ESBC) and the said enactment came to be assailed.                                  The
finding of this Court by way of an interim order dated 14 th
November 2014 is carefully scrutinized by us.                         The Division
Bench headed by Justice Mohit Shah, (Chief Justice, as he was
then), dealt with the issue whether Marathas can be
considered           as    'Backward    classes'    framed         the      following
issues :-
         Whether Marathas can be considered as 'backward
classes' eligible to the benefits of reservation under Article
18 2018 SCC Online SC 1867
patil-sachin.
::: Uploaded on - 27/06/2019                       ::: Downloaded on - 28/06/2019 05:25:21 :::
                                         198                           Marata(J) final.doc
15 and 16 of the Constitution of India ? If Yes, whether there
exists          any    exceptional        circumstances       or     extra-ordinary
reasons to grant reservation to the extent of 16% to theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Marathas,             thereby         increasing   existing        percentage            of
reservation from 52% to 68%.                  The Court then expressed that
if the first question is answered in the affirmative, then only
the second question would arise. Since the matter was at the
stage of interim relief, it will have to express prima facie view
on both the questions. On the first issue, the Division Bench
made reference to the second report of the Backward Class
Commission (Mandal Report) which categorizes Maratha as a
Foward Hindu Caste. It also made reference to the report of
the National Commission for Backward Class dated 25 th
February 2000 which had specifically rejected the request for
inclusion of Maratha caste in the Central list of backward
classes as Marathas is socially advanced and prestigious
community.               It    also    made    a   reference       to     the     Bapat
Commission report. After making a reference to the report of
the Commissions and several gazetteers, the Court also made
a reference to the report of Rane Committee constituted by
the Government Resolution dated 21st March 2013.                                      The
Division Bench noted several glaring flaws in the said report
patil-sachin.
::: Uploaded on - 27/06/2019                         ::: Downloaded on - 28/06/2019 05:25:21 :::
                                   199                             Marata(J) final.doc
and at the very same outset, commented that the very
composition of the Committee was not certainly of the type
which the Supreme Court had in contemplation as expressedDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

in Indra Sahwney when it recommended establishment of a
National and a State Backward Class Commission and
secondly,         it   noted    that    the   Rane   Committee            hurriedly
conducted survey in just about 11 days and it did not consider
the legal position laid down by the majority in Indra Sawhney
that 50% is a binding rule and not merely a rule of prudence.
The report of Rane Committee was also further criticized on
the ground that the State will have to see that the reservation
provision does not lead to excessiveness so as to breach the
ceiling limit of 50% and the Committee had fallen in error in
concluding that Maratha community is educationally and
socially backward.             Then, the Division Bench proceeded to
answer the second point and concluded that there are no
extra-ordinary situations or circumstances which would justify
providing reservation in               excess of 50%.      Reference is also
made by the Division Bench to S.V. Joshi's case (supra) which
referred to quantifiable data being was one of the essential
pre-requisites in order to justify the reservation in excess of
50%. However, it also made a reference to the observation of
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:21 :::
                                        200                              Marata(J) final.doc
the Supreme Court, which after noting a decision of State of
Karnataka and State of Tamil Nadu which was not based on
quantifiable data stayed the implementation of reservation inDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

excess of 50% and directed the State Government to place the
quantifiable data before the respective State Backward
Classes Commission for                       fresh consideration.              With the
aforesaid findings, the Division Bench stayed the impugned
ordinance           thereby          reserving     16%      seats       for      Maratha
community.
                 It is no doubt true that the prima facie opinion was
expressed by the Division Bench while pronouncing its verdict
on 14th November 2014.                         However, at present,               we are
dealing with the SEBC Act, 2018 and the statements                                         of
objects and reasons make a reference to the interim order and
that the State has decided to constitute a State Backward
Class Commission to determine the contemporary criteria and
parameters            to       be    adopted     in   ascertaining         the      social,
educational            and          economic     backwardness            of      Maratha
community for extending benefit of reservation under the
Constitutional             provision      keeping      in    focus       the      various
judgments            of        the    Court,     reservation       laws        and       the
constitutional mandate and also to define the exceptional and
patil-sachin.
::: Uploaded on - 27/06/2019                           ::: Downloaded on - 28/06/2019 05:25:21 :::
                                   201                             Marata(J) final.doc
extra-ordinary situation applied for the benefits of reservation
in the contemporary scenario.                  The Commission was also
directed to scrutinize and accept a quantifiable data which theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

State       has      submitted    to    the   Court    to    investigate           the
backwardness of the community.                   In this backdrop of the
reference, the Commission appointed panel of experts, social
scientists, statisticians and sociologists from the Government
and various universities to analyze and interpret the sample
survey data and information and collate the findings with the
other       contemporary         surveys      undertaken       by      the     State
Departments, Government agencies, previously constituted
Commissions.              The Commission submitted its report to the
Government on 15th November 2018 and it clearly referred to
the backwardness of the Maratha community by taking into
consideration various aspects i.e. their representation in
public employment, presence of Maratha community in higher
and technical, academic institutions as teachers and students
and by determining its social status by applying the necessary
indicators.          It also determined the educational status and
economical status of the Marathas and not only this, the
Commission highlighted the extra-ordinary situations and
circumstances for crossing the 50% limit of reservation after
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:21 :::
                                     202                              Marata(J) final.doc
recording a finding that the total percentage of Marathas in
the State population being 30%, the backward classes
constitute 85% of the population and this entire class isDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

entitled for the benefits under Article 15(4) and 16(4) and this
according to the Commission, is the existing compelling extra-
ordinary situations demanding extra-ordinary solution within
the constitutional framework. The Commission also analyzed
the extra-ordinary situation where keeping 50% ceiling intact
but allowing more and more class of citizenry to be
accommodated in 50%, miniscule forward class of society to
enjoy their social and educational dominance in perpetuity at
the cost of majority class of population. Since the Commission
in its exhaustive report based on quantifiable data and on
scientific analysis of the said data, arrived at a conclusion that
Maratha         class      of   citizens   is   socially    and      educationally
backward class of citizens and has inadequate representation
in the services under the State, it is entitled for reservation
enshrined in Article 15(4) and 16(4) of the Constitution. The
State Government had before it a report of the Gaikwad
Commission and its recommendations whereunder                                 a detail
study of the said community in the backdrop of the public
employment sector, education sector, social and economic
patil-sachin.
::: Uploaded on - 27/06/2019                        ::: Downloaded on - 28/06/2019 05:25:21 :::
                                   203                             Marata(J) final.doc
status of the community, ratio of the population of the
Maratha community, living condition of the community and
based on this quantifiable data, reflecting backwardness andDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

inadequacy in representation, it deemed it expedient to
provide16% reservation to such category by making a special
provision for their advancement, both in the matter of
admission to educational institutions and also for appointment
in public services and posts under the State.                      At the same
time, the State had also taken into consideration the aspect of
efficiency of the administration and that it will not be affected,
since the Government is not diluting the standard of
educational           qualification   for   direct    recruitment         for     this
category and there will be definitely competition amongst
themselves for such recruitment and it would enact a suitable
law for the aforesaid purpose.                       The Government has,
therefore, arrived at a conclusion that the persons belonging
to Maratha community below creamy layer needs special help
to advance further in the contemporary period so that they
can move to a stage of equality with advance sections of the
society, wherefrom they can progress and proceed.                                This
exercise undertaken by the State, after the interim order
passed in the case of Sanjit Shukla justifies the SEBC Act of
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:21 :::
                                       204                            Marata(J) final.doc
2018. The State Government has thus, attempted to remove
the basis of the judgment which earlier held that there was no
quantifiable data before the State before categorizing MarathaDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

community as a backward category and in absence of this
data, the increase in proportion of reservation from 52% to
68% was found to be not justiciable.                    However, the State
Government appointed a Commission, collected a quantifiable
data, analyzed it in a scientific manner and when the
Commission             made     its     recommendation          to      the       State
Government to declare the Maratha community as socially
and       educationally        backward     and    in    this      manner,           the
substratum of foundation of a judgment came to be removed
and the legislature then enacted the impugned enactment
and therefore, it cannot be said that it would be an
encroachment upon judicial power since the legislature has
not directly overruled or reversed a judicial dictum. In case of
Goa Foundation Vs. State of Goa19                             the Apex Court
observed to the following extent :
         "The principles on which first question would require to be
         answered are not in doubt. The power to invalidate a
         legislative or executive act lies with the Court. A judicial
         pronouncement, either declaratory or conferring rights on the
         citizens cannot be set at naught by a subsequent legislative
         act for that would amount to an encroachment on the judicial
         powers. However, the legislature would be competent to pass
19 (2016) 6 SCC 602
patil-sachin.
::: Uploaded on - 27/06/2019                      ::: Downloaded on - 28/06/2019 05:25:21 :::
                                     205                                  Marata(J) final.doc
         an amending or a validating act, if deemed fit, with
         retrospective effect removing the basis of the decision of the
         Court. Even in such a situation the courts may not approve a
         retrospective deprivation of accrued rights arising from a
         judgment by means of a subsequent legislation [MadanDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

         Mohan Pathak and Another vs. Union of India and Others[3]].
         However, where the Court's judgment is purely declaratory,
         the courts will lean in support of the legislative power to
         remove the basis of a Court judgment even retrospectively,
         paving the way for a restoration of the status quo ante.
         Though the consequence may appear to be an exercise to
         overcome the judicial pronouncement it is so only at first
         blush; a closer scrutiny would confer legitimacy on such an
         exercise as the same is a normal adjunct of the legislative
         power. The whole exercise is one of viewing the different
         spheres of jurisdiction exercised by the two bodies i.e. the
         judiciary and the legislature. The balancing act, delicate as it
         is, to the constitutional scheme is guided by well defined
         values which have found succinct manifestation in the views
         of this Court in Bhaktwar Trust & Ors.(supra).
47               Further, in the case of Medical Council of India
vs. State of Kerala (supra) by relying on the earlier
precedents, the Apex Court has held that the legislature has
the power to retrospectively amend the laws and remove the
causes of ineffectiveness or invalidity on which the judgment
is based and that would not be an encroachment upon judicial
power when the legislature does not directly overrule or
reverse         a    judicial    dictum.     Thus,     when        the        cause        of
ineffectiveness            or   invalidity   is   removed,          it      cannot        be
considered as an encroachment upon judicial power.                                      The
legislature has not declared the decision of the Court as
erroneous or a nullity but it has rectified a defect in the law
patil-sachin.
::: Uploaded on - 27/06/2019                         ::: Downloaded on - 28/06/2019 05:25:21 :::
                                   206                           Marata(J) final.doc
which was noticed in the earlier enactment and which was
highlighted while passing the interim order by this Court. AsDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

has been held by their Lordships :-
                This plenary power to bring the statute in conformity
                with the legislative intent and correct the flaw
                pointed out by the court can have a curative and
                neutralizing effect. When such a correction is made,
                the purpose behind the same is not to overrule the
                decision of the court or encroach upon the judicial
                turf, but simply enact a fresh law with retrospective
                effect to alter the foundation and meaning of the
                legislation and to remove the base on which the
                judgment is founded. This does not amount to
                statutory overruling by the legislature. In this
                manner, the earlier decision of the court becomes
                non-existent and unenforceable for interpretation of
                the new legislation. No doubt, the new legislation can
                be tested and challenged on its own merits and on
                the question whether the legislature possesses the
                competence to legislate on the subject matter in
                question, but not on the ground of over-reach or
                colourable legislation."
48               The judgment in case of Cauvery Water Disputes
Tribunal (supra) relied on by Shri Datar                  was based on a
completely different situation and the issue was in regard to
an order of the Tribunal constituted to decide the River Water
Disputes between the State under Article 262 of the
Constitution.           The    Parliament by legislation had created a
Tribunal for adjudication and decision of disputes relating to
river waters and the sanctity given to the decision by the
patil-sachin.
::: Uploaded on - 27/06/2019                   ::: Downloaded on - 28/06/2019 05:25:21 :::
                                    207                          Marata(J) final.doc
Tribunal was emphasized and spelt out in Article 262(2) which
empowers the Central Government to pass a law to prohibitDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

even the Supreme Court from exercising jurisdiction in respect
of such disputes. The Apex Court in the case held that the
operation of Ordinance passed by Karnataka had extra
territorial impact which the State could not do under the
Constitution and the State had taken out on itself to decide
whether the Tribunal had jurisdiction to pass interim orders
and thereafter proceed to pass ordinance nullifying the effect
of interim orders.             The Supreme Court considered all these
aspects and held that the ordinance was beyond legislative
competence. The said judgment is therefore, delivered in the
peculiar facts of the case and the proposition with due respect
to the learned Senior counsel cannot be applied in the present
case where the law is more or less settled.                                In the
circumstances, we do not feel that the State legislature lacked
legislative competence on this count.
                 After we have closed the matter for hearing, the
Hon'ble Supreme Court in Miscellaneous Application No.1151
of 2018 in Civil Appeal No.2368 of 2011 in B.K. Pavitra &
Ors Vs. Union of India & Ors, decided a constitutional
challenge to             the   Karnataka   Extension     of Consequential
patil-sachin.
::: Uploaded on - 27/06/2019                   ::: Downloaded on - 28/06/2019 05:25:21 :::
                                 208                           Marata(J) final.doc
Seniority to Government Servants Promoted on the basis of
Reservation (to the posts in the Civil Services of the State) ActDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

2018.           The law intends to protect consequential seniority of
persons belonging to Scheduled Caste and Scheduled Tribes
promoted under the reservation policy of the State of
Karnataka. The said enactment was preceded in time by the
earlier Enactment of 2002 which was challenged in B.K.
Pavitra Vs. Union of India, 2017 (4) SCC 620. A Two Judges
Bench of the Apex Court held Sections 3 and 4 of the
Reservation Act of 2002 as ultra vires Article 14 and 16 of the
Constitution on the ground that the exercise for determining
inadequacy of representation, backwardness and impact of
overall efficiency had not preceded the enactment of the law
and such an exercise was mandated by M. Nagaraj and in
absence of the quantifiable data being collected on three
parameters, the reservation Act of 2002 was held to be
invalid.
                   One of the foremost ground of challenge to the
enactment of 2018 after invalidation of the earlier enactment
is that the State legislature has virtually re-enacted the earlier
legislation without curing its defect and it was not open to the
patil-sachin.
::: Uploaded on - 27/06/2019                 ::: Downloaded on - 28/06/2019 05:25:21 :::
                                  209                          Marata(J) final.doc
legislature to override a judicial decision without taking away
its basis. This it the exact and precise argument which is putDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

forth before us as regards the impugned enactment and that
the earlier ESBC Act of 2015 came to be stayed by an interim
order passed by this Court in Sanjeet Shukla, and therefore,
the interim order being in force, it is not open for the State to
bring out the new enactment without removing the basis of
the order/ judgment staying the earlier enactment.                           This
submission was extensively dealt and the argument of
legislative competence to render a judgment ineffective was
ruled upon. In point no.(E), His Lordship Justice Chandrachud
has answered the question as to whether the Reservation Act
of 2018 overrule or nullify B.K. Pavitra (I).             It was observed
that judgment in B.K. Pavitra (I) held that no exercise as
mandated by Nagaraj was undertaken by the State of
Karnataka before providing reservation in promotion and
providing consequential seniority and the State had not
collected         quantifiable   data   on   the    three       parameters.
However, this decision did not restrain the State from carrying
out the exercise of collecting quantifiable data so as to fulfill
the conditionalities for the exercise of enabling power under
Article 16(4A) and the legislature has the plenary power to
patil-sachin.
::: Uploaded on - 27/06/2019                 ::: Downloaded on - 28/06/2019 05:25:21 :::
                                    210                            Marata(J) final.doc
enact a law. The following observations render an assistance
to our observations made in a similar situation.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                "The decision in B.K. Pavitra I did not restrain the state
                from carrying out the exercise of collecting quantifiable
                data so as to fulfill the conditionalities for the exercise of
                the enabling power under Article 16(4A).                  The
                legislature has the plenary power to enact a law. That
                power extends to enacting a legislation both with
                prospective and retrospective effect. Where a law has
                been invalidated by the decision of a Constitutional
                Court, the legislature can amend the law retrospectively
                or enact a law which removed the cause for invalidation.
                A legislature cannot overrule a decision of the Court on
                the ground that it is erroneous or is nullity. But, it is
                certainly open to the legislature either to amend an
                existing law or to enact a law which removes the basis
                on which a declaration of invalidity was issued in the
                exercise of judicial review.        Curative legislation is
                Constitutionally permissible. It is not an encroachment
                on judicial power. In the present case, state legislature
                of Karnataka, by enacting the Reservation Act 2018, has
                not nullified the judicial decision in B.K. Pavitra I, but
                taken care to remedy the underlying cause which led to
                a declaration of invalidity in the first place. Such a law
                is valid because it removed the basis of the decision".
49               The       Apex   Court   has   reiterated         the     line      of
precedents and referred to a decision in case of Utkal
Contractors and Joinery (Pvt) Ltd. It was further observed
that the legislature has a power to validate a law which is
found to be invalid by curing an infirmity and as an incident of
the exercise of this power, the legislature may enact a
validating law to make the earlier law ineffective from the
date on which it was enacted.              Reliance was also placed on
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:21 :::
                                     211                            Marata(J) final.doc
Prithvi          Cotton         Mills     Ltd   Vs.     Broach           BoroughDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Municipality20 which had emphatically held that a Court's
decision must always bind unless the conditions on which it is
based are so fundamentally altered that the decision could not
be given in the altered circumstances.                 After due deliberation
of the law laid down by this Court, it is held that a declaration
by the Court that a law is constitutionally invalid does not
fetter the authority of the legislature to remedy the basis on
which the declaration was issued by curing the grounds for
invalidity.           While curing the defect, it is essential to
understand            the      reasons    underlying   the      declaration           of
invalidity. The reasons constitute the basis of the declaration.
The legislature cannot simply override the declaration of
invalidity without remedying the basis on which the law was
held to be ultra vires.           The Apex Court also deliberated on the
issue as to whether the basis of B.K. Pavitra (I) was cured
while enacting the Reservation Act of 2018 and concluded that
the Ratna Prabha Committee constituted by the State
Government collected the quantifiable data in the backdrop of
the three parameters laid down in M.Nagaraj and the State
analyzed the data which was found to be both relevant and
20 (1969) 2 SCC 283
patil-sachin.
::: Uploaded on - 27/06/2019                      ::: Downloaded on - 28/06/2019 05:25:21 :::
                                212                         Marata(J) final.doc
representative in character and since the opinion of the StateDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

was based on the report submitted by an expert committee
which had collected, collated and analyzed the relevant data,
the subsequent enactment of 2018 came to be upheld. We
gainfully rely upon the observations of the Hon'ble Apex Court
in answering the point that the impugned Act of 2018 which
we are dealing with, do not suffer from any legislative
incompetence on account of the earlier interim order and the
subsequent collection of quantifiable data by the Maharashtra
State Backward Class Commission (MSBCC) which classifies
the community as 'backward' and set out the extra-ordinary
situations/exceptional circumstances which we are required to
independently examine.
(b)      Whether the 102nd (Constitution) Amendment Act
2018        affects the competency of the State legislature
to enact the impugned legislation.
50               The submission of the learned Senior counsel Shri
Datar and Shri Aney is to the effect that after the Constitution
102nd Amendment Act which came into force with effect from
15th August 2018, the State legislature is denuded of its power
to declare a particular class to be socially and educationally
patil-sachin.
::: Uploaded on - 27/06/2019              ::: Downloaded on - 28/06/2019 05:25:21 :::
                                  213                          Marata(J) final.doc
backward and in light of the change brought in, to the effect
that "socially and educationally backward classes" are thoseDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

classes which are so declared under Article 342A                         of the
Constitution.           Further submission is that the newly inserted
Article 342A confers the power on the President with respect
to any State or Union territory and where it is the State, after
consultation with the Governor thereof to specify the socially
and educationally backward classes which shall be deemed to
be SEBC in relation to that State or Union territory. Reliance is
also place on clause (2) of Article 342A which confers the
privilege only on the Parliament which may by law include or
exclude any particular socially and educationally backward
class. In light of the said amendment, it is the submission of
the learned counsel for the petitioners that the impugned
amendment is violative of Constitution (102nd Amendment) Act
2018. The said point has also been extensively and forcefully
argued by the learned counsel Shri Talekar.
51               Per contra, it is submission of the State and
effectively voiced through the learned senior counsel Shri
Thorat that the 102nd Amendment which has inserted Article
342A do not affect the power of the State legislature to
patil-sachin.
::: Uploaded on - 27/06/2019                 ::: Downloaded on - 28/06/2019 05:25:21 :::
                                 214                           Marata(J) final.doc
recognize the socially and educationally backward classes
within its jurisdiction and exercise of the power conferred on itDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

by Articles 15(4) and 16(4) and to bring a legislation utilizing
this enabling power conferred exclusively on the State. The
precise submission is that the power to legislate is conferred
on the State legislature by Articles 15, 16 and other provisions
and perusal of Article 342A would make it amply clear that it
do not take away the power of the State and unless and until
a constitutional amendment is effected in Articles 15 and 16
so as to exclude the State Government from the ambit and
scope from the word 'State', Article 342A cannot be read to
control exercise of power under Articles 15(4) and 16(4). It is
also the submission of the respondent State that the
legislative competence can also be derived from other parts of
the Constitution apart from Article 246 read with Seventh
Schedule and the power to enact the impugned legislation
flows from Article 15 and 16 and Part IV of the Constitution
and therefore, there is no gain in saying that State lacks
legislative competence.
         In order to appreciate the rival contentions, we would
make reference to the Constitution (102 nd Amendment Act)
2018.           The said Act of the Parliament received assent of the
patil-sachin.
::: Uploaded on - 27/06/2019                 ::: Downloaded on - 28/06/2019 05:25:21 :::
                                    215                             Marata(J) final.doc
President on 11th August 2018 and it came into effect from 15 th
August 2018. The said amendment inserts Article 338B intoDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

the Constitution which provides for Constitution of "National
Commission for Backward Classes". Article 338-B reads thus :
                 "338B. National Commission for Backward
                 Classes (1) There shall be a Commission for the
                 socially and educationally backward classes to be
                 known as the National Commission for Backward
                 Classes.
                 (2) Subject to the provisions of any law made in this
                 behalf by Parliament, the Commission shall consist of a
                 Chairperson,    Vice-Chairperson   and   three   other
                 Members and the conditions of service and tenure of
                 office of the Chairperson, Vice-Chairperson and other
                 Members so appointed shall be such as the President
                 may by rule determine.
                 (3) The Chairperson, Vice-Chairperson and other
                 Members of the Commission shall be appointed by the
                 President by warrant under his hand and seal.
                 (4) The Commission shall have the power to regulate its
                 own procedure.
                 (5) It shall be the duty of the Commission--
                        (a) to investigate and monitor all matters relating
                        to the safeguards provided for the socially and
                        educationally backward classes under this
                        Constitution or under any other law for the time
                        being in force or under any order of the
                        Government and to evaluate the working of such
                        safeguards;
                          (b) to inquire into specific complaints with respect
                          to the deprivation of rights and safeguards of the
                          socially and educationally backward classes;
                          (c) to advise on the socio-economic development
                          of the socially and educationally backward
                          classes and to evaluate the progress of their
                          development under the Union and any State;
patil-sachin.
::: Uploaded on - 27/06/2019                      ::: Downloaded on - 28/06/2019 05:25:21 :::
                                    216                             Marata(J) final.docDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                          (d) to present to the President, annually and at
                          such other times as the Commission may deem
                          fit, reports upon the working of those safeguards;
                          (e) to make in such reports the recommendations
                          as to the measures that should be taken by the
                          Union    or   any    State   for   the effective
                          implementation of those safeguards and other
                          measures for the protection, welfare and socio-
                          economic development of the socially and
                          educationally backward classes; and
                          (f ) to discharge such other functions in relation to
                          the protection, welfare and development and
                          advancement of the socially and educationally
                          backward classes as the President may, subject to
                          the provisions of any law made by Parliament, by
                          rule specify.
                 (6)    The President shall cause all such reports to be
                 laid before each House of Parliament along with a
                 memorandum explaining the action taken or proposed
                 to be taken on the recommendations relating to the
                 Union and the reasons for the non-acceptance, if any,
                 of any of such recommendations.
                 (7) Where any such report, or any part thereof,
                 relates to any matter with which any State Government
                 is concerned, a copy of such report shall be forwarded
                 to the Governor of the State who shall cause it to be
                 laid before the Legislature of the State along with a
                 memorandum explaining the action taken or proposed
                 to be taken on the recommendations relating to the
                 State and the reasons for the non-acceptance, if any, of
                 any of such recommendations.
                 (8) The Commission shall, while investigating any
                 matter referred to in sub-clause (a) or inquiring into
                 any complaint referred to in sub-clause (b) of clause
                 (5), have all the powers of a civil court trying a suit and
                 in particular in respect of the following matters, namely:
                 --
                          (a) summoning and enforcing the attendance of
                          any person from any part of India and examining
                          him on oath;
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                      ::: Downloaded on - 28/06/2019 05:25:21 :::
                                    217                             Marata(J) final.doc
                          (b) requiring the discovery and production of any
                          document;
                          (c) receiving evidence on affidavits;
                          (d) requisitioning any public record or copy
                          thereof from any court or office;
                          (e) issuing commissions for the examination of
                          witnesses and documents;
                          (f) any other matter which the President may, by
                          rule, determine.
                 (9) The Union and every State Government shall consult
                 the Commission on all major policy matters affecting
                 socially and educationally backward classes.
52               By the same amending Act, Article 342A is also
inserted in the Constitution which reads thus :
                 342A.             Socially and Educationally backward
                 classes-(1) The President may with respect to any State
                 or Union territory, and where it is a State, after
                 consultation with the Governor thereof, by public
                 notification, specify the tribes or tribal communities or
                 parts of or groups within tribes or tribal communities
                 which shall for the purposes of this Constitution be
                 deemed to be Scheduled Tribes in relation to that State
                 or Union territory, as the case may be.
                        (2)  Parliament may by law include in or exclude
                 from the list of Scheduled Tribes specified in a
                 notification issued under clause ( 1 ) any tribe or tribal
                 community or part of or group within any tribe or tribal
                 community, but save as aforesaid a notification issued
                 under the said clause shall not be varied by any
                 subsequent notification.
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                      ::: Downloaded on - 28/06/2019 05:25:21 :::
                                       218                           Marata(J) final.doc
53               Further, there is also an amendment in Article 366
of the Constitution and                 Clause (26C) is inserted to the
following effect :
                26C    "socially and educationally backward
                classes" means the backward classes as are
                so deemed under article 342A for the
                purposes of this Constitution"
                 The import of the 102nd Constitution Amendment
Act is conferment of constitutional status on the Commission
for socially and educationally backward classes known as
"National Commission for Backward classes"
54               Part      XVI   of    the   Constitution      contain         special
provisions relating to certain classes.                Article 330 contain a
provision for reservation of seats for Scheduled Caste and
Scheduled Tribes in the House of people whereas Article 332
embodies the provision for reservation of seats of the
Scheduled Caste and Tribes in the Legislative Assemblies of
the State.             Article 338 prior to the 89 th Amendment Act
contained a provision for National Commission for Scheduled
Tribe and Other Backward Classes under Article 338(10), while
by 89th Amendment, a separate National Commission for
Scheduled Tribes was formed by inserting Article 338A with
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                       ::: Downloaded on - 28/06/2019 05:25:21 :::
                                    219                              Marata(J) final.doc
effect from 19th February 2004. The insertion of Article 338B
is on similar lines and it constitutes a National Commission for
backward           classes     known     as   "National        Commission             for
Backward Classes".              The Commission is cast with a duty to
investigate and monitor all matters relating to safeguards to
be provided for the socially and educationally backward
classes under the Constitution or under any other law for the
time being in force or under any order of the Government. It
is also entrusted with the task of evaluating the working of
such safeguards. It is also empowered to inquire into specific
complaints with respect of the deprivation of rights and
safeguards of socially and educationally backward classes. It
is also conferred with a power to present reports upon working
of the safeguards to the President, annually and at such other
times as the Commission may deem fit, in which it may
recommend measures to be taken by the State or the Union
for effective implementation of the safeguards and other
measures           for     protection,   welfare     and       socio      economic
development of the socially and educationally backward
classes. The Statements of Objects and Reasons of the 123 rd
Amendment Bill 2017 would render an insight in the
Amendment Act. The Statement of Object and Reasons (SOR)
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                       ::: Downloaded on - 28/06/2019 05:25:21 :::
                                     220                                Marata(J) final.doc
reads thus :
                 "3.      In the year 1992, the Supreme Court of India
                 in the matter of Indra Sawhney and others Vs.
                 Union of India and others (AIR 1993, SC 477) had
                 directed the Government of India to constitute a
                 permanent body for entertaining, examining and
                 recommending              requests       for       inclusion          and
                 complaints of over-inclusion and under-inclusion in
                 the      Central   List    of   Other       Backward           Classes.
                 Pursuant      to   the said      Judgment,            the      National
                 Commission for Backward Classes Act was enacted
                 in April, 1993 and the National Commission for
                 Backward Classes was constituted on 14th August,
                 1993 under the said Act. At present the functions of
                 the National Commission for Backward Classes is
                 limited to examining the requests for inclusion of
                 any class of citizens as a backward class in the
                 Lists and hear complaints of over-inclusion or
                 under-inclusion of any backward class in such lists
                 and tender such advice to the Central Government
                 as it deems appropriate. Now, in order to safeguard
                 the interests of the socially and educationally
                 backward classes more effectively, it is proposed to
                 create a National Commission for Backward Classes
                 with constitutional status at par with the National
                 Commission for Scheduled Castes and the National
                 Commission for Scheduled Tribes.
patil-sachin.
::: Uploaded on - 27/06/2019                          ::: Downloaded on - 28/06/2019 05:25:21 :::
                                    221                              Marata(J) final.doc
                 4.       The National Commission for the Scheduled
                 Castes has recommended in its Report for 2014-15
                 that the handling of the grievances of the socially
                 and educationally backward classes under clause
                 (10) of article 338 should be given to the National
                 Commission for Backward Classes.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                 5.        In view of the above, it is proposed to amend
                 the Constitution of India, inter alia, to provide the
                 following, namely:--
                          (a ) to insert a new article 338 so as to
                          constitute      the   National      Commission              for
                          Backward Classes which shall consist of a
                          Chairperson,      Vice-Chairperson           and        three
                          other Members. The said Commission will
                          hear    the      grievances       of     socially         and
                          educationally backward classes, a function
                          which has been discharged so far by the
                          National Commission for Scheduled Castes
                          under clause (10) of article 338; and
                          (b ) to insert a new article 342A so as to
                          provide that the President may, by public
                          notification,     specify     the        socially         and
                          educationally backward classes which shall
                          for the purposes of the Constitution be
                          deemed to be socially and educationally
                          backward classes".
patil-sachin.
::: Uploaded on - 27/06/2019                       ::: Downloaded on - 28/06/2019 05:25:21 :::
                                  222                          Marata(J) final.doc
55                Perusal of the statement would disclose that it was
deemed appropriate to create a National Commission for
backward classes with a constitutional status on par with the
National Commission for Scheduled Castes and National
Commission for Scheduled Tribes.                 The earlier existing
National Commission for backward classes which came to be
created in the backdrop of the statutory framework of National
Commission for backward classes Act 1992 is repealed with
coming into force of the 102 nd (Constitution Amendment). TheDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

functions entrusted to the commission revolve around a
broader framework and it is competent to investigate,
monitor, evaluate, recommend, safeguards provided for the
socially and educationally backward classes.                    It may also
provide guidance in form of recommendations as to the
measures to be taken by the Union or any State for effective
implementation of the safeguards meant for the said classes.
The Commission with the constitutional status thus aims to
work towards advancement of the socially and educationally
backward classes and assist the State in conferring benefits
on the said classes. The question that arise for consideration
after       the      Constitutional    Amendment       is    whether           the
patil-sachin.
::: Uploaded on - 27/06/2019                 ::: Downloaded on - 28/06/2019 05:25:21 :::
                                223                             Marata(J) final.doc
constitution of the State Backward Classes Commission, in
pursuance to the directions issued by the Hon'ble Apex Court
in case of Indra Sawhney & ors to constitute a permanent
body        for entertaining, examining and recommending upon
request for inclusion and complaints of over inclusion and
under inclusion in the list of Other Backward Class of citizens
would cease to function automatically.                  Shri Talekar had
canvassed this extreme submission and has urged that the
State Backward Class Commission would cease to function
and he would go to the extent of submitting that by comingDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

into effect of the said provision, the Maharashtra State
Commission for Backward Classes Act, 2005 is impliedly
repealed.          It is to be noted that the OM providing 27%
reservation of Other Backward Classes in Central Government
posts, pursuant to the Mandal Commission's report which was
challenged in Indra Sawhney's case, the Supreme Court
made the following observations :
            "The Government of India, each of the State Governments
            and the administration of Union territories shall, within four
            months from today constitute a permanent body for
            entertaining, examining and recommending upon request
            for inclusion and complaints of over inclusion and under
            inclusion in the list of Other Backward Classes of citizens.
            The advice tendered by such body shall, ordinarily be
            binding on the Government".
patil-sachin.
::: Uploaded on - 27/06/2019                  ::: Downloaded on - 28/06/2019 05:25:21 :::
                                        224                               Marata(J) final.doc
                 Pursuant        to    the      said   judgment,         the      National
Commission for Backward Classes Act was enacted in April
1993 and the National Commission for Backward classes was
constituted on 14th August 1993, which is authorized to
examine the request for inclusion of any class of citizens as
backward classes in the Central list and it is also authorized to
hear complaints of over-inclusion or under-inclusion of any
backward classes in such list and tender such advice to the
Central         Government            as   it   deemed       to     be     appropriate.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

However,          while        this   Commission         was       functioning,           the
Parliament constituted a Committee on welfare of Other
Backward Classes under the Chairmanship of Shri B.K.
Handique which presented its first report on 27 th August 2012
and it recommended that the NCBC should be conferred with
a constitutional status and this saw light of the day by
introduction of 123rd Bill. The Committee, in its Second Report
recommended deletion of clause 10 of Article 338 and instead
recommended insertion of new Article 338B.                                The National
Commission for Scheduled Castes also recommended in its
report in the year 2014-15 that the hearing of grievances of
socially and educationally backward classes under clause (10)
of Article 338 should be left to the National Commission for
patil-sachin.
::: Uploaded on - 27/06/2019                            ::: Downloaded on - 28/06/2019 05:25:21 :::
                                  225                           Marata(J) final.doc
backward classes. It is also to be noted that in furtherance of
the directions issued in case of Indra Sawhney, the State of
Maharashtra also provided for constitution of a State level
Commission for backward classes other than the Scheduled
Caste and Scheduled Tribes by enacting the Maharashtra State
Commission for Backward Classes Act, 2005. The said
enactment provides for constitution of the State Commission
for Backward Classes to entertain and examine the request for
inclusion of any class or citizens as backward class in the lists.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

The Act defines the term "lists" in Section 2(e) in the following
manner :
                "Lists means the list prepared by the State
                Government, from time to time for the purposes of
                making provision for the reservation of appointments
                or posts, in favour of the backward classes of citizens
                who, in the opinion of the State Government, are not
                adequately represented in the services under the
                State Government and any local or other authority
                within the State or under the control of the State
                Government"
                  The State Backward Commission, therefore, is
entitled to entertain, hear, enquire and into complaints of
over-inclusion or under-inclusion of any backward classes in
the list prepared by the State and tender advice to the State
Government as it deemed fit.                The advice tendered or
recommendation made by the Commission shall ordinarily be
patil-sachin.
::: Uploaded on - 27/06/2019                  ::: Downloaded on - 28/06/2019 05:25:21 :::
                                     226                           Marata(J) final.doc
binding on the State Government and the State Government
shall record reasons in writing if it totally or partially reject the
recommendation or modifies it in terms of sub-section (2) of
Section 9 of the enactment.                   Section 11 of the State
Enactment of              2005    enables    the State Government on
expiration of 10 years from the appointed date and every
succeeding period of 10 years thereafter to undertake revision
of the lists with a view to exclude from such list those classes
which have ceased to be backward or for including in such list
new backward classes and while doing so, the State shallDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

consult the Commission.
45               Subsequent to the judgment in Indra Sawhney,
apart from the National Commission constituted under the Act
of Parliament, the State Commission was also constituted
under the State Enactment                 and continues to discharge the
functions as on the date when the Constitution 102 nd
Amendment came to be introduced. The 123rd Bill came to be
introduced           and       deliberated   along    with       the       National
Commission for Backward Class (Repealed Bill 2017) and the
said Bill came to be passed with the hope that the newly
constituted            National      Commission       for       Socially          and
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:21 :::
                                227                          Marata(J) final.doc
Educationally backward classes will have a greater and larger
role to play and it would not only focus on the issue of
inclusion and reservation but on the holistic development and
advancement of each community within the backward classes.
The deliberations in the Rajya Sabha disclose that the
members deliberating expect the newly constituted National
Commission to ensure the social and economic development
of the backward classes and bring them on par with the
socially and economically advanced class and eradicate the
malignancy of social inferiority and moving these classes fromDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

category of backwardness.            However, we do not find any
material in form of any discussion to accept the submission of
Shri Talekar that this amendment has resulted into repeal of
the Maharashtra State Backward Commission Act, 2005 also.
Shri Talekar himself has placed before us the report of the
Select Committee on the Constitution 123rd Amendment Bill
2013. The 123rd Amendment Bill 2017 was introduced in Lok
Sabha on 5th April 2017 and passed by it on 10 th April 2017. It
was then referred to the Select Committee comprising 25
members of the Rajya Sabha on a motion adopted by the
State on 11th April 2017 for examination of the Bill and report
thereon to the Rajya Sabha. The Committee, after taking into
patil-sachin.
::: Uploaded on - 27/06/2019               ::: Downloaded on - 28/06/2019 05:25:21 :::
                                228                           Marata(J) final.doc
consideration, the information furnished by the Ministry of Law
and Justice, Ministry of Finance, Ministry of Human Resources,
Anthropological Survey of India and memorandum furnished
by 23 State Governments and Union territories considered
their views on the Bill. We have gone through the report of
the     Select Committee and have carefully perused the
deliberations of the Select Committee.             The questions with
which we are confronted today strikingly appeared to the
Committee also and taking into consideration the history of
the reservation, the Committee sought clarifications on theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

following issues:
(1)      Whether there was an objective criteria laid down by the
Supreme Court for deciding the basis of 'inclusions' and
'exclusions' of any notified classes?
(2)      What would be the status of existing list of Other
Backward Classes after coming into effect of the Bill under
consideration of the observations of the Select Committee are
self-explanatory?
(3)      What would be the status of the State Backward Class
Commission after coming              into force of the Bill under
consideration?
patil-sachin.
::: Uploaded on - 27/06/2019                ::: Downloaded on - 28/06/2019 05:25:22 :::
                                    229                               Marata(J) final.doc
(4)      What would be role of Governor in deciding about the
inclusion or exclusion of classes in the OBC list?
                 The observations of the Committee are sufficiently
eloquent and we would reproduce the same.
        "11. The Committee was                  informed       that     the     eleven
                indicators provided by the Mandal Commission would
                provide the broad framework for deciding the classes to
                be     included   in    the   Central   list    of    socially       and
                educationally backward classes (SEBCs) by the National
                Commission for Backward Classes. The Committee was
                informed that the proposed amendment was only to
                confer constitutional status to the National Commission
                for Backward Classes while the State Backward Classes
                Commissions would continue to function as earlier
                without any modifications. It was further informed thatDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                two Bills have been introduced in the Parliament, i.e. (i)
                the      Constitution    (One   Hundred        and     Twenty-Third
                Amendment) Bill, 2017 and (ii) the National Commission
                for Backward Classes (Repeal) Bill, 2017 which provides
                for saving of the actions taken under the said Act.
        12       It was further clarified that in respect of the backward
                classes, there are two lists i.e. the Central List and the
                State List. The Central List provides for education and
                employment        opportunities    in    Central        Government
                Institutions as per laid down procedures.               In the State
                List, the States are free to include or exclude in their
                backward classes list.        This Constitutional amendment
                does not affect or alter in any way the present powers or
                functions of the State Backward Classes Commissions
                and their powers for exclusion or inclusion of backward
patil-sachin.
::: Uploaded on - 27/06/2019                       ::: Downloaded on - 28/06/2019 05:25:22 :::
                                  230                             Marata(J) final.doc
                classes in the State Backward Classes list shall remain
                unchanged.
56               As regards point no.4, the Committee observed
thus:-
         "In its Fifth meeting representatives/members raised a
         concern about sub-clause (1) of Article 342-A, whether
         the list would be issued by the President, after
         consultation with the State Government or consultation
         with only Governor of the State".
                 It was clarified by the Ministry that clause (1) of
Article 154 and Article 163 of the Constitution clearly state
that the Governor shall act on the advice of the Council of
Ministers.           It was also clarified that under the above
Constitutional provisions, the Governor shall exercise his
authority either directly or indirectly through officers of the
respective State Government.           Article 341 of the ConstitutionDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

provides for consultation with the Governor of State with
respect         to   Scheduled   Castes   and     Article       342      provides
consultation of President with Governor of State in respect of
Scheduled Tribes. As is the practice, at no time has the State
Government been excluded in consultation process. It is
always invariably the State Government which recommends
to the President the category of inclusion/exclusion in
patil-sachin.
::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:22 :::
                                    231                               Marata(J) final.doc
Scheduled castes and Scheduled Tribes. Similar provision is
provided for in the case of conferring of constitutional status
for backward classes for inclusion in Central list of socially and
educationally           backward    classes.        Consultation            with      the
Governor          thereby      implies   consultation          with       the      State
Government.
57               The report of the Select Committee thus make it
amply clear that the constitutional amendment in no way
affects the          State level commission for Backward Classes to
entertain and examine the request for inclusion of any class of
citizens as backward classes in the list.                    The constitutional
amendment thus, in no way, nullifies the constitution of a
backward class commission by the State Government under a
statute whereby the State Government, in exercise of powersDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

conferred under sub-section (1) and clauses (a), (b) and (c) of
sub-section (2) of Section 3 of the Maharashtra State
Commission for Backward Classes Act, 2005 constituted the
Maharashtra State Commission for Backward Classes (MSBCC)
under the Chairmanship of Retired Justice Sambhajirao Mhase
and       subsequently         substituted     by      Justice       Gaikwad           by
notification dated 4th January 2017.                       The report of the
patil-sachin.
::: Uploaded on - 27/06/2019                        ::: Downloaded on - 28/06/2019 05:25:22 :::
                                  232                            Marata(J) final.doc
Commission            which    formed   the   basis    of    the      impugned
enactment cannot therefore be said to be nullity by coming
into force of the Constitution 102 nd Amendment with effect
from 15th August 2018.             The Backward Class Commission
constituted by the State is not denuded of its powers to
entertain and examine the request for inclusion of any class of
citizens as 'backward class' in the list and on such a claim
being examined, if a recommendation is made by the
Commission under the State enactment, it shall ordinarily bind
the State Government in terms of Section 9. We, therefore, do
not agree with the submission of the learned counsel for the
petitioners that with the Constitution 102 nd Amendment
coming into force, the State Backward Class Commission
would impliedly cease to exercise its jurisdiction and the State
legislation itself stands impliedly overruled.                       The StateDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Backward Class commission, on the contrary, in terms of the
directives issued in Indra Sawhney would continue to assist
the State in determining the backward classes within its
territory and would continue to assist in discharge of its
constitutional obligation to uplift the backward classes of
citizens.
patil-sachin.
::: Uploaded on - 27/06/2019                   ::: Downloaded on - 28/06/2019 05:25:22 :::
                                  233                             Marata(J) final.doc
58                Another argument which need to be dealt with is
the scope and width of Article 342A and whether by insertion
of the said Article, the State Government is deprived of its
power to specify the social and educational backward classes
in relation to a particular State and here the State of
Maharashtra. It is no doubt true that the terms "Scheduled
Caste and Scheduled Tribe" found its place in the Constitution
since inception and Article 341 and 342 of the Constitution
specified who are Scheduled Caste and Scheduled Tribes.
Article 366(24) defined Scheduled Caste "to mean such
castes, races or tribes or parts of or groups within such castes,
races or tribes as are deemed under Article 341 to be
Scheduled Castes for the purposes of this Constitution.
Similarly,        Article 366(25) defined Scheduled Tribes to mean
such tribes or tribal communities or part or groups within suchDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

tribes or tribal communities as are deemed under Article 342
to the scheduled tribes for the purposes of this Constitution.
Article 341 of the Constitution read thus :
                341      Scheduled Castes _ (1) The President may with
                respect to any State or Union territory, and where it is a
                State after consultation with the Governor thereof, by
                public notification, specify the castes, races or tribes or
                parts of or groups within castes, races or tribes which
                shall for the purposes of this Constitution be deemed to
                be Scheduled Castes in relation to that State or Union
                territory, as the case may be
patil-sachin.
::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:22 :::
                                  234                             Marata(J) final.doc
                (2)     Parliament may by law include in or exclude from
                the list of Scheduled Castes specified in a notification
                issued under clause ( 1 ) any caste, race or tribe or part
                of or group within any caste, race or tribe, but save as
                aforesaid a notification issued under the said clause shall
                not be varied by any subsequent notification.
Similarly worded to Article 341 is Article 342 which reads
thus :-
                342      Scheduled Tribes - (1) The President may with
                respect to any State or Union territory, and where it is a
                State, after consultation with the Governor thereof, by
                public notification, specify the tribes or tribal
                communities or parts of or groups within tribes or tribal
                communities which shall for the purposes of this
                Constitution be deemed to be Scheduled Tribes in relation
                to that State or Union territory, as the case may be
                (2)     Parliament may by law include in or exclude from
                the list of Scheduled Tribes specified in a notification
                issued under clause (1) any tribe or tribal community or
                part of or group within any tribe or tribal community, but
                save as aforesaid a notification issued under the said
                clause shall not be varied by any subsequent notificationDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                  From the very inception of the Constitution, the
power to specify the Scheduled Caste and Scheduled Tribes
vests exclusively with the President who may, where it is a
State, after consultation with the Governor, specify the caste,
race or tribes or parts of all groups within the caste, races or
tribes which shall be deemed to be Scheduled Caste or
Scheduled Tribes in relation to that State or the Union
Territory, as the case may be. The power to specify these two
patil-sachin.
::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:22 :::
                                235                      Marata(J) final.doc
classes is therefore, the exclusive prerogative of the President
who may consult the Governor of a State if the caste or tribes
are to be declared for that particular State.                 Once the
Scheduled Caste or Scheduled Tribes are notified, then, it is
only the Parliament which may by law, include in or exclude
from the Scheduled Caste or Scheduled Tribe order and this
power of inclusion or exclusion can be exercised only by the
Parliament and by none else. It has been a consistent view
taken by the rulings of the Apex Court as well as the High
Court of this country that it is exclusive prerogative of the
President to initially specify and notify the caste as Scheduled
caste or tribes as Scheduled Tribes and once such list is
prepared, it is only the Parliament who is empowered to add,
delete or make any alteration in the said list. In exercise of
the power conferred by clause (1) of Article 341 of theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Constitution of India, the President after consultation with the
Governors of the States, was pleased to make the Constitution
(Scheduled Caste) Order 1950 and all the caste, races or
tribes or parts of, or groups within the caste or tribes of the
Schedule appended to the order in relation to the States to
which those parts respectively relate were deemed to be
Scheduled caste. Similarly, in exercise of power conferred by
patil-sachin.
::: Uploaded on - 27/06/2019           ::: Downloaded on - 28/06/2019 05:25:22 :::
                                      236                              Marata(J) final.doc
clause (1) of Article 342, the President was pleased to declare
the Constitution (Scheduled Tribes Order 1950). Every entry
in the said order/list meant for a particular State by the
President         is    in     consultation   with    the     Governor          of     the
concerned State.
59                As we have mentioned above, on recommendation
of the Mandal Commission, the Government of India issued an
Office          Memorandum          providing   for     reservation           of     27%
vacancies in civil posts and services under the Government of
India in favour of Other Backward Classes. As per the Office
Memorandum issued by the Ministry of Personnel, Public
grievances and Pensions (Department of Personnel and
Training) the Other Backward classes for the purposes of 27%
reservation comprised of the caste and communities whichDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

are common to both the list in the report of Mandal
Commission and the State Government list.                                The expert
committee on 'creamy layer' headed by Justice (Retired) R.M.
Prasad, was commissioned to prepare the common list in
respect of 14 States including the State of Maharashtra which
had notified the list of Other Backward Classes for the
purposes of reservation of State services on the date of the
patil-sachin.
::: Uploaded on - 27/06/2019                         ::: Downloaded on - 28/06/2019 05:25:22 :::
                                    237                             Marata(J) final.doc
judgment of the Supreme Court in case of Indra Sawhney.
The common list prepared by the Committee came to be
accepted by the Government and then the Government
decided to notify the list of Other Backward Classes in context
of implementation of the Office Memorandum issued and
these lists were deemed to have been in effect from 8 th
September 1993.                The National Commission for Backward
Classes         set    out     under   the   provisions      of    the      National
Commission for Backward classes Act, 1993 in pursuance of
the directions of the Supreme Court was permitted to
entertain, examine and recommend upon request for inclusion
and complaints of over-inclusion and under-inclusion in the list
of Other Backward Classes of citizens.                  By this mechanism,
there came into existence two lists of Other Backward Classes
for the State of Maharashtra. One is the Central list of OBCsDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

for the State of Maharashtra which includes 261 castes,
another list is the State list of OBCs in the State of
Maharashtra, which as on date, contains 346 castes which are
recognized as OBCs for the purposes of reservation of OBC in
the State. It is to be noted that the entries in the said list are
added/deleted by issuing Government Resolutions from time
to time. Thus, the scenario that emerges is unlike the
patil-sachin.
::: Uploaded on - 27/06/2019                      ::: Downloaded on - 28/06/2019 05:25:22 :::
                                     238                           Marata(J) final.doc
Scheduled Caste and Scheduled Tribe order pertaining to State
of Maharashtra, where there is one common list of Scheduled
Castes and Schedule Tribe in form of the Schedule Tribe Order
for State of Maharashtra, as far as the Other Backward Class is
concerned, there are two lists in existence and the central list
of OBCs for the State of Maharashtra is operated for providing
27% reservation in the Central Government services in the
State of Maharashtra, whereas for providing 19% reservation
for the Other Backward Class category, in terms of the
Maharashtra State Public Services Reservation for Schedules
Castes, Scheduled Tribes, Denotified Tribes (Vimukta Jatis),
Nomadic          Tribes,       Special    Backward   Category         and      other
Backward Classes Act, 2001 and for providing reservation in
the Professional Institutions under              The Maharashtra Private
Professional Educational Institutions (Reservation of seats forDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

admission for Scheduled castes, Scheduled tribes, De-notified
tribes (Vimukta Jatis), Nomadic tribes and Other Backward
Classes) Act, 2006, the said list of OBCs in the State of
Maharashtra is operated.
60               In light of this existing scenario, we would now
examine the scope of Article 342A. As far as sub-clause (1) of
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:22 :::
                                       239                              Marata(J) final.doc
Article 342A is concerned, the same is identically worded as
Article 342(1) and 342(2) and there is no distinction.
However,             sub-clause (2) of Article 342A contains one
additional word which is conspicuously absent and the word is
"Central".           There is no quarrel about the proposition that
when the Parliament has used the word 'Central', it is not in
vacuum but it must take its due meaning in reference to the
context. The Parliament being conscious of the fact that there
are two lists operating in various states, listing the OBCs in the
State       for     two        distinct   purposes,     firstly,      for     providing
reservation prescribed by the Central Government in Central
Services by its OM i.e. 27% reservation for OBCs and the other
list    for     providing         reservation   by      the     respective          State
Governments for public employment in that particular state
and when this scenario in background is kept in mind, then, itDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

becomes apparently clear that the Parliament intended that it
would retain the power to include or exclude from the Central
list" meaning thereby that the Parliament would exercise the
power only for including or excluding from the central list of
socially and backward classes which is specified by the
President, with respect to any State, after consultation with its
Governor. We are in agreement with the submission advanced
patil-sachin.
::: Uploaded on - 27/06/2019                          ::: Downloaded on - 28/06/2019 05:25:22 :::
                                240                         Marata(J) final.doc
by the learned counsel Shri Thorat who had submitted that if
the scope of Article 342A is read in the manner which is
sought to be interpreted by the learned counsel for the
petitioners, then, it would be interfering with the power of the
State, and it cannot be the intention of the Parliament to
denude the State of its power and confer the said power on
the President exclusively, particularly in light of federal
structure of our Constitution.       On a plain reading of Article
342-A, the position that emerges by reading it without
creating any ambiguity is that the Parliament intended to
restrict the power of inclusion and exclusion of the Caste from
the list of Other Backward Classes in respect of the Central list
and therefore, the restriction imposed that it is only the
Parliament which may include or exclude from the list restrict
itself to the Central List only. Had the Parliament intended toDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

deprive the State of its power, it would have specifically
mentioned so. The plain reading of Article 342A thus leads to
an irresistible interpretation that by virtue of the 102 nd
Constitutional Amendment, the socially and educationally
backward classes is defined in the Constitution itself and it is
that class which is deemed to be socially and educationally
backward under Article 342-A. How such class will be created
patil-sachin.
::: Uploaded on - 27/06/2019              ::: Downloaded on - 28/06/2019 05:25:22 :::
                                     241                               Marata(J) final.doc
is specified in Article 342-A.             Once this class is specified as
"socially and educationally backward class", then, it is only
the Parliament which is authorized by law to include or
exclude from the Central list of socially and educationally
backward classes as specified by the notification and it is not
permissible to vary the first notification by a subsequent
notification. The reservation of posts under the State or under
any authority of the State or seats in educational institutions
within the State is, therefore, beyond the purview of the 102 nd
Amendment. The operation of clause (2) of Article 342-A is
limited to the inclusion or exclusion from the central list. The
term       'list'   is    defined   in    Section        2(C)   of    the      National
Commission of Backward Classes to mean the list which
relates to services under the Government of India or any other
authority under the control by the Government of India. It, inDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

any contingency, do not extend its sweep to the list of the
State which is defined in Section 2(e) of the Maharashtra State
Commission for Backward Classes Act, 2005.                           Howsoever, if
the said interpretation as sought to be placed by the
petitioners assailing the legislative competency of the State to
enact       the     impugned        legislation     in    the     wake       of    102 nd
Amendment to the Constitution is accepted, it would be in
patil-sachin.
::: Uploaded on - 27/06/2019                         ::: Downloaded on - 28/06/2019 05:25:22 :::
                                          242                           Marata(J) final.doc
breach of the principle of Federalism, which is a basic
structure of the Constitution.                 The Federal structure of the
Constitution          is       equally    important    feature       of     an     Indian
Constitution necessitated on account of the contemporaneous
diversity and as expressed by the Hon'ble Apex Court in the
latest judgment of State, NCT of Delhi Vs. Union of
India,21 in the following words :
                "Our Constitution contemplates a meaningful
                orchestration of federalism and democracy to put in
                place an egalitarian social order, a classical unity in a
                contemporaneous diversity and a pluralistic milieu in
                eventual cohesiveness without losing identity.
                Sincere attempts should be made to give full-fledged
                effect to both these concepts".
                  The Constitution has mandated a federal balance
wherein independence of certain required degree is assured to
the State Government. As opposed to centralism, a balanceDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

federal structure mandates that Union does not usurp all the
powers and State enjoy freedom without any unsolicited
interference from the Central Government with respect to
matters which                  exclusively fall within their domain.                   The
federal structure for governance which is a part of basic
structure recognizes the importance of fulfilling regional
aspirations as a means of strengthening unity.
21 2018 (8) SCC 501
patil-sachin.
::: Uploaded on - 27/06/2019                          ::: Downloaded on - 28/06/2019 05:25:22 :::
                                     243                           Marata(J) final.doc
70               The expressive use of the word 'State' in Article 14,
15 and 16 is to be understood in the context of Article 12
which would include the State legislature and all local and
other authorities.             It is by now settled that the enabling
provisions under Article 15(4) and 16(4) can be invoked by the
State and in Indra Sawhney's case, it has been held that the
provision in Article 16(4) need not necessarily only be
enforced by the Parliament/legislature but can be made and
asserted by an executive fiat. The special power conferred on
the State under Article 15(4) for making any special provision
for advancement of any socially and educationally backward
classes of citizens or the power conferred on the State under
Article 16(4) for making any provision for reservation of
appointments or posts in favour of any backward class of
citizens which, in the opinion of the State, is not adequatelyDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

represented is indicative of the fact that the State is in a
better position to             understand the State of affairs prevailing
within its jurisdiction and the power is therefore, conferred on
the State             to recognize this "socially and educationally
backward classes of citizens" or backward class of citizens.
Depriving the State of this power and conferring the same on
the Parliament would surely result in breach of the principle of
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:22 :::
                                      244                         Marata(J) final.doc
federalism and would destroy the basic structure of the Indian
Constitution.                  In our considered opinion, the enabling
provisions contained in form of Article 15(4) and 16(4) need to
be construed liberally so as to give full effect to the intention
of the Constitution makers in conferring such a power on the
State which is a special provision               enabling the State to
advance the weaker sections. The existence of central list of
backward classes is distinct from the list of the State which is
prepared by the State for translating the enabling power
conferred on it and in any contingency, Article 342-A cannot
be read to control the enabling power conferred on the State
under Article 15 and 16.
71               We have also carefully glanced over the report of
the Standing Committee of Rajya Sabha and the debate in theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Lok Sabha and Rajya Sabha while the 123 rd Amendment Bill
2017 was tabled. The said material has been referred by us
and relied upon to the limited extent of ascertaining the
intention of the Parliament as we are conscious of the settled
position of law that it can be only used as an external aid in
interpretation. The Hon'ble Minister Shri Thavarchand Gehlot
has clarified that the methodology which is followed as
patil-sachin.
::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:22 :::
                                245                       Marata(J) final.doc
regards the Scheduled Caste and Scheduled Tribe in the
matter of inclusion or exclusion in the list with the consultation
of the State Governments and the Registrar General of India
would also be followed while preparing the list of SEBC under
the new amendment. He also clarified that the castes which
are presently included in OBC based on the report of Mandal
Commission, the entries of those castes in the list would be
acknowledged and in future, it would be given due weightage.
As regards the power of the State Government to place castes
in the OBC list, the Hon'ble Minister has clarified that it will be
the prerogative of the State Backward Class Commission and
of the State Government and there will be no interference by
the Union Government but if any caste is to be included in the
central list, and a State proposes to do so, then, the same
mechanism which is followed in respect of inclusion of a casteDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

in Scheduled Caste/Scheduled Tribe order would be complied
with.      The Ministry of Social Justice and Empowerment also
clarified and it has been so reflected in the report of the
standing committee that the proposed amendment does not
interfere with the powers of the State Government to identify
the socially and educationally backward classes and the
existing powers of the State Backward Classes Commission
patil-sachin.
::: Uploaded on - 27/06/2019            ::: Downloaded on - 28/06/2019 05:25:22 :::
                                      246                           Marata(J) final.doc
would continue to exist even after passage of the Constitution
123rd Bill 2017.               The Ministry also clarified to the following
effect :-
                "55           The Ministry clarified that the aspect of
                reservation of posts under that State or under any
                other authority of the State or under the control of the
                State, or seats in the educational institutions within
                that State was beyond the purview of the instant Bill
                and hence the amendments proposed are not
                allowed"
                56      It was clarified that ......... Similar provision is
                provided for in the case of conferring of constitutional
                status for backward classes for inclusion in Central list
                of SEBC. Consultation with Governor thereby implies
                constitution with the State Government"
                57      The Ministry also clarified ...... The Article
                342-A will provide for a comprehensive examination
                of each case of inclusion/exclusion from the Central
                list. The ultimate power for such inclusion/exclusion
                would stand vested with the Parliament.
                67       The     Committee   observes   that   the
                amendments do not in any way affect the
                independence and functioning of State BackwardDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                Classes Commissions' and they will continue to
                exercise       unhindered    their    powers    of
                inclusion/exclusion of other backward classes with
                relation to State list"
                  Perusal of the report is indicative of the intention of
the Government in introducing the 123 rd Amendment bill 2017
and from the report and the debates, following Points
emerge :
patil-sachin.
::: Uploaded on - 27/06/2019                      ::: Downloaded on - 28/06/2019 05:25:22 :::
                                   247                              Marata(J) final.doc
                (a)            The Constitutional amendment does not
                affect that alter the powers or functions of the State
                backward Class Commissions.
                (b)            The powers for exclusion or inclusion of
                backward classes in State Backward Class list shall
                remain unchanged.
                (c)            As a result of the amendment these shall
                be two lists i.e. the Central and the State list.
                (d)            Sub-Clause 9 of Article 338B does not in
                any way interfere with the powers of the State
                Government to prepare their own list. The classes
                included in State backward list do not automatically
                come into the Central list of OBC's.
                (e)            The State Government is to recommend
                to the President the category of inclusion/exclusion
                in scheduled Castes and Scheduled Tribes.                     Similar
                provision is provided in Article 342A for conferring
                Constitutional    status   for    backward           classes         for
                inclusion in the Central lists.
                (f)       In paragraph 48 of the Report, is clearly
                stated that the amendment Bill neither interferes
                with the powers of the State Government, nor with
                State Backward Class Commission to identify SEBC
                classes even after the passage of the said Bill.
                (g)       That the reservation of post under the State
                or under any authority of the State or seats in the
                educational institutions within the State was beyond
                the preview of the 123rd amendment.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

patil-sachin.
::: Uploaded on - 27/06/2019                      ::: Downloaded on - 28/06/2019 05:25:22 :::
                                    248                           Marata(J) final.doc
                (h)       Para-67 of the report states that the backward
                class commission will continue to exercise its power
                of inclusion/exclusion of backward classes in relation
                to the State lists.
                (i)       The summary of the Report reproduced above
                resulted in several amendments being rejected since
                it was a view of the Government of India that the
                amendment does not seek any charge in the powers
                or in the status of the State of Government or the
                State Backward Commission.
                (j)       The term "list" is defined under Section 2-C of
                the National Commission for backward classes Act,
                which clearly states that the list relates to services
                under the       Government     of India        or any         other
                authority under the control by the Government of
                India.
72               Mr.Talekar      has     vehemently        submitted            that
identification of any class as socially and educationally
backward, after the 102nd Constitution Amendment has to be
necessarily preceded by the reference to the National
Commission for SEBC constituted by the said amendment. He
would submit that the State Backward Class Commission
stands denuded of any power to identify SEBC and in turn,
exercise of its enabling power by carving out a privilege in
form of reservation for them. We are not ready to agree with
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:22 :::
                                    249                            Marata(J) final.doc
the     said      submission      of Shri    Talekar.       With       the     102 nd
Amendment, simultaneously, the National Commission for
Backward Classes Act of 1993 stands repealed. However, in
terms of the mandate laid down by the Nine Judges Bench in
Indra Sawhney, it is left it to the discretion of the respective
State to identify the backward classes and in order to have a
quantifiable data before it, the States were directed to
constitute           the       backward     class       commissions.              The
backwardness of a class/community can be better understood
by taking into consideration the prevailing factors by the State
itself and when it comes to exercise of the enabling power
who can be better positioned than the State to ascertain as to
what steps are necessary for advancement of this class or to
be subjectively satisfied that this class is not adequately
represented in its State.                  When this power has been
construed as a discretion vested in the State, in that
contingency, the identification of the beneficiaries of this class
is better left to the State, and therefore, in our considered
view, the amendment conferring a constitutional status on the
National Backward Class Commission would not materially
affect the power of the States to recognize such class and
exercise its enabling power.             Moreover, the Commission is not
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:22 :::
                                250                       Marata(J) final.doc
yet constituted nor the exercise contemplated under Article
342A has been undertaken and in any contingency, it was not
the intention of the Parliament to stall the entire process in
the respective States till the exercise contemplated by the
102nd Amendment gets converted into a reality. Hence, in our
view, the legislative competency of the State legislature, is
not at all curtailed by the Constitution (102nd Amendment)
Act of 2018.
(c)              As regard the argument about the legislative
incompetency on account of the ceiling limit laid down in the
case of Indra Sawhney, we have exhaustively dealt with the
said point under Head "VII"
(IV)       Whether the State has been able to establish the
social and educational backwardness and inadequacy
of representation of the Maratha Community in public
employment on the basis of the report of the MSBCC
under the Chairmanship of Justice Gaikwad on the
basis of quantifiable and contemporaneous data ?
73               Before proceeding to deal with the impugned
enactment, we would deliberate on the report of the
Maharashtra State Backward Classes Commission under the
Chairmanship of Justice Gaikwad.         The said report after
patil-sachin.
::: Uploaded on - 27/06/2019            ::: Downloaded on - 28/06/2019 05:25:22 :::
                                      251                            Marata(J) final.docDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

evolving and applying the parameters of the backwardness,
has declared the Maratha community as backward and
classified it as "socially and educationally backward class". It
is this SEBC class which has been provided with reservation
under section 4 of the impugned Act and report of the
commission in the form of quantifiable data forms the basis of
the enactment. We, therefore, proceed to deal with the issue
as     to       whether        the   commission      has      established            the
backwardness of the community so as to justify the exercise of
enabling power by the State under Articles 15(4) and 15(5) of
the Constitution of India.
74                The conferment of the benefit of reservation and
concession by the State is dependent on the credibility of the
material collected by the Commission and its analysis, leading
to a conclusion of backwardness of Maratha community.
75                The identification of citizens has been left to the
State by the majority view of Justice B. P. JeevanReddy in Indra
Sawhney's case (supra).                    We would gainfully refer to the
following observations of the judgment :
                "780.        Now, we may turn to the identification
                of "backward class of citizens". How do you go about
patil-sachin.
::: Uploaded on - 27/06/2019                       ::: Downloaded on - 28/06/2019 05:25:22 :::
                                    252                             Marata(J) final.docDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                it? Where do you begin? Is the method to vary from
                State to State, region to region and from rural to
                urban? What do you do in the case of religions where
                caste system is not prevailing? What about other
                classes, groups and communities which do not wear
                the label of caste? Are the people living adjacent to
                cease-fire line (in Jammu and Kashmir) or hilly or
                inaccessible regions to be surveyed and identified as
                backward classes for the purpose of Article 16(4)? And
                so on and so forth are the many questions asked of us.
                We shall answer them. But our answers will necessarily
                deal with generalities of the situation and not with
                problems or issues of a peripheral nature which are
                peculiar to a particular State, district or region. Each
                and every situation cannot be visualised and
                answered. That must be left to the appropriate
                authorities appointed to identify. We can lay down
                only general guidelines.
                782.            Coming back to the question of
                identification, the fact remains that one has to begin
                somewhere - with some group, class or section. There
                is no set or recognised method. There is no law or
                other     statutory     instrument     prescribing    the
                methodology. The ultimate idea is to survey the entire
                populace. If so, one can well begin with castes, which
                represent explicit identifiable social classes/groupings,
                more particularly when Article 16(4) seeks to
                ameliorate       social    backwardness.      What      is
                unconstitutional with it, more so when caste,
                occupation, poverty and social backwardness are so
                closely inter-twined in our society? [Individual survey is
                out of question, since Article 16(4) speaks of class
                protection and not individual protection]. This does not
                mean that one can wind up the process of
                identification with the castes. Besides castes (whether
                found among Hindus or others) there may be other
                communities, groups, classes and denominations
                which may qualify as backward class of citizens. For
                example, in a particular State, Muslim community as a
                whole may be found socially backward. (As a matter of
                fact, they are so treated in the State of Karnataka as
                well as in the State of Kerala by their respective State
                Governments). Similarly, certain sections and
                denominations among Christians in Kerala who were
                included among backward communities notified in the
                former princely State of Travancore as far back as in
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                      ::: Downloaded on - 28/06/2019 05:25:22 :::
                                   253                             Marata(J) final.doc
                1935 may also be surveyed and so on and so forth.
                Any authority entrusted with the task of identifying
                backward classes may well start with the castes. It can
                take caste 'A', apply the criteria of backwardness
                evolved by it to that caste and determine whether it
                qualifies as a backward class or not. If it does qualify,
                what emerges is a backward class, for the purposes of
                Clause (4) of Article 16. The concept of 'caste' in this
                behalf is not confined to castes among Hindus. It
                extends to castes, wherever they obtain as a fact,
                irrespective of religious sanction for such practice.
                Having exhausted the castes or simultaneously with it,
                the authority may take up for consideration other
                occupational groups, communities and classes. For
                example, it may take up the Muslim community (After
                excluding those sections, castes and groups, if any,
                who have already been considered) and find out
                whether it can be characterised as a backward class in
                that State or region, as the case may be. The approach
                may differ from State to State since the conditions in
                each State may differ. Nay, even within a State,
                conditions may differ from region to region. Similarly,
                Christians may also be considered. If in a given place,
                like Kerala, there are several denominations, sections
                or divisions, each of these groups may separately be
                considered. In this manner, all the classes among the
                populace will be covered and that is the central idea.
                The effort should be to consider all the available
                groups, sections and classes of society in whichever
                order one proceeds. Since caste represents an
                existing, identifiable, social group spread over an
                overwhelming majority of the country's population, we
                say one may well begin with castes, if one so chooses,
                and then go to other groups, sections and classes. We
                may say, at this stage, that we broadly commend the
                approach and methodology adopted by Justice
                O.Chinnappa Reddy Commission in this respect.
                783.            We do not mean to suggest - we may
                reiterate - that the procedure indicated hereinabove is
                the only procedure or method/approach to be adopted.
                Indeed, there is no such thing as a standard or model
                procedure/approach. It is for the authority (appointed
                to identify) to adopt such approach and procedure as it
                thinks appropriate, and so long as the approach
                adopted by it is fair and adequate, the court has no
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:22 :::
                                     254                           Marata(J) final.doc
                say in the matter. The only object of the discussion in
                the preceding para is to emphasise that if a
                Commission/Authority       begins    its   process     of
                identification with castes (among Hindus) and
                occupational groupings among others, it cannot by
                that reason alone be said to be constitutionally or
                legally bad. We must also say that there is no rule of
                law that a test to be applied for identifying backward
                classes should be only one and/or uniform. In a vast
                country like India, it is simply not practicable. If the
                real object is to discover and locate backwardness,
                and if such backwardness is found in a caste, it can be
                treated as backward; if it is found in any other group,
                section or class, they too can be treated as backward.
76                A perusal of above observations makes it clear
that identification of backward class of citizens is left to the
appropriate authority appointed by the State. The Apex Court
also held that there is no set or recognized method in
identification of the backward class of citizens and there is no
law       or       other       statutory   instrument      prescribing            the
methodology. The Apex Court further held that it is for the
authority appointed by the State to identify the backward
class of citizens to adopt such approach and procedure as it
thinks appropriate.              It was also held that so long as the
approach adopted by the authority is fair and adequate, the
Court has no say in the matter.
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:22 :::
                                       255                            Marata(J) final.doc
77               In view of the directions issued by the Apex Court,
the State of Maharashtra enacted the Maharashtra State
Backward Classes Commission Act in the year 2005. Prior to
the said enactment, the State Commissions in the form of
Bapat Commission and Khatri Commission, delved into the
issue of backwardness of this community. Apart from this, two
national commissions also deliberated on the said issue and it
has been strenuously argued by the learned counsel for the
Petitioners that none of the commissions finds favour with the
backwardness of Maratha community and their demand of
being included in the list of other backward class came to be
rejected. Rane Committe appointed by the State Government
in the year 2013 was the only committee who gave a positive
recommendation, which resulted into the State introducing an
ordinance in the year 2015 and the similar enactment in the
year 2015.
78               The said ordinance and the enactment were
assailed in a writ petition and this Court has stayed its effect
and operation. Resultantly, the Maratha community was not
conferred         with         any   benefits   stipulated     under        the     said
enactment. During the pendency of petition before this Court,
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                        ::: Downloaded on - 28/06/2019 05:25:22 :::
                                 256                            Marata(J) final.doc
the State constituted the Maharashtra State Backward Classes
Commission by issuing notification dated 4 th January 2017 in
exercise of power conferred under sub-section (1) and clauses
(a), (b) and (c) of sub-section (2) of section 3 of the
Maharashtra State Backward Classes Commission Act, 2005.
The government referred the following terms of reference to
the commission.
                 1.    To determine the contemporary criteria and
                 parameters to be adopted in ascertaining the
                 social, educational and economic backwardness
                 for the benefits of reservation in present context
                 and in confirmity with the Constitutional
                 mandate, reservation laws and various judgments
                 of the courts.
                 2.   To define exceptional circumstances and or
                 extraordinary situations to be applied for the
                 benefits of reservation in the present context.
                 3.   To scrutinize and inspect the quantifiable
                 and other data collected by State Govt., State
                 and National Commissions for Backward Classes
                 and Rane Committee along with data placed
                 before the Hon'ble High Court of Judicature at
                 Bombay in WP no. 3151/2014 and other
                 connected matters for investigating the social,
                 educational and economical backwardness of
                 Maratha Community by applying the criteria and
                 parameters determined as above.
                 4.     To determine the representation of Maratha
                 Community in the public employment under
                 Central and State Government establishments,
                 Public Sector Undertaking, Universities and other
                 Institutions aided and funded by Government.
                 5.   To ascertain proportion of population of
                 Maratha Community in the State of Maharashtra
                 on the basis of records, reports, census and otherDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

patil-sachin.
::: Uploaded on - 27/06/2019                  ::: Downloaded on - 28/06/2019 05:25:22 :::
                                    257                          Marata(J) final.doc
                 available data.
                 6.   To investigate such other matters as the
                 State Government may hereafter refer to the
                 commission in this context.
                 7.   To submit a report to the State Government
                 by recording the facts and observations and
                 thereby make suitable recommendations.
                 Further the commission may -
                 a) Obtain such information or statistics as they
                 may consider necessary or relevant for their
                 purpose in such form and manner as they may
                 think appropriate from the Central and State
                 Government Offices, public sector undertaking,
                 establishments, universities and other institutions
                 and such other authorities, organizations or
                 individuals as may in the opinion of the
                 Commission be of assistance to them.
                 b) Avail advice of experts and researchers by
                 holding meetings with them and also get
                 assistance of recognized research institutions as
                 and when felt essential for analysis of the
                 quantifiable data and also for the efficient and
                 qualitative functioning of the Commission.
                 c)   Visit  or    depute     sub-committee/s     or
                 representative/s to visit such part/ s of the State
                 of Maharashtra and/or places in the country as
                 they may be considered necessary or convenient
                 for obtaining any information or data or
                 documents or otherwise.
                 d) Record the evidences and contentions lead by
                 the individuals as and when found necessary
                 during the course of investigation.
79               The Commission has representative members from
all the regions of the State.            The Commission requested its
members to suggest names of the institutions from theirDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

division for the purpose of carrying out survey. The details of
patil-sachin.
::: Uploaded on - 27/06/2019                   ::: Downloaded on - 28/06/2019 05:25:22 :::
                                  258                           Marata(J) final.doc
the Region-wise institutions recommended by the members
of the Commission are as under :
     1.     Guru Kripa Vikas Sansthan - Nashik Region
     2.     Gokhale Institute of Politics and Economics - Pune
            Region-wise
     3.     Rambhau Mhalgi Prabodhini Sanstha, Konkan Region
     4.     Sharda        Consultancy   Services   -    Vidarbha          Region
            (Nagpur, Amravati)
     5.     Chhatrapati Shivaji Prabodini Sanshta - Marathwada
            Region.
80               In addition to the above institutions, the following
experts were appointed for analysis of the data :
            1. Professor Sudhir Gavhane
            2. Dr. Omprakash Shivajirao Jadhav
            3. Prof. Ambadas Y. Mohite
                 It is worth to mention that the experts appointed
for analysis of the data are persons having rich experience
and expertise in their field.
METHODOLOGY AND PROCEDURE ADOPTED BY THE
COMMISSION :
81               Having regard to the constitutional provisions and
the decisions of the Constitution Courts , the Commission
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                  ::: Downloaded on - 28/06/2019 05:25:22 :::
                                  259                           Marata(J) final.doc
devised scientific method for collecting quantifiable data to
answer the terms of reference.              The Commission adopted
procedure in the following manner :-
a)       The Commission decided to conduct sample surveys so
as to collect information in respect of social, educational and
economic backwardness.
b)       In consultation with a        group of Social Scientists, the
Commission framed questionnaire             for the purpose of sample
surveys.
c)       The Commission decided to select five                  Talukas from
each District and two villages from each Taluka so selected
and collect information of all families from such selected
villages excluding tribal districts.
d)          In    addition,    the   Commission     decided         to    collect
information by selecting one Municipal Corporation and one
Municipal Council from each of six regions of the State of
Maharashtra , so as to cover the information in respect of the
Maratha community from the urban areas.
e)       To maintain uniformity in the surveys to be carried out by
all the agencies, the agencies were provided with common
questionnaire containing 40 questions for collecting required
information.
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                  ::: Downloaded on - 28/06/2019 05:25:22 :::
                                 260                           Marata(J) final.doc
f)       In addition to the information to be collected by way of
sample surveys, the Commission also decided to give
opportunity of being            heard to the public in the State of
Maharashtra excluding the tribal districts on the subject of
reservation to the Maratha community with reference to its
social          backwardness,     educational     backwardness                and
economical            backwardness.   For   the   said       purpose,          the
Commission decided to hold public hearings at the places so
selected from all the regions of the State of Maharashtra.
g)       The Commission also decided to call for opinions of
experts in the fields of history, sociology and agriculture so as
to find out social backwardness, educational backwardness
and economical backwardness of the Maratha Community.
h)       The Commission also decided to collect information from
the Directorate of Higher and Technical Education, Director of
Medical Education and all the Universities in the State of
Maharashtra including Agriculture Universities to find out the
percentage of students studying for different subjects, so as to
decide the educational backwardness or otherwise of the
Maratha community.
i)       The Commission also decided to collect information or
data from the State Government, Semi-Governmental and
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                 ::: Downloaded on - 28/06/2019 05:25:22 :::
                                261                           Marata(J) final.doc
autonomous organizations about the representation of the
Maratha community in the employment to find out whether it
is adequate or inadequate.
j)       The Commission also decided to examine and verify the
quantifiable data collected by the Rane Committee supported
by other materials accompanying additional affidavits filed in
the Court in writ petition (lodging) No.4100 of 2018.
82               The Commission undertook the sociological study
of the caste/community system and for that purpose took into
consideration the historical accounts.          The commission also
considered the historical documents so as to make an
assertive statement about the exact status of the Maratha
community. The commission noted Varna system / caste
system prevalent in the Indian society, which was divided
mainly in two categories, namely, Bhrahmins- higher castes
and Shudras - lower castes.          The commission also referred to
quotations from Shastras (Kandpurana) and Manusmruti and
found that Upanayana Sanskar is the sine qua non for
elevation to the higher caste / class.                 The commission
concluded that Upnayan sanskar is not observed / performed
in the Maratha community and therefore the same is
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                ::: Downloaded on - 28/06/2019 05:25:22 :::
                                    262                               Marata(J) final.doc
considered to be Shudras.
83                The Commission found that Maratha community is
engaged in agriculture, which is their traditional occupation.
The Commission examined the agricultural census of 2010-11
and found that the holding of the agriculturists have
decreased in the course of time because of ceiling laws as well
as family partitions. The commission noted that agriculturist
depends on rain to water crops which he grows. The judicial
note of the fact is taken by the commission that over the
years or alternate years, there is a short rainfall and there is
scarcity like situation in either one or other regions of
Maharashtra            State.      The    commission         on     the     basis       of
agricultural census also found that agricultural holdings of
agriculturists in the State of Maharashtra is 1.44 hectares,
whereas the holding of individuals in the State of Rajasthan is
3.07 hectares and in Madhya Pradesh it is 1.78 hectares, in
Punjab it is 3.77 hectares and in Gujarat it is 3.03 hectares.
The commission found that the holding of the agriculturists in
the     Maharashtra            mainly    of   the   Maratha        community               is
uneconomical holding mainly because it depends on rain
harvesting. The commission also found that income from the
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                        ::: Downloaded on - 28/06/2019 05:25:22 :::
                                263                         Marata(J) final.doc
agriculture is not even sufficient for the livelihood of Maratha
community. The commission concluded that considering the
holdings held by each family which are unirrigated and rain-
fed, the economic conditions of agriculturist class become
worst and deteriorated day by day.
84                Out of 43629 families surveyed, the commission
found that 345 persons from equal number of families have
committed suicide from all the caste groups during last 10
years.          Out of these 345 persons, 277(80.28%) were from
Maratha families, which is exorbitantly high proportion as
compared to other castes indicating the grave state of socio-
economic plight of Maratha community warranting urgent
attention of the State to address this issue.         The Commission
found that the suicides in Maratha community are directly
related to degrading social status, depleting educational
opportunities in the reservation regimen of which they are not
the beneficiaries and deteriorating economic condition.
85                The Commission also called for the information
from the Labour Commissioner, Mumbai asking for the details
of menial workers known as Mathadi kamgar / hamals and
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019              ::: Downloaded on - 28/06/2019 05:25:22 :::
                                      264                              Marata(J) final.doc
found that as many as 1,25,669 families were reported to be
of mathadi workers, out of it 50,483 families, ie., more than
40% are Maratha families. They are residing in slums, having
no permanent houses, no facilities of batherooms or toilets.
The commission also referred to the survey conducted by
Gokhale Institute of Politics and Economics in the year 2016 at
the     instance         of Commissioner        of Labour,            Mumbai          and
concluded that in the year 2016, total 2,12,519 mathadis /
hamals were found to be registered with 36 different mathadi
boards established under the Maharashtra Act No. XXX of
20169.          The Gokhale Institute concluded that out of total
registered          mathadi        hamals,    43%       were       from        Maratha
community.
86               The commission noted that a large class of Maratha
community in Mumbai city is leading a life of dabbewalas. The
commission obtained their details from their associations. The
commission found that about 4800 families are found engaged
in the said occupation.                Out of this 4800 families, 4,600
families i.e., 95.8% are of Marathas. The commission found
that families of dabbewalas are leading life without any social
status.           The          commission    noted     that      organisation            of
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                         ::: Downloaded on - 28/06/2019 05:25:22 :::
                                    265                         Marata(J) final.doc
dabbewalas has informed it that number of customers of
dabbewalas are decreased and consequently dabawalas were
required to search for alternative job where they do menial
work to learn livelihood for their families. Besides, the wives
of dabewalas work as maid-servants in the houses of others
where they wash clothes, clean utensils, etc. Moreover, the
children of dabbewalas work in morning to distribute daily
newspapers and to supply milk to various houses.                               The
commission was informed by the Association that because of
the financial condition of dabbewalas, they are unable to
afford to pay education fees of their children and as a result of
the      above        aspects   dabbewalas    are    socially       backward,
educationally backward and also economically backward and
by the days passed, their backwardness continues unabated
with rise therein.
87               The      sample   survey   was   carried       out     by      the
institutions named above extensively and the data was
collected and submitted to the Commission. The Commission,
in addition to this survey, also held public hearing in all parts
of the State excluding tribal district on reservation to Maratha
community and on its social, educational and economic
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                  ::: Downloaded on - 28/06/2019 05:25:22 :::
                                    266                            Marata(J) final.doc
backwardness.              The total persons heard by the Commission
were 1,97,522, out of which, 1,95,174 persons were in favour
of Maratha reservation. The Commission also considered
representations from experts, public at large and other
entities. The Commission called for opinion of the experts.
The Commission also called for information from Educational
Heads and Universities in the State and collected information
from       the      State      Government,   Semi      Governmental               and
autonomous             organisations     about   the      representation             of
Maratha community in public employment.
88                The Commission having regard to the principles set
out by the Hon'ble Apex Court while interpreting Articles 15
and 16 of the Constitution of India, in order to determine the
social,         educational     and   economic    backwardness              of     the
Maratha community, considered 26 contemporary parameters
to ascertain social backwardness and incorporated them in the
questionnaire.             So far as the economical backwardness in
concerned,            the      commission    considered         the       following
parameters viz. ration card entitlement, below poverty line
status, income level of family, borrowing status of family
during last 5 years, reasons for borrowing, source of borrowing
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:22 :::
                                       267                               Marata(J) final.doc
and loan repayment, vehicle ownership for personal use,
vehicle owned for occupational/agricultural use, agricultural
land owned in rural area and non-agricultural land owned.
89               As far as economical backwardness is concerned,
the Commission considered following parameters :
                 "Students           undergoing           primary            education,
proportion of drop-outs, proportion of students pass out in
higher secondary examination and proportion of conventional
graduates and professional graduates".
90               The data collected from the surveys has been
compiled          and          tabulated    by   the      experts         referred         to
hereinabove. The experts analyzed the data, recorded their
observations and thereafter have given their conclusions. The
analysis and observations of the data with respect to each of
the parameters given by the experts are as under :
          [A] Social backwardness :
          (1) With regard to occupation of head of family :
                   76.86% families of Maratha Class are found to
                   be engaged in the occupation of a griculture and
                   agriculture labour (combined), 6% are in
                   government and semi-government services, 3%
                   in private services, 4% in trade and industry and
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                           ::: Downloaded on - 28/06/2019 05:25:22 :::
                                    268                              Marata(J) final.doc
                   9% are invol ved in non-agricultural physical
                   labour for their livelihood.
                   76.86% of the Maratha families are involved in
                   own a griculture a n d 26.46% out of that, are also
                   undertaking f arming labour in t h e a g r i c u l t u r a l
                   f a rm s o f o t h e r s which is the highest of all
                   other Castes and Classes. 26.48% of Marathas
                   are earning livelihood by way of physical labour
                   in agricu lture farms as against 2.22% Kunbis,
                   22.24% OBCs, and 1.34% OOCs. This state of
                   affairs gets confirmed from the figures of the
                   national survey of Rural Livelihood done by
                   NABARD which reveals that the farmers in
                   Maharashtra are earning only 35% of their
                   income from the farming whereas 43% income is
                   generated from labour. Looking to the largest
                   percentage of Marathas involved in agricultural
                   labour compared to other classes confirms the
                   heavy dependence of Maratha cultivators on
                   agriculture labour for subsistence. The figures of
                   Kunbis involved in agriculture          labour        are
                   insignificant. It reveals a factual position as to
                   agriculture holdings. It is also confirmed under
                   Surveys of sugarcane labour where it is found that
                   most of Maratha labours are marginal farmers also but
                   they have to take up labour work of sugarcane
                   cutting for which they migrate to distant places as
                   income from agriculture is not adequate to make
                   both ends meet l eaving farms at the mercy of
                   their extended family members .
                  Marathas are involved mostly in agriculture and
                  related agriculture labour in rural areas. Their
                  involvement in non agriculture related labour is
                  less compared to other OBCs who have to work in
                  such activities as there is no other source for
                  livelihood. When Marathas migrate to urban area
                  their involvement in physical oriented non
                  agriculture   labour- wage,  self-employment   is
                  significant compared to others as seen from their
                  rampant percentage in works as Mathadis,
                  Dabbewala s, Maid Servants, Port labour, Mill
                  labour, Market Committee kamgars etc. in urban
                  areas.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

patil-sachin.
::: Uploaded on - 27/06/2019                       ::: Downloaded on - 28/06/2019 05:25:23 :::
                                  269                           Marata(J) final.doc
                  The m ajor involvement in non-agricultural physical
                  labour in rural areas is also by way of earning
                  additional income from works under Mahatma
                  Gandhi National Rural Employment Guarantee
                  Program (MGNREGP). Marathas cultivators do not
                  have much spare time to earn such extra income
                  whereas villagers belonging to other Caste/Class
                  do obtain extra income. However plight of
                  Marathas if collated with their major dependence
                  on agriculture for livelihood and day-to-day
                  survival, which is not generating adequate
                  income (only 35%) and no spare time to earn
                  extra income from non-farm activities, they had
                  to withdraw some of their family members from
                  agriculture to be migrated to urban areas for
                  meeting the gap in the l ivelihood income where
                  they have to perform work in lowly labour oriented
                  activities as revealed from the highest percentage
                  of migration to urban centers and involvement in
                  substandard wage earning activities in private
                  sector as compared to Kunbis or OBCs. This is a
                  clear indication of the social degradation and
                  deteriorating    economic     condition/status   of
                  Maratha class of citizenry.
          (2) With regard to Nature of Houses of the
          Families :
                    More than 42% families of Marathas live in
                    Kuccha houses, 2% live in shelters made from
                    grass and wastes, 26% live in semi-Pucca houses
                    with no amenities and only 29 % live in Pucca-
                    houses
                    In all 71% families of Maratha caste live in
                    shelters made from grass and wastes, Kuccha
                    houses and semi-Pucca houses with no
                    amenities    which     show   their   miserable
                    conditions and low standard of living. Even the
                    Pucca houses in rural areas are not of that type
                    which is built in urban areas. The so-called
                    Pucca houses in rural area are not as pucca
                    and furnished as like urban areas.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

patil-sachin.
::: Uploaded on - 27/06/2019                  ::: Downloaded on - 28/06/2019 05:25:23 :::
                                   270                            Marata(J) final.doc
          (3) With regard to Type of locality of Family :
                   More than 61% families of Marathas live in village-
                   locality while 29% live in temporary habitats, 8%
                   live in agricultural land habitats and 2% live in
                   slum and like-wise areas. The data reveal that in
                   all 39% families of Marathas live in temporary
                   habitats, agriculture-land habitats and slum a n d
                   like-wise areas. This proportion is quite higher
                   than other caste-groups. It should be considered
                   that the Maratha families living in village
                   localities are also placed in the same situation
                   of those families who live in temporary and
                   agricultural -habitats.
          (4) With regard to Type of Ownership of House :
                   More than 94% families of Maratha live in owned
                   houses, 6% live in rented houses or are sharing
                   dwellings with others they being homeless. The
                   ownership proportion of the houses in rural areas
                   in all groups is by and large in the same range.
          (5) With regard to Number of Rooms for the use of
          family :
                   More than 21% families of Maratha caste live in
                   one room houses, 48% live in two rooms, 20% live
                   in three rooms, 8% live in four room and less than
                   3% live in five and more rooms. The standard of
                   living is lower in Marathas. The percentage of
                   families living in four rooms is the least in Maratha
                   community (only 8%) as compared to other
                   castes.
          (6) With regard to Availability of separate kitchen :
                 58% families of Maratha community are having
                 a separate kitchen while 42% of families are
                 having no separate Kitchen.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

          (7) With regard to type of bathroom for family use :
                 More than 14% of Maratha families are not
                 having bathroom facility, 48% families have
patil-sachin.
::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:23 :::
                                  271                           Marata(J) final.doc
                 Kuccha bathroom and only 37% families have
                 Pucca I Closed Bathroom. The percentage of
                 families having no separate bath room is
                 highest in Maratha Community which is 14%
                 followed by OBC (12%) as compared to other
                 castes.
          (8) With regard to availability and use of toilet :
                 More than 18% of Maratha families are not having
                 separate toilet facility, 76% families have toilet
                 and 5% families go to the public toilets. The
                 percentage of families having no toilet is 19% in
                 the Maratha community and it is the highest as
                 compared to other castes.
          (9) With regard to sources of water for drinking :
                 35% of Maratha families have personal drinking
                 water tab connection at homes, 46% families go to
                 public water tabs, 16% families go to public
                 well/bore and 2% go to river and other water
                 sources for their domestic water uses.       The
                 percentage of Maratha population having personal
                 tab connection as a source of drinking water is
                 least as compared to other caste groups. The
                 percentage of Maratha population using public
                 water sources and public well and bore well is
                 highest as compared to other castes.
          (10) With regard to fuel for cooking and domestic
          uses of family :
                   4% of Maratha families use kerosene for cooking,
                   60% families have LP gas connections, 2% families
                   are using electricity, bio-gas, solar energy for
                   cooking and 32% families are using fire wood, cow
                   dung, wastage for cooking. The percentage of
                   families using LP gas is least in the MarathasDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                   (59%) as compared to other caste / class groups.
          (11) With regard to family member committing
          suicide during last 10 years. :
                   In a survey of 43629, 345 persons from equal
                   number of families have committed suicides from
patil-sachin.
::: Uploaded on - 27/06/2019                  ::: Downloaded on - 28/06/2019 05:25:23 :::
                                  272                            Marata(J) final.doc
                   all the caste groups during last 10 years. Out of
                   these 345 persons, 277(80%) were from Maratha
                   families which is exorbitantly high proportion as
                   compared to other castes.
          (12) With regard to migration during last 10 years :
                 21% of Maratha families have migrated during last
                 10 years, which is very high as compared to
                 migration of family members of other castes.
          (13) With regard to occupation of migrants :
                 17% migrant families of Maratha caste are
                 engaged in private service, most of which are lowly
                 jobs or daily wage earnings. 11% are small self-
                 employment activities or petty business.       52%
                 families engaged in physical labour. 9% are other /
                 contractual work of lower categories.
          (14) With regard to          inter-caste /     inter-religious
          marriage in family :
                 98.53% of the Maratha families do not enter into
                 inter-caste / inter-religious marriages.
          (16) With regard to widow / widower remarriage in
          family :
                 94% of the Maratha families do not enter into
                 widow / widower remarriage in family which is the
                 highest as compared to other castes.
          (17) With regard to girls' age of marriage in family :
                 18% Maratha families marry their daughters at the
                 age of 16 to 18 years and those families marrying
                 them between 18 to 21 is 54.50% and more than
                 21 years is 27%. 18% of the Maratha families
                 marry their daughters before they attend the legalDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                 age of girl's marriage of 16 to 18 years, which is
                 highest as compared to other castes.
          (18) With regard to nature of treatment in families
          (Health) :
                 9% of Marathas take treatment exclusively from
                 Mantrik / tantrik, not believing in any modern or
                 traditionally recognised scientific treatment. While
patil-sachin.
::: Uploaded on - 27/06/2019                   ::: Downloaded on - 28/06/2019 05:25:23 :::
                                 273                             Marata(J) final.doc
                 71% take treatement from doctors. 6% resort to
                 treatment from house made sources, while 2%
                 have no taken any treatment at all leaving it to fate
                 to get cured.
          (19) With regard to nature of treatment for jaundice
          in families :
                 9.65% Marathas take treatment form mantrik /
                 tantrik. 69% take treatment from doctors. 5.16%
                 usually resort to house made remedies and 0.54%
                 have not taken any medicine or treatment leaving
                 it to the mercy of God. The proportion of treatment
                 from doctor is lower in the Marathas than all other
                 castes.
          (20) With regard to nature of treatment for nominal
          illness in family :
                 3.14 families take treatment from mantrik / Tantric,
                 75.28% take treatment from Doctors, 7.33%
                 Respondents believe in house made sources.
                 0.56% respondents have not taken any treatment
                 and 13.69% respondents take treatment from
                 both the homemade measures and doctors. The
                 comparative     proportion   of treatment      from
                 Mantrik/Tantric, homemade measures, not taking
                 any treatment and both homemade and Doctor
                 are higher and the proportion of treatment from
                 doctor is lower in Marathas than all other castes.
          (21) With regard to influence of superstitions / Blind
          (Vow/Navas) :
                52.84 % Marathas are under the influence of
                superstitions / blind (Vow/Navas) faith. This
                proportion is too much higher than all otherDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                castes. It indicates lack of rational thinking and
                influence of unscientific approach to deal with the
                problems being encountered in the day-to-day
                lives of Maratha Community. It is certainly due to
                lack in education, living under the influence of
                superstitions and lack of social awareness.
patil-sachin.
::: Uploaded on - 27/06/2019                   ::: Downloaded on - 28/06/2019 05:25:23 :::
                                  274                            Marata(J) final.doc
          (22) With regard to animal sacrifices :
                 39.22% Marathas believe in the practice of killing
                 goats/ cocks/ animals to please supernatural
                 powers for fulfillment of their wish / desire /
                 demand. The percentage of Maratha is highest of
                 all the OBCs and OOCs.
          (23) With regard to modern home appliances uses :
                 It is seen that 25% of Marathas do not have any of the
                 appliances. 46% Maratha families have a television,
                 while less than 1% own and use refrigerators, washing
                 machines, Air conditioners and computers. It is also
                 seen that the proportion of No-Appliance-Users is very
                 high in Marathas as compared to other OBCS.
          (24) With regard to inferior status of the socially
          recognised traditional occupation from own
          perspective :
                 It is seen that 53.28% of Marathas perceive their
                 occupational status as inferior and this proportion
                 is higher in Marathas as compared to other caste-
                 groups.     Most of them are involved in the
                 occupation of agriculture and dry land farming not
                 yielding even subsistence level income.        The
                 percentage in other OBCs an OOCs describing their
                 occupation as inferior is lesser as compared to
                 Marathas.
          (25) Whether others consider your occupation as
          inferior :
                 53.04 Marathas affirmed that other peoples
                 consider their occupation has inferior status n theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                 society and this proportion is higher in Marathas as
                 compared to other caste-groups.
          (26) With regard to types of backwardness of
          Maratha community :
                 73% of Marathas feel that they are suffering from
                 all types of backwardness, while this percentage in
                 Kunbi caste is 19% and 45% for other OBC Caste
                 and 25.56% for OCCs.          The Marathas are
                 depolarized lot, desperate and lost their self
                 respect.
patil-sachin.
::: Uploaded on - 27/06/2019                   ::: Downloaded on - 28/06/2019 05:25:23 :::
                                 275                            Marata(J) final.doc
          (27) Maratha Community considered as backward
          by others :
                 It is observed that 98% of the Marathas, 89% of
                 Kunbis, 89% OCCs and 90% OBCs affirm/feel that
                 Maratha is a backward caste.
          (28) With regard to women in family engaged in
          physical labour for livelihood :
                 89% Marathas affirmed that female family
                 members of the community perform physical
                 labour for the family occupation of agriculture or
                 for adding earnings to the family income or for
                 livelihood.   Labour work performance to earn
                 livelihood or support family income gap is also
                 higher in Maratha community, be they working as
                 maid-servants, sugarcane cutting labour, as cook
                 for other families.
          [B] Educational backwardness :
          (1) With regard to educational level of head of
          family :
                 13% heads of Maratha families are illiterate,
                 35.31% have taken education upto primary level,
                 around 43% have taken education upto secondary
                 and higher secondary level and mere 6% have
                 taken education upto graduation and post-
                 graduation, whereas only 0.77% have taken
                 education in technical and professional streams.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

          (2) With regard        to   education     of     children        of
          Marathas :
                 Of the total of Marathas' school and college going
                 children, 86.4 are found to be in primary level
                 (standard 1 to 8), 6.5% are found to be in
                 secondary level (standard 9 to 10), 4% are found to
                 be taking higher secondary / junior college level
                 education (standard 11 to 12). With regard to
                 UG/PG level, it is 2.6%, and whereas technical
                 courses level are found to be 0.5% only.
patil-sachin.
::: Uploaded on - 27/06/2019                  ::: Downloaded on - 28/06/2019 05:25:23 :::
                                  276                            Marata(J) final.doc
          [C] Economical backwardness :
          (1) With regard to types of ration card :
                 21.97% of Maratha community families have
                 yellow ration card, whereas 70.97% Maratha
                 families have orange ration card and 3% have
                 white ration cards and 4% have no ration cards.
          (2) With regard to below poverty line status :
              37% families of Marathas are below poverty
              line compared to the State rural average of 24.
          (3) With regard to income level of family :
                 22% Maratha families have annual income upto Rs.
                 24,000/-.   22% Maratha families have annual
                 income between Rs. 24,001/- to 50,000/-. 19%
                 Maratha families have annual income between
                 Rs.50,001/- to 1,00,000/-. 8% Maratha families
                 have annual income between Rs.1,00,001/- to
                 4,00,000/- and just 0.46% Maratha families have
                 annual income more than Rs.4,00,000/-.
          (4) With regard to borrowing status of family
          during last 5 years :
                 On an average 52% of Marathas have taken the
                 loan in last 5 years. As compared to other castes,
                 this proportion is highest of all of them. It shows
                 Marathas dependency on borrowings to make bothDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                 ends meet because of low income generated from
                 agriculture, which is their main source of livelihood.
          (5) With regard to reasons for borrowing :
                 85.65% Maratha families take loan for agricultural
                 purposes, 6% Maratha families take loan for their
                 profession, 2% for marriages, 1% for illness, 0.32%
                 for religious activities and 2% for child education
                 and 3% for other purposes.
          (6) With regard to source of borrowing and loan
          repayment :
                 40.03% Marathas have taken loan from banks,
                 39.94% Marathas have taken loan from co-
                 operative societies, 14% Marathas have taken loan
patil-sachin.
::: Uploaded on - 27/06/2019                   ::: Downloaded on - 28/06/2019 05:25:23 :::
                                 277                             Marata(J) final.doc
                 from private money-lenders, 2.10% Marathas have
                 taken loan from relatives or friends and 2.14%
                 Marathas have taken loan from private banks and
                 other sources.
                 7.97% Marathas had to sell their properties and
                 assets for repayment of loans. This proportion is
                 higher as compared to other castes-groups.
          (7) With regard to vehicles owned for personal
          use :
                48.97% Marathas have no personally owned
                vehicles of any kind. 47% Marathas have two
                wheelers, 0.45% Marathas have 3 wheelers and
                only 0.53 Maratha families have four wheelers.
          (8) With regard to vehicles owned for occupational
          use :
                78.31% families of Marathas have no occupational
                vehicles owned by them.
          (9) With regard to agricultural land owned in rural
          areas :
                8.66% of Maratha families are landless, 62.74% of
                Maratha families own agricultural land not more
                than 2.5 acres, 19% own agricultural land moreDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                than 2.5 acres and less than 5 acres, 6% of Maratha
                families own agricultural land in the range of 5 to 10
                acres and just 2.7% of Maratha families have
                agricultural land more than 10 acres.
          (10) With regard to non-agricultural land owned :
                 88% of Maratha families have no non-agricultural
                 lands of their own. 9% of Maratha families own
                 such land to the extent of 1000 sq.ft., 0.65% of
                 Maratha families have plot of land of themselves in
                 the range of 1000 to 2000 sq.ft. and 9.48% of
                 Maratha families have ownership of land in the
                 range of 2000 to 3000 sq. ft, and only 1% of
                 Maratha families have owned the plot of non-
                 agricultural land more than 3000 sq.ft.
patil-sachin.
::: Uploaded on - 27/06/2019                   ::: Downloaded on - 28/06/2019 05:25:23 :::
                                      278                             Marata(J) final.doc
91               Apart from the data collected through surveys, the
Commission also collected data from the hearings and
representations.               The Commission received total of 1,97,522
representations from individuals as well as from various
organizations and public bodies.                     The Commission also
received          gram-sabha          resolutions      from        282        villages-
panchayats.            Out of these representations and gram-sabha
resolutions, only 84 representations stated that no reservation
should be given to Maratha community, which is 0.04% of
total representations received by the commission. The rest of
the representations/gram-sabha resolutions have demanded
reservations for the Maratha community.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

MARKING SYSTEM :
92               For      the      purpose   of     marking          system,          the
Commission fixed broad parameters as follows :
[A]      Social backwardness :
         Considered lower in social structure on the basis of
caste, considered to be pursuing lower occupation/livelihood,
females engaged in physical labour, males engaged in
physical labour.
patil-sachin.
::: Uploaded on - 27/06/2019                        ::: Downloaded on - 28/06/2019 05:25:23 :::
                                     279                          Marata(J) final.doc
[B]      Educational backwardness :
         Students undergoing primary education, proportion of
drop-outs, proportion of students passing out in higher
secondary examinations, proportion of conventional graduates
/ professional graduates.
[C]      Economical backwardness :
         Percentage of families below poverty line, percentage of
families living in Kuccha houses, strength of marginal farmers,
strength of landless families.
93                Out of total 25 marks, the commission allotted 10
marks to Maratha community for social backwardness, 8
marks           for   educational    backwardness      and      7    marks        forDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

economical            backwardness.       The   Marathas         were       to     be
considered backward if they obtain more than 50% of total
marks, i.e., 12.5 marks out of 25 marks.
94                The Commission considered the analysis of data
collected in surveys regarding the backwardness of Maratha
community and compared the same with the State average
and on the basis of the parameters mentioned hereinabove,
out of 10 marks the Commission allotted 7.5 marks for social
patil-sachin.
::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:23 :::
                                   280                             Marata(J) final.doc
backwardness to Maratha community and, therefore, the
Marathas were held to be socially backward. The Commission
allotted 8 out of 8 marks for educational backwardness to the
Maratha community and, therefore, they were held to be
educationally backward.               So far marks which were to be
allotted under the head of "economic backwardness" is
concerned, the Commission allotted 6 out of total 7 marks to
the      Maratha          community     and    held    them        economically
backward. Thus, Maratha community got 22.5 marks out of
total 25         marks under the three different heads viz. social
backwardness, educational backwardness and economical
backwardness.              The Commission accordingly concluded that
the Maratha community is                      socially, educationally andDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

economically backward.
Whether Marathas are inadequately represented in
public employment.
95               So far as the representation of Maratha community
in services under the State is concerned, the Commission has
considered the same extensively in Chapter IX of Volume III of
the report. The Commission also took into consideration the
report of the Rane Committee that the representation of
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:23 :::
                                281                         Marata(J) final.doc
Marathas in public employment is 14.68% of total sanctioned
posts and that it is more in Grade C and D as compared to
Grade A and B. Apart from the report of Rane Committee, the
Commission also obtained independent data and found that
the proportion of Maratha Class employees against sanctioned
posts who are eligible only for open category posts is 11.16%
in Grade-A, 10.86 % in Grade-B, 16.09% in Grade-C and
12.07% in Grade-D. Whereas the proportion of Maratha Class
employees against the filled post as on 31st August, 2018 is
18.95% in Grade-A, 15.22% in Grade-B, 19.56% in Grade-C
and 18.23% in Grade-D. The combined average proportion of
Maratha employees in all the four grades is found to be 14.63
% against total sanctioned posts and 19.05% against the filledDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

posts. Having regard to these figure, the Commission arrived
at the conclusion that in none of the four grades, the strength
of Maratha Class employees is touching the proportion to their
population in the State which, based on various sources, is
estimated at to be 30%.
96               All these posts referred to in above paragraph in
Class A, B and C occupied by Maratha community are from the
open category, they being included in the unreserved
patil-sachin.
::: Uploaded on - 27/06/2019              ::: Downloaded on - 28/06/2019 05:25:23 :::
                                        282                             Marata(J) final.doc
category for which 48% of the total posts as against 52% for
all    the      reserved         class   categories     are      available.            The
commission considered the proportion of 48% of the total
available        open          class   posts   occupied       by     average          30%
population of Maratha in the State and compared the same
with the total open category citizens, which population is
averaged to be approximately 12% including unreserved
minorities (excluding 13% Scheduled Caste + 7% Schedulted
Tribes + 38% OBCs including minority communities included in
OBCs). Having compared the availability of seats for the open
class, the commission came to the conclusion that out of total
5,72,214 open category posts filled in as on 30 th August 2018,
2,07,989 are occupied by 30% Maratha population whereasDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

remaining 3,64,225 are occupied by 12% to 15% open
category population, which makes out of that total open
category posts 30% Marathas obtained 36.34% of the open
category posts whereas 12% of all other open category
citizens obtained 63.66% of the open unreserved posts.
97               The Commission also called for information about
the officers in All India Cadres i.e. IAS, IPS and IFS cadres. The
Commission found that so far as IAS cadre is concerned, out of
patil-sachin.
::: Uploaded on - 27/06/2019                          ::: Downloaded on - 28/06/2019 05:25:23 :::
                                283                        Marata(J) final.doc
total unreserved posts, Marathas occupy 15.52 % and other
open category occupies 84.48% posts.           In IPS cadre, out of
total unreserved posts Marathas occupy 28% and other open
category occupies 72% posts. So far as IFS is concerned, out
of total unreserved posts, the Marathas occupy 17.97% and
other open category occupies 82.03%. The Commission also
concluded that out of total posts in Mantralaya, Marathas
occupy 16.17% of the sanctioned posts. The Commission also
collected the information of the teachers from some of the
universities in the State and found that so far as Pune
University is concerned, out of total unreserved posts, the
Marathas occupy 7% posts and other open category occupy
93% posts. As far as Mumbai University is concerned, 4.14%Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

out of total filled post are from Maratha Community.
Population of Marathas :
98               The commission has come to the conclusion that
the population of Marathas is 30% in the State of Maharashtra.
In order to arrive at this figure, the commission relied upon the
following material :
           (i) The census of 2011 provides figure of exact
           population percentage of SCs and STs and
           minorities.  According to this census, the
patil-sachin.
::: Uploaded on - 27/06/2019             ::: Downloaded on - 28/06/2019 05:25:23 :::
                                284                          Marata(J) final.doc
           population of scheduled caste is 11.81%, the
           population of scheduled tribe is 9.30%, the
           population of minority is 11.80%, the percentage
           of the OBCs is estimated under the Government
           of India documentation at 32.75% in the State
           (including DT/NT, SBCs).     The total of above
           percentage of population comes to 65.66%.
           What remains is two categories, namely, Maratha
           and other open classes, and population of these
           two categories is 34.34%. The commission took
           into consideration the population of other open
           categories excluding minorities, which is around
           4% to 5%, and the estimated population of
           Marathas is around 29.34%.
           (ii) The commission also relied upon the sample
           surveys carried out by the planning department
           of State Government to assist Rane Committee.
           In this survey, the population of Maratha
           community was found to be 32.14%
           (iii) The survey of Maratha population in the rural
           area was conducted by the Rural Development
           Department of the State Government through
           GIPE. This reflects figure of 27% Maratha in rural
           area. The commission took into considerationDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

           the integrating rural population percentage with
           the exodus to the urban area which was found to
           be around 6% to 7% per annum, and came to the
           conclusion that average Maratha population
           (rural plus urban) to be 30%.
           The average of above surveys comes to 30.49%
           and therefore the commission concluded that the
           population of Maratha community is about 30%
           of the total population of the Maharashtra state.
patil-sachin.
::: Uploaded on - 27/06/2019               ::: Downloaded on - 28/06/2019 05:25:23 :::
                                       285                           Marata(J) final.doc
99               After         identifying   the   backwardness              of      the
community by applying different yardsticks in the social,
educational and economical fields, the commission concluded
that the Maratha community is socially, educationally and
economically backward.                  It also concluded that the said
community is inadequately represented in the services under
the State. The commission dedicated Chapter-X of its report
to       "Exceptional             Circumstances     and/or          Extraordinary
Situations", justifying the excess of reservation beyond 50%
and we have separately dealt with the said circumstances and
examined the same in exercise of power of judicial review.
(V)      Scope of Judicial Review for Interference in the
Findings, conclusions, and recommendations of the
MSBCC.
100              The Constitution does not permit unfairness or
unreasonableness in state action in any sphere of its activityDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

contrary to the professed idea of its preamble. The power of
judicial review which is recognized as one of the basic features
of the Constitution enables the Constitutional Court to oversee
the action of the State for the purpose of satisfying that it is
not vitiated by the vice of arbitrariness. The wisdom of the
patil-sachin.
::: Uploaded on - 27/06/2019                       ::: Downloaded on - 28/06/2019 05:25:23 :::
                                      286                            Marata(J) final.doc
policy or the lack of it or the desirability of a better alternative
is not within the permissible scope of judicial review.                             The
Courts would not exercise its power so as to recast the policy
of the State or to substitute it with another. The power is to
be limited to the grounds of illegality, irrationality and
procedural impropriety.
                 The reports of the Backward Class Commissions
under the statutory framework which have been established in
form of an expert body to identify the backwardness
contemplated for conferring the benefits of reservation under
Article 15(4) and 16(4) must toe the line in somehow similar
way. As early as in 1972, the Apex Court in case of State of
Andhra Pradhesh versus U.S.V. Balram , 22 while dealing
with      the      report      of   the    Backward    Classes        Commission
appointed by the State of Andhra Pradesh, and which
recommended reservation of 30% of seats to persons
belonging to backward classes, dealt with the scope of judicialDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

review in the report of the Commission.
101              The       terms    of     reference   made        over       to     the
Commission included the determination of criteria to be
22 1972 (1) SCC 660
patil-sachin.
::: Uploaded on - 27/06/2019                       ::: Downloaded on - 28/06/2019 05:25:23 :::
                                    287                             Marata(J) final.doc
adopted in considering whether any section of citizens of India
in the State of Andhra Pradesh may be treated as socially and
educationally backward.             The Commission in its report, had
drawn a list of 92 castes, which are socially and educationally
backward and classified as backward classes. The Government
accepted the list drawn up by the Commission in toto. After
making a detailed reference to the methodology adopted by
the Commission which included the questionnaire which was
widely circulated to various authorities and organizations and
which referred to various matters regarding the criteria to be
adopted in ascertaining the backwardness of persons as well
as information on matters relating to social and educational
backwardness, it was noted that the Commission also called
information from Head of the Government Departments
regarding number of persons belonging to each class or
community            employed      in    their   department              and       also
information was sought from Principals of Colleges includingDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

the professional and technical colleges.               It was noted that the
Commission toured all the districts in the State and recorded
evidence          on       oath   from    the    representatives            of      the
communities.             The Commission visited the houses and huts
belonging to the different communities and also made
patil-sachin.
::: Uploaded on - 27/06/2019                      ::: Downloaded on - 28/06/2019 05:25:23 :::
                                  288                            Marata(J) final.doc
inquiries about their conditions of living, customs and their
problems. It then analyzed the replies received by it and the
Commission               made a reference to upto date statistical
information with regard to population of several communities.
After making reference to the report of the Commission
recommending provision for reservation on the basis of the
data collected by it, the Apex Court observed thus :-
                96             There is a criticism levelled that the
                Commission has used its personal knowledge for the
                purpose of characterising a particular group as
                backward. That, in the circumstances of the case, is
                inevitable and there is nothing improper or illegal.
                The very object of the Commission in touring the
                various areas and visiting the huts and habitations of
                people is to find out their actual living conditions.
                After all that information has been gathered by the
                Commission not secretly but openly. In fact the actual
                living conditions of habitation can be very
                satisfactorily judged (1) [1968] 2 S. C. R. 786 and
                found out only on a personal visit to the areas, which
                will give a more accurate picture of their living
                conditions and their surroundings. If the personal
                impressions gathered by the members of the
                Commission have also been utilised to augment the
                various other materials gathered as a result of
                detailed investigation, it cannot be said that theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                report of the Commission suffers from any vice
                merely on the ground that they imported personal
                knowledge. In our opinion, the High Court has not
                been fair to the Commission when it says that
                whenever the Commission found the figures obtained
                in respect of certain groups as relating to their
                educational standard being higher than the State
                average, it adopted an ingenious method of getting
                over that obstacle by importing personal knowledge.
                In fact the Commission has categorically stated that
                the information received from the various schools
                showed that the percentage of education was slightly
                higher than the State average in respect of certain
patil-sachin.
::: Uploaded on - 27/06/2019                   ::: Downloaded on - 28/06/2019 05:25:23 :::
                                  289                             Marata(J) final.doc
                small groups; but in view of the fact that their living
                conditions were deplorably poor, the slight higher
                percentage of literacy should not operate to their
                disadvantage.
102              The judgment of the Hon'ble Apex Court in Indra
Sawhney which was examining the report of the 2 nd Backward
Class Commission and its culmination into provision of
reservation of OBC, the Apex Court observed thus :-
            "―798....The language of clause (4) makes it
            clear that the question whether a backward class
            of citizens is not adequately represented in the
            services under the State is a matter within the
            subjective satisfaction of the State. This is
            evident from the fact that the said requirement is
            preceded by the words "in the opinion of the
            State". This opinion can be formed by the State
            on its own, i.e., on the basis of the material it has
            in its possession already or it may gather such
            material through a Commission/ Committee,
            person or authority. All that is required is, there
            must be some material upon which the opinion is
            formed. Indeed, in this matter the court should
            show due deference to the opinion of the State,
            which in the present context means the
            executive. The executive is supposed to know theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

            existing conditions in the society, drawn as it is
            from among the representatives of the people in
            Parliament/ Legislature. It does not, however,
            mean that the opinion formed is beyond judicial
            scrutiny altogether. The scope and reach of
            judicial scrutiny in matters within subjective
            satisfaction of the executive are well and
            extensively stated in Barium Chemicals v.
            Company Law Board [1966 Supp SCR 311 : AIR
            1967 SC 295] which need not be repeated here.
            Suffice it to mention that the said principles apply
            equally in the case of a constitutional provision
            like Article 16(4) which expressly places the
            particular fact (inadequate representation) within
            the subjective judgment of the State/executive."
patil-sachin.
::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:23 :::
                                 290                            Marata(J) final.doc
                 The Nine Judges Bench therefore, recorded that the
State is aware of the conditions prevailing and the subjective
satisfaction on adequacy of representation for backward
classes in public services should be based on subjective
satisfaction of the State.         That is the reason why direction
came to be issued to constitute Backward Class Commission
in each State so that the State would be able to identify the
classes which are backward and exercise its enabling power
for their advancement to ensure that they are adequately
represented in the services of the State.
103              In Nagaraj while dealing with the parameters
governing the assessment of adequacy of representation or ofDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

the impact on efficiency, the Constitution Bench of the Apex
Court held thus:
                 "45.............The basic presumption, however,
                 remains that it is the State who is in the best
                 position to define and measure merit in whatever
                 ways it considers it to be relevant to public
                 employment because ultimately it has to bear the
                 costs arising from errors in defining and
                 measuring merit. Similarly, the concept of "extent
                 of reservation" is not an absolute concept and like
                 merit it is context-specific.
                 49. Reservation is necessary for transcending
                 caste and not for perpetuating it. Reservation has
                 to be used in a limited sense otherwise it will
patil-sachin.
::: Uploaded on - 27/06/2019                  ::: Downloaded on - 28/06/2019 05:25:23 :::
                                  291                              Marata(J) final.doc
                 perpetuate casteism in the country. Reservation is
                 underwritten by a special justification. Equality in
Article 16(1) is individual specific whereas
                 reservation in Article 16(4) and Article 16(4A) is
                 enabling. The discretion of the State is, however,
                 subject to the existence of backwardness and ―
                 inadequacy      of    representation       in    public
                 employment. Backwardness has to be based on
                 objective factors whereas inadequacy has to
                 factually exist.   This is where judicial review
                 comes in. However, whether reservation in a given
                 case is desirable or not, as a policy, is not for us to
                 decide as long as the parameters mentioned in
Articles 16(4) and 16(4A) are maintained. As
                 stated above, equity, justice and merit (Article
                 335) / efficiency are variables which can only be
                 identified and measured by the State therefore in
                 each case, a contextual case has to be made out
                 depending upon different circumstances which
                 may exist State-wise."
                 102........... As stated above, equity, justice and
                 efficiency are variable factors. These factors are
                 context-specific. There is no fixed yardstick to
                 identify and measure these three factors, it willDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                 depend on the facts and circumstances of each
                 case.........."
104              The scope of the State Governments to
determine adequacy of representation in promotional
posts is emphasized in the decision of the Apex Court in
Jarnail Singh v. Lachhimi Naranain Gupta [(2018)
10 SCC 396]. The relevant observation is contained in
paragraph 35, which reads thus : -
         "35...According to us, Nagaraj has wisely left the test
         for determining adequacy of representation in
         promotional posts to the States for the simple reason
         that as the post gets higher, it may be necessary,
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:23 :::
                                292                           Marata(J) final.doc
         even if a proportionality test to the population as a
         whole is taken into account, to reduce the number of
         Scheduled Castes and Scheduled Tribes in
         promotional pots, as one goes upwards. This is for
         the simple reason that efficiency of administration
         has to be looked at every time promotions are made.
         As has been pointed out by B P Jeevan Reddy, J.'s
         judgment in Indra Sawhney, there may be certain
         posts right at the top, where reservation is
         impermissible altogether. For this reason, we make it
         clear that Article 16 (4A) has been couched in
         language which would leave it to the States to
         determine adequate representation depending upon
         the promotional post that is in question." (Emphasis
         supplied)"
105              In Ram Singh Vs. Union of India,23                 the Apex
Court once again dealt with the issue of scope of judicial
review in appreciating the findings recorded by the BackwardDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Class Commission in regards to the inclusion of Jat community
in the Central list of backward classes.                     The National
Commission for backward classes entrusted the task of survey
of the relevant material to an expert committee constituted by
ICSSR. On completion of the task, the Committee submitted
its report to the NCBC on 26 th February 2014 which was based
on a detailed consideration of various report of the State
backward classes commission, other available literature on
the subject and findings of the expert committee.                            The
decision was taken not to recommend the Jats for inclusion in
23 2015(4) SCC 696
patil-sachin.
::: Uploaded on - 27/06/2019                ::: Downloaded on - 28/06/2019 05:25:23 :::
                                    293                             Marata(J) final.doc
the central list of OBC of the States in question and the issue
was whether there was any scope for interference in the said
report.          While recording a finding that the decision not to
recommend the Jats for inclusion in the Central list of Other
Backward Classes cannot be said to be based on 'no material'
or unsupported by reasons or characterized at decision arrived
at extraneous and irrelevant consideration and the report
being of an expert body, the Apex Court held as under :
                47        Undoubtedly, the report dated 26.02.2014 of
                the NCBC was made on a detailed consideration of
                the various reports of the State Backward Classes
                Commissions; other available literature on the subject
                and also upon consideration of the findings of the
                Expert Committee constituted by the ICSSR toDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                examine the matter. The decision not to recommend
                the Jats for inclusion in the Central List of OBCs of the
                States in question cannot be said to be based on no
                materials or unsupported by reasons or characterized
                as decisions arrived at on consideration of matters
                that are, in any way, extraneous and irrelevant.
                Having requested the ICSSR to go into the matter and
                upon receipt of the report of the Expert Committee
                constituted in this regard, the NCBC was under a duty
                and obligation to consider the same and arrive at its
                own independent decision in the matter, a duty cast
                upon it by the Act in question. Consideration of the
                report of the Expert Body and disagreement with the
                views expressed by the said body cannot, therefore,
                amount to sitting in judgment over the views of the
                experts as has been sought to be contended on behalf
                of the Union. In fact, as noticed earlier, the Expert
                Body of the ICSSR did not take any particular stand in
                the matter and did not come up with any positive
                recommendation either in favour or against the
                inclusion of the Jats in the Central List of OBCs. The
                report of the said Body merely recited the facts as
                found upon the survey undertaken, leaving the
                eventual conclusion to be drawn by the NCBC. It may
patil-sachin.
::: Uploaded on - 27/06/2019                      ::: Downloaded on - 28/06/2019 05:25:23 :::
                                   294                            Marata(J) final.doc
                be possible that the NCBC upon consideration of the
                various materials documented before it had
                underplayed and/or overstressed parts of the said
                material. That is bound to happen in any process of
                consideration by any Body or Authority of voluminous
                information that may have been laid before it for the
                purpose of taking of a decision. Such an approach, by
                itself, would not make either the decision making
                process or the decision taken legally infirm or
                unsustainable. Something more would be required in
                order to bypass the advice tendered by the NCBC
                which judicially (Indra Sawhney) and statutorily (NCBC
                Act) would be binding on the Union Government in the
                ordinary course. An impossible or perverse view
                would justify exclusion of the advice tendered but that
                had, by no means, happened in the present case. The
                mere possibility of a different opinion or view would
                not detract from the binding nature of the advice
                tendered by the NCBC.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                  While dealing with an argument advanced on behalf of
the Union claiming the power to bypass NCBC and to include group
of citizens in the Central List of OBCs on the basis of Article 16(4)
itself, it is held that undoubtedly, Article 16(4) confers such a power
on the Union but what cannot be overlooked is the enactment of
the specific statute providing for constitution of a Commission
(NCBC) and the recommendations of which are required to be
adequately considered by the Union Government before taking its
final decision and surely the Union cannot be permitted to discard
its self professed norms which are statutory in character.
106               The Apex Court in Bir Singh v. Delhi Jal Board
[(2018) 10 SCC 312] has held that the quantifiable data can
patil-sachin.
::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:23 :::
                                  295                              Marata(J) final.doc
be gone into on the limited ground of relevance of the
circumstance on which the satisfaction of the State is
moulded.           The relevant observation in paragraph 37 reads
thus :
                "37. Article 16(4) is an enabling provision. It
                enables the State to provide to backward classes
                including Scheduled Castes and Scheduled Tribes
                reservation in appointments to public services.
                Such reservation is to be provided on the basis of
                quantifiable data indicating the adequacy or
                inadequacy, as may be, of the representation of
                such classes in Government service. The data
                which is the basis of the satisfaction of the StateDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                being verifiable, is open to judicial scrutiny on the
                limited ground of          relevance        of     the
                circumstances       on which the satisfaction is
                moulded.      The policy    decision     to    provide
                reservation, of course, is beyond the pale of
                judicial review.
107              We need not multiply the authorities so as to assail
the well settled principle that the Constitutional courts cannot
sit over the decision of the expert bodies as Courts of Appeal.
108              The Apex Court in a recent decision in B. K.
Pavitra and ors. Versus Union of India and ors. took a
survey of earlier decisions regarding the scope of judicial
review in the matter of expert committee reiterated the
parameters on which judicial review can be exercised.                                   It
examined the Ratnaprabha Committee report which was the
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:23 :::
                                  296                             Marata(J) final.doc
basis of reservation of the Karnataka Act of 2018. By applying
the parameters laid down in Nagaraj, subsequently clarified in
case of Jarnail Singh, in regard to adequacy of representation
and impact of efficiency of administration, the Apex Court held
as under :-
                 95. In dealing with the submissions of the
                 petitioners on this aspect, it is relevant for this
                 Court to recognize the circumspection with
                 which judicial power must be exercised on
                 matters which pertain to propriety and
                 sufficiency, in the context of scrutinizing theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                 underlying collection of data by the State on the
                 adequacy of representation and impact on
                 efficiency. The Court , is above all, considering
                 the validity of a law which was enacted by the
                 State legislature for enforcing the substantive
                 right to equality for the SCs and STs. Judicial
                 review must hence traverse conventional
                 categories by determining as to whether the
                 Ratna Prabha Committee report considered
                 material which was irrelevant or extraneous or
                 had drawn a conclusion which no reasonable
                 body of persons could have adopted. In this
                 area, the fact that an alternate line of approach
                 was possible or may even appear to be
                 desirable cannot furnish a foundation for the
                 assumption by the court of a decision making
                 authority which in the legislative sphere is
                 entrusted to the legislating body and in the
                 administrative sphere to the executive arm of
                 the government."
109              In the light of the aforesaid position of law, we have
examined the report of the commission and proceed to deal
with the scope for our interference in                  the said report in
exercise of our power of judicial review.
patil-sachin.
::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:23 :::
                                     297                                Marata(J) final.doc
                 The       terms    of    reference      made         over       to     the
Commission included the determination of the contemporary
criteria and parameters to be adopted in ascertaining the
social, educational and economic backwardness for conferring
the benefit of reservation in present context and in conformity
with the constitutional mandate, reservation laws and the
existing precedents. The exhaustive report of the commissionDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

has       focused         itself   on    collection      of     quantifiable           and
contemporary evidence.                    The Commission had before it
several           representations,          which         included           individual
representations as well as the representations from various
organizations.            The representations raised the demand for
inclusion or non-inclusion of Maratha community into the other
backward class.                The Commission         held public hearings at
distinct places on different dates which were widely attended.
The commission also took into consideration the written
representations made by 5 main organisations in the State of
Maharashtra including Akhil Bhartiya Maratha Mahasangh,
Maratha Seva Sangh, Akhil Maratha Federation etc.                                   There
were representations before the commission which staked a
demand that Marathas should be given a separate reservation
out of the reservation meant for the other backward class in
patil-sachin.
::: Uploaded on - 27/06/2019                          ::: Downloaded on - 28/06/2019 05:25:23 :::
                                   298                           Marata(J) final.doc
the State of Maharashtra.               The commission scrutinized the
claim made in those representations at length and has given
its thoughtful consideration to the demands raised by the
organisations. It also took into consideration the statements
made on oath by the members of the community which
favoured the inclusion of Maratha community in the list of
other backward classes. The individual affidavits highlightedDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

the social position and status of the said community, justifying
their demand.              The commission in public hearing conducted
by it, collected the information of the social, educational and
economical status of the said community and it identified its
backwardness in light of the parameters recognized by the
Constitution Bench judgment in Indra Sawhney (supra)                             for
conferring the benefits of Articles 15(4) and 16(4). The report
of the commission refers to the history of the community and
also the fact as early as in 1902, the community was
recognised to be backward and privilege of being backward
was conferred on this community. The commission has also
made a exhaustive reference to the judgment of Madras High
Court in the case of Maharaja of Kolhapur Vs. S. Sundaram
Ayyar, AIR 1925 Madras 497 focusing on the point whether
Marathas are "Khastriya" or "Shudras".                  It relied upon the
patil-sachin.
::: Uploaded on - 27/06/2019                   ::: Downloaded on - 28/06/2019 05:25:23 :::
                                299                            Marata(J) final.doc
observations of the Madras High Court, which has held that
direct blood relatives of great King Chhatrapati Shivaji Maharaj
were declared as Shudras.            After referring to the history of
community and to the distress in which the community finds
itself, the commission also made reference to the agricultural
census and analysed the quantum of holding of the persons
belonging to this community by specifically making referenceDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

to the irrigation potential created in each sector.                           The
commission has also heavily relied upon the economic census
of 2017-18 published by the Statistical Department of
Government of Maharashtra and concluded that the average
holding in the state of Maharashtra is 1.44 hectare and on
comparison with the other States, the report has concluded
that the holding of agriculturist in the survey is on the decline
and moreover, the yield of this holding also depends on the
condition of soil and percentage of rain. The commission also
made reference to the NABARD Survey which is national level
survey providing insights into the economical conditions of the
farmer community in the State of Maharashtra.                      It is not a
matter of dispute that Maratha and Kunbi communities are
engaged in the traditional occupation of farming and therefore
it had relied upon the afore-stated two reports to assess the
patil-sachin.
::: Uploaded on - 27/06/2019                 ::: Downloaded on - 28/06/2019 05:25:23 :::
                                       300                          Marata(J) final.doc
financial distress suffered by this community who are largely
agriculturists and residing in rural areas.
                 The Commission appointed five agencies to collect
the data and which were provided with uniform questionnaire
containing 40 questions.                    It evolved 25 indicators for
determining the backwardness broadly categorized under
three heads. It also called for opinion of experts in the fieldsDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

of history, sociology and agriculture so as to assess the
backwardness.
110              The Commission had before it the exhaustive data
in form of the survey reports, response to the questionnaire
and the representations, affidavits and based on the said
material, it analyzed the reasons for backwardness of the said
community.             It      also   received   information           from         the
Commissioner of Labour in respect of the status of members
registered as Mathadi Hamals along with information in
relation to Dabbewalas from their registered associations.
Apart from this major reports, the commission had before it,
several survey reports of individuals like the report submitted
by Advocate Surya Rao in respect of village Shindi Khurd,
report in relation to a village in Thane district. Panel of experts
patil-sachin.
::: Uploaded on - 27/06/2019                      ::: Downloaded on - 28/06/2019 05:25:23 :::
                                      301                          Marata(J) final.doc
was appointed by the Commission to analyze the data
collected by the five agencies in the sample survey.
                 On careful perusal of the Three Volume Report
submitted by the Commission, we have noted that the
Commission has undertaken an independent sample survey in
order       to     estimate      social,   economical       and      educationalDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

backwardness of Maratha community, it collected quantitative
and qualitative data and information to estimate, assess and
analyze the status of Maratha community.                     It has thereafter
collated data and information obtained independently in the
survey with regard to the studies, case studies, survey done
separately by the expert entities, reputed institutions and
agencies in a contemporary times. The Commission has
related the finding in the independent survey and public
hearings and integrated the historical information, view and
opinions of the members of the Commission who separately
conducted the exercise. Lastly it evaluated conclusions,
findings and observations with reference to the various judicial
pronouncements                 and    as   to   whether          backwardness
contemplated in the Constitution is the same which the
community suffers from and it arrived at a positive conclusion
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:23 :::
                                       302                           Marata(J) final.doc
that the said community is socially, economically and
educationally backward. It is also relevant to note that the
assessment of the backwardness was carried out by the
Commission by allocation of weightages and by adopting
marking system. As far as social backwardness is concerned,
the Commission applied 26 parameters and the averages of
the weightage was arrived at by comparing it with the StateDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

average.            As     far   as    the   educational     backwardness                 is
concerned, the Commission determined the educational status
of the said community at all levels i.e. primary, secondary,
UG/PG, technical/professional and the rate of illiteracy and
compared it with the State average and concluded that the
Maratha Population seems to be suffering from all the
deficiencies in education sector i.e. from failure to gain an
entry, drop out and inability to continue schooling. 8 marks
were       allotted       for    educational     backwardness          which        was
determined on the basis of four parameters pertaining to the
deficiency in admission percentages, compared with the State
average in Primary, Secondary, higher secondary education
and drop out at the primary education level and the gap in
the higher education levels in the community compared to the
State       average.           The    economic    backwardness            was      also
patil-sachin.
::: Uploaded on - 27/06/2019                       ::: Downloaded on - 28/06/2019 05:25:23 :::
                                         303                               Marata(J) final.doc
assessed by assessing the contemporary position of the said
community. The Commission has exhaustively dealt with the
statistics about the holdings in the Ninth agricultural census of
2011 and on the basis of the said census, it has made
observation about the deteriorating social status of the
farming Maratha class in the State. The Commission also
concluded that the figure of the agricultural census conductedDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

for three periods namely 1970-71, 2000-01 and latest 2010-11
which throws light on the deteriorating social and economical
condition of the traditional farming class in the State, majority
of    them        belong        to   Maratha      and      Kunbi       caste.       It   also
conclusively           recorded         a     finding     that      the       agricultural
community which once may have enjoyed the privilege of
having sumptuous agricultural land, is no more able to sustain
themselves simply on the farming activities, whereas the
other avenues of livelihood are not within their reach
particularly on account of lack of education and alternate skills
and      this     is    a      factor    which     has      contributed           to     their
backwardness.
                 The Commission also collected data in the form of
surveys on the basis of category of the ration card and
assessed per capita average income of the members of the
patil-sachin.
::: Uploaded on - 27/06/2019                             ::: Downloaded on - 28/06/2019 05:25:23 :::
                                        304                            Marata(J) final.doc
said community.                  On the basis of data and survey it has
arrived at the conclusion that 37% families belonging to
Maratha are below poverty line compared to the State rural
average of 24.20% and as compared, this proportion for
Kunbis is 32% and for OBC it is 41.5%. The family income has
also been calculated and the Commission has concluded that
out of total surveyed families 22% of the Maratha familiesDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

have annual income upto 24,000/-, 22% families have income
in the range of 24,001/- to 50,000/-, 19% have income
between 50,001/- to 1,00,000/- and 8% families have income
between 1,00,000/- to 4,00,000/- and the bare minimum of
0.46% families have annual income of more than 4,00,000/-. It
also assessed dependency of this community on the borrowed
resources on account of the deficient earning capacity of the
family. Conclusively, the Commission has recorded a finding
that the community on the basis of the sample survey,
analysis of the survey by experts and applying 25 indicators
and by allocating marks on the basis of analysis have
established that the community has scored 21.5 marks out of
25 marks, and applying the said parameters, the said
community             is       socially,   educationally     and       economically
backward.
patil-sachin.
::: Uploaded on - 27/06/2019                         ::: Downloaded on - 28/06/2019 05:25:23 :::
                                      305                             Marata(J) final.doc
                 It is this exhaustive report which we have carefully
analyzed and in the light of well determined parameters laid
down by the Apex Court of the permissiblility of the Courts to
exercise its power of judicial review, we have given thoughtful
consideration as to the scope of judicial review to be exercised
by us. The Commission has collected the contemporaneousDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

and quantifiable data and recorded a finding, after analyzing
data in a scientific manner. The criticism of the report of the
Commission by the learned senior counsel Shri Sancheti on
the ground that the sample size is not representatives of the
entire State data, is without merit. The detailed report of the
Commission do disclose that the Commission has factually
collected          the         information   in    the     form         of     various
parameters/yardsticks to determine the backwardness of the
community and it had                   adopted the method of purposive
sampling and the data collected is compared with the State
average. In any contingency, the petitioners who have
assailed the data, do not possess an expertise to claim                                its
exclusion and cannot attack the credibility of the data
collected        by      the     Commission       merely     on     the      basis      of
assumptions and surmises. The scope of judicial review being
patil-sachin.
::: Uploaded on - 27/06/2019                        ::: Downloaded on - 28/06/2019 05:25:23 :::
                                     306                            Marata(J) final.doc
only available when the irrelevant material being taken into
consideration            and     relevant   material     kept       out      of     the
consideration, is by now a settled position of law. In the light
of the limited scope of the judicial review, it is not open for us
to substitute the finding by an expert body which had before it
the quantifiable data. The approach of the Commission has
been to assess the status of the Maratha community atDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

ground level and factually it dispelled the common submission
that it is a forward community. It is only on factual assessment
and      surveys         being    carried   out   in   villages       where         the
community actually resides, the Commission has recorded its
finding and conclusions.             We are of the opinion that even if
there are minuscule errors in the data collection or a little
disparity in comparing this community with other communities
in the backdrop of the State average which was emphasied by
Mr. Sancheti, we do not feel that it is proper for us to exercise
our power of judicial review and substitute the finding of the
Commission. Once the Commission has carried the exercise of
collection, collation and analysis of the relevant data we do
not think it is possible for us to revaluate it. The scope and
reach of the judicial scrutiny in the matters which lie within
the subjective satisfaction of the executive is well settled and
patil-sachin.
::: Uploaded on - 27/06/2019                      ::: Downloaded on - 28/06/2019 05:25:23 :::
                                         307                              Marata(J) final.doc
as held in the case of Pavitra (supra), the principles apply
equally in the case of constitutional provision like                                 Article
16(4) which expressly places the particular fact (inadequate
representation)                within   the       subjective        judgment       of     the
State/executive.
111              On a similar analogy, a legislation enacted by aDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

State legislature which is based on a report of the Commission
constituted by the State, backed by the empirical and
contemporaneous data leaves very little scope for us to
interfere.           The        statute      is   no   doubt        presumed        to     be
constitutionally valid and it is the legislature of the State
which would better understand the contingencies and the
extra-ordinary circumstances and exceptional situations and it
is thus the best Judge to reflect on the needs of a particular
class. The State which exercises its enabling power and brings
a legislation in the form of the affirmative action backed by
data supporting the inadequacy of representation of a
particular         community            or    intending        to    take     steps        for
advancement of a weaker section like the Maratha community
which is identified as socially and educationally backward,
which the State of Maharashtra has precisely done, in our
patil-sachin.
::: Uploaded on - 27/06/2019                            ::: Downloaded on - 28/06/2019 05:25:23 :::
                                308                          Marata(J) final.doc
opinion, do not call for any interference since we have not
noted any illegality or perversity in the methodology adopted
by the Commission and the well supported conclusions
derived by it. The presumption is always in favour of the
constitutionality of an enactment and the onus lies upon the
person who attacks the statute and we are not impressed by
the arguments which would convince us to interfere in theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

exercise undertaken by the State except to the limited extent
which we would deal with in the subsequent paragraphs.
(VI) - Whether impugned Enactment, satisfy test of
Reasonable classification and meet the Essence of
Article 14.
112              The Preamble of the Constitution of India, which is
a brief introductory statement embodies the fundamental
values and the underlying philosophy and the aims and
objectives which the founding fathers of the Constitution
enjoined the polity to strive to achieve.               The hopes and
aspirations of the people of India are enveloped in the
preamble.             According to Dr. Babasaheb Ambedkar, the
Preamble is, indeed a way of life which recognizes liberty,
equality and fraternity which cannot be divorced from each
patil-sachin.
::: Uploaded on - 27/06/2019               ::: Downloaded on - 28/06/2019 05:25:24 :::
                                     309                               Marata(J) final.doc
other. In words of Dr.Ambedkar, they form a union of trinity in
the sense that to divorce one from other is to defeat the very
purpose of democracy.
113              The       right   to     equality    is    embodied            in     the
Constitution from Article 14 to Article 18. Article 14 contains
the principle Rule of law whereas Article 15 and Article 16
contain the application of this principle. Article 14 reads thus :Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                "The State shall not deny to any person equality
                before law" and equal protection of law within
                the territory of India".
                 It involves two expressions "Equality before law"
and "equal protection of the laws".                  Equality before law is a
negative concept and equal protection of law is a positive
concept. The principle of equality before law owes its origin to
the doctrine of rule of law profounded by Professor Dicey in his
book "The Law of the Constitution" (1885) who give three
implications of Rule of law - Supremacy of law - Equality
before law - Primacy of the rights of the individuals. Equal
protection of law under the Indian Constitution conveys the
concept of right to equal treatment in similar circumstances
patil-sachin.
::: Uploaded on - 27/06/2019                         ::: Downloaded on - 28/06/2019 05:25:24 :::
                                310                       Marata(J) final.doc
both in privileges and liabilities. Article 14 does not imply that
the same law should apply to all persons and every law must
have universal application because all persons are not by
nature, attainment or circumstances in the same position. In
an ideal situation, the concept of equality would simply
contemplate equality of status and opportunity as the
preamble indicates. The right of equality was considered to
be a negative right of an individual not to be discriminated inDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

matters of public access or public office or public matters
generally. It did not take into account the existing inequalities
arising even from public policies and exercise of public
powers.           The framers of the Indian Constitution were
conscious of the wide spread, social and economic inequalities
in the country as past experience which was supported by the
classification of society based on caste, religion, each one of
its firmly established and deeply rooted in forms of social
norms and practices. The framer of the Constitution in order
to tackle with such inequalities deemed it necessary to
enforce equality in its positive form and did not restrict the
concept of equality merely to a negative right, but ushered in
the positive aspect of equality, conveying equal opportunity
for the grossly affected and discriminated to move forward so
patil-sachin.
::: Uploaded on - 27/06/2019            ::: Downloaded on - 28/06/2019 05:25:24 :::
                                 311                             Marata(J) final.doc
that they can march hand in hand with other citizens of India
on equal basis.
                 This positive concept of equality in form of an
affirmative action was introduced in the Constitution by
making a provision of reservation which lead to a series of
measures in form of clause(4) of Article 15 and clause (4) of
Article 16.          This enabling provisions enabled the State to
translate the special provision for advancement of socially andDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

educationally backward classes or for the Scheduled Castes
and Scheduled Tribes or in favour of those backward classes
of citizens which, in the opinion of the State, are not
adequately            represented     in   public     employment.               The
reservation aimed to nourish the historical disadvantageous
caste and tribes listed as Scheduled Caste and Scheduled
Tribes and also identified as 'Other Backward Classes" and it
expected to address historic oppression, inequality and
discrimination faced by those communities.                    In form of the
said provisions, the Constitution makers intended to realize
the promise of equality enshrined in the Constitution.                          The
provision of reservation thus flow from the Constitution and
find its entry in the statutory laws, local rules and regulations.
It aims to enhance the social and educational status of the
patil-sachin.
::: Uploaded on - 27/06/2019                   ::: Downloaded on - 28/06/2019 05:25:24 :::
                                      312                           Marata(J) final.doc
underprivileged communities and this was looked as a means
of enforcing the equality in a positive way.
114              The concept of equality which also contemplates an
affirmative action by the State towards unequals do not
prevent certain classes of persons being conferred with
special privileges. Article 14 prohibits class legislation which
makes           improper        discrimination   by   conferring          particularDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

privileges upon a class of persons arbitrarily selected but it
permits reasonable classification for the purpose of achieving
specific ends.                 Article 14 contains an inhibition against
discrimination either in favour of a person or a class of
persons or against any individual or group of individuals but it
do not prohibit legislature from enacting special laws as
applicable to a particular group in a State nor does it forbid
classification resting upon reasonable grounds of distinction.
The principles is stated by Professor Willice (Constitutional
law) in the following words :
                  "The guarantee of equal protection of the
                laws means the protection of equal laws".
patil-sachin.
::: Uploaded on - 27/06/2019                      ::: Downloaded on - 28/06/2019 05:25:24 :::
                                  313                             Marata(J) final.doc
115               The meaning and scope of Article 14 came to be
elaborated in Chiranjeet Lal Vs. Union of India ,24 and the
principles laid down by the Constitution Bench could be
summarized in the following words:
                "The principle underline the guarantee in Article 14 is not
                that the same Rules of Law should be applicable to all
                persons within the Indian Territory or that the same
                remedies should be made available to them irrespective
                of differences of circumstances".
It only means that all persons similar circumstanced shall be
treated alike, both in privileges conferred and liabilitiesDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

imposed. Equal laws will have to be applied to all, in the same
situation and there should be no discrimination between one
person and another if as regards the subject matter of the
legislation, their position is substantially the same. The entire
problem under the equal protection of laws is one of
classification or of drawing lines. In making a classification,
the legislature cannot certainly be expected to provide an
abstract symmetry.             It can make and set apart the classes
according to the needs and exigencies of the Society and is
suggested by experience. The classification should never be
arbitrary, artificial or evasive.          It must rest upon real and
substantial distinction bearing a reasonable and just relation
241950 SCR 869
patil-sachin.
::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:24 :::
                                  314                             Marata(J) final.doc
to the thing in respect of which the classification is made and
classification made without any reasonable basis should be
regarded as invalid.
116              In case of Union of India vs. N.S. Rathnam &
Sons,25 , the following observations of the Hon'ble Apex Court
needs a reproduction:-
                 13. It is, thus, beyond any pale of doubt that the
                 justiciability of particular Notification can be tested
                 on the touchstone of Article 14 of the Constitution.
Article 14, which is treated as basic feature of the
                 Constitution, ensures equality before the law or
                 equal protection of laws. Equal protection means theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                 right to equal treatment in similar circumstances,
                 both in the priviliges conferred and in the liabilities
                 imposed. Therefore, if the two persons or two sets of
                 persons are similarly situated/placed, they have to
                 be treated equally. At the same time, the principle of
                 equality does not mean that every law must have
                 universal application for all persons who are not by
                 nature, attainment or circumstances in the same
                 position. It would mean that the State has the power
                 to classify persons for legitimate purposes. The
                 legislature is competent to exercise its discretion and
                 make classification. Thus, every classification is in
                 some degree likely to produce some inequality but
                 mere production of inequality is not enough. Article
                 14 would be treated as violated only when equal
                 protection is denied even when the two persons
                 belong to same class/category. Therefore, the person
                 challenging the act of the State as violative of Article
                 14 has to show that there is no reasonable basis for
                 the differentiation between the two classes created
                 by the State. Article 14 prohibits class legislation and
                 not reasonable classification.
                 14. What follows from the above is that in order to
                 pass the test of permissible classification two
                 conditions must be fulfilled, namely, (i) that the
25(2015) 10 SCC 681
patil-sachin.
::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:24 :::
                                  315                            Marata(J) final.doc
                 classification must be founded on an intelligible
                 differential which distinguishes persons or things
                 that are grouped together from others left out of the
                 group and (ii) that, that differential must have a
                 rational relation to the object sought to be achieved
                 by the statute in question. If the government fails to
                 support its action of classification on the touchstone
                 of the principle whether the classification is
                 reasonable having an intelligible differentia and a
                 rational basis germane to the purpose, the
                 classification has to be held as arbitrary and
                 discriminatory.
In the backdrop of the said legal scenario, we examined theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

case in hand as to whether the reservation carved out in
favour of Maratha community by classifying them as SEBC is
sustainable.
117              The true meaning and scope of Article 14 has been
explained in several decisions and they have been succinctly
summarized by Das, C.J in case of Ram Krishna Dalmia Vs.
Justice S.R. Tendolkar26.                 The Constitution Bench was
dealing with an enactment providing for appointment of
commission of inquiry and conferring of powers to conduct an
inquiry.        Sub-section    (1)   of   Section    3    empowered              the
appropriate Government, if it was of the opinion that it is
necessary so to do to appoint a commission of inquiry for the
purpose of making an inquiry into any definite matter of public
26 AIR 1958 SC 538
patil-sachin.
::: Uploaded on - 27/06/2019                   ::: Downloaded on - 28/06/2019 05:25:24 :::
                                   316                             Marata(J) final.doc
importance and performing such function within such time as
may be specified in the notification and the Commission so
appointed shall then make an inquiry and perform the
functions.          We need not deliberate on the scheme of the
enactment but suffice it to say that in exercise of powers
conferred by Section 3 of the Act, the Central Government
published in the Gazette of India a notification dated 11 th
December 1956, thereby directing a full inquiry into theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

matters involving the appellant and it had categorically opined
that these are the matters which are of definite public
importance, both by reason of great consequences which
appear to have ensued to the invested public and also to
determine such measures as may be deemed necessary in
order to prevent a recurrence thereof.                This notification was
the subject matter from which the litigation spurred.
                 The judgment of the Apex Court has laid down
ever      guiding        principles   when   a   statute       comes        up      for
consideration, on question of its validity under Article 14 and
categorized the same into one of the five classes. The first
two classes are important for us and we reproduce the same
as under :
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:24 :::
                                   317                           Marata(J) final.doc
                       (i) A statute may itself indicate the persons or
                       things to whom its provisions are intended to
                       apply and the basis of the classification of such
                       persons or things may appear on the face of the
                       statute or may be gathered from the
                       surrounding circumstances known to or brought
                       to the notice of the court. In determining the
                       validity or otherwise of such a statute the court
                       has to examine whether such classification is or
                       can be reasonably regarded as based upon
                       some differentia which distinguishes such
                       persons or things grouped together from those
                       left out of the group and whether such
                       differentia has a reasonable relation to the
                       object sought to be achieved by the statute, noDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                       matter whether the provisions of the statute are
                       intended to apply only to a particular person or
                       thing or only to a certain class of persons or
                       things. Where the court finds that the
                       classification satisfies the tests, the court will
                       uphold the validity of the law.
                       (ii)A statute may direct its provisions against
                       one individual person or thing or to several
                       individual persons or things but, no reasonable
                       basis of classification may appear on the face of
                       it or be deducible from the surrounding
                       circumstances,      or   matters   of   common
                       knowledge. In such a case the court will strike
                       down the law as an instance of naked
                       discrimination.
                 On factual aspect in paragraph no.13, the Court
held that the case falls in the first category and since the
preamble or provisions of the statute classed under the first
category         mentioned      above,    could   read       as     making            a
reasonable classification satisfying the requirement of Article
patil-sachin.
::: Uploaded on - 27/06/2019                   ::: Downloaded on - 28/06/2019 05:25:24 :::
                                 318                            Marata(J) final.doc
14 and there can be no objection in construing Section 3 as
making a reasonable classification as, at any rate, declaring
with sufficient clarity the policy of Parliament and laying down
principles for the guidance for the exercise of powers
conferred on appropriate Government so as to bring the
statute in first category.       The Act came to be upheld and the
contention that the Companies that they have been arbitrarily
singled out for the purpose of hostile and discriminatoryDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

treatment, came to be rejected.
118              Another important judgment on the point which is
heavily relied upon by the learned Senior counsel Shri Dada is
in the matter of In Re : Special Courts Bill, 1978 (1971 (1) SCC
380) and he relied upon the following propositions laid down
by the Apex Court.
                 1.       ............ ........
                 2.    The State, in the exercise of its governmental
                 power, has of necessity to make laws operating
                 differently on different groups or classes of persons
                 within its territory to attain particular ends in giving
                 effect to its policies, and it must possess for that
                 purpose large powers of distinguishing and classifying
                 persons or things to be subjected to such laws.
                 3.   The Constitutional command to the State to afford
                 equal protection of its laws sets a goal not attainable
                 by the invention and application of a precise formula.
                 Therefore, classification need not be constituted by an
patil-sachin.
::: Uploaded on - 27/06/2019                  ::: Downloaded on - 28/06/2019 05:25:24 :::
                                  319                             Marata(J) final.doc
                 exact or scientific exclusion or inclusion of persons or
                 things. The Courts should not insist on delusive
                 exactness or apply doctrinaire tests for determining the
                 validity of classification in any given case. Classification
                 is justified if it is not palpably arbitrary.
                 4.      The principle underlying the guarantee of Article
                 14 is not that the same rules of law should be
                 applicable to all persons within the Indian territory or
                 that the same remedies should be made available to
                 them irrespective of differences of circumstances. It
                 only means that all persons similarly circumstanced
                 shall be treated alike both in privileges conferred andDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                 liabilities imposed. Equal laws would have to be applied
                 to all in the same situation, and there should be no
                 discrimination between one person and another if as
                 regards the subject-matter of the legislation their
                 position is substantially the same.
                 5.    By the process of classification, the State has the
                 power of determining who should be regarded as a
                 class for purposes of legislation and in relation to a law
                 enacted on a particular subject. This power, no doubt,
                 in some degree is likely to produce some inequality; but
                 if a law deals with the liberties of a number of well-
                 defined classes, it is not open to the charge of denial of
                 equal protection on the ground that it has no
                 application to other persons. Classification thus means
                 segregation in classes which have a systematic
                 relation, usually found in common properties and
                 characteristics. It postulates a rational basis and does
                 not mean herding together of certain persons and
                 classes arbitrarily.
                 6.    The law can make and set apart the classes
                 according to the needs and exigencies of the society
                 and as suggested by experience. It can recognise even
                 degree of evil, but the classification should never be
                 arbitrary, artificial or evasive.
                 7.     The classification must not be arbitrary but must
                 be rational, that is to say, it must not only be based on
                 some qualities or characteristics which are to be found
                 in all the persons grouped together and not in others
                 who are left out but those qualities or characteristics
patil-sachin.
::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:24 :::
                                 320                             Marata(J) final.doc
                 must have a reasonable relation to the object of the
                 legislation. In order to pass the test, two conditions
                 must be fulfilled, namely, (1) that the classification
                 must be founded on an intelligible differentia which
                 distinguishes those that are grouped together from
                 others and (2) that differentia must have a rational
                 relation to the object sought to be achieved by the Act.
                 8.      The differentia which is the basis of the
                 classification and the object of the Act are distinctDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                 things and what is necessary is that there must be a
                 nexus between them. In short, while Article 14 forbids
                 class discrimination by conferring privileges or
                 imposing liabilities upon persons arbitrarily selected out
                 of a large number of other persons similarly situated in
                 relation to the privileges sought to be conferred or the
                 liabilities proposed to be imposed, it does not forbid
                 classification for the purpose of legislation, provided
                 such classification is not arbitrary in the sense above
                 mentioned.
Applying the principles carved out as above, the Constitution
Bench by upholding the creation of Special Courts to try
offences committed by high public offices during the period of
emergency, since it satisfied the test under Article 14.
119              Based on this decision, what is being argued by the
State is that the Maratha community clearly falls within four
corners of the above 11 principles. The argument advanced is
that the Maratha community is in need of affirmative action in
form of reservation but to their detriment, both the National
Commissions constituted under Article 340 did not consider
patil-sachin.
::: Uploaded on - 27/06/2019                   ::: Downloaded on - 28/06/2019 05:25:24 :::
                                     321                           Marata(J) final.doc
the claim of the community in proper perspective and the
community            was       declared   as   forward      by     the      Second
Commission without supportive data.                      Further, the Khatri
Commission report was also unfair to the Maratha community
and Justice Bapat Committee report, according to the State,Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

has ignored a dissent note of expert member recommending
the Maratha community to be backward. It is then sought to
be argued that the Gaikwad Commission report has gone into
great detail and collected quantifiable data                  analysed it and
has carved out an extra-ordinary situation and exceptional
circumstances and recommended to include the community in
a separate category without touching the existing reservation
and this categorization cannot be claimed to be arbitrary since
it is based on intelligible differentia and has a rational nexus
with the object. The classification is also sought to be justified
on the ground that no reservation is being afforded to Maratha
community in the political arena since they were sufficiently
represented in politics.             The classification is sought to be
justified by stating that it has resulted into some inequality
but if a law which deals with liberties of approximately 30 to
34%, well defined class of population of the State, it is not
open to charge it with denial of equal protection on the ground
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:24 :::
                                      322                             Marata(J) final.doc
that it has no obligation to other persons. The Maratha class of
citizens are in need of affirmative action since 1902 they were
provided          with         benefits    of    reservations        which         were
discontinued from 1952. The Commission has recorded a
finding about population of Maratha community and MarathaDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

being numerically high in number were excluded without any
justification and subsequently several Commissions ignored
the claims of this community.                   The Gaikwad Commission, in
light of the extra-ordinary situation which it has carved out in
great detail has created a separate class for this community
and captioned as "Socially and Educationally Backward Class".
This classification is asserted by Shri Dada to be reasonable,
based on the report of an independent commission which has
collected adequate quantifiable data and carved out an
extraordinary situation and exceptional circumstances. No
benefit of reservation in form of political reservation is
conferred on the SEBC i.e. in Panchayati Raj Institutions and
local self governing bodies and this makes this class stand
apart. The very idea of classification is to remove inequality
and when classification is made by creating a separate class
of SEBC's and inclusion of Maratha community in it in order to
attain social justice and advancement of this community, we
patil-sachin.
::: Uploaded on - 27/06/2019                        ::: Downloaded on - 28/06/2019 05:25:24 :::
                                     323                          Marata(J) final.doc
do not find the classification to be unreasonable. Article 14 of
the Constitution               ensures that similarly circumstanced are
entitled for equal treatment. Equality is for equals and to treat
unequals as equals would violate Article 14. The Maratha
community on the basis of its historical position and the factDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

that it was treated as 'backward class/intermediate class"
prior to the point of time when the Constitution came into
force shared the quota meant for Other Backward Classes.
The segregation of this community from the Other Backward
Classes is without any justification. Merely because the
Backward Class Commission answering a reference made to it
in the year 2000 for its inclusion in the list of OBC, was
negatived, do not preclude examination of the backwardness
of this community once again. Now, in the contemporaneous
period, its backwardness is identified and recognized, it is the
duty of the State to confer the concessions on this class from
which they were kept away. This would achieve in real sense
the equality of opportunity. Equality under the Constitution of
India has been recognized as a dynamic concept which must
cover every process of equalization and it is expected to
become a living reality for the large masses of people. Those
who are unequal cannot be treated by identical standards and
patil-sachin.
::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:24 :::
                                        324                            Marata(J) final.doc
that may amount to equality in law but not equality in reality.
The existence of equality of opportunity depends not only
mere absence of disabilities but on the presence of abilities.
                 The Maratha community on account of its identified
backwardness, also is distinctly placed than the advantageousDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

class and it cannot be equated with them.                               It is always
permissible for the State while enacting a provision for
upliftment of backward class to classify it into a different class
provided the classification satisfies the twin test.                                As a
principle recognized in the case of In Re: Special Court Bill,
1978, the State in its governmental power may feel the
necessity to make laws operating differently on different
groups or classes to attain particular aims and the only test is
that      the     class        which   is    separately    created        has      some
distinguishing features, which is lacking in the one left out.
The State has the power to determine who should be regarded
as a class for the purposes of legislation and it can then
segregate this class based on its distinct properties. The State
has carved out an SEBC class under the Enactment of 2018
which include the Maratha class. The affirmative action of the
State, though apparently appear to be discriminatory is in
reality aimed at attaining equality by eliminating the de facto
patil-sachin.
::: Uploaded on - 27/06/2019                         ::: Downloaded on - 28/06/2019 05:25:24 :::
                                       325                          Marata(J) final.doc
inequality. This is achieved by placing this class by applying
the principle of equality on par with the other backward
classes but on account of its distinctive character of not being
conferred with the benefit for more than last six decades and
since it is not conferred with any political reservation, form aDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

separate class, not adequately represented in services under
the State.
120                The         enabling provisions in form of 15(4), 15(5)
and 16(4), 16(4A) if looked at in light of the directive principles
of State policy and in particular, contained in Article 38 which
cast a duty on the State to secure a social order for promotion
of welfare of people, then this affirmative action of the State in
form of reservation has always been construed as a method to
advance the prospects of weaker section of society.                                The
question, however, remains about the social adjustments, that
is how to strike a balance between the segment of socially
disadvantageous community and for how long to become
equal with others and it has always been a matter of judicial
concern to strike a balance so that there is no discontentment
on the part of any community or section of community and
not to exclude their legitimate expectations.                   The reservation
patil-sachin.
::: Uploaded on - 27/06/2019                      ::: Downloaded on - 28/06/2019 05:25:24 :::
                                   326                         Marata(J) final.doc
to the backward classes though is not a constitutional
mandate, but it has been recognized as                prerogative of the
State which can                be exercised through an executive or
legislative fiat and the extent of reservation in form of
affirmative action is thus left to the respective States.                     TheDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

recognition of these backward classes and its classification so
as to ensure the benefits which the State intends to confer on
them by taking recourse to Article 15(4) and 16(4) are best
left to the State including determination of the percentage of
reservation with the limit or ceiling laid down by the
Constitution Benches of the Hon'ble Apex court subject to the
exceptions laid down finally by the 9 Judges Bench in Indra
Sawhney.            The affirmative action formulated with a view to
increasing opportunities for disadvantageous class and which
is commonly referred to as compensatory discrimination finds
its place in the Constitution itself.        The Maratha community
which is recognized as a backward class is a homogeneous
group which has suffered uniformly from the same level of
deprivation. Amongst themselves, they may vary with range
of difference in the economic, social or educational standards
of backwardness.
patil-sachin.
::: Uploaded on - 27/06/2019                 ::: Downloaded on - 28/06/2019 05:25:24 :::
                                327                         Marata(J) final.doc
                 The State of Maharashtra enacted The Maharashtra
State Public Services Reservation for Schedules Castes,
Scheduled Tribes, Denotified Tribes (Vimukta Jatis), Nomadic
Tribes, Special Backward Category and other Backward
Classes Act, 2001 which provide for reservation of vacanciesDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

in public services and posts in favour of the persons belonging
to all the aforesaid categories. The Act of 2001 defines "Other
Backward Classes" in Section 2(g) to mean Socially and
Educationally Backward Class of Citizens as declared by the
Government and includes Other backward classes declared by
the Government of India in relation to the State. Section 4 of
the Enactment prescribed that there shall be posts reserved
for the persons belonging to Scheduled Caste, Scheduled
Tribes, De-Notified (Vimukta Jatis) Nomadic Tribes Special
Backward category and Other Backward Classes at the stage
of direct recruitment of public services and it provided for
percentage of seats to be reserved as against the particular
caste or tribe. The classification of these categories is
mentioned in Section 4 is as follows :
patil-sachin.
::: Uploaded on - 27/06/2019              ::: Downloaded on - 28/06/2019 05:25:24 :::
                                      328                            Marata(J) final.doc
            Description of                            Percentage of
            Caste/Tribe/Category/ Class               vacancies or seats
                                                      to be reserved
    1       Scheduled Castes                          13.00%
    2       Scheduled Tribes                          7.00%
    3       De-Notified Tribe (A)                     3.00%
    4       Nomadic Tribes (B)                        2.50%
    5       Nomadic Tribes (C)                        3.50%
    6       Nomadic Tribes (D)                        2.00%
    6       Special backward category                 2.00%
    7       Other Backward Classes                    19.00%
                                           Total      52.00%Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

121              The explanation appended to the said section set
out that the expression "De-Notified Tribe (A), Notified Tribe
(B) (C) (D) shall mean such tribe or sub-tribes declared by the
Government by general or special orders issued in this behalf
from time to time.
                 Similarly, the State of Maharashtra has enacted an
Act      known          as     The   Maharashtra       Private         Professional
Educational Institutions (Reservation of Seats For Admission
For Scheduled Castes, Scheduled Tribes, De-Notified Tribes
(Vimukta Jatis), Nomadic Tribes and Other Backward Classes)
Act, 2006 to make special provisions for reservation of seats in
the private professional educational institutions for this caste/
class. The said enactment in Section 4 prescribe that in every
aided private professional educational institutions, seats equal
patil-sachin.
::: Uploaded on - 27/06/2019                       ::: Downloaded on - 28/06/2019 05:25:24 :::
                                    329                               Marata(J) final.doc
to 50% of the sanction intake of each professional course shall
be       reserved       for    candidates   belonging         to    the      reserved
category.         The classification of this caste/tribe/category and
the percentage of reservation prescribed is to the following
proportion :
            Description of                             Percentage of
            Caste/Tribe/Category/ Class of             reservation
            Reserved Category
     1      Scheduled Castes and Scheduled             13.00%
            Castes converts to Buddhism
     2      Scheduled Tribes                           7.00%Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

     3      De-Notified Tribes (A)                     3.00%
     4      Nomadic Tribes (B)                         2.50%
     5      Nomadic Tribes (C)                         3.50%
     6      Nomadic Tribes (D)                         2.00%
     7      Other Backward Classes                     19.00%
                                            Total      50.00%
The note appended to Section 4 declares that a candidate
belonging to Special Backward Category shall be considered
from and out of their respective (original and parent reserved
category such as Other backward Classes). Section 5 of the
said enactment prescribe that in every unaided private
professional educational institutions, the seats to be reserved
for candidates belonging to reserved category shall be such as
may be notified from time to time in the official gazette but
shall not exceed 50% of the sanction intake for the particular
patil-sachin.
::: Uploaded on - 27/06/2019                        ::: Downloaded on - 28/06/2019 05:25:24 :::
                                330                        Marata(J) final.doc
professional course.
122              With these enactments being in force from 2001
and 2006 respectively when the State Government collected
the quantifiable data through the Backward Class Commission,
and conclusively held that Maratha community is socially and
educationally backward, and the State took a decision to
provide reservation to this community for admission in
educational institutions and on posts for appointments in
public services and under the State by bringing in aDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

legislation, it exercised its enabling power and took necessary
steps for providing adequate representation to this Committee
and to take steps for its social advancement.               Once it was
satisfied on the basis of the report of the Commission, its
finding and recommendations that this community requires
the desired protection as an affirmative step, it also proceeded
to decide the quantum of reservation by carving out an extra-
ordinary situation and exceptional circumstances to justify and
deviate from the limit of 50% set out by the constitutional
courts and it deemed it expedient to provide 16% reservation
to this category.
patil-sachin.
::: Uploaded on - 27/06/2019             ::: Downloaded on - 28/06/2019 05:25:24 :::
                                      331                          Marata(J) final.doc
123              The affirmative action contemplated in the Indian
Constitution contemplates the upliftment of the weaker
sections.          By reserving the posts in service or seats in
educational institutions, a fixed number is reserved for a
group or class collectively and the competition is amongst the
members of the same class.                 The equality enshrined in the
Indian Constitution is sought to be achieved by grouping these
two classes on a same platform and that is how the real
equality is sought to be achieved. The terminology implied in
Article 15(4) and 16(4) intend to benefit the backward classesDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

lagging behind and though under Article 16(4) these classes
are entitled for protection if they are not adequately
represented in the services in the State and in Article 15(4),
the      backward          classes    so   categorized     as     socially        and
educationally backward classes are entitled to have measures
for their social advancement.
                 As far as State of Maharashtra is concerned, the
Maharashtra State Public Services Act of 2001 ensures
reservation of 52% for the Scheduled Caste, Scheduled Tribe,
De-Notified Tribes (Vimukta Jatis) Nomadic Tribes, Special
Backward Category and Other Backward Classes of citizens.
The Scheduled Caste and Scheduled Tribe being a distinct
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:24 :::
                                      332                         Marata(J) final.doc
category recognized under the Indian Constitution has been
allotted 13% and 7% of reservation in the public services. The
Other Backward Classes have been divided into six categories
and separate percentage of reservation is carved out for the
de-notified         tribes     and   Nomadic   Tribes,     for     the     Special
Backward category and the Other Backward Classes. The
enactment stipulates that the percentage of reservation in all
the posts to the aforesaid categories shall be on the post of
the latest census record of the population of the State in the
case of State cadre post and the concerned district in the caseDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

of District cadre post. Further, a principle of creamy layer is
made applicable to all categories except Scheduled Caste and
Scheduled Tribes.              What can thus be seen has a fall out of
Section 4 is the classification made between two categories,
Scheduled Caste and Scheduled Tribe on one hand, to whom
the principle of creamy layer is not applicable and another
class covers the remaining 32% of reservation to whom the
creamy layer requirement is made applicable and this includes
the Other Backward Classes for whom the 19% of seats are to
be reserved in the public services or posts in the State.
                 Similar is the situation in case of the Maharashtra
Private Professional Educational Institutions Act of 2006 where
patil-sachin.
::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:24 :::
                                       333                           Marata(J) final.doc
the similar percentage of reservation is maintained except the
Special Backward Category and in case of this legislation, the
candidates of the Special Backward Category are entitled to
be considered from their respective parent reserved category
such as Other Backward Classes. The implementation of the
provisions of both the enactments is held to be imperative.
                 The       position    of   the   reservation        in    state       of
Maharashtra as it stands today is as under :-
Reservation QuotaDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

  SN Cast Reservati                     Details of Caste                    Remarks
      e      on                           Categories
             %
   1       SC          13%       SC & SC converts to                   59 Castes
                                 Budhhism
   2       ST           7%       ST including those living             47 Tribes
                                 outside specified areas
   3      OBC          19%       OBC-Other Backward Class :            346 Castes
   4      SBC           2%       SBC-Special Backward Class:           7 Castes
   5       VJ           3%       (Vimukta Jati/Denotified              14 Tribes
                                 Tribes)
   6     NT-B          2.5%      (Nomadic Tribes-B)                    28+7 Tribes
   7     NT-C          3.5%      Dhangar-(Nomadic Tribes-C)            1 Caste
   8     NT-D           2%       Vanjari-(Nomadic Tribes-D)            1 Caste
       TOTAL           52%
The Other Backward classes in State of Maharashtra are thus
stratified into compartments of OBC - SBC - VJ De-notified
patil-sachin.
::: Uploaded on - 27/06/2019                       ::: Downloaded on - 28/06/2019 05:25:24 :::
                                334                          Marata(J) final.doc
Tribe - NT-B - NT-C (dhangar) - NT-D (Vanjari). The situation
prevailing in Maharashtra thus denotes that the Tribes other
than Scheduled Tribes have distinctly classified and allotted a
separate quota and in case of Dhangar and Vanjari, they have
been assigned exclusive quota of 3.5% and 2% respectively.
Therefore, the sub-classification of backward classes is not a
new concept in State of Maharashtra and in light of the Apex
Court judgment in Indra Sawhney which permit such a sub-
classification as backward and more backward classes would
be referred in the subsequent paragraphs.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

124               Since we have already expressed our opinion on
the report of the backward class commission and have
concurred with its findings that Maratha is a backward class,
the question arises for consideration is in which category this
class should fall in?          The reservation      provided for OBC
category in both these two enactments is to the extent of
19%.            The report has conclusively held that the Maratha
community forms 30% of the population of the State and since
this community was never counted in the OBC category, the
question that fell for consideration before the Commission and
the State Government was whether they should be fitted into
patil-sachin.
::: Uploaded on - 27/06/2019               ::: Downloaded on - 28/06/2019 05:25:24 :::
                                   335                             Marata(J) final.doc
the 19%           quota meant for OBC.          As the Commission has
expressed that it would lead to a catastrophic situation since
as on today, there are approximate 346 number of castes
included in the list of OBC and they together take 19%
reservation. The list of Other Backward Classes in the State
includes several severely backward classes which may be
minuscule           in    population    but   they    being       socially        and
educationally backward require protection and therefore, find
their place in the list declared by the State Government. If the
Maratha community which comprises of 30% of population is
ushered into the said category, the reservation of the OBCDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

would be shared with the new class which comprises of 30%
of the population and it is likely to take major chunk of the
reservation benefits in the class of Other Backward Category.
This situation was sought to be avoided by the Commission
once it was satisfied that this class being backward needs
protection.          The Commission referred to the data available
with it about the availability of jobs for youth in public services
and the figures are disheartening.                    The Maratha being
included in the OBC quota would destroy the entire structure
of the OBC quota and apart from they being entitled for the
benefits, the caste already finding place in the OBC list since
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:24 :::
                                336                       Marata(J) final.doc
1995 would stand displaced and they would be making way to
accommodate the Maratha community.                 The Commission
expressed its apprehension of creation of a situation where
the backward class communities already included in OBC list
are abruptly asked to share their well established entitlement
for reservation with the Maratha communities                        and it
apprehended that this may lead to unwarranted repurcations
in the well set harmonious co-existence culture of the State.
The Commission therefore, suggested a mechanism to provide
justice to the newly recognized backward class of citizens i.e.
the Maratha and at the same time, not disturbing the existingDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

composition of the Other backward Class which is entitled for
19% reservation in educational field and in employment. It,
therefore, thought it expedient to categorize the said class
into a distinct class captioned as "socially and educationally
backward class" and carved out a distinct 16% reservation for
this class.
                 The argument advanced before us opposing the
permissibility of such a sub-classification of the Other
Backward Category since the Marathas are ultimately nothing
but Other Backward Class, but they have been categorized
distinctly as SEBC, requires consideration. The question that
patil-sachin.
::: Uploaded on - 27/06/2019            ::: Downloaded on - 28/06/2019 05:25:24 :::
                                         337                           Marata(J) final.doc
arise is whether it is permissible for the State to classify the
backward classes into backward and more backward category.
This issue came up for consideration for the first time in Balaji
(supra) and it was categorically held that it is not permissible
for the State to categorize backward classes into backward
and more backward on the basis of their relative social
backwardness.                  However, this issue was again framed as
Question No.5 in Indra Sawhney and on this point, the finding
recorded          in    Balaji     was       disapproved    by     the      9    Judges
Constitution Bench. As per the majority view voiced through
Justice         Jeevan         Reddy,    a    reference    was     made         to     theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

observations of Justice Chinappa Reddy in Vasanth Kumar
(supra) where he was observed thus :
                "We do not see why on principle there cannot be a
                classification into Backward Classes and More Backward
                Classes, if both classes are not merely a little behind, but
                far far behind the most advanced classes. In fact such a
                classification would be necessary to help the More
                Backward Classes; otherwise those of the Backward
                Classes who might be a little more advanced than the
                More Backward Classes might walk away with all the
                seats.
                  Relying on the said observation, Justice Jeevan
Reddy observed as under :
                  "We are of the opinion that there is no constitutional or
                legal bar to a State categorizing the backward classes as
                backward and more backward. We are not saying that it
                ought to be done. We are concerned with the question if
                a State makes such a categorisation, whether it would be
patil-sachin.
::: Uploaded on - 27/06/2019                         ::: Downloaded on - 28/06/2019 05:25:24 :::
                                  338                            Marata(J) final.doc
                invalid? We think not. Let us take the criteria evolved by
                Mandal Commission. Any caste, group or class which
                scored eleven or more points was treated as a backward
                class. Now, it is not as if all the several thousands of
                castes/groups/classes scored identical points. There may
                be some castes/groups/classes which have scored points
                between 20 to 22 and there may be some who have
                scored points between eleven and thirteen. It cannot
                reasonably be denied that there is no difference between
                these two sets of castes/groups/classes. To give an
                illustration, take two occupational groups viz., gold-
                smiths and vaddes (traditional stone-cutters in Andhra
                Pradesh) both included within Other Backward Classes.
                None can deny that gold-smiths are far less backward
                than vaddes. If both of them are grouped together and
                reservation provided, the inevitably result would be that
                gold-smiths would take away all the reserved posts
                leaving none for vaddes. In such a situation, a State may
                think it advisable to make a categorisation even among
                other backward classes so as to ensure that the more
                backward among the backward classes obtain theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                benefits intended for them. Where to draw the line and
                how to effect the sub-classification is, however, a matter
                for the Commission and the State - and so long as it is
                reasonably done, the Court may not intervene. In this
                connection, reference may be made to the categorisation
                obtaining in Andhra Pradesh. The Backward Classes have
                been divided into four categories. Group-A comprises of
                "Aboriginal tribes. Vimukta jatis. Nomadic and semi-
                nomadic tribes etc.". Group-B comprises professional
                group like tappers, weavers, carpenters, ironsmiths,
                goldsmiths, kamsalins etc. Group-C pertains to
                "Scheduled Castes converts to Christianity and their
                progency", while Group-D comprises of all other
                classes/communities/groups, which are not included in
                groups A, B and C. The 25% vacancies reserved for
                backward classes are sub-divided between them in
                proportion     to  their   respective    population.   This
                categorisation was justified in Balram [1972] 3 S.C.R. 247
                AT 286. This is merely to show that even among
                backward classes, there can be a sub-classification on a
                reasonable basis.
patil-sachin.
::: Uploaded on - 27/06/2019                   ::: Downloaded on - 28/06/2019 05:25:24 :::
                                   339                            Marata(J) final.doc
                  The majority view also examined this issue with
reference to Article 16(4) and according to Justice Reddy, it
recognizes only one class i.e. Backward class of citizens.                             It
does not speak separately of Scheduled Caste and Scheduled
Tribe as Article 15(4) and therefore, even Scheduled Caste and
Scheduled Tribes are included in the expression "backward
class of citizens" and            separate reservation be provided in
their favour and this according to the majority view is a well
accepted phenomenon throughout the country. The majority
view further observed :-Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                "It is that if Scheduled Tribes, Scheduled Castes and Other
                Backward Classes are lumped together, O.B.Cs. will take
                away all the vacancies leaving Scheduled Castes and
                Scheduled Tribes high and dry".
                  "The same logic also warrants categorization more
backward and backward. We do not mean to say - we may
reiterate - that this should not be done. We are only saying
that if a state chooses to do so, it is not permissible in law"
                  Justice Savant also touched the said issue and
made reference to judgment in Vasanth Kumar and held that
depending upon the facts of each case, sub-classification of
backward classes into backward and more, or most backward
would be justifiable provided separate quotas are prescribed
patil-sachin.
::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:24 :::
                                    340                          Marata(J) final.doc
for each of them.              He has quoted an instance and justified
conclusion in the following manner :-
                "To give an instance, the Mandal Commission has, on
                the basis of social, educational and economic indicators
                evolved 22 points by giving different values to each of
                the three factors, viz., social, educational and economic.
                Those social groups which secured 22 points or above
                have been listed there as "socially and educationally
                backward" and the rest as "advanced". Now, between
                11 and 22 points some may secure, say, 11 to 15 points
                while others may secure all 22 points. The difference in
                their backwardness is, therefore, substantial.         Yet
                another illustration which may be given is from
                Karnataka State Government order dated October 13,
                1986 on reservations issued after the decision in
                Vasanth Kumar where the backward classes are grouped
                into five categories viz. A, B, C, D and E. In category A,Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                fall such castes or communities as that of Bairagi,
                Banjari and Lambadi which are nomadic tribes, and
                Bedaru, Ramoshi which were formerly stigmatised as
                criminal tribes whereas in category D fall such castes as
                Kshatriya and Rajput. To lump both together would be
                to deny totally the benefit of special provisions to the
                former, the latter taking away the entire benefits. On
                the other hand, to deny the status of backwardness to
                the latter and ask them to compete with the advanced
                classes would leave the latter without any seat or post.
                In such circumstances, the sub-classification of the
                backward classes into backward and more or most
                backward is not only desirable but essential. However,
                for each of them a special quota has to be prescribed as
                is done in the Karnataka Government order. If it is not
                done, as in the present case, and the reserved posts are
                first offered to the more backward and only the
                remaining to the backward or less backward, the more
                backward may take away all the posts leaving the
                backward with no posts. The backward will neither get
                his post in the reserved quota nor in the general
                category for want of capacity to compete with the
                forward"
patil-sachin.
::: Uploaded on - 27/06/2019                   ::: Downloaded on - 28/06/2019 05:25:24 :::
                                   341                              Marata(J) final.doc
                 Justice Sahai, however, did not agree to the view of
the majority and according to him, since the constitution
treats all citizens alike for           purposes of employment except
those who fall under Article 16(4), any further classification or
grouping         for     reservation    is   constitutionally        invalid       and
according to him, for valid classification, legislature or
executive          measures may be co-related with the legislative
purpose or objective. Similar is the observation of Justice
Pandian and Justice Thommen. In any event, the saidDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

observations are in minority and therefore, not binding on us.
Thus, in light of the Constitution Bench judgment, it is
permissible to divide the backward classes into backward and
more backward.
125              The list of OBC in the State includes the castes
which are identified as socially and educationally backward by
applying yardsticks which was approved in Indra Sawhney.
The argument advanced of reserving 27% seats for the
recognized backward classes was turned down by holding that
though equal protection clause prohibits the State from
making unreasonable discrimination for providing facilities for
any section of its people, it requires the State to afford
patil-sachin.
::: Uploaded on - 27/06/2019                      ::: Downloaded on - 28/06/2019 05:25:24 :::
                                    342                              Marata(J) final.doc
substantially equal opportunities to whose placed unequally
and        the        submission     that    implementation                 of       the
recommendation of the report will curtail concept of equality
and destroy the basic structure of the Constitution was held to
be not legally sustainable.              Justice Savant in para 415 has
observed thus :
                "Equality contemplated by Article 14 and other
                cognate articles including Article 15(1), 16(1) 29(2)
                and 38(2) of the Constitution is secured not only
                when equals are treated equally but also when
                unequals are treated unequally. Conversely, when
                unequals are treated equally, the mandate ofDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                equality before law is breached. To bring out equality
                between unequals, therefore, it is necessary to adopt
                positive measures to abolish inequality.          The
                equalizing measures will have to use the same tools
                by which inequality was introduced and perpetuated.
                Otherwise equalization will not be of the unequals.
The reservation when looked as an affirmative action and
provides a remedy for historical discrimination and its
continuing ill-effects, aims at redressing the malady.                              The
eradication          of    such   discrimination      is    the     constitutional
mandate. It is no doubt true that any legitimate affirmative
action must be supported by valid classification based on
intelligible differentia distinguishing classes of citizens chosen
for the protective measures from those excluded from those
measures and such differentia must bear a reasonable nexus
patil-sachin.
::: Uploaded on - 27/06/2019                       ::: Downloaded on - 28/06/2019 05:25:24 :::
                                    343                          Marata(J) final.doc
with the object sought to be achieved i.e. the amelioration of
the backwardness of the chosen class of citizens. The avowed
purpose for which the impugned legislation is introduced by
the State legislature is to attain an affirmative action for a
class which has escaped its identification as 'backward class'
for a considerable long period of time. However, after
collecting the quantifiable data in respect of a particular
community, the State stepped in and enacted a legislation
conferring recognition on the said class to be a socially andDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

educationally backward class. The conclusion derived on the
basis of applying the indicators set out by the National
Commission for backward classes i.e. the Mandal Commission
and by applying the similar yardsticks which came to be
applied by the Commission while identifying the Other
Backward Classes.              The classification of Maratha community
as a backward community, however, posed several questions
and the perplexed issue which the State was confronted with
was about introducing this class to the benefits of reservation
contemplated under Article 15(4) and 16(4) particularly when
the Other Backward Classes, the Scheduled Caste and
Scheduled Tribes have already taken their positions and the
quota of seats was already reserved for them.                        The newly
patil-sachin.
::: Uploaded on - 27/06/2019                   ::: Downloaded on - 28/06/2019 05:25:24 :::
                                   344                           Marata(J) final.doc
identified class called for an accommodation but without
disturbing the well established pattern in favour of the Other
Backward Classes which entered the State list on being
identified so.           This resulted into an extra-ordinary situation
and an exceptional circumstance which compelled the State to
sub-categorize the strata of Other Backward Classes into the
two distinct categories i.e. the existing Other Backward
Classes which already have paved a way for availing benefits
of reservation in form of affirmative action and the other classDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

which is found to be backward but is being provided benefits
for the first time. The population of 30% of this class, if
allowed its entry in the Other Backward Category would have
resulted into unjust deprivation of those caste which already
finds place in the list of Other Backward Classes after being
identified so on the recommendation of Mandal Commission.
The State Government therefore, bifurcated the backward
class existing in State and divided it in Other Backward Class
and the Socially and Educationally backward class (SEBC) and
Maratha community is one of them. The State has left scope
for including other such castes in this newly category as class
i.e. Socially and Educationally Backward Class of Citizens
(SEBC) who have been held eligible to avail the benefits of
patil-sachin.
::: Uploaded on - 27/06/2019                   ::: Downloaded on - 28/06/2019 05:25:24 :::
                                    345                              Marata(J) final.doc
reservation of seats for admission in educational institutions in
the State and for appointments or posts in the public services
under the State. The categorization of this class, however, did
not entitle it to avail the benefits of appointments to super
specialized posts or in the temporary appointments of less
than 45 days duration.              Similarly, the impugned legislation
restricts the benefit to be conferred on the newly created class
only for admission in educational institution and posts for
appointments in public services and under the State and notDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

for political purpose.           The said enactment, further clarified
that the impugned Act will not affect the reservation provided
to Other Backward Classes under the Act of 2001 or the Act of
2006. The classification of Maratha community which is
otherwise declared as Backward class into a distinct class
captioned as 'Socially and educationally backward class' is
perfectly within the province of the State and the classification
of the Other Backward Classes in the State based on the
acclaimed          parameters      of    backwardness        i.e.     Social       and
Educational backwardness, according to us, is reasonable
classification commensurating with the object sought to be
achieved          i.e.     upliftment    of   Maratha      as       socially       and
educationally backward class in the State and of affording
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:24 :::
                                346                         Marata(J) final.doc
equality of opportunity in the matter of employment and
education to the said class.
126              Learned counsel Shri Datar has placed reliance on
the judgment of the Hon'ble Apex Court in case of E.V.
Chinnaiah Vs. State of Uttar Pradesh ,27 to submit that it is
not permissible for a State to sub-divide a class so as to give
more preference to a minuscule proportion in preference to
other members of the said class. He has placed reliance onDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

the said judgment and advanced an argument that the
reservation looked as affirmative action for Scheduled Caste
though it is the prerogative of the State, it is not permissible
to have further sub-division/sub-classification of Scheduled
caste as contained in presidential list under Article 341 and
according to him, it was not open for the State to sub-classify
Scheduled caste and apportion the seats of the quota already
reserved for Scheduled caste as a whole among sub-classes of
Scheduled caste so created. He would submit that the Hon'ble
Apex Court in categorical terms has held that such sub-
classification or micro classification would be violative of
Article 14 and doctrine of reasonableness.
27 2005(1) SCC 394
patil-sachin.
::: Uploaded on - 27/06/2019              ::: Downloaded on - 28/06/2019 05:25:24 :::
                                       347                               Marata(J) final.doc
                 We have perused the said judgment and on its
perusal,         express       that     the    said      judgment            is    clearly
distinguishable. It pertains to sub-classification of the list of
Scheduled caste                under Article 341 and this makes it
distinguishable from the present case in hand where we are
dealing with the Other backward classes. The said judgment
revolves around distinct fact involving the Andhra Pradhesh
Scheduled Caste (Rationalization of Reservation Act 2000).
The facts disclose that the State of Andhra Pradesh appointedDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

a Commission to identify group amongst the Scheduled Caste
found in the list prepared under Article 341 of the Constitution
by the President who had failed to secure the benefit of
reservation provided for Scheduled Caste in the State in
admission          to     Professional      colleges      and      appointment             to
services in the State. According to the report, the State, by an
ordinance divided 57 castes enumerated in the Presidential
list into 4 groups based on inter se backwardness and fixed
separate quotas in reservation of each of these groups,
resultantly in the Presidential list came to be grouped as 'A',
'B', 'C' and 'D' and 15% reservation for the Scheduled Caste
under Article 15(4) and 16(4) came to be apportioned as
Group A - 1%, Group B 7%, Group C 6% and Group D 1%. The
patil-sachin.
::: Uploaded on - 27/06/2019                           ::: Downloaded on - 28/06/2019 05:25:24 :::
                                348                        Marata(J) final.doc
argument of the appellant before the Court was that the State
legislature has no competence to make any law in regard to
bifurcation of the Presidential list of scheduled caste prepared
under Article 341(1) of the Constitution and impugned
legislation being one solely meant for sub-dividing or sub-
grouping of the caste enumerated in the Presidential list
suffers from lack of legislative competence.
                 The appellant was thus critical of allotting a
separate percentage of reservation from amongst the totalDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

reservation allotted to the scheduled caste to different groups
among the scheduled caste amounted to depriving one class
of benefits of such reservation atleast partly.                The State
advanced a submission that quantum of reservation to be
provided is an exclusive privilege of the State and that State
will have to keep in mind the extent of backwardness of a
group, be it Other backward Class, Scheduled caste or
Scheduled Tribe and since the legislative competence of the
State was not disputed, the sub-categorization was sought to
be justified by placing reliance on Indra Sawhney vs. Union of
India. It was in these peculiar facts, the Apex Court dealt with
the contentions and emphasize that under Article 341 of the
Constitution, there is only one list for the State and the Article
patil-sachin.
::: Uploaded on - 27/06/2019             ::: Downloaded on - 28/06/2019 05:25:24 :::
                                   349                           Marata(J) final.doc
provides that the President may, with respect to any State or
Union Territory after consultation with the Governor thereof
by public notification specify the caste, races or tribes or part
of, or groups within the caste, races or tribes, which shall for
the purposes of Constitution             be deemed to be scheduled
caste in relation to that State or Union Territory and this was
indicative that there can be only one list which shall include all
specified caste, races or tribes or part or groups notified in
that presidential list and any inclusion or exclusion from theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

said list can only be done by Parliament under Article 341(2)
of the Constitution.           It was also observed that in the entire
Constitution           whenever    reference    has      been         made         to
"Scheduled Castes", it refers only to the list prepared by the
president under Article 341 and there is no reference to any
sub-classification or sub-division in the said list except may be
for the limited purpose of Article 330. It was thus observed
that it is clear from Article 341 that except for a limited power
of making an exclusion or inclusion in the list by an act of
parliament, there is no provision to sub-divide, sub-classify or
sub-grop these castes which are found in the Presidential list
of Scheduled castes. A reference was made to the constituent
Assembly Debates and a unique nature of Article 341. It was
patil-sachin.
::: Uploaded on - 27/06/2019                   ::: Downloaded on - 28/06/2019 05:25:25 :::
                                     350                             Marata(J) final.doc
then held that the Scheduled Caste list prepared by the
President          under       Article    341(1)   forms        one        class       of
homogeneous group and any division of this class based on
any consideration would be tinkering with the presidential list.
The enactment which provides for creation of four groups of
the caste enumerated in the presidential list of the state and
provided for proportionate allotment of reservation after
regrouping was held to be resulting in sub-classification or
micro classification and this was held to be violative of ArticleDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

14. The following observations would reveal the conclusions :-
                32.    The last question that comes up for our
                consideration is : whether the impugned enactment
                creates sub-classification or micro classification of
                the Scheduled Castes so as to violate Article 14 of
                the Constitution.
                37.    We have already held that the members of
                Scheduled Castes form a class by themselves and
                any further sub- classification would be impermissible
                while applying the principle of reservation.
                38.      On behalf of the respondents, it was pointed
                out that in Indra Sahani's case(supra), the court had
                permitted sub- classification of other backward
                communities, as backward and more backward based
                on their comparative under development, therefore,
                the similar classification amongst the class
                enumerated in the Presidential List of Scheduled
                Castes is permissible in law. We do not think the
                principles laid down in Indra Sahani's case for sub-
                classification of other backward classes can be
                applied as a precedent law for sub- classification or
patil-sachin.
::: Uploaded on - 27/06/2019                       ::: Downloaded on - 28/06/2019 05:25:25 :::
                                 351                           Marata(J) final.doc
                sub-grouping Scheduled Castes in the Presidential
                List because that very judgment itself has specifically
                held that sub-division of other backward classes is
                not applicable to Scheduled Castes and Scheduled
                Tribes. This we think is for the obvious reason, i.e.
                Constitution itself has kept the Scheduled Castes and
                Scheduled Tribes List out of interference by the State
                Governments.
127              In light of the aforesaid observation, we would
gainfully observe that the Apex Court was dealing with a
situation of a list of Scheduled Castes under Article 341(1).
However, before us, we are confronted with the issue of sub-Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

classification of Other Backward classes and its permissibility
by sub-classifying them.
128              In case of Atyant Pichhara Barg Chhatra Vs
Jharkhand State Vaishya28 when the State of Jharkand had
clubbed          together the Extremely Backward Category and
Backward Category for the purpose of reservation in the State
of Jharkhand, the Apex Court remitted the matter to the State
to determine separately as to what would be the percentage
of reservation for the Extremely Backward Category and held
that the amalgamation of the two classes of people for
reservation would be unreasonable as two different classes
are treated similarly which is in violation of the mandate of
28 2006(6) SCC 718
patil-sachin.
::: Uploaded on - 27/06/2019                 ::: Downloaded on - 28/06/2019 05:25:25 :::
                                352                       Marata(J) final.doc
Article 14 of the Constitution of India which is to "treat similar
similarly and to treat different differently" and it was held that
it is well settled, that to treat unequals as equals also violates
Article 14 of the Constitution. It was further held that there is
no constitutional bar to a state categorizing the backward
classes as backward and more backward class but the action
of the State Government for excluding from the list of classes
was frowned upon on the ground that once the particular
community is included in the list, it can be taken out only afterDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

the State has reached a conclusion that community is
adequately represented in the services of the State.                 It was
held that the State has failed to show any new circumstances
except for a bald statement that the community was removed
after careful application of mind whereas there was no
empirical data to indicate that the circumstances have
undergone change. In these circumstances, the matter was
remitted to the State Government to undertake a deep study
and research by a special Committee of experts and to make
recommendations.
patil-sachin.
::: Uploaded on - 27/06/2019            ::: Downloaded on - 28/06/2019 05:25:25 :::
                                   353                            Marata(J) final.doc
129              It can thus be seen that there is a systematic
relation in segregating the Maratha class which is distinct in
characteristic and herding Maratha class with the OBC would
be highly unjust. The argument is that the State has taken
utmost care in classifying the Maratha community as SEBC
and has satisfied itself of the characteristic of social,
educational and economic backwardness and inadequacy of
representation in public employment and these characteristic
features are consequently absent in the open category who
are left out of reservation and therefore, there is well founded
intelligible        differentia   which     distinguishes        the      MarathaDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

community from others.                  Ultimately, the whole object in
providing reservation is to attain social justice, advancement
of Maratha community as a class of citizens and adequate
representation in Government service for the differently
placed Maratha class of citizens and this establishes a nexus
which is the basis of creating separate class of SEBC and
while doing so, State has already taken care of maintaining
the efficiency of administration by not diluting the standard of
educational qualification for direct recruitment.
patil-sachin.
::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:25 :::
                                   354                          Marata(J) final.doc
(VII) WHETHER CEILING LIMIT OF 50% IN RESERVATION
EXISTS
130              The philosophy of Indian Constitution is reflected in
its preamble.             The significance of the preamble lies in its
components. It embodies the source of the Constitution i.e.
"We, the People of India". The terms 'sovereign', 'socialist',
'secular', 'democratic', 'republic' suggest the nature of the
State. The Ideals of justice, liberty, equality, fraternity reflects
the objectives of the Constitution. The words employed in the
preamble are indicative of the fundamental values on which
the constitution rests. It emulates the dreams and aspirations
of its founding fathers.
                 The preamble avouch equality of status andDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

equality of opportunity as one of its prominent goal.                                It
embraces three dimensions of equality - civil, political and
economic. The fundamental rights enshrined in Part III of the
Constitution ensures civil equality through the paraphernalia
of Article 14, 15, 15(1) and 16(1) and also through Article 17
and 18 which abolish untouchability and titles. Political
equality is ushered through Article 325 which contemplates
one general electoral roll for every territorial constituency of
election either to the house of Parliament or to the house of
patil-sachin.
::: Uploaded on - 27/06/2019                  ::: Downloaded on - 28/06/2019 05:25:25 :::
                                355                         Marata(J) final.doc
the legislature of the State and no person shall be deemed to
be ineligible for inclusion in such roll on the ground of religion,
race, caste, sex or any of them. Article 326 prescribes that
the elections to the house of people and to the legislative
assembly of States to be based on adult suffrage. Economic
equality in the country is secured through directive principles
of State Policy and in particular, Article 39 which mandates
every State to direct its policy towards securing adequate
means of likelihood to citizens - men and women equally, and
which ensures equal pay or equal work for both.                       It also
mandates the State to direct its policy in a way that the
operation of economic system does not result in concentration
of wealth and means of production to the common detriment.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

131              Equality is thus essence of the Indian Democracy.
The right to equality under Article 14 has been held to
constitute the basic structure of the Constitution in terms of
the decision of the Apex Court in case of N. Nagaraj (supra).
Article 14 of the Constitution envelopes a positive concept and
postulates equal treatment to similarly situated persons.                        It
makes it imperative for the State to ensure equality before law
and equal protection of laws within the territory of India.
patil-sachin.
::: Uploaded on - 27/06/2019              ::: Downloaded on - 28/06/2019 05:25:25 :::
                                   356                             Marata(J) final.doc
However, recognizing the inequality in existence in our social
structure, the makers of the Constitution conceived that the
weaker sections have to be dealt with preferential hand.                                A
special responsibility was placed on the State to provide
protection           to   the   weaker   sections    of     Society.              The
Constitution, contains several inbuilt provisions which provide
for protective discrimination to accelerate the process of
building an egalitarian social order which would ensure
upliftment of the weaker sections of society.                      This was an
answer found by the Constitution makers to the Indian Social
System which is a caste based hierarchical system which
made certain classes suffer the demerits of social and
economic             underdevelopment.       Though        these        provisionsDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

appear to be violating the principle of equality, yet, its
justification is sustained by the obligation of a social welfare
state.
132              The system of reservation in India extends to a
series          of     measures     such    as      reserving          seats         in
Parliament/legislature, government job, securing admission in
higher educational institutions, scholarships, housing etc. The
reservation policy nourishes the historically disadvantageous
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:25 :::
                                   357                            Marata(J) final.doc
castes and tribes - listed as Scheduled Caste and Scheduled
Tribe and also those designated as Other Backward Class so as
to      address          the   historic   oppression,       inequality           and
discrimination faced by certain communities and to uplift
them on the same pedestal as those who have already
advanced in the social scenario.             The reservation system is
intended to realise the promise of equality enshrined in the
Constitution and is looked upon as a means to confer benefits
on indigenous people with lesser abilities so that they can get
access to the social and economic resources and gain entry
into the mainstream of public life.
                 Though the 'equal protection' clause prohibits State
from       making          unreasonable   discrimination         in     providingDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

preferences and facilities to any section of it is people, none
the less, the spirit of the constitution obligates a State to
afford substantially equal opportunities to those                           placed
unequally so as to ensure equality to them.                           The basic
philosophy of reservation is to off-set the inequality and
remove the            manifest imbalance, the victims of which have
been left behind by those who, on account of advantages
conferred, have moved far ahead and those lagging behind
demand equality, at times through special preferences.
patil-sachin.
::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:25 :::
                                358                         Marata(J) final.doc
Those classes of social groups which are inherently unequal
and suffered the brunt of social discrimination resulting into
backwardness, demand to justify the treatment to them in
form of concession and equality can be achieved only when
equilibrium is established between these two sections of
society who were once unequal.          Equality can be achieved
only by treating equals, equally and to equate unequals would
amount to perpetuating inequality.
                 The idea of preferential treatment for caste and
tribal groups perceived to be the lowest in social and
economic hierarchy pre-dates the Indian Constitution.                      The
Constitution of independent India has translated the idea of
preferential policies, declared untouchability as illegal                  andDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

espoused the ideal of a casteless society.
133              The reservation system in India first came into
effect from 1950 though prior to its advent, the Hindu system
was a Chaturvarniya system involving the higher caste and
the lower caste frequently referred to as 'shudras'. When the
makers of the modern India sat to pen down the Constitution
of independent India though realized the need to give visibility
to the diversity within its social landscape while at the same
patil-sachin.
::: Uploaded on - 27/06/2019              ::: Downloaded on - 28/06/2019 05:25:25 :::
                                       359                            Marata(J) final.doc
time, were confronted with levelling them out in an equal
socio economic strata. Caste was the very important factor to
be taken care of since the Varna system had gained its root in
the society and was firmly founded. While this unique position
existed in Indian subcontinent for over a century, the Decenn
Census          started        by   British   in   late    19 th     Century         had
institutionalized it as a foremost social division existing.
Recognition of caste discrimination and the need to rectify the
same was noted even before the Constitution was framed. Dr.
Ambedkar was a pioneer of separate political representation
for lower caste. His vociferous effort culminated in allotment
of separate electorate for the lower caste, grouped under the
category "Scheduled Caste" in the Government of India Act,Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

1935. The constituent assembly promised to transform India
into a casteless society.              The Constitution with its theme of
equality was weaved around the "Fundamental Rights of
Citizens".          Keeping in mind the unique role that the caste
played historically discriminating against the entire group of
people, it was deemed necessary for the Constitution to
recognize its existence through provisions carefully crafted for
their advancement.                  Article 15(4) and 16(4) translate this
policy and carve out a special provision.                          The constituent
patil-sachin.
::: Uploaded on - 27/06/2019                        ::: Downloaded on - 28/06/2019 05:25:25 :::
                                      360                           Marata(J) final.doc
assembly is a witness to long and heated debate and
discussion to decide upon the precise nature and duration of
these provisions.              In 1951, when reservation privileges were
being decided, Census lists were utilized and the State came
to the conclusion that 55.3 million people i.e. 20% of India's
population would be brought under reserved categories. The
constitution makers deemed it fit to determine the indicators
of the backward classes though as far as Scheduled Caste and
Schedule          Tribes       are   concerned,   it    devised         a     special
mechanism of identifying them by Presidential Notification and
its inclusion and deletion by the Parliament itself.                           Social
backwardness and Educational backwardness were zeroed
down as the indicators for determining the backwardness andDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

sub-clause (4) of Article 15 which was inserted by the 1 st
Amendment with effect from 18 th June 1951 conferred the
power on the State to make any special provision for the
advancement of any socially and educationally backward
classes of citizens or for the Scheduled Caste and the
Scheduled Tribes. The word "backward classes" was preceded
by terminology 'socially and educationally'.                    The equality of
opportunity in matters of public employment which is
contained in Article 16 of the Constitution enable the State to
patil-sachin.
::: Uploaded on - 27/06/2019                      ::: Downloaded on - 28/06/2019 05:25:25 :::
                                     361                           Marata(J) final.doc
make any provision for reservation of appointments or posts in
favour of any backward class of citizens which in the opinion
of the State are inadequately represented.
134              Affirmative action, especially for Other Backward
classes has always been an issue of debate in the history of
independent India. Positive discrimination, as this is known in
India, is a laudable process in line with the Constitutional goals
that India has set out for itself.            The task of identifying the
other Backward Classes is a complex issue since the
Constitution has neither defined the term nor has prescribed
any method of recognizing them unlike the Scheduled Caste
and Scheduled Tribes.                The issue of identification of theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Backward class still persists despite several authoritative
pronouncements embarking the issue.                      In absence of an
uniform         method         conclusively   tested    to     determine           the
backwardness, resentment among large section of population
remains as the issue is seen to have politicized at times with
the intent of OBC being marginalized. Though the perennial
conundrum whether caste should be used as sole factor for
identification of the backward classes, has undergone a
paradigm shift in the approach and by this time it is settled
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:25 :::
                                     362                               Marata(J) final.doc
that caste may not be the sole factor in identification of the
backward classes and other indicators contributing to the
backwardness               in    various     forms    including          educational
backwardness, economic backwardness, occupation, place of
residence has been recognized as accepted yardsticks for
measuring backwardness.
          After Seven decades of the Constitution being in force,
the States are still baffled with the concept of social and
economic          backwardness         and       whether,      these       indicators/
yardsticks are sufficient to determine backward classes,
determination of which has been left exclusively to the
province and wisdom of the States.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

135              The first National Commission for backward class
constituted in the year 1953 under the Chairmanship of
Kalelkar Commission which was entrusted with the task of
listing of the socially and educationally backward classes,
related it to social hierarchy based on caste and identified
2399        castes.        However,        the   recommendations               of     this
Commission were not accepted since it was predominantly
based on caste.                 In 1979, the Second National Backward
Commission Class Commission under the Chairmanship of
patil-sachin.
::: Uploaded on - 27/06/2019                         ::: Downloaded on - 28/06/2019 05:25:25 :::
                                        363                           Marata(J) final.doc
Bindeshwari Prasad Mandal was constituted which carried out
an empirical assessment of 405 out of 406 districts by
evolving 11 yardsticks covering social, educational and
economic backwardness. It submitted its report in 1980 listing
3743 Hindus and non-hindu caste and communities which
according          to    the    Commission,     constituted          52%       of     the
population.             The Mandal Commission recommended 27%
reservation for the communities identified by it as "socially
and educationally backward" over and above the Scheduled
Caste and Scheduled Tribe.                   After a gap of 10 years, the
Government               took      a     decision     to       implement              the
recommendations of the Commission and it is not a hidden
fact that it was met with wide spread protest, both classes i.e.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

one being identified as socially and educationally backward
and the other class being apprehensive of the privileges being
conferred protested in rigorous forms.                     Amongst this chaos
and conflict, the Hon'ble Apex Court through its Constitution
Bench in case of Indra Sawhney (supra) upheld the
reservation of 27% conferred on the socially and educationally
backward class.                Since then, the caste led reservation on
being identified as social backwardness have stayed in form of
an affirmative action.
patil-sachin.
::: Uploaded on - 27/06/2019                        ::: Downloaded on - 28/06/2019 05:25:25 :::
                                    364                          Marata(J) final.doc
136              The       Other   Backward   Class     is     thus      another
beneficiary group which has entered into the arena of
reservation policy. Though the term "backward class" is not
precisely defined in the Constitution, the characteristic for its
identification finds place in Article 15(4) and Article 16(4).
Further, Article 46 contained in the directive principles of State
policy which endows the State with a duty to promote with
special care the educational and economic interest of the
weaker section of the people and in particular of Scheduled
Caste and Scheduled Tribe and to protect them from social
injustice and all forms of exploitation lead to an irresistibleDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

conclusion that the constitution makers intended to protect
the educational and economic interest of the weaker sections.
The term being widely used so as to cover a community other
than Scheduled Caste and Scheduled Tribes and to protect this
community from any sort of social injustice, thereby taking
care of their social backwardness.              Article 15(4) and 16(4)
removes the fetters of the equality clause from the State and
permits it to make special provision for advancement of
socially and educationally backward class of citizens for the
Scheduled Caste and Scheduled Tribes and also permit the
patil-sachin.
::: Uploaded on - 27/06/2019                   ::: Downloaded on - 28/06/2019 05:25:25 :::
                                    365                           Marata(J) final.doc
State to make provision for reservation of appointments of
post in favour of any backward class of citizens which, in the
opinion of the State is not adequately represented in the
services under the State. The said provision thus recognizes
the need to take special steps for ameliorating the social
conditions of certain classes. Pertinent to note that neither
Article 15(4) nor Article 16(4) makes reference to the words
"caste" but it makes a reference to the word 'class'. "Class" is
clearly distinguishable from 'caste' and 'class' is a system of
social stratification which rests upon the unequal distribution
of power between status groups having definite position in
prestige hierarchy.            It is relatively open as compared to otherDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

form of status like caste. 'Backward class' do not constitute
one single whole but a multitude of social groups with varying
position and socio economic standing in the social hierarchy of
Indian Society.
137              We are confronted with the rival claim as to
whether 50% limit for reservation of the backward classes of
citizens, including the Scheduled Caste and Schedule Tribe
exists in the constitutional frame work.                The learned senior
counsel representing the State Government Shri Rohatgi and
patil-sachin.
::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:25 :::
                                366                      Marata(J) final.doc
Shri Thorat has strenuously urged that the ceiling of 50% in
reservation is a misconception.        It is argued that the
reservation is permissible under the Constitution and is carved
out as an exception to the theory of equality and there is no
embargo created by the Constitution restricting it to 50%. It is
also urged that the authoritative pronouncement of the Apex
Court do not lay down any numerical limit for the reservation
contemplated under Article 15(4) or 16(4). The arguments are
also focused on the 77th Constitutional amendment as well as
81st Amendment in form of Article 16(4B) dealing with the
unfilled vacancy and it is then argued that except this article,
the Constitution nowhere prescribes 50% as the limit.                  It isDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

attempted to canvass that the pronouncements of the Apex
Court in case of M.R. Balaji (supra) while dealing with the
competing claims of the two categories have been clarified
subsequently by the majority judgment in Indra Sawhney as
only rule of prudence and it has been categorically held that
exceptional circumstances and extra-ordinary situation justify
crossing of the limit of 50% and ceiling of 50% is normal rule
and excess is an exception which contemplates a justification.
Learned senior counsel Shri Rohatgi has placed heavy reliance
on certain parts of the judgment in case of N. Nagaraj.
patil-sachin.
::: Uploaded on - 27/06/2019           ::: Downloaded on - 28/06/2019 05:25:25 :::
                                367                    Marata(J) final.doc
Respective counsel appearing for the State have also invited
our attention to a subsequent judgment of the Apex Court in
case of S.V. Joshi Vs. State of Karnataka29 and relying on
the said judgment, they would submit that if quantifiable data
is available, then, there is no hindrance in the reservation
exceeding 50%. It is then sought to be submitted that when
the MSBCC headed by Shri Gaikwad has made available
quantifiable data pertaining to Maratha community, in light of
this existing data demonstrating that Maratha constitute 30%
of the population in State of Maharashtra has therefore,
justified the reservation in favour of Maratha and this data
being collected in a scientific manner, and the scope ofDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

judicial review being limited, the ceiling of 50% will not
preclude the State from enacting a legislation providing for
16% reservation in favour of Maratha community.                 On the
other hand, the respective counsel opposing reservation in
favour of Maratha proceed on the very premise that the said
reservation obliterate the constitutional requirement of a
ceiling limit of 50% and submit that even the father of the
Constitution Dr. B.R. Ambedkar in the constituent assembly
had expressed that reservation should be confined to a
29 2012(7) SCC 41
patil-sachin.
::: Uploaded on - 27/06/2019         ::: Downloaded on - 28/06/2019 05:25:25 :::
                                         368                          Marata(J) final.doc
minority seats.                Heavy reliance is placed by the respective
counsel in case of Archana Reddy, a judgment delivered by
the Andhra Pradesh High Court where even 1% excess
reservation has been frowned upon since the exceptional or
extra-ordinary circumstances were not made out.                                     It is
unequivocally argued by the learned senior counsel Shri Aney,
Shri Datar and Shri Sadavarte that the Constitution Bench
Judgment in case of Indra Sawhney upholds and follows the
principle laid down in Balaji and the only exception is in
respect of the "Far flung and Remote areas" which are
portrayed as extra-ordinary situation. However, the ultimate
word of the Constitution Bench is "extreme caution" for goingDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

beyond 50%.
138              In light of these legal submissions, we would
examine the legal scenario as unfolded in the catena of
judgments of the Hon'ble Apex Court to ascertain as to
whether ceiling of 50% really exists. The said judgments need
to be construed and read in the light of the provisions
providing for the special privilege. Article 15(4) is introduced
by the Constitution (1st Amendment) Act of 1951 in order to
enable          the    State       to    make   special    provision          for     the
patil-sachin.
::: Uploaded on - 27/06/2019                        ::: Downloaded on - 28/06/2019 05:25:25 :::
                                 369                           Marata(J) final.doc
advancement of any socially and educationally backward class
of citizens or for the Scheduled caste or Scheduled Tribe.
Further, it would be also necessary to make a reference to
clause (5) inserted in Article 15 by the Constitution (93 rd
Amendment) Act of 2005 with effect from 20 th January 2006
which is an enabling provision for advancement of any socially
and educationally backward classes of citizens or for the
Scheduled Caste and Schedule Tribe, insofar as it relate to
their admission to educational institutions, including private
educational institution, whether aided or unaided by the State,
other than the minority educational institution referred to in
clause (1) of Article 30. Article 16(1) and 16(2) mandate theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

equality of opportunity in matters of public employment.
Clause (4) of Article          16 enables the State for making any
provision for reservation of appointment or posts in favour of
any backward class of citizens, which in the opinion of the
State is not adequately represented in the services under the
State.          Clause (4) do not make any reference to Scheduled
Castes or Scheduled Tribes but it is apparent and by this time,
conclusively held that the expression "any backward class of
citizens" would include within its sweep the Scheduled caste
and Scheduled Tribe.            It is clarified so in the Constitution
patil-sachin.
::: Uploaded on - 27/06/2019                 ::: Downloaded on - 28/06/2019 05:25:25 :::
                                  370                            Marata(J) final.doc
Bench Judgment in case of Indra Sawhney. Further more, the
position as regards whether Article 16(4) would apply only to
initial appointment or promotion is also clarified by the
Constitution Bench that it would apply only to appointment
and would not extend to promotion. However, on account of
an uproar following the said verdict, since it adversely affected
the interest of Scheduled Caste and Schedule Tribe, the 77 th
Amendment Act of 1995 introduced clause 16(4A) which reads
thus :
                  "(4A) Nothing in this article shall prevent the State
                  from making any provision for reservation in matters of
                  promotion to any class or classes or posts in the
                  services under the State in favour of the Scheduled
                  Castes and the Scheduled Tribes which, in the opinion
                  of the State, are not adequately represented in theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                  services under the State".
We would also make a reference to Article 16 (4B) which was
inserted by the Constitution (85th Amendment) Act of 2001
with effect from 17th June 1995.
                (4B) Nothing in this article shall prevent the State
                from considering any unfilled vacancies of a year
                which are reserved for being filled up in that year in
                accordance with any provision for reservation made
                under clause (4) or clause (4A) as a separate class of
                vacancies to be filled up in any succeeding year or
                years and such class of vacancies shall not be
                considered together with the vacancies of the year in
                which they are being filled up for determining the
                ceiling of fifty per cent reservation on total number of
                vacancies of that year".
patil-sachin.
::: Uploaded on - 27/06/2019                   ::: Downloaded on - 28/06/2019 05:25:25 :::
                                 371                               Marata(J) final.doc
It is this clause which is introduced with effect from 9 th June
2000, there is a mention of ceiling of 50%.
139               In case of M.R. Balaji Vs. State of Mysore
(supra), the Hon'ble Apex Court was confronted with the two
affirmative clauses in form of Article 15(4) and 16(4) and the
Constitution Bench dealt with two competing claims i.e.
interest of weaker sections of the Society and adjudged the
said claim against the interest of other communities. In the
said case, the petitioners before the Apex Court had
challenged the validity of an order passed by the State ofDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Mysore           endeavoring   to     make   a      special        provision         of
advancement of its socially and educationally backward class
of citizens under Article 15(4) of the Constitution.                      The said
order was challenged by the petitioner on the basis that but
for the reservation, they would have been entitled to
admission in the respective colleges on the basis of their
merit.          It was urged that the basis adopted by the order in
specifying and enumerating social and backward class of
citizens in the State is unintelligible and irrational and the
classification made on the said basis is inconsistent with and
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:25 :::
                                372                         Marata(J) final.doc
outside the provision of Article 15(4). It was also urged that
the extent of reservation prescribed by the said order was
unreasonable and extravagant and amounts to a fraud on the
power conferred by the said provision          on the State.               The
State, on the other hand, urged that the classification is
rational and intelligible and reservation prescribed is fully
justified by Article 15(4). By the said order, a quota of 50%
was fixed for Other Backward Class, out of which 28% seats
were reserved for so-called backward classes and 22% seats
were reserved for more backward classes.                    This was in
addition to the reservation of 15% and 3% for Scheduled
Caste and Scheduled Tribe respectivelyd and result of theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

order was 68% of the seats available for admission to
engineering and medical colleges came to be reserved,
leaving only 32% seats available to the merit pool.
140              While dealing with the two competing claims, the
Constitution Bench determined the scope and extent of the
expression "backward classes" and held that the concept of
backwardness is not intended to be relevant in the sense that
any classes who are backward in relation to the most
advanced classes of the society should be included in it.                        It
patil-sachin.
::: Uploaded on - 27/06/2019              ::: Downloaded on - 28/06/2019 05:25:25 :::
                                    373                            Marata(J) final.doc
held that if such relative tests were to be applied, there would
be several layers or strata of backwardness and each one of
them may claim to be included under Article 15(4).                           It held
that the backwardness under Article 15(4) must be social and
educational, both.             It then proceeded to determine how the
social and economic backwardness can be determined.                                     It
then deliberated on the issue of the extent of such reservation
and observed thus :-
                     30        That takes us to the question about the
                     extent of the special provision which it would be
                     competent to the State to make under Art. 15(4).
Article 15(4) authorizes the State to make any
                     special provision for the advancement of the
                     Backward Classes of citizens or for the Scheduled
                     Castes and Scheduled Tribes. The learned Advocate-Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                     General contends. that this Article must be read in
                     the light of Art. 46, and he argues that Art. 15(4) has
                     deliberately and wisely placed no limitation on the
                     State in respect of the extent of special provision that
                     it should make. Art. 46 which contains a directive
                     principle, provides that the State shall promote with
                     special care the educational and economic interests
                     of the weaker sections of the people, and in
                     particular, of the Scheduled Castes and the
                     Scheduled Tribes, and shall protect them from social
                     injustice and all form,% of exploitation. There can be
                     no doubt that the object of making a special
                     provision for the advancement of the castes or
                     communities, there specified, is to carry out the
                     directive principle enshrined in Art. 46. It is obvious
                     that unless the educational and economic interests of
                     the weaker sections of the people are promoted
                     quickly and. liberally, the ideal of establishing social
                     and economic equality will not be attained, and so,
                     there can be no doubt that Art. 15(4) , authorises the
                     State to take adequate steps to achieve the object
                     which it has in view. No one can dispute the
                     proposition that political freedom and even
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:25 :::
                                   374                            Marata(J) final.doc
                     fundamental rights can have very little meaning or
                     significance for the Backward Classes and the
                     Scheduled Castes Scheduled Tribes unless the
                     backwardness and inequality from which they suffer
                     are immediately redressed.
                     31        When Art. 16(4) refers to the special
                     provision for the advancement of certain classes or
                     scheduled castes or scheduled tribes, it must not be
                     ignored that the provision which is authorised to be
                     made is a special provision ; it is not a provision
                     which is exclusive in character, so that in looking
                     after the advancement of those classes, the State
                     would be justified in ignoring altogether the
                     advancement of the rest of the society. It is because
                     the interests of the society at large would be served
                     by promoting the advancement of the weaker
                     elements in the society that Art. 15(4) authorises
                     special provision to be made. But if a provision which
                     is in the nature of an exception completely excludes
                     the rest of the society, that clearly is outside the
                     scope of Art. 15(4). It would be extremelyDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                     unreasonable to assume that in enacting Art. 15(4)
                     the Parliament intended to provide that where the
                     advancement of the Backward Classes or the
                     Scheduled Castes , and Tribes was concerned, the
                     fundamental rights of the citizens constituting the
                     rest of the society were to be completely and
                     absolutely ignored,
                     32        In this connection, it is necessary to
                     remember that the reservation made by the
                     impugned order is in regard to admission in the seats
                     of higher education in the State. It is well-known that
                     as a result of the awakening caused by political
                     freedom, all classes of citizens are showing a growing
                     desire to give their children higher university
                     education and so, the Universities are called upon to
                     face the challenge of this growing demand. While it is
                     necessary that the demand for higher education
                     which is thus increasing from year to year must be
                     adequately met and properly channelised, we cannot
                     overlook the fact that in meeting that demand
                     standards of higher education in Universities must
                     not be lowered. The large demand for education
                     maybe met by starting larger number of educational
                     institutions, vocational schools and polytechnics. But
patil-sachin.
::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:25 :::
                                    375                            Marata(J) final.doc
                     it would be against the national interest to exclude
                     from the portals of our Universities qualified and
                     competent students on the ground that all the seats
                     in the Universities are reserved for weaker elements
                     in society. As has been observed by the University
                     Education Commission,
                                 "he indeed must be blind who does not
                                 see that mighty as are the political
                                 changes, far deeper are the fundamental
                                 questions which will be decided by what
                                 happens in the universities" (p. 32).
                      Therefore, in considering the question about the
                      propriety of the reservation made by the impugned
                      order, we cannot lose sight of the fact that the
                      reservation is made in respect of higher university
                      education. The demand for technicians scientists,Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                      doctors, economists, engineers a experts for the
                      further economic advancement of the country is so
                      great that it would cause grave prejudice to national
                      interests if considerations of merit are completely
                      excluded by whole-sale reservation of seats in all
                      Technical, Medical or Engineering colleges or
                      institutions of that kind. Therefore, considerations of
                      national interest and the interests of the community
                      or society as a whole cannot be ignored in
                      determining the question as to whether the special
                      provision contemplated by Art. 15(4) can be special
                      provision which excludes the rest of the society
                      altogether.
141              Thus, in a broader way, the Constitution Bench
expressed that a special provision for reservation should be
less than 50% of the seats and as to how much less would be
depending           on     the   circumstances    of    each       case.          The
recommendation of the Nagan Gowda Committee prescribing
68% reservation was not found to be proper in the larger
interest of the State.              Direction was issued to the State
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:25 :::
                                          376                           Marata(J) final.doc
Government that while making provision for advancement for
the weaker sections of the society, the issue should be
approached objectively in a rational manner. It categorically
expressed "there can be no doubt that the constitution
makers assume as they were entitled to, that while making
adequate reservation, under Article 16(4), care would be
taken           not   to       provide     for   unreasonable,        excessive           or
extravagant reservation, for that would, by eliminatingDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

general competitor in a large field and by creating widespread
dissatisfaction amongst the employees, materially affecting
efficiency.           Therefore, like the special provision improperly
made under Article 15(4) reservation made under Article 16(4)
beyond beyond permissible and legitimate limits would be
liable to be challenged as a fraud on the Constitution.
142               The Special Bench of Nine Judges came to be
constituted to settle the legal position relating to the
affirmative actions in form of reservation in light of OM dated
13th August 1980 and 25th September 1991 issued by the
Government pursuant to Mandal Commission Report.
                  The Constitution bench indicated and formulated
several issues and issue no.6 which is relevant for us at this
patil-sachin.
::: Uploaded on - 27/06/2019                          ::: Downloaded on - 28/06/2019 05:25:25 :::
                                      377                              Marata(J) final.doc
juncture reads thus :-
       (a)      Whether the 50% rule enunciated in Balaji (1963
                Supp 1 SCR 439) is a binding rule or only a rule of
                caution of prudence?
       (b)      Whether the 50% rule, if any, is confined to
                reservations made under clause (4) of Article 16 or
                whether it takes in all types of reservations that can
                be provided under Article 16?
       (c)      Further while applying 50% rule, if any, whether an
                year should be taken as a unit of whether the total
                strength of the cadre should be looked to?
143              The majority judgment was delivered by JusticeDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Jeevan B.P. Reddy (for Justice M.H. Kania, CJ, Justice                               M.N.
Venkatachalaiah,               Justice   Ahmadi,).       Since       the      bone       of
contention between the parties is based on the judgment of
the Constitution bench, it will be apposite to consider the said
Judgment in its proper perspective.
         The majority judgment carefully analyzed the term
"Socially and educationally" contained in clause (4) of Article
15. It clarified that the backward class of citizens in clause (4)
OF Article 16 takes in the Scheduled Caste and Scheduled
Tribes and all other backward class of citizens including
Socially and Educationally backward class. On the issue as to
patil-sachin.
::: Uploaded on - 27/06/2019                         ::: Downloaded on - 28/06/2019 05:25:25 :::
                                    378                           Marata(J) final.doc
whether the class should be situated similarly to the
scheduled caste                or scheduled tribes to be qualified as
backward, in para 795, Justice Jeevan Reddy observes thus :
                "795 We see no reason to qualify or restrict the
                meaning of the expression "backward class of
                citizens" by saying that it means those other
                backward classes who are situated similarly to
                Scheduled Castes and/or Scheduled Tribes. As pointed
                out in para 85, the relevant language employed in
                both the clauses is different. Article 16(4) does not
                expressly refer to Scheduled Castes or Scheduled
                Tribes; if so, there is no reason why we should treat
                their backwardness as the standard backwardness for
                all those claiming its protection. As a matter of fact,
                neither the several castes/groups/tribes within the
                Scheduled Castes and Scheduled Tribes are similarly
                situated nor are the Scheduled Castes and ScheduledDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                Tribes similarly situated. If any group or class is
                situated similarly to the Scheduled Castes, they may
                have a case for inclusion in that class but there seems
                to be no basis either in fact or in principle for holding
                that other classes/groups must be situated similarly to
                them for qualifying as backward classes. There is no
                warrant to import any such a priori notions into the
                concept of Other Backward Classes. At the same time,
                we think it appropriate to clarify that backwardness,
                being a relative term, must in the context be judged
                by the general level of advancement of the entire
                population of the country or the State, as the case
                may be. More than this, it is difficult to say"
While answering question no.6, which we have reproduced
above, the majority view, after making reference to the
Constitution Bench judgment in Balaji which rejected the
argument that the absence of limitation contained in Article
15(4), no limitation can be prescribed by the Court on the
extent of reservation and after making further reference to the
patil-sachin.
::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:25 :::
                                  379                                Marata(J) final.doc
observation of Justice Fazal Ali in the judgment of N.M.
Thomas,          expressed     that    after   a     decision         in    Thomas,
controversy arose wherein the 50% rule enunciated in Balaji,
stands overruled by Thomas or does it continue to be valid.
The majority view is expressed in the following manner :
                 807         We must, however, point out that Clause
                (4) speaks of adequate representation and not
                proportionate         representation.         Adequate
                representation cannot be read as proportionate
                representation.      Principle     of     proportionate
                representation is accepted only in Articles 330 and
332 of the Constitution and that too for a limited
                period. These articles speak of reservation of seats inDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                Lok Sabha and the State Legislatures in favour of
                Scheduled Tribes and Scheduled Castes proportionate
                to their population, but they are only temporary and
                special provisions. It is therefore not possible to
                accept the theory of proportionate representation
                though the proportion of population of backward
                classes to the total population would certainly be
                relevant. Just as every power must be exercised
                reasonably and fairly, the power conferred by Clause
                (4) of Article 16 should also be exercised in a fair
                manner and within reasonably limits - and what is
                more reasonable than to say that reservation under
                Clause (4) shall not exceed 50% of the appointments
                or posts, barring certain extra-ordinary situations as
                explained hereinafter. From this point of view, the
                27% reservation provided by the impugned
                Memorandums in favour of backward classes is well
                within the reasonable limits. Together with reservation
                in favour of Scheduled Castes and Scheduled Tribes, it
                comes to a total of 49.5%. In this connection,
                reference may be had to the Full Bench decision of
                the Andhra Pradesh High Court in Narayan Rao v.
                State 1987 A.P. 53, striking down the enhancement of
                reservation from 25% to 44% for O.B.Cs. The said
                enhancement had the effect of taking the total
                reservation under Article 16(4) to 65%.
patil-sachin.
::: Uploaded on - 27/06/2019                       ::: Downloaded on - 28/06/2019 05:25:25 :::
                                  380                             Marata(J) final.doc
                808          It needs no emphasis to say that the
                principle aim of Article 14 and 16 is equality and
                equality of opportunity and that Clause (4) of Article
                16 is but a means of achieving the very same
                objective. Clause (4) is a special provision - though
                not an exception to Clause (1). Both the provisions
                have to be harmonised keeping in mind the fact that
                both are but the restatements of the principle of
                equality enshrined in Article 14. The provision under
Article 16(4) - conceived in the interest of certain
                sections of society - should be balanced against the
                guarantee of equality enshrined in Clause (1) of
Article 16 which is a guarantee held out to every
                citizen and to the entire society. It is relevant to point
                out that Dr. Ambedkar himself contemplatedDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                reservation being "confined to a minority of seats"
                (See his speech in Constituent Assembly, set out in
                para 28). No other member of the Constituent
                Assembly suggested otherwise. It is, thus clear that
                reservation of a majority of seats was never
                envisaged by the founding fathers. Nor are we
                satisfied that the present context requires us to
                depart from that concept.
                809. From the above discussion, the irresistible
                conclusion that follows is that the reservations
                contemplated in Clause (4) of Article 16 should
                not exceed 50%.
                810. While 50% shall be the rule, it is necessary
                not to put out of consideration certain
                extraordinary situations inherent in the great
                diversity of this country and the people. It might
                happen that in far-flung and remote areas the
                population inhabiting those areas might, on
                account of their being out of the main stream of
                national life and in view of conditions peculiar to
                and characteristical to them, need to be treated in
                a different way, some relaxation in this strict rule
                may become imperative. In doing so, extreme
                caution is to be exercised and a special case made
                out.
patil-sachin.
::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:25 :::
                                    381                             Marata(J) final.doc
                 Our       attention     was   invited     to     the       relevant
observation in paragraph no.807 by Shri Dada where it is
observed that "though it is not possible to accept the theory
of proportionate representation, though the proportion of
population of the backward classes of the total population
would certainly be relevant".                  Emphasis is also laid onDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

observations in para 810 which contemplate extra-ordinary
situations.
                 It    would    also     be    appropriate        to     reproduce
paragraph no.859:
                 859.       We may summarise our answers to the
                 various   questions dealt with  and   answered
                 hereinabove:
                (1)       .....
                (6)(a)&(b) The reservations contemplated in
                Clause (4) of Article 16 should not exceed 50%.
                While 50% shall be the rule, it is necessary not to
                put out of consideration certain extraordinary
                situations inherent in the great diversity of this
                country and the people. It might happen that in
                far-flung and remote areas the population
                inhabiting those areas might, on account of their
                being out of the main-stream of national life and in
                view of the conditions peculiar to and
                characteristic of them need to be treated in a
                different way, some relaxation in this strict rule
                may become imperative. In doing so, extreme
                caution is to be exercised and a special case made
                out.
                860.        For the sake of ready reference, we
                also record our answers to questions as framed by
patil-sachin.
::: Uploaded on - 27/06/2019                      ::: Downloaded on - 28/06/2019 05:25:25 :::
                                 382                            Marata(J) final.doc
                the counsel for the parties and set out in para 681.
                Our answers question-wise are:
                (1) ..........
                (4)    The reservations contemplated in Clause
                (4) of Article 16 should not exceed 50%. While
                50% shall be the rule, it is necessary not to put
                out of consideration certain extraordinary
                situations inherent in the great diversity of this
                country and the people. It might happen thatDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                in far-flung and remote areas the population
                inhabiting those areas might, on account of
                their being out of the main-stream of national
                life and in view of the conditions peculiar to
                and characteristic of them need to be treated
                in a different way, some relaxation in this strict
                rule may become imperative. In doing so,
                extreme caution is to be exercised and a
                special case made out.
                For applying this rule, the reservations should
                not exceed 50% of the appointments in a
                grade, cadre or service in any given year.
                Reservation can be made in a service or
                category only when the State is satisfied that
                representation of backward class of citizens
                therein is not adequate.
                To the extent, Devadasan           is    inconsistent
                herewith, it is over-ruled.
                (5) There is no constitutional bar to
                classification of backward classes into more
                backward and backward classes for the
                purposes of Article 16(4). The distinction
                should be on the basis of degrees of social
                backwardness. In case of such classification,
                however, it would be advisable-nay, necessary
                - to ensure equitable distribution amongst the
                various backward classes to avoid lumping so
                that one or two such classes do not eat away
                the entire quota leaving the other backward
                classes high and dry.
patil-sachin.
::: Uploaded on - 27/06/2019                  ::: Downloaded on - 28/06/2019 05:25:25 :::
                                   383                             Marata(J) final.doc
                For excluding 'creamy layer', an economic
                criterion can be adopted as an indicium or
                measure of social advancement.
144              Further in the said decision, S. Ratnavel Pandian, J.
while concurring has observed thus :
                183.         As to what extent the proportion ofDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                reservation will be so excessive as to render it bad
                must depend upon adequacy of representation in
                a given case. Therefore, the decisions fixing the
                percentage of reservation only upto the maximum
                of 50% are unsustainable. The percentage of
                reservation at the maximum of 50% is neither
                based on scientific data nor on any established
                and agreed formula. In fact,Article 16(4) itself
                does not limit the power of the Government in
                making the reservation to any maximum
                percentage; but it depends upon the quantum of
                adequate representation required in the Services.
                In this context, it would be appropriate to recall
                some of the decisions of this Court, not agreeing
                with Balaji as regards the fixation of percentage of
                reservation.
                184.          The question of percentage of
                reservation was examined in Thomas wherein
                Fazal Ali, J not agreeing with Balaji has observed
                thus:
                      ".... clause (4) of Article 16 does not fix
                      any limit on the power of the Government
                      to make reservation. Since Clause (4) is a
                      part of Article 16 of the Constitution it is
                      manifest that the State cannot be allowed
                      to indulge in excessive reservation so as
                      to defeat the policy contained in Article
                      16(1). As to what would be a suitable
                      reservation within permissible limits will
                      depend upon the facts and circumstances
                      of each case and no hard and fast rule
                      can be laid down, nor can this matter be
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:25 :::
                                    384                            Marata(J) final.doc
                      reduced to a mathematical formula so as
                      to be adhered to in all cases. Decided
                      cases of this Court have no doubt laid
                      down that the percentage of reservation
                      should not exceed 50%. As I read the
                      authorities, this is, however, a rule of
                      caution and does not exhaust all
                      categories. Suppose for instance a StateDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                      has a large number of backward classes
                      of citizens which constitute 80% of the
                      population and the Government, in order
                      to give them proper representation,
                      reserves 80% of the jobs for them, can it
                      be said that the percentage of reservation
                      is bad and violates the permissible limits
                      of Clause (4) of Article 16? The answer
                      must necessarily be in the negative. The
                      dominant object of this provision is to take
                      steps to make inadequate representation
                      adequate."
          185.       Krishna Iyer, J in the same decision has
          agreed with the above view of Fazal Ali, J stating
          that "...the arithmetical limit of 50% in any one
          year set by some earlier rulings cannot perhaps
          be pressed too far." (SCC p.371, para 143).
           186.      Though Mathew, J. did not specifically
           deal with this maximum limit of reservation,
           nevertheless the tenor of his judgment indicates
           that he did not favour 50% rule.
           187.     Chinnappa Reddy, J in Karamchari case
           has expressed his view on the ceiling of
           reservation as follows:
                         ".... There is no fixed ceiling to
                         reservation or preferential treatment in
                         favour of the Scheduled Castes and
                         Scheduled Tribes though generally
                         reservation may not be far in excess of
                         fifty percent. There is no rigidity about
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:25 :::
                                    385                            Marata(J) final.doc
                         the fifty percent rule which is only a
                         convenient guideline laid down by
                         Judges. Every case must be decided
                         with reference to the present practical
                         results yielded by the application of the
                         particular rule of preferential treatmentDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                         and not with reference to hypothetical
                         results which the application of the rule
                         may yield in the future. Judged in the
                         light of this discussion I am unable to
                         find anything illegal or unconstitutional
                         in any one of the impugned orders and
                         circulars...."
                188.         Again in Vasanth Kumar, Chinnappa
                Reddy, J reiterates his view taken in Karamchari in
                the following words:
                         "We must repeat here, what we have
                         said earlier, that there is no scientific
                         statistical data or evidence of expert
                         administrators who have made any
                         study of the problem to support the
                         opinion that reservation in excess of 50
                         per cent may impair efficiency."
                189.           I fully share the above views of Fazal
                Ali, Krishna Iyer, Chinnappa Reddy, JJ holding that
                no maximum percentage of reservation can be
                justifiably fixed under Articles 15(4) and/or 16(4) of
                the Constitution.
                190.        It should not be out of place to recall
                the observation of Hegde, J in Hira Lal observing
                [SCC p.572, para 8]
                         "The extent of reservation to be made is
                         primarily a matter for the State to decide.
                         By this we do not mean to say, that the
                         decision of the State is not open to judicial
                         review.... The length of the leap to be
                         provided depends upon the gap to be
                         covered. (emphasis supplied)
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:25 :::
                                   386                           Marata(J) final.doc
145                  Justice P. B. Sawant, J. while concurring with the
majority view has held that clause (4) of Article 16 is not anDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

exception to clause (1) thereof and even if assuming that it is
an exception, there is no numerical relationship between the
rule and its exception and their respective scope depends of
the areas and situations they cover and how large the areas
of exception will be, would depend on the circumstances of
each case.             Their Lordships held that legally it cannot be
insisted that exception will cover not more than 50% of the
area covered by the rule. It is further clarified that clause (4)
even if it is held as an exception to clause (1), it has no
bearing on the percentage of reservations to be kept under it.
Quoting Justice Hegde in State of Punjab Vs. Hiralal 30,
"The length of the leap to be provided depends upon the gap
to be covered," he concluded that in Article 16(4), there is no
indication of the extent of reservation that can be made in
favour          of    backward   classes.    However,        the      object       of
reservation being to ensure adequacy of representation,
serves as a guide for percentage of reservation to be kept and
broadly speaking the adequacy of representation in the
services will have to be proportionate to the portion of the
30 1971 SCR (3) 267
patil-sachin.
::: Uploaded on - 27/06/2019                   ::: Downloaded on - 28/06/2019 05:25:25 :::
                                 387                            Marata(J) final.doc
backward classes in the total population.                       It is further
conclusively held that if reservation is to be on the basis ofDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

proportion of the population in this country, the backward
classes being no less than 77 - one half% (socially and
educationally backward classes and SC and ST taken together,
the total reservation will have to be to that extent. It is not
disputed that the present reservation of the Scheduled Caste
and Scheduled Tribe is in proportion to their population.
                 Justice Savant further observed :
                 "What was in the mind of the Constitution-framers was
                 the removal of the inadequacy in representation over a
                 period of time, on each occasion balancing the
                 interests of the backward classes and the forward
                 classes so as not to affect the provisions of equality
                 enshrined in Articles 14 and 16(1) as also the interests
                 of the society as a whole. As pointed out earlier, Dr
                 Ambedkar was not only not in favour of proportional
                 representation but was on the contrary, of the firm view
                 that the reservations under Article 16(4) should be
                 confined to the minority of the posts/appointments. In
                 fact, as the debate in the Constituent Assembly shows
                 nobody even suggested that the reservations under
Article 16(4) should be in proportion to the population
                 of the backward classes.
                 506.        While deciding upon a particular percentage
                 of reservations, what should further not be forgotten is
                 that between the backward and the forward classes,
                 there exits a seizable section of the population, who
                 being socially not backward are not qualified to be
                 considered as backward. At the same time they have
                 no capacity to compete with the forwards being
                 educationally and economically not as advanced. Most
                 of them have only the present generation acquaintance
                 with education. They are, therefore, left at the mercy
patil-sachin.
::: Uploaded on - 27/06/2019                  ::: Downloaded on - 28/06/2019 05:25:25 :::
                                  388                            Marata(J) final.doc
                 of chance-crumbs that may come their way. They have
                 neither the benefit of the statutory nor of theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                 traditional in-built reservations on account of the
                 unequal social advantages.          It is this section
                 sandwiched between the two which is most affected by
                 the reservation policy. The reservation percentage has
                 to be adjusted to meet their legitimate claims also.
                  518.        To summarise, the question may be
                  answered thus. There is no legal infirmity in keeping
                  the reservations under clause (4) alone or under
                  clause (4) and clause (1) of Art. 16 together,
                  exceeding 50%. However, validity of the extent of
                  excess of reservations over 50% would depend upon
                  the facts and circumstances of each case including the
                  field in which and the grade or level of administration
                  for which the reservation is kept. Although, further,
                  legally and theoretically the excess of reservations
                  over 50% may be justified, it would ordinarily be wise
                  and nothing much would be lost, if the intentions of
                  the Framers of the constitution and the observations of
                  Dr. Ambedkar on the subject in particular, are kept in
                  mind.     The reservations should further be kept
                  category and gradewise at appropriate percentages
                  and for practical purposes the extent of reservations
                  should be calculated category and gradewise.
146              The afore-extracted passages from the majority
judgment in Indra Sawhney undisputedly lead to a conclusion
that there is no constitutional bar to the reservation exceeding
more than 50%. Articles 15 and 16 of the Constitution of India
and more particularly Articles 15(4) and 16(4) being the
enabling         provisions    for     advancement       of     socially        and
educationally backward class of citizens and the power
exercised by the State, in this regard, is to be circumscribed in
patil-sachin.
::: Uploaded on - 27/06/2019                   ::: Downloaded on - 28/06/2019 05:25:25 :::
                                389                            Marata(J) final.docDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

limited sphere of judicial review, in order to test the bonafides
of State.        The judgment of Indra Sawhney read in its proper
perspective and in benevolence of advancing cause of the
weaker sections under Articles 15 and 16 the Constitution
does not impose any fetter on State's power to exceed
reservation more than 50% in a deserving case.                           This is
however, subject to the State providing valid justification in
exceeding the limit of 50%. No provision of the Constitution,
and in particular Articles 15 and 16, impose any restriction on
the extent of reservation. There is a reference in Article 16(4-
B) to 50% limit but, that is restricted to promotions per year.
The ratio of the majority judgment binds us and we need not
refer to the minority view.          The Judgments of the Apex Court
and the High Courts make reference to the percentage of
reservation. The ratio of Indra Sawhney has not been
disturbed, modified or reversed by any other judgment.
Obviously, the judgment in Indra Sawhney is a seven Judges
has been constituted to consider the issues. It is also required
to be noted that the minority judgment of the Supreme Court
need not be referred to, since what is binding upon the High
Court is the majority view. Reading of the majority view and
concurring views of the said judgment would divulge that 50%
patil-sachin.
::: Uploaded on - 27/06/2019                 ::: Downloaded on - 28/06/2019 05:25:26 :::
                                390                            Marata(J) final.docDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

ceiling limit has been accepted as a rule but the majority view
also contemplated certain extra-ordinary situations inherited
in the great diversity in this country and its people and this
was illustrated in form of "far flung and remote area" where
population inhabiting those areas might on account of their
being within the main stream of national life and conditions
peculiar to them need to be treated in a different way. It was
thus accepted that such a contingency may call for some
relaxation.           However, in expressing so, word of extreme
caution was also expressed and categorically it was ruled that
unless and until a specific case is made out, imperative nature
of the rule shall not be diluted. We are therefore, inclined to
accept the submission by             the learned Senior Counsel Shri
Rohatgi that though 50% ceiling/cap has been imposed on the
power of the State to exercise its enabling power, the State is
not denuded in exercising the discretion in exceeding the
ceiling limit in extra-ordinary situations and exceptional
circumstances. Whether the State has been able to make its
case fall within its newly opened window, is to be determined
by us which we will be dealing at a later point.
patil-sachin.
::: Uploaded on - 27/06/2019                 ::: Downloaded on - 28/06/2019 05:25:26 :::
                                         391                          Marata(J) final.doc
147              True that, between the judgment delivered by theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Constitution          Bench        in   Balaji   (supra)    and      in     judgment
delivered by the 9 Judges Bench in Indra Sawhney (supra),
another Constitution Bench found in its way in State of
Kerala & Anr vs. N.M. Thomas & Ors31, while determining
the validity of Rule 13(AA) which empowered the State
Government to                  exempt for a specified period, members of
Scheduled Caste and Scheduled Tribe already in service from
passing the test, the purport of Article 14 and Article 14 was
once again scrutinized and this time, in the backdrop of Article
335, CJ Ray, as His Lordships was, then analyzed the scheme
of Article 14, 15 and 16 threadbare and held it to be formed
part of the Constitution creating rights, supplementing each
other. Article 16 which ensured to all the citizens equality of
opportunity in the matters relating to employment, was held
to be independent of guarantee of equality contained in
Article 14.           It was also held that equality under Article 16
could not have a different content from equality under Article
14 and Article 16(1) is affirmative, whereas Article 14(1) is
construed in negative language but ultimately, Article 16(4)
indicates one of the methods of achieving equality embodied
31 1976 AIR 490,
patil-sachin.
::: Uploaded on - 27/06/2019                        ::: Downloaded on - 28/06/2019 05:25:26 :::
                                      392                         Marata(J) final.doc
in Article 16(1).                The concept of equality was furtherDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

elaborated in the backdrop of Article 16(1) and 16(4) in the
following paragraphs :-
                28       This equality of opportunity need not be
                confused with absolute equality. Article 16(1) does not
                prohibit the prescription of reasonable rules for
                selection to any employment or appointment to any
                office. In regard to employment, like other terms and
                conditions associated with and incidental to it, the
                promotion to a selection post is also included in the
                matters relating to employment and even in regard to
                such a promotion to a selection post all that Article
                16(1) guarantees is equality of opportunity to all
                citizens. Articles 16(1) and (2) give effect to equality
                before law guaranteed by Article 14 and to the
                prohibition of discrimination guaranteed by Article
                15(1). Promotion to selection post is covered by Article
                16(1) and (2).
                  The rule of equality within Articles 14 and 16(1)
was held to be not violated by a rule which will ensure
equality of representation in the services for unrepresented
classes after satisfying the basic needs of efficiency of
administration.                Justice Mathew described the concept of
'Equality of Opportunity' contemplated under Article 16(1) as
an aspect of the more comprehensive notion of equality. He
elaborated the said concept in the following paragraphs
                81      Article 16(1) is only a part of a comprehensive
                scheme to ensure equality in all spheres. It is an instance
                of the application of the larger concept of equality under
                the law embodied in Articles 14 and 15. Article 16(1)
                permits of classification just as Article 14 does [see S. G.
patil-sachin.
::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:26 :::
                                   393                            Marata(J) final.doc
                Jaisinghani v. Union of India & ors.(2), State of Mysore &Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                Anr. v. P. Narasing Rao(3) and C. A. Rajendran v. Union of
                India & Ors.(4).]. But, by the classification, there can be
                no discrimination on the ground only of race, caste and
                other factors mentioned in Article 16(2)
148               Justice Krishna Iyer described equal justice as an
aspect of social justice, the salvation of the very weak and
down-trodden, and held that the methodology for levelling
them up to a real, not formal, is the goal.                       His Lordship
described Article 46 and 336 being testament and Articles 14
to 16 being the tool-kit.           In paragraph no.129, he deduced
certain clear conclusions of great relevance in the following
manner :
                 129          Now we may deduce from these and other
                 like Articles, unaided by authority, certain clear
                 conclusions of great relevance to the present case: (1)
                 The Constitution itself demarcates Harijans from others.
                 (2) This is based on the stark backwardness of this
                 bottom layer of the community. (3) The differentiation
                 has been made to cover specifically the area of
                 appointments to posts under the State. (4) The twin
                 objects, blended into one, are the claims of harijans to
                 be considered in such posts and the maintenance of
                 administrative efficiency. (5) The State has been
                 obligated to promote the economic interests of harijans
                 and like backward classes, Arts. 46 and 335 being a
                 testament and Arts. 14 to 16 being the tool-kit, if one
                 may put it that way. To blink at this panchsheel is to be
                 unjust to the Constitution.
                 If Art. 14 admits of reasonable classification, so does Art.
                 16(1) and this Court has held so. In the present case,
                 the economic advancement and promotion of the claims
                 of the grossly under-represented and pathetically
patil-sachin.
::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:26 :::
                                 394                             Marata(J) final.docDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                neglected classes, otherwise described as Scheduled
                Castes and Scheduled Tribes, consistently with the
                maintenance of administrative efficiency, is the object,
                constitutionally sanctioned by Arts. 46 and 335 and
                reasonably accommodated in Art. 16(1). The differentia,
                so loudly obtrusive, is the dismal social milieu of
                harijans. Certainly this has a rational relation to the
                object set out above. I must repeat the note of caution
                earlier struck. Not all caste backwardness is recognised
                in this formula. To do so is subversive of both Art. 16(1)
                and (2). The social disparity must be so grim and
                substantial as to serve as a foundation for benign
                discrimination. If we search for such a class, we cannot
                find any large segment other than the Scheduled Castes
                and Scheduled Tribes. Any other caste, securing
                exemption from Art. 16(1) and (2), by exerting political
                pressure or other influence, will run the high risk of
                unconstitutional discrimination. If the real basis of
                classification is caste masked as backward class, the
                Court must strike at such communal manipulation.
                Secondly, the Constitution recognizes the claims of only
                harijans (Art. 335) and not of every backward class. The
                profile of Art. 46 is more or less the same. So, we may
                readily hold that casteism cannot come back by the
                backdoor and, except in exceptionally rare cases, no
                class other than harijans can jump the gauntlet of 'equal
                opportunity' guarantee. Their only hope is in Art. 16(4). I
                agree with my learned brother Fazal Ali J. in the view
                that the arithmetical limit of 50% in any one year set by
                some earlier rulings cannot perhaps be pressed too far.
                Overall representation in a department does not depend
                on recruitment in a particular year, but the total
                strength of a cadre. I agree with his construction of Art.
                16(4) and his view about the 'carry forward' rule.
149              In words, Justice Fazal Ali, the doctrine contained in
Article 16 is a hard and reeling reality, a concrete and
constructive concept and not a rigid rule or an empty formula.
According to him, Article 16 is merely an incident of Article 14,
Article 14 being the genus is of universal application, whereas
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                   ::: Downloaded on - 28/06/2019 05:25:26 :::
                                  395                          Marata(J) final.doc
Article 16 is the species and seeks to obtain equality of
opportunity in the services under the State.                   According to
Justice Fazal Ali, the         only manner in which the objective of
equality as contemplated by the founding fathers of the
Constitution and as enshrined in Articles 14 and 16 can be
achieved is to boost up the backward classes by giving them
concessions, relaxations, facilities, removing handicaps, and
making suitable reservations so that the weaker sections may
compete with the advanced class and in due course of time
all may become equals and backwardness is banished for
ever.           Justice Fazal Ali, however, did not agree that an
arithmetical limit of 50% set by some earlier rulings is the final
word.
                  It is to be noted that the view point expressed by
Justice Krishna Iyer and Justice Fazal Ali was appropriately
deciphered and given due consideration by majority view in
case of Indra Sawhney (supra), to which we have already
referred to above. In any contingency, the Constitution Bench
has added a further adage in the form of extra-ordinary
situation is the verdict of a larger Bench and prevails as on
date.
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                 ::: Downloaded on - 28/06/2019 05:25:26 :::
                                       396                           Marata(J) final.doc
150              A perusal of the subsequent judgment in case of N.
Nagaraj & Ors Vs. Union of India 32 reiterates the said
position.        The Constitution Bench in Nagaraj was confronted
with the Constitution (Eighty-Fifth Amendment] Act, 2001
inserted          Article 16(4) of the Constitution retrospectively
providing          reservation        in    promotion    with       consequential
seniority and the same was challenged as unconstitutional
and violative of the basic structure. The argument canvassed
was that the Parliament appropriated the judicial power to
itself and has acted as an appellate authority by reversing the
judicial pronouncement of the Court by the use of power of
amendment, and therefore, it is violative of the basic
structure.           It was also argued that it also altered the
fundamental right of equality which was part of the basic
structure of the Constitution. According to the petitioners, the
consequences              of   85th    Amendment        which       provided          for
reservation           and      promotion,      would     result        in     reverse
discrimination in the percentage of reservation in the reserved
category.
151              Apart from examining the said contention on a
broader canvas of whether the basic structure of the
32 2006 (8) SCC 212
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                       ::: Downloaded on - 28/06/2019 05:25:26 :::
                                397                         Marata(J) final.doc
Constitution was infringed by the said amendment, the
Constitution Bench dealt in detail the ambit and scope of
Article 16(4A), it also dealt with the extent of reservation. The
problem as to what should be basis of distribution was
approached with the three criteria to judge the basis of
distribution and these three criteria were put under                       two
concepts of equality, formal equality and proportional equality.
Formal equality was described to mean that the law treats
everyone equal and does not favour anyone, whereas concept
of proportional equality expect the State to take affirmative
action in favour of disadvantaged sections of the society
within the framework of liberal democracy.
152              It was held that Article 16(1) cannot prevent the
State from taking cognizance of the compelling interest and
the earlier position of Article 16(4) being read as an exception
to 16(1) was clarified in Indra Sawhney and the position which
emerges is that Article 16(1) and 16(4) are restatements of
principles of equality under Article 14 and equality in Article
16(1) is individual - specific whereas reservation in Article
16(4) and 16(4A) is an enabling power. It also held that the
word "nothing in this article" in Article 16(4) represents a legal
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019              ::: Downloaded on - 28/06/2019 05:25:26 :::
                                     398                             Marata(J) final.doc
device allowing the discrimination in favour of a class and it
creates a field which enables the State                          to provide for
reservation where it is satisfied on the basis of quantifiable
data that there exists backwardness of a class and inadequacy
of representation in employment and these are considered to
be compelling reasons which do not exist in Article 16(1). The
Apex        Court,        therefore,      formulated     existence           of     two
circumstances              i.e.   'backwardness'       and     'inadequacy             of
representation'. It held that backwardness has to be based on
effective factors whereas 'inadequacy' has to factually exist.
153               Justice S.H. Kapadia (as he was then) in M. Nagaraj
identified the limitation on the power available to the State
under 16(4A) and 16(4B) viz. (1) The ceiling limit of maximum
50% reservation (quantitative limitation) (2) The principle of
creamy layer (qualitative exclusion) (3)                        The compelling
reason          for   exercise      of    power   i.e.   backwardness               and
inadequacy of representation and (4) Overall administrative
efficiency as required by Article 335. The Constitution Bench
observed thus :-
                123     However, in this case, as stated, the main issue
                concerns the "extent of reservation". In this regard the
                concerned State will have to show in each case the
                existence   of  the    compelling    reasons,    namely,
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                       ::: Downloaded on - 28/06/2019 05:25:26 :::
                                   399                             Marata(J) final.doc
                backwardness, inadequacy of representation and overall
                administrative efficiency before making provision for
                reservation. As stated above, the impugned provision is an
                enabling provision. The State is not bound to make
                reservation for SC/ST in matter of promotions. However if
                they wish to exercise their discretion and make such
                provision, the State has to collect quantifiable data
                showing backwardness of the class and inadequacy of
                representation of that class in public employment in
                addition to compliance of Article 335. It is made clear that
                even if the State has compelling reasons, as stated above,
                the State will have to see that its reservation provision
                does not lead to excessiveness so as to breach the ceiling-
                limit of 50% or obliterate the creamy layer or extend the
                reservation indefinitely.
                  Our attention was specifically invited by Mr.Rohatgi
in paragraph no.58 where Their Lordships proceeded to
observe that in Indra Sawhney, majority held that 50% was a
binding rule and not a mere rule of prudence. Shri Rohatgi
attempted to canvass that Indra Sawhney itself carve out a
window for exceptional circumstances and extra-ordinary
situation and he would submit that paragraph no.58 is not the
sole spirit of the judgment but the entire permissibility of
exceeding the reservation of 50% is further highlighted in the
subsequent paragraphs and para 58 cannot be thus read in
isolation. The respective counsel for the State have heavily
relied upon a judgment in case of S.V. Joshi Vs. State of
Karnataka (supra) which is delivered by Three Judges Bench
of the Apex Court where the window opened by Nagaraj was
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:26 :::
                                   400                            Marata(J) final.doc
carried forward while determining whether the quantum of
reservation provided for in Tamil Nadu Backward Classes,
Scheduled Caste and Scheduled Tribes (reservation of seats in
educational institutions and of appointments or posts in the
services under the State) Act of 1993 is valid. The Court, after
taking note of the Constitution (93 rd Amendment Act 2005)
and Constitution (81st Amendment Act 2000) which were
subject matter of Nagaraj and Ashok Kumar Thakur Vs. Union
of India which had laid down the position of law that if the
State wants to exceed 50% reservation, then it is required to
base its decision on quantifiable data. The Court proceeded to
observe that this exercise was not undertaken by State of
Tamil Nadu and therefore, direction was issued to the State to
place the quantifiable data before the Tamil Nadu State
Backward Classes Commission and on the basis of such
quantifiable data, the Commission was directed to decide the
quantum of reservation. As far as the State of Karnataka was
concerned whose enactment was subject to scrutiny since it
provided         for     reservation    exceeding    50%       in    matter         of
admission to educational institutions and recruitment to
service, the State was cautioned that it should be guided in its
decision by Nagaraj and Ashok Kumar Thakur (supra). Time
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:26 :::
                                      401                              Marata(J) final.doc
was granted to the State Government to take appropriate
decision and it was held that the reservation exceeding 50%
would be permissible only on the basis of quantifiable data,
placed before the Government since no such data was
collected or presented to the Court.
154               The subsequent judgment in case of Jarnail Singh
Vs.Lachhmi Narain Gupta,33 disclose that the Constitution
Bench was constituted to determine the issue of reservation
in promotion with consequential seniority for Scheduled Caste
and Scheduled Tribes under Article 16(4A) and 16(4B) and to
determine whether three pre-conditions laid down in Nagaraj
and the obliteration of creamy layer requirement in case of
Scheduled Caste and Scheduled Tribes for reservation need to
be referred to a larger Bench.                    The first test of collecting
quantifiable data on backwardness insofar as Scheduled Caste
and Scheduled Tribes are concerned, were held to be contrary
to the judgment in case of Indra Sawhney and was struck
down to that extent. The principle laid down in M. Nagaraj
which           had   left     the   test   for   determining         adequacy           of
representation in promotional post to the State, it was clarified
33 2018(10) SCC 306
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                         ::: Downloaded on - 28/06/2019 05:25:26 :::
                                402                          Marata(J) final.doc
that efficiency of administration should be ensured since that
was a third factor laid down in Nagaraj.                 Ultimately, the
decision in E. V. Chinnaiah (supra) came to be clarified and it
was held that Chinnaiah dealt with a completely different
problem and not a constitutional amendment and therefore,
the reference to a larger bench was totally unwarranted. In
any contingency, this referred to the Scheduled Caste and
Scheduled Tribes. However, as far as Other Backward Classes
are concerned, the three guiding principles laid down in Nagraj
remained untouched and reference to larger Bench was held
unwarranted.
155              Recently, the Rajasthan High Court, Jaipur bench in
case of Captain Gurvinder Singh Vs State of Rajasthan 34
had an opportunity to deal with a similar situation wherein the
State Government enacted the Rajasthan Special Backward
Class (Reservation of Seats in Educational Institutions) in the
State and appointments and post in Services under the State)
Act, 2015, on the basis of report submitted by the Other
Backward Commission recommending 5 castes as Special
Backward Classes with 5% reservation and sought to shift
these five castes from Backward classes to Special Backward
34 CWP 1645/2016
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019               ::: Downloaded on - 28/06/2019 05:25:26 :::
                                      403                             Marata(J) final.doc
Classes. The allegation of the petitioners was that the State
Government somehow wanted to provide 5% reservation to
Gurjars/Gujars and other castes on account of the Statewide
agitation launched by them for their inclusion in the category
of Scheduled Tribe.
                 Strong        reliance    has     been     placed        on      these
judgments by the learned senior counsel Shri Aney appearing
for the petitioner. The Division Bench was called up to answer
the challenge to the reservation which was crossing the ceiling
of 50%. After making a detail reference to the judgment of
M.R. Balaji (supra) and the judgment in case of N. Nagaraj,
the Division Bench examined the report of the Commission on
its merit.        By citing instances demonstrating perversity and
inadequacy in the report which recommended for reservation
beyond 50% by carving out a new category for those who are
already getting benefit of reservation for past many years, the
Division Bench held that no extra-ordinary circumstances exist
to provide 5% reservation.                   The report was said to be not
based on quantifiable data.
                 The said judgment can be distinguished from the
facts which we are dealing since the Division of Rajasthan
High       Court        did    not    find     a   case     of     'extra-ordinary
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                        ::: Downloaded on - 28/06/2019 05:25:26 :::
                                       404                              Marata(J) final.doc
circumstances' being made out to justify exceeding the ceiling
of 50% as the report did not place any quantifiable data and
therefore, according to the Division Bench, the special case as
set out in Indra Sawhney was not made out and the Court
quashed the report of the Commission itself along with the
impugned enactment.
156              Reliance was also placed on the interim order
passed by this Court on an earlier occasion when the earlier
Ordinance          and         the   Enactment   of     2015        providing         16%
reservation          to        Maratha   community        was       challenged           on
somehow similar grounds.                     The observations made by a
Bench headed by the Hon'ble Chief Justice Mohit Shah (as he
was then) are prima facie in nature and were made on interim
deliberations, nonetheless, the Special Leave Petition assailing
the said judgment delivered on 14 th November 2014 has been
dismissed.          The Division Bench           extensively dealt with the
plethora of judgments touching the issue of ceiling of 50% and
it has in extenso referred to the observations of the Apex
Court in Indra Sahwney.                  The Division Bench though made a
reference to S.V. Joshi Vs. State of Karnataka and Rohtas
Bhankar Vs. Union of India, it brushed aside the exercise
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                          ::: Downloaded on - 28/06/2019 05:25:26 :::
                                405                         Marata(J) final.doc
undertaken in S.V. Joshi's case on the ground that the said
judgment was not merely concerned with reservation of posts/
vacancies in public employment but also with reservation of
seats in educational institutions and in this judgment, the
Apex Court did not purport to modify the law laid down in M.
Nagaraj, but rather directed the State to follow the law and
refer to the principles laid down regarding inter alia, collection
of quantifiable data. The Division Bench therefore, reiterated
that 50% is the ceiling limit but it also observed that the
ceiling limit cannot exceed in absence of any quantifiable
data. The said observations of the Division Bench no longer
hold good since the restriction now gets watered down since
the State has asserted the compelling reasons in view of
quantifiable data demonstrating backwardness of the class
and inadequacy of representation in addition to compliance in
Article 335 for maintenance of administrative efficiency.
157              Reliance is placed by Shri Datar on the judgments
of the Andhra Pradesh High court in case of B. Archana
Reddy and ors Vs State of Andhra Pradesh 35. The Andhra
Pradesh High court was dealing with the reservation of seats
35 2005 (6) ALT 364
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019              ::: Downloaded on - 28/06/2019 05:25:26 :::
                                406                       Marata(J) final.doc
in the educational institutions and of appointments/posts in
the public services under the State to Muslim community
Ordinance 2005 (Ordinance No.13 of 2005). The most
important question that fell for consideration was whether
Muslim community as a community can be declared socially
and educationally backward for the purposes of Article 15 and
16. The larger bench also deliberated as to whether there was
relevant and scientific material before the Commission to
come to a conclusion that Muslim community in Andhra
Pradesh were, as a community backward, socially and
educationally and how far can the Court go into analyzing the
material which was collected by the Commission. Acting Chief
Justice Bilal Nazki, as his Lordship was then, writing for himself
and on behalf of Justice R Subhash Reddy did not agree with
the remaining 2 Judges i.e. Justice Raghuram and Justice V.Rao
and held that in light of the earlier Five Judges Bench of the
same Court held that Muslims can be declared a community
to be a backward class. The judgment also commented on the
report of the Commission and according to Justice Nazki, the
report of the Commission could not have accepted to form an
opinion that Muslim community, as a whole, in State of Andhra
Pradesh is a backward community in the light of the
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019            ::: Downloaded on - 28/06/2019 05:25:26 :::
                                    407                                 Marata(J) final.doc
parameters laid down in the Mandal Commission case. After
carefully analyzing the report of the Commission and the
scope of judicial review, a finding was ultimately recorded that
the identification was done on a defective criteria, which is
unscientific and which do not indicate as to whether Muslim
community, as a whole, is backward or not and therefore the
Ordinance was quashed.
                 Justice Raghuram approached the question from a
different angle and as regards the first issue as to whether
declaration of a Muslim community residing in the State of
Andhra Pradesh as backward class and their inclusion in the
list of backward class is sustainable in light of law declared in
Indra Sawhney and also whether it is violative of Article 14, 15
and 16 of the Constitution. It was held that quotas even for
affirmative action predicated on religion basis alone derogate
the human dignity of all to whom they are applied, positively
or negatively. It was also held that relevant criteria, adequate
and probative data must exist to sustain a conclusion for
backwardness              of   class   (social   and/or         educational)           and
adequacy of data justifies the satisfaction of backwardness
and       states      conclusion       based     on     illusory       or     irrelevant
information or data would compel a judicial determination.
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                          ::: Downloaded on - 28/06/2019 05:25:26 :::
                                           408                           Marata(J) final.doc
Resultantly, it was held that the entire exercise undertaken by
the Commission and its conclusion fell foul of the impregnable
constitutional           norm        of    classification    in    identifying          and
classifying the backward classes. It was further held that in
treating the backward class of Muslims in the State of Andhra
Pradesh and the other Muslims as an integral homogeneous
social class,           as     the    basis     for its     entire     exercise,         the
Commission was led into a fatal error and the entire exercise
was in futility. Resultantly, the Ordinance based on the report
of the Commission met with the same fate in the judgment of
Justice Nazki. The point of excess reservation as a proposition
of law evolving from the said judgment needs to be read and
referred to in light of the aforesaid factual and legal situation
emerging out of the said judgment. After finding fault with the
report of the Commission which identified Muslims as the
backward class, thereby increasing the reservation from 46%
to 51%, the judgment proceeds to observe that the excess 1%
do not fall within that "extra-ordinary situation" carved out in
Indra Sawhney and then the observation of 1% (excess) was
propounded and it was held that the reservation though
exceeding by 1%, is not tolerable relaxation but we will have
to keep in mind the observations in the backdrop of the entire
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                           ::: Downloaded on - 28/06/2019 05:25:26 :::
                                       409                            Marata(J) final.doc
gamut of the facts and law evolved in the said judgment and
when the Ordinance itself providing for 5% reservation came
to be quashed on being held that the identification of the
community itself was unsustainable in the fabric of the
Constitution, we do not think that the said judgment can be
accepted as a proposition as to what has been sought to be
propounded by Shri Datar.
                 We are therefore, inclined to hold that it is
ultimately the State on whom the burden is cast to justify the
excess reservation and since the 50% ceiling limit is not
exhaustive of all the categories. As Justice Jeevan Reddy has
expressed in the majority view that the extent of reservation
depends upon the proportion of backward classes to the total
population and their representation in public services.                             It is
also by now settled that backwardness being ia relative term,
it must be judged by the general level of advancement of the
entire population of the country or the State, as the case may
be, and therefore, determination of backwardness is best left
to the respective State.                Once the State forms an opinion
about the backwardness of a community and has before it, the
data       depicting           that   the   said   community/class             is     not
adequately represented in the services in the State and
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                        ::: Downloaded on - 28/06/2019 05:25:26 :::
                                   410                               Marata(J) final.doc
requires        an affirmative action,            it would       determine           the
quantum of reservation to this class in form of a quota. The
extra-ordinary situations contemplated by Indra Sawhney
were       not     exhaustively     set     out   but    none        the     less,        it
contemplated             the   conditions    of    a    class      peculiar         and
characteristical which may prove a justification for relaxation
of strict rule.           The view of the majority judgment in Indra
Sawhney is concurred by Justice Ratnavel Pandian by making
reference to the observations of Justice Fazal Ali,                            Justice
Krishna Iyer and Justice Chinnappa Reddy holding that no
maximum percentage of reservation can be justifiably fixed
under Article 15(4) and/or Article 16(4) of the Constitution.
Justice Savant concurring in unequivocal terms hold that the
validity of the extent of excess of reservation over 50% would
depend upon the facts and circumstances of each case,
including the field in which and the grade or level of
administration for which the reservation is made. Ultimately,
in Nagaraj, the Apex Court has expressed that in a given case,
an appropriate Government is free to provide reservation
where it is satisfied on the quantifiable data of backwardness
and inadequacy of representation of a community. All these
factors are context specific and there cannot be any fixed
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                       ::: Downloaded on - 28/06/2019 05:25:26 :::
                                        411                              Marata(J) final.doc
yardstick and the exercise of the power of the State can be
examined by the Court in exercise of its power of judicial
review and the State would then be required to justify the
existence           of         compelling      reasons      i.e.      backwardness,
inadequacy           of        representation    and     overall       administrative
efficiency. In light of the aforesaid parameters which we have
derived from the series of judgments to which we have
referred, we now proceed to determine whether extra-ordinary
circumstances or exceptional situations have been brought
forth by the state of Maharashtra in bringing the impugned
legislation.
(VIII)          Whether            extra-ordinary          circumstances                  or
exceptional situations as spelled out in Indra Sawhney
are made out by the State in providing reservation for
Maratha community by the impugned legislation.
158              The issue that arise for our consideration is,
therefore, whether there exists extra-ordinary circumstances
which would justify the dilution of the principle of 50% ceiling
limit in favour of the Maratha community and as to whether
the      State       has        been    able    to   establish         extra-ordinary
circumstances classifying Maratha as a separate class.
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                           ::: Downloaded on - 28/06/2019 05:25:26 :::
                                       412                         Marata(J) final.doc
159                When a reservation policy of State is challenged,
several           factors      need   consideration   and       they      can       be
enumerated as follows :
            (i)     The Constitutional limits within which the State
                    action may be pursued such as the explicit or
                    clearly implied constitutional prohibition as to
                    classificatory parameters
            (b) The relevance or rationality of the criteria adopted
                    by the State constituted commission or an expert
                    body entrusted by the State to undertake the said
                    exercise.
            (c) The adequacy of data considered in the said
                    exercise
            (d) The rationality of the synthesis between the
                    evolved criteria and the collected data for analysis
                    and ;
            (e) The rationality of conclusions arrived at by an
                    expert body resulting into the decision by the
                    State.
160                In Ram Singh Vs. Union of India,36                         Justice
Ranjan Gogoi, the Hon'ble Chief Justice, while dealing with the
notification published in the Gazette of India and examining its
validity, by which the Jat community was included in the
36 2015(4) SCC 697
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:26 :::
                                 413                            Marata(J) final.doc
Central list of backward classes in Bihar, Gujarat, Haryana,
Himachal Pradesh, Madhya Pradesh, NCT of Delhi and                             twoDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

districts of Rajasthan and State of Uttar Pradesh and
Uttarakhand, it observed that the decisions which affect the
right of citizens and specifically based on Articles 14, 16(4)
and 15(4) must be on the basis of contemporaneous inputs
and not outdated antiquated data since one may legitimately
presume progressive advancement of all citizens on every
count i.e. social, economic and political.                    The following
observations made by the Hon'ble Chief Justice aptly provides
the prism through which the whole issue can be examined :-
                54       Backwardness is a manifestation caused by
                the presence of several independent circumstances
                which may be social, cultural, economic, educational
                or even political. Owing to historical conditions,
                particularly in Hindu society, recognition of
                backwardness has been associated with caste.
                Though caste may be a prominent and distinguishing
                factor for easy determination of backwardness of a
                social group, this Court has been routinely
                discouraging the identification of a group as
                backward solely on the basis of caste. Article 16(4)
                as also Article 15(4) lays the foundation for
                affirmative action by the State to reach out the most
                deserving. Social groups who would be most
                deserving must necessarily be a matter of
                continuous evolution. New practices, methods and
                yardsticks have to be continuously evolved moving
                away from caste centric definition of backwardness.
                This alone can enable recognition of newly emerging
                groups in society which would require palliative
                action. The recognition of the third gender as a
                socially and educationally backward class of citizens
patil-sachin.
::: Uploaded on - 27/06/2019                  ::: Downloaded on - 28/06/2019 05:25:26 :::
                                  414                             Marata(J) final.doc
                entitled to affirmative action of the State under the
                Constitution in National Legal Services Authority vs.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                Union of India[8] is too significant a development to
                be ignored. In fact it is a path finder, if not a path-
                breaker. It is an important reminder to the State of
                the high degree of vigilance it must exercise to
                discover emerging forms of backwardness. The
                State, therefore, cannot blind itself to the existence
                of other forms and instances of backwardness. An
                affirmative action policy that keeps in mind only
                historical injustice would certainly result in under-
                protection of the most deserving backward class of
                citizens, which is constitutionally mandated. It is the
                identification of these new emerging groups that
                must engage the attention of the State and the
                constitutional power and duty must be concentrated
                to discover such groups rather than to enable groups
                of citizens to recover "lost ground" in claiming
                preference and benefits on the basis of historical
                prejudice.
161              The most cherished principle of equality embodied
in Article 14 of the Constitution finds place in Chapter III with
its different facet in form of Articles 15 and 16. A duty is cast
on the State to achieve the goal of equality enshrined in
Article 14. Article 15 is thus an instance of right to equality
stated in Article 14. Article 15(4) which begins with the word
"Nothing in this Article" envisages a policy of compensatory
protective discrimination which enables the State in making
any special provision for advancement of any socially and
educationally backward class of citizens or for the Scheduled
Caste and Scheduled Tribes.                 Sub-clause (5) is another
sprawling tenet of equality where it enables the State to make
patil-sachin.
::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:26 :::
                                     415                              Marata(J) final.doc
any special provision, by law, for the advancement of sociallyDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

and educationally backward class of citizens or for the
Scheduled Caste and Scheduled Tribes, insofar as such
provisions relate to their admission to educational institutions.
Article 15(4) confers a discretion and it may not be looked at
as      creating          any     Constitutional     obligation           and        the
Constitutional Court in exercise of writ jurisdiction may not be
persuaded           to    issue   writ    of   mandamus         to    provide         for
reservation.           The enabling power can be exercised by the
State in favour of the socially and educationally backward
classes of citizens or for the Scheduled Caste and Scheduled
Tribes. The latter are recognized by the Constitution itself but
the former are to be identified by the State by the well-known
parameters which are to be found in the Constitution itself,
though ironically the issue as to who are backward classes has
eluded the State and the judiciary equally.                       It is, however,
settled position that the enabling power which is a special
provision and though not looked at necessarily to be an
exception to the guarantee of equality underlying in Article
15(1), a balance should always be struck between the
fundamental rights of other citizens of not to be discriminated
and protection or concession being availed by the weaker
patil-sachin.
::: Uploaded on - 27/06/2019                       ::: Downloaded on - 28/06/2019 05:25:26 :::
                                       416                            Marata(J) final.doc
section. The State must identify the socially and educationallyDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

backward classes and what it contemplated is both social and
educational backwardness of a class. The identification of the
backwardness is a prerogative conferred on the State as
defined in Article 12 and it can then take assistance of the
backward class commission constituted under Article 340 to
investigate the conditions of backward classes.                          This power
exercised by the State is always subject to judicial review and
when it is found that it is not exercised within the four corners
of the Constitutional principles or not based on reasonable
classification, then exercise of such power by the State can
always be struck down as not violative of the Constitutional
mandate.
162              Those who oppose the identification of Maratha
community             as       a   backward   community         and      reservation
provided         to     them        through   the   State      legislation         have
propensely argued that a community which was not backward
for all these years and to be precise in the opinion of two
National Commissions and the earlier State Backward Class
Commissions which did not find sufficient material to identify
them as backward and the presumption being that the
patil-sachin.
::: Uploaded on - 27/06/2019                        ::: Downloaded on - 28/06/2019 05:25:26 :::
                                    417                            Marata(J) final.doc
population of this country is advancing with the country'sDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

advancement and taking the leap forward, how can it be
presumed that a community which was once upon a time
'forward' can be declared as 'backward' by passage of time.
This question is unequivocally raised by all the respective
counsel appearing for the petitioners.
                  In order to enable us to find an answer to this
question, it would be required to refer to the past including the
findings of various Commission which dealt with the aspect of
backwardness of this community. The history disclose that as
early as in 1902 Maratha community was provided the benefit
of reservation by Chhatrapati Shahu Maharaj. It is to be noted
that the census of India 1931 Vol.VIII Part 2 Bombay
Presidency           has       shown   Maratha   community             as      Hindu
Intermediate community. This Hindu Intermediate community
is synonymous with backward classes and we would refer to
para 768 in Indra Sawhney which reads thus :
                "768.         In Bombay province, the Government of
                Bombay, Finance Department Resolution No. 2610 dated
                5.2.1925 defined "Backward Classes" as all except
                Brahmins, Prabhus, Marwaris, Parsis, Banyas and
                Christians. Certain reservations in Government service
                were provided for these classes. In 1930, the State
                Committee noticed the over-lapping meanings attached to
                the expressions "depressed classes" and "backward
                classes" and recommended that "Depressed Classes"
                should be used in the sense of untouchables, a usage
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:26 :::
                                   418                            Marata(J) final.doc
                which "will coincide with existing common practice." TheyDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                proposed that the wider group should be called "Backward
                Classes", which should be subdivided into Depressed
                Classes (i.e., untouchables); Aboriginals and Hill Tribes;
                Other Backward Classes (including wandering tribes). They
                opined that the groups then currently called Backward
                Classes should be renamed "intermediate classes"
Further, the Government of Bombay by its resolution dated
23rd April 1942 classified the intermediate communities and
this included Maratha community at Sr. No.149.                          However,
after this point of time, this community came to be displaced
from the category of backward classes and though most of the
intermediate communities found their way in the list of OBCs,
Kunbi being one of them, Maratha community was excluded.
It do not appear that there was any conscious exercise to
exclude it.          As far as the report of Mandal Commission is
concerned, it did not focus particularly on Maratha community
and rather, broadly dealt and recognized the backward clases
qua the respective States. A request was therefore, made for
inclusion of the Maratha community which is a synonym of
'Kunbi' in the central list of backward classes and the National
Commission for Backward Classes report submitted on 22 nd
February 2000 has been strongly relied upon by Shri Talekar.
The Member Secretary of the NCBC has submitted this report
after analyzing the request received by the Commission from
patil-sachin.
::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:26 :::
                                    419                            Marata(J) final.doc
the Akhil Bharatiya Maratha Mahasangh.                     The claim at theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

relevant time was submitted making a request for inclusion of
Marathas along with the Kunbis in the list of backward classes
on the ground that Marathas are originally Kunbis. The Two
Member Maharashtra Bench of the Commission consisting of
Shri P.S. Krishnan, Member Secretary and Shri Sahu Akshay
Bhai held public meetings and this hearing was attended by
Justice         Shri   S.N.    Khatri,   Chairperson     of    MSBCC.             The
Commission took note of the fact that 'kunbi' is included in the
Mandal, State and the first phase central list of backward
classes for Maharashtra. The Commission made reference to
the Maharashtra District Gazetteers of districts like Nagpur,
Parbhani, Aurangabad, Sangli and Thane as well as Amravati
and Wardha and it recorded a finding that Maratha is not one
and the same as Kunbi but rather it constitutes a separate and
distinct class/community though they originated from Kunbi.
A distinction is then sought to be drawn between these two
castes with reference to its communal practices.                          The two
Member Commission then observed that a community whose
close association is with the ruling classes and which has
enjoyed important economic and political rights and positions
of power and influence and which eventually became rulers
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:26 :::
                                420                         Marata(J) final.doc
cannot be said to have suffered any social disadvantages.                        ItDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

also noted that numerous Chief Ministers from this community
never made this demand and conclusively in light of the fact
that Maratha is not a synonym of Kunbi, it did not recommend
its inclusion in the list of backward classes. This finding is not
based on any quantifiable data and/or any material on record.
A general perception which prevailed in respect of Maratha
community was a basis for rejecting the demand for inclusion
of this class into the list of Other Backward Class. The said
inclusion was, therefore, not rejected on basis of any
contemporaneous or quantifiable data or any in-depth study
of the social and educational        status of the said community
but it was only rejected on the ground of its classification
earlier as 'forward community' in the past and it bears no
semblance with 'Kunbi' which had already found its way in the
Other Backward Class list. We, therefore, conclude that the
two Member Commission did not analyse the status of this
Community, social, educational and economical and merely
because minuscule members of this community have reached
the upper strata of the society and were in controlling position
and even gained a political placement was the broad rationale
for not conferring the benefit on the entire community.
patil-sachin.
::: Uploaded on - 27/06/2019              ::: Downloaded on - 28/06/2019 05:25:26 :::
                                421                          Marata(J) final.docDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

163               We then turn to the reports of the Commissions
constituted by the State specifically Khatri Commission and
the Bapat Committee report where attempt was made by
these Commissions to assess the social status of this class.
Perusal of the reports would divulge that the report placed
before us           no way indicate that this class has progressed
socially and educationally in the subsequent years. The Bapat
Commission report which was submitted in the year 2008 is
carefully perused by us which disclose that the Committee
Members had factually visited various villages in different
districts and the members who visited, for example, Professor
Dr. Anuradha Bhoite, who visited and carried out the survey in
Satara district has observed that the lower strata of Maratha
community are extremely poor and leading a life of distress
and they need a helping hand for their upliftment. Same is
the observation in respect of the Kolhapur district. Professor
D.K. Gosavi who was also part of the Commission and
participated in the survey conducted in several villages in
Beed,           Nanded, Latur districts, also recommended that in
North Maharashtra, the entries of caste recorded in the year
1917-1927 are 'kunbi'. However, subsequently, the Maratha
patil-sachin.
::: Uploaded on - 27/06/2019               ::: Downloaded on - 28/06/2019 05:25:26 :::
                                  422                              Marata(J) final.docDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

community considered it to be a matter of inferiority to record
such a caste and thereafter, subsequent to 1994-95, the
entries of Kunbi were deleted. The said Member has also
recorded that the community comprises of members who are
unemployed and like any other community, it is stratified into
lower, middle and higher middle class.                    In conclusion, the
member           has       recommended    that      the      whole         Maratha
community cannot be declared as Other Backward Class but
the lower strata of the society which is economically backward
needs some protection.                 Another Member Shri Laxman
Gaikwad on the basis of his survey has highlighted the
deplorable status of Marathas in rural areas and he has clearly
observed that the Maratha community residing in villages is
extremely          backward,    economical       and      they       have       been
deprived of their agricultural yields and most of them worked
in fields owned by others. He categorically makes a reference
to Latur from where one of the Chief Ministers of Maharashtra
comes and record that this is also no exception. He has also
state that in Usmanabad, there is a mixture of political
leaders, sugarcane cultivators and the extreme poverty of
Maratha community deserve them a reservation in OBC. The
member suggested that the OBCs would also be adversely
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:26 :::
                                        423                            Marata(J) final.docDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

affected         and       he    recommended         that      though          Maratha
community needs some reservation for their advancement but
that should be done without placing them in the OBC category.
                 This Commission was not however, a statutory
Commission             since     the    MSBCC      Act    2005       came        to     be
implemented only in the year 2009. Thus, this report in fact is
in favour of inclusion of Maratha in OBC but the final decision
by way of voting is contrary as pointed out by the learned
senior counsel Shri Vineet Naik. We have therefore, perused
the individual reports of the members and except the dissent
note of Shri Devgaokar and Shri Deshpande, the other
members            have         supported    the     backwardness              of      the
community. Anyhow, the report was not based on any data on
educational backwardness and inadequacy of representation
but was rather a fact finding/field survey report depicting the
situation of Maratha community.
                 It was after this report and coming into force of the
MSBCC Act of 2005, Rane Committee came to be appointed to
procure quantifiable data pertaining to the social, educational
and       economic             backwardness     of       the    community             and
inadequacy of the representation in State public services.
patil-sachin.
::: Uploaded on - 27/06/2019                         ::: Downloaded on - 28/06/2019 05:25:26 :::
                                         424                            Marata(J) final.docDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

This resulted into the Ordinance 2014 which was replaced by
ESBC Act of 2015.
                 It can thus be seen that the claim of Maratha
community was never deeply gone into and on the other
hand, the fact finding disclose the social status of this
community. As far as the earlier reports are concerned, we
have noted that none of the reports had empirical data before
it and it therefore, cannot stand the scrutiny of classifying
Maratha as not backward.                      We would curiously refer to the
reports, which would disclose that it is for the first time in form
of Gaikwad Commission the quantifiable data has been
collected and in terms of Nagaraj, the quantifiable data.
inadequacy of representation are two key factors which would
permit exceeding of reservation of 50% by the State.
                 The erroneous exclusion of the Maratha community
from       reservation         itself    contribute    to    the      extra-ordinary
situation that this community without determination of its
backwardness was kept out of the benefits conferred on the
backward classes though the kunbi community which is
identically placed in social scenario since ages, finds its place
in the list of Other Backward Classes on recommendation of
Mandal Commission.                 This contribute as one of the extra-
patil-sachin.
::: Uploaded on - 27/06/2019                          ::: Downloaded on - 28/06/2019 05:25:26 :::
                                  425                         Marata(J) final.docDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

ordinary circumstance when the State attempts to do away
the injustice caused to this community which has been
completely kept out of any benefits approximately Seven
decades after the concept of backwardness was introduced
and still continues to remain backward.
164              The tabular form reproduced below would indicate
the manner in which the various commissions dealt with the
Maratha community and as to why the findings of the earlier
Committee/Commissions will not preclude the claim of the
community being once again considered by the MSBCC based
on the quantifiable data.
 Sr. Commissio                 Modalities adopted and Method
 No n Report                             undertaken
  1      Kalekar   No sample survey was carried out and no
       Report-1955 representative data.
                   No quantifiable data pertaining to social,
                   educational and economic backwardness and
                   inadequacy of representation in government
                   services.
                   No criteriawise marks allotment.
                   No State averages compared for any of the
                   class or community.
                   No ascertainment of backwardness for each
                   Class/community.
                   Social backwardness proclaimed on the basis
                   of perceptions and personal knowledge.
                   Arbitrary listing of castes and communities as
                   backward and inadequately represented.
                   Maratha categorized as backward class and
                   included in the list of Vidarbha and
                   Marathwada regions.
patil-sachin.
::: Uploaded on - 27/06/2019                ::: Downloaded on - 28/06/2019 05:25:26 :::
                                        426                            Marata(J) final.docDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                               Reservation in services recommended ot the
                               extent of 62.5%.
                               Reservation in education recommended to the
                               extent of 70%.
                               All the women from all classes in the country
                               identified as backward class for reservation.
 2     Deshmukh                Appointed for the purpose of reservation in
       Committee-              services only.
       1964                    No sample survey was carried out and no
                               representative data.
                               No quantifiable data pertaining to social,
                               educational and economic backwardness and
                               inadequacy of representation in government
                               services.
                               No criteria wise marks allotment.
                               No State averages compared for any of the
                               class or community.
                               No ascertainment of backwardness of any
                               Class/community.
                               No ascertainment of backwardness of any
                               Class/community.
                               No list of backward classes or communities
                               given.
                               Catogarisation of all backward classes into
                               four categories-1. SC and Neo Buddhists, 2.
                               ST, 3. VJNT and 4. OBC.
                               Reservation percentage of each category
                               recommended in proportion to its population.
 3     Mandal                  At the beginning of the its working, Mandal
       Commission              divided the population of the country into
       -1980                   backward and non backward without going
                               into investigation and identification.
                               The so called non-backward segment excluded
                               completely from its further consideration.
                               The data of public employment sought
                               collectively for the so called backward castes/
                               communities       without     identification of
                               backwardness at the beginning of its work and
                               list of backward castes prepared at the end.
                               No sample survey was carried out and no
                               representative data collected.
                               No quantifiable data pertaining to social,
                               educational and economic backwardness and
                               inadequacy of representation in government
                               services.
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                         ::: Downloaded on - 28/06/2019 05:25:26 :::
                                        427                            Marata(J) final.doc
                               11 Criteria of backwardness applied to any of
                               the caste or communities.
                               No criteria of backwardness applied to any of
                               the caste or communities.
                               No criteria-wise marks allotment for any of the
                               castes or communities.
                               No State averages compared for any of the
                               castes or communities.
                               No ascertainments of backwardness for any or
                               the caste or communities.
                               Social backwardness proclaimed on the basis
                               of perceptions and personal knowledge.
                               Arbitrary listing of castes and communities as
                               backward and inadequately represented.
                               Maratha mentioned under the heading of
                               forward Hindu castes and communities for the
                               purpose of deriving OBC population.
                               No mention of a single fact or figure that
                               Marartha were not socially, educationally and
                               economically and economically backward and
                               inadequately represented.
                               Mandal recommended review of its entire
                               scheme after 20 years.
 4     NCBC- 2000              No sample survey was carried out and no
                               representative data.
                               No quantifiable data pertaining to social,
                               educational and economic backwardness and
                               inadequacy of representation in government
                               services.
                               No criteria-wise marks allotment to Maratha
                               community.
                               No State averages compared for ascertaining
                               backwardness Maratha community.
                               No ascertainment of backwardness of Maratha
                               community.
                               Social backwardness rejected on the basis
                               irrelevant citations pertaining to 3 centuries
                               ago.Only issue of whether Maratha Kunbi are
                               one and the same was referred.
                               Arbitrary rejection of backwardness of
                               Maratha community and stating it as
                               advanced community without any fact, figure
                               or particulars or recored.
                               Only tow meetings in Mumbai with a few
                               representatives held for understanding the
                               issue.
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                         ::: Downloaded on - 28/06/2019 05:25:26 :::
                                        428                            Marata(J) final.doc
                               Conclusions drawn at the whims and fancies.
                               Total report of 25 pages without any table and
                               annexure.
                               No scientific data analysis of Maratha
                               community.
                               No investigation and no proper identification.
 5     Khatri      Entire report is 10 pages without any
       Commission annexure or table.
       Report-2001 No sample survey was carried out and no
                   representative data collected.
                   No quantifiable data pertaining to social,
                   educational and economic backwardness and
                   inadequacy of representation in government
                   services.
                   8 Criteria prepared but none applied for
                   ascertaining     backwardness     of  Maratha
                   community.
                   No criteria wise marks allotment.
                   No State averages compared.
                   Final conclusions were drawn in absence of
                   the chairman and recommendation were
                   made without validation by the chairman.
                   Government accepted this incomplete report
                   and included Maratha Kunbi and Kunbi
                   Maratha in the list of OBC as a part of Kunbi
                   Caste at Sr. no 83.
 6     Bapat       No quantifiable data pertaining to social,
       Commission educational and economic backwardness in
       Report-2008 government services.
                   10 Criteria prepared but not applied for
                   ascertainment of backwardness of Maratha
                   community.
                   No criteriawise marks allotted to Maratha
                   community.
                   No State averages compared to te3st any
                   parameter.
                   Total report is of 5 pages without any
                   annexure, tabulation or analysis.
                   No data collected to examine the
                   backwardness and inadequacy of
                   representation.
                   4 out 5 members concluded their field
                   observation reports stating that Mratha andDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

patil-sachin.
::: Uploaded on - 27/06/2019                         ::: Downloaded on - 28/06/2019 05:25:26 :::
                                         429                           Marata(J) final.doc
                               Kunbi are socially one and the same and
                               submitted hundreds of valid caste certificates
                               and record of marriages inter se Maratha and
                               Kunbi.
                               2 of the members of the commission
                               submitted       their    independent      note
                               recommending inclusion of Maratha into OBC
                               as a apart of Kunbi caste at Sr. no 83.
                               Final conclusions were drawn on the basis of
                               political method of voting on a negative
                               resolution without giving notice to all
                               members and without giving notice to all
                               members and without considering the written
                               submission of absent member.
                               The member who did not do any field survey
                               and who did not submit any written opinion
                               and who was appointed at the time of last
                               meeting only, voted against the reservation
                               for Maratha community.
 7     Rane                    Not a statutory Committee
       Committee               Compiled quantifiable data
                               Identified     Maratha      community                 as
                               educationally and socially backward
165              In the backdrop of the long drawn demand of the
Maratha community for conferment of benefits and its specific
assertion         that         though    this   community        is    socially       and
educationally backward, it was deprived from the fruits of any
form of concessions being conferred by the State, and the
earlier Commissions not taking into consideration the factual
scenario, the State decided to appoint the backward class
commission under the Chairmanship of Justice Gaikwad to
determine the contemporary criteria and parameters to be
adopted in ascertaining the social, educational and economicDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

patil-sachin.
::: Uploaded on - 27/06/2019                         ::: Downloaded on - 28/06/2019 05:25:27 :::
                                430                           Marata(J) final.doc
backwardness for availing the benefits of reservation                           in
conformity with the Constitutional mandate.                  The terms of
reference also directed the Committee to scrutinize and
inspect the quantifiable and other data collected by the State
Government and the State and National Commissions for
backward classes and to determine the representation of the
Community in public employment and educational sector. The
Terms of Reference also directed to ascertain the proportion of
population of Maratha community in the State on the basis of
records, reports, census and other available data.
                 The commission, in its report, in Chapter IV has set
out in detail the procedure and investigation carried out by it
and in Chapter VII makes a reference to the quantifiable
evidence of backwardness in social, educational and economic
form. The report of the Commission in Chapter IX also focus
on the inadequacy of Marathas in the services under the
State.
                 The commission in terms of the Second term of
reference has defined the exceptional circumstances and/or
extra-ordinary situations necessitating crossing of the ceiling
limit of 50% while conferring the benefit of reservation on the
Maratha community in the present context, which it culled outDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

patil-sachin.
::: Uploaded on - 27/06/2019                ::: Downloaded on - 28/06/2019 05:25:27 :::
                                      431                           Marata(J) final.doc
on the basis of the material collated by it.                    The Committee
also had before it the opinions of the organizations of
Backward Classes, including the organizations of Maratha
community and it also dealt with the apprehension raised by
the      organization          of   backward    classes     that      if    Maratha
community is included in the OBC, after                         recognizing its
backwardness, the existing backward classes would be
required to share their quota of 19% and resultantly, they
would suffer huge injustice.                   The Committee, therefore,
proceeded to deal with this extra-ordinary situation.                            After
analyzing the Constitutional scheme and keeping in mind the
ceiling for total reservation of 50% as laid down in case of
Indra Sawhney and also keeping in mind the word of extreme
caution while exceeding the ceiling limits, the Commission has
ascertained the 'extra-ordinary circumstances'.
                 The quantifiable data collected by the Committee
based on the census of the year 2011 where population of the
Scheduled Caste and Scheduled Tribes in State of Maharashtra
is recorded as 11.81% and 9.35% respectively, the Committee
fell back on the socio economic caste census conducted by
the State of Maharashtra through Gokhale Institute of Politics
and Economics, Pune. The said survey report has calculatedDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

patil-sachin.
::: Uploaded on - 27/06/2019                      ::: Downloaded on - 28/06/2019 05:25:27 :::
                                432                           Marata(J) final.doc
the percentage of Maratha community with Kunbi community
as 35.7% and percentage of all the reserved Backward Classes
to be 48.6%. The percentage of other classes of population
who have not disclosed their caste have been shown to be
15.7%. The Commission therefore concludes that though the
survey report relates to rural area, the total percentage of
existing backward classes, Maratha and kunbi, who claim to
be backward comes to 48.6% + 35.7%, equivalent to 84.3% of
the total population. The Commission has also made a
reference to the census of the year 1872 which calculates the
population of Shudras          and the census report of 1872 from
which the position emerge that more than                 80% population
was found backward in the census of 1872. The commission
categorizes this as an extra-ordinary situation since the
majority of the unequals are living with the minority of the
equals.         The figures available on record on the basis of 2011
census disclose that the State population is about 11.24 crores
out of which 3,68,83,000 is the population of OBC (VJNT, OBC
SBC)            The statistics of Ministry of Social Justice and
Empowerment, Government of India has given the State wise
percentage of OBCs in India and for Maharashtra it is 33.8%
whereas SC-ST is 22%.                The Gaikwad commission hasDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

patil-sachin.
::: Uploaded on - 27/06/2019                ::: Downloaded on - 28/06/2019 05:25:27 :::
                                433                        Marata(J) final.doc
therefore deduced that the population of Marathas is 30%.
Therefore, in terms of the population, if we look at the figures
then the situation which emerges is that almost 85% of the
population is of the backward classes and to suggest that if
85% of people are backward and they get only a reservation
of 50%, it would be traversity of justice. When we speak of
equality - equality of status and opportunity, then whether
this disparity would be referred to as achieving equality is the
moot question. The situation of extra-ordinary circumstances
as set out though by way of illustration in Indra Sawhney
would thus get attracted and the theme of the Indian
Constitution to achieve equality can be attained. Once we
have accepted that the Maratha community is a backward
class, then it is imperative on the part of the State to uplift the
said community and if the State does so, and in extra ordinary
circumstances, exceed the limit of 50%, we feel that this is an
extra ordinary situation to cross the limit of 50%.
                 The Maratha community post the Constitution of
India coming into force, has never enjoyed any concession or
privilege in form of reservation.      Its counterpart like Kunbi
caste and contemporaries like Mali, Dhangar, already made
their way in the list of backward classes prepared by State ofDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

patil-sachin.
::: Uploaded on - 27/06/2019             ::: Downloaded on - 28/06/2019 05:25:27 :::
                                  434                         Marata(J) final.doc
Maharashtra.               It is not disputed by anyone that this
community is mostly the agricultural community and the
social status of the agricultural community is well known and
specially, of the marginal farmers who could barely manage to
stay alive. The community faces a peculiar situation where on
account of its educational backwardness, the youth of this
community is not in a position to compete with the open
category candidates on merits for securing public employment
and in absence of they enjoying any concession or privilege
find themselves distanced from the Other Backward Classes.
Inspite of their proven and factual social and educational
backwardness, they are perforced to compete with the open
category candidates and cannot withstand them and this is
apparent from their poor performance.             The social status of
Maratha community is further deteriorating on account of the
agrarian crisis and absence of any advancement on economic
and educational front. The perception that this community is
forward and affluent no longer factually exists and inspite of
the brave front on part of this community, their present
situation is aptly described in Ethnographic Appendices to Sir
H.H. Risley's India Census Report of 1901 in the following
words :Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

patil-sachin.
::: Uploaded on - 27/06/2019                ::: Downloaded on - 28/06/2019 05:25:27 :::
                                     435                            Marata(J) final.doc
                 "What little display his means afford a Maratha still tries
                to maintain. Though he may be clad in rags at home, he
                has a spare dress which he himself washed and keeps
                with great care and puts on when he goes to pay a visit.
                He will hire a boy to attend him with a lantern at night, or
                to take care of his shoes when he goes to his friend's
                house and hold them before him when he comes out.
                Well to do Marathas are usually in their service a
                Brahman clerk known as 'divanji' who often take
                advantage of his master's want of education to defraud
                him".
The Maratha community which is awarded weightage of 21.5
marks out of 25 by the Commission is identified as socially
and educationally backward in light of it having obtained 90%
of the total weightage. The social status of the community is
very well depicted in the report of the Commission and we do
not find any arbitrariness or excessiveness in the report of the
Commission which, according to us, is based on a ground level
survey of the members of the community mostly from rural
area where this community is predominantly found. The
educational status of the community is highly deplorable andDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

is    well      brought        before   us   through    the     report       of     the
patil-sachin.
::: Uploaded on - 27/06/2019                      ::: Downloaded on - 28/06/2019 05:25:27 :::
                                    436                               Marata(J) final.doc
Commission.              Same is the situation about the economic
condition of the community.                   The report of the Gokhale
institute on suicide of the farmers including the Marathas is
self eloquent about its status.                  The inadequacy of the
Marathas in service is also brought on record through its well
researched survey.              In light of the yardsticks applied, the
Commission             has     conclusively    held     that      the        Maratha
community is socially and educationally backward. The core
issue before the Commission was to tackle with the extra-
ordinary situation which has developed in the State after
recording that 30% of the population of State is Maratha and it
was thus imperative for the State to focus on their needs and
it was duty bound to take steps for removal of disparity and
backwardness of this community.                  After declaring the said
community as backward and after recording a finding that
about 85% of the population of the State is backward, the
Commission had to address itself as to how justice can be
done to everyone and it has arrived at the following solution
which we reproduce as under :-
                 320 After        declaring    Marathas          a      socially,
                 educationally and economically backward class
                 of the citizens the total percentage of the State
                 population entitled to the Constitutional benefitsDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

patil-sachin.
::: Uploaded on - 27/06/2019                      ::: Downloaded on - 28/06/2019 05:25:27 :::
                                          437                            Marata(J) final.doc
                 and advantages as listed under the Article 15(4)
                 and the Article 16(4) will be around 85%
                 (21.16%            SCs and STs + 13% Vjs/Nts/SBCs+
                 20% already listed OBCs + proposed 30%
                 Maratha population community). Additionally, a
                 Minority group of citizenry (Muslims, Christians,
                 Jains) having a state population share of around
                 10/11% (After reducing the strength of around
                 50 Castes like groups already included in the
                 State OBC list) are clamoring for their inclusion
                 in the OBC category leaving only 4%-5% forward
                 class population out of reservation fold. Now to
                 address and accommodate the constitutionally
                 admissible claims for the reservations, being
                 falling       in     entitlement     zone        is     herculean
                 impossibility. This is a compelling extra ordinary
                 situation demanding extra ordinary solution
                 within the Constitutional frame.
                  321               Added to that the judicial verdicts
                  have         categorically        pronounced          that        the
                  reservation policy frame and Constitutional
                  mandate           as    regards    SCs     and       STs     is    so
                  sacrosanct that there is no need of any
                  quantifiable data or its verification whatsoever
                  deemed to have been "Given". It has also to be
                  in proportion to their population needing no
                  distinction to be made as regards "adequate"
                  vis-a-vis "proportionate" as to be done in case
patil-sachin.
::: Uploaded on - 27/06/2019                           ::: Downloaded on - 28/06/2019 05:25:27 :::
                                          438                              Marata(J) final.doc
                  of reservations to other backward class of
                  citizens. Therefore, the scenario that emerges
                  would be to accommodate remaining 63% (85%
                  - 22%) backward class population in remaining
                  29%          (50   -    21)      reservation       allocation        asDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                  conditioned by the ceiling 50%. If in future the
                  claim of Minorities is conceded (which is
                  presently          sub       judice)    it    will      mean          to
                  accommodate around 73% backward class of
                  the State population within 29% reservation
                  quota.        This is yet another facet of the extra
                  ordinary situation and exceptional circumstance
                  emerging in the State"
 166             The       other         crucial     aspect     is     regarding           the
quantifiable data about the public employment.                                 Under this
subhead,          it is observed by the Commission that at present
strength of State Public Employment is around 14,00,000,
which is available to 11.24 crores population of the State,
which proportion comes to 1.24% jobs per hundred youth. If
computed against the eligible youth, population which is found
to be 27% of the State population as per latest figure, it gets
converted into 4.62% jobs per hundred youth.                                 It is further
observed that the average recruitment per year is not more
than 5% in the State. Therefore, 5% of the 4.62% jobs per
patil-sachin.
::: Uploaded on - 27/06/2019                             ::: Downloaded on - 28/06/2019 05:25:27 :::
                                 439                            Marata(J) final.doc
hundred youth gets translated to 0.23%, that is almost less
than one job per hundred eligible youth. Now in this scenario,
there is 50% reservation in matter of public employment,
which further brings the number down to 0.12% and this is the
percentage which will be available for 95% population and the
remaining 0.12% would be available for remaining 5% forwardDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

class youth.
167              The aforesaid data reflect the availability of jobs for
youth and also raises a question as to if the said statistics is
accepted, then, where would the youth belonging to Maratha
community which is 30% in the State of Maharashtra finds a
chance to get an employment.              The data collected by the
Commission clearly reflect that the Maratha community is
engaged mostly in agricultural occupation but wherever this
community has moved to the city like Bombay, it has found its
employment only in form of Mathadi Hamals, Dabbewalas and
the women creed being engaged as domestic workers.                             The
report from the Maharashtra State Labour Commissioner on
Mathadi-Hamals has established that out of total Mathadi-
Hamals who are registered with Labour Commissioner, the
percentage of Marathas is 43% and 33% belong to Muslim
patil-sachin.
::: Uploaded on - 27/06/2019                  ::: Downloaded on - 28/06/2019 05:25:27 :::
                                      440                                Marata(J) final.doc
community.             There cannot be any doubt about the socio
economic and educational status of those who are working as
Mathadi Hamals and the survey of Gokhale Institute has made
available the quantifiable data about this community.                                   The
Gokhale Institute has also conducted a study of domestic
workers, house maids in the year 2015 in the area of Pune andDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Pune Chinchwad Municipal Corporation and it has recorded
that this includes large part of Maratha community women.
The report on sugarcane cutters is also one significant report
before the Commission.                 The study carried out at 10 sugar
factories reveal that sugarcane cutters belonging to Beed,
Dhule, Ahmednagar, Jalgaon, Nandurbar and Aurangabad
largely comprise of Marathas and Vanjara communities which
is a migrant population. There can also be no quarrel about
the social status based on the economical earnings of this
class of people.               The data placed before the Commission
disclose that 85% segment of Maratha community has an
annual average income per family less than Rs.25,000/- and
this     figure      itself    is   sufficient   to     indicate        the     financial
backwardness of the community.                        This financial distress is
probably one of the major factor which has contributed to
large number of suicides of farmers and since it is largely the
patil-sachin.
::: Uploaded on - 27/06/2019                           ::: Downloaded on - 28/06/2019 05:25:27 :::
                                    441                            Marata(J) final.doc
Kunbis and Marathas who were the cultivators, the proportion
of suicides of farmers from this community, the percentage is
higher being agriculturist and with the sizable decrease in the
holding of the land, the non-irrigated holding being as large as
82% coupled with the poor quality of soil are some of the
factors         which      have   contributed   to    the      suicides        beingDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

committed on account of agrarian crisis and the major chunk
is of Maratha.
                 The situation, therefore, which emerges is that the
earlier generation of the community has with great efforts
trying to clinch on to their traditional occupation of farming in
spite of the major agrarian crisis whereas the younger
generation is finding its way into the cities.                     However, on
account of the lower educational levels and the scarcity of
availability of jobs, they are constrained to take up the
occupations            like    working   as   Hamals,      entering         in     the
Dabbewala chain prominent in the city of Bombay and other
inferior and ancillary jobs.             Hence, we have before us a
community which is conclusively established to be backward
and has reached its Nadir on account of their economic
distress and the State in its enabling power is duty bound to
lead a helping hand to this community in exercise of the duty
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:27 :::
                                    442                              Marata(J) final.doc
cast upon it in light of the directive principles of the State
policy. The prime question, therefore, is when the State has
identified this community as backward on all fronts, i.e. social,
economic and educational, can the State turn a blind eye to
their      demand          to   claim    certain   concessions          which        are
otherwise available to number of communities residing in theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

State only on the ground that ceiling of 50% would not permit
the State to do so. It is the duty of the State to promote with
special care the educational and economic interest of the
weaker section of the people and to protect them from social
injustice and all forms of exploitation.                It is also a bounden
duty of a State under Article 38 of the Constitution to strive to
promote the welfare of its people by securing and protecting
as effectively as it made a social order in which justice, social,
economic and political can be achieved. It is also a duty of
the State to minimize the inequalities in income and
endeavour to eliminate inequalities in status, facilities and
opportunities not only amongst individuals but group of people
engaged in different vocations.                If in exercise of this duty
which is enjoined on the State, the State makes a sincere
attempt to achieve such a social order ensuring welfare of a
section of people, can it be not said that the situation
patil-sachin.
::: Uploaded on - 27/06/2019                       ::: Downloaded on - 28/06/2019 05:25:27 :::
                                   443                             Marata(J) final.doc
prevalent in State of Maharashtra and the endeavour of the
State to take steps for upliftment of Maratha community falls
within the exceptional and extra-ordinary circumstances.
Accommodating the said community in the list of Other
Backward Classes of the State which have been held entitled
for a quota of 19% under the two legislations framed by theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

State would really be a chaotic situation. This would not only
hit the Other Backward Classes adversely but it would also in
a sense literally uproot them since the Other Backward Class
community            is    enjoying   the   benefit   of     reservation          and
unfortunately that day has not yet come when it can be said
that they have relieved themselves of backwardness and have
been really brought on par with the upper class of the society.
The situation that emerges is that the Maratha community
suffers from a double jeopardy, in spite of the proven social
and             educational       backwardness,            historically           and
contemporarily, they are perforced to compete with the open
category candidates and do not fare well. The social status of
this community is on the decline on account of its economic
and educational backwardness and on account of the fact that
no benefit has ever being conferred on them leading to a
situation that they are left to themselves and their outburst
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:27 :::
                                444                           Marata(J) final.doc
has been witnessed by the State in form of participation in
agitations and various dharnas/morchas which were taken out.
The State is, therefore, attempting to derive a solution which
is in the interest of Other Backward Classes and also the
Maratha community which is nothing else but an Other
Backward Class. The visible biggest inequality perpetuating inDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

State Public Employment compels the State to ensure that the
existing scenario is not disturbed, but at the same time, the
large backward class of Marathas having estimated population
of 30% is also conferred with the benefit of Article 15(4) and
16(4). The wrong done to the community can only be righted
by classifying them as a distinct class from the OBC and
ensuring them a separate quota of reservation so that the
OBCs with the quota of 19% who are themselves struggling,
do not get disturbed.          The very inability of the Marathas to
stand in with the open category candidates who are otherwise
socially, educationally and economically better placed, would
then be taken care of and this would gain them an entry into
the main stream of life and avail an opportunity to overcome
the backwardness with which they are struggling and by
availing the opportunity, they would progress further. This can
only be done by crossing the limit of 50% ceiling on account of
patil-sachin.
::: Uploaded on - 27/06/2019                ::: Downloaded on - 28/06/2019 05:25:27 :::
                                445                      Marata(J) final.doc
extra-ordinary situations created in the State.                  We are
conscious that mere agitations or demands by a particular
community may not be a justiciable reason for the State to
exceed the limit of 50%. However, we have noted that here
is a community who on the basis of quantifiable and
contemporary data, is entitled to be classified as a separateDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

class and the State has taken necessary steps for its social
advancement and also provided it an adequate representation
in the posts in the State by taking affirmative steps in exercise
of its enabling power. This peculiar situation has given rise to
an extra-ordinary scenario which the State has strived to deal
with in exercise of its enabling power so as to achieve the
primary goal of equality for all its citizens. The Commission,
has collected and collated the data and placed it before the
State so as to enable it to invoke its enabling power, and
particularly when the Commission has arrived at a conclusion
that 80% to 85% of population in the State of Maharashtra is
backward and accommodating this population within a ceiling
limit of 50% will be injustice to the identified backward classes
and it will also frustrate the very purpose of the reservation
policy, the State has taken steps to deal with the situation
through the impugned legislation.
patil-sachin.
::: Uploaded on - 27/06/2019           ::: Downloaded on - 28/06/2019 05:25:27 :::
                                   446                             Marata(J) final.doc
168              Justice A.P. Sen in K.C. Vasanth Kumar Vs. State
of Karnataka has expressed his opinion on the percentage of
reservation by taking into consideration the population and his
opinion reads thus :
                   85.         "In this context, I must point out that theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                   adequacy or otherwise of representation of the
                   backward classes in the services has to be determined
                   with reference to the percentage of that class in the
                   population and the total strength of the service as a
                   whole. The representation does not have to exactly
                   correspond to the percentage of that class in the
                   population; it just to be adequate. Moreover, in the
                   case of services the extent of representation has to be
                   considered by taking into account the number of
                   members of that class in the service, whether they are
                   holding reserved or unreserved posts. I cannot
                   overemphasize the need for a rational examination of
                   the 17 whole question of reservation in the light of the
                   observation made by us. The State should give due
                   importance and effect to the dual constitutional
                   mandates of maintenance of efficiency and the
                   equality of opportunity for all persons. The nature and
                   extent of reservations must be rational and
                   reasonable. It may be, and often is difficult for the
                   Court to draw the line in advance which the State
                   ought not to cross, but it is never difficult for the Court
                   to know that an invasion across the border, however
                   ill-defined, has taken place. The Courts have neither
                   the expertise nor the sociological knowledge to define
                   or lay down the criteria for determining what are
                   'socially and educationally backward classes of
                   citizens' within the meaning of Art 15(4) which
                   enables the State to make 'special provisions for the
                   advancement' of such classes notwithstanding the
                   command of Art. 15(2) that the State shall not
                   discriminate against and citizens on the ground only
                   of religion, race, caste, descent, place of birth,
                   residence or any of them. Art. 340 provides for the
                   appointment of a Commission to 'investigate the
                   conditions of socially and educationally backward
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:27 :::
                                   447                             Marata(J) final.doc
                   classes within the territory of India and the difficulties
                   under     which    they     labour    and    to     make
                   recommendations as to the steps that should be taken
                   by the Union or any State to remove such difficulties
                   and to improve their condition. The state of
                   backwardness of any class of citizens is a fact
                   situation which needs investigation and determination
                   by a fact finding body which has the expertise and theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                   machinery for collecting relevant data. The
                   Constitution has provided for the appointment of such
                   a Commission for Backward Classes by the President
                   under Art. 340 to make recommendations and left it to
                   the State to make special provisions for the
                   advancement of such backward classes. The Court is
                   ill- equipped to perform the task of determining
                   whether a class of citizens is socially and
                   educationally backward. This Court has, however, a
                   duty to interpret the Constitution and to see what it
                   means and intends when it makes provision for the
                   advancement of socially and educationally back- ward
                   classes. In considering this situation then, we must
                   never forget that it is the Constitution we are
                   expounding. Except for this the Court has very little or
                   no function".
169              The State has also taken into account the efficiency
of      administration         while    considering        the       exceptional
circumstances. The next point to which we would refer is the
overall efficiency of administration is as highlighted by the
judgment in Nagaraj. In the latest judgment in case of B.K.
Pavitra Vs. The Union of India and ors, (supra) the said
argument has been conclusively dealt with in the backdrop of
the various judgments and we would carefully refer to the said
observations :-
patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:27 :::
                                 448                             Marata(J) final.doc
                 116         Critics of affirmative action programs in
                 government services argue that such programs
                 adversely    impact      the    overall   competence    or
                 ―efficiency of government administration. Critics
                 contend that the only method to ensure ―efficiency in
                 the administration of government is to use a ―meritDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                 based approach - whereby candidates that fulfil more,
                 seemingly ―neutral, criteria than others are given
                 opportunities      in     government       services.   The
                 constitutional justification for this ―efficiency argument
                 is centred around Article 335.
                      ―335. The claims of the members of the
                      Scheduled Castes and the Scheduled Tribes shall
                      be taken into consideration, consistently with the
                      maintenance of efficiency of administration, in
                      the making of appointments to services and posts
                      in connection with the affairs of the Union or of a
                      State:
                      [Provided that nothing in this article shall prevent
                      in making of any provision in favour of the
                      members of the Scheduled Castes and the
                      Scheduled Tribes for relaxation in qualifying
                      marks in any examination or lowering the
                      standards of evaluation, for reservation in
                      matters of promotion to any class or classes of
                      services or posts in connection with the affairs of
                      the Union or of a State.].
                 The proviso was inserted by the Constitution (Eighty-
                 second Amendment) Act 2000.
                 117           The substantive part of Article 335 contains
                 a mandate : a requirement to take into consideration
                 the claims of SCs and STs in making appointments to
                 services and posts in connection with the affairs of the
                 Union or of a State. Consideration is much broader in its
                 ambit than reservation. The consideration of their
                 claims to appointment is to be in a manner consistent
                 with maintaining the efficiency of administration. The
                 proviso specifically protects provisions in favour of the
                 SCs and STs for: (i) relaxing qualifying marks in an
                 examination; (ii) lowering the standards of evaluation;
                 or (iii) reservation in matters of promotion. Reservation
                 is encompassed within the special provision but the
                 universe of the latter is wider.
patil-sachin.
::: Uploaded on - 27/06/2019                   ::: Downloaded on - 28/06/2019 05:25:27 :::
                                 449                             Marata(J) final.doc
                 118         The    proviso   recognizes    that   special
                 measures need to be adopted for considering theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                 claims of SCs and STs in order to bring them to a level
                 playing field. Centuries of discrimination and prejudice
                 suffered by the SCs and STs in a feudal, caste oriented
                 societal structure poses real barriers of access to
                 opportunity. The proviso contains a realistic recognition
                 that unless special measures are adopted for the SCs
                 and STs, the mandate of the Constitution for the
                 consideration of their claim to appointment will remain
                 illusory. The proviso, in other words, is an aid of
                 fostering the real and substantive right to equality to
                 the SCs and STs. It protects the authority of the Union
                 and the States to adopt any of these special measures,
                 to effectuate a realistic (as opposed to a formal)
                 consideration of their claims to appointment in services
                 and posts under the Union and the states. The proviso
                 is not a qualification to the substantive part of Article
                 335 but it embodies a substantive effort to realise
                 substantive equality. The proviso also emphasises that
                 the need to maintain the efficiency of administration
                 cannot be construed as a fetter on adopting these
                 special measures designed to uplift and protect the
                 welfare of the SCs and STs.
                 119          The Constitution does not define what the
                 framers meant by the phrase ―efficiency of
                 administration. Article 335 cannot be construed on the
                 basis of a stereotypical assumption that roster point
                 promotees drawn from the SCs and STs are not efficient
                 or that efficiency is reduced by appointing them. This is
                 stereotypical because it masks deep rooted social
                 prejudice. The benchmark for the efficiency of
                 administration is not some disembodied, abstract ideal
                 measured by the performance of a qualified open
                 category candidate. Efficiency of administration in the
                 affairs of the Union or of a State must be defined in an
                 inclusive sense, where diverse segments of society find
                 representation as a true aspiration of governance by
                 and for the people. If, as we hold, the Constitution
                 mandates realisation of substantive equality in the
                 engagement of the fundamental rights with the
                 directive principles, inclusion together with the
                 recognition of the plurality and diversity of the nation
                 constitutes a valid constitutional basis for defining
                 efficiency. Our benchmarks will define our outcomes. If
                 this benchmark of efficiency is grounded in exclusion, it
patil-sachin.
::: Uploaded on - 27/06/2019                   ::: Downloaded on - 28/06/2019 05:25:27 :::
                                    450                              Marata(J) final.docDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                 will produce a pattern of governance which is skewed
                 against the marginalised. If this benchmark of efficiency
                 is grounded in equal access, our outcomes will reflect
                 the commitment of the Constitution to produce a just
                 social order. Otherwise, our past will haunt the inability
                 of our society to move away from being deeply unequal
                 to one which is founded on liberty and fraternity. Hence,
                 while interpreting Article 335, it is necessary to liberate
                 the concept of efficiency from a one sided approach
                 which ignores the need for and the positive effects of
                 the inclusion of diverse segments of society on the
                 efficiency of administration of the Union or of a State.
                 Establishing the position of the SCs and STs as worthy
                 participants in affairs of governance is intrinsic to an
                 equal    citizenship.    Equal    citizenship   recognizes
                 governance which is inclusive but also ensures that
                 those segments of our society which have suffered a
                 history of prejudice, discrimination and oppression have
                 a real voice in governance. Since inclusion is
                 inseparable from a well governed society, there is, in
                 our view, no antithesis between maintaining the
                 efficiency of administration and considering the claims
                 of the SCs and STs to appointments to services and
                 posts in connection with the affairs of the Union or of a
                 State.
Reliance is also placed on the judgment of Justice O.
Chinnappa Reddy in K.C. Vasanth Kumar which reads thus :
            120 This part of the philosophy of the Constitution was
            emphasized in a powerful exposition contained in the judgment
            of Justice O Chinnappa Reddy in K C Vasanth Kumar v State of
            Karnataka (―K C Vasanth Kumar). The learned Judge held:
                    ―35. One of the results of the superior, elitist
                    approach is that the question of reservation is
                    invariably viewed as the conflict between the
                    meritarian principle and the compensatory principle.
                    No, it is not so. The real conflict is between the class
                    of people, who have never been in or who have
                    already moved out of the desert of poverty, illiteracy
                    and backwardness and are entrenched in the oasis of
                    convenient living and those who are still in the desert
                    and want to reach the oasis. There is not enough fruit
                    in the garden and so those who are in, want to keep
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

::: Uploaded on - 27/06/2019                       ::: Downloaded on - 28/06/2019 05:25:27 :::
                                     451                              Marata(J) final.doc
                     out those who are out. The disastrous consequences
                     of the so-called meritarian principle to the vast
                     majority of the under-nourished, poverty-stricken,
                     barely literate and vulnerable people of our country
                     are too obvious to be stated. And, what is merit?
                     There is no merit in a system which brings about such
                     consequences...
                   Conclusively, Their Lordships have held as follows:
                124        Once we understand ―merit as instrumental in
                achieving goods that we as a society value, we see that the
                equation of ―merit with performance at a few narrowly defined
                criteria is incomplete. A meritocratic system is one that rewards
                actions that result in the outcomes that we as a society value.
                125      For     example,     performance       in   standardised
                examinations (distinguished from administrative efficiency) now
                becomes one among many of the actions that the process of
                appointments in government services seeks to achieve. Based
                on the text of Articles 335, Articles 16 (4), and 46, it is evident
                that the uplifting of the SCs and STs through employment in
                government services, and having an inclusive government are
                other outcomes that the process of appointments in
                government services seeks to achieve. Sen gives exactly such
                an example
                     If, for example, the conceptualisation of a good society
                     includes the absence of serious economic inequalities,
                     then in the characterisation of instrumental goodness,
                     including the assessment of what counts as merit, note
                     would have to be taken of the propensity of putative merit
                     to lessen - or to generate - economic inequality. In this
                     case, the rewarding of merit cannot be done independent
                     of its distributive consequences.
                     ... A system of rewarding of merit may well generate
                     inequalities of well-being and of other advantages. But, as
                     was argued earlier, much would depend on the nature of
                     the consequences that are sought, on the basis of which
                     merits are to be characterised. If the results desired have a
                     strong distributive component, with a preference for
                     equality, then in assessing merits (through judging the
                     generating results, including its distributive aspects),Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                     concerns about distribution and inequality would enter the
                     evaluation.
patil-sachin.
::: Uploaded on - 27/06/2019                        ::: Downloaded on - 28/06/2019 05:25:27 :::
                                     452                            Marata(J) final.doc
                 The       State    Government     while       acting       on      the
quantifiable data has ensured that the standards of merit are
not diluted while the community compete in the quota allotted
to it and in any contingency, the Other Backward Classes in
the State are enjoying the said privileges and the Maratha
community should not be accused of bringing the efficiency
down, which is again not proved by any material being placed
on record, but is only expressed as an apprehension.
170              The State after constituting a Commission in June
2017 to determine the representation of Marathas and to
define the exceptional circumstances and extra-ordinary
situations has enacted a legislation conferring benefits on the
said      class      which     it   has   identified    as     backward.           The
Commission has recommended that Maratha class of citizens
in the State is socially, educationally and economically
backward by analyzing the determined parameters. We have
reproduced above the conclusions of the Commission. Point
No.H of the said recommendation categorise the extra-
ordinary situation and circumstances for crossing 50% limit.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

The Committee is also therefore, conscious of the limit/ceiling
of 50% as determined by the authoritative pronouncement of
patil-sachin.
::: Uploaded on - 27/06/2019                      ::: Downloaded on - 28/06/2019 05:25:27 :::
                                         453                            Marata(J) final.doc
the Hon'ble            Apex Court through its 9 Judges Constitution
Bench. The extra-ordinary situations have been culled out as
the report has declared that Maratha community comprise
30% of the population of the State and this figure is derived
on the basis of quantifiable data. The extra-ordinary situation
is     therefore          carved        out    for   awarding         an      adequate
representation to the Maratha community who is now declared
socially, educationally and economically backward. Based on
the     population             of   30%,      Commission     has      arrived       at       a
conclusion that the total percentage of State population which
is entitled for the constitutional benefits and advantages as
listed under Article 15(4) and Article 16(4) would be around
85%       and      this        is   a   compelling    extra-ordinary           situation
demanding extra-ordinary solution within the constitutional
framework.            The Commission has concluded that as far as
Scheduled Caste and Scheduled Tribes are concerned, the
Constitutional framework do not contemplate any quantifiable
data or its verification and it has to be in proportion to the
population requiring more distinction to be made as regards
adequate, vis-a-vis proportionate                    as to be one in case ofDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

reservation to the Other Backward Classes. The Commission
therefore, proceeds to derive a formula for tackling emerging
patil-sachin.
::: Uploaded on - 27/06/2019                          ::: Downloaded on - 28/06/2019 05:25:27 :::
                                454                             Marata(J) final.doc
scenario and it calculates that for dealing with 63% of weaker
section, excluding 22% (SC ST VJNT) will have to be restricted
to the remaining 29% reservation allocation as a condition by
ceiling of 50% and this is an extra-ordinary situation.                        The
Commission has attempted to clarify it in the following
manner :-
 87+9Total Backward             85%
 population                     (52% as determined by Mandal
                                Commission + 30% of Maratha
 OBC and Maratha                63%
 Population                     (85% - 22% SCST VJNT)
                 Total percentage of reservation 50%
 Reservation of 22% SCST             21.00%
 Reservation available for           29.00%
 63%
 (Maratha + OBC)
The Commission, therefore, makes out a case that if the
ceiling of 50% is kept in tact, and more and more classes of
citizenry are to be accommodated in the other 50%, this
would result in a way favouring the forward class of society to
enjoy their age-old social and educational dominance in
perpetuity again at the cost of majority, backward class of
population and this is a breach of principle of positiveDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

discrimination which has been invoked by the Constitution
patil-sachin.
::: Uploaded on - 27/06/2019                  ::: Downloaded on - 28/06/2019 05:25:27 :::
                                455                        Marata(J) final.doc
makers.         The plight of Maratha has been described as the
worst sufferers by not allowing the breach of 50% reservation
limit on one hand and tagging them with forward class citizens
to frame the constitution on the other hand, and in fact, the
Maratha community was already included in the backward
category before independence and till the year 1952, as an
intermediary class and most of the classes from intermediary
has been included in backward classes but only the Marathas
have been included without any reasoning and came to be
tagged with forward class of citizens to face a stilt unequal
competition. The reasoning cited by the Commission in its
report does disclose that it has formulated and answered an
issue that Maratha community is a kin to another side of coin
of Kunbi community. However, the Commission has derived a
method of placing this community outside the Other Backward
Class list and it has shared a reasoning that the backward
class communities already included in the OBC list, the total
population of which is estimated to be around 33% to 34%
and they are enjoying 29% of reservation quota (50 - 21)
allotted to SCST and and if abruptly they are asked to share
their well established entitlement of       reservation with 30%Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Maratha class, it would be a catastrophic scenario and this,
patil-sachin.
::: Uploaded on - 27/06/2019             ::: Downloaded on - 28/06/2019 05:25:27 :::
                                  456                                Marata(J) final.doc
according to the Commission is an extra-ordinary situation
and exceptional circumstances, which if not swiftly and
judicially addressed may lead to unwarranted repurcation in
the well said harmony of of co-existence culture of the State.
This conclusion of the Commission gets translated into the Bill
which is included in the State legislature providing the
reservation to Maratha community in a different compartment
than that of the backward classes. There can be no quarrel
and we have already expressed our accord to the findings
recorded by the Commission and we are also in agreement
with the report of the Commission that Marathas have a less
representation in the public services.                 The statistics by the
Commission do disclose that as per the latest census figure
4.62% jobs are available per 100 youth in public services and
has the average recruitment per year is not more than 5% of
the total body of the State. The availability ratio sinks to 0.23
% less than one job per 100 eligible youth. According to the
SOR, if the job scenario is restricted in the manner that only
50% of 0.23% i.e. 0.12% jobs per recruitment year will be
available to 95% population and remaining 0.12% jobs to a
population of 5% unreserved jobs of forward seats, this is aDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

mockery          of     reservation    principle     in     State/employment
patil-sachin.
::: Uploaded on - 27/06/2019                       ::: Downloaded on - 28/06/2019 05:25:27 :::
                                      457                            Marata(J) final.doc
constitutionally treachery according to the report and this is
also       taken       as      an    extra-ordinary    situation         warranting
enhancement of reservation of percentage beyond 50%.
171              In light of the aforesaid discussion, we are satisfied
that the Commission as well as the State Government has
made out a case of existence of extra-ordinary situation and
exceptional circumstances being in existence in the State so
as to fall within the exception carved out in the judgment of
Indra Sawhney and it has crossed the said limit in light of an
extra-ordinary situation emerging in the State.
(IX) WHETHER THE STATE GOVERNMENT HAS JUSTIFIED
EXERCISE OF ITS ENABLING POWER UNDER ARTICLE
15(4) AND 16(4) IN THE BACKDROP OF THE FINDINGS
CONCLUSIONS AND RECOMMENDATIONS OF THE MSBCC
REPORT
172              Under         the   Indian   Constitution,       reservation             is
accepted as one of modes of achieving equality and though
the quotas are seen as widely unfair and condemned for
punishing the innocent upper caste for the damage suffered inDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

the past, leading to widening of gaps in the society, based on
patil-sachin.
::: Uploaded on - 27/06/2019                       ::: Downloaded on - 28/06/2019 05:25:27 :::
                                458                          Marata(J) final.doc
caste lines instead of striving for casteless society, the need
for reservation in form of special concession still persists as it
assists in achieving the Constitutional goal of equality of
opportunity and equality of status. Amidst this conundrum, it
is also realised that benefiting generation whose parents have
already moved up by enjoying the privilege and attained
equality in the social structure, both in status and opportunity
do not avail the benefits in form of such concession. The result
of the situation is that the much poorer, first generation of a
family is left in lurch.
                 Due to passage of time, the traditional occupation
as the standard means of economic achievement has lost
much of its significance and by this time it is also settled by
the legal debate that caste cannot be the sole criteria for
identifying backwardness. However, the criteria of social and
educational backwardness is still relevant since it finds place
in the Constitution itself and identification of this class is
important. It may not contemplate identification of a particular
individual to fit into the said category but the task is to
identify an entire class which is socially and educationally
backward. Though economic backwardness is not a measure
to identify backwardness till the latest 103rd AmendmentDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

patil-sachin.
::: Uploaded on - 27/06/2019               ::: Downloaded on - 28/06/2019 05:25:27 :::
                                        459                               Marata(J) final.doc
which has mandated certain reservation in favour of the
economically weaker sections of the society. However, we
cannot turn a blind eye to the social scenario with a wide gap
between the affluent economic class enjoying an upper hand
irrespective of their caste, occupation etc, whereas there exist
a class which is economically deprived and though normally
we apply the terminology 'poor' to the said class, it exist
irrespective of the caste, occupation, etc.                               The present
scenario prevailing in the State of Maharashtra is also not an
exception to this rule. The community known as Maratha also
comprise of these two stratas those which are well to do,
affluent and even in the helm of affairs of the State on one
hand and the persons belonging to the same class on account
of    the        economic           backwardness       suffer     from       social      and
educational backwardness.                     It is difficult to ascertain whether
economic           situation          leads     to    educational          and        social
backwardness or vice-a-versa.                      However, for the purpose of
the Constitution, the educational and economic backwardness
is a measure of backwardness. It is necessary to achieve a
social          balance        so    that    the     said   class      attains        social
empowerment.                   Backwardness no longer remains to be
identified on the basis of traditional yardsticks of occupationDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

patil-sachin.
::: Uploaded on - 27/06/2019                            ::: Downloaded on - 28/06/2019 05:25:27 :::
                                      460                            Marata(J) final.doc
and social acceptability. The backwardness of OBC need not
be strictly comparable to that of Scheduled Caste and
Scheduled Tribes.               Mere educational or social backwardness
would also be not the end point since the economic criteria is
closing in as a prime cause for backwardness.
                 Though it is attempted to canvass before us that
Maratha community is socially advanced and the instances
have been cited to inform that several Chief Ministers of the
State, belonged to Maratha community, that in our opinion, do
not make the entire community forward or advanced.                                        A
community            is    a    group   of    people   having        a     particular
characteristics in common and when this community is
stratified on economic factors, then just because one part of
the      community             has   progressed   do     not     wipe       out      the
backwardness of the remaining part.                          By applying the
yardstick        for      measuring     the    backwardness,          the      MSBCC
concluded that Maratha community                    as a class are socially,
educationally and economically backward and weightage of
21.5 marks out of maximum 25 marks, by statistically
analysing the data has been brought on record. Similarly, the
Commission has also recorded that there is no adequate
representation of this community in public employment andDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

patil-sachin.
::: Uploaded on - 27/06/2019                       ::: Downloaded on - 28/06/2019 05:25:27 :::
                                461                     Marata(J) final.doc
the presence of Marathas in the said public employment in
higher grade of 'A', 'B', 'C' and 'D' is found to be inadequate
not only as proportion to their State population share of
around 30% but also because of inadequacy in the number of
graduates which is the minimum educational qualification for
this grade of public posts. Further, the Commission has also
brought on record the quantifiable data as regards the
presence of Maratha community in pursuit of academic career
and on an average 4.30% is the figure which is arrived at
being occupied by the persons from Maratha community in
academic and teaching post. The lack of conventional degree
level education has been traced as one of the cause for they
adopting a lowly labour oriented employment such as
Mathadis, Hamals, Dabbewalas working in sugar crushers etc.
As far as the educational status is concerned, 13.42% of the
community is found to be illiterate whereas the proportion of
those attaining SSC and HSC level is also recorded to be below
State average and whereas only 0.77% of this population has
acquired technical and professional proficiency. This position
of Marathas is reflective of their economical status and the
Commission has concluded that around 93% of Maratha
families have an annual income of much less, which is belowDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

patil-sachin.
::: Uploaded on - 27/06/2019          ::: Downloaded on - 28/06/2019 05:25:27 :::
                                        462                             Marata(J) final.doc
the average income of middle class family. The percentage of
landless and marginal farmers (land ownership less than 2.5
acres) is found to be around 71% and percentage of big
farmers holding about 100 acres of land is only around 2.7%.
This precisely is the position of Maratha community in the
State. This situation being emerged out of the report of the
Commission which we have accepted since based on a
systematic study and since the Commission has collected the
contemporaneous data by actually visiting the houses located
in villages, talukas and attempted to ascertain the condition of
living of this community and though we accept the argument
of those opposing reservation to the said community that the
situation of all the communities residing in rural area is the
same. However, we have also noted that dominantly, it is this
caste which continues its habitat in rural part of State of
Maharashtra. The community is not able to move out of the
rural      scenario            since   their   traditional     occupation           being
agriculture, either they own small portions of land in villages
or have been working with the land owners of the same
community having more acreage of land. When they migrate
to the urban/semi-urban areas, their educational status poses
a handicap for them.                      The backwardness of the saidDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

patil-sachin.
::: Uploaded on - 27/06/2019                          ::: Downloaded on - 28/06/2019 05:25:27 :::
                                463                            Marata(J) final.doc
community thus not being doubted, the State has come up
with an affirmative action by bringing in a legislation providing
quotas in education and employment for this community.
Considering the fact that the community had sufficient
political representation, no reservation is provided to this
community in the political arena.             The compelling State's
interest of recognizing the said community as backward and
conferring certain privileges on the said community has been
scrutinized by us in exercise of a power of judicial review. The
Maratha community largely is found to be poor though
poverty is a peculiarity of Indian population that a factor has
not been adopted the sole criteria for identifying their
backwardness but the unfortunate situation leading to their
social and educational backwardness has been pin-pointedly
relied upon by the State while exercising its enabling power.
In Ashok Kumar Thakur Vs. Union of India ,37 the Apex
Court       has      unmistakably    recognised   that      the     economic
backwardness is also a relevant factor which can never be lost
sight of.
37 2008 (6) SCC 1Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

patil-sachin.
::: Uploaded on - 27/06/2019                 ::: Downloaded on - 28/06/2019 05:25:27 :::
                                   464                             Marata(J) final.doc
173              The following observations truly depict the scenario
prevailing as on today not only in the State of Maharashtra but
through out the country :
                    "Caste has divided this country for ages. It has
                    hampered its growth. To have a casteless society will
                    be realization of a noble dream. To start with, the
                    effect of reservation may appear to perpetuate caste.
                    The immediate effect of caste based reservation has
                    been rather unfortunate. In the pre- reservation era
                    people wanted to get rid of the backward tag -- either
                    social or economical. But post reservation, there is a
                    tendency even among those who are considered as
                    'forward', to seek 'backward' tag, in the hope of
                    enjoying the benefits of reservations. When more and
                    more people aspire for 'backwardness' instead of
                    'forwardness' the country itself stagnates. Be that as
                    it may. Reservation as an affirmative action is required
                    only for a limited period to bring forward the socially
                    and educationally backward classes by giving them a
                    gentle supportive push. But if there is no review after
                    a reasonable period and if reservation is continued,
                    the country will become a caste divided society
                    permanently. Instead of developing an united society
                    with diversity, we will end up as a fractured society for
                    ever suspicious of each other. While affirmative
                    discrimination is a road to equality, care should be
                    taken that the road does not become a rut in which
                    the vehicle of progress gets entrenched and stuck.
                    Any provision for reservation is a temporary crutch.
                    Such crutch by unnecessary prolonged use, should not
                    become a permanent liability. It is significant that
                    Constitution does not specifically prescribe a casteless
                    society nor tries to abolish caste. But by barring
                    discrimination in the name of caste and by providing
                    for affirmative action Constitution seeks to remove the
                    difference in status on the basis of caste. When the
                    differences in status among castes are removed, all
                    castes will become equal. That will be a beginning for
                    a casteless egalitarian society."Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

patil-sachin.
::: Uploaded on - 27/06/2019                     ::: Downloaded on - 28/06/2019 05:25:27 :::
                                  465                             Marata(J) final.doc
174              In Ram Singh Vs. Union of India (supra), Hon'ble
The Chief Justice Ranjan Gogoi held thus :
                       "An affirmative action policy that keeps in mind
                only historical injustice would certainly result in under-
                protection of the most deserving backward class of
                citizens, which is constitutionally mandated. It is the
                identification of these new emerging groups that must
                engage the attention of the State and the
                constitutional power and duty must be concentrated
                to discover such groups rather than to enable groups
                of citizens to recover "lost ground" in claiming
                preference and benefits on the basis of historical
                prejudice".
                       The perception of a self-proclaimed socially
                backward class of citizens or even the perception of
                the "advanced classes" as to the social status of the
                "less fortunates" cannot continue to be a
                constitutionally       permissible     yardstick        for
                determination of backwardness, both in the context of
Articles 15(4) and 16(4) of the Constitution. Neither
                can any longer backwardness be a matter of
                determination on the basis of mathematical formulae
                evolved by taking into account social, economic and
                educational        indicators.     Determination         of
                backwardness must also cease to be relative; possible
                wrong inclusions cannot be the basis for further
                inclusions but the gates would be opened only to
                permit entry of the most distressed. Any other
                inclusion would be a serious abdication of the
                constitutional duty of the State. Judged by the
                aforesaid standards we must hold that inclusion of the
                politically organized classes (such as Jats) in the list of
                backward classes mainly, if not solely, on the basis
                that on same parameters other groups who have
                fared better have been so included cannot be
                affirmed".
                 Keeping these principles in mind, we have delvedDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

into the report of MSBCC.                 A community which was
patil-sachin.
::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:27 :::
                                466                          Marata(J) final.doc
subjected to the test of backwardness at the hands of
various         commissions    never   received      recognition           as
backward till the MSBCC came into picture.                      The said
Commission for the first time carried a systematic scientific
analysis based on the ground survey and analysed the
status of the said class and identified it to be backward.
Their backwardness though not comparable to Scheduled
Caste and Scheduled Tribe, is comparable to several other
backward classes which find its place in the list of Other
Backward Classes pursuant to Mandal Commission. "Kunbi"
is one such caste which has gained entry into the list of OBC
and Gaikwad Commission has specifically ruled that there is
no distinction between 'Kunbi' and 'Maratha' community. In
the backdrop of these findings, a question has arose for
determination is if the yardstick of backwardness apply to
both the communities, produce the same end result of they
being identified as 'backward', then why the Maratha
community should be excluded from availing the benefits.
The extra-ordinary situation that have emerged in adjusting
the said community into the 50% ceiling limit has already
been dealt with by the Commission extensively and it hadDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

recommended for creation of a separate class for this
patil-sachin.
::: Uploaded on - 27/06/2019               ::: Downloaded on - 28/06/2019 05:25:27 :::
                                    467                          Marata(J) final.doc
community and similar other communities which are socially
and educationally backward. This community can have its
comparison with the Other Backward Classes in getting the
recognition of its social and educational backwardness
whereas it is distinct from the Other open class which do not
satisfy the criteria of social and educational backwardness.
The community, therefore, finds its place in a separately
grouped class of SEBC and a separate quota being reserved
for it. Since we have accepted the report of the Commission
and do not find any perversity or arbitrariness in the said
report and also since we have recorded that the State
legislature did not lack competency to enact the SEBC Act
2018, a step taken by it in exercising of its enabling power,
it poses no difficulty to uphold the reservation in favour of
this community.                In the words of Justice Krishna Iyer
"Constitutional questions cannot be viewed in vacuo but
must be answered in the social milieu which gives it living
meaning. "There must be a synthesis of ends and means, of
life's maladies and law's remedies". If these words are kept
in mind, in the framework of the Constitution and the
existing need of a particular class which came to beDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

subjected to scrutiny by the State and on a finding recorded
patil-sachin.
::: Uploaded on - 27/06/2019                   ::: Downloaded on - 28/06/2019 05:25:27 :::
                                  468                         Marata(J) final.doc
by an expert body in form of MSBCC who has acted within
the statutory framework, we feel no reason to interfere in
the decision of the State to confer reservation under Article
15(4) and 16(4) on the said community. It is to be noted
that in order to do away with the malady of the affluent or
the so-called advance members of this community availing
the benefit of Section 4(2) of the Enactment has introduced
the principle of creamy layer and has made it applicable for
the purposes of reservation to the SEBC and the reservation
available can only be availed by those persons who are
below creamy layer. Not only this, in form of Section 5, the
Enactment stipulated that if on merit, the person belonging
to SEBC class competes or secures a seat or appointment,
such a selection or appointment shall be considered on the
basis of merit.            The impugned enactment keeps open the
inclusion of other similarly situated classes of citizens to be
included in the SEBC class created under Section 2(j) of the
impugned enactment and share the quota prescribed in
Section 4. The enactment do not entail any political
reservation for the said community for election of the seats
in Village Panchayats, Panchayat Samitis, Zilla Prishadas,Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Municipal Councils, Municipal Corporations, etc.
patil-sachin.
::: Uploaded on - 27/06/2019                ::: Downloaded on - 28/06/2019 05:25:27 :::
                                   469                            Marata(J) final.doc
                The State Government has also taken care of the
argument affecting the efficiency of administration. This
argument which is very much on the lips of the privilege
whenever reservation is mentioned was dealt by Justice
Chinappa Reddy three decades back in K.C. Vasanth Kumar
Vs. State of Karnataka (supra) has observed thus:-
                 37.      But the controversy between the meritarian
                 and the compensatory principals cannot be allowed to
                 cloud the issues before us. An intelligible consequence
                 of the fundamental rights of equality before the law,
                 equal protection of the laws, equality of opportunity,
                 etc., guaranteed to all citizens under our Constitution
                 is the right of the weaker sections of the people to
                 special provision for their admission into educational
                 institutions and representation in the services.
                 Appreciating the realities of the situation. and least
                 there by any misapprehension, the Constitution has
                 taken particular care to specially mention this right of
                 the weaker sections of the people in Arts. 15(4) and
                 16(4) of the Constitution. In view of Arts. 15(4) and
                 16(4) the so-called controversy between the
                 meritarian and compensatory principles is not of any
                 great significance, though, of course, we do not
                 suggest efficiency should be sacrificed. The question
                 really is, who are the scheduled castes, scheduled
                 tribes and backward classes, who are entitled to
                 special provision and reservation in regard to
                 admission      into   educational     institutions  and
                 representation in the services"
                 58              We must repeat here, what we have said
                 earlier, that there is no scientific statistical data or
                 evidence of expert administrators who have made any
                 study of the problem to support the opinion that
                 reservation in excess Or 5() percent may impair
                 efficiency. It is a rule of thumb and rules of the thumbDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                 are not for judges to lay down to solve complicated
                 sociological and administrative problems. Sometimes,
                 it is obliquely suggested that excessive reservation is
                 indulged in as a mere votecatching device. Perhaps so,
patil-sachin.
::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:28 :::
                                 470                             Marata(J) final.doc
                perhaps not. One can only say 'out of evil cometh
                good' and quicker the redemption of the oppressed
                classes, so much the better for the nation. Our
                observations are not intended to show the door to
                genuine efficiency. Efficiency must be a guiding factor
                but not a smokes-cream. All that a Court may
                legitimately say is that reservation may h not be
                excessive. It may not be so excessive as to be
                oppressive; it may not be so high as to lead to a
                necessary presumption of unfair exclusion of everyone
                else.
175              The avowed purpose of the impugned legislation
being lending a helping hand to persons belonging to the
said class below creamy layer and in order to afford them an
opportunity to advance further in the contemporary period,
aims at moving them to a stage of equality with the
advance section of the society wherefrom they can proceed
further. The State who is conferred with the enabling power
and though argued by the Senior counsel Shri Aney that the
State cannot be compelled to exercise this enabling power,
equally true that if the State exercises this power, we can
only review the decision of the State to a limited extent to
find out whether the decision making is just and would not
ponder on the decision itself unless it is arbitrary. When we
have scrutinized the report of the Commission and theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

decision of the State, we are satisfied that the procedure
preceding identification of a backward class has been
patil-sachin.
::: Uploaded on - 27/06/2019                   ::: Downloaded on - 28/06/2019 05:25:28 :::
                                      471                            Marata(J) final.doc
complied with and the data arrived by the Commission of
inadequacy of representation and backwardness being
based on the subjective satisfaction of the State, we have
shown           restraint      in   substituting   the    findings         of    the
Commission.              The State Government has exercised its
enabling power based on the report of the Commission and
has accepted the report in totality with an exception to the
quantum of reservation. The report of the Commission has
carved out 12% reservation for the community for education
purpose and 13% reservation to the posts/seats in the
services in the State. The learned senior counsel Shri
Sancheti has submitted that there is no justification for the
State to deviate from the percentage prescribed by the
Commission and when it has capped it at 12 and 13%
respectively, the State was not justified in prescribing the
reservation of 16% in favour of Maratha community. We find
substance in the said submission of the learned senior
counsel. The State Government is not justified exercise of
its enabling power in fixing a limit of 16%, both under 15(4)
and 16(4). The said limit, according to us, is not justified byDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

the State by bringing any quantifiable data establishing the
end point of 16%. The report                 of the Commission though
patil-sachin.
::: Uploaded on - 27/06/2019                       ::: Downloaded on - 28/06/2019 05:25:28 :::
                                   472                           Marata(J) final.doc
recommendatory in nature or in form of an advice given by
the Commission in terms of Section 9 of the MSBCC Act
2005 shall ordinarily be binding on the State Government
and if the State Government propose to reject the same,
totally or partially or even if intends to modify, it is
imperative for the State Government to record reasons in
writing. In absence of any such exercise undertaken by the
State Government, we hold that the exercise of enabling
power by the State Government determining the quantum
of reservation cannot be sustained and we express that the
quantum/limit            fixed   by the   Commission       is    based        on
quantifiable data. Since we have heard storming arguments
on the point of the ceiling imposed by the Apex Court in
matters of reservation, and the judgment in Archana Reddy
by the Andhra Pradesh High Court is heavily relied upon, we
should be conscious of even one percent of reservation
being conferred by the State without quantifiable data. The
Gaikwad Commission has justified the limit which it has set
in the report is based on the quantification set out by it by
taking into consideration the factors like the population ofDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Maratha as well as the several reserved categories who can
compete with the individuals on merit and do not desire to
patil-sachin.
::: Uploaded on - 27/06/2019                  ::: Downloaded on - 28/06/2019 05:25:28 :::
                                        473                                   Marata(J) final.doc
avail the reservation benefits as per their free choice and
aspire to opt for merit quota only. The Commission has set
out the calculation in Volume II in the following manner :-
(A)      For employment in State Public Employment will be :
 Sr.             Class           Proposed         Proposed                     Remarks.
 No.                            Allocation of    merit open
                                reservation        Quota
                                percentage       percentage
 1     Scheduled Caste          13%              35% for all Open Merit Quota of 35% for All
                                                 categories  the classes from 1 to 6 can
 2.    Scheduled tribe          7%                           compete        including     those
 3.    Most Backward Classes 13%                             individuals who do not desire to
       (NT/VJ/SBC)                                           avail reservation benefits as their
                                                             free choice and aspire to opt for
 4.    Other         Backward 19%                            Merit Quota Selection only.
       classes
 5.    Socially Educationally 13%
       Intermediate Backward
       Class (SEIBSC)
 6.    Free Merit Quota for all NIL
       the Open & Reserved
       Categories
       Total                    65%              35%
(B)      For      admission           in   Higher,      Technical            and       Medical
Admissions will be :
 Sr.                 Class                   Proposed           Proposed             Remarks.
 No.                                        Allocation of      merit openDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

                                            reservation          Quota
                                            percentage         percentage
 1     Scheduled Caste                     13%                36% for all Open Merit Quota of
                                                              categories  36%     for    All the
 2.    Scheduled tribe                     7%
                                                                          classes from 1 to 6
 3.    Most Backward Classes (NT/VJ/ 13%                                  will be eligible.
       SBC)
 4.    Other Backward classes              19%
 5.    Socially        Educationally 12%
       Intermediate Backward Class
       (SEIBSC)
 6.    Free Merit Quota for all the NIL
       Open & Reserved Categories
patil-sachin.
::: Uploaded on - 27/06/2019                                ::: Downloaded on - 28/06/2019 05:25:28 :::
                                  474                                Marata(J) final.doc
       Total                         64%               36%
                 The       Commission      has    given       its     thoughtful
consideration to the extent of reservation in the backdrop of
the ceiling limit laid down by the Apex Court and at the
same time, ensuring the quantum of reservation to a class
which it has determined and identified to be backward. In
making          its      recommendation,         the        Commission           has
undertaken a balancing act by classifying the newly created
class into a separate category of SEBC to ensure that this do
not affect the reservation already provided to the Other
Backward Classes in the State.              Considering the need of the
State to prescribe a separate quota for the Maratha
community pursuant to the MSBCC report, we hold andDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

declare that since the State Government has accepted the
report of the MSBCC, it ought to have adhered to it including
its recommendation on quantum of reservation for the
SEBC. The action of the State Government in not accepting
the     recommendation          on     quantum         of    reservation         and
prescribing the reservation of 16% to the community cannot
be sustained, over and above the percentage recommended
by the Commission. By doing so, we ensure the compliance
patil-sachin.
::: Uploaded on - 27/06/2019                       ::: Downloaded on - 28/06/2019 05:25:28 :::
                                475                         Marata(J) final.doc
of the parameters laid down in Nagaraj, i.e. the inadequacy
of representation and backwardness which necessarily has
to be based on quantifiable data being available with the
State. In light of this, though we uphold the enabling power
of the State to carve out a separate quota for the socially
and educationally backward class, including the Maratha,
and we uphold this enabling power contained in Section 4 of
the impugned Act, we declare that the quantum of 16% of
reservation under Article 15(4) and (5) as prescribed in sub-
section (a) of Section 4(1) of the impugned Act and the
quantum of reservation under Article 16(4) prescribed by
sub-section (b) of Section 4 (1), over and above, the
quantum prescribed by the Maharashtra State BackwardDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Class Commission is quashed and set aside.
176              Our whole deliberation revolved around the
identification of a community as a backward class and the
steps taken by the State in exercise of its enabling power.
We have also dealt with the specific objection advanced on
behalf of the petitioners that a class which was not
backward since the advent of the Constitution is now being
identified as backward.        The issue of identification of the
patil-sachin.
::: Uploaded on - 27/06/2019              ::: Downloaded on - 28/06/2019 05:25:28 :::
                                       476                               Marata(J) final.doc
backward classes which has eluded the constitutional courts
since it started examining the enabling power of the State
conferred as a special provision. The focal point has always
been of identification of these "backward classes". Several
judgments have been dedicated in answering the said
question and as to whether the backwardness has to be
social          and     educational         or    whether         the      economic
backwardness which contribute to the other two can also be
the factor for determination since in country like India,
poverty          is   the      root   cause      for   social     and      economic
backwardness. The uniform test of evolving the criteria to
determine the social and educational backwardness has also
been delved into for a long time.                       It is however, not inDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

dispute         that     the     reservation      policy     which        has      been
considered as a more for achieving equality without
impairing the efficiency but at the same time, aimed at
securing adequate representation, was never considered to
be a permanent feature.                 The framers of the Constitution
intended it to survive for a limited period to remove the
disparity which was historically traced amongst different
classes.          The preferential principle involved formidable
burden on the policy makers and the administration in a
patil-sachin.
::: Uploaded on - 27/06/2019                           ::: Downloaded on - 28/06/2019 05:25:28 :::
                                    477                                 Marata(J) final.doc
developing nation. The constitutional court also step in to
ensure that the policy makers have devised the effective
use of its enabling powers which the Constitution has
conferred on them. The width of the power exercised by the
State by invoking the provisions in the Constitution which
conferred this power on them varied from State to State and
region to region within a State depending on conditions
prevailing of the backward classes.                    Since the reservation
itself was expected to have a life, the provisions were
introduced in form of statutes which would enable the State
to have a review of the situation prevailing in its State and
take periodical measures                 to    continue        its exercise of
reviewing the socio economic progress of the backwardDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

classes of citizens. This did not extend only to review the
conditions of those who are already conferred with the
benefits but also of those who are left out and are struggling
with their backwardness and feel aggrieved, comparing
themselves with those classes who have been enjoying the
privilege conferred by the State and have sufficiently
progressed in life.            This was the precise function which was
assigned         to     the    backward       class    commissions             to     be
constituted by the States in form of permanent body for
patil-sachin.
::: Uploaded on - 27/06/2019                          ::: Downloaded on - 28/06/2019 05:25:28 :::
                                478                          Marata(J) final.doc
entertaining, examining and recommending upon request
for inclusion, hearing complaints of over-inclusion or under-
inclusion in the list of Other Backward Classes in light of the
decision in the case of Indra Sawhney. As far as the State of
Maharashtra is concerned, it enacted the MSCBC Act 2005
constituted the State Commission for Backward Classes and
entrusted it with the functions set out in Section 9 and apart
from inclusion and exclusion of any class of citizens in the
list of backward class, it was assigned a function to cause
studies to be conducted on regular basis through and in
collaboration with reputed academic and research bodies for
building of data for about the changing socio economic
status of various classes of citizens and to regularly reviewDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

the socio economic progress of the backward classes of
citizens.       In light of this function to be discharged by the
Commission, under Section 11 of the Statute, it is made
imperative for the State Government to undertake revision
of the list after every succeeding period of 10 years, with a
view to exclude from such list, those classes which have
ceased to be backward classes, or for including in such list
new backward classes. Thus, the exercise of identification
of backwardness is a continuous process which the State is
patil-sachin.
::: Uploaded on - 27/06/2019               ::: Downloaded on - 28/06/2019 05:25:28 :::
                                        479                               Marata(J) final.doc
expected          to     undertake          but   the    issue      is    not     about
identification of such backward classes, but the issue is after
identifying these classes, conferring the concessions on
such classes. The Statute expects the State Government to
revise the list of Other Backward Classes and even
empowers it to remove those classes who have progressed
and in order to follow the regime of the maximum limit
prescribed for reservation, it is open for the State to achieve
this limit by undertaking a periodical exercise of conferring
the concession.                This, according to us, is the only solution
which would avoid a situation which the State has faced
today. The Maratha community which, compels itself with
the Other Backward classes who has found their way in theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

list of OBC framed by the State, also stakes its demand for
being           placed         in     the     list      whereas          there        are
castes/communities which have been placed in the list who
have progressed since their inclusion, pursuant to Mandal
Commission report.                  We have noted that the said list has
been subjected to amendment from time to time and
various castes/ communities have been included and the
deletion from this list is a rare phenomenon.                            The Courts
have neither expertise nor the sociological knowledge to
patil-sachin.
::: Uploaded on - 27/06/2019                            ::: Downloaded on - 28/06/2019 05:25:28 :::
                                       480                             Marata(J) final.doc
define or lay down the criteria for determining what are
"socially and educationally backward classes of citizens" for
the purpose of Article 15(4) nor does it have an expertise to
determine what is adequacy of representation for the
purpose of Article 16(4), the duty which is assigned to the
Constitutional courts is only to examine the exercise
undertaken by the State and that too, on limited grounds,
keeping in mind its function to expound the Constitution.
We hope and trust that the State Government would
discharge the duty cast on it by Section 11 of the MSBCC Act
of 2005 and bring the reservation conferred on the Other
Backward Classes as well as the SEBC within the ceiling limit
set out by the Constitution Bench in Indra Sawhney.                                  AtDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

present, we have dealt with the extra ordinary situation with
which the State is confronted with where it justified the
exceeding of limit, and we, by taking into consideration the
exceptional circumstances, have upheld this exercise of
power by the State.                   We hope and trust that the said
situation would be reviewed by the State in the near future
so that it follows the rule of caution and do not forever
continue          with         this   "Exceptional     circumstances               and
extraordinary situation".
patil-sachin.
::: Uploaded on - 27/06/2019                         ::: Downloaded on - 28/06/2019 05:25:28 :::
                                         481                          Marata(J) final.doc
                    The need of a solution to the peculiar problem
brought before us arise on account of the social status of
the Maratha community which can be best described by the
lines of poetry quoted in Nehru's Autobiography38
                  "Bowed by the weight of centuries,
                  he leans
                  upon his hoe and gazes on the ground
                 the emptiness of ages in his face and on
                 his back, burden of the world".
(X) Summary of conclusions :
177              In the light of the discussion above, we summarize
our conclusions to the points which we have formulated in the
proemial of the judgment and deliberated in the judgment.
We summarize our conclusions in the same sequence :
[1]              We hold and declare that the State possess theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

legislative competence to enact the                        Maharashtra State
Reservation for Seats for Admission in Educational Institutions
in the State and for appointments in the public services and
posts under the State (for Socially and Educationally Backward
Classes) SEBC Act, 2018 and State's legislative competence is
not      in     any      way     affected     by   the    Constitution           (102 nd
Amendment) Act 2018 and the interim order passed by this
38 Allied Publishers 1962 Edition 439
patil-sachin.
::: Uploaded on - 27/06/2019                        ::: Downloaded on - 28/06/2019 05:25:28 :::
                                482                               Marata(J) final.doc
Court in Writ Petition No. 3151 of 2014. We resultantly uphold
the impugned enactment except to the extent of quantum of
reservation as set out in point no. 6.
[2]              We conclude that the report of the MSBCC under
the Chairmanship of Justice Gaikwad is based on quantifiable
and contemporaneous data and it has conclusively established
the social, economical and educational backwardness of the
Maratha          community     and   it   has    also       established           the
inadequacy of representation of the Maratha community in
public employment / posts under the State. Accordingly we
uphold the MSBCC report.
[3]              We hold and declare that the classification of theDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Maratha class into "Socially and Educationally Backward
Class" complies the twin test of reasonable classification
permissible under Article 14 of the Constitution of India,
namely, (a) intelligible differentia and (b) rational nexus to the
object sought to be achieved.
[4]              We hold and declare that the limit of reservation
should not exceed 50%, however in exceptional circumstances
patil-sachin.
::: Uploaded on - 27/06/2019                    ::: Downloaded on - 28/06/2019 05:25:28 :::
                                483                          Marata(J) final.doc
and extra-ordinary situations, this limit can be crossed subject
to availability of quantifiable and contemporaneous data
reflecting backwardness, inadequacy of representation and
without affecting the efficiency in administration.
[5]              We hold and declare that the report of the Gaikwad
Commission has set out the exceptional circumstances and
extra-ordinary situations justifying crossing of the limit of 50%
reservation as set out in Indra Sawhney's case.
[6]              We hold and declare that the State Government in
exercise of its enabling power under Articles 15(4)(5) and
16(4) of the Constitution of India is justified, in the backdrop of
report of MSBCC, in making provision for separate reservationDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

to Maratha community. We, however, hold that the quantum
of reservation set out by the Maharashtra State Reservation
for Seats for Admission in Educational Institutions in the State
and for appointments in the public services and posts under
the State (for Socially and Educationally Backward Classes)
SEBC Act, 2018, in section 4(1)(a) and 4(1)(b) as 16% is not
justifiable and resultantly we quash and set aside the
quantum of reservation under the said provisions over and
patil-sachin.
::: Uploaded on - 27/06/2019               ::: Downloaded on - 28/06/2019 05:25:28 :::
                                    484                            Marata(J) final.doc
above 12% and 13% respectively as recommended by the
Commission.
                 In the light of the discussion and the conclusions
enumerated above, we pass the following order.
                                  :ORDER:
[A] In the light of summary of conclusions above, we dispose of the following writ petitions / PILs by
upholding the Impugned Act of 2018 except to the extent of quantum of reservation prescribed by
section 4(1)(a) and 4(1)(b) of the said Act :
          1]     PIL No. 175 of 2018,
          2]     WP (stamp No.) 2126 of 2019
          3]     WP (stamp No.) 2668 of 2019
          4]     WP (stamp No.) 3846 of 2019
          6]     WP (Lodg. No.) 4100 of 2018
          7]     WP (Lodg. No.) 4128 of 2018.
          8]     WP (Lodg. No.) 4269 of 2018
          9]     PIL No. 6 of 2019.
          10] WP (Lodg No.) 969 of 2019.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

[B]              The       following   writ   petitions     /    PILs       seeking
implementation of the Impugned Act of 2018, are also disposed of in view of the Impugned Act
being upheld except to the extent of quantum of reservation prescribed by section 4(1)(a) and
4(1)(b).
patil-sachin.
485 Marata(J) final.doc 1] PIL No.19 of 2019 :- The petition is allowed in terms of prayer clause (a).
2] PIL No.181 of 2018 :- The petition is allowed in terms of prayer clause (a). As far as prayer clause
(b) is concerned, we grant liberty to the petitioner to file a fresh petition in case cause of action
survives. [C] The following writ petitions are rendered infructuous on account of the passing of
SEBC Act of 2018 which has repealed the earlier ESBC Act of 2015.
                  1]      Writ Petition (Stamp No.) 10755 of 2017
                  7]      Writ Petition No. 3151 of 2014.
[D]      The following writ petitions are de-taged from the
present group of petitions as they claim reservation for the Muslim communities.
1] Writ Petition No. 937 of 2017 2] Writ Petition No. 1208 of 2019 4] PIL (Stamp No.) 1914 of 2019.
patil-sachin.
486 Marata(J) final.doc [E] WP No.11368 of 2016:- The Petition is dismissed as far as prayer clause
(A) is concerned. As far as prayer (B) is concerned the petitioner is at liberty to file an appropriate
Writ Petition seeking said relief.
[F] PIL (Stamp No.) 36115 of 2018 :- The is disposed of since the recommendation of the
commission are implemented in form of the impugned SEBC Act, 2018. [G] In the light of disposal
of above writ petitions and PILs, all pending civil applications / notice of motions / Chamber
Summons taken out in these writ petitions and PILs do not survive and the same are accordingly
disposed of. 178 Before concluding, we place on record the appreciation of the erudite submissions
advanced by the learned Senior counsel who have ably assisted us in delivering the judgment. We
deeply value the assistance rendered by the learned senior counsel Shri Datar, Shri Aney, ShriDr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

Sancheti assisted by the junior counsel on record. We also acknowledge the valuable assistance
rendered by Advocate Shri Sadavarte, Shri Talekar. We also acknowledge the valuable assistance
rendered by the learned senior counsel Shri Thorat who was ably assisted by Advocate Akshay
Shinde and Ms.Prachi Tatke for his strenuous efforts. We also patil-sachin.
487 Marata(J) final.doc acknowledge the special assistance rendered by the learned senior counsel
Shri Mukul Rohatgi and Shri Paramjeet Singh Patwalia. We were also deeply assisted in our
endeavor by the learned senior counsel Shri Rafiq Dada, Shri Arif Bookwala, Shri Sakhare, Shri
Dhakephalkar, Shri Vineet Naik, Shri Mihir Desai. We also acknowledge the assistance of Shri
Tekale, Advocate Gaikwad and Advocate Abhijeet Patil. 179 At this stage, Mr.Sancheti, learned
senior counsel and Mr.Sadavarte, learned counsel appearing for the petitioners requested for stay of
the judgment. Since we have upheld the validity of the Act of 2018 on the reasoning given in the
judgment, we reject the said prayer. (SMT.BHARATI DANGRE, J) (SHRI RANJIT MORE, J)
patil-sachin.Dr. Jishri Laxmanrao Patil, Member, The ... vs The Chief Minister Of State Of ... on 27 June, 2019

