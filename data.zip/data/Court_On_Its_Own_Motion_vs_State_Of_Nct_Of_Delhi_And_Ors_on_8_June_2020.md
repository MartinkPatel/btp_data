Court On Its Own Motion vs State Of Nct Of Delhi And Ors on 8
June, 2020
Author: Prateek Jalan
Bench: Chief Justice, Prateek Jalan
$~3
*      IN THE HIGH COURT OF DELHI AT NEW DELHI
+      W.P.(C) 3250/2020 & CM APPL.11769/2020 (for Intervention)
       COURT ON ITS OWN MOTION                 ..... Petitioner
                     Through: Mr. Om Prakash, Amicus Curiae.
                         versus
       STATE OF NCT OF DELHI AND ORS.          ..... Respondents
                     Through: Mr. Rahul Mehra, SC (Crl.) with
                              Mr. Anuj Aggarwal, ASC and
                              Mr. Chaitanya Gosain, Adv. for
                              GNCTD.
                              Mr. Kirtiman Singh, CGSC with
                              Mr. Rohan Anand, Adv. for UOI.
                              Mr. Chander M. Lall, Sr. Adv. with
                              Ms. Nancy Roy, Intervener in person
                              in CM APPL. 11769/2020 for
                              Intervener.
       CORAM:
       HON'BLE THE CHIEF JUSTICE
       HON'BLE MR. JUSTICE PRATEEK JALAN
                         ORDER
% 08.06.2020 Proceedings of the matter have been conducted through video conferencing.
1. This writ petition has been taken up by this Court on its own motion vide order dated 26.05.2020.
2. Learned Amicus Curiae has assisted this Court painstakingly by filing more than one report.
Similarly, reports/affidavits have also been filed by the respondents, especially, a detailed affidavit
filed by Government of NCT of Delhi.
3. Learned Amicus Curiae electronically sent a copy of an additional report dated 06.06.2020. The
same is taken on record.
4. Learned Amicus Curiae has pointed out to this Court that the Mobile Application namely "Delhi
Corona Mobile Application", developed by Delhi Government, is not being updated regularly. He
also submitted that there is a mismatch of the facts and data released by the Government/private
hospitals in Delhi especially with regard to the availability of the beds and ventilators. It is also
submitted that some of the hospitals run by Central Government/Government of NCT of Delhi are
not updating the data. It is further submitted that helpline numbers as provided by Govt. of NCT ofCourt On Its Own Motion vs State Of Nct Of Delhi And Ors on 8 June, 2020

Delhi, are not properly working. Learned Amicus Curiae submitted that the Nodal Officers
appointed by the Delhi Government should be the ones vested with the responsibility to monitor the
allotment of the beds in the Government as well as private hospitals, so that these officers can keep a
check on the hospitals which are denying admission to the corona patients even though the beds are
available with them. It is further submitted by the learned Amicus Curiae that real time updation of
data should be done by the hospitals or data should atleast be updated every 8 hours. He also
submitted that there should be no denial in testing and asymptomatic patients should also be tested
for Covid 19 immediately. Various suggestions have been given by the learned Amicus Curiae in
paragraph 10 of the first report submitted by him dated 02.06.2020 which may be considered by the
Central Government as well as by the State Government.
5. We have also heard the Intervener and the learned Senior Counsel appearing for the Intervener
who has filed CM No.11769/2020 in this writ petition. It is submitted by the learned Senior Counsel
for the Intervener that suitable direction may be given to the Central Government and the
Government of NCT of Delhi to carry out tests of all those having apprehension of being exposed to
Corona virus. The learned Senior Counsel for the Intervener has named two private hospitals
wherein the number of tests have been drastically reduced to 45 and 100 tests per day respectively
due to the restrictions imposed in testing by Govt. of NCT of Delhi. It is also submitted by the
learned counsel for the Intervener that presently certain hospitals not having multi-speciality
facilities have been dedicated for the Corona patients. In this regard, the learned Senior counsel for
the Intervener submitted that Coronavirus may affect several organs of the body and therefore the
hospitals having multi-speciality facilities should be made available for the Corona patients. We are
avoiding giving names of the hospitals mentioned by the learned Senior Counsel for the Intervener,
however, learned Standing Counsel for the Govt. of NCT of Delhi has taken note of the names of
these hospitals and we expect that proper instructions shall be given to such hospitals in this regard.
6. Learned Standing Counsel appearing for the Government of NCT of Delhi has stated that
pursuant to this Court's orders dated 26.05.2020 and 02.06.2020, a detailed affidavit by Deputy
Secretary, Health and Family Welfare Department, GNCTD dated 07.06.2020 has been sent
electronically. The same is taken on record. Learned Standing Counsel appearing for the
Government of NCT of Delhi has pointed out various steps initiated by the Government of NCT of
Delhi like:-
(i) Now, Centralized toll-free helpline number 1031 has been developed by merging
all the helplines. Government of NCT of Delhi is in the process of further augmenting
the toll-free helpline No. 1031 by adding 50 more hunting lines enabling callers to be
connected swiftly to an operator. The toll-free helpline No. 1031 is providing seven
types of services which have been mentioned in the affidavit viz.
(a) For Bhojan Rahat Kendra - Dial 1
(b) For Ration Rahat Kendra - Dial 2
(c) For E pass - Dial 3Court On Its Own Motion vs State Of Nct Of Delhi And Ors on 8 June, 2020

(d) For information on CORONA Hospitals in Delhi and availability of beds in the
hospitals - Dial 4
(e) For Auto-rickshaw, Grahmin seva, Fat Fat seva - Dial 5.
(f) For the information on containment zone in Delhi - Dial Further, Press 1 for
information on home quarantine or Press 2 to talk to the concerned emergency
response official in your containment zone.
(g) To talk to customer care - Dial 7
(ii) That the Standard Operating Procedure has also been evolved for receiving calls
and effectively responding to the callers. As per the SOP, whenever a call is received,
the concerned District Surveillance Officer (DSO) is informed and in case of a COVID
19 case, and the concerned DSO takes the necessary measures.
(iii) That a special helpline number dedicated only to the Corona positive
patients/cases has recently been initiated. The helpline number for Corona positive
patients is 1800-111-747 (toll free) and any further information in this regard is
available on www.delhifightscorona.in. There are district-wise ground teams assigned
for effective surveillance of Corona. Each District has a DSO supported by a medical
team to reach out to the patients by making calls or home-visits to assess whether
they need home-
quarantine or are required to be sent to the hospitals or a nearby quarantine-centre. Since the model
operates district-wise, the district allocation needs to be precise and correct. He submitted that
much of the district-wise distribution data that Delhi receives from ICMR is incorrect, resulting in
inordinate delay in the geo-station mapping carried out by authorities/agencies. Thus, there is
usually a delay caused in contacting the patient who has tested positive after he has received the
lab-report and in the meantime patients tend to panic. The new helpline is aimed to cater to such
patients only, especially during the first 24 to 36 hours, who have tested positive and are scared, yet
clueless as to what should be their next/desired course of action. The said helpline would help them
resolve issues pertaining to availability of Ambulance/s and free medical consultation with a doctor.
It also used to happen that sometimes a positive corona patient could not be reached out due to
wrong information. The endeavour is also being made to get this helpline number printed on every
lab's test-report, so as to make the patient aware about such helpline facility.
(iv) Out of 209 ambulances of the Centralized Accident and Trauma Services (CATS) available
overall, 136 are exclusively dedicated for Covid patients. 125 additional cabs have been hired by
Government of NCT of Delhi from private operators for non-serious patients. Now the calls for
ambulances are being attended. Turn around time varies from 15 minutes to 50 minutes and the
time taken in reaching to the patient shall also be reduced in coming weeks.Court On Its Own Motion vs State Of Nct Of Delhi And Ors on 8 June, 2020

(v) So far as hospitalization of Corona patients is concerned, it is submitted by Mr. Rahul Mehra,
learned Standing Counsel appearing on behalf of Government of NCT of Delhi that they have
developed Mobile Application namely "Delhi Corona" on Google Platform for Android phone users
and World Wide Web for non-Android phone users which will facilitate in giving real time
information. Learned Standing Counsel further submitted that Government of NCT of Delhi is not
updating the data on this mobile application but the ID and passwords have been given to the
concerned hospitals and these hospitals are directly uploading the data regarding availability of the
beds, ventilators, etc. In this regard, more than 100 meetings have been held with the
management/owners of the hospitals in the city of Delhi and all steps are being taken to ensure
proper updation of the data by the hospitals and the Government of NCT of Delhi.
(vi) Four Grievance Officers have been appointed for redressal of complaints regarding availability
of the ambulance, hospital, beds and ventilators, etc.
7. Upon our specific query raised to Mr. Rahul Mehra, learned Standing Counsel that in spite of
availability of beds the Corona patients are being denied admission, it is submitted that they are
holding meetings with the owners of the hospitals/management and in case of any breach of the
directions given by the Government of NCT of Delhi action shall be initiated against errant
hospitals.
8. Having heard learned Amicus Curiae as well as the counsel for the respondents/Intervener, it
appears that there is a need of real time updation of the data by all hospitals including the Delhi
Government run hospitals, the Central Government run hospitals and private hospitals. We,
therefore, direct Government of NCT of Delhi as well as the Central Government that they shall take
all necessary steps for ensuring real time updation of the data, without too much of a time lag, so
that the information being received by the public is current. If any Committee is appointed by
Government of NCT of Delhi, the said Committee will also take note of this fact that there shall be
real time updation of the data on the mobile application developed by the Government of NCT of
Delhi.
9. We also direct the Central Government as well as the Government of NCT of Delhi that testing
shall be carried out by the Central Government as well as the State Government run hospitals, as far
as possible, subject to availability of testing kits with priority be given to the persons approaching
for test on the recommendation of a doctor.
10. So far as the points which are highlighted by the Intervener about availability of hospitals having
multi speciality facilities for the Corona patients, the same shall be considered by the State
Government/Central Government.
11. The practical applicability of the suggestion made by the learned Amicus Curiae and the learned
Senior Counsel for the Intervener will be kept in mind by the State Government/Central
Government. Reply shall be filed by the State Government/Central Government before the next date
of hearing.Court On Its Own Motion vs State Of Nct Of Delhi And Ors on 8 June, 2020

12. List on 25.06.2020.
CHIEF JUSTICE PRATEEK JALAN, J JUNE 08, 2020 kksCourt On Its Own Motion vs State Of Nct Of Delhi And Ors on 8 June, 2020

