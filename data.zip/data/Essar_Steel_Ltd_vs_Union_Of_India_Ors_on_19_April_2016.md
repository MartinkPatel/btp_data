Essar Steel Ltd vs Union Of India & Ors on 19 April, 2016
Equivalent citations: AIR 2016 SUPREME COURT 1980, 2016 (3) ADR 529,
2016 (3) AJR 459, AIR 2016 SC (CIVIL) 1605, (2016) 4 SCALE 267, (2016) 3 JCR
130 (SC), (2016) 3 MAD LJ 864, 2016 (11) SCC 1, 2016 (2) KCCR SN 196 (SC)
Author: V. Gopala Gowda
Bench: Uday Umesh Lalit, V. Gopala Gowda
            REPORTABLE
IN THE SUPREME COURT OF INDIA
CIVIL APPELLATE JURISDICTION
CIVIL APPEAL NO. 4610 OF 2009
ESSAR STEEL LTD.                      ……APPELLANT
                                     Vs.
UNION OF INDIA & ORS.                  ……RESPONDENTS
                              WITH
                        CIVIL APPEAL NO. 4609 OF 2009
                                     AND
                        CIVIL APPEAL NO. 4657 OF 2009
                                 J U D G M E N T
V. GOPALA GOWDA, J.
The present appeals arise out of the impugned common final judgment and order dated 16.05.2008
passed in Special Civil Application No. 4468 of 2008 etc. by the High Court of Gujarat at
Ahmedabad, wherein by a majority of 2:1, a Three Judge bench upheld the validity of the impugned
policy decision dated 06.03.2007 on the ground that the Union of India is competent to take the
policy decision and further it has held that it is either arbitrary, unjust or violative of the
fundamental rights of the appellants herein.
Since the facts in all these appeals raise the same issue for our consideration, for the sake of brevity,
we refer to the facts of Civil Appeal No.4610 of 2009. The necessary relevant facts required to
appreciate the rival legal contentions advanced on behalf of the parties are stated in brief hereunder:
India purchases natural gas from Gulf countries. Since gas in large quantities cannot
be feasibly transported by pipelines across countries, before such gas is transported,Essar Steel Ltd vs Union Of India & Ors on 19 April, 2016

it is liquefied and thereafter shipped to India. This liquefied gas is known as
Liquefied Natural Gas (hereinafter referred to as “LNG”). Once this liquefied gas
reaches India, it is converted into gas again. This is known as Regasified Liquefied
Natural Gas (hereinafter referred to as “RLNG”).
In the instant case, Ras Laffin Natural Gas Company Limited, Qatar (hereinafter
referred to as “RasGas”) sold LNG to Petronet LNG Limited (hereinafter referred to
as “Petronet”), an Indian company, which was set up as a Joint venture between the
Government of India and the key players in the LNG market like Oil and Natural Gas
Corporation (hereinafter referred to as “ONGC”), Indian Oil Corporation Limited
(hereinafter referred to as “IOCL”) and Bharat Petroleum Corporation Limited
(hereinafter referred to as “BPCL”). This was done under a Sale Purchase Agreement
entered in July, 1999 for a period of 25 years.
Petronet sold the resultant LNG to companies like BPCL, IOCL and GAIL. They in
turn, sold it to customers like Essar Steel, which is the appellant in Civil Appeal No.
4610 of 2009.
In the immediate context of the present appeals, Essar Steel signed contracts with
IOCL, BPCL and GSPCL for purchase of RLNG at a fixed price. The price was fixed
upto the date 31.12.2008. The Gas Supply Agreements were for the supply of 5
million metric tonnes per annum (MMTPA) at a fixed price of US $ 2.9412 per
million metric british thermal unit (MMBTU).
On 06.03.2007, the Central Government issued the impugned policy directive to
Petronet in the following terms:
“1. The question of prices to be charged for RLNG from different customers has been
under consideration of the Government. After considering existing practices and to
avoid loading high cost of additional RLNG being made available to the prospective
customers, it has been decided, after examination of all aspects, in public interest,
that the gas prices being charged on supply of RLNG procured under long term
contracts should be on a non discriminatory basis and uniform pooled prices should
be charged for all the existing and new customers.
2. You are advised accordingly and requested to give effect to the same immediately.” The letter was
authenticated by the Under Secretary to the Government of India.
In pursuant to the above communication dated 06.03.2007, letters dated 19.03.2007 and
12.04.2007 were sent from IOCL, BPCL and GAIL to Essar Steel, informing it that in view of the
policy decision of the Government to pool RLNG prices, the price of gas under the contract would be
revised and increased from Rs. 135 per MMBTU to Rs. 207.02 MMBTU.Essar Steel Ltd vs Union Of India & Ors on 19 April, 2016

Aggrieved, the appellant filed Writ Petition No. 5098 of 2007 before the High Court of Delhi,
challenging the impugned policy decision and the consequent action of IOCL, BPCL, GAIL and
GSPCL in unilaterally increasing the price of RLNG w.e.f. 01.08.2007, is in contravention of the gas
supply contracts which clearly stipulate the fixed price of US $ 2.93 per MMBTU of RLNG. Certain
other appellants had also filed Writ Petitions before the High Court of Gujarat urging various legal
grounds questioning the legality of the impugned policy decisions and the communications received
by them. In pursuant to which, the High Court passed an interim order granting stay of the
operation of the impugned policy decision. A Transfer Petition No. 513 of 2007 was filed before this
Court seeking for transfer of Writ Petition No. 5098 of 2007 from the High Court of Delhi to the
Gujarat High Court. Vide order dated 22.08.2007, this Court vacated the stay operating on the
impugned policy decision and transferred the Writ Petition No. 5098 of 2007 from Delhi High Court
to Gujarat High Court and directed the Division Bench of the Gujarat High Court to hear the batch
of Writ Petitions. The judges of the Division Bench could not concur on the opinion and vide order
dated 28.09.2007, referred the matter to a third judge. Vide order dated 12.10.2007, the single judge
opined not to grant any interim relief in favour of the appellants in their writ petitions. The Chief
Justice of the Gujarat High Court rejected the prayer of the appellants for stay of the operation of
the impugned policy vide order dated 17.10.2007. The appellants challenged the correctness of the
said order before this Court by way of filing SLP (C) Nos. 21397-99 of 2007. This Court vide its order
dated 26.02.2008 directed the High Court of Gujarat to list the Writ Petitions for final hearing
before a Three Judge bench. Vide impugned judgment and order dated 16.05.2008, by a majority of
2:1, the High Court upheld the impugned policy decision dated 06.03.2007 and dismissed the Writ
Petition filed by the appellant. The majority judgment opined as under:
“……Union of India, by Empowered Group of Ministers with advise of experts and
Secretaries of various departments of Union of India, has taken the decision of
pooling of price of Regasified Liquefied Natural Gas, on non- discriminatory basis
and thereby has put under one denomination, consumers of long term contracts and
future consumers. Parties to the contract cannot bind Union of India (third party) by
terms of contract…Policy of Union of India is not bound by contractual terms of two
private parties, on the contrary, contractual terms will be subject to policy decision by
Union of India…… As a cumulative effect of the aforesaid facts, reasons and judicial
pronouncement, the impugned decision taken by the Union of India dated
06.03.2007, is a policy decision for pooling price of Regasified Liquefied Natural Gas.
Union of India is competent to take this policy decision and the same is neither
arbitrary, nor it is unjust, nor violative of fundamental rights, nor violative of
constitutional rights nor the same is violative of statutory rights of the petitioners and
the petitioners have failed to establish that they have borne the burden of increase in
price of Regasified Liquefied Natural Gas without passing the same to their further
consumers, hence, are not entitle to refund. For getting refund, the aforesaid aspect
ought to be established by the petitioners, on the basis of evidence on record, either
in the suit or in the arbitration. There is no substance in these petitions, and,
therefore, all these petitions are hereby dismissed.” Hence, the present appeals.Essar Steel Ltd vs Union Of India & Ors on 19 April, 2016

Mr. Abhishek Manu Singhvi, learned senior counsel appearing on behalf of the appellant Essar Steel
in Civil Appeal No. 4610 of 2009 has questioned the correctness of the impugned judgment and
order passed by the High Court. It is contended by him that the contracts between the appellants
and off takers (IOCL, GPSCL) had three elements, viz., fixed price, for a fixed term, in respect of a
fixed basic quantity. The appellant is aggrieved by the fact that even with this limited five year
period and after having faithfully observed these frozen and unchangeable contractual parameters of
fixed term, fixed price and fixed quantity for almost four out of five years, the respondents reneged
and violated these fixed parameters in the last fourteen months of the contract, all for the benefit of
a single entity, that is the Ratnagiri Gas and Power Private Limited (hereinafter referred to as the
“Ratnagiri Power Project”).
The learned senior counsel further contends that executive actions of the Union of India which
operates to the prejudice of any person must necessarily have legislative backing. It is contended
that in the present case, no entity except the Ratnagiri Power Project was benefited as a result of the
change of policy by the Central Government.
The learned senior counsel in support of his legal submission places reliance on the decision of this
Court in the case of Delhi Development Authority v. Joint Action Committee, Allottee of SFS
Flats[1], wherein it has held as under:
“62. ……It is well known principle of law that a person would be bound by the terms
of the contract subject of course to its validity. A contract in certain situations may
also be avoided. With a view to make novation of a contract binding and in particular
some of the terms and conditions thereof, the offeree must be made known
thereabout. A party to the contract cannot at a later stage, while the contract was
being performed, impose terms and conditions which were not part of the offer and
which were based upon unilateral issuance of office orders, but not communicated to
the other party to the contract and which were not even the subject matter of a public
notice.
67. The stand taken by DDA itself is that the relationship between the parties arises
out of the contract. The terms and conditions therefore were, therefore, required to
be complied with by both the parties. Terms and conditions of the contract can
indisputably be altered or modified.
They cannot, however, be done unilaterally unless there exists any provision either in contract itself
or in law. Novation of contract in terms of Section 60 of the Contract Act must precede the contract
making process. The parties thereto must be ad idem so far as the terms and conditions are
concerned. If DDA, a contracting party, intended to alter or modify the terms of contract, it was
obligatory on its part to bring the same to the notice of the allocate. Having not done so, it, relying
on or on the basis of the purported office orders which is not backed by any statute, new terms of
contract could thrust upon the other party to the contract. The said purported policy is, therefore,
not beyond the pale of judicial review. In fact, being in the realm of contract, it cannot be stated to
be a policy decision as such.” The learned senior counsel further contends that executive action ofEssar Steel Ltd vs Union Of India & Ors on 19 April, 2016

the Union of India, when it seeks to prejudice the rights of a person, must have the backing of a
statute. The learned senior counsel in support of the above contention places reliance on the
decision of a Constitution Bench of this Court in the case of State of Madhya Pradesh v. Thakur
Bharat Singh[2], wherein it was held as under:
“We have adopted under our Constitution not the continental system but the British
system under which the rule of law prevails. Every Act done by the Government or by
its officers must, if it is to operate to the prejudice of any person, be supported by
some legislative authority.” Another Constitution Bench of this Court, in the case of
Bishan Das v. State of Punjab[3], held as under:
“As pointed out by this Court in Wazir Chand v. The State of Himachal Pradesh 1954
Cri LJ 1029, the State or its executive officers cannot interfere with the rights of
others unless they can point to some specific rule of law which authorises their acts.
In Ram Prasad Narayan Sahi v. The State of Bihar [1953]4 SCR 1129 this Court said
that nothing is more likely to drain the vitality from the rule of law than legislation
which singles out a particular individual from his fellow subjects and visits him with a
disability which is not imposed upon the others.” The learned senior counsel further
places reliance on yet another constitution bench decision of this Court in the case of
Satwant Singh Sawhney v. D. Ramarathnam, Asstt. Passport Officer[4], wherein it
was held as under:
“Article 14 says that the State shall not deny to any person equality before the law or
the equal protection of the laws within the territory of India. This doctrine of equality
before the low is a necessary corollary to the high concept of the rule of law accepted
by our Constitution. One of the aspects of rule of law is that every executive action, if
it is to operate to the prejudice of any person, must be supported by some legislative
authority.” Placing strong reliance on the cases cited above, the learned senior
counsel contends that the impugned policy decision of the Union of India has no
statutory flavour, as price pooling has been implemented neither through statute nor
delegated legislation.
The learned senior counsel further contends that the impugned policy decision is an
executive action benefitting a single person, namely Ratnagiri Power Project. Thus,
this is on a worse footing than single person legislation, as it is a single person
executive action. The learned senior counsel places reliance on the decision of a
Constitution Bench of this Court in support of the above legal plea urged by him in
the case of Ram Prasad Narayan Sahi v. The State of Bihar[5] , wherein it was held as
under:
“There have been a number of decisions by this court where the question regarding
the nature and scope of the guarantee implied in the equal protection clause of the
Constitution came up for consideration and the general principles can be taken to be
fairly well settled. What this clause aims at is to strike down hostile discrimination orEssar Steel Ltd vs Union Of India & Ors on 19 April, 2016

oppression or inequality. As the guarantee applies to all persons similarly situated, it
is certainly open to the legislature to classify persons and things to achieve particular
legislative objects; but such selection or differentiation must not be arbitrary and
should rest upon a rational basis, having regard to the object which the legislature
has in view. It cannot be disputed that the legislation in the present case has singled
out two individuals and one solitary transaction entered into between them and
another private party, namely, the Bettiah Wards Estate and has declared the
transaction to be a nullity on the ground that it is contrary to the provisions of law,
although there has been no adjudication on this point by any judicial tribunal. It is
not necessary for our present purpose to embark upon a discussion as to how far the
doctrine of 'separation of powers has been recognised in our Constitution and
whether the legislature can arrogate to itself the powers of the judiciary and proceed
to decide disputes between private parties by making a declaration of the rights of
one against the other. It is also unnecessary to attempt to specify the limits within
which any legislation, dealing with private rights, is possible within the purview of
our Constitution. On one point our Constitution is clear and explicit, namely, that no
law is valid which takes away or abridges the fundamental rights guaranteed under
Part III of the Constitution. There can be no question, therefore, that it the legislation
in the present case comes within the mischief of article 14 of the Constitution, it has
got to be declared invalid.” The learned senior counsel contends that Government
action, more so executive action, which is not subjected to democratic debate in the
Parliament, benefitting or burdening a single person or entity ought to be viewed as
especially pernicious and discriminatory, and ought to be treated as such, especially
while scrutinizing such action under the lens of Article 14 of the Constitution. It is
submitted that in the instant case, it is not a legislative action which has marked out
the Ratnagiri Power Project for a special benefit; this is a single person executive
action, which is on an even weaker footing.
The learned senior counsel further contends that price fixation is a legislative
function and in support of this contention he places reliance on the Seven Judge
Bench decision of this Court in the case of Prag Ice & Oil Mills v. Union of India[6],
wherein it was held as under: “We think that unless, by the terms of a particular
statute, or order, price fixation is made a quasi-judicial function for specified
purposes or cases, it is really legislative in character….” Further, it was held in the
case of Union of India v. Cynamide India Ltd[7] that:
“7.The third observation we wish to make is, price fixation is more in the nature of a
legislative activity than any other. It is true that, with the proliferation of delegated
legislation, there is a tendency for the line between legislation and administration to
vanish into an illusion. Administrative, quasi-judicial decisions tend to merge in
legislative activity and, conversely, legislative activity tends to fade into and present
an appearance of an administrative or quasi-judicial activity. Any attempt to draw a
distinct line between legislative and administrative functions, it has been said, is
'difficult in theory and impossible in practice'. Though difficult, it is necessary thatEssar Steel Ltd vs Union Of India & Ors on 19 April, 2016

the line must sometimes be drawn as different legal rights and consequences may
ensue. The distinction between the two has usually been expressed as 'one between
the general and the particular'. 'A legislative act is the creation and promulgation of a
general rule of conduct without reference to particular cases; an administrative act is
the making and issue of a specific direction or the application of a general rule to a
particular case in accordance with the requirements of policy'. 'Legislation is the
process of formulating a general rule of conduct without reference to particular cases
and usually operating in future; administration is the process of performing
particular acts, of issuing particular orders or of making decisions which apply
general rules to particular cases.' It has also been said "Rule making is normally
directed toward the formulation of requirements having a general application to all
members of a broadly identifiable class" while, "adjudication, on the other hand,
applies to specific individuals or situations". But, this is only a bread distinction, not
necessarily always true. Administration and administrative adjudication may also be
of general application and there may be legislation of particular application only.
That is not ruled out. Again, adjudication determines past and present facts and
declares rights and liabilities while legislation indicates the future course of action.
Adjudication is determinative of the past and the present while legislation is
indicative of the future. The object of the rule, the reach of its application, the rights
and obligations arising out of it, its intended effect on past, present and future events,
its form, the manner of its promulgation are some factors which may help in drawing
the line between legislative and non- legislative acts. A price fixation measure does
not concern itself with the interests of an individual manufacturer or producer. It is
generally in relation to a particular commodity or class of commodities or
transactions. It is a direction of a general character, not directed against a particular
situation. It is intended to operate in the future. It is conceived in the interests of the
general consumer public. The right of the citizen to obtain essential articles at fair
prices and the duty of the State to so provide them are transformed into the power of
the State to fix prices and the obligation of the producer to charge no more than the
price fixed. Viewed from whatever angle, the angle of general application the
prospectively of its effect, the public interest served, and the rights and obligations
flowing therefrom, there can be no question that price fixation is ordinarily a
legislative activity. Price-fixation may occasionally assume an administrative or
quasi-judicial character when it relates to acquisition or requisition of goods or
property from individuals and it becomes necessary to fix the price separately in
relation to such individuals. Such situations may arise when the owner of property or
goods is compelled to sell his property or goods to the Government or its nominee
and the price to be paid is directed by the legislature to be determined according to
the statutory guidelines laid down by it. In such situations the determination of price
may acquire a quasi-judicial character. Otherwise, price fixation is generally a
legislative activity. We also wish to clear a misapprehension which appears to prevail
in certain circles that price-fixation affects the manufacturer or producer primarily
and therefore fairness requires that he be given an opportunity and that fair
opportunity to the manufacturer or producer must be read into the procedure forEssar Steel Ltd vs Union Of India & Ors on 19 April, 2016

price- fixation. We do not agree with the basic premise that price fixation primarily
affects manufacturers and producers. Those who are most vitally affected are the
consumer public. It is for their protection that price- fixation is resorted to and any
increase in price affects them as seriously as any decrease does a manufacturer, if not
more.” The learned senior counsel further urged that the impugned policy decision
was nothing but a means to provide subsidized gas to the Ratnagiri Power Project. If
the ultimate intention of the Union of India was to provide subsidized gas to the
Ratnagiri Power Project, then the cost of the same should have been borne by Union
of India itself and not by entities like the appellants.
Mr. Ravindra Srivastava, learned senior counsel appearing on behalf of the appellant
in Civil Appeal No. 4657 of 2009 contends that the government, a third party to the
contract, in purported exercise of its executive power under Article 73 of the
Constitution, cannot interfere with, much less alter the terms and conditions of the
contract between the two private parties.
The learned senior counsel further contends that the power to unilaterally alter the
terms and conditions of an agreement is not available even to a party to a contract
and such a unilateral exercise affects the integrity of the contract and therefore it is
illegal. Since the impugned policy decision directly results in infringement of the legal
rights of a private party governed by the contract, it can be done only with the
support of validly enacted law. The learned senior counsel places reliance in support
of the above plea on a Constitution Bench decision of this Court in the case of
Maganbhai Ishwarbhai Patel v. Union of India[8] wherein it was held as under:
“If, in consequence of the exercise of executive power, rights of the citizens or others
are restricted or infringed, or laws are modified, the exercise of power must be
supported by legislation : where there, is no such restriction, infringement of the
right or modification of the laws, the executive is competent to exercise the power.”
The learned senior counsel further contends that the communication dated
06.03.2007 is not a policy decision and merely attaching the label of ‘policy’ and
therefore, it does not make it a policy decision. Reliance is placed on the decision of
this Court in the case of Jaipur Development Authority v. Vijay Kumar Data &
Anr.[9], wherein it was held as under: “49. It is trite to say that all executive actions
of the Government of India and the Government of a State are required to be taken in
the name of the President or the Governor of the State concerned, as the case may be
[Articles 77(1) and 166(1)]. Orders and other instruments made and executed in the
name of the President or the Governor of a State, as the case may be, are required to
be authenticated in such manner as may be specified in rules to be made by the
President or the Governor, as the case may be [Articles 77(2) and 166(2)].
52. ……Article 166(1) requires that all executive action of the State Government shall
be expressed to be taken in the name of the Governor. This clause relates to cases
where the executive action has to be expressed in the shape of a formal order orEssar Steel Ltd vs Union Of India & Ors on 19 April, 2016

notification. It prescribes the mode in which an executive action has to be expressed.
Noting by an official in the departmental file will not, therefore, come within this
article nor even noting by a Minister. Every executive decision need not be as laid
down under Article 166(1) but when it takes the form of an order it has to comply
with Article 166(1). Article 166(2) states that orders and other instruments made and
executed under Article 166(1), shall be authenticated in the manner prescribed. While
Clause (1) relates to the mode of expression, Clause (2) lays down the manner in
which the order is to be authenticated and Clause (3) relates to the making of the
rules by the Governor for the more convenient transaction of the business of the
Government. A study of this article, therefore, makes it clear that the notings in a file
get culminated into an order affecting right of parties only when it reaches the head
of the department and is expressed in the name of the Governor, authenticated in the
manner provided in Article 166(2).
53. It is thus clear that unless an order is expressed in the name of the President or
the Governor and is authenticated in the manner prescribed by the rules, the same
cannot be treated as an order made on behalf of the Government. A reading of letter
dated 6.12.2001 shows that it was neither expressed in the name of the Governor nor
it was authenticated manner prescribed by the Rules. That letter merely speaks of the
discussion made by the Committee and the decision taken by it. By no stretch of
imagination the same can be treated as a policy decision of the Government within
the meaning of Article 166 of the Constitution.” Further reliance has been placed by
him on a Three Judge bench decision of this Court in the case of G.J. Fernandes v.
State of Mysore[10], wherein it was held as under:
“12……Of course, under such executive power, the State can give administrative
instructions to its servants how to act in certain circumstances; but that will not make
such instructions statutory rules which are justifiable in certain circumstances. In
order that such executive instructions have the force of statutory rules it must be
shown that they have been issued either under the authority conferred on the State
Government by some statute or under some provision of the Constitution providing
therefore.” More recently, this Court has observed in the case of Lala Ram v. Jaipur
Development Authority[11] as under:
“At the same time where however, a power or authority is conferred with a direction
that certain regulation or formality shall be complied with, it would neither be unjust
nor incorrect to exact a rigorous observance of it as essential to the acquisition of the
right of authority.” The learned senior counsel contends that the Empowered Group
of Ministers (EGOM) was supposed to recommend the restructuring of the Ratnagiri
Power Project. There was nothing to say that it was empowered to restructure the
prices of gas as well. The Rules of Business requires that executive action is taken in a
manner in accordance with the law. The learned senior counsel further draws our
attention to the provisions of the Government of India (Transaction of Business)
Rules, 1961 (hereinafter referred to as the “Business Rules”), extracted as under:Essar Steel Ltd vs Union Of India & Ors on 19 April, 2016

“3. Disposal of Business by Ministries.- Subject to the provisions of these Rules in
regard to consultation with other departments and submission of cases to the Prime
Minister, the Cabinet and its Committees and the President, all business allotted to a
department under the Government of India (Allocation of Business) Rules, 1961,
shall be disposed of by, or under the general or special directions of, the
Minister-in-charge.
6. Committees of the Cabinet.- (1) There shall be Standing Committees of the Cabinet
as set out in the First Schedule to these Rules with the functions specified therein.
The Prime Minister may from time to time amend the Schedule by adding to or
reducing the numbers of such Committees or by modifying the functions assigned to
them. (2) Each Standing Committee shall consist of such Ministers as the Prime
Minister may from time to time specify. (3) Subject to the provisions of rule 7, each
Standing Committee shall have the power to consider and take decisions on matters
referred to it by order of the Minister concerned or by the Cabinet.” The learned
senior counsel contends that the policy directives have been issued by the Union of
India in violation of the Business Rules. Under the said Business Rules, the power of
disposal of business of the Department is vested in the Minister-in-charge. The
EGOM is neither a Committee of Cabinet nor Standing Committee within the
meaning of Rule 6 of the Business Rules. The learned senior counsel contends that
nothing has been placed on record either before the High Court or this Court to show
any ‘authorisation’ to the EGOM for taking decision on the matters of price fixation.
The EGOM did not have the mandate to decide as regards the price of the LNG under
the existing contract.
Mr. Shyam Diwan, the learned senior counsel appearing on behalf of GSPCL in Civil Appeal No.
4609 of 2009 contends that the power to issue the impugned policy decision by the Central
Government is an independent one and it does not depend on the individual contracts between the
parties. In the instant case, the impugned directive issued to Petronet has resulted in a domino
effect, all the way down to the last purchaser. The learned senior counsel contends that the
impugned policy decision affects the rights of the consumers without any statutory backing and is
therefore bad in law liable to be quashed. The learned senior counsel places reliance on the decision
of this Court in the case of Central Dairy Farm v. GI India Ltd. & Ors.[12], wherein it was held as
under :-
“The power of State Government to fix prices of milk and milk products by issuance
of notification under Section 15 of the Milk Act is merely an enabling one, and it is
not obligatory for State Government in all circumstances to fix the prices. In the
instant case, the prices of cream and paneer were fixed through mutual negotiations
between authorised representatives of the two companies and with the assistance of
the authorities of the state. Such binding terms of agreement reached between the
two companies could not be frustrated by statutory intervention of the State by
issuance of notification for fixation of prices under Section 15 of the Act. As has been
pointed out by the State the notification was intended to apply only to respondentEssar Steel Ltd vs Union Of India & Ors on 19 April, 2016

Glindia Ltd. as the supplies of cream and paneer were being made to the appellant
Central Fairy Farm by the Glindia Ltd. alone.” The learned senior counsel further
contends that change in policy can be no defence for breaching contract. Similarly, by
mere issuance of a policy directive, the government cannot direct parties to breach
the terms of the contract negotiated among themselves. As long as the policy directs
variation in the existing arrangements or destroys contracts, the same is violative of
Article 14 of the Constitution of India.
On the other hand, Mr. Ranjit Kumar, learned Solicitor General for India contends
that the price of LNG is linked directly to the price of crude oil, the appellants are
ignoring the benefit they were getting as a result of the efforts by the Government of
India.
The learned Solicitor General contends that a policy cannot be vitiated only on the
ground of change. Reliance in placed on the decision of a Three Judge bench of this
Court in the case of Shimnit Utsch India Pvt. Ltd. & Anr v. West Bengal Transport
Infrastructure Development Corporation Ltd. & Ors[13], wherein it was held as
under:
“52…The courts have repeatedly held that government policy can be changed with
changing circumstances and only on the ground of change, such policy will not be
vitiated. The government has discretion to adopt a different policy or alter or change
its policy calculated to serve public interest and make it more effective. Choice in the
balancing of the pros and cons relevant to the change in policy lies with the authority.
But like any discretion exercisable by the government or public authority, change in
policy must be in conformity with Wednesbury reasonableness and free from
arbitrariness, irrationality, bias and malice.” In the case of Union of India & Anr. v.
International Trading Co. & Anr.[14], this Court held as under:
“14. It is trite law that Article 14 of the Constitution applies also to matters of
governmental policy and if the policy or any action of the Government, even in
contractual matters, fails to satisfy the test of reasonableness, it would be
unconstitutional.
15. While the discretion to change the policy in exercise of the executive power, when
not trammelled by any statute or rule is wide enough, what is imperative and implicit
in terms of Article 14 is that a change in policy must be made fairly and should not
give impression that it was so done arbitrarily on by any ulterior criteria. The wide
sweep of Article 14 and the requirement of every State action qualifying for its validity
on this touchstone irrespective of the field of activity of the State is an accepted tenet.
The basic requirement of Article 14 is fairness in action by the state, and
non-arbitrariness in essence and substance is the heart beat of fair play. Actions are
amenable, in the panorama of judicial review only to the extent that the State must
act validly for a discernible reasons, not whimsically for any ulterior purpose. TheEssar Steel Ltd vs Union Of India & Ors on 19 April, 2016

meaning and true import and concept of arbitrariness is more easily visualized than
precisely defined. A question whether the impugned action is arbitrary or not is to be
ultimately answered on the facts and circumstances of a given case. A basic and
obvious test to apply in such cases is to see whether there is any discernible principle
emerging from the impugned action and if so, does it really satisfy the test of
reasonableness.” The learned Solicitor General has also sought to explain the reason
for the change in policy. He has taken us through the history of the two Sale Purchase
Agreements between Petronet and RasGas. On the First Agreement, it has been
stated in the Reply filed by Petronet as under:
“3.3……The first LNG SPA was signed on 31.07.1999 for supply of 5 MMTPA of LNG
for a period of 25 years commencing from January 2004. Originally, the foreign
currency component (FCC) of the LNG price under the First LNG SPA was intended
to be market driven and hence variable. However, Respondent No.1 took up the issue
with the State of Qatar and brought about a fixed FCC for a period of five years
ending 31.12.2008, whereby FCC under First LNG SPA was fixed at USD 2-3 upto
31.12.2008 based on crude price of USD 20 per barrel. This has been agreed between
RasGas and the answering respondent by way of a Side Letter dated 26.09.2003 to
the First LNG SPA. A new price regime would come into effect from 01.01.2009
under which the LNG price would have a link to the market prices, and would vary
each month. 3.4 The answering respondent has an obligation to sell RLNG, produced
from imported LNG under the First LNG SPA, to the Off-takers for onward sale to the
downstream customers. Hence, corresponding to the First LNG SPA, the answering
respondent also signed separate GSPAs with each of the three off-
takers, viz, GAIL, IOC and BPCL ON 26.09.2003 for the sale of 5 MMTPA of RLNG. FCC under the
First GSPA was also fixed at USD 2-3 per MMBTU.” Since the new price regime was to come into
effect on 01.01.2009, Petronet started negotiating with RasGas from 2007 for additional supply of
LNG under a term contract. The new Agreement was signed on 03.07.2007. The FCC of the LNG
prices under this agreement was fixed at USD 8-9 per MMBTU for a total of 1.5 MMTPA and was to
remain so until 31.12.2008. The benefit of the executive policy direction dated 06.03.2007 has been
explained in the following terms:
“3.5 In early 2007, the answering respondent was negotiating with RasGas for
additional supplies of LNG under a term contract. Pursuant thereto a fresh LNG SPA
was signed between RasGas and the answering respondent on 03.07.2007 for
additional supply of 1.5 MMTPA of LNG. The FCC of the LNG price under the Second
LNG SPA is USD 8-9 per MMBTU and will remain so until 31.12.2008.
3.6 In the meantime, GOI had issued its policy directive by communication dated
06.03.2007. In terms of the said policy directive, RLNG procured under long term
contracts is to have a uniform non-discriminatory pooled price based on weighted
average which is binding on the Off-takers. The only long term RLNG contracts
upstream as on this date, was between the answering respondent and the Off-takersEssar Steel Ltd vs Union Of India & Ors on 19 April, 2016

under the First GSPA. 3.7 ……In the absence of the price pooling policy, the FCC of
1.5 MMTPA of RLNG under the Second GSPA would also have been USD 8-9 per
MMBTU…However, in view of the uniform price pooling directive, which was
binding on the Off-takers, FCC under the Second GSPA has been fixed at USD 4.32
per MMBTU.
The uniform pooled price of USD 4.32 per MMBTU was arrived at by taking the weighted average of
the FCC of USD 2-3 for 5 MMTPA and USD 8-9 for 1.5 MMTPA. The answering respondent has
facilitated implementation of the policy by pooling the RLNG prices under the First and Second
GSPA’s vis-à- vis the Off-takers.” Mr. Gourab Banerji, the learned senior counsel appearing on
behalf of respondent-GAIL in Civil Appeal No. 4610 of 2009 contends that not only Ratnagiri Power
Limited, but several other Public Sector Undertakings would benefit as a result of the pooling of
prices. Thus, it is the larger public interest which must be considered.
The learned senior counsel further contends that the claim of the appellants cannot be sustained in
law as they have already passed the burden of the increase in the price on to their customers. The
learned senior counsel places reliance on the decision of this Court in the case of Sahakari Khand
Udyog Mandal Ltd. v. CCE & Customs[15],wherein the concept of unjust enrichment was elaborated
as under:
“Stated simply, 'Unjust enrichment' means retention of a benefit by a person that is
unjust or inequitable. 'Unjust enrichment' occurs when a person retains money or
benefits which in justice, equity and good conscience, belong to someone else.
The doctrine of 'unjust enrichment', therefore, is that no person can be allowed to
enrich inequitably at the expense of another. A right of recovery under the doctrine of
'unjust enrichment' arises where retention of a benefit is considered contrary to
justice or against equity.” Mr. Tushar Mehta, learned Additional Solicitor General
appearing on behalf of the respondents in Civil Appeal Nos. 4609 and 4657 of 2009
contends that the pooled prices came into effect on 29.08.2007 and remained in
effect till 31.12.2008. What is under consideration in the present appeals is the
impact of the pooling price policy supplied to the consumers between 29.08.2007
and 31.12.2008. The only relief that the appellants in the present case can claim is
that of refund of the differential prices paid by them. The learned Additional Solicitor
General contends that this claim also cannot succeed, since the appellants already
passed on the burden to the consumers and payment of differential prices to them
would result in unjust enrichment. The learned ASG places reliance on the nine judge
bench decision of this Court in the case of Mafatlal Industries Ltd. v. Union of
India[16], wherein it was held as under:
“105. It would be evident from the above discussion that the claims for refund under
the said two enactments constitute an independent regimen. Every decision
favourable to an assessee/manufacturer, whether on the question of classification,
valuation or any other issue, does not automatically entail refund. Section 11-B of theEssar Steel Ltd vs Union Of India & Ors on 19 April, 2016

Central Excises and Salt Act and Section 27 of the Contract Act, whether before or
after 1991 Amendment - as interpreted by us herein - make every refund claim
subject to proof of not passing-on the burden of duty to others. Even if a suit is filed,
the very same condition operates. Similarly, the High Court while examining its
jurisdiction under Article 226 - and this Court while acting under Article 32 - would
insist upon the said condition being satisfied before ordering refund. Unless the
claimant for refund establishes that he has not passed on the burden of duty to
another, he would not be entitled to refund, whatever be the proceeding and
whichever be the forum. Section 11-B/Section 27 are constitutionally valid, as
explained by us hereinbefore. They have to be applied and followed implicitly
wherever they are applicable.” The learned Additional Solicitor General further
contends that there is nothing on record to suggest that the appellants had suffered
any loss during the relevant period. It is further submitted that the Union of India is
well within its right to take a policy decision in public interest. This policy decision
has been taken after taking into consideration all relevant factors and is in
consonance with the principles enshrined in Article 14 of the Constitution of India.
The learned ASG further contends that the uniform price pooling policy is within the
executive powers vested with the Union of India under Articles 73 and 246 read with
Entry 53 of List I of Seventh Schedule of the Constitution of India, as also Rules 2 & 3
(1) and Items 2, 6 and 8 in the Second Schedule to the Government of India
Allocation of Business Rules, 1961. The learned Additional Solicitor General further
contends that there is no vested right in price, that it cannot be raised at all. It was
infact only the intervention of the government that ensured availability of the natural
resources at a lower rate. The policy also provides for a level playing field and a non
discriminatory regime.
We have heard the learned counsel appearing on behalf of the parties. The main issue
which arises for our consideration is whether impugned policy decision dated
06.03.2007 is bad in law, and if so, whether the appellants are entitled to any refund
of the amount paid by them as a result of increase in price of RLNG after the
impugned policy decision dated 06.03.2007.
Before we examine the validity of the impugned policy decision dated 06.03.2007, it
is important to examine clause 11.4 of the Supply Agreement between IOCL and
Essar Steel which reads as under:
“11.4 Change in Law If at any time due to a change in law or a change in the policy of
any Government…………seller incurs am increase or decrease in its costs or expenses,
the seller may request a revision of the Contract Price to reflect any such increase or
decrease and the Contract Price shall stand so increased or decreased. Such increased
or decreased Contract Price shall be reflected in the immediate following Invoice.” A
similar clause has been incorporated in the other agreements as well. It becomes
clear from a perusal of the aforementioned clause that price revision on account of
change in government policy is a situation which had been envisaged by the partiesEssar Steel Ltd vs Union Of India & Ors on 19 April, 2016

themselves at the time of entering into the Supply Agreement.
Before we can examine the validity of the impugned policy decision dated
06.03.2007, it is crucial to understand the extent of the power vested with this Court
to review policy decisions.
In the case of Delhi Development Authority (supra) on issue of judicial review of policy decisions,
the power of the court is examined and observed as under:
“An executive order termed as a policy decision is not beyond the pale of judicial
review. Whereas the superior courts may not interfere with the natty grittiest of the
policy, or substitute one by the other but it will not be correct to contend that the
court shall like its judicial hands off, when a plea is raised that the impugned decision
is a policy decision. Interference therewith on the part of the superior court would
not be without jurisdiction as it is subject to judicial review. Broadly, a policy decision
is subject to judicial review on the following grounds:
(a) if it is unconstitutional;
(b) if it is de'hors the provisions of the Act and the Regulations;
(c) if the delegatee has acted beyond its power of delegation;
(d) if the executive policy is contrary to the statutory or a larger policy.” Thus, we will
test the impugned policy on the above grounds to determine whether it warrants our
interference under Article 136 or not. Further, this Court neither has the jurisdiction
nor the competence to judge the viability of such policy decisions of the Government
in exercise of its appellate jurisdiction under Article 136 of the Constitution of India.
In the case of Arun Kumar Agrawal v. Union of India[17], this Court has further held
as under:
“This Court sitting in the jurisdiction cannot sit in judgment over the commercial or
business decision taken by parties to the agreement, after evaluating and Assessing
its monetary and financial implications, unless the decision is in clear violation of any
statutory provisions or perverse or for extraneous considerations or improper
motives. States and its instrumentalities can enter into various contracts which may
involve complex economical factors. State or the State undertaking being a party to a
contract, have to make various decisions which they deem just and proper. There is
always an element of risk in such decisions, ultimately it may turn out to be a correct
decision or a wrong one. But if the decision is taken bona fide and in public interest,
the mere fact that decision has ultimately proved to be a wrong, that itself is not a
ground to hold that the decision was mala fide or done with ulterior motives.”
(emphasis laid by this Court) In the case of Villianur Iyarkkai Padukappu Maiyam v.
Union of India[18], it was held as under:Essar Steel Ltd vs Union Of India & Ors on 19 April, 2016

“It is neither within the domain of the courts nor the scope of judicial review to
embark upon an enquiry as to whether a particular public policy is wise or whether
better public policy can be evolved. Nor are the courts inclined to strike down a policy
at the behest of a Petitioner merely because it has been urged that a different policy
would have been fairer or wiser or more scientific or more logical. Wisdom and
advisability of economic policy are ordinarily not amenable to judicial review. In
matters relating to economic issues the Government has, while taking a decision,
right to "trial and error" as long as both trial and error are bona fide and within the
limits of the authority. For testing the correctness of a policy, the appropriate forum
is Parliament and not the courts.” (emphasis laid by this Court) A Three Judge bench
of this Court in the case of Narmada Bachao Andolan v. Union of India[19] cautioned
against Courts sitting in appeal against policy decisions. It was held as under:
“234.In respect of public projects and policies which are initiated by the Government
the Courts should not become an approval authority. Normally such decisions are
taken by the Government after due care and consideration. In a democracy welfare of
the people at large, and not merely of a small section of the society, has to be the
concern of a responsible Government. If a considered policy decision has been taken,
which is not in conflict with any law or is not mala fide, it will not be in Public
Interest to require the Court to go into and investigate those areas which are the
function of the executive. For any project which is approved after due deliberation
the Court should refrain from being asked to review the decision just because a
petitioner in filing a PIL alleges that such a decision should not have been taken
because an opposite view against the undertaking of the project, which view may
have been considered by the Government, is possible. When two or more options or
views are possible and after considering them the Government takes a policy decision
it is then not the function of the Court to go into the matter afresh and, in a way, sit in
appeal over such a policy decision.” (emphasis laid by this Court) A similar sentiment
was echoed by a Constitution Bench of this Court in the case of Peerless General
Finance & Investment Co. Ltd. v. Reserve Bank of India[20], wherein it was observed
as under:
“Courts are not to interfere with economic policy which is the function of experts. It is
not the function of the Courts to sit in Judgment over matters of economic policy and
it must necessarily be left to the expert bodies. In such matters even experts can
seriously and doubtlessly differ. Courts cannot be expected to decide them without
even the aid of experts.” A perusal of the above mentioned judgments of this Court
would show that this Court should exercise great caution and restraint when
confronted with matters related to the policy regarding commercial matters of the
country. Executive policies are usually enacted after much deliberation by the
Government. Therefore, it would not be appropriate for this Court to question the
wisdom of the same, unless it is demonstrated by the aggrieved persons that the said
policy has been enacted in an arbitrary, unreasonable or malafide manner, or that it
offends the provisions of the Constitution of India.Essar Steel Ltd vs Union Of India & Ors on 19 April, 2016

Entry 53 of List I of Seventh Schedule to the Constitution of India reads thus:
“53. Regulation and development of oilfields and mineral oil resources petroleum and
petroleum products; other liquids and substances declared by Parliament by law to
be dangerously inflammable.” In the case of Association of Natural Gas v. Union of
India[21], the question which arose for consideration of this Court was whether
liquefied natural gas is a petroleum product or not. After adverting to several
authorities on the subject, this Court concluded as under: “All the materials produced
before us would only show that the natural gas is a petroleum product. It is also
important to note that in various legislations covering the field of petroleum and
petroleum products, either the word 'petroleum' or 'petroleum products' has been
defined in an inclusive way, so as to include natural gas. In Encyclopaedia Britannica,
15 th Edn. Vol. 19, page 589 (1990), it is stated that "liquid and gaseous hydrocarbons
are so intimately associated in nature that it has become customary to shorten the
expression 'petroleum and natural gas' to 'petroleum' when referring to both." The
word petroleum literally means 'rock oil'. It originated from the Latin term
petra-oleum. (petra-means rock or stone and oleum-means oil). Thus, Natural Gas
could very well be comprehended within the expression 'petroleum' or 'petroleum
product…… Under Entry 53 of List I, Parliament has got power to make legislation for
regulation and development of oil fields, mineral oil resources; petroleum, petroleum
products, other liquids and substances declared by Parliament by law to be
dangerously inflammable. Natural gas product extracted from oil wells is
predominantly comprising of methane. Production of natural gas is not independent
of the production of other petroleum products; though from some wells the natural
gas alone would emanate, other products may emanate from subterranean chambers
of earth. But all oil fields are explored for their potential hydrocarbon. therefore, the
regulation of oil fields and mineral oil resources necessarily encompasses the
regulation as well as development of natural gas. For free and smooth flow of trade,
commerce and industry throughout the length and breadth of the country, natural
gas and other petroleum products play a vital role…… Natural gas being a petroleum
product, we are of the view that under Entry 53 List I, Union Govt. alone has got
legislative competence.” (emphasis laid by this Court) Thus, by virtue of Article 73 of
the Constitution of India read with Entry 53 of List I, the Union has the power to
legislate and take policy decisions in relation to the matters pertaining to mineral oil
resources and inflammable substances, which includes RLNG. Further, as has been
correctly recorded in the impugned judgment and order, there is no existing
legislative provision as far as fixing of the price of RLNG is concerned.
Thus, the executive of the Union of India is well within its right to exercise its powers under the
Constitution to take such decisions by way of policy decisions.
The objective of the impugned policy decision dated 06.03.2007 is to unify the prices of RLNG on a
non-discriminatory basis so that there is no distinction between old customers and new customers,
as far as prices of RLNG in the long term contracts is concerned. In the counter affidavit filed by theEssar Steel Ltd vs Union Of India & Ors on 19 April, 2016

respondent-Union of India, the rationale behind unifying the prices of RLNG has been explained as
under:
“The power sector continues to be one of the major consumers of Natural Gas. The
intent of the answering respondent is to ensure power generation costs are
maintained at reasonable rate. In this regard, a brief reference to the Dabhol power
project and the Pragati II & III Power Projects, which are gas based power projects is
relevant. The answering respondent has attached a lot of importance to the revival of
the Dabhol power project and has constituted an Empowered Group of Ministers for
this purpose. RGPPL was formed to ta ke over and revive the Dabhol project. It was
recognized that the pricing of gas is a critical factor in revival of the project, which
was beset with a number of complexities. A huge sum of Rs. 10,038 crores of public
money has already gone into the Dabhol project………The Dabhol project on which
more than Rs. 10,000 crores of public money is riding, has been restructured in
larger public interest………the viability of the project is dependent on RLNG being
available at affordable prices. If RLNG, which is the base fuel for the Dabhol power
project, is not made available to RGPPL at a reasonable price, the power produced
would be unaffordable and consequently, would lead to the shut-down of the Dabhol
power plant. This would mean more than Rs. 10,000 crores of public money going
down the drain. The answering respondent has a duty to prevent such a catastrophic
effect, as it is bound to have a cascading effect on the overall economy of India.
……However, the prevalent cost of LNG is very high (about USD 8-9 per MMBTU),
and if RGPPL had to purchase RLNG based on such market price, it would result in
exponential increase in the cost of power, produced by the plant. Such cost of power
would be prohibitively expensive and would have no buyers, making the entire
Dabhol project unviable.
In the circumstances, the answering respondent was of the view that the high cost of RLNG should
not be loaded on to new customers alone and attempts should be made to provide RLNG to all the
customers, whether existing or new, including RGPPL at a uniform average pooled price.” (emphasis
laid by this Court) A perusal of the above paragraph would show that the respondent-Union of India
passed the impugned policy decision dated 06.03.2007 in the larger public interest, keeping in view
the need to provide RLNG at viable prices to the existing and new customers alike. It is further clear
that it is nearly impossible to predict or even control LNG prices, as the same are controlled by
global market forces. The only way to have any semblance of control over the prices of RLNG was to
pool the prices of RLNG procured by the off-takers under long term contracts.
We have perused the documents marked as Annexures R-3 to R-15, which are the letters containing
the communication between the government and RasGas.
Annexure R-6 is the minutes of meeting dated 05.06.2002 regarding finalization of the General Sale
Purchase Agreement, held in the office of the Secretary, Ministry of Petroleum and Natural Gas. The
meeting was attended by representatives of Ministry of Petroleum and Natural Gas, ONGC, IOCL,Essar Steel Ltd vs Union Of India & Ors on 19 April, 2016

BPCL, GAIL and Petronet. One of the points discussed in the meeting was:
“It was also recognized that there is a need for Government to provide certain relief
for LNG so that it can be competitive and acceptable to the end users. For the
purpose declaring natural gas “Declared Goods” under Central Sales Tax Act maybe
considered by the government……with the pooling mechanism……price of regasified
LNG shall become more competitive.” Annexures R-7, R-8, R-9, R-10 contain
communications between the Minister of Finance, Qatar and representatives of the
Indian Ministry of Petroleum and Natural Gas as well as RasGas between June and
July 2002. The abovesaid communication would show the efforts that were being
made at Ministry level to secure supply of LNG from Qatar to India. The most
significant is Annexure R-10, which is the record note of discussion of the meeting
dated 22.09.2002, between the then Indian Minister of Petroleum and Natural Gas
and the Minister of Energy and Industry, Qatar, held in Japan, where several
concerns were flagged by Qatar, including the non-fulfillment of certain promises by
India, including negotiating of contracts between Petronet and the downstream
consumers of RLNG. Pursuant to this, several meetings took place between
representatives of Ministry of Petroleum and Natural Gas, ONGC, IOCL, BPCL, GAIL
and Petronet and other experts, during the course of which several options were
explored, including the pooling of LNG with ONGC, which was to be considered as
the last option.
Thus, it becomes clear from a perusal of the documents produced on record that the
executive policy decision dated 06.03.2007 to pool the price of RLNG was arrived at
after elaborative discussions between representatives of Qatar, India, IOC, BPCL,
GAIL, ONGC and other experts in the field. It was an informed decision taken in the
interest of the public at large.
The impugned policy decision dated 06.03.2007 has also been duly authenticated by
the Under Secretary to the Government of India.
The next major contention advanced on behalf of the appellants is that since the
communication dated 06.03.2007 is not a legislative action, hence price of RLNG
could not have been fixed by virtue of that, and that it must be viewed more
suspiciously as it is for the benefit of only one entity, viz, RGPPL. We are unable to
agree with this contention. Various cases have been cited by the appellants to show
that price fixing is a legislative function. The same does not come to the rescue of the
appellants, because they have not appreciated in their entirety in a proper
perspective.
RLNG, being a petroleum product, is an essential commodity for the purpose of the
Essential Commodities Act, 1955. In the case of M/S Sitaram Sugar Co. Ltd. v. Union
of India[22], a Constitution Bench of this Court deliberated as to who has the power
to fix prices of essential commodities. It held as under:Essar Steel Ltd vs Union Of India & Ors on 19 April, 2016

“The question of fixation of a fair and reasonable price for goods placed on the
market has come up for consideration of Parliament and Courts in different contexts.
Price fixation, it is common ground, is generally a legislative function. But Parliament
generally provides for interference only at a stage where in pursuance of social and
economic objectives or to discharge duties under the Directive Principles of State
Policy, control has to be exercised over the distribution and consumption of the
material resources of the community. Thus while Parliament has enacted the
Essential Commodities Act, it has left it to the discretion of the Executive to take
concrete steps for fixing the prices of essential commodities as and when necessity
arises, by promulgating Control Orders in exercise of the powers vested in the Act.
Various types of foodgrains, sugarcane and drugs have come under the purview of
such control orders and the modalities of fixation of fair prices there under have also
come up for consideration of the Courts.” (emphasis laid by this Court) This Court
also deliberated in detail as to what constitutes a legislative function:
“32.… to distinguish clearly legislative and administrative functions is "difficult in
theory and impossible in practice". Referring to these two functions, Wade says:
“They are easy enough to distinguish at the extremities of the spectrum: an Act of
Parliament is legislative and a deportation order is administrative. But in between is
a wide area where either label could be used according to taste, for example where
ministers make orders or regulations affecting large numbers of people....” Wade
points out that legislative power is the power to prescribe the law for people in
general, while administrative power is the power to prescribe the law for them, or
apply the law to them, in particular situations. A scheme for centralising the
electricity supply undertakings may be called administrative, but it might be just as
well legislative. Same is the case with ministerial orders establishing new towns or
airports etc. He asks: "And what of 'directions of a general character' given by a
minister to a nationalised industry? Are these various orders legislative or
administrative?" Wade says that the correct answer would be that they are both. He
says:" ...there is an infinite series of gradations, with a large area of overlap, between
what is plainly legislation and what is plainly administration". Courts, nevertheless,
for practical reasons, have distinguished legislative orders from the rest of the orders
by reference to the principle that the former is of general application. They are made
formally by publication and for general guidance with reference to which individual
decisions are taken in particular situations.
33. According to Griffith and Street, an instruction may be treated as legislative even
when they are not issued formally, but by a circular or a letter or the like. What
matters is the substance and not the form, or the name. The learned authors say:
"...where a Minister (or other authority) is given power in a statute or an instrument
to exercise executive, as opposed to legislative, powers—as, for example, to
requisition property or to issue a licence—and delegates those powers generally, then
any instructions which he gives to his delegates may be legislative". Where anEssar Steel Ltd vs Union Of India & Ors on 19 April, 2016

authority to whom power is delegated is entitled to sub-delegate his power, be it
legislative, executive or judicial, then such authority may also give instructions to his
delegates and these instructions may be regarded as legislative.” On the power of
delegated legislation, it was held as under:
“47. Power delegated by statute is limited by its terms and subordinate to its objects.
The delegate must act in good faith, reasonably, intra vires the power granted, and on
relevant consideration of material facts. All his decisions, whether characterised as
legislative or administrative or quasi- judicial, must be in harmony with the
Constitution and other laws of the land. They must be "reasonably related to the
purposes of the enabling legislation"……” Accepting the interpretation of ‘legislative
function’ advanced by the learned senior counsel on behalf of the appellants, would
be giving it too narrow and restrictive a meaning. It becomes clear from a perusal of
the case law discussed above that even though price fixing is a legislative function;
the same can be delegated and can be fixed by way of executive orders as well. In the
instant case, the policy decision dated 06.03.2007 has been taken after detailed
communication between the then Minister of Petroleum and Natural Gas, as well as
the then heads of IOCL, BPCL, ONGC, GAIL and Petronet. The impugned policy
decision dated 06.03.2007 has also been duly authenticated by the Under Secretary
to the Government of India, which is well within the powers conferred on the Under
Secretary under the Business Transaction Rules, 1961.
The contention advanced on behalf of the appellants that the said policy takes away
their vested right cannot be accepted in light of Clause 11.4 of the Supply Agreement,
which clearly provides for a situation of change in price of RLNG under the contract
as a result of change in the policy of the Government. The case of Delhi Development
Authority (supra), relied upon by the appellants on the point also does not come to
their rescue. It was held in that case as under:
“Terms and conditions of the contract can indisputably be altered or modified. They
cannot, however, be done unilaterally unless there exists any provision either in
contract itself or in law.” In the instant case, clause 11.4 in the Supply Agreement is
the provision of the contract which provides for a change in the terms and conditions
of the contract.
Further, except a strong contention urged by the learned senior counsel for the
appellants that the policy is for the benefit of one entity (RGPPL), the appellants have
not present any evidence to show that they have been discriminated against, as the
policy has been applied for all players across the board, as far as long term contracts
are concerned. Nothing has been brought on record to show that the said decision is
arbitrary, mala fide, unreasonable or taken after non application of mind. On the
contrary, the documents produced on record by the respondents, which is the back
and forth of communication and minutes of meetings between Ministers in Qatar and
India, as well Secretaries of the Government and the representatives of IOCL, BPCL,Essar Steel Ltd vs Union Of India & Ors on 19 April, 2016

GAIL, ONGC and Petronet, would clearly show that the impugned decision dated
06.03.2007 was taken after due deliberation and exploring all other possible
alternatives to reduce the price of RLNG, so as to make it viable for the new entrants
in the market to buy it and run their projects in a feasible manner in the larger public
interest. The consumers of RLNG though long term contracts are a class by
themselves, for the purpose of Article 14 of the Constitution of India. The impugned
policy decision dated 06.03.2007 was to apply to all the players within this class
uniformly and across the board. Thus, the contention that the appellants have been
discriminated against, or that the impugned policy decision was taken in an arbitrary
manner cannot be accepted as the said contention is wholly untenable in law.
Since the legality of the executive decision dated 06.03.2007 has been upheld, the
question of refund of the amount of losses suffered by the appellants as a result of
increase in the price of RLNG in their contract as urged on their behalf, does not arise
for consideration at all by us. There being no evidence to suggest that the impugned
policy direction is illegal, arbitrary, unreasonable or otherwise violative of Article 14
of the Constitution of India, we find no reason to interfere with the same. The
impugned judgment and order dated 16.05.2008 passed by the High Court of Gujarat
is upheld as the same is in accordance with the provisions of the Constitution and law
laid down by this Court in catena of cases as stated supra. Therefore, the impugned
policy decision dated 06.03.2007 does not suffer from any infirmity in law and is
hereby upheld. For the foregoing reasons, the appeals are accordingly dismissed. All
pending applications are disposed of.
…………………………………………………………J. [V. GOPALA GOWDA
…………………………………………………………J. [UDAY UMESH LALIT] New Delhi, April
19, 2016
-----------------------
[1] [2] (2008) 2 SCC 672 [3] [4] AIR 1967 SC 1170 [5] [6] AIR 1961 SC 1570 [7] [8]
AIR 1967 SC 1836 [9] [10] AIR 1953 SC 215 [11] [12] (1978) 3 SCC 459 [13] [14]
(1987) 2 SCC 720 [15] [16] (1970) 3 SCC 400 [17] [18] (2011) 12 SCC 94 [19] [20] AIR
1967 SC 1753 [21] 2015 (13) SCALE 559 [22] [23] (2004) 1 SCC 55 [24] [25] (2010) 6
SCC 303 [26] [27] (2003) 5 SCC 437 [28] [29] (2005) 3 SCC 738 [30] [31] (1997) 5
SCC 536 [32] [33] (2013) 7 SCC 1 [34] [35] (2009) 7 SCC 561 [36] [37] (2000) 10 SCC
664 [38] [39] (1992) 2 SCC 343 [40] [41] (2004) 4 SCC 489 [42] [43] (1990) 3 SCC
223Essar Steel Ltd vs Union Of India & Ors on 19 April, 2016

