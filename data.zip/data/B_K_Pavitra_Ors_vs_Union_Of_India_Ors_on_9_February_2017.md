B.K.Pavitra & Ors vs Union Of India & Ors on 9 February, 2017
Equivalent citations: AIR 2017 SUPREME COURT 820, 2017 (4) SCC 620, 2017
LAB. I. C. 1075, 2017 (2) AKR 155, AIR 2017 SC (CIVIL) 931, (2017) 1 ESC 169,
(2017) 2 KANT LJ 369, (2017) 2 SCT 192, (2017) 3 SERVLR 216, (2017) 2
SCALE 296, (2017) 2 SERVLJ 226, (2017) 2 LAB LN 273, 2017 (2) KCCR SN
153 (SC), 2017 (7) ADJ 79 NOC, 2018 (127) ALR SOC 58 (SC), 2018 (182) AIC
(SOC) 37 (SC)
Author: Adarsh Kumar Goel
Bench: Uday Umesh Lalit, Adarsh Kumar Goel
                                              REPORTABLE
                        IN THE SUPREME COURT OF INDIA
                        CIVIL APPELLATE JURISDICTION
                        CIVIL APPEAL NO. 2368 OF 2011
B.K. PAVITRA  & ORS.
…APPELLANTS
                                   VERSUS
UNION OF INDIA &  ORS.                                   ...RESPONDENTS
                                    WITH
CIVIL APPEAL NOS.2369 OF 2011, 2370-2373 OF 2011, 2374-2377 OF 2011, 2378
OF 2011, 2379 OF 2011, 4320-4327 OF 2011 AND 5280-5286 OF 2011
                               J U D G M E N T
ADARSH KUMAR GOEL, J
1. These appeals involve the question of validity of the Karnataka Determination of Seniority of the
Government Servants Promoted on the Basis of Reservation (To the Posts in the Civil Services of the
State) Act, 2002 (the impugned Act). The Act inter alia provides for grant of consequential seniority
to the Government servants belonging to Scheduled Castes and the Scheduled Tribes promoted
under reservation policy. It also protects consequential seniority already accorded from 27th April,B.K.Pavitra & Ors vs Union Of India & Ors on 9 February, 2017

1978 onwards.
2. The validity of the Act was challenged before this Court by way of Writ Petition (Civil) No.61 of
2002 titled M. Nagaraj and others v. Union of India and others. The issue referred to larger Bench in
the writ petition along with connected matters was decided by this Court on 19th October, 2006[1].
While upholding the constitutional validity of the Constitution (seventy-seventh Amendment) Act,
1995; the Constitution (Eighty-first Amendment) Act, 2000; the Constitution (Eighty-Second
Amendment) Act, 2000 and the Constitution (Eighty-fifth Amendment) Act, 2001, individual
matters were remitted to the appropriate Bench[2]. Thereafter, the matter was remitted back to the
High Court for deciding the question of validity of the said enactment[3].
3. The petition was re-numbered by the High Court as Writ Petition (Civil) No.14672 of 2010. The
High Court by the impugned judgment has held the Act to be valid. The question framed for
determination by the High Court is as follows :
“Whether the State Government has shown the compelling reasons, namely,
backwardness, inadequacy of representation and overall administrative efficiency
before making provision for reservation for Scheduled Castes and Scheduled Tribes
in matters of promotion and as to whether the extent of reservation provided for
promotion in favour of the persons belonging to Scheduled Castes and Scheduled
Tribes at 15% and 3% respectively, in Karnataka is justified?
4. It will be appropriate to notice the factual matrix relevant to determine the controversy. Policy of
reservation in promotion was introduced in the State of Karnataka vide Government Order dated
27th April, 1978. The reservation in promotion was provided to the SCs and STs to the extent of 15%
and 3% respectively but upto and inclusive of the lowest Group-A posts in the cadres where there is
no element of direct recruitment and where the direct recruitment does not exceed 66? %. A roster
of 33 points was issued applicable to each cadre of posts under each appointing authority. Prior to
1st April, 1992, there was no carry forward system of the vacancies. It was introduced on 1st April,
1992. In the stream of graduate Engineers, the reservation in promotion was available upto and
inclusive of third level, i.e., Executive Engineers upto 1999 and on the date of filing of the petition
(in 2002), it was available upto second level, i.e. Assistant Executive Engineer. In Diploma
Engineers, it was available upto third level, i.e. Assistant Executive Engineer – Division II.
According to the appellants, Assistant Engineers of SC/ST category recruited in the year 1987 were
promoted to the cadre of Assistant Executive Engineers while in general merit, Assistant Engineers
recruited in 1976 were considered for promotion to the said cadre. The representation of the SC/ST
group was as follows:
EE Cadre               19.9%
SE Cadre               23.95%
CE Cadre               4.3% (being a selection post)B.K.Pavitra & Ors vs Union Of India & Ors on 9 February, 2017

Engineer-in-chief      44.44%
5. Thus, according to the appellants, SC/ST candidates got promotion early and on account of
consequential seniority, percentage of SC/ST candidates was much higher than the permitted
percentage and all top positions were likely to be filled up by SC/ST candidates without general
merit candidates getting to higher positions. This aspect was considered in the judgment of this
Court dated 1st December, 2000 in M.G. Badappanavar v. State of Karnataka[4]. This Court
applying the principles laid down in Ajit Singh Januja v. State of Punjab (Ajit Singh I)[5]; Ajit Singh
(II) v. State of Punjab[6] and R.K. Sabharwal v. State of Punjab[7] issued a direction to the State of
Karnataka to redo the seniority and take further action in the light of the said judgments. Pointing
out the consequence of accelerated seniority to the roster point promotee, it has been averred in the
writ petition that the roster point promotee would reach the third level by the age of 45 and fourth,
fifth and sixth level in next three, two and two years. The general merit promotee would reach the
third level only at the age of 56 and retire before reaching the fourth level. This would result in
reverse discrimination and representation of reserved category would range between 36% to 100%.
6. Stand of the State and the contesting respondents who have been given promotion under the
reservation, is that inter se seniority amongst persons promoted on any occasion is determined as
per Karnataka Government Servants (Seniority) Rules, 1957 (1957 Rules). By amendment dated 1st
April, 1992 provision was made to fill-up backlog vacancies which was upheld by this Court in
Bhakta Ramegowda v. State of Karnataka[8]. On that basis, Government order dated 24th June,
1997 was issued for fixation of seniority of SC/ST candidates promoted under reservation. Thus, all
candidates promoted ‘on the same occasion’ retained their seniority in the lower cadre. This aspect
was not considered in Badappanavar (supra). Extent of reservation for SC and ST was 15% and 3%
respectively on the basis of census figures of 1951, though the population of SCs and STs has
substantially increased. As per census figures of 1991 population of SC and ST was 16.38% and
4.26% respectively. The stand of the appellants that the SC/ST candidates reach level four at 45
years or become Chief Engineers by 49 years or there is reverse discrimination has been denied.
7. In the light of the above pleadings and judgment of this Court in M. Nagaraj (supra), the matter
was put in issue before the High Court. The contention raised on behalf of the appellants was that
grant of consequential seniority to candidates promoted by way of reservation affected efficiency of
administration and was violative of Articles 14 and
16. In spite of 85th Amendment having been upheld, law laid down in Badappanavar (supra), Ajit
Singh II (supra) and Union of India v. Virpal Chauhan[9] remained relevant in absence of
‘backwardness’, ‘inadequacy of representation’ and ‘overall administrative efficiency’ being
independently determined. The State Government had not provided any material or data to show
inadequacy of reservation to the members of SC/ST nor the State has given any thought to the issue
of overall administrative efficiency.B.K.Pavitra & Ors vs Union Of India & Ors on 9 February, 2017

8. On the other hand, the submission on behalf of the State was that reservation to SCs and STs to
the extent of 15% and 3% respectively could never be said to be excessive in view of progressive
increase in population of SCs and STs.
9. The High Court referring to this Court’s judgment in M. Nagaraj (supra) observed that concept of
“catch up” rule and “consequential seniority” are judicially evolved concepts to control the effect of
reservations. Deleting the said rule cannot by itself be in conflict with “equality code” under the
Constitution. The 85th Amendment gave freedom to the State to provide for reservation in
promotion with consequential seniority under Article 16(4-A) if ‘backwardness’, ‘inadequacy of
representation’ and ‘overall efficiency’ so warranted. There is no fixed yardstick to identify and
measure the above three factors. If the State fails to identify and measure the above three factors,
the reservation can be invalid. Examining whether the State had in fact measured the above factors,
the High Court observed that Order dated 27th April, 1978 was issued by the State of Karnataka
after considering the statistics available about the representation of SCs and STs in promotional
vacancies. On 3rd February, 1999, the policy was modified to limit reservation in promotion in cadre
upto and inclusive of the lowest category of Group-A posts in which there is no element of
recruitment beyond 66? %. The said order was further amended on 13th April, 1999 to the effect that
reservation in the promotion for SCs and STs will continue to operate till their representation
reached 15% or 3% respectively and promotion of SCs and STs and against backlog was to continue
as per order dated 24th June, 1997 till the said percentage was so reached in the total working
strength. As per the Karnataka Scheduled Castes, Scheduled Tribes and other Backward Classes
(Reservation of seats in Educational Institutions and of appointments or posts in the services under
the State) Act, 1994 (the Karnataka Act 43 of 1994), seniority in the lower cadre is maintained in
promotional posts for the persons promoted “on one occasion”. Since reservation had not exceeded
15% and 3% for SCs and STs while population of the said categories had increased, there was
adequate consideration of the above three factors of “backwardness”, inadequacy of representation”
and “overall efficiency”. Section 3 of the Act provided for an inbuilt mechanism for providing
reservation in promotion to the extent of 15% and 3% respectively for the SCs and STs. The State
Government collects statistics every year. The High Court held that contention that if all the posts in
higher echelons may be filled by SCs and STs, the promotional prospects of general merit candidates
will get choked or blocked could not be accepted as reservation in promotion was provided only upto
the cadre of Assistant Executive Engineers. It was further observed that there was no pleading that
overall efficiency of service would be hampered by promoting persons belonging to SCs and STs.
10. The impugned judgment has been challenged on behalf of the appellants mainly relying upon
judgment of this Court in Uttar Pradesh Power Corporation Limited v. Rajesh Kumar[10]. It was
submitted that the High Court erroneously held that there was an inbuilt mechanism under Section
3 of the impugned Act or that the seniority rule maintaining lower cadre seniority in respect of
persons promoted on a particular occasion was a safeguard against excessive reservation. Similarly,
the finding that reservation was only upto a particular level and not beyond or that accelerated
promotion upto that level did not affect further promotions was erroneous. It was also submitted
that there was no provision for excluding the creamy layer which also rendered the Act invalid. It
was submitted that no exercise whatsoever in terms of M. Nagaraj case has been undertaken by the
State.B.K.Pavitra & Ors vs Union Of India & Ors on 9 February, 2017

11. Shri Basava Prabhu S. Patil, learned senior counsel appearing on behalf of the State submitted
that the Act did not deal with the reservation. It only dealt with seniority. Seniority was not a
fundamental right but a civil right as held in Bimlesh Tanwar vs. State of Haryana[11]. M. Nagaraj
judgment of this Court had dealt with reservation and not with consequential seniority. Once
reservation is within the prescribed limit, there was no bar to consequential seniority being granted.
It was further submitted that even if seniority is to be struck down, the clock cannot be entirely
reversed so as to affect seniority of persons who had retired or who are about to retire or who had
reached higher positions.
12. Shri S.N. Bhat, learned counsel for the private respondents supported the impugned judgment
and submitted that the Government was not required to carry out the exercise of finding out
‘backwardness’, ‘inadequacy of representation’ and ‘overall administrative efficiency’ for providing
consequential seniority to officers on the basis of reservation. The said exercise was required to be
carried out only for providing reservation in promotion. Reservation in promotion was permissible
only upto Class I posts in Karnataka. Moreover, inter se seniority of reserved category and general
category candidates promoted together was not disturbed. The roster points ensured that there was
no excessive representation in different cadres of service. In view of Government Order dated 3rd
February, 1999 there was enough data available to justify continuance of provision for consequential
seniority under the impugned Act. Data collected by the Department of Statistics with regard to
overall representation of SCs and STs as on 31st March, 2002 showed that the representation of SCs
and STs was not above 15% and 3% respectively. Section 4 of the Act only protected consequential
seniority which was already given. Promotions already effected cannot be disturbed.
13. Reference may now be made to the impugned Act. The preamble of the Act refers to policy of
reservation in promotion in favour of Government servants belonging to SCs and STs in terms of
order dated 27th April, 1978. Para 7 of the said order stipulates that inter se seniority amongst
persons promoted in accordance with the said order has to be determined in the manner provided
under Rule 4 or Rule 4A of the 1957 Rules. There is further reference to the judgment of this Court
in Badappanavar (supra) to the effect that there was no specific rule permitting seniority to be
counted for persons promoted against a reserved roster point. It further refers to the Constitution
(85th Amendment) Act, 2001 permitting consequential seniority in the case of promotion on the
basis of reservation. It states that to remove any ambiguity and to clarify that government servants
belonging to SCs and STs promoted in accordance with the reservation in promotion shall be
entitled to seniority as it is available to government servants belonging to other categories. Section 3
of the impugned Act provides that government servants belonging to SCs and STs promoted in
accordance with the policy reservation in promotion shall be entitled to consequential seniority on
the basis of length of service in a cadre. Proviso to the said section to the effect that inter se seniority
of government servants belonging to SCs/STs and those belonging to unreserved category promoted
at the same time by a common order shall be on the basis of inter se seniority in the lower cadre.
Section 4 provides for protection of consequential seniority already accorded from 27th April, 1978.
Since Sections 3 and 4 are the key sections, the same are reproduced below :
“3. Determination of Seniority of the Government Servants Promoted on the basis of
Reservation.- Notwithstanding anything contained in any other law for the timeB.K.Pavitra & Ors vs Union Of India & Ors on 9 February, 2017

being in force, the Government Servants belonging to the Scheduled Castes and the
Scheduled Tribes promoted in accordance with the policy of reservation in promotion
provided for in the Reservation Order shall be entitled to consequential seniority.
Seniority shall be determined on the basis of the length of service in a cadre.
Provided that the seniority inter-se of the Government Servants belonging to the
Scheduled Castes and the Scheduled Tribes as well as those belonging to the
unreserved category, promoted to a cadre, at the same time by a common 5 order,
shall be determined on the basis of their seniority inter- se, in the lower cadre.
Provided further that where the posts in a cadre, according to the rules of recruitment
applicable to them are required to be filled by promotion from two or more lower
cadres,-
(i) The number of vacancies available in the promotional (higher) cadre for each of
the lower cadres according to the rules of recruitment applicable to it shall be
calculated; and
(ii) The roster shall be applied separately to the number of vacancies so calculated in
respect of each of those lower cadres;
Provided also that the serial numbers of the roster points specified in the Reservation Order are
intended only to facilitate calculation of the number of vacancies reserved for promotion at a time
and such roster points are not intended to determine inter-se seniority of the Government Servants
belonging to the Scheduled Castes and the Scheduled Tribes vis-a-vis the Government Servants
belonging to the unreserved category promoted at the same time and such inter-se seniority shall be
determined by their seniority inter-se in the cadre from which they are promoted, as illustrated in
the Schedule appended to this Act.
4. Protection of consequential seniority already accorded from 27th April, 1978, onwards.-
Notwithstanding anything contained in this Act or any other law for the time being in force, the
consequential seniority already accorded to the Government servants belonging to the Scheduled
Castes and the Scheduled Tribes who were promoted in accordance with the policy of reservation in
promotion provided for in the Reservation Order with effect from the Twenty Seventh Day of April,
Nineteen Hundred and Seventy Eight shall be valid and shall be protected and shall not be
disturbed. “
14. Question for consideration is whether the impugned Act is consistent with Articles 14 and 16 of
the Constitution. The said question has been gone into by this Court inter alia in identical
circumstances in Suraj Bhan Meena v. State of Rajasthan[12] and Uttar Pradesh Power Corporation
Limited (supra) to which we will make a reference at appropriate place.
15. We proceed to deal with the contention that High Court judgment proceeds on incorrect
understanding of the law laid down in M. Nagaraj (supra). While no doubt in M. Nagaraj (supra),B.K.Pavitra & Ors vs Union Of India & Ors on 9 February, 2017

85th Amendment was upheld with the observation that enabling the State to do away with the ‘catch
up’ rule, a judicially evolved concept to control the effect of reservations, was valid but the exercise
of power to do away with the said rule and providing consequential seniority in favour of roster
point promotees of reserved category was subject to the limitation of determining the three factors
of ‘backwardness’, ‘inadequacy of representation’ and ‘overall efficiency’. The High Court brushed
aside the said mandatory requirement by simply observing that Section 3 provided for an inbuilt
mechanism as the extent of mechanism was limited to 15% and 3% respectively for the SCs and STs
which dispensed with any requirement of determining inadequacy of representation or
backwardness. High Court further dispensed with the requirement of determining overall efficiency
by observing that there was no pleading that overall efficiency would be hampered by promoting
persons belonging to SCs and STs. This reasoning in the judgment of the High Court, it is submitted,
is contrary to the mandate of law as recognized in M. Nagaraj (supra) and the view similar to the
impugned judgment has been repeatedly disapproved in decisions of this Court.
16. We find considerable force in the submission. The issue is no longer res integra and it will be
suffice to refer to the law clearly laid down by this Court in this regard.
17. In M. Nagaraj (supra), this Court considered constitutional validity of 77th, 81st, 82nd and 85th
Amendments. In doing so, the Court was concerned with the question whether the amendment
infringed the basic structure of the Constitution. It was held that equality is part of the basic
structure but in the present context, right to equality is not violated by an enabling provision if
exercise of power so justifies. In this regard, following observations are worthwhile to note :
“31. At the outset, it may be noted that equality, rule of law, judicial review and
separation of powers are distinct concepts. They have to be treated separately, though
they are intimately connected. There can be no rule of law if there is no equality
before the law; and rule of law and equality before the law would be empty words if
their violation was not a matter of judicial scrutiny or judicial review and judicial
relief and all these features would lose their significance if judicial, executive and
legislative functions were united in only one authority, whose dictates had the force
of law. The rule of law and equality before the law are designed to secure among
other things, justice both social and economic …… …… ……
32. In Minerva Mills [(1980) 3 SCC 625] Chandrachud, C.J., speaking for the
majority, observed that Articles 14 and 19 do not confer any fanciful rights. They
confer rights which are elementary for the proper and effective functioning of
democracy. They are universally regarded by the Universal Declaration of Human
Rights. If Articles 14 and 19 are put out of operation, Article 32 will be rendered
nugatory …..
…… …… ……
33. From these observations, which are binding on us, the principle which emerges is
that “equality” is the essence of democracy and, accordingly a basic feature of theB.K.Pavitra & Ors vs Union Of India & Ors on 9 February, 2017

Constitution. …… …… ……
34. However, there is a difference between formal equality and egalitarian equality
which will be discussed later on.
xxxx
42. ….. ….There can be no justice without equality. Article 14 guarantees the fundamental right to
equality before the law on all persons. Great social injustice resulted from treating sections of the
Hindu community as “untouchable” and, therefore, Article 17 abolished untouchability and Article
25 permitted the State to make any law providing for throwing open all public Hindu religious
temples to untouchables. Therefore, provisions of Part III also provide for political and social
justice.
18. Considering the right of equality in the context of reservation/affirmative action it was observed
:
“43. … … … Therefore, the concept of “equality of opportunity” in public employment
concerns an individual, whether that individual belongs to the general category or
Backward Class. The conflicting claim of individual right under Article 16(1) and the
preferential treatment given to a Backward Class has to be balanced. Both the claims
have a particular object to be achieved. The question is of optimisation of these
conflicting interests and claims.”
19. Thereafter, concepts of ‘equity’, ‘justice’ and ‘merit’ in public employment were referred to and it
was held that application of these concepts in public employment depends upon quantifiable data in
each case. It was observed:
“44. … … …Backward Classes seek justice. General class in public employment seeks
equity. The difficulty comes in when the third variable comes in, namely, efficiency in
service. In the issue of reservation, we are being asked to find a stable equilibrium
between justice to the backwards, equity for the forwards and efficiency for the entire
system. Equity and justice in the above context are hard concepts. However, if you
add efficiency to equity and justice, the problem arises in the context of the
reservation. This problem has to be examined, therefore, on the facts of each case.
Therefore, Article 16(4) has to be construed in the light of Article 335 of the
Constitution. Inadequacy in representation and backwardness of the Scheduled
Castes and Scheduled Tribes are circumstances which enable the State Government
to act under Article 16(4) of the Constitution. However, as held by this Court the
limitations on the discretion of the Government in the matter of reservation under
Article 16(4) as well as Article 16(4-A) come in the form of Article 335 of the
Constitution.B.K.Pavitra & Ors vs Union Of India & Ors on 9 February, 2017

45. … … …The basic presumption, however, remains that it is the State who is in the
best position to define and measure merit in whatever ways it consider it to be
relevant to public employment because ultimately it has to bear the costs arising from
errors in defining and measuring merit.
Similarly, the concept of “extent of reservation” is not an absolute concept and like merit it is
context-specific.
46. … … …Therefore, “vesting of the power” by an enabling provision may be constitutionally valid
and yet “exercise of the power” by the State in a given case may be arbitrary, particularly, if the State
fails to identify and measure backwardness and inadequacy keeping in mind the efficiency of service
as required under Article 335.”
20. The above discussion led this Court to hold that conferment of enabling power on State under
Article 16(4A) did not by itself violate the basic feature of equality. If the affirmative action
stipulated under Article 16(4A) could be balanced with the need for adequate representation for
justice to the backwards while upholding equity for the forwards and efficiency for the entire system
with the further observation that the content of a right is defined by the Courts and even while the
amendment as such could be upheld, validity of an individual enactment was required to be gone
into. If the State wished to exercise its discretion under Article 16(4A), it was to collect quantifiable
data showing backwardness of the class and inadequacy of representation of that class in public
employment in addition to compliance with Article 335. It was made clear that even if the State has
compelling reasons, as stated above, the State will have to see that its reservation provision does not
lead to excessiveness so as to breach the ceiling limit of 50% or obliterate the creamy layer or extend
the reservation indefinitely.
21. It may also be worthwhile to note further observations of this Court in the said judgment :
“49. Reservation is necessary for transcending caste and not for perpetuating it.
Reservation has to be used in a limited sense otherwise it will perpetuate casteism in
the country. Reservation is underwritten by a special justification.
xxxx
59. Giving the judgment of the Court in Indra Sawhney [(1992) Supp. (3) SCC 217]
Jeevan Reddy, J. stated that Article 16(4) speaks of adequate representation not
proportionate representation although proportion of population of Backward Classes
to the total population would certainly be relevant ………… …… …… xxxx
102. …. ….. ….. Therefore, in every case where the State decides to provide for
reservation there must exist two circumstances, namely, “backwardness” and
“inadequacy of representation”. As stated above, equity, justice and efficiency are
variable factors. These factors are context-B.K.Pavitra & Ors vs Union Of India & Ors on 9 February, 2017

specific. There is no fixed yardstick to identify and measure these three factors, it will depend on the
facts and circumstances of each case. These are the limitations on the mode of the exercise of power
by the State. None of these limitations have been removed by the impugned amendments. If the
State concerned fails to identify and measure backwardness, inadequacy and overall administrative
efficiency then in that event the provision for reservation would be invalid …… …… …… xxxxx
104. ….. ….. As stated above, be it reservation or evaluation, excessiveness in either would result in
violation of the constitutional mandate. This exercise, however, will depend on the facts of each
case. In our view, the field of exercise of the amending power is retained by the impugned
amendments, as the impugned amendments have introduced merely enabling provisions because,
as stated above, merit, efficiency, backwardness and inadequacy cannot be identified and measured
in vacuum. Moreover, Article 16(4-A) and Article 16(4-B) fall in the pattern of Article 16(4) and as
long as the parameters mentioned in those articles are complied with by the States, the provision of
reservation cannot be faulted. Articles 16(4-A) and 16(4-B) are classifications within the principle of
equality under Article 16(4).
xxxxx
106. …… …… According to the Constitutional Law of India, by H.M. Seervai, 4th Edn., p. 546,
equality is not violated by mere conferment of discretionary power. It is violated by arbitrary
exercise by those on whom it is conferred. This is the theory of “guided power”. This theory is based
on the assumption that in the event of arbitrary exercise by those on whom the power is conferred,
would be corrected by the courts …... ….. ……
107. ….. …… If the State has quantifiable data to show backwardness and inadequacy then the State
can make reservations in promotions keeping in mind maintenance of efficiency which is held to be
a constitutional limitation on the discretion of the State in making reservation as indicated by
Article 335. As stated above, the concepts of efficiency, backwardness, inadequacy of representation
are required to be identified and measured …… …… ……
108. …… …… Moreover, Article 335 is to be read with Article 46 which provides that the State shall
promote with special care the educational and economic interests of the weaker sections of the
people, and in particular, of the Scheduled Castes and Scheduled Tribes, and shall protect them
from social injustice. Therefore, where the State finds compelling interests of backwardness and
inadequacy, it may relax the qualifying marks for SCs/STs. These compelling interests however have
to be identified by weighty and comparable data.
xxxxx
117. ….. …… Therefore, in each case the Court has got to be satisfied that the State has exercised its
opinion in making reservations in promotions for SCs and STs and for which the State concerned
will have to place before the Court the requisite quantifiable data in each case and satisfy the Court
that such reservations became necessary on account of inadequacy of representation of SCs/STs in a
particular class or classes of posts without affecting general efficiency of service as mandated underB.K.Pavitra & Ors vs Union Of India & Ors on 9 February, 2017

Article 335 of the Constitution.
118. The constitutional principle of equality is inherent in the rule of law. However, its reach is
limited because its primary concern is not with the content of the law but with its enforcement and
application. The rule of law is satisfied when laws are applied or enforced equally, that is,
even-handedly, free of bias and without irrational distinction. The concept of equality allows
differential treatment but it prevents distinctions that are not properly justified. Justification needs
each case to be decided on case-to-case basis.
xxxx
120. At this stage, one aspect needs to be mentioned. Social justice is concerned with the
distribution of benefits and burdens. The basis of distribution is the area of conflict between rights,
needs and means. These three criteria can be put under two concepts of equality, namely, “formal
equality” and “proportional equality”. Formal equality means that law treats everyone equal.
Concept of egalitarian equality is the concept of proportional equality and it expects the States to
take affirmative action in favour of disadvantaged sections of society within the framework of
democratic polity. In Indra Sawhney all the Judges except Pandian, J. held that the “means test”
should be adopted to exclude the creamy layer from the protected group earmarked for reservation.
In Indra Sawhney this Court has, therefore, accepted caste as a determinant of backwardness and
yet it has struck a balance with the principle of secularism which is the basic feature of the
Constitution by bringing in the concept of creamy layer. Views have often been expressed in this
Court that caste should not be the determinant of backwardness and that the economic criteria
alone should be the determinant of backwardness. As stated above, we are bound by the decision in
Indra Sawhney. The question as to the “determinant” of backwardness cannot be gone into by us in
view of the binding decision. In addition to the above requirements this Court in Indra Sawhney has
evolved numerical benchmarks like ceiling limit of 50% based on post-specific roster coupled with
the concept of replacement to provide immunity against the charge of discrimination.
xxxx
122. We reiterate that the ceiling limit of 50%, the concept of creamy layer and the compelling
reasons, namely, backwardness, inadequacy of representation and overall administrative efficiency
are all constitutional requirements without which the structure of equality of opportunity in Article
16 would collapse.”
22. Question of application of principles laid down in M. Nagaraj (supra) for judging the exercise of
enabling power of granting consequential seniority and promotion was raised in Suraj Bhan Meena
(supra). Therein challenge was to the validity of notification dated 25th August, 2008 issued by the
State Government of Rajasthan under proviso to Article 309 of the Constitution, amending the
service rules in the State of Rajasthan w.e.f. 28th December, 2002. The notification purported to
give consequential seniority to candidates belonging to SCs and STs who got roster point
promotions. The challenge to the notification was that without quantifying figures of SCs and STs or
showing compelling reasons such as ‘backwardness’, ‘inadequacy of representation’ and ‘overallB.K.Pavitra & Ors vs Union Of India & Ors on 9 February, 2017

administrative efficiency’ as laid down in M. Nagaraj (supra) the grant of consequential seniority
was not permissible. The High Court quashed the notification providing for consequential seniority
on the ground that no exercise had been undertaken in terms of Article 16(4A) to acquire
quantifiable data regarding inadequacy of representation to SCs and STs in public service and to
assess whether such reservation was necessary. This was upheld by this Court as under :
“66. The position after the decision in M. Nagaraj case is that reservation of posts in
promotion is dependent on the inadequacy of representation of members of the
Scheduled Castes and Scheduled Tribes and Backward Classes and subject to the
condition of ascertaining as to whether such reservation was at all required.
67. The view of the High Court is based on the decision in M. Nagaraj case as no
exercise was undertaken in terms of Article 16(4-A) to acquire quantifiable data
regarding the inadequacy of representation of the Scheduled Caste and Scheduled
Tribe communities in public services. The Rajasthan High Court has rightly quashed
the Notifications dated 28-12-2002 and 25-4-2008 issued by the State of Rajasthan
providing for consequential seniority and promotion to the members of the
Scheduled Caste and Scheduled Tribe communities and the same does not call for
any interference.”
23. Again in Uttar Pradesh Power Corporation Limited (supra), validity of Rule 8A of the U.P.
Government Servants Seniority Rules, 1991, inserted by way of an amendment in 2007, was put in
issue. While a Division Bench of Lucknow Bench in Prem Kumar Singh v. State of U.P.[13] struck
down the said rule, another Division Bench at Allahabad in Mukund Kumar Srivastava v. State of
U.P.[14] took a contrary view. This Court dismissed the appeal filed by the U.P. Power Corporation
Limited and upheld the view of the Lucknow Bench. Reference was made to observations in para
819 in Indra Sawhney v. UOI[15] to the effect that reservation under Article 16(4) of the
Constitution could only be at the stage of entry into the State service and not in promotion.
Reservation in promotion is bound to generate acute heartburning and lead to inefficiency in
administration. The members of open category would think that whatever be their record or
performance, members of reserved category will steal a march over them irrespective of their
performance and competence. Once persons coming from different sources join a category or class,
they must be treated alike for promotion and no distinction was permissible on the basis of
‘birth-mark’. Reservation in promotion will be contrary to the mandate of Article 335, viz.,
maintenance of efficiency in administration and put premium on efficiency. Members of reserved
category will not work hard since they do not have to compete with their colleagues and because of
assured promotion, which will be against the goal of excellence under Article 51-A (j). Reference was
also made to para 831 in the said judgment to the effect that extending concessions and relaxations
in the matter of promotion to members of reserved category could affect efficiency of
administration. Reference was then made to the decisions of this Court holding that roster only
ensured percentage of reservation in promotion but could not affect seniority.[16]
24. Reference was then made to the Constitution amendment enabling reservation in promotions
and consequential seniority which was upheld in M. Nagaraj (supra). The said judgment wasB.K.Pavitra & Ors vs Union Of India & Ors on 9 February, 2017

summarized as follows:
“ 81. From the aforesaid decision in M. Nagaraj case and the paragraphs we have
quoted hereinabove, the following principles can be carved out:
(i) Vesting of the power by an enabling provision may be constitutionally valid and
yet “exercise of power” by the State in a given case may be arbitrary, particularly, if
the State fails to identify and measure the backwardness and inadequacy keeping in
mind the efficiency of service as required under Article 335.
(ii) Article 16(4) which protects the interests of certain sections of the society has to
be balanced against Article 16(1) which protects the interests of every citizen of the
entire society. They should be harmonised because they are restatements of the
principle of equality under Article
14.
(iii) Each post gets marked for the particular category of candidates to be appointed against it and
any subsequent vacancy has to be filled by that category candidate.
(iv) The appropriate Government has to apply the cadre strength as a unit in the operation of the
roster in order to ascertain whether a given class/group is adequately represented in the service. The
cadre strength as a unit also ensures that the upper ceiling limit of 50% is not violated. Further,
roster has to be post-specific and not vacancy based.
(v) The State has to form its opinion on the quantifiable data regarding adequacy of representation.
Clause (4-A) of Article 16 is an enabling provision. It gives freedom to the State to provide for
reservation in matters of promotion. Clause (4-A) of Article 16 applies only to SCs and STs. The said
clause is carved out of Article 16(4-A). Therefore, clause (4- A) will be governed by the two
compelling reasons—“backwardness” and “inadequacy of representation”, as mentioned in Article
16(4). If the said two reasons do not exist, then the enabling provision cannot be enforced.
(vi) If the ceiling limit on the carry over of unfilled vacancies is removed, the other alternative time
factor comes in and in that event, the timescale has to be imposed in the interest of efficiency in
administration as mandated by Article 335. If the timescale is not kept, then posts will continue to
remain vacant for years which would be detrimental to the administration. Therefore, in each case,
the appropriate Government will now have to introduce the duration depending upon the fact
situation.
(vii) If the appropriate Government enacts a law providing for reservation without keeping in mind
the parameters in Article 16(4) and Article 335, then this Court will certainly set aside and strike
down such legislation.B.K.Pavitra & Ors vs Union Of India & Ors on 9 February, 2017

(viii) The constitutional limitation under Article 335 is relaxed and not obliterated. As stated above,
be it reservation or evaluation, excessiveness in either would result in violation of the constitutional
mandate. This exercise, however, will depend on the facts of each case.
(ix) The concepts of efficiency, backwardness and inadequacy of representation are required to be
identified and measured. That exercise depends on the availability of data. That exercise depends on
numerous factors. It is for this reason that the enabling provisions are required to be made because
each competing claim seeks to achieve certain goals. How best one should optimise these conflicting
claims can only be done by the administration in the context of local prevailing conditions in public
employment.
(x) Article 16(4), therefore, creates a field which enables a State to provide for reservation provided
there exists backwardness of a class and inadequacy of representation in employment. These are
compelling reasons. They do not exist in Article 16(1). It is only when these reasons are satisfied that
a State gets the power to provide for reservation in the matter of employment.”
25. Referring to the “Social Justice Committee Report” relied upon by the U.P. Power Corporation, it
was observed that the said report was in respect of population and vacancies and not in respect of
the concepts evolved in M. Nagaraj (supra). Therefore, exercise in the light of judgment in M.
Nagaraj was a categorical imperative. The contention that no such exercise was necessary could not
be accepted. Accordingly, this Court upheld the view that grant of consequential seniority in
promotion to the persons belonging to SCs and STs who were granted promotion against roster
points could not be sustained. Reference may be made to the following observations :
“85. As has been indicated hereinbefore, it has been vehemently argued by the
learned Senior Counsel for the State and the learned Senior Counsel for the
Corporation that once the principle of reservation was made applicable to the
spectrum of promotion, no fresh exercise is necessary. It is also urged that the
efficiency in service is not jeopardised. Reference has been made to the Social Justice
Committee Report and the chart. We need not produce the same as the said exercise
was done regard being had to the population and vacancies and not to the concepts
that have been evolved in M. Nagaraj. It is one thing to think that there are statutory
rules or executive instructions to grant promotion but it cannot be forgotten that they
were all subject to the pronouncement by this Court in Virpal Singh Chauhan and Ajit
Singh.
86. We are of the firm view that a fresh exercise in the light of the judgment of the
Constitution Bench in M. Nagaraj is a categorical imperative. The stand that the
constitutional amendments have facilitated the reservation in promotion with
consequential seniority and have given the stamp of approval to the Act and the Rules
cannot withstand close scrutiny inasmuch as the Constitution Bench has clearly
opined that Articles 16(4-A) and 16(4-B) are enabling provisions and the State can
make provisions for the same on certain basis or foundation. The conditions
precedent have not been satisfied. No exercise has been undertaken. What has beenB.K.Pavitra & Ors vs Union Of India & Ors on 9 February, 2017

argued with vehemence is that it is not necessary as the concept of reservation in
promotion was already in vogue. We are unable to accept the said submission, for
when the provisions of the Constitution are treated valid with certain conditions or
riders, it becomes incumbent on the part of the State to appreciate and apply the test
so that its amendments can be tested and withstand the scrutiny on parameters laid
down therein.
87. In the ultimate analysis, we conclude and hold that Section 3(7) of the 1994 Act
and Rule 8-A of the 2007 Rules are ultra vires as they run counter to the dictum in M.
Nagaraj. Any promotion that has been given on the dictum of Indra Sawhney and
without the aid or assistance of Section 3(7) and Rule 8-A shall remain undisturbed.”
26. In Central Bank of India v. SC/ST Employees Welfare Association[17], question was whether in
absence of a rule of reservation for promotion such reservation was permissible merely because the
banks were following reservation policy of the Government of India. The Madras High Court after
considering the statistics found that there was no adequate representation of SCs and STs in higher
scales. It directed that such representation be granted. Plea of the Bank that such reservation will
affect efficiency in the administration was rejected. This Court held that in absence of any specific
provision for reservation in promotion, the Court could not issue a direction for reservation. It was
observed :
“32. We have already noticed above that in matters of promotion within Group A
posts, which carry an ultimate salary of Rs 5700 per month, there was no provision
for any reservation. On a conjoint reading of these two Office Memorandums dated
1-11-1990 and 13-8-1997, in the absence of any other provision or rule evidencing
such a reservation in the matter of promotions, it cannot be said that there was
reservation in promotion within Group A posts up to the ultimate salary of Rs 5700
per month. The High Court in the impugned judgment has gone by the lofty ideals
enshrined in Articles 15 and 16 of the Constitution as well as the fact that in these
Banks there is no adequate representation of SC/ST category of officers in Group IV
and above. That may be so. It can only provide justification for making a provision of
this nature. However, in the absence of such a provision, same cannot be read by
overstretching the language of the Office Memorandum dated 13-8-1997. It is for the
State to take stock of the ground realities and take a decision as to whether it is
necessary to make provision for reservation in promotions to the aforesaid post as
well.”
27. In S. Panneer Selvam v. State of Tamil Nadu[18], question before the Court was whether in
absence of any policy decision by the State for giving consequential seniority to candidates
promoted on the basis of reservation prior to a senior general category candidate, claim for
consequential seniority could be accepted. Answering the question in the negative, it was held that
in absence of provision for consequential seniority, ‘catch up’ rule will be applicable and the roster
point promotees cannot claim such consequential seniority. The senior general candidates will
regain their seniority on being promoted. Observations relevant in this regard are as follows :B.K.Pavitra & Ors vs Union Of India & Ors on 9 February, 2017

“34. If we look at the above comparative table of the service particulars of the
appellants and the respondents, it is seen that the contesting respondents U.
Palaniappan joined the service almost seven years after the appellants, his seniority is
automatically accelerated at an unprecedented rate and as on 1-4-2004 his seniority
rank as ADE is 150 and seniority of V. Appadurai is 120. The appellants who are
qualified and senior than the contesting respondents are placed much below in rank
in comparison to the person belonging to the reserved class promotees who were
promoted following the rule of reservation. It is to be noted that the private
respondents in the present case have been promoted temporarily under Rule 39(a)
and Rule 10(a)(i) of the General Rules with the condition that their inclusion in the
promotional order shall not confer on them any right whatsoever in the service.
Determination of seniority is a vital aspect in the service career of an employee and
his future promotion is dependent on this. Therefore, determination of seniority
must be based on some principles which are just and fair. In the absence of any policy
decision taken or rules framed by the State of Tamil Nadu regarding Tamil Nadu
Highways Engineering Service, accelerated promotion given to the respondents
following rule of reservation in terms of Rule 12 will not give them consequential
accelerated seniority.
xxxx
36. In the absence of any provision for consequential seniority in the rules, the
“catch-up rule” will be applicable and the roster-point reserved category promotees
cannot count their seniority in the promoted category from the date of their
promotion and the senior general candidates if later reach the promotional level,
general candidates will regain their seniority. The Division Bench appears to have
proceeded on an erroneous footing that Article 16(4-A) of the Constitution of India
automatically gives the consequential seniority in addition to accelerated promotion
to the roster-point promotees and the judgment of the Division Bench cannot be
sustained.”
26. It is clear from the above discussion that exercise for determining ‘inadequacy of
representation’, ‘backwardness’ and ‘overall efficiency’, is a must for exercise of
power under Article 16(4A). Mere fact that there is no proportionate representation
in promotional posts for the population of SCs and STs is not by itself enough to
grant consequential seniority to promotees who are otherwise junior and thereby
denying seniority to those who are given promotion later on account of reservation
policy. It is for the State to place material on record that there was compelling
necessity for exercise of such power and decision of the State was based on material
including the study that overall efficiency is not compromised. In the present case, no
such exercise has been undertaken. The High Court erroneously observed that it was
for the petitioners to plead and prove that the overall efficiency was adversely
affected by giving consequential seniority to junior persons who got promotion on
account of reservation.B.K.Pavitra & Ors vs Union Of India & Ors on 9 February, 2017

Plea that persons promoted at the same time were allowed to retain their seniority in the lower
cadre is untenable and ignores the fact that a senior person may be promoted later and not at same
time on account of roster point reservation. Depriving him of his seniority affects his further
chances of promotion. Further plea that seniority was not a fundamental right is equally without any
merit in the present context. In absence of exercise under Article 16(4A), it is the ‘catch up’ rule
which is fully applies. It is not necessary to go into the question whether the concerned Corporation
had adopted the rule of consequential seniority.
27. In view of the above, we allow these appeals, set aside the impugned judgment and declare the
provisions of the impugned Act to the extent of doing away with the ‘catch up’ rule and providing for
consequential seniority under Sections 3 and 4 to persons belonging to SCs and STs on promotion
against roster points to be ultra vires Articles 14 and 16 of the Constitution. The judgment will not
affect those who have already retired and will not affect financial benefits already taken.
Consequential promotions granted to serving employees, based on consequential seniority benefit,
will be treated as ad hoc and liable to be reviewed. Seniority list may be now revised in the light of
this judgment within three months from today. Further consequential action may be taken
accordingly within next three months.
…………..…………………………….J. [ ADARSH KUMAR GOEL ] .….……………………..……………..J. [ UDAY
UMESH LALIT ] NEW DELHI FEBRUARY 09, 2017
-----------------------
[2] (2006) 8 SCC 212 [4] Para 124 of ‘M. Nagaraj’ (supra) [6] Vide order of this Court dated 18th
March, 2010 [8] (2001) 2 SCC 666 [10] (1996) 2 SCC 715 [12] (1999) 7 SCC 209 [14] (1995) 2 SCC
745 [16] (1997) 2 SCC 661 [18] (1995) 6 SCC 684 [20] (2012) 7 SCC 1 [22] (2003) 5 SCC 604 [24]
(2011) 1 SCC 467 [26] (2011) 3 All LJ 343 [28] (2011) 1 All LJ 428 [30] (1992) Supp. (3) SCC 217
[32] R.K. Sabharwal versus State of Punjab, Ajit Singh Januja versus State of Punjab (Ajit Singh I);
Ajit Singh (II) versus State of Punjab and Union of India versus Virpal Chauhan (supra) [34] (2015)
12 SCC 308 [36] (2015) 1 SCC 292B.K.Pavitra & Ors vs Union Of India & Ors on 9 February, 2017

