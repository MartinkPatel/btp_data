Dr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22
March, 2024
Author: Nitin Jamdar
Bench: Nitin Jamdar, M.M.Sathaye
2024:BHC-AS:14276-DB
               Trupti                                   1             22 March J-PIL-43-2022.doc
                        IN THE HIGH COURT OF JUDICATURE AT BOMBAY
                                CIVIL APPELLATE JURISDICTION
                          PUBLIC INTEREST LITIGATION NO. 43 OF 2022
                        Dr. Harish Shetty
                        Age- 64,
                        Indian Citizen and practicing Psychiatrist,
                        Residing at Flat No. 802,
                        Lodha Eternis, Building No.1,
                        MIDC, Mahakali, Andheri East,
                        Mumbai - 400 093.                                ... Petitioner
                          V/s.
               1. The State of Maharashtra,
                  Through the Secretary/ Principal Secretary,
                  Department of Public Health, Maharashtra,
                  Mantralaya, Mumbai- 400021.
               2. The State Mental Health Authority,
                  Through its Chairperson, Secretary,
                  Department of Public Health,
                  Maharashtra, Mantralaya,
                  Mumbai - 400 021.
               3. The Regional Mental Hospital,
                  Near Nyan Sadhana College,
                  Mulund Check Naka, Naupada,
                  Thane (West) Thane 400 062,
                  Through the Medical Superintendent.
               4. Shraddha Rehabilitation Foundation,
                  An NGO registered under the
Bombay Trusts Act,
                  having office at : Shraddha Manosarovar,
                  Opposite Eskay Resorts, Off Link Road,Dr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

                  ::: Uploaded on - 22/03/2024                   ::: Downloaded on - 02/04/2024 06:14:58 :::
 Trupti                                  2        22 March J-PIL-43-2022.doc
         Borivali (West), Mumbai,
         Through its Founder Trustee,
         Dr. Bharat Kotwnani.
5. Maharashtra State Legal Services Authority,
   A Statutory Authority constituted Under
Section 6 of the Legal Services Authorities
   Act, 1987. Having office at : 105,
   PWD Office Building, High Court,
   Bombay, Fort, Mumbai 400 032,
   Through its Secretary.                      ... Respondents
                                .......
Mr.J.P.Sen, Senior Advocate as Amicus Curiae.
Ms.Pranati Mehra for the Petitioner.
Mr.Vishwajeet Sawant, Senior Advocate with Mr.Prabhakar M.
Jadhav for Respondent No.2.
Mr.P.P.Kakade, GP with Mr.M.M.Pabale, AGP for the Respondent-
State.
Ms.Rebecca Gonsalves for the Respondent - Maharashtra State
Legal Services Authority.
                            ......
                      CORAM : NITIN JAMDAR &
                              M.M.SATHAYE, JJ.
                          DATE : 22 MARCH 2024
JUDGMENT:
(Per : Nitin Jamdar, J.) Rule. Rule made returnable forthwith. Respondents waive service.
Trupti 3 22 March J-PIL-43-2022.doc
2. In 2009, a patient 'X' was admitted by her husband to a government mental health establishment.
Her husband filed for divorce, and her family abandoned her. In 2021, when a committee appointed
by the Family Court visited the Hospital, they found that 'X' was coherent, and her thoughts were
relevant. By this time, 'X' had already spent twelve years needlessly languishing in the mental health
establishment. X's incarceration and abandonment raised grave issues regarding apathy to theDr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

problem of mental health in the society and inefficiency of the institutional framework.
3. Citing the example of X, the Petitioner, a practicing Psychiatrist, has filed this Public Interest
Litigation (PIL) to highlight the shortcomings in the implementation of the legal framework for
mental health care and the protection of the rights of individuals with mental health problems. The
Petitioner has sought urgent collection of data and reports from all Regional Mental Health
Hospitals in the State of Maharashtra regarding details of the patients and a report from the State
on the status of the implementation of statutory framework and for issuance of remedial orders and
directions.
4. Substantial academic and research material exists emphasising the high prevalence of mental
health disorders in the country, including chronic depression, anxiety disorders, bipolar disorders,
Trupti 4 22 March J-PIL-43-2022.doc schizophrenia, and substance abuse disorders, across age
groups, socioeconomic backgrounds, and geographical regions . It is trite to state that the cost of
mental health issues on individuals, families, and society is immense, leading to significant
economic and social consequences.
5. Initially, the legislative framework was the the Indian Lunacy Act, 1912. It was enacted to
consolidate and amend the law relating to lunacy. Later, the attitude of the society towards persons
afflicted with mental illness changed and it was recognized that the mentally ill persons are to be
treated like any other sick persons and the environment around them should be made as normal as
possible. With the advance in medical science and the understanding of the nature of malady, it was
felt necessary to have a new legislation with provisions for treatment of mentally ill persons in
accordance with the new approach. Accordingly, Mental Health Act (No. 14 of 1987) was enacted in
1987. However, this Act also could not adequately protect the rights of persons with mental illness
and promote access to mental health care in the country. The Convention on Rights of Persons with
Disabilities and its Optional Protocol was adopted at the United Nations Headquarters in New York
on 13 December 2006 and came into force on 3 May 2008. India signed and ratified the said
Convention on 1 October 2007 to align and harmonise the existing laws. It was proposed that new
legislation be enacted.
Trupti 5 22 March J-PIL-43-2022.doc
6. The Mental Healthcare Act, 2017 (the Act of 2017) was accordingly enacted and it came into force
on 29 May 2018. Legislature has acknowledged the vulnerable position of individuals with mental
illness in society, recognising the discrimination they face and the challenges experienced by their
families. The Act of 2017 aims to ensure that people with mental illness receive treatment
comparable to those with physical ailments, fostering an environment conducive to their recovery,
rehabilitation, and societal participation. The Act of 2017 addresses the shortcomings of the Act of
1987, and endeavors to protect and promote the rights of individuals with mental illness, both in
healthcare institutions and within the community. It's emphasis is on healthcare, treatment, and
rehabilitation to be provided in the least restrictive environment possible, respecting the dignity and
rights of individuals. The emphasis is on the importance of integrating individuals with mental
illness into community life. Also to fulfill constitutional obligations and commitments underDr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

international conventions, regulating both public and private mental health sectors to maximise
public health benefits. The Act mandates quality public mental health services, ensure
non-discrimination in health insurance, and integrates mental health into general healthcare
systems at all levels. By promoting equity, efficiency, and stakeholder participation principles, the
Act of 2017 strives to establish a comprehensive and inclusive framework for mental healthcare
delivery in India.
Trupti 6 22 March J-PIL-43-2022.doc
7. The Act of 2017 is divided into twenty-five chapters, which include the Rights of Persons with
Mental Illness; Duties of Appropriate Government; State Mental Health Authority; Finance,
Accounts and Audit of the State Mental Health Authority and its annual report; Mental Health
Establishments; Mental Health Review Boards; Admission, Treatment and Discharge of patients
and responsibilities of other agencies. According to Section 2(o) of the Act of 2017, "Mental
healthcare" includes analysing and diagnosing a person's mental condition and providing treatment,
care, and rehabilitation for their mental illness or suspected mental illness. Section 2(s) of the Act of
2017 defines "mental illness" as a significant disorder affecting thinking, mood, perception,
orientation, or memory that severely impairs judgment, behaviour, the ability to recognise reality, or
to meet the ordinary demands of life. It also includes mental conditions associated with substance
abuse but excludes intellectual disability which is characterised by sub-normal intelligence due to
arrested or incomplete development of the mind. This is broadly the object and the scheme of the
Act of 2017.
8. In this PIL, Respondent No.1 is the Principal Secretary, Department of Public Health, State of
Maharashtra; Respondent No.2 is the State Mental Health Authority; and Respondent No.3 is the
Regional Mental Hospital, Thane. Respondent No.4 is the Maharashtra State Legal Services
Authority. Respondent No.3 is a Trupti 7 22 March J-PIL-43-2022.doc Non-Governmental
Organisation with whom a Memorandum of Understanding is entered into by the State Authority.
9. The PIL was filed on 17 February 2022. By administrative order, the PIL was assigned to the
Bench headed by one of us (Nitin Jamdar, J). There are various issues relating to mental health in
the State, and it is not possible to deal with the same in this PIL neither it is the ambit of this PIL.
When the PIL was taken up for consideration even the basic framework under the Act of 2017 was
not in place in the State of Maharashtra. Over two years, several orders have been passed. There has
been progress, albeit slowly, pursuant to continuous directions of this Court. Substantial work still
needs to be done by the State and the State Mental Health Authority. Initially, the focus of this PIL
was on the primary statutory authority under the Act of 2017. Directions have been issued
concerning the methodology for rehabilitation of persons with mental illness. Thereafter, we have
discussion on the involvement of the Maharashtra State Legal Services Authority (MSLSA) and
touching some aspects of the rights of prisoners with mental illness, as well as the functioning of the
Mental Health Review Boards. We propose to elaborate on these aspects and, after that, as a
culmination of various interim orders, issue certain directions with input from the Petitioners, the
learned Amicus, officers of the State Government and the State Mental Health Authority.Dr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

Trupti 8 22 March J-PIL-43-2022.doc
10. The discussion is divided in two broad areas. First, strengthening and making the statutory
authorities under the Act of 2017 functional and set up coordination between various authorities.
Secondly in respect of rehabilitation protocols and challenges. We also briefly deal with the aspect of
rights of prisoners with mental illness, involvement of Maharashtra State Legal Services Authority
and the Mental Health Review Boards.
11. Generally, in welfare legislation, an authority is set up to oversee the implementation of the
legislation. Existence of such an authority and its proper functioning are crucial to achieve the object
of any beneficial legislation. Under the Act of 2017, in the State of Maharashtra it is the State Mental
Health Authority. State Authority is defined in Section 2 (z) (zb), meaning the State Mental Health
Authority established under Section 45 of the Act of 2017.
12. Section 46 of the Act of 2017 lists the composition of the State Mental Health Authority. The
Authority consists of a chairperson and members. The Principal Secretary of the Department of
Health of State Government is the chairperson. Members included ex officio members such as the
Joint Secretary in charge of mental health in the Department of Health, the Director of Health
Services or Medical Education, and a Joint Secretary in the Department of Social Welfare.
Additionally, there are ex officio representatives from relevant State Government Ministries or
Departments. Other Trupti 9 22 March J-PIL-43-2022.doc members consist of professionals
nominated by the State Government, including the head of Mental Hospitals or the Department of
Psychiatry, an eminent psychiatrist, mental health professionals, psychiatric social workers, clinical
psychologists, and mental health nurses, all with at least fifteen years of experience. Further, there
are representatives of persons with mental illness, caregivers, and non-governmental organisations
providing mental health services, all nominated by the State Government. The nomination process
for non-ex-officio members is according to regulations prescribed by the State Government. Though
Section 50 of the Act of 2017 states that vacancies will not invalidate proceedings so that the State
Mental Health Authority takes a comprehensive and informed decision, it is necessary to have a
representation of the expert members.
13. Under Section 53 of the Act of 2017, the Chief Executive Officer is entrusted with various tasks.
The Chief Executive Officer of the State Mental Health Authority has several key responsibilities
outlined in the statute. The Chief Executive Officer is the legal representative of the State Mental
Health Authority and is responsible for its day-to-day administration, implementing its work
programs and decisions, drafting proposals for work programs, and managing the budget. Each
year, the Chief Executive Officer must submit a general report covering all activities of the Authority
in the previous year, work programs, annual accounts, and the budget for Trupti 10 22 March
J-PIL-43-2022.doc the upcoming year to the State Mental Health Authority for approval.
14. Section 55 of the Act of 2017 outlines the functions of the State Mental Health Authority. The
Authority is entrusted with various responsibilities regarding mental health establishments and
professionals within the State. It is required to register all mental health establishments (excluding
those specified) and maintain a register of these establishments, which must be published, includingDr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

publishing it online. Additionally, the Authority must develop quality and service provision norms
for different types of mental health establishments. Furthermore, the Authority is responsible for
supervising all mental health establishments in the State and addressing complaints about
deficiencies in service provision. The Authority is tasked with registering clinical psychologists,
mental health nurses, and psychiatric social workers as mental health professionals within the State.
The list of registered mental health professionals must be published according to regulations set by
the Authority. Moreover, the State Authority is mandated to provide training on the provisions and
implementation of the Mental Health Act to relevant individuals, including law enforcement officials
and health professionals. Finally, they are required to fulfill any other functions related to mental
health matters as decided by the State Government. Under Section 56 of the Act of 2017, the State
Mental Health Authority has to meet at least four times a year.
Trupti 11 22 March J-PIL-43-2022.doc
15. Under Sections 61 and 62 of the Act of 2017, the funds required for the functioning of the State
Mental Health Authority are referred to. The State Government may grant such sums of money as
the State Government may think fit for being utilised for this Act to the State Authority. Section 62
establishes the State Mental Health Authority Fund, which will receive grants, loans, fees, and other
sums as the State Government decides. This Fund covers the salaries, allowances, and expenses of
the State Authority members, officers, and employees, as well as costs related to the Authority's
functions as outlined in the Act. The Fund is to be used for expenses incurred for functions and
implementation of the Act.
16. Section 63 of the Act of 2017 provides for accounts and audit of the State Mental Health
Authority in consultation with the Comptroller and Auditor-General of India. Section 63 mandates
the Authority to maintain proper accounts and records and prepare an annual statement of accounts
as the State Government prescribes, in consultation with the Comptroller and Auditor-General of
India. The accounts of the Authority will have to be audited by the Comptroller and Auditor-General
of India at specified intervals.
17. Section 64 of the Act of 2017 requires the State Mental Health Authority to prepare a report
detailing its activities for the previous year, following the format and timeline set by the State
Government. This report, the annual accounts and the auditor's report must be Trupti 12 22 March
J-PIL-43-2022.doc submitted to the State Government, which will lay these reports before the State
Legislature.
18. Under the proviso to sub-section (2) read with sub-sections (1) and (4) of section 121 of the Act
of 2017, the Mental Healthcare (State Mental Health Authority) Rules, 2018 (referred to as the State
Mental Health Authority Rules, 2018) have been framed. Rule 10 empowers the State Government
to call for information concerning the activities of the State Authority periodically or as and when
required by it, and the State Authority has to submit and furnish such information in Form-A. Form
A, appended to the Rules, gives the heads of the information to be furnished by the Authority. Form
A is as follows.Dr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

"Form-A [See rule 10] INFORMATION ON THE ACTIVITIES OF THE STATE
AUTHORITY/ BOARD
1. New Regulations notified:
2. Number of orders passed during the year:
3. Meetings held during the year:
4. Number and details of mental health establishments under the control of the State
Government:
5. Number and details of mental health establishments in the State or Union
Territory:
6. Registration of mental health professionals by the State Authority:
Trupti 13 22 March J-PIL-43-2022.doc
7. Statement on references received from the Central Government and the State
Government and action taken thereon:
8. Quality and service provision norms for different types of mental health
establishments under the State Government:
9. Training imparted to persons including law enforcement officials, mental health
professionals and other health professionals about the provisions and
implementation of the Mental Healthcare Act, 2017:
10. Applications for registration of mental health establishments received, accepted
and rejected along with reasons for such rejection:
11. Audit of Mental Health Establishments along with audit reports:
12. Complaints received regarding violation of rights of Mentally ill persons and
action taken thereon.
13. Details regarding guidance document for medical practitioners and mental health
professionals.
14. Number of cases registered regarding Sexual Harassment of Women at Workplace
under section 22 of the Sexual Harassment of Women at Workplace (Prevention,
Prohibition and Redressal) Act, 2013 and details thereof:Dr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

15. Details of inspection and inquiry of Mental Health Establishments:
16. Number of appeals to High Court against order of Authority and status thereof:
17. Complaints received regarding deficiencies in provision of services and action
taken thereon:
18. Stakeholders Consultations:
19. Inquiry initiated by the Authority/Board:
20. Administration and establishment matters:
21. Budget and Accounts with details including balance sheet, income and
expenditure account, etc.:
22. Any other matter which may be relevant:".
Trupti 14 22 March J-PIL-43-2022.doc The information is thus exhaustive and
covers various aspects. It gives a complete overview of the functioning of the
Authority in the entire year.
19. Rules 15 and 16 of the State Mental Health Authority Rules, 2018 mandate the Authority to
prepare and submit financial statements and annual reports within the stipulated time. Rule 15
deals with accounts and audits of the State Mental Health Authority. The Authority has to maintain
accounts of its yearly income and expenditure, preparing an annual statement including an income
and expenditure account and a balance sheet. This statement must be submitted for audit by 30
June each year. The statement must be signed by the accounts officer and the Chief Executive
Officer on behalf of the Authority and approved by them. The annual report of the Authority is dealt
with under Rule 16, which provides that the Authority must complete its annual report using
Form-E and submit it to the State Government within nine months after the end of the financial
year for presentation to each House of the State Legislature.
20. From E reads thus :
"ANNUAL REPORT OF STATE AUTHORITY
1. Introduction
2. Profile of the Authority's Members
3. Scope of Regulation
4. New Regulations/procedures, etc., notified/issuedDr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

5. Orders passed by the Authority
6. Meetings of the State Mental Health Authority held during the year.
Trupti 15 22 March J-PIL-43-2022.doc
7. Mental health establishments under the control of the State Government
8. Mental health establishments in the State
9. Registration of mental health professionals by the State Authorities
10. A statement on references received from Central and State Governments and
action taken thereon
11. A statement on references sent to the Central and State Governments and action
taken thereon by the respective Governments
12. Quality and service provision norms for different types of Mental health
establishments under the State Government
13. Supervision of mental health establishments under the State Government and
action taken on the complaints received about deficiencies in provision of services
therein
14. Training imparted to persons including law enforcement officials, mental health
professionals and other health professionals about the provisions and
implementation of the Mental Healthcare Act, 2017
15. Applications for registration of mental health establishments received, accepted
and rejected along with reasons for such rejection.
16. Audit of Mental Health Establishments
17. Complaints received regarding violation of rights of Mentally ill persons and
action taken thereon
18. Details regarding guidance document for medical practitioners and mental health
professionals
19. Implementation of RTI Act, 2005
20. Details regarding Sexual Harassment of Women at Workplace under section 22 of
the Sexual Harassment of Women at Workplace (Prevention, Prohibition andDr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

Redressal) Act, 2013.
21. Inspection and Inquiry of Mental Health Establishments
22. Appeals to High Court against order of Authority and status thereof
23. Status of review of use of advance directives and recommendations of the
Authority in respect thereof.
24. Complaints received about deficiencies in provision of services and action taken
thereon.
Trupti 16 22 March J-PIL-43-2022.doc
25. Stakeholders Consultations
26. Inquiry initiated by the Authority
27. Administration and establishment matters
28. Annual accounts
29. Any other matter which in the opinion of the Authority needs to be highlighted".
Thus, this report outlines the activities from the previous year comprehensively and include the
audited accounts for that year, along with the report from the Comptroller and Auditor General of
India
21. Thus, a bare perusal of the statutory provisions above would indicate that obligations placed
upon the State Mental Health Authority are important and are to be monitored by the State
Government.
22. Therefore, when the PIL came up for hearing on 23 August 2022 at the initial hearing, we raised
a query about the existence and working of the State Mental Health Authority. It is the primary
Authority in the State of Maharashtra to oversee the functioning of the Act of 2017. The role of this
Authority is crucial in addressing the mental health issues in the State. It was informed that the
State Mental Health Authority was formed only on 23 October 2021, and composition still needed to
be completed.
23. On 23 August 2022, the learned Advocate General had informed that non-official members
contemplated under Section Trupti 17 22 March J-PIL-43-2022.doc 46(1)(g) to (n) were yet to be
appointed. The learned Advocate General stated that efforts would be taken to fill in the above
vacancies so that the State Mental Health Authority becomes fully operational. Therefore, there was
no State Mental Health Authority as of 23 August 2022. Further there was no clarity on its ChiefDr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

Executive officer, its funding etc. The most important authority under the Act was not set up and
functional for almost three years from the enactment of the Act.
24. On 29 August 2022, the learned Advocate General placed before us a Government Resolution
dated 25 August 2022 nominating the non-official members of the Authority. The learned Advocate
General stated that a comprehensive resolution notifying the entire members of the Authority would
be issued by 6 September 2022. While deferring the hearing of the PIL, we recorded our expectation
that the State Mental Health Authority would hold its first meeting and discuss, amongst other
subjects, the issues highlighted in this PIL and the proceeding of the meetings of the State Mental
Health Authority with their opinion/ result of the discussion would be placed by way of report.
25. On 25 November 2022, when the PIL came up on board, the learned Advocate General pointed
out that after the order was passed on 29 August 2022 to make the State Mental Health Authority
functional, steps were taken by the State Government.
Trupti 18 22 March J-PIL-43-2022.doc The learned Advocate General tendered an additional
affidavit placing the Government Resolution dated 6 September 2022 on record. By this
Government Resolution, members to the Authority were appointed concerning the respective
provisions of Section 46 of the Act of 2017. The learned Advocate General stated that two members
under Sections 46(1)(l) and (m) were to be appointed, and an advertisement for that purpose was
issued. The learned Advocate General informed that the Authority held its meeting on 16 September
2022, but the minutes still needed to be finalised. The learned Advocate General sought to apprise
the steps taken by the State Government, including finalising a memorandum of understanding with
the non-governmental organization for providing services for rehabilitation and reunion. Since the
State Mental Health Authority is entrusted with overseeing compliance and implementation of the
Act of 2017, it was felt necessary to examine the minutes of the meeting, the decisions, and the steps
pursuant to the decisions. The learned Advocate General stated that the minutes would be placed on
record on the following date by circulating them in advance.
26. Therefore, even on 25 November 2022, the State Mental Health Authority had a partial
composition as stipulated under the Act of 2017. Even though the meeting was stated to be held on
16 September 2022, the minutes were still being finalised for more than a month. This was the
progress despite the direction of this Trupti 19 22 March J-PIL-43-2022.doc Court. An affidavit was
filed on 25 November 2022 by the Deputy Superintendent of Regional Mental Hospital, Thane, on
behalf of the Principal Secretary of the Public Health Department, State of Maharashtra. This
affidavit stated that the State Mental Health Authority was established by the State Government by
Government Resolution dated 23 October 2018, and certain persons were nominated. It was stated
that from 2018 till September 2022, the State Mental Health Authority held five meetings. The
learned Advocate General, however, had accepted the position in the earlier hearing that the State
Mental Health Authority was not fully functional. Even otherwise, it was only on paper. The rest of
the contents of the affidavit barely give any detail, sidestepping the enormity of the issue.
27. During the hearing on 2 December 2022, the learned AGP tendered finalized minutes of the
meeting held by the State Mental Health Authority on 16 September 2022 with a summary. TheDr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

minutes were one and a half pages. The minutes referred to five agenda points. These were,
confirmation of the compliance report of the fifth meeting held on 2 September 2021; welcoming
newly selected non-ex-officio members with flowers; reference to the directions given by the
Additional Chief Secretary; to set up a proposal to the Social Justice Department for the discharge of
indoor patients who were eligible for discharge out of the total admitted patients in the hospitals
(unfortunately mentioned as 'Mental Trupti 20 22 March J-PIL-43-2022.doc Hospitals'). Discussion
was held regarding two foreign patients admitted to a hospital in Mumbai. Nothing was stated about
the case that gave rise to this public interest litigation. Then, there was a reference to arranging a
meeting with the Petitioners and others regarding patients' issues. The last item was a decision to
open a bank account in the name of Maharashtra State Mental Health Authority. That was all the
discussion. Nothing was placed before us except for these one-and-a-half pages and one-page
summary. It was clear what was discussed in the meeting was entirely perfunctory and not
commensurate with the functions of the Authority.
28. Recording our dissatisfaction, we issued the following directions to the Chief Executive Officer of
the Respondent State Authority :
(a) Place the details of the State Mental Health Authority Fund, such as when it was
created, what the sum available in the Fund is, and whether it is adequate for its
functioning and performance of the Act.
(b) To prepare a proposal for a work programme as per Section 53(1)(c) of the Act.
(c) To prepare a statement of revenue and expenditure and the budget of the
Authority as per Section 53 of the Act.
(d) To prepare a general report covering all activities of the Authorities in the
previous year per Section 53 of the Act.
Trupti 21 22 March J-PIL-43-2022.doc
(e) To prepare the schedule of programmes of work and budget for the coming year
for approval of the Authority per Section 53 of the Act.
(f) To prepare a report in terms of Rule 10 of the Rules of 2018 as per Form A
appended.
29. The Secretary of the Department of Public Health was also directed to place on record details of
tasks performed by the appropriate Government since 2017. The Secretary was also directed to place
on record a proposal giving details of what steps the State Government intended to take regarding
the duties mentioned above, with a timeline. Further it was directed to place on record whether the
State Government has called for a report from the Authority under Rule 10 of the Rules and details
of the reports so submitted since the inception of the Authority.Dr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

30. When the PIL was taken up on 21 December 2022, reply affidavits were filed by the Principal
Secretary of the Public Health Department and Additional Director of Health Services on behalf of
the Chief Executive Officer of the State Mental Health Authority. These affidavits stated that the
State Mental Health Authority was established on 20 October 2018 as per section 46(1) of the Act of
2017. Thereafter, the members were nominated by a Government Resolution dated 23 October
2018. On 5 December 2018, the State Mental Health Authority held its first meeting. The next
meetings Trupti 22 22 March J-PIL-43-2022.doc were held on 9 January 2017, 17 October 2019, 3
August 2019, 5 September 2021 and 6 September 2022. Certain activities were initiated to redress
mental health care problems under the National Health Mission. The affidavits indicated that the
State's stand is that the activities carried out under the National Health Mission should be construed
as activities under the Act of 2017. A tentative timeline for activities for 2022-23 was appended to
the affidavits filed by these Respondents. The tentative schedule referred to targeted intervention
for mental health by attending schools, colleges, and other places to take workshops on mental
well-being. The timeline referred to was till February 2023. Then, it was stated that Mega Camp for
mental health and suicide prevention would be held with no specific timeline. A range reference is
made that daycare centres would be set up, and 13 such centres would be set up by February 2022.
Clinical psychology equipment was to be procured till February 2023. Medicines to hospitals of
psychiatric patients, procurement of drugs till February 2023, training para- medical staff with
batches of 300 till February 2023, clerical activities such as hiring of vehicles, office expenses,
translation of material and distribution, survey register printing and creation of software. Targets
were up to March 2023. This was the timeline submitted before us by the Principal Secretary for the
obligations of the State under Sections 29, 30, 31 and 32 of the Act, which was clearly not
satisfactory.
Trupti 23 22 March J-PIL-43-2022.doc
31. The Chief Executive Officer of the State Mental Health Authority in his affidavit stated that the
State Mental Health Authority Fund was established on 16 September 2022 by opening a bank
account, and prior to that, the Authority used funds from National Health Mission and sought to
give details of the contribution by the State Government to the Authority as and when funds were
transferred from the State Government as regards the National Health Mission. It was also placed
on record that the Government Resolution was issued on 15 December 2022 appointing the Chief
Executive Officer. This Government Resolution referred to the Government Resolution dated 6
September 2022 as one which had established the Authority. It was not clarified why a Government
Resolution was issued on 15 December 2022 for the appointment of the Chief Executive Officer of
the State Mental Healthcare Authority if the Authority was already established. There was no clarity
emerging on this aspect. It was accepted that the statutory reports referred to in the order dated 2
December 2022 had not been prepared since the inception of the Authority. The Principal Secretary
had accepted that no details as per Rule 10 of the State Mental Health Authority Rules 2018 had
ever been called for from the Authority. This was the state of affairs even in December 2022.
32. When the PIL came up for hearing on 24 February 2023, we highlighted the functions of the
State Mental Health Authority Trupti 24 22 March J-PIL-43-2022.doc under Section 55 of the Act of
2017 of registration. Under Section 55 of the Act of 2017, the State Mental Health Authority isDr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

responsible for registering and supervising all Mental Health Establishments. This includes the
registration of clinical psychologists, mental health nurses, psychiatric social workers, and other
related professionals. The aim is to ensure that all recognized Mental Health Establishments operate
under the supervision of the State Authority and employ registered mental health professionals.
thus, the State Mental Health Authority had to register not only mental health establishments but
also clinical psychologists, mental health nurses, and psychiatric social workers in the State. The
State Mental Health Authority stated that the registration was in progress.
33. We noticed that during the hearing, the learned AGP was handicapped for want of information.
He was not even furnished with the Government Resolution dated 20 October 2018, which
constituted the Authority. The officers present in the Court did not have basic documents.
Considering the lack of assistance that the learned AGP had received despite our orders, we were
constrained to direct the Principal Secretary, the Public Health Department and the Chief Executive
Officer of the Authority to remain present in the Court on the next date so that the Court was
apprised of the initiatives taken by the Authority.
Trupti 25 22 March J-PIL-43-2022.doc
34. On the next date of hearing on 12 January 2023, the learned Advocate General placed on record
minutes of the seventh meeting of the Authority dated 4 January 2023. The Chief Executive Officer
and the Principal Secretary were present in the Court. A substantial part of the minutes referred to
the duties of Appropriate Government enumerated in Chapter VI of the Act of 2017 and not the
State Mental Health Authority. The State Mental Health Authority is governed by different
provisions in Chapter VIII, and the Authority has different functions. Regarding the Authority's
functions, the minutes did not satisfactorily refer to these functions. The learned Advocate General
accepted the position and stated that since the Authority was not functional until recently and
various steps were required to be taken by the State, he would take the initiative in this matter and
call for a meeting of the stakeholders before the next date so that the future course of action could be
decided and conveyed to the Court.
35. The minutes of the meeting dated 4 January 2023 noted that though funds from the National
Health Mission were being utilized, the proposal had been submitted to the Government for corpus
fund and simultaneously Public Health Department needed to pursue the matter with the Finance
Department and Accountant General, Mumbai for allotment of Budget Head. The learned Advocate
General had stated that after getting the Budget Head, a supplementary demand for a corpus fund of
Rs. 3.14 crores would Trupti 26 22 March J-PIL-43-2022.doc be submitted in the budget session for
the financial year 2022-2023, and regular provision was to be included in the budget estimates
thereafter. The learned Advocate General stated that the possibility of sources other than the grant
from the Government under Section 61 of the Act of 2017, in the meanwhile, would be considered.
Therefore, on 24 February 2023, the learned Advocate General informed that Rs. 1 Crore was
transferred under Section 62 of the Act of 2017 to the State Mental Health Authority Fund as a loan
as contemplated under Section 62(1)(i). The budget head was yet to be created.Dr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

36. The learned Counsel for the Petitioner and the learned Amicus Curiae again pointed out to
functions of the State Mental Health Authority under Section 55 of the Act. The registration of all
Mental Health Establishments, their supervision, and registration of clinical psychologists, mental
health nurses, psychiatric social workers, etc. is necessary, which will bring all the Mental Health
Establishments which are recognized to work under the State Authority as registered mental health
professionals. Rule 11 in Chapter III of the State Mental Health Authority Rules, 2018 provides for
provisional Mental Health establishment registration. Rule 14, introduced through an amendment
dated 12 August 2021, states that the Authority shall also provide an online platform for the digital
submission of applications for the grant of provisional registration/renewal of provisional
registration and digital issuance of the certificate.
Trupti 27 22 March J-PIL-43-2022.doc
37. During the hearing on 10 March 2023, the State Mental Health Authority informed that the
Authority would take immediate steps to computerize the details of all patients in four Regional
Hospitals in the State of Maharashtra, and their database would be created. The learned Counsel for
the parties drew our attention to the scheme of the National Legal Services Authority (Legal Services
to the Mentally Ill and Mentally Disabled Persons) Scheme, 2015. Noting the common object of the
Scheme and the State Mental Health Authority, we suggested that the efforts of the State Mental
Health Authority and the Maharashtra State Legal Services Authority should be coordinated. The
State Mental Health Authority had also stated that a committee would be formed to draft the
Maharashtra State Mental Health Policy with special emphasis on patient's rights.
38. It was directed that the officials deputed by the State Mental Health Authority and the paralegal
volunteers under the NALSA Scheme of 2015 would collect the data referred to above from the
mental health institutions registered under the Act of 2017. All registered mental health institutions
were directed to cooperate when such data was called for. If such cooperation was not extended and
a complaint was made to the State Mental Health Authority, the State Mental Health Authority was
directed to take necessary steps to ensure compliance.
Trupti 28 22 March J-PIL-43-2022.doc
39. During the hearing on 10 July 2023, the Maharashtra State Legal Services Authority placed on
record a report dated 14 June 2023 as per the information collected, mostly from private hospitals.
The State Mental Health Authority stated that the data was collected but had to be structured
analytically. We placed the responsibility on the Deans of the Government Hospitals and the
Directors of all the private hospitals to whom this inquiry was made by the State Mental Health
Authority to furnish the data to the State Mental Health Authority without fail. The Secretary of the
Public Health Department was directed issue a circular directing the Deans of the mental hospital
establishments and the Directors of the private establishments to supply the necessary data as called
for by the State Mental Health Authority to take measures contemplated under the Act of 2017.
40. The State Mental Health Authority submitted that the website of the State Health Department
was currently being used and a process was underway to create a separate portal. We expected thatDr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

this initiative to be taken as soon as possible as it would enable the State Authority to register all
establishments and persons effectively to discharge its functions under Section 55 of the Act of 2017.
The creation of a portal, in our opinion, should not take much time, and we expected the authorities
to take urgent steps in that regard. The State Mental Health Authority stated that the registration
was in progress, and the concerned establishments Trupti 29 22 March J-PIL-43-2022.doc referred
to in Section 55(1)(a) and the persons referred to in Section 55(1)(d) were called upon to register
themselves and submits that, in addition, wide publicity would be given through media and social
media. Thus even on that date, despite the order dated 21 April 2023, there was no credible data to
take further measures.
41. Taking an overview of these developments, we note that a robust framework with functional
agencies which is vital to tackle this enormous challenge of mental illness in the society is missing.
The State Mental Health Authority can mandate and coordinate mental health services, ensuring
appropriate treatment and support access. Functional agencies play a crucial role in coordinating
and facilitating collaboration between different sectors involved in mental health. Section 45 of the
Act of 2017 mandates every State Government to establish the State Mental Health Authority within
nine months from the date the Act received the assent. The Act of 2017 was brought into force on 7
July 2018, and the appointed date is 29 May 2018. The State of Maharashtra, therefore, was
mandated to establish a fully functional State Authority under Section 45 of the Act 2017 within nine
months of this date, which it failed to do so till the Court's intervention.
42. On 23 August 2022, we were informed that the State Mental Health Authority was formed only
on 23 October 2021, and composition still needed to be completed. On 23 August 2022, the Trupti
30 22 March J-PIL-43-2022.doc non-official members under section 46(1)(g) to (n) were yet to be
appointed. Then affidavit dated 25 November 2022 stated that the State Mental Health Authority
was established by Government Resolution dated 23 October 2018, and certain persons were
nominated. It was stated that from 2018 till September 2022, the State Mental Health Authority
held five meetings. Then Government Resolution issued on 15 December 2022 was placed on record
appointing the Chief Executive Officer. This Government Resolution referred to the Government
Resolution dated 6 September 2022 as one which had established the Authority. It was not clarified
why a Government Resolution was issued on 15 December 2022 for the appointment of the Chief
Executive Officer of the State Mental Healthcare Authority if the Authority was already established.
If it were only a change of Chief Executive Officer, the Government Resolution would have been in a
different manner. In the Government Resolution dated 15 December 2022, reference was to the
constitution of the Authority as per Government Resolution dated 6 September 2022. There was no
clarity emerging on this aspect. This was the state of affairs even in December 2022.
43. Section 62 of the Act of 2017 establishes the State Mental Health Authority Fund, which will
receive grants, loans, fees, and other sums as the State Government decides. This Fund covers
salaries, allowances, and expenses of the State Authority members, Trupti 31 22 March
J-PIL-43-2022.doc officers, and employees, as well as costs related to the Authority's functions as
outlined in the Act. The Fund is to be used for expenses incurred for functions and performance of
the Act. It is only on 24 February 2023, Rs. 1 Crore was transferred under Section 62 of the Act of
2017 to the State Mental Health Authority Fund as a loan as contemplated under Section 62(1)(i).Dr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

The budget head was created much later and an amount around Rs. 35 Crore was transferred the
later part of 2023.
44. Further, the minutes dated 16 September 2022 referred to a decision to open a bank account in
the name of the Authority. It is not explained how this Authority worked without a bank account or
statutory fund required for its functioning. Out of this fund, the salary, allowances and other
remuneration of the chairperson, other members, chief executive officer, other officers and
employees of the State Authority and the expenses incurred by the State Authority to discharge its
functions and purposes have to be managed. Until December 2022, there was no amount in the
State Authority Fund. Fund was established on 16 September 2022 by opening a bank account.
Before that, the State Authority used to account for its expenses to be sanctioned by the National
Health Mission. However, this was not as per the provisions of the Act, which contemplates a
specific creation of a fund that must be audited. On 4 February 2023, five years after the Act of 2017
came into force, an amount of Rs. 1 Crore was transferred under Section 62 of the Act Trupti 32 22
March J-PIL-43-2022.doc of 2017 to the State Mental Health Authority Fund. Even then, a budget
head was not created, which was created subsequently.
45. Therefore, the meetings of the Authority were not held as per section 56 of the Act of 2017,
which mandates that meetings be held at least four times a year. On paper, the State Mental Health
Authority was established in the State of Maharashtra on 20 October. After that, members were
nominated by a Government Resolution dated 23 October 2018. On 5 December 2018, the Authority
held its first meeting. Considering that the Authority was not functional until August 2022 and that
the meeting marked its first of the year, it was expected to address broader issues arising from
implementing the Act of 2017. However, there was no mention of this in the meeting. There was no
discussion regarding the functions of the Chief Executive Officer, such as preparing the State
Authority's work programs, revenue and expenditure statements, budget execution, or submitting a
general report covering all Authority activities, previous year accounts, and the upcoming year's
budget, etc. There was no indication that any Annual statement of accounts or reports had been
prepared or were in progress The learned AGP was given no instructions.
46. Therefore, we find that the grievance made by the Petitioner regarding the failure of
implementation of the Act of 2017 in the State of Maharashtra is fully justified. The resultant
position shows Trupti 33 22 March J-PIL-43-2022.doc a failure to set up even the basic Authority to
oversee the Act of 2017. Various rights have been conferred upon persons with mental illness and
corresponding duties on the authorities established under the Act of 2017. State Mental Health
Authority is tasked with implementing the provisions of the acts. The effectiveness of this legislative
framework will depend upon the functionality of the State Mental Health Authority. Without an
active and functional State Mental Health Authority to oversee the implementation of the law, this
legislation will remain paper.
47. Now that the Authority is set up (though with gross delay), we now proceed to discuss the way
forward for the State Mental Health Authority to be relevant and functional.Dr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

48. Firstly, without adequate funds, the State Mental Health Authority will not be able to discharge
its functions for the purposes of the Act. Though it is correct that the State Mental Health Authority
Fund will also include all fees and charges received by the State Mental Health Authority under the
Act of 2017, considering the State of affairs, obviously, this source under Section 62 (1) (ii) alone will
not be sufficient. The State Government should take its commitment seriously under Sections 61
and 62 of the Act of 2017 so that the State Mental Health Authority can function at its fullest
capacity. The State Government shall ensure that the activities of the State Mental Health Authority
are not hampered by the lack of funds.
Trupti 34 22 March J-PIL-43-2022.doc
49. Under Section 56 of the Act of 2017, the State Mental Health Authority must meet not less than
four times a year. This mandate has been seriously breached. It is of utmost importance, considering
that the State Mental Health Authority became functional four years after the enactment of the Act
of 2017, that it needs to increase its efforts and not only be satisfied with minimum required
meetings. The Authority could invite representative of the State Legal Services Authority to attend
the said meeting for coordinating the efforts. The Authority should also consider inviting the Jail
Authorities and Police Authorities for its statutory meeting so that a coordinated effort can be
achieved to tackle the issues under the Act of 2017.
50. Functions of the State Mental Health Authority include registration of all mental health
establishments in the State except those excluded. The procedure for registration is to be prescribed
by the State Government. Chapter III of the State Mental Health Authority Rules, 2018, outlines the
process for the provisional registration of mental health establishments by the State Mental Health
Authority. Mental health establishments must be registered with the State Authority, excluding
those under the Central Government's control. Establishments submit an application for provisional
registration in Form-B with a prescribed fee. Upon satisfaction that the establishment meets the
specified requirements, the State Authority grants a provisional registration certificate in Form-C.
This certificate is valid for twelve months from the date of Trupti 35 22 March J-PIL-43-2022.doc
issuance. A late fee is applicable if the renewal application is not submitted within the specified
period.
51. The State Authority should also take steps to register all mental health establishments except
those referred to in Section 43 and maintain and publish (including online on the Internet) a
register of such establishments. The State Authority must develop quality and service provision
norms for different types of mental health establishments in the State and upload them to its
website. The State Mental Health Authority should take steps to initiate the process for registering
clinical psychologists, mental health nurses and psychiatric social workers in the State to work as
mental health professionals and publish the list of such registered mental health professionals in
such a manner as may be specified by regulations by the State Authority.
52. As per Section 71 of the Act of 2017, read with Rule 14 of the State Mental Health Authority
Rules, 2018, a register of mental health establishment in digital format has to be created. Rule 14 of
the State Mental Health Authority Rules, 2018 states that a register of mental health establishment,Dr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

including the name and address of the applicant, name of the establishment and date of the
applicant and registration with number of beds, has to be prepared and the same shall be in digital
format and an online platform for digital submission of application for grant of provisional
registration/ renewal has to be provided. Therefore, the State Mental Health Trupti 36 22 March
J-PIL-43-2022.doc Authority is under a duty to have updated data on the registration of every
mental health establishment in the State, excluding certain categories that provide an online format
for digital submission. Currently the State Mental Health Authority uses the website of the State
Health Department and it is informed that the process is underway to create a separate portal. This
process must be completed as soon as possible as it would enable the State Authority to register all
establishments and persons effectively to discharge its functions under Section 55 of the Act of 2017.
The creation of a portal should not take much time and setting up a timeline for the said purpose is
necessary.
53. The State Mental Health Authority has to prepare an annual statement of accounts for the
previous year and an annual report. This is an area where there is a serious breach. The Authority
must scrupulously follow the mandate of Section 63 of the Act of 2017 to maintain proper accounts
and other relevant records and prepare an annual statement of accounts as prescribed. The State
Mental Health Authority will have to prepare every year's annual report as prescribed under Rule 16
of the State Mental Health Authority Rules, 2018, read with Form E appended to the State Mental
Health Authority Rules, 2018. The Annual Report, subject to non-sharing of sensitive and
prohibited information under the Act of 2017, should be made accessible on its website to enable
other entities to aid and assist the State Mental Health Authority based on the official data. The
Annual Report should be prepared by a fixed date, Trupti 37 22 March J-PIL-43-2022.doc
preferably by the end of December of every year. The Chief Executive Officer of the State Mental
Health Authority should ensure that the mandate under Sections 63 and 64 of the Act of 2017 is
adhered to.
54. Rule 10 of the State Mental Health Authority Rules, 2018, empowers the State Government to
call for information concerning the activities of the State Authority. Form A, appended to Rule 10
reproduced above, gives all necessary details from which the steps taken can be seen. This includes
various important aspects such as the audit of mental health establishments along with audit
reports, complaints received regarding violation of rights of mentally ill persons, registration of
mental health professionals and complaints received regarding deficiencies. Therefore, furnishing
this information is crucial. This report has to be prepared every year, and a full account of its
activities has to be submitted under Section 64 of the Act of 2017. This audited report and the
annual report under Section 64 must be placed before the State Legislature. There can be debate on
the said annual report. No annual report is being submitted since inception and it is a serious lacuna
in the functioning of the State Mental Health Authority which is also neglected by the State who is
empowered to call for information.
55. A dedicated website of the State Mental Health Authority with a feedback mechanism is
necessary to achieve the objectives of Trupti 38 22 March J-PIL-43-2022.doc the Act of 2017. The
Authority should place relevant data regarding the Act of 2017 on its website so that
non-governmental organizations and other public-spirited individuals can aid and assist the effortsDr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

of the State Mental Health Authority, which may be hampered by the lack of official data. The State
Mental Health Authority should consider uploading the annual report mandated under Section 64
of the Act of 2017, subject to Sections 23 and 24 of the Act of 2017 regarding rights to confidentiality
and restriction on the release of information regarding mental illness. The State Mental Health
Authority should make efforts to make all relevant information available in the public domain,
subject to confidentiality. Under the portal of the Public Health Department of the Government of
Maharashtra, a website has been created providing for minimum standards and a checklist for
Mental Health Establishments, Mental Health Establishment Registers, Mental Health
Professionals in Maharashtra and a provision for uploading complaints with a temporary email
address and contact number are provided. This has to be is transitional and a full-fledged
portal/website of the State Mental Health Authority should be created. It is informed that the State
Mental Health Authority has entered into a tripartite Memorandum of Understanding (MOU)
between the State Mental Health Authority, National Institute of Mental Health and Neuro Sciences
and National Health Mission, Karnataka Health & Family Welfare Society and it is in process of
Trupti 39 22 March J-PIL-43-2022.doc being finalized. This MOU contemplates providing technical
services to the State Mental Health Authority.
56. Online and offline presence and visibility of the State Mental Health Authority is crucial.
Considering the vulnerability of the class, unless the classes for whom the rights are created and
those who look after them are made aware, right would remain only in the statute book. Under
Section 25 of the Act of 2017, a person with mental illness has the right to access basic medical
records. If it is withheld, then he has the right to apply to the concerned Board for an order to
release such information. The data furnished shows that there is not a single application received
from any person with illness about medical records being denied under Section 25 of the Act. This
may indicate a lack of awareness regarding the patients' rights, both in the complaints regarding
deficiency of service and denial of medical records. The State Mental Health Authority has to initiate
campaigns to make the patients and the relatives of persons with mental illness aware of their
rights. The Act of 2017 casts a duty on the State Government to make the intended beneficiaries
aware of the said rights. Apart from the helpline, which is stated to be in existence, the Authority
should direct that posters with the helpline and toll-free numbers be displayed by all mental health
institutions. The State Government, along with the State Mental Health Authority, will draw a draft
plan of action as to how the beneficiaries should be made aware of their rights, including the
contingency Trupti 40 22 March J-PIL-43-2022.doc where they cannot be made fully aware of their
rights because of their disabilities.
57. The non-governmental organizations could complement the work of spreading awareness. The
learned Counsel for the Petitioner stated that the Petitioner would endeavour to engage as many
non-governmental organizations as possible to make the persons aware of their rights. The
Maharashtra State Legal Services Authority would examine if this initiative would fall within the
ambit of the State Legal Services Authority. It should make efforts to make persons with mental
illness aware of their rights under Chapter V and, if so, to initiate proper schemes as Section 28 of
the Act of 2017 also refers to legal aid.Dr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

58. If there are vacancies, the State Mental Health Authority will not be able to function effectively.
Section 46 of the Act of 2017 provides for the composition of State Authority; under Section 49 of
the Act of 2017, the State Government has to fill vacancies in the Authority in time. As per Section
49, the State Government should, within two months from the date of occurrence of any vacancy
and three months of the anticipated vacancy, make a nomination to fill the vacancy. Because the
fully functional State Authority was not been established for almost four years since the Act of 2017
came into force, the State Government should ensure that the vacancies in the State Mental Health
Authority in future are filled up in time.
Trupti 41 22 March J-PIL-43-2022.doc
59. Under Section 55 (e) of the Act of 2015, the State Mental Health Authority must develop a
protocol for training all relevant persons and issue necessary instructions to law enforcement
officials, mental health professionals, and other health professionals. The State Government should
render all necessary assistance to the State Mental Health Authority in developing the protocol and
providing training to all relevant persons.
60. Given the State Mental Health Authority's chronic failure and lack of basic data, we intend to
issue certain directions in the operative portion of the judgment to ensure that it becomes functional
and relevant.
61. The next aspect that we deal with in the judgment is the rehabilitation of persons with mental
illness, which is of importance. Section 18 of the 2017 Act guarantees the right to access mental
healthcare. It states that every person has the right to receive mental healthcare and treatment from
mental health services that are either run or funded by the appropriate Government. Section 19 of
the Act elaborates on the right to community living, while Section 20 provides protection from cruel,
inhuman, and degrading treatment. Section 21 of the Act guarantees equal and non-discriminatory
rights, while Section 22 ensures the right to information. Under Section 23, individuals with mental
illnesses have the right to confidentiality. Section 24 restricts the release of information about Trupti
42 22 March J-PIL-43-2022.doc mental illness, while Section 25 guarantees the right to access
medical records. Section 26 ensures the right to personal contact and communication, and Section
27 guarantees the right to legal aid. Finally, Section 28 guarantees the right to file complaints about
any deficiencies in the provision of services.
62. Section 19 of the Act of 2017, which is important, reads thus:
"Section 19- Right to community living - (1) Every person with mental illness shall;--
(a) have a right to live in, be part of and not be segregated from society; and
(b) not continue to remain in a mental health establishment merely because he does
not have a family or is not accepted by his family or is homeless or due to absence of
community based facilities.Dr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

(2) Where it is not possible for a mentally ill person to live with his family or
relatives, or where a mentally ill person has been abandoned by his family or
relatives, the appropriate Government shall provide support as appropriate including
legal aid and to facilitate exercising his right to family home and living in the family
home.
(3) The appropriate Government shall, within a reasonable period, provide for or
support the establishment of less restrictive community based establishments
including half-way homes, group homes and the like for persons who no longer
require treatment in more restrictive mental health establishments such as long stay
mental hospitals".
(emphasis supplied) Trupti 43 22 March J-PIL-43-2022.doc Therefore, a person with mental illness
has the right to not to continue to remain in mental health establishments merely because he does
not have family or is not accepted by his family or is homeless or there is absence of community
based facilities. This provision has to be read along with Section 18(4)(b) of the Act of 2017 which
states that appropriate Government will make provision for half-way homes, sheltered
accommodation, supported accommodation as may be prescribed.
63. In the process of rehabilitation, the Mental Health Review Boards play a crucial part. Section 73
of the Act of 2017 contemplates the constitution of the Mental Health Review Boards in each District
or group of Districts in the State. The composition of the Board is provided under Section 74 of the
Act of 2017. A judicial officer is the chairperson of the Board. Section 77 contemplates applications
to the Board by any person with mental illness or his nominated representative or a representative
of a registered non-governmental organisation, with the consent of such a person. Section 77
provides that any individual with mental illness, their appointed representative, or a representative
from a registered non-governmental organization, with the individual's consent, who feels aggrieved
by a decision made by a mental health establishment or believes their rights under this Act have
been violated, may submit an application to the Board seeking resolution or appropriate remedy. No
fee or charge shall be imposed for Trupti 44 22 March J-PIL-43-2022.doc submitting such an
application. Each application should mention details specified. In exceptional circumstances, the
Board may accept oral or telephone applications from individuals admitted to a mental health
establishment.
64. Section 82 of the Act of 2017 outlines the powers and functions of the Mental Health Review
Board. It empowers the Board to register, review, amend, or revoke advance directives, appoint
nominated representatives, and adjudicate on applications challenging decisions made by medical
officers or mental health professionals. The Board also handles applications related to
confidentiality, resolves complaints about care deficiencies, and conducts inspections of prisons or
jails regarding health services. Additionally, if a mental health establishment violates the rights of
individuals with mental illness, the Board or Authority can conduct inquiries and take corrective
actions, including imposing fines up to five lakh rupees or canceling the establishment's registration.
The Board, in consultation with the Authority, may take necessary measures to safeguard the rights
of persons with mental illness, regardless of other provisions in the Act.Dr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

65. Section 80 of the Act of 2017 contemplates time bound disposal of the applications before the
Mental Health Review Board and the category of the applications to be disposed of. Section 80 reads
as follows :-
Trupti 45 22 March J-PIL-43-2022.doc "80. Proceedings before Board.-(1) The Board, on receipt of
an application under sub-section (1) of section 77, shall, subject to the provisions of this section,
endeavour to hear and dispose of the same within a period of ninety days.
(2) The Board shall dispose of an application--
(a) for appointment of nominated representative under clause (d) of sub-section (4) of section 14;
(b) challenging admission of a minor under section 87;
(c) challenging supported admission under sub- section (10) or sub-section (11) of section 89, within
a period of seven days from the date of receipt of such applications.
(3) The Board shall dispose of an application challenging supported admission under section 90
within a period of twenty-one days from the date of receipt of the application.
(4) The Board shall dispose of an application, other than an application referred to in sub-section
(3), within a period of ninety days from the date of filing of the application.
(5) The proceeding of the Board shall be held in camera.
(6) The Board shall not ordinarily grant an adjournment for the hearing.
(7) The parties to an application may appear in person or be represented by a counsel or a
representative of their choice.
(8) In respect of any application concerning a person with mental illness, the Board shall hold the
Trupti 46 22 March J-PIL-43-2022.doc hearings and conduct the proceedings at the mental health
establishment where such person is admitted.
(9) The Board may allow any persons other than those directly interested with the application, with
the permission of the person with mental illness and the chairperson of the Board, to attend the
hearing.
(10) The person with mental illness whose matter is being heard shall have the right to give oral
evidence to the Board, if such person desires to do so.
(11) The Board shall have the power to require the attendance and testimony of such other witnesses
as it deems appropriate.Dr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

(12) The parties to a matter shall have the right to inspect any document relied upon by any other
party in its submissions to the Board and may obtain copies of the same.
(13) The Board shall, within five days of the completion of the hearing, communicate its decision to
the parties in writing.
(14) Any member who is directly or indirectly involved in a particular case, shall not sit on the Board
during the hearings with respect to that case."
(emphasis supplied) For each category of application time limit is prescribed. Section 83 of the Act
of 2017 provides for an appeal to the High Court against the order of Authority or Board.
Trupti 47 22 March J-PIL-43-2022.doc
66. As per Section 82(c) of the Act of 2017, the applications from persons with mental illness or their
nominated representative or any other interested person against the decision of a medical officer or
mental health professional in charge of mental health establishment or mental health establishment
under Sections 87, 89 or 90 can be received by the Board. Section 87 deals with the admission of
minors to mental health establishments after following the procedure laid down. Section 89 is
regarding the admission and treatment of persons/patients with mental illness, with high support
needs, in mental health establishments up to 30 days and Section 90 is for such persons beyond 30
days. The Board is also empowered to decide the applications regarding non-disclosure under
Section 25(3) of the Act. Section 25 confers the right of persons with mental illness to have access to
their primary medical records, and if the medical records are withheld, such person has the right to
apply to the Board. The Board is also authorised to adjudicate complaints about the deficiency in the
provision of services made by any person or his nominated representative. Therefore, it is clear that
the Act of 2017 confers broad and important powers to the Board. These provisions would show that
the Board plays a crucial role in safeguarding the rights of persons with mental illness and in their
rehabilitation.
67. The constitution of the State Mental Health Review Boards was placed on record stating that
they were established by Notification dated 15 November 2021, that is, three years after the Trupti
48 22 March J-PIL-43-2022.doc Act of 2017 had come into force. Information regarding the Boards
is as follows:
Mental Health The district under its jurisdiction Review Board 1 Thane Thane,
Palghar, Raigad, Mumbai. 2 Pune Pune, Satara, Solapur.
3 Nagpur Nagpur, Wardha, Bhandara, Gondia, Chandrapur, Gadchiroli.
4 Kolhapur Kolhapur, Ratnagiri, Sindhurag, Sangli.
5 Nashik Nashik, Ahmednagar, Dhule, Jalgaon, Nandurbar.Dr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

6 Akola Akola, Buldhana, Washim, Amravati, Yeotmal.
7. Aurangabad Aurangabad, Jalana, Parbhani, Hingoli.
8 Latur Latur, Beed, Osmanabad, Nanded.
68. We were informed that the Mental Health Review Board at Thane had conducted eight meetings
from August 2022 to July 2023; the Pune Board held three meetings in the year 2023; the Nagpur
Board held 11 meetings from August 2022 to July 2023; Kolhapur Board held four meetings from
August 2022 to April 2023; Nashik Board held only one meeting in November 2022; Akola Board
also held only one meeting in January 2023; Aurangabad Board held six meetings from June 2022
to June 2023; and Latur Board held two meetings from September 2022 to March 2023.
Trupti 49 22 March J-PIL-43-2022.doc
69. The State Mental Health Authority had submitted a chart containing data and stated that
pursuant to the directions issued, the Deans of these four hospitals had supplied the data to the
State Mental Health Authority. This compilation contained a summary and two further components,
i.e. one dealing with the patients who were fit for discharge but not yet discharged and the second,
the patients who were unfit for discharge. Regarding patients who were fit for discharge but not yet
discharged, the data about four mental health hospitals was provided. The summary was as follows:
A Top up sheet ( Concise Data) Summary Opinion of No of Patients sent Length Of
Stay ( Total no of patient) Doctor with home but not Discharge accepted by family Sr.
Name of Government No Mental Hospital More Up to 6 6 Months 1 to 2 2 to 5 5 to 10
than 10 Total Fit Unft 2023 2022 2021 Months To 1 Year years years years years 1
Nagpur Mental Hospital 229 32 25 46 74 116 522 138 384 1 1 1 2 Thane Mental
Hospital 507 138 69 53 42 114 923 429 494 5 3 2 3 Pune Mental Hospital 473 63 75
96 150 226 1083 411 672 3 2 0 4 Ratnagiri Mental Hospital 87 14 7 11 6 19 144 44 99 1
0 1 Total 1296 247 176 206 272 475 2672 1022 1649 10 6 4 Therefore, 1022 patients
were declared fit for discharge, but were awaiting discharge from the hospital. As far
as 451 patients were concerned, there did not appear to be any serious impediment,
but there was a delay in view of the compliance of the process. As regards columns-
'a' and 'c' of the chart, these patients had serious issues that needed to be dealt with
by the State Mental Health Authority. As regards the patients who were declared
unfit for discharge, the data was as follows:
 Trupti                                                                                   50                            22 March J-PIL-43-2022.doc
                                                                                        Reason of Not yet discharged - Fit
                                                                                    A                        B                           Dr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

Relatives not traceable Discharge in process Poor Family support TOTAL NO. OF
Patients Fit Relatives not traceable Waiting for responce Old age of relatives Sr.No.
NAME OF MENTAL HOSPITAL for Discharge But not yet Change of address Poor
acceptance by family Discharged members Change of phone number Distant relatives
Waiting for Rehabilitation The Petitioner pointed out that in the Summary-A
provided, 1649 patients were shown as unfit for discharge in the doctors' opinion,
and 475 patients were shown to have been in the hospital for more than ten years. It
was not clear whether there was an appropriate review of these patients.
70. We directed eight Review Boards to supply the State Mental Health Authority with information
regarding patients reviewed in the preceding three months. We also directed the District Health
Officer and the Psychiatrist attached to the Boards to attend the next meeting of the State Mental
Health Authority to devise a holistic plan of action.
71. During the hearing on 11 October 2023, the State Mental Health Authority placed only minutes
of the meeting of the Authority before us without any affidavit. From the information given to us by
the Maharashtra State Legal Services Authority, it transpired that the scrutiny conducted under the
earlier directions had revealed a position of grave concern. As per the chart given to us Trupti 51 22
March J-PIL-43-2022.doc earlier, 1022 patients were stated to be fit for discharge. We had directed
that special emphasis be given to the cases of 475 patients who had been in mental health
establishments for more than ten years. We were informed that apart from routine examinations by
one psychiatrist, as far as 475 patients were concerned, the examination process by two psychiatrists
was carried out and was in progress. As of 11 October 2023, 379 patients had been certified by two
Psychiatrists as fit for discharge. That meant that 379 patients in mental health establishments, even
after more than ten years, could be discharged yet continue to live in these establishments. This was
indeed a deplorable situation.
72. As per the process, the opinion of two Psychiatrists has to be placed before the Review Board and
upon directions issued by the Review Board, further action would be taken. Two Psychiatrists had
found them to be fit. The State Mental Health Authority also informed us that the examination
process by two psychiatrists with respect to the remaining patients out of 475 would be completed
within two to three weeks, and thereafter, their cases would be placed before the Review Board. The
State Government was called upon to issue necessary communications based on our observation to
all the Review Boards to take up the matters of the above class of patients on a priority basis.
73. During the hearing on various dates, it became amply clear that the State Mental Health
Authority did not have any plan for Trupti 52 22 March J-PIL-43-2022.doc rehabilitation of the
patients with mental illness. Even for a mere outline of the plan, the Authority sought time from the
Court.
74. Two affidavits were tendered during the further hearing on 8 November 2023 pursuant to the
earlier directions. One was by the State of Maharashtra through the Assistant Commissioner on
behalf of the Persons with Disability Welfare Commissionrate, and the second was by the State
Mental Health Authority. The Authority had placed on record that two meetings were held on 13Dr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

October 2023 and 23 October 2023, wherein it was noted that out of fit patients, 23 were physically
challenged, and 71 were mentally challenged.
75. Two meetings were held on 26 October 2023 and 27 October 2023 by the Pune Board and
Nagpur Board to take an overview of the discharge of long-stay patients. It was also placed on record
that a draft plan was prepared for a systematic reunion and rehabilitation process. The affidavit filed
on behalf of the State Government placed the details of halfway homes on record. It was also stated
that the affidavits were filed in proceedings pending before the Hon'ble Supreme Court in the case of
Gaurav Kumar Bansal1 and the Action Taken Report was also filed before the Hon'ble Supreme
Court, the details of which were placed on record. The affidavits filed before the Hon'ble Supreme
Court were reiterated and reproduced in the affidavit filed before us. Except for filing an affidavit
based on an 1 Contempt Petition (C) No. 1653/2018 in WP (C) No. 412 of 2016 Trupti 53 22 March
J-PIL-43-2022.doc affidavit already filed before the Hon'ble Supreme Court, we did not have any
information placed on record by the State.
76. The State Mental Health Authority informed that 263 patients who had been staying in the
Medical Health Establishment for more than 10 years were finally found fit by the Review Boards,
out of whom 24 were reunited with their families. The State Mental Health Authority stated that out
of 263 patients, as a target for the next date, an attempt would be made to rehabilitate at least 50
patients out of the said list. For this purpose, a priority list would have to be prepared. Those found
fit for immediate rehabilitation could be put on the list. The Petitioner suggested that if the patients
who had overstayed the Mental Health Establishment for more than 10 years were being
rehabilitated by an escort drive, then if any other patients were found fit but had spent less than 10
years, they could also be attempted to be rehabilitated if they were from the same locality or village.
The learned Amicus had pointed out that it could be easier to rehabilitate the patients who had
stayed for less time in the Mental Health Establishment.
77. The next issue that arose was that 94 patients were found to be fit by the Review Board; however,
they could not be discharged because either they were physically challenged or mentally challenged.
This was where the role of the Directorate of Disabilities would be important. The plan of action by
the Commissioner for Trupti 54 22 March J-PIL-43-2022.doc Disabilities regarding these 94
patients was directed to be placed on record by the next date. Even on that date, only an outline of
the plan of action was placed before us.
78. On 8 December 2023, the State Mental Health Authority tendered an affidavit sworn by the
Medical Superintendent Regional Mental Establishment, Thane, dated 7 December 2023. In this
affidavit, the efforts taken by the Authority with respect to the rehabilitation of patients were
enumerated. It was stated that the Mental Health Establishment in Pune rehabilitated 42 patients in
halfway homes. As regards Thane Mental Establishment, an attempt was made through a system of
escorting patients under the "Drive for Escort" scheme. The details of this Scheme were placed on
record. This campaign was carried out by a Mental Health Establishment to send the patients in
batches accompanied by hospital staff with the assistance of local authorities. It was stated that six
patients attempted to reunite with their families through this method, and three were successfully
reunited. Three patients could not be reunited for various reasons, which have been placed onDr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

record, such as resistance from the relatives, etc. Therefore, these three patients, though certified as
no longer in need of continuous monitoring had to be returned to the Mental Health Establishment.
79. The patients had to be returned because there is a lack of coordination between the State Mental
Health Authority and the Trupti 55 22 March J-PIL-43-2022.doc Government Departments as
regards the persons to be sent to the halfway homes. We therefore directed that the Principal
Secretary of the Public Health Department, who is the Chairperson of the State Mental Health
Authority, and the Principal Secretary of the Persons with Disabilities Welfare Department hold a
joint meeting to address the issues highlighted in the orders and streamline the procedure for
coordination.
80. In conclusion, from this narration and the data presented, various crucial issues regarding the
functioning of the Act of 2017 regarding rehabilitation of cured patients in the State of Maharashtra
emerge, and the scenario is disturbing.
81. Under Section 18 (3) of the Act of 2017, the appropriate Government is under the mandate to
make sufficient provision, as may be necessary, for a range of services required by persons with
mental illness, which includes provisions for half-way homes, shelter accommodation, supported
accommodation, as may be prescribed, including rehabilitation establishments. Currently, there are
only six half-way homes and the State Government is considering increasing the number to twelve.
Six additional half-way homes accordingly should be created as early as possible preferably within a
period of four months. This is to ensure the right conferred under Section 19 of the right to
community living.
Trupti 56 22 March J-PIL-43-2022.doc
82. Reply affidavit is filed by the Assistant Commissioner, Persons with Disabilities Welfare
Commissionerate on 8 November 2023. In this affidavit, reference is made to the case of Gaurav
Kumar Bansal before the Hon'ble Supreme Court, where the issue of rehabilitation of cured patients
in mental healthcare hospitals is considered. Pursuant to the directions, a list of non-governmental
organisations and establishments accommodating cured patients is provided. It lists six
non-governmental organisations in Mumbai, Nagpur and three in Pune. The capacity is around 525,
and the current position is stated to be 147. In the case of Gaurav Kumar Bansal, the Hon'ble
Supreme Court has directed that the Union of India, through the Department of Empowerment of
Persons with Disabilities to circulate guidelines prepared for the State Government for setting up
rehabilitation homes for persons living with mental illness who do not need further hospitalisation
of those who are homeless and are not accepted by their families. The Union of India has
accordingly circulated the guidelines to the State Government for setting up rehabilitation homes.
The guidelines state as under :
"Guidelines for the State Government for setting up of Rehabilitation Homes for
Persons Living with Mental Illness (who have been cured, do not need further
hospitalization, are homeless or are not accepted by their families) Many persons
with mental illness after hospitalization recover adequately and go back to their livesDr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

with mental illnesses, in the society/ community - living with families or living Trupti
57 22 March J-PIL-43-2022.doc independently. A small proportion of such persons,
even after sufficient recovery, may not be capable of living independently, and may
also not have families or with families who unable to take care of them. This group of
"Long Stay Patients" (LSP), have been the concern of many stakeholder groups, in the
last few decades- because despite advances in mental health science- and this sizable
group of persons not only continue to occupy beds in the hospitals; but also get
deprived of their human rights. The Hon'ble Supreme Court in the matter of Writ
Petition (Civil) No. 412/ 2016 in the matter of Shri Gaurav Kumar Bansal Vs State of
UP and others has directed the Central Government to frame guidelines for
rehabilitation of such persons with mental illness who have recovered but continue to
remain in various mental hospitals.
2. In light of the above, the Department of Empowerment of Persons with
Disabilities, Government of India prescribes the following guidelines for setting up of
Rehabilitation Homes for Persons Living with Mental Illness (who have been cured,
do not need further hospitalization, homeless or are not accepted by their families):-
 The State Government shall be responsible to take necessary steps for creation and
management of 'Rehabilitation Homes"- for Persons Living with Mental Illness to
provide for the combined needs of Half-Way Homes & Long-Stay Homes for the
foreseeable future.
 The State Government should assess the need for such "homes" specifically for the
"Long Stay Patients" (beyond two year length of stay) in the Mental Hospitals and
Mental Health Institutions in its State.
 Based on the assessment of requirement of such Trupti 58 22 March
J-PIL-43-2022.doc homes, initially at least one or two homes may be set up in the
selected city where the mental health institute/ hospital is located with the short term
goal to provide such "homes" for all the Long Stay Patients by the State.
 The "Rehabilitation Homes" must follow the Social Care Model with efforts at
Reintegration and Rehabilitation beyond Relocation. All such homes should have
Day Care Center as part of the Home, or at least in close geographical proximity and
in active consideration.
 The "Rehabilitation Homes for Persons Living with Mental Illness" should have the
following facilities / infrastructure :-
(iv) Physical Infrastructure -
 The rehabilitation homes should be located outside any hospital premises.
                         The building housing such persons shouldDr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

                          be preferably not more than 2 storey
                          building and the balconies are properly
                          wire fenced.
                         Proper boundary wall should be there
                          around such homes.
                         The building should have accessible
features and should fulfill the basic safety requirement relating to electricity.
                         There should be separate accommodation
                          for male and female inmates.
                         There should be a clear entry and exit
                          policy.
                          (v) Human Resource requirement per 25
                          residents
                       1 House Incharge
                       1 Office Assistant
 Trupti                                        59           22 March J-PIL-43-2022.doc
                       1 Social Worker
                       1 Vocational Instructor
                       2 Trained Care givers
                       2 Helpers
 1 Visiting Psychiatrist (should be available on call also to attend emergency situations)  1 Visiting
General Physician (should be available on call also to attend emergency situations)  Security as per
requirement depending on the size of the premises and number of inmates.
 Housekeeping personnel and kitchen staff as per requirement.
(vi) Other Norms  Cultural and Sporting activities may be conducted involving such persons so as
to make them feel homely and living in the community.
 Counselling assistance should be provided to such persons to make them independent.
 There should be close coordination with the Vocational / skill Training institutes in the nearby
vicinity to impart skill training to the inmates of the rehabilitation homes.
 A District Level Committee should be formed which would visit such homes periodically and a
register be maintained regarding such visits so as to ensure compliance of norms.
 Proper cleanliness should be maintained in the rehabilitation homes.Dr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

 The provisions of Rights of Persons with Trupti 60 22 March J-PIL-43-2022.doc Disabilities Act,
2016 containing various rights and entitlements for PwDs should be followed in letter and spirit.
 The Central Government shall so provide necessary technical guidance for setting up of such
homes, if required by the State Government".
(emphasis supplied) Substantial emphasis is placed on the long stay patients.
83. A contempt petition was filed in the Hon'ble Supreme Court since there was a
non-implementation of the directions issued by the Hon'ble Supreme Court in the case of Gaurav
Kumar Bansal. In light thereof, the meeting was held by the Chief Secretary of State of Maharashtra,
and a report was submitted to the Hon'ble Supreme Court on behalf of the State of Maharashtra. It
was stated in the report that the State Government is considering creating halfway homes and
rehabilitation homes as a permanent mechanism. In the meeting under the Chairmanship of the
Chief Secretary, it was decided that with due coordination with the Public Health Department, the
Commissioner for Persons with Disabilities, a revised proposal of a road map for setting up halfway
homes and rehabilitation homes needs to be prepared with the approval of the Cabinet. It was stated
that a temporary measure needs to be taken to create halfway homes and rehabilitation homes.
However, this Action Taken Report was of 24 July 2021. The affidavit in reply was filed in the
contempt petition pending before the Hon'ble Trupti 61 22 March J-PIL-43-2022.doc Supreme
Court on 6 December 2021. These are not recent documents. In reply, in this PIL, reference was
made only to six institutes and accommodation of 130 persons in the same.
84. A Government Resolution dated 1 September 2023 issued by the Department of Disability
Welfare was placed on record concerning the contempt petition pending before the Hon'ble
Supreme Court. This Government Resolution creates 16 rehabilitation centres and lays down a
methodology for the steps to be taken for release from the rehabilitation centres. It was stated in the
first phase that there would be 16 rehabilitation centres. Appendix to the Government Resolution
dated 1 September 2023 lays down the responsibilities of the head of the rehabilitation centre and
other persons associated with it.
85. During the hearing on 11 October 2023, rehabilitation of the patients fit to be discharged was
considered. As regards the issues that were raised by us in the earlier order and were to be taken in
the meeting for detailed consideration, the same was referred to in clause-3 of the minutes of the
meeting, which read thus:
"1. Patient data should be in one format; there shouldn't be separate data for the
same variables.
2. As per the Hon. High Court's directions, a representative of the Social welfare
department attended a meeting of SMHA. Dr.Prachi Chivate explained the discharge
process of the fit patients. Undersecretary, PwD Welfare department explained the
GR issued on 1st September 2023 about Trupti 62 22 March J-PIL-43-2022.doc
accommodating discharged persons from Mental Hospitals.Dr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

3. There is a need to address the issue of schooling of adult Intellectually disabled
persons who have been discharged from mental hospitals.
4. As per Hon., the High Court gave directions regarding addressing the issue of
discharged patients effectively. SMHA members gave inputs about involving
grassroots-level health workers in the comprehensive plan. Hon. Commissioner, sir,
instructed to make a comprehensive and holistic plan for rehabilitation of patients
living with mental illness with the active involvement of a psychiatrist from MHRB
and District Health Officer."
86. Thus, on this crucial issue of rehabilitation of cured patients all that transpired in the meeting
was that some members of the Authority gave inputs of grassroots-level health workers in the
comprehensive plan. The Commissioner was asked to make a holistic plan for the rehabilitation of
patients living with mental illness. Nothing was concluded in the meeting. Even for a mere outline of
the plan, the State Mental Health Authority informed the Court that details would be provided on
the next date. Thus, even as of 11 October 2023, the Authority still lacked a comprehensive plan or a
road map. The actions of the Authority were not commensurate with the gravity of the issue.
Without keeping in mind that the Authority has lost substantial time to reach its goal because it
started functioning with a five-year delay, the State Mental Health Authority stated that each case
would be examined independently on its own merits. The Act of 2017 contemplates Trupti 63 22
March J-PIL-43-2022.doc creation of halfway homes, shelter accommodation, supported
accommodation and hospital and community-based rehabilitation establishments. No data is placed
before us regarding shelter accommodations, support accommodations, and hospital- and
community-based rehabilitation establishments. The state government was directed to place all the
data before us.
87. On 8 November 2023, two affidavits were placed before us regarding two meetings held on 13
October 2023 and 23 October 2023. The affidavit filed on 5 November 2023 by the Chief Executive
Officer, State Mental Health Authority, emphasized the long-stay issue. The affidavit would reveal
that even as of 5 November 2023, a plan for systematic reunion/ rehabilitation of long-stay patients
was still at the draft stage. Then, by affidavit dated 7 December 2023, information of all mental
health hospitals, Thane, Pune, Nagpur and Ratnagiri, was placed on record. The Commissioner for
Persons with Disabilities provided a chart for compiling the detailed information of patients to be
rehabilitated on 3 December 2023. In the meanwhile, that the mental health hospital at Pune had
rehabilitated 42 patients in the halfway homes and attempted the reunion of six patients through a
conventional system of escorting the patients.
88. A draft Action Plan was finally placed on record, in which, the Authority has classified the
patients fit for discharge into two Trupti 64 22 March J-PIL-43-2022.doc broad categories.
Category-A- those whose relatives are existent. Category-B- those whose relatives are not known.
The draft Action Plan reads thus:
"Once patient is treated and certified by 2 independent psychiatrist as fit for
discharge, then relatives will be communicated about the same.Dr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

 For patients staying above 180 days , three reminders by the psychiatric social
service superintendent to the relatives of patient through telephonic calls/electronic
messsages/letter at their place at an interval of 8 days will be sent.
 Psychiatric nurse along with social service superintendent will use all their skills to
establish a good rapport with relatives in order to understand basic cause of delay in
taking discharge.A detailed case by case individualized study will be done by them to
recognize the psychodynamics between family members and know their
interpersonal relations .
 Relatives should be educated about the triggers of psychiatric illness and the
precipitating factors and how to overcome them.
 Proper psychoeducation of relatives of patients about remitting nature of illness
will be done and that it can be controlled on medications and with proper social
support ,relapse rate would reduce will be counselled hereof.
 A maximum of one month will be given for social service superintendent for
detailed workout of each case from date declared fit by 2 independent psychiatrist. 
During this process following are major hurdles faced by social service
superintendent:
Authority has classified classify patients fit for discharge into categories :
          a) Those whose relatives are existent
 Trupti                                  65             22 March J-PIL-43-2022.doc
           b)     hose whose relatives are not known
Escort drive is concept wherein patients fit for discharge are sent home in an
ambulance accompanied by the mental health professionals with proper care , safety
and coordination .They are sent twice a week in batches of 3 to 4 per batch to their
homes.
Category A includes (Relatives are existent) the following groups Group 1 Group 2 Group 3 ↓ ↓ ↓
Address is Relatives are not Address is confirmed changed / ready to take Phone not responsibility
reachable ↓ ↓ ↓ Police officials and Relatives to be Escort Drive to be local panchayat to presented inDr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

front operated help for locating of MHRB for address DLSA to detailed help discussion ↓ ↓ Sent to
disabilities Reunited with department for family accommodating in different rehabilitation ↑←
Returned centre/ halfway Back Hospital home  For Address confirmed cases group 3, an attempt
could be done through escort drive to reunite the patients with their Trupti 66 22 March
J-PIL-43-2022.doc families.
Inspite of that if patients return back from home for those not accepted by family members, then
they would qualify for Group 2 wherein to discuss this patient in front of MHRB and as the decision
of board happens direct them to disability department and put in rehabilitation centre accordingly.
 For the group of patients whose address and relatives are confirmed but because of various
reasons like: (Group 2 ) Those who have admitted are not the direct relatives of patient.
Those who have admitted are incapable of taking care due to financial constraints or social cause
(eg. Sister is married in family and parents are no more alive.no one to take care of patient brother.)
Those relatives who have medical reasons at home (eg.they have undergone surgery and require
medical supervision.It would be difficult to take care of psychiatric patient along with the operated
patient) After discussion in MHRB for all possible options wherein police officials and DLSA have
done efforts, these patients will be sent to rehabilitation centres through disabilities department.
Later on patients can get reunited with family members from rehab centres/halfway homes.
 For group 1 ,where address is changed or phones are not reachable,social service superintendent
should take the help of police department and other concerned government agencies at their
respective place.
 Police department should extend cooperation as regards to tracking the addresses of patients and
putting legal pressure on relatives for accepting patient.
Trupti 67 22 March J-PIL-43-2022.doc  District Legal Service authority also need to assist in
process of discharging patient to relatives who are reluctant to take them home.
 In the above process, concerned social service superintendent along with treating psychiatrist
should inform the mental health review board where the patient's residence fall in jurisdiction
.MHRB along with DMHP team should accelerate the pace of tracking the relatives of patients.
 For Category  ( those who are found wandering and homeless and unknown patients brought by
police) We request the police department to establish a common portal for unknown patients and all
mental hospitals to upload the photo and information of unknown patients on that portal. That
would ease the process of finding the family and place where patient belongs to and accelerate the
pace of reuniting with their families located anywhere in the country through the medium of portal.
In order to safeguard the identity of patients ,this portal should be accessed only by mental hospitals
,police officials and concerned government agencies.Dr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

Incharge of concerned police station should report to the concerned MHRB on monthly basis about
the progress of discharge of patients.
At Present following table shows data of all patients more than 6 months but less than 10 years:
             Name of Regional Mental        No of patients from
             Hospital                       6 months to 10
                                            years
 Trupti                                 68              22 March J-PIL-43-2022.doc
An attempt will be made to discharge a total of 50 to 70 patients from each mental hospital either to
homes or to rehabilitation centres/halfway homes in each month.
As mentioned, patients in group 1 and group 3 wherein efforts become unsuccessful and those from
group 2 whose relatives are not ready to take responsibility, they need to be discussed in Mental
Health Review Board meeting. After the approval from the Board, they need to be sent to
rehabilitation centre or halfway homes through Disabilities department.
A monthly report will be sent from respective regional mental hospital of the patients who need to
be sent to rehabilitation centre through social disabilities department within 3 days of MHRB
meeting .
Social disabilities department need to revert within 7 working days of receipt of the eligible data and
pass order for accommodating these patients in different rehabilitation centres.
As soon as allocation of proper rehabilitation centre is done,patients should be shifted from mental
hospital to that respective centre within a span of 7 working days After the discharge of patient :
Community based services which are functional will aid in the process of recovery of
patient as below:
1.DMHP (District Mental Health Program): A team of psychiatrist,psychiatric social
worker,psychiatric nurse is posted at every district hospital.A total of 10 beds are
reserved Trupti 69 22 March J-PIL-43-2022.doc for psychiatric admissions at eachDr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

district civil hospital. The objectives of program are :
• Early detection & treatment of mental illness at the District Hospital Level and
below (OPD/ Indoor & follow up) within community itself.
• To provide sustainable basic mental health services and to integrate these health
services into the community with general health services.
• Training of Medical Officers, Community Health Workers, Nurses, Pharmacists of
CHC and PHC for integration of mental healthcare in general health care, for
increasing reach of mental healthcare and to facilitate early diagnosis and
management and follow-up of chronic cases. • Community awareness- Awareness
generation to increase help seeking behaviour and address stigma and discrimination
faced by mentally ill people.
• Inter-sectoral linkages- with schools and colleges and Outreach clinics and camps •
Psychotropic drugs, equipment, IPD services and ambulatory support.
This is broadly the outline of the Rehabilitation Plan.
89. Under 100 of the Act of 2017, every officer in charge of a police station has a duty to take any
person found wandering at large under protection whom, the officer believes has a mental illness
and is incapable of taking care of himself. Every person taken into protection must be taken to the
nearest public health establishment as soon as possible to assess the person's healthcare needs. The
medical officer in-charge of the public health establishment is responsible for assessing the person,
and the needs of the person with mental illness are to be addressed as per other Trupti 70 22 March
J-PIL-43-2022.doc provisions of this Act as applicable in the particular circumstances. Other steps
to be taken are also mentioned under this provision.
90. The State Mental Health Authority has suggested the police department to establish a common
portal for unknown patients and all mental hospitals to upload the photo and information of
unknown patients on that portal. That would speed up the process of finding the family and place
where patient belongs to and accelerate the pace of reuniting with their families located anywhere in
the country through the portal. In order to safeguard the identity of patients, this portal should be
accessed only by mental hospitals, police officials and concerned government agencies. The regional
mental establishments must send their monthly reports to the rehabilitation centre through the
Social Disabilities Department within three days of the Mental Health Review Board meeting. Once
the necessary data for accommodating patients in different rehabilitation centres is received, the
Social Disabilities Department must inform the State Mental Authority within seven days. After the
rehabilitation centre is allocated, patients should be transferred from the mental health
establishments to their respective centres within seven days.
91. What was placed before us by the State Mental Health Authority reproduced above is a draft of
the rehabilitation plan. The State Mental Health Authority has to prepare a comprehensive plan ofDr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

rehabilitation of cured persons with mental illness. The plan Trupti 71 22 March J-PIL-43-2022.doc
should provide the procedure for identification of such mentally cured persons, segregation of
mentally ill persons who are cured on a degree of illness as far as possible for rehabilitation and
approval to the halfway homes, and provisions be made for uniform distribution. The action plan
should specify each Authority's roles and stage-wise rehabilitation process. The action plan should
be flexible to cater to individual needs. The State Mental Health Authority can invite input from
different stakeholders, such as mental health professionals and non-governmental organizations
working in this field, so that the plan can be comprehensive. The State Mental Health Authority
should initiate the collection of primary data. There is a lack of essential data. Without basic data,
systematic efforts are not possible. All relevant government organizations should supply the
necessary data required by the State Mental Health Authority to perform their duties under the Act
of 2017. More particularly, cooperation from the Police Authorities and the Commissioner of
Disabilities Welfare is necessary.
92. The next aspect is the involvement of the Maharashtra State Legal Services Authority.
93. The National Legal Services Authority has framed a scheme titled NALSA (Legal Services to the
Mentally Ill and Mentally Disabled Persons) Scheme, 2015. The NALSA Scheme contemplates that
the State Legal Services Authority and a Board of Visitors would review the persons in these
hospitals, homes and Trupti 72 22 March J-PIL-43-2022.doc facilities to ascertain whether there are
any cured persons staying there whose families appear reluctant to take them back or are
themselves not able to contact their families. The Scheme contemplates that whenever the State
Legal Services Authorities / District Legal Services Authorities or Board of Visitors find such
inmates, these authorities must take necessary steps to facilitate restoration, including providing
legal representation in Court to seek orders for restoration of the cured person with the family.
Various measures are provided under the Scheme. The details are reproduced herein below :
"(i) Legal services institutions shall during their visits to the psychiatric hospitals or
homes or facilities ascertain through interaction with inmates, doctors and staff as to
whether any of the persons admitted there are victims of forced admission or not. In
such cases, legal services shall be given to such persons for their release from the
psychiatric hospitals or homes or facilities.
(ii) SLSAs/DLSAs should setup Legal Services Clinics at the psychiatric hospitals,
homes and facilities in order to provide legal assistance wherever required to the
Mentally ill/ mentally disabled persons and their families to address legal issues
concerning the mentally ill and mentally disabled persons.
(iii) Such a legal clinic should be manned by Para Legal Volunteers and Panel
Lawyers who are sensitive to such issues and persons.
Trupti 73 22 March J-PIL-43-2022.docDr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

(iv) It would be quite appropriate to train the doctors, nurses and other para medical
staff/administrative staff at the mental health facilities as Para Legal Volunteers so
that the best legal services can be provided keeping in mind the welfare of the
mentally ill/mentally disabled persons.
(v) The Clinic should also help in ensuring that the homes meant for the mentally ill
and mentally disabled persons have all facilities, including for learning appropriate
skills for independent and/or assisted living and earning. The legal services
institutions may approach the Government, and if necessary the High Court for
appropriate directions, to ensure the availability of such facilities.
(vi) The Legal Services Institutions should also connect the mentally disabled persons
with the National Trust for Welfare of Persons with Autism, Cerebral Palsy, Mental
Retardation and Multiple Disabilities so that benefits provided under the "National
Trust For Welfare of Persons with Autism, Cerebral Palsy, Mental Retardation and
Multiple Disabilities Act, 1999" are assured to these persons and their families.
(vii) Legal Services Institutions should involve through the PLVs the para medical
staff/administrative staff and doctors at the mental health facilities to identify the
relatives and homes of those patients in relation to whom such facts are not available
on record and take appropriate steps through the different legal services institutions
to reach to the relatives of the patients to Trupti 74 22 March J-PIL-43-2022.doc
facilitate re-union of the patients with the near an dear ones.
(viii)Patients, who are housed in mental health centres, homes and facilities, away
from their domicile and home, must be considered for providing legal assistance to
ensure their transit to mental health centres, homes and facilities nearer to their
native place. This can be done with the involvement of SLSAs and DLSAs."
xxx
94. It is clear to us that if the efforts of the Maharashtra Legal Services Authority under the Scheme
are coordinated with those of the State Mental Health Authority, it would aid in resolving the issues
highlighted in this PIL substantially. Legal Services Authority will assist in discharging the patients
to relatives who are reluctant to take them home. It needs to be noted that the NALSA (Legal
Services to the Mentally III and Mentally Disable Persons) Scheme, 2015 is based on the Mental
Health Act, 1987 and the Persons with Disabilities (Equal Opportunities, Protection of Rights and
Full Participation) Act, 1995. The Mental Health Act, 2017 and the Rights of Persons with
Disabilities Act, 2016 have now replaced these two enactments. The Scheme will have to be brought
in consonance with these new enactments. The State Legal Services Authority informed us that a
communication has already been addressed with the National Legal Services Authority to take
corrective measures.
Trupti 75 22 March J-PIL-43-2022.docDr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

95. The State Legal Services Authority pointed out that as per the Scheme framed by NALSA titled "
Legal Services to Mentally Ill and Medically Disabled Persons Scheme 2015", jail visits are also
contemplated. The State Legal Services Authority stated that the Legal Services Authority do not
have expertise in the subject of dealing with mental illness. The State Legal Services Authority stated
that as and when the Authority plans visits to the jails, information would be given to the State
Mental Health Authority to coordinate efforts. Both Authorities would examine the statutory
provisions and then decide on a plan of action so that there was no conflict with any statutory
provisions or authority vested with this task.
96. The State Mental Health Authority has informed that to coordinate efforts in that regard,
whenever the statutory meetings of the State Mental Health Authority would be held, the
representative of the State Legal Services Authority in the context of the Scheme of National Legal
Services Authority would be invited as a special guest. The representative of the State Legal Services
Authority stated that they are ready to coordinate with the State Mental Health Authority in that
regard. This is more so because under Section 27 of the Act of 2017, a person with mental illness is
entitled to receive free legal aid to exercise any of his rights given under this Act. Section 27 is
defined as under :
"27. Right to legal aid.- (1) A person with mental illness shall be entitled to receive
free legal Trupti 76 22 March J-PIL-43-2022.doc services to exercise any of his rights
given under this Act.
(2) It shall be the duty of magistrate, police officer, person in charge of such custodial
institution as may be prescribed or medical officer or mental health professional in
charge of a mental health establishment to inform the person with mental illness that
he is entitled to free legal services under the Legal Services Authorities Act, 1987 (39
of 1987) or other relevant laws or under any order of the Court if so ordered and
provide the contact details of the availability of services".
Therefore, since under Section 27 of the Act of 2017, this duty is placed upon the Maharashtra State
Legal Services Authority, coordination between it and the State Mental Health Authority is
necessary. A protocol can be developed where if the State Legal Services Authority comes across any
person (including one in jail) with mental issues, steps can be taken as per the Act of 2017 and
correspondingly, if any mentally ill person requires legal assistance and legal aid, the Maharashtra
State Legal Services Authority can provide the same. It would be appropriate that both these
Authorities develop a protocol for collaboration.
97. The Maharashtra State Legal Services Authority would consider an action plan for the year to
focus on the right to legal aid to persons with mental illness as a separate initiative in consonance
with the Scheme framed by the National Legal Services Authority. While planning its activities, the
Maharashtra State Legal Services Authority should give special emphasis to creating an awareness
Trupti 77 22 March J-PIL-43-2022.doc programme with respect to providing legal aid for persons
with mental illness to achieve the objective of Section 27 of the Act of 2017.Dr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

98. The learned Counsel for the Maharashtra State Legal Services Authority has urged us to also
look into the issue of Prisoners with Mental illness. Section 2 (1)(w) of the Act of 2017 defines a
prisoner with mental illness as a person with mental illness who is an under-trial or convicted of an
offence and detained in a jail or prison. Section 103 of the Act of 2017 deals with prisoners with
mental illness. Section 103 of the Act of 2017 reads as under :
"Section 103. Prisoners with mental illness. -
(1) An order under section 30 of the Prisoners Act, 1900 (3 of 1900) or under section
144 of the Air Force Act, 1950 (45 of 1950), or under section 145 of the Army Act,
1950 (46 of 1950), or under section 143 or section 144 of the Navy Act, 1957 (62 of
1957), or under section 330 or section 335 of the Code of Criminal Procedure, 1973 (2
of 1974), directing the admission of a prisoner with mental illness into any suitable
mental health establishment, shall be sufficient authority for the admission of such
person in such establishment to which such person may be lawfully transferred for
care and treatment therein:
Provided that transfer of a prisoner with mental illness to the psychiatric ward in the
medical wing of the prison shall be sufficient to meet the requirements under this
section:
Provided further that where there is no provision for a psychiatric ward in the
medical wing, the prisoner may be transferred to a mental health Trupti 78 22 March
J-PIL-43-2022.doc establishment with prior permission of the Board. (2) The
method, modalities and procedure by which the transfer of a prisoner under this
section is to be effected shall be such as may be prescribed. (3) The medical officer of
a prison or jail shall send a quarterly report to the concerned Board certifying therein
that there are no prisoners with mental illness in the prison or jail.
(4) The Board may visit the prison or jail and ask the medical officer as to why the
prisoner with mental illness, if any, has been kept in the prison or jail and not
transferred for treatment to a mental health establishment.
(5) The medical officer in-charge of a mental health establishment wherein any
person referred to in sub-section (1) is detained, shall once in every six months, make
a special report regarding the mental and physical condition of such person to the
authority under whose order such person is detained.
(6) The appropriate Government shall setup mental health establishment in the
medical wing of at least one prison in each State and Union territory and prisoners
with mental illness may ordinarily be referred to and cared for in the said mental
health establishment.Dr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

(7) The mental health establishment setup under sub-section (5) shall be registered
under this Act with the Central or State Mental Health Authority, as the case may be,
and shall conform to such standards and procedures as may be prescribed".
(emphasis supplied) The Rights of Persons with Mental Illness Rules, 2018, also provide for the
right to legal aid under Rule 7. Under Rule 11, the mental Trupti 79 22 March J-PIL-43-2022.doc
health establishment where the prisoner with mental illness is detained must conform to the
minimum standards and procedures as prescribed.
99. Some of the aspects highlighted by the State Legal Services Authority as above may not strictly
fall within the ambit of this Public Interest Litigation. The NALSA (Legal Services to the Mentally III
and Mentally Disabled Persons), 2015 Scheme also includes a visit to jails apart from legal aid given
to the prisoners. The State Legal Services Authority will chalk out a programme to complement the
efforts of the State Government and the State Mental Health Authority in furtherance of the Act of
2017 in pursuance of the Scheme.
100. The Maharashtra State Legal Services Authority has furnished the statistics regarding the
prisoners in the State of Maharashtra. It is not necessary to reproduce all the data regarding the
number of prisoners and the occupancy, etc. The Prison Statistics India 2021, published by the
National Crime Records Bureau, Ministry of Home Affairs, contains these figures. We, however,
note that the Advisory is issued by the National Human Rights Commission, which is sent to all
Chief Secretaries of the State Governments and Union Territories on 19 June 2023. The Advisory
states that the prisons in the country have seen a significant number of deaths through suicide in
recent years due to various reasons, which include Trupti 80 22 March J-PIL-43-2022.doc mental
health issues. The Advisory covers various aspects pertinent to the matter at hand.
101. Section 31 of the Act of 2017 provides for training for medical officers in prison. The Advisory
stipulates the training of prison staff as under :
"2. Training of Prison staff
a) A component of mental health literacy must be included in the basic training of
Prison staff. This needs to be supplemented with refresher training every three years.
A suitable supervisory officer to be designated as the Mental Health Officer and
assigned to ensure such training.
b) The curriculum of such a component of mental health literacy in the basic and
refresher training of Prison staff must be prepared at the State level in collaboration
with a government mental health institution & other experts.
c) The Prison staff be trained for administering PFA (Psychological First Aid). PFA is
a training program to identify, understand and respond to signs of mental illnesses
and substance abuse disorders to enable trainees to develop "the skills to reach out
and provide initial help and support to an inmate developing a mental health orDr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

substance use problem or experiencing a crisis.
d) Selected Prison staff in each Prison barrack be trained in providing
Cardiopulmonary Resuscitation & First Aid (CPR), particularly for handling
attempted hanging, bleeding through self inflicted cuts or on ingesting toxic
substances.
Trupti 81 22 March J-PIL-43-2022.doc
c) They also be trained to inform the trained medical staff immediately and to shift
the patient to the closest medical facility".
The State Government should consider these recommendations.
102. The State Legal Services Authority has placed on record a communication received from the
Prison Authority on 5 October 2023 in response to its query regarding Section 103 of the Act of 2017
as under :
"1. Presently there are psychiatric wards in Yerwada Central Prison and Nashik Road
Central Prison in Maharashtra. As per the guidelines made by the Public Health
Department, Home Department, Government of Maharashtra letter dated 31st
August, 2023, this office have informed all the prisons in the state to follow the
guidelines regarding The Mental Health Care Act 2017. The process of registering the
psychiatric was under
Section 65 of the Mental Health Care Act 2017 is in process.
2. At present, a total of 05 posts of psychologists are sanctioned out of which 2 posts
at Nagpur Central Prison, 01 post at Borstal School, Nashik and 02 posts at Yerwada
Central Prison, Pune to treat the mentally ill prisoners regularly.
3. Likewise, 03 posts of psychiatrists have been sanctioned i.e. one post in Nagpur
Central Prison, one post in Mumbai Central Prison and one post in Yerwada Central
Prison. In other prisons, psychologists and psychiatrists from the nearest
government hospital/ government medical college visit the prison regularly for the
treatment of mentally ill prisoner.
Trupti 82 22 March J-PIL-43-2022.doc
4. In view of the current number of prisoners in all the Prisons of Maharashtra, it is
approved in principle to sanction 07 additional posts of psychologists and 06 posts of
psychiatric. A final order is being issued by the government in this regard.Dr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

5. Psychologists and psychiatrists from the nearest government hospital or
government medical college treat psychiatric patients in prisons which do not have
psychiatric wards and if necessary, on the recommendation of the Mental Health
Review Board, but with the prior approval of the state government under section 93
of the Mental Health Care Act 2017, mentally ill prisoners are admitted to the
Regional Mental Health Establishment.
6. Wide this office letter dated 14/9/2023, as per the guidelines of the Public Health
Department, all the Prison Establishments have been informed to submit the
quarterly report to the concerned Mental Health Review Board certifying that, there
is no prisoner with mental illness is lodged in the prison. Also informed to submit six
monthly report to the authority regarding the physical and mental condition of the
mentally ill prisoners admitted to the Psychiatric Ward in the prison.
7. As per section 65 of the Mental Health Care Act 2017, Mental Health
Establishments in prisons should be registered and instructions have been given to
all the prisons in Maharashtra that it should be maintained through proper
procedures and standards.
(emphasis supplied)
103. Though we refer to all these provisions and guidelines regarding prisoners with mental illness,
we intend to examine only a Trupti 83 22 March J-PIL-43-2022.doc limited aspect because the
subject is broad and requires a separate Petition by itself. Given the large number of prisoners in
Maharashtra, in principle, the proposal to sanction seven additional posts of psychologists and 6
posts of psychiatrists is approved, a timeline for issuing the final orders is required. Schedule to the
Advisory includes minimum standard for mental healthcare in prison, as per Rule 11 of the Rights of
Persons with Mental Illness Rules, 2018. Some of the minimum standards are required prompt and
proper identification of persons with mental health problems in the prison, mandatory physical and
mental status examination for identification of persons with serious mental illnesses, protocols for
dealing with prisoners with suicidal risk and crisis relating to mental illness, implementation of
National Mental Health Program in prison, providing trained four counsellors for every 500
prisoners etc. The State should examine these recommendations and incorporate them if feasible.
104. The Act of 2017 grants rights to individuals with mental illness and fixes responsibilities for the
designated authorities. The State Mental Health Authority is the Nodal Authority for ensuring the
effective enforcement of this Act in Maharashtra. Without an active and functional State Mental
Health Authority, the Act of 2017 will remain on paper. Even after two years, the essential data is
still lacking, and there is no clear road map for the rehabilitation of recovered patients. The Act
assigns responsibility to both the State Government and the State Mental Health Authority to
achieve its Trupti 84 22 March J-PIL-43-2022.doc objectives. It is imperative for the State
Government to fulfil its obligations concerning rehabilitation and funding for the State Mental
Health Authority.Dr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

105. Now that the State Mental Health Authority has commenced working through various court
orders, it must diligently carry out its responsibilities, especially because of the significant delay of
almost four years. Though we have passed various orders over two years, this Court cannot be
expected to replace the State Mental Health Authority and perform its function, nor should the
Authority rely on the Court to oversee its work. The role of the Court in a Public Interest Litigation is
primarily to strengthen the existing mechanism so that it performs efficiently. By issuing various
directions, we intend to achieve the said objective. The responsibility now lies on the State Mental
Health Authority and the State Government to ensure that the objectives of the Act regarding
persons with mental illness are met with a fully manned and adequately functioning State Mental
Health Authority. We hope and trust that the State Mental Health Authority, departments of the
State of Maharashtra and all the governmental agencies involved will work together to ensure that
the adequate mental healthcare services are provided to individuals suffering from mental illness in
the State.
106. In view of the above discussion and as a culmination of the various orders over a period of two
years, we close the proceedings in the PIL with the following directions:
 Trupti                                 85              22 March J-PIL-43-2022.doc
(i)      The State Mental Health Authority shall prepare a
comprehensive plan/ protocol for the rehabilitation of cured patients within six months from today.
It is open for the State Mental Health Authority to invite inputs from other stakeholders, such as
mental health professionals and non- governmental organizations working in this field. The
rehabilitation plan/ protocol should be reasonably flexible to adapt to the individual needs. The
protocol/ plan will delineate the duties and responsibilities of all the agencies involved in the
process of rehabilitation.
(ii) Till the comprehensive protocol for rehabilitation is developed by the State Mental Health
Authority as above, the draft comprehensive plan stated in paragraph no. 88 be followed. Following
this plan and as stated therein, an attempt should be made to discharge at least 50 to 70 patients,
who are ready to be so discharged from each mental health establishment to either their family
homes or the rehabilitation centre/ halfway homes, each month. A monthly report from the regional
mental establishments be sent to the rehabilitation centres through the Disabilities Welfare
Department. After necessary data is received for accommodating patients in different rehabilitation
centres, the Disabilities Welfare Department will inform the State Mental Authority preferably
within seven days. After the rehabilitation centre is allocated, the patients Trupti 86 22 March
J-PIL-43-2022.doc should be shifted from the mental health establishments to the respective
centre, preferably within seven days. We place the responsibility of adhering to this requirement on
the In-charge of the concerned mental health establishments to ensure that no patient certified fit to
be discharged and is allotted a rehabilitation centre remains in the mental health establishments for
more time than necessary for procedural formalities.Dr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

(iii) During the rehabilitation process, while transferring the patients to the halfway homes, efforts
should be made to ensure that the patients are distributed evenly as far as possible. For that
purpose, the State Mental Health Authority shall develop norms and protocols for even distribution
within six months from today.
(iv) The State Mental Health Authority shall take steps to register all mental health establishments
except those referred to in Section 43 and maintain and publish (including online) a register of such
establishments within a period of six months from today. The State Authority shall develop quality
and service provision norms for different types of mental health establishments in the State and
upload the same on its website within a period of four months.
 Trupti                                 87             22 March J-PIL-43-2022.doc
(v)      The State Mental Health Authority shall, within one month,
initiate the process for registering clinical psychologists, mental health nurses and psychiatric social
workers in the State, as mental health professionals, and publish the list of such registered mental
health professionals in such a manner as may be specified by regulations by the State Authority and
preferably complete the process of registration within a period of eight months.
(vi) The State Mental Health Authority shall regularly hold its meetings, which shall not be less than
four times in a year, as per the provisions of Section 56 of the Act of 2017. The State Mental Health
Authority will consider inviting the representatives of the State Legal Services Authority, Jail
Authorities and Police Authorities for its statutory meeting concerning their subject so that a
coordinated effort can be achieved to tackle the issues arising under the Act of 2017.
(vii) The State Mental Health Authority shall prepare the Annual Report as prescribed under Rule 16
of the State Mental Health Authority Rules, 2018, read with Form E appended to the State Mental
Health Authority Rules, 2018 by the end of December of every year. We place the responsibility of
adhering to the mandate under Sections 63 and 64 of the Act of 2017 on the Chief Executive Officer
of the State Mental Health Authority.
Trupti 88 22 March J-PIL-43-2022.doc
(viii) The State Mental Health Authority will create its dedicated website within four months. The
website will have a feedback mechanism. The State Mental Health Authority will upload the final
Annual Report under Section 64 of the Act of 2017 on its website in the public domain to enable
other entities to aid and assist the State Mental Health Authority based on the official data, subject
to Sections 23 and 24 of the Act of 2017, rights to confidentiality and restrictions on release of
information regarding mental illness and such other sensitive data.Dr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

(ix). The State Mental Health Authority shall initiate the drive to collect basic data necessary for the
effective implementation of the Act of 2017 from the authorities of the State Government and
non-governmental organizations. These authorities and organizations shall supply necessary data as
required by the State Mental Health Authority. Refusal to do so without justifiable reason will be
considered a breach of the order of this Court. The State Mental Health Authority will issue
necessary instructions to the authorities/ organizations accordingly.
(x) The State Mental Health Authority, as per Section 55 (e) of the Act of 2017, shall develop a
protocol for training all concerned persons, that is, law enforcement officials, mental health
professionals and other health professionals, about the Trupti 89 22 March J-PIL-43-2022.doc
provisions and implementation of the Act within four months from today. The State Government
shall render all necessary assistance to the State Mental Health Authority for developing the
protocol for the training program.
(xi) The State Mental Health Authority will regularly conduct workshops and seminars to sensitize
stakeholders, such as the Police Department, Child Welfare Committees, Non- Governmental
Organizations working in mental health, jail authorities, etc., regarding the Act of 2017.
(xii) The State Mental Health Authority will issue mandatory directions to all Mental Health
Establishments to prominently display posters emphasising on the Rights of Persons with Mental
Illness with the helpline and toll-free numbers.
(xiii) Under Section 18 (3) of the Act of 2017, the State Government is mandated to make sufficient
provision for a range of services required by persons with mental illness, including provisions for
halfway homes. In furtherance of this, at least six additional halfway homes should be created as
early as possible within four months.
(xiv) The State Government Fund should take its commitment under Sections 61 and 62 of the Act
of 2017 seriously and make efforts to maintain adequate funds in the State Mental Health Authority
Fund to ensure that the State Mental Health Trupti 90 22 March J-PIL-43-2022.doc Authority can
function at its fullest capacity and its activities are not hampered by a lack of funds. We grant liberty
to the State Mental Health Authority to file an application if necessary, directions are required in
this regard.
(xv) The State Government, along with the State Mental Health Authority, will prepare a draft plan
of action within four months for the beneficiaries stipulated under Chapter V of the Act of 2017 to be
made aware of their rights, including the contingency of cases where they cannot be made fully
aware of their rights because of their disabilities.
(xvi) In pursuance of the composition of the Authority under Section 46 of the Act of 2017 and
under Section 49 of the Act of 2017, the State Government is under obligation to fill up vacancies in
time. As per Section 49, the State Government shall make nominations for filling vacancies within
two months from the date of occurrence and within three months of the anticipated vacancy.
Considering that a fully functional State Authority was not established for almost four years sinceDr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

the Act of 2017 came into force, the State Government shall in future ensure that the vacancies in
the State Mental Health Authority are filled up in time.
(xvii) The State Government will issue necessary directions to establish a common portal for
unknown patients and all mental health establishments to upload the photos and Trupti 91 22
March J-PIL-43-2022.doc information of unknown patients to accelerate the process of reuniting
with families located anywhere in the country. This portal be made accessible only to mental health
establishments, police officials and concerned government agencies. The process for creating the
portal be initiated in consultation with the State Mental Health Authority within three months.
(xviii)The State will issue necessary instructions to the In charge of every police station (as
applicable) to report to the concerned Mental Health Review Boards on a monthly basis regarding
the progress of discharge of patients.
(xix) The State Government shall initiate the process of filling the sanctioned additional posts of
psychologists and psychiatrists at the jails within three months and ensure that the process of filling
anticipated vacancies of psychologists and psychiatrists attached to jails is initiated four months in
advance.
(xx) The State Government will examine the recommendations in the Advisory issued by the
National Human Rights Commission dated 19 June 2023 for its implementation as feasible. More
particularly, the recommendations regarding minimum standards for mental healthcare in prisons.
These include prompt and proper identification of persons with mental health problems in the
prisons; mandatory physical Trupti 92 22 March J-PIL-43-2022.doc and mental status examination
of prisoners; identification of persons with serious mental illnesses; protocols for dealing with
prisoners with suicidal risks and crisis related to mental illness; implementation of National Mental
Health Program in the prison and providing four trained counsellors for every 500 prisoners.
(xxi) Mental Health Review Boards constituted under Section 73 of the Act of 2017 shall ensure that
the Board assembles as regularly as possible, preferably every month, considering the importance of
the issue and the pendency of the matters before the Boards. The chairpersons of the Board will
ensure that the meetings are held regularly and that pendency in the Board does not delay/hamper
the rehabilitation process.
(xxii) The Maharashtra State Legal Services Authority and State Mental Health Authority will
develop a protocol for cooperation amongst them to deal with the issues highlighted in this PIL and
arising under the Act of 2017 and the NALSA scheme, within four months. For example, the State
Mental Health Authority can furnish the Legal Services Authority with a list of counsellors,
psychiatrists, and psychologists who are required to deal with trauma victims, and paralegal
volunteers attached to the Legal Services Authorities can assist in collecting the data for the State
Mental Health Authority.
Trupti 93 22 March J-PIL-43-2022.doc (xxiii)We place the responsibility for developing the above
protocol through joint meetings on the Member Secretary of the Maharashtra State Legal ServicesDr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

Authority and the Chief Executive Officer of the State Mental Health Authority.
(xxiv)The Maharashtra State Legal Services Authority would consider placing a special emphasis on
creating an awareness of legal aid available to the persons with mental illness to achieve the
objective of Section 27 of the Act of 2017. The Maharashtra State Legal Services Authority will
examine the feasibility of the District Legal Services Authority assisting in discharging the patients
to relatives who are reluctant to take them home and, if feasible, issue guidelines and modalities in
that regard.
(xxv) We direct that all Police Authorities of the State, the Commissioner of Disabilities Welfare, and
other concerned departments and governmental and non-governmental organizations, within the
ambit of their duties and functions, to cooperate with the State Mental Health Authority to perform
its duty under the Act of 2017 and for compliance of these directions. If faced with a lack of
cooperation, we grant liberty to State Mental Health Authority to apply for suitable directions.
(xxvi)All interim directions in consonance with the above directions shall continue as final
directions.
Trupti 94 22 March J-PIL-43-2022.doc
107. We grant the Petitioner, the State Mental Health Authority, and the Maharashtra Legal Service
Authority liberty to apply for any further directions arising from the subject matter as above.
108. Rule made absolute in above terms.
109. The Public Interest Litigation is accordingly disposed of.
110. We place on record our sincere appreciation for the assistance rendered by Mr. J.P. Sen, the
learned Senior Advocate, Amicus Curie and all the advocates for the appearing parties.
111. The judgment began with case X, and we end it on a positive note. During the hearing of the
PIL, X was reunited with her family, as we were informed.
     (M.M. SATHAYE, J.)                       (NITIN JAMDAR, J.)Dr. Harish Shetty vs The State Of Maharashtra Thr The ... on 22 March, 2024

