And For The Relief Of Permanent ... vs Was Appointed By The
Plaintiff As A ... on 30 March, 2022
                           60
                                   Com.O.S.No.4816/2015
 IN THE COURT OF LXXXII ADDL.CITY CIVIL & SESSIONS
           JUDGE, AT BENGALURU (CCH.83)
           THIS THE 30th DAY OF MARCH 2022.
                      PRESENT:
         SRI.DEVARAJA BHAT.M., B.COM, LL.B.,
       LXXXII ADDL.CITY CIVIL & SESSIONS JUDGE,
                     BENGALURU.
                 Com. O.S. No.4816/2015
BETWEEN:
M/s     Pest    Control
(India)          Private
Limited., A Company
incorporated      under
the Indian Companies
Act, 1913 and now
Governed      by     the
Companies Act, 1956,
having its Registered
Office at 36, Yusuf
Building, M.G. Road,
Mumbain - 400 0001,
India, represented by
tis          Authorized
representative      Mrs.
K.S. Harina.
                            60
                                 Com.O.S.No.4816/2015
                                       : PLAINTIFF
(Represented by Sri.
G.B. Sharath Gowda -
Advocate)
                           AND
1. Dr. Swapan Kumar
Ghosh, S/o Mr. Prabhu
Nandan Ghosh, agedAnd For The Relief Of Permanent ... vs Was Appointed By The Plaintiff As A ... on 30 March, 2022

about     49     years,
residing at No. 204, II
Block, Heritage Estate,
Dodaballapur     Road,
Yelhanka, Bengaluru -
560 064.
2. M/s        Multiplex
Group of Companies
Whiteway         Retail
Private Limited, No. 14
(old No. 2/B), OVH
Road,    Basavanagudi,
Bengaluru - 560 004.
                                    : DEFENDANTS
(Defendant         No.1
represented by Sri. K.S.
Sridhar - Advocate and
the    Defendant No.2
                            60
                                    Com.O.S.No.4816/2015
Represented   by   Smt
Maheshwari - Advocate)
Date of Institution of the 04.06.2015
suit
Nature of the suit (suit on
pronote,        suit      for
declaration & Possession, Suit for recovery of money
Suit for injunction etc.)
Date of commencement of
recording of evidence   12.12.2019
Date  of   First  Case      -
Management Hearing
Time taken for disposal 4 days
from    the     date   of
conclusion of arguments
Date on which    judgment 30.03.2022
was pronounced
Total Duration             Year/s   Month/s   Day/s
                            06       09        26
                           (DEVARAJA BHAT.M),And For The Relief Of Permanent ... vs Was Appointed By The Plaintiff As A ... on 30 March, 2022

                  LXXXII Addl.City Civil & Sessions Judge,
                                Bengaluru.
                                  60
                                           Com.O.S.No.4816/2015
                     JUDGMENT
This is a suit filed by the Plaintiff to direct the 1 st Defendant to pay a sum of Rs.3,76,62,101/- as
damages to the Plaintiff, and for the relief of permanent injuction restraining the 1st Defendant from
sharing the confidential information/ data of the Plaintiff with the 2nd Defendant and third parties.
2. The contentions of the Plaintiff in brief are as follows:-
That the Plaintiff is a private limited company, that the Plaintiff has set up its division
under the name and style of 'Bio- Control Research Laboratories' for research and
development work, that the BCRL was established by Sri. Nalakur Sripad Rao, a
visionary from Karkala in the year 1981, at the invitation of Indian Council of
Agricultural Research, that the BCRL is involved in research, commercial production
and extension activities for promotion of environmental-friendly pest control
practices for the benefit of farming community, that BCRL carries on activities such
as research work in labs, experimental field work to test trail products,
manufacturing of bio-pesticide formulations and other related products and
developing methodologies for rearing insects, parasites and predators as well as
development of pheromones and lures based on them, that the efforts made by BCRL
have played a very crucial role in Com.O.S.No.4816/2015 popularizing and
transferring environment-friendly plant protection technology to farmers fields, that
the BCRL is one of the largest producers of organic inputs for management of crop
pests and diseases, that the BCRL has a dedicated field extention unit working in
association with the Departments of Agriculture and Horticulture for the benefit of
farming community in the state, that the BCRL is a recoginzed laboratory by
Department of Scientific and Industrial Research, Government of India, that the
BCRL has won two DSIR National Awards for outstanding contribution in the field of
Agro- Industries category, that in furthereance of its object to reach out to the needs
of the farming community in the State of Karnataka, the Plaintiff through BCRL has
set up its research laboratory at Sriramanahalli, Hesarghatta Hobli, that the 1 st
Defendant was appointed by the Plaintiff as a Technical Officer vide Appointment
Order dated 12.05.1998 and was assigned to work at BCRL, that the 1st Defendant
while reporting to duty with the Plaintiff executed a Secrecy Bond dated 02.06.1998
undertaking to maintain secrecy of the confidental information/ data of the research
work, production process and marketing strategy of the Plaintiff, that the said
Secrecy Bond contemplated that in the event of any violation of the terms of Secrecy
Bond by the 1st Defendant, the Plaintiff was entitled to seek damages from the 1st
Defendant, that the 1st Defendant Com.O.S.No.4816/2015 later executed
Non-Disclosure Agreement dated 15.10.2010 wherein he has undertaken to keep all
data, information regarding research work, production process and marketingAnd For The Relief Of Permanent ... vs Was Appointed By The Plaintiff As A ... on 30 March, 2022

strategy of the Plaintiff confidential, that aforesaid NDA contemplates that any
violation of its terms by the 1 st Defendant would expose him to prosecution both on
civil as well as criminal side, that the 1 st Defendant over a period of time was
promoted as Assistant General Manager (Research) Bio- Pesticides at BCRL, that the
1 st Defendant was in-charge of the research activities being carried out at BCRL and
nearly 50 employees were working under supervision of the 1 st Defendant, that as
the 1st Defendant was occupying a post of management cadre and a position of
confidence, he was privy to Plaintiff's research activities, production process,
techniques of pest control services, business transaction and trade secret, that during
August - September 2014 it was noticed by the Plaintiff that the 1st Defendant in
breach of NDA and his terms of employment had shared confidential and sensitive
data/information of the Plaintiff with external agencies without obtaining prior
permission of his reporting authority, that the Defendant also shared confidential
information data and findings of research work of the Plaintiff with 1 st Defendant's
wife to her personel email id, that the 1 st Defendant also forwarded material
subscribed by the Plaintiff for BCRL Com.O.S.No.4816/2015 scientists, internal
correspondence on corporate policies and further the 1st Defendant had also made
comitment via email to an external agency to meet and share product trial
information for one of their product without contract or commercial agreement and
wihtout bringing it to the knowledge of his reporting authority, that the 1st
Defendant's wife was earlier working in BCRL, that she has resigned from service,
that when the 1st Defendant sent the aforesaid confidential/sensitive
information/data to his wife's emai id, she was working with an NGO by name CABI.
ORG which works on contract basis with several competitors of the Plaintiff, that it
was under the above circumstances the Plaintiff issued a written memo dated
17.09.2014 calling upon the 1st Defendant to handover all the information, data and
data storage devices that were in his possession, that the 1st Defendant gave a reply
to the aforesaid written memo, wherein the 1st Defendant admitted his misconducts
and requested with the Plaintiff not to impose any punishment, that in the above
circumstances the 1 st Defendant submitted his resignation on 18.08.2014 which was
accepted by the Plaintiff would have been adverse to its interest, that while accepting
1st Defendant's resignation, considering the duration of his service put in with
Plaintiff, it took a sympathetic and humanitarian approach towards 1 st Defendant
and offered to pay him 3 months salary as ex-gratia amount, that the 1 st
Com.O.S.No.4816/2015 Defendant was relieved from service, that the 1 st Defendant
surrendered the laptop, mobile and other data storage devices that were in his
possession to Plaintiff,that it is only after the Information Technology Department of
the Plaintiff carried out detailed investigation of the laptop, mobile and other data
storage devices used by the 1st Defendant, the Plaintiff realized the enormity of
misconducts committed by the 1 st Defendant which has caused irreparable loss and
injury to the Plaintiff, that the investigation revealed that while the 1 st Defendant
was sent on official visit to Nasik during January 2014 to review field performance of
Plaintiff's products, that the 1 st Defendant was simultaneously engaged in freelance
project work, that the 1 st Defendant has received a freelance assignment formAnd For The Relief Of Permanent ... vs Was Appointed By The Plaintiff As A ... on 30 March, 2022

CABI.ORG, on which the 1st Defendant has worked and summarized his work into a
document by name "extension activities.. NASIK visit.doc", that the emial exchange
between the 1 st Defendant and representative of CABI.ORG reflected that the 1 st
Defendant engaged in such activities and provided his professional services to the
said organization using the resources of the Plaintiff, that all these were done by the 1
st Defendant without the knowledge or approval of the Plaintiff, which is per se in
violation of 1st Defendant's terms of his employment and NDA, that while the 1st
Defendant was to conduct a workshop on Bio-
Pesticides in Nepal during July 2014, the 1st Defendant did not Com.O.S.No.4816/2015 make a
presentation on the approved topic which was only to explain the Technology of Bio-persticides, that
the exchange of mails between the 1st Defendant and the representatives of companies/competitors
of the Plaintiff reflects that the 1 st Defendant provided documents with details on how to rear grubs
by using Plaintiff's methodology, that the said rearing technique has been developed after 2 years of
research at BCRL and its process has been designed by Plaintiff and it is core to Plaintiff's
established product Grub-X, that the exchange of emails reflects that the 1st Defendant has passed
on this information to Director of a company by name M/s Agricare Nepal Private Limited, with
same commercial interests as that of Plaintiff, that the investigation further revealed that the 1 st
Defendant during June 2014 took aproval from Dr. K.P. Jayanth, Vice President (BCRL) for
dispatching the finished products viz., Myco-Jaal (Beavveria bassiana 1.15%SC) and Grub-X
(Metarhizium anisopliae 10% G.R.) for conducting the aforesaid workshop held at Nepal, that
Myco-Jaal and Grub-X are pest control products, that the said products have been developed by the
Plaintiff after years of research and that they are "star products" of the Plaintiff, that upon approval
of Dr. K.P. Jayanth dispatched finished products of Myco-Jaal and Grub-X , that the 1st Defendant
clandestinely instructed members of the team working under him to sent raw materials viz., 600 gm
each of Com.O.S.No.4816/2015 active spores of Beavveria bassiana and Metarhizium anisopliae
which can be used for producting 6000 liters of Myco-Jaal and 6000 Kgs of Grub-X, that the
investigation carried out further revealed that the 1 st Defendant also shared proprietary
information of certain rearing techniques that were developed by BCRL after years of research, that
further the 1 st Defendant has also video recorded the production process of Myco-Jaal and Grub-X
including Grub rearing process designed by Plaintiff and shared the same with an educational
e-mail domain and other competitors of Plaintiff, that the investigation carried out by the Plaintiff
further disclosed that the 1 st Defendant was in agreement with one Mr. Robin Adhikari to setup
bio-pesticides factory at silgudi and that the 1 st Defendant shared proprietary information of the
Plaintiff with the said person and therey caused huge commercial loss to the Plaintiff, that the 1st
Defendant had an intention of setting up business with competitors of the Plaintiff and acted in a
manner that is determental to the interest of the Plaintiff and thereby causing loss of proprietary
information and also causing commercial harm to the Plaintiff, that BCRL which is research division
of Plaintiff provides entomological research services commercially, that therefore, all products being
accessed for commercial agreement with the Plaintiff, that one of the 1 st Defendant's official
assignments was to participate in demonstration of Com.O.S.No.4816/2015 effective control of pests
by using Bio-Pesticides at a field trial in Nasik during July 2014, that the Pheromone component
was missing in trials, that the 1 st Defendant requested permission from his reporting authority to
include LUREM for purpose of demonstration, that the 1st Defendant's reporting authority accordedAnd For The Relief Of Permanent ... vs Was Appointed By The Plaintiff As A ... on 30 March, 2022

permission to include LUREM for the purpose of demonstration at Naik trials, that the
investigations have revealed that the 1st Defendant vide e-mail comunications with one Dr. David
Teulon, has agreed to access the product efficacy under multiple situations such as lab trials, free
lance studies in the field and then the Nasik Trials, that Dr. David Teulon with whom the 1st
Defendant agreed to engage independently in research activities is Director of Better Border
Security (B3), Plant and Food Research, New Zealand, which is competitor of Plaintiff, which is
against commercial interest of the Plaintiff, that the investigation has further revealed that the 1 st
Defendant has exchanged emails with various individuals who were not connected to the Plaintiff
and with those who are working with Plaintiff's competitor company wherein the 1 st Defendant has
agreed to carry out small scale trials locally i.e., in Bengaluru which was impermissible as that was
not a part of the project, that the 1st Defendant had requested and received detailed instructions and
protocal for small scale testing and then for larger area, the 1st Defendant and other individuals
Com.O.S.No.4816/2015 have been made without marking a copy to his reporting authority, that the
e-mails establish that the trial was not carried out for benefit of BCRL and the mails also further
reflect that the 1st Defendant clearly intended on meeting with Dr. David Teulon and sharing the
findings of trials of field studies, however, due to the changes in climate and due to their effect on
agricultural, the trial at Nasik was cancelled, accordingly the funding from the project partner also
stopped by the end of September, that thereafter, the 1st Defendant clandestinely sought approval
for funding the project from Plaintiff and thereby completed the report which 1 st Defendant
intended to share with Dr. David Teulon, the request which caused a suspicious in the mind of the
Plaintiff that led to internal assessment and it was found that the 1 st Defendant was indeed
violating the terms of his appointment and NDA, that the 1 st Defendant was occypying a very
important and responsible post i.e., Assistant General Manager (Research) Bio-Pesticides, that the
1st Defendant was in-charge of the research activities being carried out at BCRL, that nearly 50
employees were working under supervision of the 1st Defendant, that on account of misconducts of
the 1st Defendant, the research activities at BCRL have been severely hampered and it has caused
loss of proprietary information, caused detriment to commercial activities and also has caused
monetary loss to the Plaintiff, Com.O.S.No.4816/2015 that the Plaintiff has invested huge amount of
money on research work while developing the products Myco-Jaal and Grub-X, that apart the
Plaintiff has also incurred expenses while getting the aforesaid products registered with appropriate
authority, that the 1st Defendant being the Department head for Research and Prodcution of the
aforesaid products, the Plaintiff has paid the 1st Defendant in terms of salary and other expenses,
that the 1st Defendant joined the services with the Plaintiff as Technical officer in the year 1998 and
over period of time he has been promoted as Assistant General Manager which is one of the High
Offices of the Plaintiff Company, that the 1st Defendant during his tenure with the Plaintiff was
encouraged to learn and research new things and the 1 st Defendant was given lot of exposure by
making him attend training programs, conferences and seminars across the country and also abroad
in countries such as Switzerland, Netherlands etc., thereby the Plaintiff has invested huge amount of
money on the 1st Defendant, that apart the Plaintiff has suffered loss of commercial opportunity as
well as its credibility has taken huge dent on account of the misconduct of the 1st Defendant, that
the Plaintiff has sufered damages to the tune of Rs. 3,79,92,733/- which shall be payable by the 1 st
Defendent to the Plaintiff, that upon revelation of the grave misconducts of the 1st Defendant, the
Plaintiff was left with no Com.O.S.No.4816/2015 alternative but to withdraw the offer made by it to
the 1 st Defendant i.e., to pay 3 months salary in lieu of notice period, that the 1st Defendant is notAnd For The Relief Of Permanent ... vs Was Appointed By The Plaintiff As A ... on 30 March, 2022

entitled for 3 months salary that was offered by the Plaintiff as a goodwill gesture at the time of
accepting 1st Defendant's resignation, that the Plaintiff is liable to pay a sum of Rs. 3,30,632/-, that
the 1 st Defendant is liable to pay damage in a sum of Rs. 3,79,92,733/- to the Plaintiff, the Plaintiff
has withheld the amount of Rs. 3,30,632/- which is payable to 1st Defendant, the amount of Rs,
3,30,632/- payable to the 1st Defendant is adjusted towards the damages payable by the 1st
Defendant to the Plaintiff, that after adjusting the said sum towards damages, the 1st Defendant is
due a sum of Rs. 3,76,62,101/- to the Plaintiff towards damages, that the 1 st Defendant is currently
working with the 2 nd Defendant, that the Plaintiff reliably learnt that the 1st Defendant has shared
Plaintiff's confidential information/data regarding the research work, manufacturing process of
Plaintiff's star products Grub-X and Myco-Jaal with the 2nd Defendant and that they are making
hectic efforts to manufacture products similar to that of Grub-X and Myco-Jaal, that the Plaintiff
has issued notices to the 1 st Defendant seeking show cause as to why appropriate action should not
be initiated against him, that the 1 st Defendant time and again issued frivolous replies adopting
dilatory tactics, that the 1st Defendant on 11.04.2015 issued a legal notice to the
Com.O.S.No.4816/2015 Plaintiff laying a frivolous claim, that therefore on 02.05.2015 the Plaintiff
issued a reply notice narrating the aforesaid facts and demanding the 1st Defendant to pay a sum of
Rs. 3,76,62,101/- as damages to the Plaintiff and also to refrain from sharing Plaintiff's confidential
information/ data with the 2nd Defendant and to refrain from commercially intorducing any pest
control prooducts similar to that of Myco-Jaal and Grub-x, that the said notice is served on the 1 st
Defendant on 05.05.2015, he has issued a reply dated 19.05.2015 seeking 10 more days to give a
reply, but till date the 1 st Defendant has not given any reply to the said notice, that the 1 st
Defendant though has been served with notice dated 02.05.2015 has neither come forward to pay
the damages as demanded thereunder nor has he stopped sharing the confidential information and
data of the Plaintiff with the 2nd Defendant, that the Plaintiff has learnt that the Defendants are
working overtime to commerically launch pest control products similar to that of Myco-Jaal and
Grub-x, that the Plaintiff has developed the aforesaid products Myco-Jall and Grub-x after years of
research and the Plaintiff has invested huge amount of money for developing the said products, that
Myco-Jaal and Grub-X are the star products of the Plaintiff in the commercial field, that if the
Defendants succeeded in introducing similar products using the confidential information and data
of the Plaintiff, then the Plaintiff would be Com.O.S.No.4816/2015 put to irreparable loss and injury
which cannot be compensated in terms of money and hence, the Plaintiff has filed the present suit
for the above-mentioned reliefs.
3. The Defendant No.1 has filed detailed written statement on 18.09.2015 and his contentions in
brief are as follows:-
While denying the various allegations against the 1 st Defendant, he has contended
that the 1 st Defendant was never in any agreement with Mr. Robin Adhikari to set up
Bio- Pesticides in Siligudi, that mere transfer of knowledge will not cause commercial
harm if the products are not manufactured and marketed sold, that Dr. K.P. Jayanth
instructed the 1 st Defendant to include LUREM for purposes of field
demonstration/trial, that there were exchange of emails between him and Dr. David
Teulon, who is a Director of Better Border Security (B3), Plant and Food Research,
New Zealand, the 1st Defendant made suggestion to Dr. K.P. Jayanth as there was noAnd For The Relief Of Permanent ... vs Was Appointed By The Plaintiff As A ... on 30 March, 2022

rainfall in NASIK, Bengaluru could be one of the places for conducting the trial on a
smaller scale instead of completely abandoning the project to be held in NASIK, that
the 1 st Defendant never requested and receive details protocal for small scale testing
and also for larger areas, that whenever and wherever required the 1st Defendant
would report to his Com.O.S.No.4816/2015 reporting authority and take necessary
instructions and permission whenever required, that the 1st Defendant was meeting
and sharing information with Dr. David Teulon under the instructions from Dr. K.P.
Jayanth as any discussion with Dr. David Teulon would be beneficial to the Plaintiff
company as the said Dr. David Teulon had vast knowledge in the field of pesticides
and control of the diseases, that the trial as NASIK was canceled due to the climatic
changes and their effect on agriculture, that the funding for the project would be
stopped by the end of September-2014, that the 1st Defendant never indulged in any
activities detrimental to the interest of the Plaintiff Company, there was no
negligence on the part of 1 st Defendant and the trials could not take place due to
inadequate rainfall in NASIK which was beyond the control of the 1 st Defendant,
that whenever the Company server was not working, the 1st Defendant and other
staff members were using their personal email ID to do communication and it was
approved by Dr. K.P. Jayanth who was heading the business of the Company, that the
Plaintiff forced the 1 st Defendant to submit his Resignation and Resign from the
Company, that the Plaintiff cannot unilaterally withdraw the offer of 3 months salary
and prayed to dismiss the suit. The 1 st Defendant has also filed a Counter-Claim for
Rs. 8,90,967/- against the Plaintiff.
Com.O.S.No.4816/2015
4. The 2nd Defendant has filed a separate detailed written statement on 07.04.2016 and has
contended that the Defendant No.2 has been marketing two of its products namely BABA and
METARHIZIUM from past many years, that it has obtained certificate of Registration under Section
9 (3 B) of the Insecticides Act, 1968 in respect of said products, that the Plaintiff by making
appointment of the Defendant No.1 with the Defendant No.2 as an issue and is attempting to defeat
legitimate rights of the Defendant No.2, that there are more than 50 companies marketing products
similar to that of the Myco-Jaal and Grub-X in the commercial field and hence he prayed to dismiss
the suit.
5. The Plaintiff has filed his Replication/written statement to the Counter-Claim of the 1st
Defendant on 26.11.2015 and prayed to dismiss the said Counter-Claim.
6. On the above pleadings of the parties, the following issues are framed by then
Predecessor-in-Office :-
1. Whether Plaintiff proves that Defendant No.1 shared its Propriatory information
and confidential information to others and infringment of its Intelecutual Property
Rights by violating the terms and conditions Com.O.S.No.4816/2015 of
Non-Disclosure Agreement dated 15.10.2010 and also Secrecy Bond dated 12.05.1998And For The Relief Of Permanent ... vs Was Appointed By The Plaintiff As A ... on 30 March, 2022

as contended ?
2. Whether the Plaintiff proves that it suffered loss due to acts of Defendant No.1 in
sharing its confidential and Propritory information to others and due to infringment
of its Intellectual Property Rights as contended ?
3. Whether the Defendant No.1 proves that suit is bad for non-joinder of necessary
party ?
4. Whether court fee paid by the Plaintiff is sufficient ?
5. Whether the Plaintiff is entitled to recover suit claim from the Defendant No.1 ?
6. Whether the Plaintiff is entitled for the relief of Permanent Injunction against
Defendants as claimed ?
7. Whether the Defendant No.1 is entitled to recover the amount from the Plaintiff as
claimed in the counter claim ?
8. What Decree or Order ?
7. During the course of Trial, PW-1 is examined and Ex.P.1 to Ex.P.60 are marked. On behalf of the
Defendants DW-1 and Com.O.S.No.4816/2015 DW-2 are examined and Ex.D.1 to Ex.D.48 are
marked.
8. I have heard the arguments of the learned Advocate Sri.Sharath Gowda G.B., on behalf of the
Plaintiff. I have heard the arguments of the learned Advocate for the Defendant No.1.
Sri.K.S.Sridhar and Smt.Leela Pai. I have heard the arguments of the Advocate for the Defendant
No.2 Smt.Maheshwari. The Advocate for the Defendant No.1 has filed written arguments.
9. My findings on the above Issues are as under:
Issue No.1 :- In the Negative.
Issue No.2:- In the Negative.
Issue No.3 :- In the Negative.
Issue No.4:- In the Negative.
Issue No.5 :- In the Negative.
Issue No.6:- In the Negative..And For The Relief Of Permanent ... vs Was Appointed By The Plaintiff As A ... on 30 March, 2022

Issue No.7:- In the Affirmative Issue No.8:- As per the final Order for the following
reasons.
Com.O.S.No.4816/2015 REASONS
10. Issue No.1:- The Plaintiff has alleged that the Defendant No.1 has shared its proprietary
information and confidential information to others by violating the terms and conditions of Ex.P.3/
Secrecy Bond dated 02.06.1998 and Ex.P.4/Non-Disclosure Agreement dated 15.10.2010.
11. One of the said allegations of the Plaintiff against the 1 st Defendant is that the investigation
revealed that while the 1 st Defendant was sent on official visit to Nasik during January 2014 to
review field performance of Plaintiff's products, he was simultaneously engaged in freelance project
work from CABI.ORG., and provided his professional services to the said organization using the
resources of the Plaintiff. However, the evidence reveals that the said Nasik Project was not
conducted due to scarcity of rain in the said year.
12. The P.W.1 has deposed that the Exs.P.11 to 14 and 17 are the records to show that the Defendant
No.1 was engaged in freelance project work of CABI. She has admitted that the E- mail at Ex.P. 10
was sent by Defendant No.1 from his official e- mail ID to his personal e-mail ID regarding the
extension Com.O.S.No.4816/2015 activities of Nasik visit. She has further deposed that it is not
appearing in Ex.P.10 that Nasik visit was for freelance work of CABI. Further, the PW.1 has also
deposed during her cross- examination that the Plaintiff has not produced records to show that the
Defendant No.1 had received amount for sharing the confidential details of the Plaintiff with CABI.
When the Plaintiff has not received any monitory benifit from the alleged sharing of confidential
details of the Plaintiff, it cannot be considered that he has shared such confidential details of the
Plaintiff with a malafide intention.
13. The PW.1 has further deposed that wife of Defendant No.1 also joined service of Plaintiff
Company in the year 2001 and she was also working in research and development Department of
the Plaintiff company, that she has also completed Ph.D, that she resigned the service of the Plaintiff
Company in or about the year 2013. This is an admitted fact by the 1st Defendant. It is the allegation
that the Defendant No.1 shared confidential information, data and findings of research work of the
Plaintiff Company with his wife to her personal e- mail ID, while she was working with an NGO,
CABI.ORG, which works on contract basis with several competitiors of the Plaintiff Company.
Com.O.S.No.4816/2015
14. The PW.1 has deposed during her cross-examination, during the service of Plaintiff company,
wife of Defendant No.1 was working for the Sumona product, that at the time of her resignation to
the Plaintiff company, she was working in the Onion IPM Project of the Plaintiff company, that this
Onion IPM Project was funded by the USAID, which is a big orgnaisation carrying out the objectives
of UNO, as admitted by the PW.1.And For The Relief Of Permanent ... vs Was Appointed By The Plaintiff As A ... on 30 March, 2022

15. The learned Advocate for the 1 st Defendant has argued about the background of USAID. He has
argued that the United States Agency for International Development (USAID) is an independent
agency carrying out the objectives of UNO and that it is an agency of the United States Federal
Government that is primarily responsible for administering civilan, foreign aid and development
assistance.
16. According to the Plaintiff, the Ex.P.10 to Ex.P.17 are the said e-mails. In order to better
appreciation of the said contentions, I arranged Ex.P.10 to Ex.P.15 in the choronological order. The
Ex.P12/E-mail dated 16.12.2013 which was forwarded mail by the wife of Defendant No.1 to the
Defendant No.1. ExP.15 is the E-mail dated 16.12.2013 sent by wife of the 1st Defendant to the 1st
Defendant. Ex.P.11 is the E-mail dated 04.01.2014 sent by the wife of the 1st Defendant to the 1st
Com.O.S.No.4816/2015 Defendant. Ex.P.13 is the e-mail dated 04.01.2014 sent by the wife of the 1st
Defendant to the 1st Defendant. Ex.P.14, 16 and 17 are the e-mails dated 04.01.2014 sent by the wife
of the 1 st Defendant to the 1st Defendant. All the said emails were sent by the wife of the 1st
Defendant to the 1st Defendant. From the said e-mails it cannot be said that the 1 st Defendant
shared the confidential information, data in findings of the research work of the Plaintiff with his
wife to her personal email ID as deposed by the PW.1 at Para No. 8 of the her Affidavit filed in-lieu
of oral Examination-in-Chief. Further, the Defendant No.1/DW.1 has deposed that in Ex.P.10 to
Ex.P.17 his wife has been asking questions. If we read the contents of Ex.P.10 to Ex.P.17 the said
evidence of DW.1 cannot be brushed aside. Further, Ex.P.10 to Ex.P.15 are not detrimental to the
interest of the Plaintiff. Hence, the said contentions of the Plaintiff is not proved at all.
17. The second allegation against the 1 st Defendant is that while the 1st Defendant was to conduct
for workshop on Bio- Pesticides in Nepal during July 2014, the 1 st Defendant did not make a
presentation on the approved topic because only to explain the Technology of Bio-Pesticides, that
the exchange of mails between the 1st Defendant and the representatives of companies/competitors
of the Plaintiff Company reflects that the 1st Defendant provided documents with details on how to
Com.O.S.No.4816/2015 rear grubs by using Plaintiff Companies methodology, that the said rearing
technique has been developed after years of research at BCRL and its process has been designed by
the Plaintiff Company and it is core to the Plaintiff Company's established product Grub-x, that the
exchange of emails reflects the 1st Defendant has passed information to Director of a Company by
name M/s Agricare Nepal Private Limited with same commercial interests as that of Plaintiff
Company, as deposed by the PW.1 at Para No. 12 of her Affidavit filed in-lieu of oral
Examination-in-Chief.
18. But during her cross-examination, she has deposed that in the year 2013, the Plaintiff was
conducting research at Nasik relating to the onion crop and by seeing this research work of the
Plaintiff, USAID requested the Plaintiff to conduct 3 days international work shop in India involving
more than 12 Countries.
19. She has further deposed that USAID is a big organisation carrying out the objectives of UNO,
that some of its objectives are quality of air, agriculture, pesticides, manure, climatic change etc, that
IPM-IL is a smaller organisation of USAID.And For The Relief Of Permanent ... vs Was Appointed By The Plaintiff As A ... on 30 March, 2022

Com.O.S.No.4816/2015
20. The learned Advocate for the Defendant No.1 has argued that Intigrated Pest Management -
Innovative Lab is called as IPM-IL, which is an USAID assisted laboratory who works for intigrated
pest management. According to the learned Advocate for the 1st Defendant based on the expertice in
the field of Intigrated Pest Management and Biological Control of crop pests, the USAID offered
IPM project to the Plaintiff to develop a cost effective IPM module for the onion cultivation of Nasik,
during 2012.
21. The PW.1 has further deposed that Dr.Muniyappan, Dr.Ed- Rozztee and Dr.Nina Jenkins are the
scientists of IPM-IL, that the Plaintiff was able to get many of the assignments from USAID through
Dr.Muniyappan who is friend of Dr.K.P.Jayanth.
22. She has further deposed that the said workshop was part of the IMP-IL programme, that the
Plaintiff worked for some time to conduct for said 3 days international work shop. When a specific
question put to her during her cross-examination, that Dr.Nina Jenkins was supposed to take
theoretical classes and Defendant No.1 was supposed to take practical classes in the said work shop,
she pleaded her ignorance about the same.
Com.O.S.No.4816/2015
23. She has further deposed that the said work shop could not be conducted in India and it was
shifted to Nepal in the year 2014 as per Ex.P.60, that the Plaintiff made all preparations and
correspondences with concerned scientists to conduct said work shop at Bengaluru, that since the
Plaintiff could not take approval of the Government of India to conduct said work shop at
Bengaluru, the said work shop was shifted to Nepal.
24. The allegation against the 1 st Defendant is that after taking permission for dispatching finished
products of Myco-jaal and Grub-X for conducting the said workshop in Nepal, he clandestinely
instructed the members of the team under him to send raw-materials of 600 grams of active spores
of Metarhizium and Beauveria.
25. The PW.1 has deposed during her cross-examination that in Ex.P.60, IDE Nepal requested the
Plaintiff to furnish fungal culture product of Metarhizium and Beauveria, that Ex.P.29/e- mail dated
17.06.2014 was sent by the Defendant No.1 with the head of Plaintiff company to furnish samples to
the Nepal Company. She has further deposed that Mr.Raman was working as a Marketing Head of
the Plaintiff company and he dispatched materials to the Nepal Company as shown in the Ex.P.29.
She Com.O.S.No.4816/2015 has admitted that the Plaintiff has separate purchase department and
also separate marketing department, that the Production head of the Plaintiff company was
controller of store room where products were kept. According to her, the Defendant No.1 was taking
care of production and research of Bio-pesticides. But, she has not produced any records to show
that Defendant No.1 was taking care of production branch of the Plaintiff company.And For The Relief Of Permanent ... vs Was Appointed By The Plaintiff As A ... on 30 March, 2022

26. She has admitted that bottom portion of Ex.P.31 was sent by the Defendant No.1 to
Dr.K.P.Jayanth on 17.06.2014 at 11.04 A.M.
27. The PW.1 has further deposed that Dr.K.P.Jayanth permitted the Defendant No.1 to send
materials to the Nepal work shop, as shown in Ex.P.30, that after getting such permission, the
Defendant No.1 had sent mail as per Ex.P.31 to Smt.Rekha, Smt.Rashmi and Mr.Surendra specifying
the materials and its quantity to be sent to Nepal work shop, that Mr.Surendra whose name shown
in Ex.P.30 was working as Co- ordinator, Smt.Rekha and Smt.Rashmi shown in Ex.P.30 were
working as Technical Officers of the Plaintiff.
Com.O.S.No.4816/2015
28. The PW.1 has further deposed that the practice of the Plaintiff company to send the finished
products out was that after receipt of indent for supply of the finished products, production
department used to provide details of the indent to the dispatch department who used to dispatch
the finished products from the company. According to PW.1, the production and research branches
of the Plaintiff were together at that time.
29. She has further deposed that the Defendant No.1 was head of both production and research
branches at that time and he worked under the guidance of Dr.K.P.Jayanth, that at that time
Dr.K.P.Jayanth was Vice President of the Plaintiff company. However, no records are produced in
this case to show that Defendant No.1 was appointed as head and to look after both the branches i.e.,
production and research branches of the Plaintiff company at that time. She has further deposed
that the dispatch document of the Plaintiff relating to the dispatch of materials, is available with the
Plaintiff and it is not produced in this case. Therefore, the Plaintiff has failed to prove the
contentions that by taking permission to dispatch finished products, the 1st Defendant has sent raw
materials, as alleged by the Plaintiff.
Com.O.S.No.4816/2015
30. The another allegation is that the 1 st Defendant was in agreement with one Mr. Robin Adhikari
to setup bio-pesticides factory at silgudi and that the 1 st Defendant shared proprietary information
of the Plaintiff with the said person and therey caused huge commercial loss to the Plaintiff.
According to the argument of the learned Advocate for the Plaintiff the 1 st Defendant has shared
the confidential and propiretory information to the external agencies without permission of the
reporting authority. Only document produced about the said allegation is Ex.P.33/ email dated
24.08.2014, which was sent by said Mr. Robin Adhikari to the 1 st Defendant. The 1st
Defendant/DW.1 has deposed that he has not replied to Ex.P.33. From the said Ex.P.33, the Plaintiff
has not proved that the 1 st Defendant has shared the confidential and propiretory information of
the Plaintiff Company to any external agencies.
31. The learned Advocate for the 1st Defendant has argued that the said Mr. Robin Adhikari is not a
totally unconnected person to the Plaintiff Company, to treat him as an external agency. Elaborating
the said arguments, he has argued that the above-mentioned workshop at Nepal was held by M/sAnd For The Relief Of Permanent ... vs Was Appointed By The Plaintiff As A ... on 30 March, 2022

Nepal Agricare Private Limited as per the decision of USAID and the said Mr. Robin Adhikari was
the Director of M/s Nepal Agricare Private Limited. He has further argued that rearing grub of
Com.O.S.No.4816/2015 insect was a part of his traning programme and the same was clearly
mentioned in the brochure of said workshop, which was annexed to Ex.D.20, which was known by
BCRL as well as Dr. K.P. Jayanth. When such being the case, said Mr. Robin Adhikari cannot be
treated as an exclusive external agency to the Plaintiff Company.
32. As per the contentions of the Plaintiff and as per the evidence of PW.1, BCRL is a research
division of Plaintiff Company provides entomological research services commercially, that all
products being accessed for commercial viability and field efficacy would need to enter into a
commercial agreement with the Plaintiff Company, that one of the 1st Defendant's official
assignments was to participate in demonstration of effective control of pests by using bio- pesticides
at a field trial in Nasik during July 2014, that as Pheromone component was missing in trials, the 1
st Defendant requested permission from his reporting authority to include LUREM for the purpose
of demonstration at Nasik trials, that the investigation has revealed that the 1 st Defendant through
email communications with Dr. David Teulon, has agreed to assess the product efficacy under
multiple situations such as lab trials, freelance studies in the filed and the Nasik trial. According to
Com.O.S.No.4816/2015 the arguments of the learned Advocate for the Plaintiff the said Dr. David
Teulon is also an external agency.
33. Now, I propose to consider whether the said Dr. David Teulon is an extenral agency and whether
the 1 st Defendant has sent any confidential information to him. The DW.1 has admitted that in
Ex.P.39/Email dated 12.05.2014 and Ex.P.40/Emails dated 15.02.2014 to 18.06.2014, he had agreed
with Dr. David Teulon to assess the Plaintiff products efficacy under different situation. The PW.1
has deposed that LUREM is one of the components of the Nasik Project. Ex.P.39 is the record to
show that the Defendant No.1 was involved in freelancing work with Dr.David Tuelon relating to
LUREM. The DW.1 has deposed that the product LUREM does not belong to Plaintiff. He has also
admitted that Ex.P.39 and Ex.P.40 were not marked to Dr.K.P.Jayanth. The PW.1 has further
admitted that the LEUREM Sample shown in Ex.P.39 was received in the official address of the
Plaintiff through courier parcel.
34. The PW.1 has deposed that Dr.David Teulon was the Director of a Company by name Better
Border Security (B3), Plant and Food Research, New Zealand. According to the Plaintiff the said
Company is a direct competitor of the Plaintiff Company. The said Company had developed a
Pheromone Com.O.S.No.4816/2015 called LEUREM used for the Management of onion. The said
Company was also working under fund granted by USAID/IPM - IL expressed his interest to assess
the efficacy of LEUREM in the onion project of Nasik. As could be seen from the Ex.P.35/Email
dated 14.05.2014, the said aspect was discussed in detail with Dr. K.P. Jayanth and asked his
opinion. The said Dr. K.P. Jayanth had given clear instruction to Defendant No.1 that the Plaintiff
will validate LEUREM at Nasik trial, under the instruction of Mr. Ed.Rajotte. When such being the
case the said fact is within the knowledge of the reporting authority i.e., Dr. K.P. Jayanth and the
Defendant No.1 has acted as per his instruction only. Therefore, the Plaintiff has failed to prove that
the Defendant No.1 had sent confidential and proprietory information to the said Dr. David Teulon,
who is an external agency.And For The Relief Of Permanent ... vs Was Appointed By The Plaintiff As A ... on 30 March, 2022

35. The next contentions is about the information sent to Mr. Sulav Paudel, Dr. Nina Jentkins and
Mr. Robin Adhikari. The PW.1 has deposed that Mr.Sulav Paudel was one of the organisors of the 3
days work shop in Nepal, that he was a IPM-IL programme co-ordinator. The learned Advocate for
the 1 st Defendant has argued that the said Mr.Sulav Paudel worked under Dr.Nina Jentkins. The
Advocate for the 1st Defendant has drawn my attention to Ex.D.20/ Reply Notice issued by the 1st
Defendant dated 05.12.2014, wherein he has annexed brochure in respect Com.O.S.No.4816/2015 of
the said workshop in Nepal. In the said brochure, it is clearly mentioned that the said Sri. Sulav
Paudel was the coordinator of the said workshop. It is to be noted that Ex.D.20 was confronted to
PW.1 during her cross-examination and since she admitted, the same was earlier marked as Ex.D.1
and later corrected as Ex.D.20.
36. The learned Advocate for the 1st Defendant has argued that since Dr. Sulav Paudel was the
coordinator, had to rear white grubs, and only as per his request the 1 st Defendant provided with
the information by email and automatically it was sent to Mr. Robin Adhikari, who was the Director
of M/s Agricare Nepal, host of the said workshop.
37. According to the learned Advocate for the 1 st Defendant, Dr. Nina Jentkins was a Co-resource
person along with the Defendant No.1 in Nepal workshop, and that the information at Ex.P.23 to
Ex.P.27 was shared only in the course of the said workshop.
38. The learned Advocate for the 1 st Defendant has drawn my attention to the evidence of PW.1
during her cross-examination. The relevant portion of the said cross-examination of PW.1 is as
follows:-
Com.O.S.No.4816/2015 "It is true that Defendant No.1 had sent videography of the
laboratories to the Dr. Nina Jentkins for approval and it was sent through internet
server of the Plaintiff company. It is true that it was sent through official email ID of
Defendant No.1.
It is true that there were personal discussions between Dr.K.P.Jayanth and
Defendant No.1 relating to the conducting of 3 days work shop in Bengaluru.
Investigation stated in para No.14 of my chief- examination affidavit, was done by Dr.
K.P.Jayanth. I do not know who were the people present at the time of said
investigation. Witness volunteers the said investigation was done by checking the
laptop of Defendant No.1, email correspondence etc. Defendant No.1 was not present
at the time of investigation."
39. It is to be noted that during the cross-examination of PW.1 it is suggested to her that Dr.
K.P.Jayanth instructed the Defendant No.1 to prepare videographs and photographs of the
laboratory of the Plaintiff company to be shown to the delegates proposed to participate 3 days work
shop in Bengaluru and this instruction was made to cut short the time required for the delegates to
see the laboratories and to prevent the contamination of the laboratory at BCRL Bengaluru, that as
per the instruction of the Dr.K.P.Jayanth, Defendant No.1 had to prepare videos of the laboratoriesAnd For The Relief Of Permanent ... vs Was Appointed By The Plaintiff As A ... on 30 March, 2022

to show it to Dr.K.P.Jayanth.
Com.O.S.No.4816/2015 Though the PW.1 has denied the said suggestions, she has admitted that
there were personal discussion between Dr. K.P. Jayanth and Defendant No.1 relating to the
conducting of 3 days workshop in Bengaluru. It is to be noted that it is the specific contention of the
1 st Defendant that he had taken permission from Dr. K.P. Jayanth and he had communicated about
all the disputed email transactions relied on by the Plaintiff, to Dr. K.P. Jayanth and he took
permission from Dr. K.P. Jayanth for all the said transactions. It is to be noted that not only before
this court in the written statement, but also in the various Legal Notices exchanged between the
parties, before institution of this suit, the 1 st Defendant had taken similar contentions to the effect
that he had taken permission of Dr. K.P. Jayanth or that he had informed the said facts to Dr. K.P.
Jayanth. The Plaintiff is well aware about the said contentions of the 1st Defendant. In spite of the
same, he has not examined Dr. K.P. Jayanth in this case. The learned Advocate for the Plaintiff has
vehemently argued that since Dr. K.P. Jayanth is now retired from the Plaintiff Company, he could
not examine him. I cannot understand the said submission of the Advocate for the Plaintiff. Even if
the said Dr. K.P. Jayanth is now retired, there was no impediment to examine him as witness of the
Plaintiff. If he refused to come before this court, the Plaintiff could have taken steps to issue witness
summons to him. Without making such Com.O.S.No.4816/2015 efforts, mere arguments to that
effect cannot be accepted at all. It is to be noted that even the PW.1 has not deposed that since Dr.
K.P. Jayanth is now retired, the Plaintiff is not in a position to examine him. Further, the Defendant
has filed a detailed written statement in this suit by taking several contentions. The PW.1 was aware
of said contentions. The Plaintiff has also filed his replication/written statement to the counter
claim of the 1st Defendant. In spite of that the Affidavit filed in-lieu of oral Examination-in-Chief of
PW.1 is nothing but replication of the Plaint averments only. She has not deposed anything about
the counter claim of the 1 st Defendant. She has also prayed to decree the suit only. She has not
prayed for dismissal of the counter claim of the 1 st Defendant, in her affidavit. As per Order XIX
Rule 6 (b) of the Civil Procedure Code as amended under Section 16 of the Commercial Courts Act, if
the affidavit is mere reproduction of the pleadings, the court cannot consider the same. Further, if
the party wants to counter the allegations of the adverse party, then he has to specifically deny the
said allegations in the affidavit and in the absence of such specific denial, the party has deemed to be
admitted the contentions of the adverse party as held in A.I.R. - 2009 - KAR - 109 (DB) (S. Prasanna
Kumar vs. R. Saraswathi). In view of the ratio of the said decision, and in the absence of any
evidence about reasons for non-examination of Dr. K.P. Jayanth, Com.O.S.No.4816/2015 I am of
the opinion that the contentions of the 1 st Defendant that he has obtained permission of Dr. K.P.
Jayanth, about all the aspects alleged against him including that of the alleged videography, are
deemed to have been admitted by the Plaintiff. Further, the Plaintiff has not proved that the above-
mentioned Mr. Sulav Paudel, Dr. Nina Jentkins, and Mr. Robin Adhikari are totally strangers to the
Plaintiff Company and they are external agencies, to whom the 1 st Defendant has passed the
confidential and proprietary information of the Plaintiff Company.
40. The PW.1 has admitted during her cross-examination that Mico-Jaal and Grub-x are trade
names, that similar to these products are available in the market and that the Plaintiff has not
obtained any patents to the said products. Since the Plaintiff has not obtained any Patent in respect
of any of its products, the Plaintiff has also failed to prove any infringement of Intellectual PropertyAnd For The Relief Of Permanent ... vs Was Appointed By The Plaintiff As A ... on 30 March, 2022

Rights by the 1 st Defendant by violating the terms of Ex.P.3 and Ex.P.4.
41. In view of the said discussions and observations, I am of the opinion that the Plaintiff has failed
to prove that the Defendant No.1 shared its proprietary information and confidential information by
violating the terms and conditions of Com.O.S.No.4816/2015 Ex.P.3 and Ex.P4, and that he has
infringed the Intellectual Property Rights of the Plaintiff Company by violating the terms of Ex.P.3
and Ex.P.4. Hence, I answer this Issue in the Negative.
42. Issue No. 2:- In view of my discussions and observations on Issue No.1 and findings on Issue
No.1 as Negative, for the same reasons, I am of the opinion that the Plaintiff has not suffered any
loss as alleged by him since the Plaintiff has failed to prove that the Defendant No.1 has shared any
confidential and proprietary information to external agencies. Hence, I answer this Issue in the
Negative.
43. Issue No. 3:- The learned Advocate for the 1 st Defendant has argued that BCRL is a necessary
party to this suit and hence the suit is bad for non-joinder of BCRL. However, the learned Advocate
for the Plaintiff has convinced me that the BCRL is one of the wings of the Plaintiff Company and
hence the same is not a necessary party. Hence, I answer this Issue in the Negative.
44. Issue No. 4:- Though the 1st Defendant has contended that the court fee paid is insufficient, he
has not specifically pleaded how the said court fee paid is insufficient under the
Com.O.S.No.4816/2015 provisions of Karnataka Court Fee and Suits Valuation Act. Hence, there is
no merit in the contentions of the 1 st Defendant to that effect. Therefore, I answer this Issue in the
Negative.
45. Issue No. 5:- In view of my discussions and observations on Issue No.1 and findings on Issue
No.1 and 2 as Negative, for the same reasons I am of the opinion that the Plaintiff is not entitled to
recover the suit claim from the 1st Defendant. Hence, I answer this Issue in the Negative.
46. Issue No. 6:- The learned Advocate for the 2 nd Defendant has argued that the Plaintiff has
failed to show that it has exclusive right over the said products, and the Plaintiff is not entitled for an
order of injunction for the similar products which are already available in the market since many
years.
47. The learned Advocate for the Plaintiff has drawn my attention to the evidence of DW.2 and
during his cross- examination, he has deposed that because of DW-1 served for 16 years on various
capacity in the Plaintiff company, he gained vast knowledge, because of which Defendant No.2
employed him. He has further argued that after joining of Defendant No.1 to Defendant No.2
Company, they manufactured a product by Com.O.S.No.4816/2015 name Strike Plus, and that the
ingredients of Strike Plus is identical with the product Lastraw belonging to the Plaintiff. It is to be
noted that the DW.2 has deposed that one of the ingredients may be similar to that of the said
product. He has not admitted that the components of Strike Plus is similar to that of Lastraw. It is
the contentions of the Plaintiff that the 1 st Defendant has shared all the information pertaining to
Lastraw to the Defendant No.2 and based on which, the Defendant No.2 manufactured the productAnd For The Relief Of Permanent ... vs Was Appointed By The Plaintiff As A ... on 30 March, 2022

Strike Plus. The DW.2 has admitted that the said Strike Plus was launched in 2nd Defendant
company much after joining of 1 st Defendant, and that the 1st Defendant was the head of the team
of the researchers who came up with the said product Strike Plus. By relying on the said evidence of
DW.2, the learned Advocate for the Plaintiff has argued that the DW.2 has in fact admitted the said
contentions and hence the Plaintiff has proved the same. However, the DW.2 has specifically stated
that one of the ingredients may be similar in both products. The learned Advocate for the 2 nd
Defendant has argued that to the effect that all the ingredients of both products are similar, the
Plaintiff has not conducted any clinical investigation and any documents to that effect is not
produced.
Com.O.S.No.4816/2015
48. The Plaintiff in support of its contentions has relied upon Ex.P.20 to Ex.P.22/Certificates of
Registration/Permission to use the substances i.e., Beauveria Bassiana and Metarhizium issued in
favour of the Plaintiff under Section 9 (3) of Insecticides Act. The learned Advocate for the 2nd
Defendant has argued that the Ex.P.20 to Ex.P.22 cannot be looked into as the same is of the year
2013-2014, and that the Plaintiff has failed to show when their product was launched and when the
said products came into the market, that it can be presumed from the Ex.P.20 to Ex.P.22 the
Plaintiff's so called star products came in the market in the year 2013-2014 only.
49. She has further argued that much prior to the year 2013
-2014, the Defendant No.2 Company had applied for the said Certificate/Permission to use the
substances namely, Beauveria Bassiana and Metarhizium and the same was granted as could be
seen in Ex.D.44 and Ex.D.45, wherein the permission was granted to the Defendant No.2 in 2007
and 2010 respectively.
50. It is the further arguments of the Advocate for the 2 nd Defendant that the Defendant No.2 as
well as another entity of Defendant No.2 namely, M/s Karnataka Agro Chemicals have been selling
the products namely, BABA and Metarhizium containing the substances namely, Beauveria
Bassiana and Com.O.S.No.4816/2015 Metarhizium from many years as could be seen from Ex.D.46
and Ex.D.47/Brouchers. The Ex.D.48 is a List of various companies who are using the substances
namely, Beauveria Bassiana and Metarhizium, since the year 2006. In fact, absolutely there is no
cross-examination in respect of Ex.D.48 by the Advocate for the Plaintiff to DW.2. Hence, the
Plaintiff has deemed to have been admitted the contents of Ex.D.48. When such being the case the
Plaintiff cannot contend any exclusive right over the said substances.
51. The learned Advocate for the Plaintiff has relied on a decision reported in A.I.R. - 1967 - S.C. -
1098 (Niranjan Shankar Golikari vs. Century Spinning and Manufacturing Company Limited),
wherein at Para No. 18 and 19 it is held as follows:-
"The result of the above discussion is that considerations against restrictive
covenants are different in cases where the restriction is to apply during the period
after the termination of the contract than those in cases where it is to operate duringAnd For The Relief Of Permanent ... vs Was Appointed By The Plaintiff As A ... on 30 March, 2022

the period of the contract. Negative covenants operative during the period of the
contract of employment when the employee is bound to serve his employer
exclusively are generally not regarded as restraint of trade and therefore do not fall
under Section 27 of the Contract Act. A negative covenant that the employee would
not engage himself in a trade or business or would not get Com.O.S.No.4816/2015
himself employed by any other master for whom he would perform similar or
substantially similar duties is not therefore a restraint of trade unless the contract as
aforesaid is unconscionable or excessively harsh or unreasonable or one sided as in
the case of W.H. Milsted and Son Ltd.(3). Both the Trial Court and the High Court
have found, and in our view, rightly, that the negative covenant in the present case
restricted as it is to the period of employment and to work similar or substantially
similar to the one carried on by the appellant when he was in the employ of the
respondent company was reasonable and necessary for the protection of the
company's interests and not such as the court would refuse to enforce. There is
therefore no validity in the contention that the negative covenant contained in clause
17 amounted to a restraint of trade and was therefore against public policy.
The next question is whether the injunction in the terms in which it is framed should
have been granted. There is no doubt that the courts have a wide discretion to enforce
by injunction a negative covenant. Both the courts below have concurrently found
that the apprehension of the respondent company that information regarding the
special processes and the special machinery imparted to and acquired by the
appellant during the period of training and thereafter might be divulged was
justified; that the information and knowledge disclosed to him during this period was
different from the general knowledge and experience that he might have gained while
in the service of the respondent company and that it was against his disclosing the
former to the rival company which required protection. It was argued however that
the Com.O.S.No.4816/2015 terms of clause were too wide and that the court cannot
sever the good from the bad and issue an injunction to the extent that was good. But
the rule against severance applies to cases where the covenant is bad in law and it is
in such cases that the court is precluded from severing the good from the bad. But
there is nothing to prevent the court from granting a limited injunction to the extent
that is necessary to protect the employer's interests where the negative stipulation is
not void. There is also nothing to show that if the. the negative covenant is enforced
the appellant would be driven to idleness or would be compelled to go back to the
respondent company. It may be that if he is not permitted to get himself employed in
another similar employment he might perhaps get a lesser remuneration than the
one agreed to by Rajasthan Rayon. But that is no consideration against enforcing the
covenant. The evidence is clear that the appellant has torn the agreement to pieces
only because he was offered a higher remuneration. Obviously he cannot be heard to
say that no injunction should be granted against him to enforce the negative covenant
which is not opposed to public policy. The injunction issued against him is restricted
as to time, the nature of employment and as to area and cannot therefore be said to
be too wide or unreasonable or unnecessary for the protection of the interests of theAnd For The Relief Of Permanent ... vs Was Appointed By The Plaintiff As A ... on 30 March, 2022

respondent company."
52. Per contra, the learned Advocate for the 1 st Defendant has argued that the question whether a
negative covenant which restricts right of the employee, after the completion of the term of the
service, or the termination of the employment Com.O.S.No.4816/2015 for other reasons, to engage
in any business, similar to or competitive with that of the employer, was in restraint of trade and
void under Section 27 of the Contract Act came up for consideration in the decision reported in
A.I.R. - 1980 - S.C. - 1717 (Superintendence Comapny of India Private Limited vs. Krishan Murgai),
before the three Judge Bench of the Hon'ble Supreme Court. In that case a permanent injunction
was sought against an ex-employee to restrain him from carrying on a business substantially similar
to that of the Plaintiff. One of the terms of the employment was that the employee after leaving the
service will neither serve any rival firm nor carry on himself a similar business for a period of two
years at the place where he last served. The employee's services were terminated and thereupon he
started his own rival business. It is held that a contract in restraint of trade was one by which a party
restricted his further liberty to carry on trade, business or profession in such manner and with such
persons as he opted.
53. I wish to refer a decision reported in A.I.R. - 1995 - S.C. - 2372 = 1995(5) - S.C.C. - 545 (Gujarat
Bottling Co. Ltd. vs. Coca Cola Company and Others), wherein, the Hon'ble Apex Court elaborately
considered the agreements in Com.O.S.No.4816/2015 restraint of trade. Clause 14 of the agreement
which was under
consideration before the Hon'ble Apex Court in the said case read, "As such the
bottler covenants that the Bottler will not manufacture, bottle, sell, deal or otherwise
be concerned with the products, beverages of any other brands or trade marks/trade
names during the subsistence of this Agreement including the period of one year's
notice as contemplated in paragraph 21." The Hon'ble Apex Court referred to the
historical back ground of Section 27 of the Indian Contract Act as was noticed in the
above-mentioned decision reported in A.I.R. - 1980 - S.C. - 1717 (Superintendence
Comapny of India Private Limited vs. Krishan Murgai), and at Para 23 has held as
follows:-
"23. The said provision was lifted from Hon. David D. Field's draft Code for New York
which was based upon the old English doctrine of restraint of trade, as prevailing in
ancient times. The said provision was, however, never applied in New York. The
adoption of this provision has been severely criticised by Suir Frederick Pollock who
has observed that "the law of India is tied down by the language of the section to the
principle, now exploded in England, of a hard and fast rule qualified by strictly
limited exceptions". While construing the provisions of Section 27 the High Courts in
India have held that neither the test of reasonableness nor the principle that the
restraint being partial or reasonable are applicable to a case Com.O.S.No.4816/2015
governed by Section 27 of the Contract Act, unless it falls within the exception. The
law Commission in its Thirteenth Report has recommended that the provision should
be suitably amended to allow such restrictions and all contracts in restraint of trade,And For The Relief Of Permanent ... vs Was Appointed By The Plaintiff As A ... on 30 March, 2022

general or partial, as were reasonable, in the interest of the parties as well as of the
public. No action has, however been taken by Parliament on the said
recommendation."
54. The Hon'ble Apex Court then proceeded to examine as to what was meant by contract in
restraint of trade and observed that inquiry into reasonableness of the restraint was not envisaged
by Section 27. While examining the said question, the Hon'ble Apex Court considered the
above-mentioned decisions A.I.R. - 1967 - S.C. - 1098 (Niranjan Shankar Golikari vs. Century
Spinning and Manufacturing Company Limited), and A.I.R. - 1980 - S.C. - 1717 (Superintendence
Comapny of India Private Limited vs. Krishan Murgai).
55. In view of the ratio of the above said decisions and in- view of the above discusions based on the
evidence adduced in this case, the Plaintiff has failed to prove that it is entitled for the relief of
Permanent Injunction against the Defendants as claimed by the Plaintiff. Hence, I answer this Issue
in the Negative.
Com.O.S.No.4816/2015
56. Issue No.7:- The 1st Defendant has filed a counter-claim of Rs. 8,90,967/- against the Plaintiff in
respect of Leave Encashment of Rs. 3,30,632/- and 3 months salary as offered by the Plaintiff, when
the Defendant tendered his resignation of Rs. 4,24,425/- and past interest at the rate of 18%, i.e., Rs.
1,35,910/- in total the above-mentioned amount of Rs. 8,90,967/-. As discussed by me earlier, the
PW.1 has not whispered anything about this counter claim in her Affidavit filed in-lieu of oral
Examination-in-Chief. During the cross- examination of DW.1, it is elicited that the Leave
Encahsment amount was withheld in view of the misconduct of the 1 st Defendant. However, as
discussed earlier the Plaintiff has failed to prove the said misconduct of the 1 st Defendant. Hence,
the 1st Defendant is entitled for the said amount. It is also elicited in his evidence that the 3 months
salary is only an offer and he is not eligible to claim the same as of right and there is no statutory
obligation to pay the same to the Plaintiff. Similar arguments is also advanced by the learned
Advocate for the Plaintiff. However, the Plaintiff has appreciated the services of the 1st Defendant in
Ex.D.37, Ex.D.38 and also in Ex.P.9, while accepting the resignation. After taking all these aspects,
the Plaintiff has unequivocally made an offer to pay 3 months salary to him. Now he cannot contend
otherwise. Though there is no statutory obligation to pay 3 months salary, on account of
Com.O.S.No.4816/2015 promise/offer made by the Plaintiff, they are estopped from contending
otherwise. Hence, they are liable to pay the said amount to the 1st Defendant. Hence, I answer this
Issue in the Affirmative.
57. Issue No.8: -Therefore, I proceed to pass the following Order.
ORDER The Suit of the Plaintiff is Dismissed.
The Counter-Claim of the 1st Defendant is allowed and decreed.And For The Relief Of Permanent ... vs Was Appointed By The Plaintiff As A ... on 30 March, 2022

The Plaintiff is hereby directed to pay a sum of Rs.8,90,967/- (Rupees Eight Lakhs Ninety Thousand
Nine Hundred Sixty Seven Only) along with interest at 18% per annum from the date of suit till
realization.
The Plaintiff is hereby directed to pay cost of this suit to the Defendants. The Advocate for the
Defendants are directed to file their respective Memorandum of Cost before the Office within 5 days
from today as required under Rule 99 and 100 of Karnataka Civil Rules of Practice.
Draw Decree accordingly.
Com.O.S.No.4816/2015 The Office is directed to send copy of this Judgment to Plaintiff and
Defendants to their email ID as required under Order XX Rule 1 of the Civil Procedure Code as
amended under Section 16 of the Commercial Courts Act.
(Dictated to the Stenographer, typed by her directly on the computer, verified and pronounced by
me in open Court on this the 30th day of March, 2022).
(DEVARAJA BHAT.M), LXXXII Addl. City Civil & Sessions Judge, Bengaluru.
ANNEXURE LIST OF WITNESSES EXAMINED ON BEHALF OF THE PLAINTIFF P.W.1 Mrs. K.S.
Harina LIST OF DOCUMENTS EXHIBITED ON BEHALF OF THE PLAINTIFF Ex.P.1 Extract of
Minutes of the Meeting of the Board of Directors dated 31.03.2015 of the Plaintiff.
Com.O.S.No.4816/2015 Ex.P.2 Appointment Letter 12.05.1998.
Ex.P.3 Secrecy Bond dated 02.06.1998.
Ex.P.4 Non disclosure Agreement dated 15.10.2010. Ex.P.5 Show Cause Letter dated 17.09.2014.
Ex.P.6 Reply E-mail dated 18.09.2014.
Ex.P.7 Copy of Reply dated 18.09.2014.
Ex.P.8 Resignation letter 18.09.2014.
Ex.P.9 Acceptance of Resignation dated 22.09.2014. Ex.P.10 E-mail dated 06.01.2014.
Ex.P.11 E-mail dated 04.01.2014.
Ex.P.12 E-mail dated 16.12.2013.
Ex.P.13 E-mail dated 04.01.2014.
Ex.P.14 E-mail dated 04.01.2014.And For The Relief Of Permanent ... vs Was Appointed By The Plaintiff As A ... on 30 March, 2022

Ex.P.15 E-mail dated 16.12.2013.
Ex.P.16 E-mail dated 04.01.2014.
Ex.P.17 E-mail dated 04.01.2014.
Ex.P.18 Email dated 05.06.2014.
Ex.P.19 E-mail dated 13.06.2014.
Ex.P.20 Certificate of Registration of Myco-Jaal bearing registration number F.No.3B/F/ 9 (3)/
2009- CIR.II issued by the Central Insecticides Board and Registration Committee.
Com.O.S.No.4816/2015 Ex.P.21 Provisional Certificate of Registration Metarhizinm anisoliae
bearing registration No. F.No.41-B/F/ 9 (3b)/2009 -CIR.II issued by Central Insecticides Board and
Registration Committee.
Ex.P.22 Letter dated 30.09.2014.
Ex.P.23 E-mail dated 14.07.2014.
Ex.P.24 E-mail dated 17.07.2014.
Ex.P.25 E-mail dated 17.07.2014.
Ex.P.26 E-mail dated 17.07.2014.
Ex.P.27 E-mail dated 16.07.2014.
Ex.P.28 E-mail dated 16.07.2014.
Ex.P.29 Email dated 17.06.2014.
Ex.P.30 E-mail dated 19.06.2014.
Ex.P.31 E-mail dated 17.06.2014.
Ex.P.32 E-mail dated 12.05.2014.
Ex.P.33 E-mail dated 20.08.2014.
Ex.P.34 E-mail dated 23.06.2014.
Ex.P.35 E-mail dated 14.05.2014.And For The Relief Of Permanent ... vs Was Appointed By The Plaintiff As A ... on 30 March, 2022

Ex.P.36 E-mail dated 14.05.2014.
Ex.P.37 E-mail dated 14.05.2014.
Ex.P.38 E-mail dated 24.08.2014.
Com.O.S.No.4816/2015 Ex.P.39 E-mail dated 12.05.2014.
Ex.P.40 E-mail dated 15.02.2014.
Ex.P.41 E-mail dated 05.05.2014.
Ex.P.42 Legal Notice dated 21.11.2014.
Ex.P.43 Reply Notice dated 28.11.2014.
Ex.P.44 Legal Notice dated 10.12.2014.
Ex.P.45 Legal Notice dated 06.01.2015.
Ex.P.46 Legal Notice dated 16.01.2015.
Ex.P.47 Legal Notice dated 29.01.2015.
Ex.P.48 Legal Notice dated 30.01.2015.
Ex.P.49 Legal Notice dated 18.02.2015.
Ex.P.50 Legal Notice dated 18.02.2015.
Ex.P.51 Legal Notice dated 11.04.2014.
Ex.P.52 Legal Notice dated 15.04.2015.
Ex.P.53 Legal Notice dated 02.05.2015.
Ex.P.54 Legal Notice dated 19.05.2015.
Ex.P.55 Reply Notice dated 05.06.2015.
Ex.P.56 Tax Invoice Cash Bill dated 16.01.2017. Ex.P.57 Product manufactured by the Plaintiff by
name "Lastraw"
Ex.P.58 Product manufactured by the Defendant No.2 by name "Multiplex Strike Plus Bio-Pesticide.And For The Relief Of Permanent ... vs Was Appointed By The Plaintiff As A ... on 30 March, 2022

Com.O.S.No.4816/2015 Ex.P.59 Certificate under Section 65 B of Indian Evidence Act.
Ex.P.60 Product requirement of organize international workshop.
LIST OF WITNESSES EXAMINED ON BEHALF OF THE DEFENDANTS DW.1 Dr. Swpan Kumar
Ghosh DW.2 Dr. Nataraj Thiyagarajan LIST OF DOCUMENTS EXHIBITED ON BEHALF OF THE
DEFENDANTS Ex.D.1 2 Postal receipts dated 05.12.2014 Ex.D.2 Postal Acknowledgment dated
05.12.2014.
Ex.D.3       Legal Notice dated 10.12.2014.
Ex.D.4       Two Postal Receipts dated 10.12.2014.
Ex.D.5 & 6   Postal    Acknowledgment           dated
             10.12.2014.
Ex.D.7 & 8   Legal Notice dated 16.01.2015.
Ex.D.9       Legal Notice dated 29.01.2015.
                                      Com.O.S.No.4816/2015
Ex.D.10        Legal Notice dated 18.02.2015.
Ex.D.11        Legal Notice dated 18.02.2015.
Ex.D.12        Two Postal Receipts dated 18.02.2015.
Ex.D.13        Legal Notice dated 11.04.2015.
Ex.D.14        Two Postal Receipts dated 11.04.2015.
Ex.D.15 & 16   Two Postal    Acknowledgment     dated
               11.04.2015.
Ex.D.17        Legal Notice dated 15.04.2015.
Ex.D.18        Two Postal Receipts dated 15.04.2015.
Ex.D.19        Postal    Acknowledgment         dated
               15.04.2015.
Ex.D.20        Legal Notice dated 05.12.2014
Ex.D.21        Legal Notice dated 02.05.2015.
Ex.D.22        Legal Notice dated 19.05.2015.
Ex.D.23        Two Postal Receipts dated 19.05.2015.
Ex.D.24        Postal    Acknowledgment         dated
               19.05.2015.
Ex.D.25        Reply Notice dated 05.06.2015.
Ex.D.26        Two Postal Receipts dated 05.06.2015.
Ex.D.27        Postal    Acknowledgment         dated
               05.06.2015.
Ex.D.28        Terms and conditions of Employment
               cadre issued by the Plaintiff Company.
                                  Com.O.S.No.4816/2015
Ex.D.29   Reply Notice dated 28.11.2014.
Ex.D.30   Postal Receipts 28.11.2014.
Ex.D.31   Postal    Acknowledgment          dated
          28.11.2014.And For The Relief Of Permanent ... vs Was Appointed By The Plaintiff As A ... on 30 March, 2022

Ex.D.32 Emails correspondence between the Plaintiff and Defendant No.1 regarding settlement of
dues.
Ex.D.33 37 Emails correspondence between the Plaintiff and Defendant No.1 regarding settlement
of PF.
Ex.D.34 E-mail dated 30.01.2015.
Ex.D.35 Legal Notice dated 21.11.2014.
Ex.D.36 Promotion Letter 19.08.1999.
Ex.D.37 Appreciation Letter 12.07.2004.
Ex.D.38 Appreciation Letter 25.02.2010.
Ex.D.39 Selection Letter 18.05.2005.
Ex.D.40 Advertisement label for Met 52 of Novozymes Company.
Ex.D.41 Advertisement label for the product Baba issued by Defendant No.1.
Ex.D.42 Advertisement label for the product Metarhizium issued by Defendant No.1.
Ex.D.43 Board Resolution dated 18.01.2021 Com.O.S.No.4816/2015 Ex.D.44 and 45 Certificate of
Registration of Inspection under Section 9(3B) of the Insecticides Act.
Ex.D.46 Label product of Beauveria Bassiana. Ex.D.47 Label product of Multiplex Metarhizim.
Ex.D.48          List of transactions.
                            (DEVARAJA BHAT.M),
                  LXXXII Addl. City Civil & Sessions Judge,
                                Bengaluru.And For The Relief Of Permanent ... vs Was Appointed By The Plaintiff As A ... on 30 March, 2022

