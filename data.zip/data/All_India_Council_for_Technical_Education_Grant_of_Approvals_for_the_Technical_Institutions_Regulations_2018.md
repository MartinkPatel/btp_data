All India Council for Technical Education (Grant of Approvals for
the Technical Institutions) Regulations, 2018
UNION OF INDIA
India
All India Council for Technical Education (Grant of
Approvals for the Technical Institutions) Regulations,
2018
Rule
ALL-INDIA-COUNCIL-FOR-TECHNICAL-EDUCATION-GRANT-OF-APPROVALS-FOR-THE-TECHNICAL-INSTITUTIONS-REGULATIONS-2018
of 2018
Published on 31 December 2018• 
Commenced on 31 December 2018• 
[This is the version of this document from 31 December 2018.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
All India Council for Technical Education (Grant of Approvals for the Technical Institutions)
Regulations, 2018Published vide Notification F. No. AB/AICTE/REG/2018, dated 31.12.2018Last
Updated 5th January, 2019F. No. AB/AICTE/REG/2018. - In exercise of its powers conferred under
sub-section (1) of Section 23 read with Sections 10 and 11 of the All India Council for Technical
Education Act, 1987 (52 of 1987) and in supersession of the All India Council for Technical
Education (Grant of Approvals for the Technical Institutions) Regulations, 2016 notified in the
Gazette of India vide F. No: 37-3/Legal/AICTE/2016 dated 30th November, 2016 and the First
Amendment dated 5th December 2017 in Gazette notification, the All India Council for Technical
Education makes the following Regulations: -Preamble. - To regulate/ facilitate in an organized
manner, the Technical Institutions in maintaining quality, to follow the norms in consistent with the
ideals of AICTE and further to create an enabling environment for the Technical Institutions to
become high quality Institutions, AICTE, in exercise of powers conferred under sub section (1) of
Section 23 read with Sections 10 and 11 of the All India Council for Technical Education Act, 1987,
hereby makes the following Regulations namely:-
1. Short Title, Application and Commencement.
- 1.1 These Regulations shall be called the All India Council for Technical Education (Grant of
Approvals for the Technical Institutions) Regulations, 2018.1.2These Regulations are applicable for
the applications submitted under:a. Setting up a new Technical Institution offering a Technical
Programme at Diploma/ Post Diploma Certificate/ Under Graduate Degree/ Post GraduateAll India Council for Technical Education (Grant of Approvals for the Technical Institutions) Regulations, 2018

Diploma/ Post Graduate Degree Level;b. Change of Site/ Location;c. Conversion of Women's
Institution into Co-ed Institution and vice-versa;d. Conversion of Diploma Level into Degree Level
and vice-versa;e. To start new Programme(s)/ Level(s) in the existing Institutions;f. Extension of
Approval to the existing Institutions;g. Continuation of approval after a break in the preceding
Academic Year(s)/ Restoration of Intake;h. Extended EoA;i. Increase in Intake/ Additional
Course(s);j. Introduction of Integrated/ Dual Degree Course;k. To start Diploma in Degree
Pharmacy Institutions and vice-versa;l. Merger of Institutions under the same Trust/ Society/
Company operating in the same Campus;m. Closure of the Institution;n. Conversion of
Management Institutions running PGDM Course into MBA Course;o. Conversion of Second Shift
Course(s) into First Shift Course(s);p. Closing of MBA Programme and Introduction of MCA
Programme and vice-versa;q. Introduction/ Continuation of Fellowship Programme in
Management;r. Introduction/ Continuation of supernumerary seats for Foreign Nationals/ Overseas
Citizen of India (OCI)/ Persons of Indian Origin (PIO)/ Children of Indian Workers in Gulf
Countries;s. Introduction/ Continuation of seats for Non Resident Indian(s);t. Change in the Name
of the Course(s)/ Merger of the Courses/ Reduction in Intake/ Closure of Programme(s)/ Course(s)/
Merger of Lateral Entry Separate Division in Second Year Engineering and Technology/ MCA to
First Year Regular Courses;u. Change in the Name of the Institution or Affiliating
University/Board;v. Change in the Name of the Bank;w. Change in the Name of the Trust/ Society/
Company;x. Collaboration and Twinning Programme between Indian and Foreign Universities/
Institutions in the field of Technical Education, Research and Training; andy. Introduction of
Vocational Education Courses.1.3These Regulations shall come into force with effect from the date
of their publication in the Official Gazette.
2. Definitions.
- In these Regulations, unless the context otherwise requires2.1"Academic Year" means Academic
Year of the concerned Affiliating University/ Board/ Technical Institution.2.2"Act" means the All
India Council for Technical Education Act, 1987 (52 of 1987).2.3"Adjunct Faculty" means resource
person as per the guidelines specified in Approval Process Handbook.2.4"Affidavit" is a written
sworn statement of fact voluntarily made by a deponent under an oath or affirmation administered
by a person authorized to do so by Law. Such statement is witnessed as to the authenticity of the
deponent's signature by a taker of oaths, such as a Notary Public or Commissioner of
Oaths.2.5"AICTE Web-Portal" means the Web site hosted by the Council at URL www.aicteindia.
org.2.6"Approval Process Handbook (APH)" is a handbook published by AICTE, prescribing norms
and procedures for processing of applications submitted for grant of various
approvals.2.7"Applicant" is the one who makes an application to the Council for seeking any kind of
approval under these Regulations.2.8"Approved Institution" means the Technical Institution
approved by the Council.2.9"Approved Intake" means the number of students to be admitted in a
Course as approved by the Council.2.10"Autonomous Institution" means an Institution to which
autonomy is granted by UGC and is designated to be so by the Statutes of Affiliating University/
Board.2.11"Break in EoA" means break in the Extension of Approval of the Institution in the
previous year(s).2.12"Build-Operate-Transfer (BOT)" means a project financing, wherein a private
entity receives a concession from the public sector to finance, design, construct and operate a facility
stated in the concession contract.2.13"Chairman" means the Chairman of AICTE as described underAll India Council for Technical Education (Grant of Approvals for the Technical Institutions) Regulations, 2018

sub-section 4(a) of Section 3 of AICTE Act, 1987.2.14"Co-ed Institution" means the Institution
admitting male, female and transgender students.2.15"Commission" means the University Grants
Commission established under Section 4 of the University Grants Commission Act,
1956.2.16"Company" means a Company established/ registered under Section 8 of the Companies
Act, 2013.2.17"Competent Authority for Admission" means an Organization that has, the legally
delegated authority, capacity, or power to do admission to Technical Institutions in the State
Government/ UT concerned.2.18"Compliance Report" means the Report submitted by the Technical
Institution complying with the requirements as specified in the Approval Process Handbook for the
deficiencies observed by Expert Visit Committee/ issues mentioned in the Show Cause
Notice.2.19"Constituent College" means an Institution/ Department/ College/ School as a part of
the University.2.20"Council" means All India Council for Technical Education established under
Section 3 of the Act.2.21"Course" means one of the branches of learning in a Programme such as
Civil Engineering, Mechanical Engineering, etc.2.22"Division" meansa. A batch of a maximum of
Sixty (60) seats in Diploma/ Under Graduate Courses in Engineering and Technology/ Hotel
Management and Catering Technology/ Post Graduate Courses in MCA/ PGCM/ PGDM/ MBA
Programme, excluding supernumerary seats, if any;b. A batch of Sixty (60) seats in Diploma/ Under
Graduate Courses and to a maximum of Hundred (100) seats in Under Graduate Courses in
Pharmacy Programme, excluding supernumerary seats, if any;c. A batch of a maximum of Forty
(40) seats in Diploma/ Under Graduate Courses in Architecture/ Planning Programme, excluding
supernumerary seats, if any;d. A batch of a maximum of Thirty (30) seats in Diploma/ Under
Graduate Courses in Applied Arts and Crafts Programme, excluding supernumerary seats, if any;e.
A batch of a maximum of Thirty (30) seats in Diploma/ Under Graduate Courses in Design
Programme, excluding supernumerary seats, if any;f. A batch of a maximum of Thirty (30) seats in
Post Graduate Courses in Engineering and Technology/ Planning/ Applied Arts and Crafts/ Hotel
Management and Catering Technology Programme, excluding supernumerary seats, if any;g. A
batch of a maximum of Twenty (20) seats in Post Graduate Courses in Architecture Programme,
excluding supernumerary seats, if any;h. A batch of a maximum of Fifteen (15) seats in Post
Graduate Courses in Design Programme, excluding supernumerary seats, if any;i. A batch of a
maximum of Fifteen (15) seats in Post Graduate Courses in Pharmacy, Thirty (30) seats in
Pharm.D., Ten (10) seats in Pharm.D. (Post Baccalaureate) in Pharmacy Programme, excluding
supernumerary seats, if any;j. A batch of a maximum of Sixty (60) seats in Integrated Degree
Courses in Engineering and Technology/ Hotel Management and Catering Technology/ MCA
Programme and Integrated/ Dual Degree Course in MBA Programme, excluding supernumerary
seats, if any;k. A batch of a maximum of Forty (40) seats in Integrated Degree Course in Planning
Programme, excluding supernumerary seats, if any; andl. A maximum of Twenty (20) seats per year
in Fellowship in Management Programme.2.23"EoA" means Extension of Approval granted by
AICTE for conduct of Technical Programme(s)/ Course(s) to an Institution for that Academic
Year."Extended EoA" means Extension of Approval granted by AICTE for conduct of Technical
Programme(s)/ Course(s) to an Institution for more than one Academic Year.2.24"Executive
Committee" means the Committee constituted by the Council under Section 12 of AICTE Act,
1987.2.25"Expert Visit Committee (EVC)" means the Committee constituted by the Regional Officer
as per the composition specified in Approval Process Handbook to verify physically the availability
of Infrastructural facilities of an Institution.2.26"First Shift" means educational activities conducted
in the First spell of time (from 8 am to 3 pm) wherever two-shift working exists.2.27"ForeignAll India Council for Technical Education (Grant of Approvals for the Technical Institutions) Regulations, 2018

National" means the Citizen of the Countries other than India who are not of Indian origin as
defined under OCI/ PIO.2.28"Government aided Institution" means Technical Institution that
meets 50% or more of its recurring expenditure out of the grant received from the Government or
Government Organizations.2.29"Government Institution" means Technical Institution established
and/ or fully maintained by the Government.2.30"Head of the Institution" means the
Vice-Chancellor in case of a University or an Institution Deemed to be University, the Principal/
Director/ such other designation as the administrative Head of the Institution of the Technical
Institution referred.2.31"Institution Deemed to be University" means an Institution for higher
Education so declared, on the recommendation of the Commission, by the Central Government
under Section 3 of the University Grants Commission Act, 1956.2.32"Lateral Entry" means
admission of students into the second year of Diploma/ Under Graduate Degree/ MCA Programmes
as specified in Approval Process Handbook.2.33"Level" means Diploma, Post Diploma Certificate,
Under Graduate Degree, Post Graduate Diploma and Post Graduate Degree
Programmes.2.34"Minority Institution" means an Educational Institution established and
administered by a minority or minorities and recognized by Competent Authority as Minority
Institution.2.35"NBA" means the National Board of Accreditation, an autonomous body set up by
AICTE, registered under Societies Registration Act, 1860.2.36"Part Time" means educational
activities conducted in evening time, i.e. 5.30 pm to 9.30 pm (six days a week) wherever Regular/
First Shift working exists and are meant only for working professionals or professionals with at least
two years of work experience. Duration of the Course shall be a minimum of one/ two Semester(s) in
excess than that of the Regular Course.2.37"Private University" means a University duly established
through a State/ Central Act by a sponsoring body viz., a Society registered under the Societies
Registration Act 1860, or any other corresponding Law for the time being in force in a State or a
Public Trust or a Company registered under Section 8 of the Companies Act,
2013.2.38"Programme" means the field of Technical Education, i.e. Engineering and Technology,
Pharmacy, Architecture and Planning, Applied Arts, Crafts and Design, Hotel Management and
Catering Technology, MCA, Management (PGCM/ PGDM/ MBA) and such other Programmes/
areas as notified by AICTE Act, 1987.2.39"Public Private Partnership (PPP)" means a Partnership
based on a contract or concession agreement, between a Government or Statutory entity on the one
side and a Private Sector enterprise on the other side.2.40"Regional Committee (RC)" means a
Committee established for each region under Section 14 of AICTE Act, 1987.2.41"Restoration of
Intake" means restoring back to the "Approved Intake" of the Institution that was existing prior to
any penal action.2.42"Second Shift" means educational activities conducted in the Second spell of
time (from 12 Noon to 7 pm) wherever two-shift working exists.2.43"Self-Financing Institution"
means an Institution started by a Trust/ Society/ Company and does not receive grant/ fund from
Central/ State Government/ UT for meeting its recurring expenditure.2.44"Single Shift/ Regular
Shift" means where, educational activities of the Technical Institution are conducted between 9 am
and 5 pm.2.45"Society" means a Society registered under Societies Registration Act,
1860.2.46"Standalone Institutions" means those Institutions which are not affiliated to any of the
University/ Board, but are imparting education by means of conducting regular courses leading to
Diploma, Post Diploma Certificate, Post Graduate Certificate and Post Graduate Diploma Levels in
Management and allied areas, Travel and Tourism, Innovation and Entrepreneurship, Computer
Applications and Design.2.47"Standing Appellate Committee (SAC)" means a Committee
constituted by the Chairman as per the composition specified in Approval Process Handbook forAll India Council for Technical Education (Grant of Approvals for the Technical Institutions) Regulations, 2018

considering the appeals of the Technical Institutions.2.48"Standing Complaint Scrutiny Committee
(SCSC)" means a Committee constituted by the Chairman as per the composition specified in
Approval Process Handbook for the Scrutiny of Complaints received against the Technical
Institutions.2.49"Standing Hearing Committee (SHC)" means a Committee constituted by the
Chairman as per the composition specified in Approval Process Handbook to review the Reports of
the Expert Visit Committee/ replies received for Show Cause Notices.2.50"State Level Fee
Committee" means a Committee notified by the concerned State Government/ UT for Regulation of
fee to be charged by the Technical Institutions.2.51"Supernumerary seats" includes TFW, OCI/ PIO/
Foreign Nationals/ Children of Indian Workers in the Gulf Countries, Lateral Entry, PwD and J&K
PMSSS seats notified from time to time, over and above the "Approved Intake".2.52"Technical
Institution" means an Institution set up by the Government, Government aided and Self-Financing/
Trust/ Society/ Company for conducting Course(s)/ Programme(s) in the field of Technical
Education, Training and Research in Engineering and Technology, Pharmacy, Architecture and
Planning, Applied Arts, Crafts and Design, Hotel Management and Catering Technology, MCA,
Management, and such other Programmes and areas as notified by AICTE Act, 1987.2.53"Trust"
means a Trust registered under the Indian Trust Act, 1882 as amended from time to time or any
other relevant Acts.2.54"University" means a University defined under Clause (f) of Section 2 of the
University Grants Commission Act, 1956.2.55"University Department" means a Department
established and maintained by the University.2.56Any other word and expression used herein and
not defined but defined in the All India Council for Technical Education Act, 1987 (52 of 1987), shall
have the same meaning respectively assigned to them in the said Act.
3. Relevance of Grant of Approval.
- 3.1 After commencement of these Regulationsa. New Technical Institutions either by Government/
Government aided or Self-financing Institutions shall be started ONLY after obtaining approval of
the Council.b. Existing Government/ Government aided/ Self-financing Institutions shall either
conduct/ increase/ reduce the intake in the existing Course(s)/ Programmes or introduce new
Programme(s)/ Course(s) at any Level ONLY after obtaining approval of the Council.c. In no
eventuality, a Technical Institution without prior approval of AICTE and Affiliating University/
Board concerned, shall be allowed to participate in the counselling and admission process and to
admit students.d. Affiliating University/ Board shall not enroll students admitted in such Technical
Institutions, which do not have requisite prior approval of the Council.e. Central/ State
Government/ UT concerned shall not admit students to any Programme of a Technical Institution,
which do not have requisite prior approval of the Council.3.2In view of the large number of vacant
seats in various Programmes during the last few years and the likely future demand, the Council
shall grant approval to the new/ existing Institutions taking into account the recommendations of
the Committee set up by AICTE to provide the National Perspective Plan for the Technical
Programmes.
4. Generic Conditions for Approval.
- 4.1 a. The Applicants shall not name the Technical Institution in such a way that the abbreviated
form of the name of the Technical Institution becomes IIM/ IIT/ IISc/ NIT/ AICTE/ UGC/ MHRD/All India Council for Technical Education (Grant of Approvals for the Technical Institutions) Regulations, 2018

GoI. The Applicant shall also not use the word(s) Government/ India/ Indian/ National/ All India/
All India Council/ Commission, anywhere in the name of the Technical Institution and other names
as prohibited under the Emblems and Names (Prevention of Improper Use), Act, 1950. Provided
that the restrictions mentioned above shall not be applicable, if the Technical Institution is
established by Government of India or its name is approved by the Government of India.b.
Applicants/ Institutions shall not use the names of the Existing Institutions within the
State.4.2MHRD directives such as Scheme of "Sub-Mission on Polytechnics", to establish a
Technical Institution in "Educationally Backward Districts/ Left Wing Extremism (LWE) affected"
Districts, digital payment for all financial transactions, National Academic Depository (NAD), Study
in India and any other scheme(s) shall be complied with, as specified in Approval Process
Handbook.4.3AICTE does not recognize the Programme(s)/ Course(s) in Technical Education
offered through distance mode except Management, MCA and Diploma/ Degree in Travel and
Tourism Programmes, with the explicit approval of AICTE.4.4The Council shall not permit the
Introduction of Part Time/ Second Shift Courses.4.5To maintain the quality of Education, 60% of
the eligible Courses in any Technical Institution shall be accredited in the next 4 years time, else
EoA shall not be issued by the Council.4.6For Institutions having Courses with meager admissions
consistently, appropriate action as specified in the Approval Process Handbook shall be initiated
with the approval of the Council.4.7A Company having any foreign equity directly or indirectly as
shareholding shall not be permitted to apply for setting up a Technical
Institution.4.8Supernumerary seatsa. Fifteen percent (15%) supernumerary seats over and above
the "Approved Intake" per Course shall be approved in AICTE approved Institutions and University
Departments, for admitting students from Foreign Nationals/ Overseas Citizen of India (OCI)/
Persons of Indian Origin (PIO)/ Children of Indian Workers in the Gulf Countries. One third (1/3rd)
of these 15% seats shall be reserved for the Children of Indian Workers in the Gulf Countries.Any
vacant seat in a given Course, out of 1/3rd seats reserved for Children of Indian Workers in the Gulf
Countries shall be reverted to the seats of 2/3rd meant for OCI/ PIO/ Foreign Nationals and
vice-versa. Further, any vacant seat in the "Foreign Nationals/ Overseas Citizen of India (OCI)/
Persons of Indian Origin (PIO)/ Children of Indian Workers in Gulf Countries" after the last round
of the admission of the concerned State Government/ UT may be filled with NRI seats, subject to
the approval from AICTE for the NRI seats and fulfillment of requisite norms as specified in the
Approval Process Handbook.Beside this, any vacant seat in the "Approved Intake" after the last
round of the admission of the concerned State Government/ UT, may be filled with NRI/ Foreign
Nationals/ Overseas Citizen of India (OCI)/ Persons of Indian Origin (PIO)/ Children of Indian
Workers in the Gulf Countries, subject to the approval from AICTE for the above seats and
fulfilment of requisite norms as specified in the Approval Process Handbook.b. The Council shall
permit the Introduction/ Continuation of NRI/ OCI/ PIO/ FN/ Children of Indian Workers in the
Gulf Countries seats ONLY in the Regular Shift Courses.c. Mandatory provision of supernumerary
seats under Tuition Fee Waiver Scheme in all the Courses and Programmes shall be applicable to all
Technical Institutions as specified in the Approval Process Handbook.4.9Admission under Lateral
Entry in Diploma/ Under Graduate Degree/ Post Graduate Course(s).a. Lateral Entry to Second
Year Diploma Course(s) shall be permissible up to a maximum of 10% of the "Approved Intake"
which shall be over and above, supernumerary to the "Approved Intake", plus the unfilled vacancies
of the First year as specified in the Approval Process Handbook.b. Lateral Entry to Second Year
Degree Course(s) in Engineering and Technology/ Pharmacy/ MCA Course shall be permissible upAll India Council for Technical Education (Grant of Approvals for the Technical Institutions) Regulations, 2018

to a maximum of 10% of the "Approved Intake" which shall be over and above, supernumerary to
the "Approved Intake", plus the unfilled vacancies of the First year as specified in the Approval
Process Handbook.c. Any Foreign National who has obtained Diploma in a Foreign Institution
(having an equivalency Certificate issued by the Association of Indian Universities) or Diploma in an
Indian Institution shall also be eligible for Lateral Entry into the Second Year Degree Course(s). The
Institutions having approval for the supernumerary seats in such Course(s) are ONLY eligible to
admit the Foreign Nationals as per the norms, else the Institution shall apply for the same on AICTE
Web-Portal. However, the total Foreign Nationals admitted under supernumerary seats and the
Lateral Entry shall not exceed the 15% of the "Approved Intake" in an Academic year.d. The Council
shall not permit the Introduction or Continuation of Lateral Entry Separate Division in Second Year
Engineering and Technology/ MCA Courses.4.10Guidelines for the new/ existing Institutionsa. ALL
the Technical Institutions shall fulfill the relevant requisite norms as specified in the Approval
Process Handbook.b. Documents showing ownership of Land/ Building as per the provisions of
Section 8 of the Transfer of Property Act, 1882 or any other Law for the time being in force relating
to transfer of property to or by Companies, Associations or bodies of individuals, in the name of the
Applicant in the form of Registered Sale Deed/ Irrevocable Gift Deed (Registered)/ Irrevocable
Government/ Private Lease Deed (Registered) (for a period of minimum 30 years with at least 25
years of live Lease at the time of submission of application).Further to that, it shall be open for the
Promoter Trust/ Society/ Company of the proposed Institution to mortgage the Land after the
receipt of Letter of Approval, only for raising the resources for the purpose of development of the
Technical Education Institution situated on that Land. It shall be open for the Promoter Trust/
Society/ Company of the existing Institution to run other Educational Courses/ Institutions
(Technical/ Non-Technical) in the surplus Land arising out of the prevailing/ reduced norms of
Land requirement. However, such surplus Land shall be used as per the Land Use Certificate given
to the Trust/ Society/ Company by the concerned authority, subject to such Courses/ Institutions
having their own facilities to conduct such Programmes without sharing the essential infrastructure
facilities such as Class Room, Laboratory etc. with the already approved Technical Institution.
However, common amenities such as Canteen, Auditorium, Playground, Parking, etc. may be
shared, provided it caters to all the students of all the Programmes.c. The Promoter Trust/ Society/
Company of a new Technical Institution shall have to construct the required Built-up area for setting
up of Institution, as mentioned in the Approval Process Handbook and amended from time to
time.d. No NOC from Affiliating University/ Board/ State Government/ UT shall be required for the
reduction in intake to Non-Zero intake/ closure of the Second Shift Courses.e. For Closure of
PGCM/ PGDM Courses, NOC from Affiliating University/ Board/ State Government/ UT is not
applicable.f. Institutions having an "Approved Intake" less than a Division size in any of the
Regular/ First Shift Courses as prescribed by the Council may apply for intake of full Division size
themselves and shall maintain Faculty: Student ratio accordingly, without NBA accreditation/ NOC
from Affiliating University/ Board/ State Government/ UT, subject to "Zero Deficiency" in the
Web-Portal. However, this is not applicable in case of Institutions under penal action.g. Institutions
may apply for reduction in intake in any of the Regular/ First Shift Courses within a Division by
themselves in the Web-Portal and shall maintain Faculty: Student ratio accordingly, without NOC
from Affiliating University/ Board/ State Government/ UT, the restoration shall be permitted within
a Division without NBA.h. Existing Institutions having total "Approved Intake" less than the
"Maximum Intake Allowed"/ Institutions not eligible to apply for NBA accreditation, shall beAll India Council for Technical Education (Grant of Approvals for the Technical Institutions) Regulations, 2018

permitted to increase (without NBA accreditation) upto the "Maximum Intake Allowed" in each
Programme (considering all the specializations in MBA) as that of a new Technical Institution, as
specified in the Approval Process Handbook, subject to "Zero Deficiency" based on Self-Disclosure
on AICTE Web-Portal.An Expert Visit Committee may be conducted, any time before the first batch
of students has passed out, to verify the fulfillment of the norms as specified in the Approval Process
Handbook.i. Well performing Institutions providing quality technical education through
accreditation of Courses by NBA/ UGC approved autonomy, shall be duly recognized by AICTE and
considered for grant of approvals for Extended EoA as specified in Approval Process Handbook.
Institutions approved for extended EoA are waived from paying TER Charges for Extension of
Approval (EoA) ONLY for the extended years. However, such Institutions are required to submit the
application for EoA and duly fill all the data and maintain ALL the norms and standards as specified
in Approval Process Handbook.j. The Institution shall be given an opportunity to comply the
deficiencies, if any, before the Scrutiny/ Re-Scrutiny Committee, to fulfill the criteria of "Zero
Deficiency" based on Self-Disclosure, for processing the application, as applicable.4.11Guidelines for
the Universitiesa. Central, State and Private Universities may apply for approval by providing
Infrastructure and other requirements as specified in the Approval Process Handbook.Institutions
Deemed to be Universities shall seek prior approval of the Council under Clause 1.2 of these
Regulations.The requirements, eligibility and procedure shall be as specified in Approval Process
Handbook.Further to that, the Institution Deemed to be Universities shall also have to fulfill the
norms as per UGC Regulations.b. Institutions Deemed to be Universities offering Technical
Course(s)/ Programme(s) shall not admit students without prior approval of the Council.c.
Universities seeking approval for the first time from AICTE shall submit an application as a new
Technical Institution for all their existing Technical Programme(s) and Course(s). Institution
Deemed to be University having multiple Campuses/ Off Campuses/ Constituent Colleges shall
apply separately for approval.
5. Submission of the applications.
- 5.1 Application for grant of approval under these Regulations 1.2, a, b, c, d, e, l, m, n, p, u, v, w and
x shall be made by any of the followinga. The Chairman/ Secretary in case of the Trust/ Society/
Company;b. An Officer authorized by the concerned Central/ State Government/ UT in case of
Central or State Government/ UT Administration or a Society/ Trust registered with them; andc. An
Officer authorized by the Trust/ Society/ Company/ Central/ Sate Government/ UT under Public
Private Partnership or Build Operate Transfer (BOT) mode made by them, as the case may
be.5.2Application for grant of approval under these Regulations 1.2. f, g, h, i, j, k, o, q, r, s, t and y
shall be made by any of the followingPrincipal/ Director of the Technical Institution or Head of the
Institution or an Officer of the Institution duly authorized by the Promoter of such Institution or
Chairman/ Secretary in case of the Trust/ Society/ Company or Vice Chancellor/ Registrar of
Institution Deemed to be University.5.3The Council shall publish, from time to time, Approval
Process Handbook detailing the documents to be attached to the application, the Technical
Education Regulatory (TER) Charges to be remitted, the norms and standards, requirements and
the procedure by which the applications are processed for grant of approval of the new/ existing
Institutions.5.4a. The Applicant for setting up a new Institution shall obtain a unique USER ID
following the procedure specified in the Approval Process Handbook.The Applicants/ existingAll India Council for Technical Education (Grant of Approvals for the Technical Institutions) Regulations, 2018

Institutions shall be required to submit online application for the cases listed in Clauses 1.2 of these
Regulations using their unique USER ID allotted to them by remitting the prescribed TER Charges
as specified in Approval Process Handbook through AICTE's payment gateway on the Web-Portal,
failing which the application shall not be considered.b. Only those applications submitted within the
cut-off date, including payment shall be considered for processing.c. The Web-Portal permits the
generation of Deficiency Report for the applications.d. The Applicants shall edit the data till the final
submission of the application on the Web-Portal.After pressing the "submit" tab, the data shall not
be allowed for any further editing till the processing of the application is completed.e. If an
Applicant/ Institution has wrongly submitted an application, the same shall be processed as per the
procedure mentioned in the Approval Process Handbook.f. Applicants have to upload documents in
the Web-Portal/ submit to the Scrutiny/ Re- Scrutiny Committee, as applicable, as specified in the
Approval Process Handbook.g. An Affidavit, in the Format as specified in the Approval Process
Handbook, on a Non- Judicial Stamp Paper of 100/- duly sworn before a First Class Magistrate or
Notary or an Oath Commissioner, inter alia, stating that the information given in the application is
true and that if it is found at any time that any part of the information has been suppressed and/or
misrepresented and/or the information given in the application is false, the Council shall be free to
take action including Withdrawal of Approval/ not considering for grant of approval and/ or any
other legal action as it may deem fit shall be submitted/ uploaded by the Applicants.h. In case of
rejection of an application, the applicable TER Charges shall be refunded as specified in the
Approval Process Handbook.
6. Procedure for the processing of the applications.
- 6.1 The applications received shall be processed as per the norms and procedures prescribed in the
Approval Process Handbook as notified by the Council from time to time in addition to the existing
Central, State and Local Laws.6.2For setting up a new Institutiona. The State Government/ UT and
the Affiliating University/ Board shall forward their views on the applications received under Clause
1.2. a of these Regulations to the concerned Regional Office, not later than one week from the last
date of submission of application as notified.In the absence of the receipt of views from the State
Government/ UT/ Affiliating University/ Board on the application, the Council shall proceed for
further processing.b. The applications received under Clause 1.2. a of these Regulations, shall be
processed by a Scrutiny Committee/ Re-Scrutiny Committee duly formed by the Regional Officer as
per the composition as mentioned in Approval Process Hand Book for issue of Letter of Intent (LoI)
and the Applicant shall present ALL the original documents along with self-attested copies to the
Committee. Applicants are advised to adhere to Scrutiny schedule and not to remain absent.The
Applicant, if interested to start the Institution in the current Academic Year itself, shall submit a
Resolution to that effect to Scrutiny/Re-Scrutiny Committee.c. The recommendations of the
Scrutiny/ Re-Scrutiny Committee shall be placed before the Regional Committee for its
recommendation and further placed before the Executive Committee for approval or otherwise.d. In
case of new Technical Institutions, the Council if deems fit shall grant approval to issue the Letter of
Intent (LoI) for the given Academic Year, the same shall be valid for three Academic Years.Within
the validity period, after the establishment of Infrastructure facilities as per the requirements, the
Applicant shall apply on AICTE Web-Portal for the Letter of Approval anytime in the year. In case of
the Applicant expressing interest in getting Letter of Approval (LoA) in the current Academic YearAll India Council for Technical Education (Grant of Approvals for the Technical Institutions) Regulations, 2018

itself, the same shall be processed further by an Expert Visit Committee.Expert Visit Committee
formed by the Regional Officer as per the composition as mentioned in the Approval Process Hand
Book shall verify physically the availability of infrastructural facilities of the Institution.On expiry of
the validity, the Letter of Intent (LoI) issued stands cancelled and the Applicant shall make a fresh
application for the issuance of Letter of Intent (LoI).e. The recommendations of the Expert Visit
Committee shall be placed before the Regional Committee for its recommendation and further
placed before the Executive Committee for approval or otherwise.f. Regional Officer concerned
while forwarding the recommendations of the Regional Committee to Approval Bureau of AICTE,
for placing before the Executive Committee, shall verify that the processes and parameters
prescribed under these Regulations and Approval Process Handbook are followed by the Scrutiny
Committee, Re-Scrutiny Committee (if applicable), Expert Visit Committee and the Regional
Committee.The Approval Bureau of AICTE shall also verify that the processes and parameters
prescribed under these Regulations and Approval Process Handbook are followed by the Scrutiny
Committee, Re-Scrutiny Committee, Expert Visit Committee and the Regional Committee.g. The
decision of the Executive Committee shall be uploaded on the Web-Portal in the form of a Letter of
Intent (LoI)/ Letter of Approval (LoA) or Letter of Rejection (LoR) with the specific reasons for
rejection of the application.h. Applicants for starting new Technical Institutions (except
Government/ Government aided Institutions) whose applications are recommended for Letter of
Approval (LoA) by the Executive Committee shall be informed for depositing the Security
Deposit.The existing Institutions approved by the other Regulatory Bodies, applying for the first
time to the Council for approval and are in existence for more than 10 years are exempted from the
payment of Security Deposit.The Applicant shall submit the payment proof of the Security Deposit
along with an Affidavit within 7 days from the date of intimation to the concerned Regional Office,
else a penalty of 10% of the value of the Security Deposit shall be imposed upto 15th May of the
Calendar Year, beyond which the approval shall be withdrawn.i. The online Security Deposit amount
deposited by the Technical Institution with AICTE shall be permitted to be withdrawn after a term
of ten years or in case of closure of Course/ Institution, subject to the submission of relevant
documents. The interest accrued on the Security Deposit shall be credited to the Council and shall
be utilized by AICTE for Quality Improvement Programme for Faculty and giving scholarships to
students. However, the term of the Security Deposit could be extended for a further period as may
be decided on case to case basis and/or forfeited in case of any violation of norms, conditions and
requirements and/or Non-performance by the Institution and/or complaints against the
Institution.j. Validity of the Letter of Approval for the new Technical Institutions, if issued, shall be
for two Academic Years from the date of issue of Letter of Approval, only for obtaining affiliation
from the respective University/ Board and fulfilling State Government/ UT requirements for
admission in the current Academic Year.All the Applicants issued LoA for starting the new Technical
Institutions shall apply on AICTE Web-Portal for Extension of Approval as specified in the Approval
Process Handbook from the next Academic Year onwards, irrespective of the admission of the
students. However, the Institutions that fail to admit the students in the current Academic Year due
to Non-Affiliation by the University/ Board or Non-fulfillment of State Government/ UT
requirements are exempted from the payment of TER Charges.On expiry of the validity, the LoA
issued stands cancelled and the Applicant shall make a fresh application for the issuance of Letter of
Intent.k. New Institutions granted Letter of Approval and existing Institutions granted approval for
introduction of new Course(s), Division(s), Programme(s), variation in intake capacity shall complyAll India Council for Technical Education (Grant of Approvals for the Technical Institutions) Regulations, 2018

with appointment of Faculty and Principal/ Director as the case may be, as per the policy of the
Council.Institutions other than Minority Institutions shall appoint Faculty/ Principal/ Director and
other technical supporting staff and administrative staff strictly in accordance with the methods and
procedures of the concerned Affiliating University/ Board particularly in case of selection
procedures and selection Committees.The information about these appointments of staff in the
prescribed format shall be uploaded on the Web-Portal of AICTE.l. An Expert Visit Committee may
be conducted any time before the first batch of students have passed out, to verify the fulfillment of
the norms as specified in the Approval Process Handbook.6.3For the existing Institutionsa. For
applications submitted under Clause 1.2. f and s of these Regulations, the processing is based on
self-disclosure. The Council shall grant the desired approval, only after confirming that the
Applicant had fulfilled all the norms and standards prescribed in Approval Process Handbook. The
Council reserves the right to inspect and if any of the information submitted is found to be false,
shall initiate penal action as specified in the Approval Process Handbook.b. The applications
submitted under Clause 1.2. h, i, j, m, n, p, q, t, u, v, w and y of these Regulations shall be processed
by a Scrutiny/ Re-Scrutiny Committee based on the documents submitted by the Applicant.The
applications submitted under Clause 1.2. g, k, o and r of these Regulations shall be processed by an
Expert Visit Committee to verify the availability of the facilities in the Applicant Institutions.The
applications submitted under Clause 1.2. b, c, d, e, l and x of these Regulations shall be processed by
a Scrutiny/ Re-Scrutiny Committee based on the documents submitted by the Applicant. If the
documents are found in order, the same shall be processed further by an Expert Visit Committee to
verify the availability of the facilities in the Applicant Institutions.c. For Closure of Programme(s)/
Course(s), the Applicant shall submit the relevant NOCs at least before 31st December of the
Calendar Year.Applications of the existing Institutions who have applied for the Closure of
Institution, and if such applications are not approved by the Council due to certain deficiencies, the
Institution shall be given Extension of Approval (EoA) with ZERO Intake for that year. Such
Institutions shall submit all relevant documents after all the students have passed out or
redistributed to nearby AICTE approved Institutions and seek official closure of the Institution.The
application for the Closure of Institution shall be valid for the duration of the respective programme
offered by the Institution within which the Institution should submit the required mandatory
documents. Else, AICTE may close the Institution with the intimation to the Affiliating University/
Board and the State Government/ Union Territory and shall issue a Public Notice regarding the
same.d. Change in name of the Trust/ Society/ Company including merger of two or more Trust/
Society/ Company having the same common objects of education etc. shall be permitted as per the
respective Laws laid down in the Acts.A Trust/ Society may create a new Company to hold their
assets, and once the transfer of assets are complete, the Trust/ Society may be dissolved and the
ownership may be transferred to the Company. Such viability shall vary depending on the
jurisdiction and context.e. In case of the existing Institutions, if an EVC was conducted or Show
Cause notice was issued, the same shall be placed before the Standing Hearing Committee (SHC) as
applicable and processed as per the procedure specified in Approval Process Handbook.If the
Institution is aggrieved by the decision of the Executive Committee, the Institution shall have the
right to appeal once to the Council, as per the procedure specified in Approval Process
Handbook.6.4The uploading of the Scrutiny/ Re-Scrutiny Committee/ Expert Visit Committee
Report shall be done by the concerned Regional Office.6.5If any member of the Scrutiny/
Re-Scrutiny/ Expert Visit Committee is unable to attend or refuses or incapacitated to take part inAll India Council for Technical Education (Grant of Approvals for the Technical Institutions) Regulations, 2018

the Committee, then Regional Officer with prior or post-facto approval of the Member Secretary,
AICTE shall opt to choose another expert from the approved panel of the experts
manually.6.6Institution Deemed to be Universitya. The Council shall approve the Technical
Programme(s)/ Course(s) offered by the Universities including Institutions Deemed to be
Universities falling under Category I and II as notified by UGC. Such Institutions Deemed to be
Universities shall have to adhere to the norms and standards as specified by AICTE from time to
time and an Affidavit to this effect shall be submitted to AICTE and University Grants
Commission.The application submitted by an Institution Deemed to be University falling under
Category III as notified by UGC shall be processed as per the procedure mentioned in Clause 6.2/
6.3 (as applicable) of these Regulations.b. State University/ Central University/ Institution Deemed
to be University (Government)/ are not required to pay the Security Deposit.Institution Deemed to
be University (Private)/ Private Universities which were in existence for more than 10 years with
UGC are exempted from the payment of Security Deposit.Universities which were granted approval
from AICTE earlier as a Technical Institution and created Security Deposit and got released after the
maturity period are not required to pay the Security Deposit, else the University shall pay the
Security Deposit for the remaining period of 10 years, as applicable.6.7Vocational Education
CoursesThe applications for the introduction of Vocational Education Courses shall be processed as
per the procedure prescribed in the Approval Process Handbook and all other norms and standards
as notified in NSQF Regulations and SAMVAY from time to time.6.8The applications under 6.3 of
these Regulations shall be processed as per the procedure specified in Approval Process Handbook.
The consolidated list of all the Institutions with the "Approved Intake" shall be placed by the
Approval Bureau before the Executive Committee/ Council for the grant of Extension of Approval as
applicable for the Technical Institutions to continue to conduct Technical Programme(s) and
Course(s). The decisions taken by the Executive Committee are ratified by the Council.The same
shall be notified on the Web-Portal. Further the Institution shall download the Extension of
approval letter along with "Approved Intake" through the Institution login.All Orders shall be
uploaded by 30th April of the Calendar Year and the detailed speaking orders (in case of reduction
in intake, No Admission, etc.) shall be uploaded in the Web-Portal not later than15th May of the
Calendar Year.6.9The Council shall not grant any conditional approval to any
Institution.6.10Directorate of Technical Education/ State Government/ UT/ Affiliating University/
Board shall download the intakes for various Courses for the Institutions under their jurisdiction,
from Web-Portal through their login.6.11Student's eligibility for admission to all the Programmes
shall be as specified in the Approval Process Handbook and as per the reservation policy of the
Central Government/ respective State Government/ UT as the case may be.Provided that the Second
round of counselling/ admission for allotment of seats shall be completed on or before 10th July of
the Calendar Year. Last date upto which students can be admitted against vacancies arising due to
any reason (no student should be admitted to any Institution after the last date under any quota)
shall be 15th August of the Calendar Year.6.12Any Institution offering Technical Programme(s)/
Course(s) without approval of the Council shall be termed as unapproved Institution.
7. Appeal before Standing Appellate Committee.
- 7.1 An Institution/ Applicant, if aggrieved by the decision of Executive Committee shall have the
right to appeal once to the Council, within 7 days from the date of uploading of LoR. All the appealsAll India Council for Technical Education (Grant of Approvals for the Technical Institutions) Regulations, 2018

submitted by the Applicants/ Institutions shall be placed before the Standing Appellate Committee.
The final decision of the Council shall be uploaded on or before 30th April of the Calendar
Year.7.2An Officer of the Council shall place the records before the Standing Appellate Committee.
Two representatives of the Institution shall be invited to present their case along with the
compliance and supporting documents before the Standing Appellate Committee.7.3The
recommendations of Standing Appellate Committee shall be placed before the Council, whose
decision shall be final.7.4The decision of the Council about the grant of approval or otherwise shall
be communicated to the Applicant through Web-Portal on or before 30th April of Calendar Year,
with the reasons for rejection of the application.
8. Other Requirements to be fulfilled.
- 8.1 All Technical Institutions shall upload the information in respect of their Director/ Principal,
Faculty members and students admitted in each Course in the format available on the Web-Portal of
the Council and update the information from time to time. Scanned copies of PAN Card, Aadhaar
Card (if available) and Form 16 of all the faculty members shall also be uploaded on the
Web-Portal.8.2A Faculty/ Employee working on Full Time basis in an Institution/ Organization and
pursuing/ pursued any Full Time Course for the same duration as that of Regular Shift shall be
considered as invalid for the purpose of employment/ higher studies. However, the Faculty/
Employee shall pursue a Course as Part Time for longer duration, in the same City.8.3The
Institutions shall adopt the minimum standards and qualifications as specified in Approval Process
Handbook. However, Institutions Deemed to be Universities/ Institutions having Accreditation/
Autonomy status shall surpass the minimum standard and qualifications specified.8.4The
Applicants are expected to provide the Council true and complete information and documents
required for various purposes. If the information given and/or the documents provided to the
Council are found to be false, incomplete and/or the Applicants have failed to disclose factual
information and/or suppressed/ misrepresented the information, the Council shall initiate action
including Withdrawal of Approval/ any other action as deemed necessary against the Applicants.If
any document submitted is found to be fraudulent, criminal case shall be filed against the Principal
of the Institution and the Chairman/ Secretary of the Trust/ Society/ Company.8.5AICTE shall also
conduct inspections from time to time with or without notifying the dates, in such cases where
specific complaints of falsification of documents, misrepresentation, violation of norms of
standards, malpractices, etc. are received.Institutions at random would be subjected to surprise
inspection for the fulfillment of the norms of Approval Process Handbook and appropriate action
including Withdrawal of Approval and any other action deemed necessary, shall be initiated against
the Applicants, as the case may be.8.6In the event of denial of Extension of Approval for the existing
Courses or grant of Extension of Approval as per the Clauses 8.4 and 8.5 of these Regulations, such
Institutions shall not be considered for Extension of Approval till such proceedings are settled and
the Promoters/ Institutions are cleared of the charges of violations.8.7For the Institutions, whose
Programmes/ Courses have been discontinued by the Council or approval is withdrawn/ suspended,
the concerned State Government/ UT shall redistribute the students to other nearby AICTE
approved Technical Institutions affiliated to the University/ Board and the Council shall allow
supernumerary seats in such Institutions to accommodate the redistributed students appropriately
till they complete the Programmes/ Courses.All India Council for Technical Education (Grant of Approvals for the Technical Institutions) Regulations, 2018

9. Action in case of violation of Regulations.
- 9.1 An Institution running any technical Programme in violation of these Regulations shall be
liable for initiation of legal action including Withdrawal of Approval, if any, and/or legal criminal
action by the Council against the Institution and/or its Promoter Trust/ Society/ Company and
individuals associated, as the case may be.9.2If any Technical Institution contravenes any of the
provisions of relevant Regulations, the Council after making appropriate inquiry through Standing
Hearing Committee (SHC) and after providing an opportunity of being heard through the Standing
Appellate Committee (SAC) shall withdraw the approval granted. In case of Withdrawal of Approval
to the Institution, the Technical Institution/ Trust/ Society/ Company shall apply afresh for
approval after completion of two Academic Years for setting up a new Institution as per the
procedure defined in the Approval Process Handbook.9.3In case of any litigation pertaining to the
penal action initiated by the Council for an Institution, for the contravention of any of the relevant
Regulations, such Institution shall have to apply as specified in the Approval Process Handbook, as
applicable in the next Academic Year in AICTE Web-Portal, in the absence of any specific court
order to the contrary.9.4Non-Submission/ Submission of incomplete application for Extension of
ApprovalNon-submission/ submission of incomplete/ submission of false information, while
applying for Extension of Approval shall invite appropriate penal action against the Institution. The
Institution shall be liable to any one or more of the following punitive actions by the Council:•
Suspension of approval for NRI and supernumerary seats for one Academic Year• Reduction in
"Approved Intake"• No admission in one/ more Course(s) for one Academic Year• Withdrawal of
approval for Programme(s)/ Course(s)• Withdrawal of approval of the
Institution9.5Non-Fulfillment of the requirement of qualified Principal/ DirectorAn Institution not
having qualified Principal/ Director for a period, more than 12 months, shall be liable to any one or
more of the following punitive actions by the Council till the regular Principal/ Director is
appointed:• Reduction in "Approved Intake"• No admission for one Academic
Year9.6Non-Fulfillment of Faculty: Student ratio, not adhering to the pay scales and/or
qualifications prescribed for FacultyInstitutions not adhering to the pay scales, or qualifications
prescribed for Faculty members for more than 12 months and not maintaining prescribed Faculty:
Student ratio shall be liable to any one or more of the following punitive actions by the Council:•
Suspension of approval for NRI and supernumerary seats for one Academic Year• Reduction in
"Approved Intake"• No admission in respective Course(s) for one Academic Year• Withdrawal of
approval in the respective Course(s)• Withdrawal of approval of the InstitutionThe Council may
initiate penal action for not regularizing and ensuring the timely and full payment of the salary of
the Staffs through Electronic Clearing Service (ECS) by nationalized banks.9.7Non-Fulfillment in
Computer, Software, Internet, Printers, Laboratory Equipment, Books, Journals and Library
facilities requirements, etc.Institutions not maintaining prescribed requirements of Computer,
Software, Internet, Printers, Laboratory Equipment, Books, Journals and Library facilities, etc. shall
be liable to any one or more of the following punitive actions by the Council:• Suspension of
approval for NRI and supernumerary seats for one Academic Year• Reduction in "Approved Intake"•
No admission in one/ more Course(s) for one Academic Year• Withdrawal of approval for
Programme(s)/ Course(s)• Withdrawal of approval of the Institution9.8Non-Fulfillment of Essential
requirements for Technical InstitutionInstitutions not maintaining essential requirements as per
the Approval Process Handbook shall be liable to any one or more of the following punitive actionsAll India Council for Technical Education (Grant of Approvals for the Technical Institutions) Regulations, 2018

by the Council:• Suspension of approval for NRI and supernumerary seats for one Academic Year•
Reduction in "Approved Intake"• No admission in one/ more Course(s) for one Academic
Year9.9Non-Fulfillment of Location/ Built-up Area/ Land at the time of year of establishment or
current Academic YearInstitutions working in temporary location or at location not approved by the
Council and Institutions not fulfilling prescribed Built-up area requirements shall be liable to any
one or more of the following punitive actions by the Council:• Suspension of approval for NRI and
supernumerary seats for one Academic Year• Reduction in "Approved Intake"• No admission in
one/ more Course(s) for one Academic Year• Withdrawal of approval for Programme(s)/ Course(s)•
Withdrawal of approval of the Institution9.10Non-Adhering to the timing/ Faculty requirement for
the Second ShiftThe Second Shift shall have to be run as per the declared timings from 12 Noon to 7
pm with 50% additional Faculty, which would be subject to surprise inspection leading to Closure of
Course in case timings are not being followed/ with insufficient Faculty.9.11Excess admissionExcess
admission over the "Approved Intake" shall not be allowed under any circumstances. In case any
excess admission is reported to/ noted by the Council, appropriate penal action shall be initiated
against the Institution. The Institution shall be liable to any one more of the following punitive
actions by the Council:• Five times the total fees collected per student shall be levied against each
excess admission• Suspension of approval for NRI and supernumerary seats, if any for one
Academic Year• Reduction in "Approved Intake"• No admission in one/ more Course(s) for one
Academic Year• Withdrawal of approval for Programme(s)/ Course(s)• Withdrawal of approval of
the Institution9.12Charging excess fee than the fee prescribed by the concerned State/ Fee
Regulatory CommitteeThe Institutions shall have to announce all fees such as tuition fee,
examination fee etc. on their Web Site transparently and adhere to the same strictly. No Technical
Institution shall collect any other fee (Payment/ Amount) from the students, in addition to the fee
fixed by the State/ Fee Regulatory Committee. If any Institution does not follow the said guidelines,
the Institution shall be liable to any one or more of the following punitive actions by the Council:•
Twice the total fee collected per student and the excess fee collected shall be refunded to the
student• Suspension of approval for NRI and supernumerary seats, if any for one Academic Year•
Reduction in "Approved Intake"• No admission in one/ more Course(s) for one Academic Year•
Withdrawal of approval for Programme(s)/ Course(s)• Withdrawal of approval of the
Institution9.13Institutions not allowing Expert Visit Committee for physical verification of
Infrastructural facilities/ Institutions not having Occupancy Certificate/ Completion Certificate/
Building License/ Form D/ Barrier free environment/ PGDM Institutions not having NAD or not
uploading student enrollment data to the Council/ Institutions demanding for the Original Degree
Certificates from the Faculty members at the time of joining the InstitutionInstitutions not allowing
Expert Visit Committee for physical verification of Infrastructural facilities/ Institutions not having
Occupancy Certificate/ Completion Certificate/ Building License/ Form D/ Barrier free
environment/ PGDM Institutions not having NAD or not uploading student enrollment data in the
AICTE Web-Portal/ Institutions demanding for the Original Degree Certificates from the Faculty
members at the time of joining the Institution shall be liable for any one or more of the following
punitive actions by the Council:• No admission for one Academic Year• Withdrawal of approval of
the Institution9.14Violation of norms in case of Collaboration and Twinning Programmesa. If a
Foreign University/ Institution fails to comply with any of the conditions as contained in the
Approval Process Handbook, the Council after giving reasonable opportunity of being heard through
Standing Appellate Committee shall withdraw the approval of the Twinning Programme granted toAll India Council for Technical Education (Grant of Approvals for the Technical Institutions) Regulations, 2018

such University/ Institution to offer their Diploma/ Post Diploma Certificate/ Under Graduate
Degree/ Post Graduate Diploma/ Post Graduate Degree in India and forbid such Foreign
University/ Institution to either open Centres or enter into any Collaborative arrangement with any
University/ Institution in India.b. The Council shall also inform the concerned agencies including
Ministry of External Affairs, Ministry of Home Affairs, RBI of such decisions and advise these
agencies to take any or all of the following measures:• Refusal/ withdrawal for grant of visa to
employees/ teachers of the said Foreign University/ Institution.• Stop repatriation of funds from
India to home Country.• Informing the Public about the withdrawal of approval of the Twinning
Programme with Foreign University/ Institution and the consequence thereof.c. In case, it comes to
the notice of the Council, that a Foreign University is running Diploma/ Post Diploma Certificate/
Under Graduate Degree/ Post Graduate Diploma/ Post Graduate Degree Level Programme in
Technical Education in India directly or in Collaboration with an Indian Partner without obtaining
approval, the Council shall initiate immediate action under the Indian Penal Code for Criminal
breach of Trust, misconduct, fraud, cheating, etc.d. Once the approval of the Twinning Programme
is withdrawn, the Council shall make an attempt in co-ordination with concerned State
Government/ UT to re-allocate the students enrolled in such Programme to other approved
Institutions of the Council. The Institution shall have to return the entire fee collected from such
students to the Institutions in which the students are accommodated.e. Such Foreign University/
Institution shall not be allowed to collaborate with any other Centre/ Institution or enter into a
Collaborative arrangement in India for at least next 3 years.9.15Refund casesa. In the event of a
student withdrawing before the start of the Course, the entire fee collected from the student, after a
deduction of the processing fee of not more than L 1000/- (Rupees One Thousand only) shall be
refunded by the Institution. It would not be permissible for Institutions to retain the School/
Institution Leaving Certificates in original.b. In case, if a student leaves after joining the Course and
if the vacated seat is consequently filled by another student by the last date of admission, the
Institution must refund the fee collected after a deduction of the processing fee of not more than L
1000/- (Rupees One Thousand only) and proportionate deductions of monthly fees and hostel rent,
where applicable.c. The last date for withdrawal of PGDM admission for the purpose of refund of
fees shall be 30th June of every year.d. In case the vacated seat is not filled, the Institution should
refund the Security Deposit and return the original documents.e. The Institution should not demand
fee for the subsequent years from the students cancelling their admission at any point of time. Fee
refund along with the return of Certificates should be completed within 7 days.f. Institutions not
following guidelines issued by the Council regarding refund of fee for cancellation of admission or
delaying refunds shall be liable to any one or more of the following punitive actions by the Council:•
Fine for Non-compliance of refund rules of the fee levied against each case shall be five times the
total fee collected per student• Suspension of approval for NRI and supernumerary seats, if any, for
one Academic Year• Reduction in "Approved Intake"• No admission in one/ more Course(s) for one
Academic Year• Withdrawal of approval for Programme(s)/ Course(s)9.16In case of Institutions
where FDRs are encashed before the date of maturity or not depositing the required Security
Deposit at the time of LoA, a penalty of 10% of the value of the FDR shall be imposed. However,
Institutions that had not created FDR/created FDR for lesser duration/ lesser amount than
prescribed at the time of LoA have to create the same accordingly as specified in Approval Process
Handbook.9.17Penalty amount shall be paid online to the Council as per the instructions.9.18If any
of the information mentioned in the Affidavit is proved as false, legal action including penal actionAll India Council for Technical Education (Grant of Approvals for the Technical Institutions) Regulations, 2018

shall be initiated on the deponent.9.19Procedure for restoration against punitive action except in
case of Withdrawal of ApprovalInstitutions shall have to make an application for restoration of
intake and the same shall be processed as specified in the Approval Process Handbook.
10. Release of Security Deposit.
- The Trust/ Society/ Company shall apply online and upload/ submit the relevant documents in
AICTE Web-Portal for the release of the Security Deposit and the same shall be processed as per the
procedure specified in Approval Process Handbook.
11. Complaint Cases.
- In case of receipt of any complaint(s) about an Institution, the same shall be processed by Public
Grievance Redressal Cell (PGRC), AICTE.The complaint shall be placed before a Standing
Complaint Scrutiny Committee (SCSC) and the Complainant may be called (at his/ her own cost), if
necessary. Based on the recommendation of SCSC, a warning or Show Cause Notice may be issued
to the Institution or EVC may be conducted and processed further as per 6.3.e of these Regulations.
If necessary, the complainant may be called to appear before Standing Hearing Committee at his/
her own cost.As per CVC guidelines Anonymous/ Pseudonymous complaints shall not be processed.
12. Implementation of punitive action.
- Under extraordinary circumstances, if Punitive action (except fine) is approved by the Council
beyond 30th April of the Calendar year, the same shall be implemented for the next Academic Year
only.
13. Power delegated to Chairman of AICTE.
- Council has delegated the power to the Chairman of AICTE for taking decision on urgent matters
that needs to be communicated to the Institutions in between period of two Executive Committee/
Council meetings. However, such cases shall be placed before the next Executive Committee/
Council for ratification.
14. Charges for conducting an additional Scrutiny/ Expert Visit Committee.
- In extraordinary circumstances, if an additional Scrutiny/ Expert Visit Committee is to be
conducted inclusive of the Court directions to any type of Institutions, the Applicant has to pay the
fee as specified in the Approval Process Handbook.
15. Time Limit for the grant of LoA/ EoA.
- LoA/ EoA shall not be granted after 30th April of every Calendar Year in view of the order dated
13.12.2012 passed by the Hon'ble Supreme Court of India in CA no.9048/2012 titled as ParsvanathAll India Council for Technical Education (Grant of Approvals for the Technical Institutions) Regulations, 2018

Charitable Trust and others Vs AICTE and Ors.In case, the deficiencies are complied with
subsequently during the Academic Year, the approval shall be granted under extraordinary
circumstances, for the next Academic Year.
16. Social responsibility.
- As a part of discharging social responsibilities, all Technical Institutions approved by the Council
are expected to conduct National Skill Qualification Framework (NSQF) complied skill development
Courses to give training to a minimum of 100 students per year. These Programmes shall be based
on the needs of the local community where the Institution is located.
17. Conduct of any other Skill Development Courses.
- The Institutions may conduct Skill Development Courses of any other Regulatory Body by using
existing facilities, or by creating additional facilities as per the provisions laid down in the norms
and standards of the respective Regulatory Bodies without affecting the quality of education
prescribed by both the Regulatory Bodies after taking NOC from the Council. In such cases, a
Scrutiny Committee shall be conducted for the issue of NOC.
18. Interpretation.
- Any question arising out of the interpretation of these Regulations shall be decided by the Council
and the decision of the Council shall be binding and final.
19. Power to relax.
- The Council shall in exceptional cases, for removal of any hardship or in the national interest or
such other reasons to be recorded in writing, relax any of the provisions of these Regulations in
respect of any class or category of Institutions.All India Council for Technical Education (Grant of Approvals for the Technical Institutions) Regulations, 2018

