Foreign Exchange Management (Transfer or Issue of Security by
a Person Resident Outside India) Regulations, 2017
UNION OF INDIA
India
Foreign Exchange Management (Transfer or Issue of
Security by a Person Resident Outside India)
Regulations, 2017
Rule
FOREIGN-EXCHANGE-MANAGEMENT-TRANSFER-OR-ISSUE-OF-SECURITY-BY-A-PERSON-RESIDENT-OUTSIDE-INDIA-REGULATIONS-2017
of 2017
Published on 7 November 2017• 
Commenced on 7 November 2017• 
[This is the version of this document from 7 November 2017.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
Foreign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India)
Regulations, 2017Published vide Notification No. G.S.R. 1374(E), dated 7th November, 2017Note
Superseded by Foreign Exchange Management (Transfer or issue of Security by a Person Resident
outside India) Regulations, 2000Notification No. FEMA 20/2000-RB and Notification No. FEMA
24/2000-RB, both dated May 3, 2000Last Updated 24th April, 2019Reserve Bank of India(Foreign
Exchange Department)(Central Office)No. FEMA 20(R)/ 2017-RBG.S.R. 1374(E). - In exercise of
the powers conferred by clause (b) of sub-section (3) of section 6 and section 47 of the Foreign
Exchange Management Act, 1999 (42 of 1999) and in supersession of Notification No. FEMA
20/2000-RB and Notification No. FEMA 24/2000-RB both dated May 3, 2000, as amended from
time to time, the Reserve Bank makes the following regulations to regulate investment in India by a
Person Resident Outside India, namely:-
1. Short title and commencement.
(1)These Regulations may be called the Foreign Exchange Management (Transfer or Issue of
Security by a Person Resident outside India) Regulations, 2017.(2)They shall come into effect from
the date of their publication in the Official Gazette except proviso (ii) to sub-regulation 1 of
regulation 10 of these Regulations and proviso (ii) to sub-regulation 2 of regulation 10 of these
Regulations which will come into effect from a date to be notified.Foreign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

2. Definitions.
- In these Regulations, unless the context requires otherwise,-(i)'Act' means the Foreign Exchange
Management Act, 1999 (42 of 1999);(ii)'Asset Reconstruction Company' (ARC) means a company
registered with the Reserve Bank under section 3 of the Securitisation and Reconstruction of
Financial Assets and Enforcement of Security Interest Act, 2002 (SARFAESI Act);(iii)'Authorised
bank' will have the same meaning as assigned to it in Foreign Exchange Management (Deposit)
Regulations, 2016;(iv)'Authorised dealer' includes a person authorised under sub-section (1) of
section 10 of the Act;(v)'Capital Instruments' means equity shares, debentures, preference shares
and share warrants issued by an Indian company;Explanation:(a)Equity shares issued in accordance
with the provisions of the Companies Act, 2013 shall include equity shares that have been partly
paid. The expression 'Debentures' means fully, compulsorily and mandatorily convertible
debentures. 'Preference shares' means fully, compulsorily and mandatorily convertible preference
shares. Share Warrants are those issued by an Indian Company in accordance with the Regulations
issued by the Securities and Exchange Board of India. Capital instruments can contain an
optionality clause subject to a minimum lock-in period of one year or as prescribed for the specific
sector, whichever is higher, but without any option or right to exit at an assured price.(b)Partly paid
shares that have been issued to a person resident outside India shall be fully called-up within twelve
months of such issue. Twenty five percent of the total consideration amount (including share
premium, if any), shall be received upfront.(c)In case of share warrants at least twenty five percent
of the consideration shall be received upfront and the balance amount within eighteen months of
issuance of share warrants.(d)Capital instruments shall include non-convertible/ optionally
convertible/ partially convertible preference shares issued as on and up to April 30, 2007 and
optionally convertible/ partially convertible debentures issued up to June 7, 2007 till their original
maturity. Non-convertible/ optionally convertible/ partially convertible preference shares issued
after April 30, 2007 shall be treated as debt and shall conform to External Commercial Borrowings
guidelines regulated under Foreign Exchange Management (Borrowing and Lending in Foreign
Exchange) Regulations, 2000.(vi)'Convertible Note' means an instrument issued by a startup
company evidencing receipt of money initially as debt, which is repayable at the option of the
holder, or which is convertible into such number of equity shares of such startup company, within a
period not exceeding five years from the date of issue of the convertible note, upon occurrence of
specified events as per the other terms and conditions agreed to and indicated in the
instrument;(vii)'Domestic Custodian' means a custodian of securities, an Indian Depository, a
Depository Participant, or a bank and having permission from Securities and Exchange Board of
India to provide services as custodian;(viii)'Domestic Depository' means a custodian of securities
registered with the Securities and Exchange Board of India and authorised by the issuing entity to
issue Indian Depository Receipts;(ix)'Depository Receipt' means a foreign currency denominated
instrument, whether listed on an international exchange or not, issued by a foreign depository in a
permissible jurisdiction on the back of eligible securities issued or transferred to that foreign
depository and deposited with a domestic custodian and includes 'global depository receipt' as
defined in the Companies Act, 2013;(x)'Employees' stock option' (ESOP) means an ESOP as defined
under the Companies Act, 2013 and issued under the regulations issued by the Securities and
Exchange Board of India;(xi)'Escrow account' means an Escrow account maintained in accordance
with Foreign Exchange Management (Deposit) Regulations, 2016;(xii)'FDI linked performanceForeign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

conditions' means the sector specific conditions stipulated in regulation 16 of these Regulations for
companies receiving foreign investment;(xiii)'Foreign Venture Capital Investor' (FVCI) means an
investor incorporated and established outside India and registered with Securities and Exchange
Board of India under Securities and Exchange Board of India (Foreign Venture Capital Investors)
Regulations, 2000;(xiv)'Foreign Central Bank' means an institution/ organisation/ body corporate
established in a Country outside India and entrusted with the responsibility of carrying out central
bank functions under the law for the time being in force in that country;(xv)'FCNR (B) account'
means a Foreign Currency Non-Resident (Bank) account maintained in accordance with the Foreign
Exchange Management (Deposit) Regulations, 2016;(xvi)'Foreign Currency Convertible Bond
(FCCB)' means a bond issued under the Issue of Foreign Currency Convertible Bonds and Ordinary
Shares (Through Depository Receipt Mechanism) Scheme, 1993;(xvii)'Foreign Direct Investment'
(FDI) means investment through capital instruments by a person resident outside India in an
unlisted Indian company; or in 10 percent or more of the post issue paid-up equity capital on a fully
diluted basis of a listed Indian company; Note: In case an existing investment by a person resident
outside India in capital instruments of a listed Indian company falls to a level below 10 percent of
the post issue paid-up equity capital on a fully diluted basis, the investment shall continue to be
treated as FDI. Explanation: Fully diluted basis means the total number of shares that would be
outstanding if all possible sources of conversion are exercised(xviii)'Foreign Investment' means any
investment made by a person resident outside India on a repatriable basis in capital instruments of
an Indian company or to the capital of an LLP;Explanation: If a declaration is made by persons as
per the provisions of the Companies Act, 2013 about a beneficial interest being held by a person
resident outside India, then even though the investment may be made by a resident Indian citizen,
the same shall be counted as foreign investment.Note: A person resident outside India may hold
foreign investment either as Foreign Direct Investment or as Foreign Portfolio Investment in any
particular Indian company.(xix)'Foreign Portfolio Investment' means any investment made by a
person resident outside India through capital instruments where such investment is less than 10
percent of the post issue paid-up share capital on a fully diluted basis of a listed Indian company or
less than 10 percent of the paid up value of each series of capital instruments of a listed Indian
company;Explanation: The 10 percent limit for foreign portfolio investors shall be applicable to each
foreign portfolio investor or an investor group as referred in Securities and Exchange Board of India
(Foreign Portfolio Investors) Regulations, 2014(xx)'Foreign Portfolio Investor (FPI)' means a person
registered in accordance with the provisions of Securities Exchange Board of India (Foreign
Portfolio Investors) Regulations, 2014.Explanation: Any Foreign Institutional Investor (FII) or a sub
account registered under the Securities Exchange Board of India (Foreign Institutional Investors)
Regulations, 1995 and holding a valid certificate of registration from Securities and Exchange Board
of India shall be deemed to be a FPI till the expiry of the block of three years from the enactment of
the Securities Exchange Board of India (FPI) Regulations, 2014.(xxi)'Government approval' means
approval from the erstwhile Secretariat for Industrial Assistance (SIA), Department of Industrial
Policy and Promotion, Government of India and/ or the erstwhile Foreign Investment Promotion
Board (FIPB) and/ or any of the ministry/ department of the Government of India as the case may
be;(xxii)'Group company' means two or more enterprises which, directly or indirectly, are in a
position to (a) exercise 26 percent, or more of voting rights in other enterprise; or (b) appoint more
than 50 percent, of members of board of directors in the other enterprise;(xxiii)'Indian company'
means a company incorporated in India and registered under the Companies Act, 2013;(xxiv)'IndianForeign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

Depository Receipts (IDRs)' means any instrument in the form of a depository receipt created by a
Domestic Depository in India and authorised by a company incorporated outside India making an
issue of such depository receipts;(xxv)'Indian entity' shall mean an Indian company or an
LLP;(xxvi)'Investing company' means an Indian company holding only investments in other Indian
companies directly or indirectly, other than for trading of such holdings/
securities;(xxvii)'Investment' means to subscribe, acquire, hold or transfer any security or unit
issued by a person resident in India;Explanation:(a)This will include to acquire, hold or transfer
depository receipts issued outside India, the underlying of which is a security issued by a person
resident in India.(b)For the purpose of LLP, investment shall mean capital contribution or
acquisition/ transfer of profit shares.(xxviii)'Investment on repatriation basis' means an investment,
the sale/ maturity proceeds of which are, net of taxes, eligible to be repatriated out of India, and the
expression 'Investment on nonrepatriation basis', shall be construed accordingly;(xxix)'Investment
Vehicle' means an entity registered and regulated under relevant regulations framed by Securities
and Exchange Board of India or any other authority designated for the purpose and shall include
Real Estate Investment Trusts (REITs) governed by the Securities and Exchange Board of India
(REITs) Regulations, 2014, Infrastructure Investment Trusts (InvIts) governed by the Securities and
Exchange Board of India (InvIts) Regulations, 2014 and Alternative Investment Funds (AIFs)
governed by the Securities and Exchange Board of India (AIFs) Regulations, 2012;(xxx)'Limited
Liability Partnership (LLP)' means a partnership formed and registered under the Limited Liability
Partnership Act, 2008;(xxxi)'Listed Indian Company' means an Indian company which has any of
its capital instruments listed on a recognized stock exchange in India and the expression 'Unlisted
Indian Company' shall be construed accordingly;(xxxii)'Manufacture', with its grammatical
variations, means a change in a non-living physical object or article or thing, (a) resulting in
transformation of the object or article or thing into a new and distinct object or article or thing
having a different name, character and use; or (b) bringing into existence of a new and distinct
object or article or thing with a different chemical composition or integral structure.(xxxiii)'NRE
account' means a Non-Resident External account maintained in accordance with the Foreign
Exchange Management (Deposit) Regulations, 2016;(xxxiv)'NRO account' means a Non-Resident
Ordinary account maintained in accordance with the Foreign Exchange Management (Deposit)
Regulations, 2016;(xxxv)'Non-Resident Indian (NRI)' means an individual resident outside India
who is citizen of India;(xxxvi)'Overseas Citizen of India (OCI)' means an individual resident outside
India who is registered as an Overseas Citizen of India Cardholder under Section 7(A) of the
Citizenship Act, 1955;(xxxvii)'Resident Indian citizen' means an individual who is a person resident
in India and is citizen of India by virtue of the Constitution of India or the Citizenship Act,
1955;(xxxviii)'Secretariat for Industrial Assistance' means Secretariat for Industrial Assistance in the
Department of Industrial Policy and Promotion, Ministry of Commerce and Industry, Government
of India;(xxxix)'Sectoral cap' means the maximum investment including both foreign investment on
a repatriation basis by persons resident outside India in capital instruments of a company or the
capital of an LLP, as the case may be, and indirect foreign investment, unless provided otherwise.
This shall be the composite limit for the Indian investee entity;Explanation:(a)FCCBs and DRs
having underlying of instruments being in the nature of debt shall not be included in the sectoral
cap.(b)Any equity holding by a person resident outside India resulting from conversion of any debt
instrument under any arrangement shall be reckoned under the sectoral cap.(xl)'SNRR account'
means a Special Non-Resident Rupee account maintained in accordance with the Foreign ExchangeForeign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

Management (Deposit) Regulations, 2016;(xli)'Startup' means an entity which complies with the
conditions laid down in Notification No. G.S.R 180(E) dated February 17, 2016 issued by
Department of Industrial Policy and Promotion, Ministry of Commerce and Industry, Government
of India;(xlii)'Startup company' means a private company incorporated under the Companies Act,
2013 and recognised as such in accordance with notification number G.S.R. 180(E) dated February
17, 2016 issued by the Department of Industrial Policy and Promotion, Ministry of Commerce and
Industry, Government of India and complies with the conditions laid down by it;(xliii)'Sweat equity
shares' means sweat equity shares as defined under the Companies Act, 2013;(xliv)'Transferable
Development Rights (TDR)' shall have the same meaning as assigned to it in the Regulations made
under sub-section (2) of section 6 of the Act;(xlv)'Unit' means beneficial interest of an investor in an
investment vehicle.(xlvi)'Venture Capital Fund' means a fund established in the form of a trust, a
company including a body corporate and registered under the Securities and Exchange Board of
India (Venture Capital Fund) Regulations, 1996;(xlvii)[ 'Municipal Bonds' mean debt instruments
issued by municipalities constituted under Article 243Q of the Constitution of India.] [Added by
Notification No. G.S.R. 312(E), dated 18.4.2019 (w.e.f. 7.11.2017).](xlviii)[] [Renumbered '(xlvii)' by
Notification No. G.S.R. 312(E), dated 18.4.2019 (w.e.f. 7.11.2017).] The words and expressions used
but not defined in these Regulations shall have the same meanings respectively assigned to them in
the Act.
3. Restriction on investment by a person resident outside India.
- Save as otherwise provided in the Act, or rules or regulations made thereunder, no person resident
outside India shall make any investment in India.Provided that an investment made in accordance
with the Act or the rules or the regulations framed thereunder and held on the date of
commencement of these Regulations, shall be deemed to have been made under these Regulations
and shall accordingly be governed by these Regulations.Provided further that the Reserve Bank may,
on an application made to it and for sufficient reasons, permit a person resident outside India to
make any investment in India subject to such conditions as may be considered necessary.
4. Restriction on receiving investment.
- Save as otherwise provided in the Act, or rules or regulations made thereunder, an Indian entity or
an investment vehicle, or a venture capital fund or a Firm or an Association of Persons or a
proprietary concern shall not receive any investment in India from a person resident outside India
or record such investment in its books.Provided that the Reserve Bank may, on an application made
to it and for sufficient reasons, permit an Indian entity or an investment vehicle, or a venture capital
fund or a Firm or an Association of Persons or a proprietary concern to receive any investment in
India from a person resident outside India or to record such investment subject to such conditions
as may be considered necessary.
5. Permission for making investment by a person resident outside India.
- Unless otherwise specified in these Regulations or the relevant Schedules, any investment made by
a person resident outside India shall be subject to the entry routes, sectoral caps or the investmentForeign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

limits, as the case may be, and the attendant conditionalities for such investment as laid down in
these Regulations. A person resident outside India may make investment as under:(1)A person
resident outside India may subscribe, purchase or sell capital instruments of an Indian company in
the manner and subject to the terms and conditions specified in Schedule 1.Provided that a person
who is a citizen of Bangladesh or Pakistan or is an entity incorporated in Bangladesh or Pakistan
cannot purchase capital instruments without the prior Government approval.Provided further, a
person who is a citizen of Pakistan or an entity incorporated in Pakistan can invest, only under the
Government route, in sectors/ activities other than defence, space, atomic energy and sectors/
activities prohibited for foreign investment.Note: Issue/ transfer of 'participating interest/ right' in
oil fields by Indian companies to a person resident outside India would be treated as foreign
investment and shall comply with the conditions laid down in Schedule 1.(2)A Foreign Portfolio
Investor (FPI) may purchase or sell capital instruments of a listed Indian company on a recognised
stock exchange in India in the manner and subject to the terms and conditions specified in Schedule
2.(3)A Non- Resident Indian or an Overseas Citizen of India may on repatriation basis purchase or
sell capital instruments of a listed Indian company on a recognised stock exchange in India, in the
manner and subject to the terms and conditions specified in Schedule 3.(4)A Non- Resident Indian
or an Overseas Citizen of India may, on non-repatriation basis, purchase or sell capital instruments
of an Indian company or purchase or sell units or contribute to the capital of a LLP or a firm or
proprietary concern, in the manner and subject to the terms and conditions specified in Schedule
4.(5)A person resident outside India, permitted for the purpose by the Reserve Bank in consultation
with Central Government, may purchase or sell securities other than capital instruments in the
manner and subject to the terms and conditions specified in Schedule 5.(5)[(a) A Foreign Portfolio
Investor or a Non-Resident Indian (NRI) or an Overseas Citizen of India (OCI) may trade or invest
in all exchange traded derivative contracts approved by Securities and Exchange Board of India
from time to time subject to the limits prescribed by Securities and Exchange Board of India and
conditions specified in Schedule 5 [Added by Notification No. G.S.R. 164(E), dated 26.2.2019 (w.e.f.
7.11.2017).](5)(b)A Foreign Portfolio Investor may enter into contract in any interest rate derivative
subject to conditions laid down by the Reserve Bank from time to time.][***] [Deleted 'Note: A
Foreign Portfolio Investor or a Non-Resident Indian (NRI) or an Overseas Citizen of India (OCI)
may trade or invest in all exchange traded derivative contracts approved by Securities and Exchange
Board of India from time to time subject to the limits prescribed by Securities and Exchange Board
of India and conditions specified in Schedule 5' by Notification No. G.S.R. 164(E), dated 26.2.2019
(w.e.f. 7.11.2017).](6)A person resident outside India, other than a citizen of Bangladesh or Pakistan
or an entity incorporated in Bangladesh or Pakistan, may invest, either by way of capital
contribution or by way of acquisition/ transfer of profit shares of an LLP, in the manner and subject
to the terms and conditions as specified in Schedule 6.(7)A Foreign Venture Capital Investor may
make investment in the manner and subject to the terms and conditions specified in Schedule 7.(8)A
person resident outside India, other than a citizen of Bangladesh or Pakistan or an entity
incorporated in Bangladesh or Pakistan, may invest in units of an Investment Vehicle, in the manner
and subject to the terms and conditions specified in Schedule 8.(9)A person resident outside India
may invest in the Depository Receipts (DRs) issued by foreign depositories against eligible securities
in the manner and subject to the terms and conditions as specified in Schedule 9.(10)A Foreign
Portfolio Investor or Non- Resident Indian or an Overseas Citizen of India may purchase, hold or
sell Indian Depository Receipts (IDRs) of companies resident outside India and issued in the IndianForeign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

capital market, in the manner and subject to the terms and conditions specified in Schedule 10.
6. Acquisition through a rights issue or a bonus issue.
- A person resident outside India and having investment in an Indian company may make
investment in capital instruments (other than share warrants) issued by such company as a rights
issue or a bonus issue provided that:(1)The offer made by the Indian company is in compliance with
the provisions of the Companies Act, 2013;(2)Such issue shall not result in a breach of the sectoral
cap applicable to the company;(3)The shareholding on the basis of which the rights issue or the
bonus issue has been made must have been acquired and held as per the provisions of these
Regulations;(4)In case of a listed Indian company, the rights issue to persons resident outside India
shall be at a price determined by the company;(5)In case of an unlisted Indian company, the rights
issue to persons resident outside India shall not be at a price less than the price offered to persons
resident in India.(6)Such investment made through rights issue or bonus issue shall be subject to
the conditions as are applicable at the time of such issue.(7)The amount of consideration shall be
paid as inward remittance from abroad through banking channels or out of funds held in NRE/
FCNR(B) account maintained in accordance with the Foreign Exchange Management (Deposit)
Regulations, 2016.Note: Where the original investment has been made on a non-repatriation basis,
the amount of consideration may also be paid by debit to the NRO account maintained in
accordance with the Foreign Exchange Management (Deposit) Regulations, 2016Provided an
individual who is a person resident outside India exercising a right which was issued when he/ she
was a person resident in India shall hold the capital instruments (other than share warrants) so
acquired on exercising the option on a non-repatriation basis.Explanation: The above conditions
shall also be applicable in case a person resident outside India makes investment in capital
instruments (other than share warrants) issued by an Indian company as a rights issue that are
renounced by the person to whom it was offered.
7. Issue of shares under Employees Stock Options Scheme to persons
resident outside India.
- An Indian company may issue "employees' stock option" and/ or "sweat equity shares" to its
employees/ directors or employees/ directors of its holding company or joint venture or wholly
owned overseas subsidiary/ subsidiaries who are resident outside India, provided that:(1)The
scheme has been drawn either in terms of regulations issued under the Securities and Exchange
Board of India Act, 1992 or the Companies (Share Capital and Debentures) Rules, 2014 notified by
the Central Government under the Companies Act 2013, as the case may be;(2)The "employee's
stock option"/ "sweat equity shares" so issued under the applicable rules/ regulations are in
compliance with the sectoral cap applicable to the said company;(3)Issue of "employee's stock
option"/ "sweat equity shares" in a company where investment by a person resident outside India is
under the approval route shall require prior Government approval. Issue of "employee's stock
option"/ "sweat equity shares" to a citizen of Bangladesh/ Pakistan shall require prior Government
approval.Provided an individual who is a person resident outside India exercising an option which
was issued when he/ she was a person resident in India shall hold the shares so acquired on
exercising the option on a non-repatriation basis.Foreign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

8. Issue of Convertible Notes by an Indian startup company.
(1)A person resident outside India (other than an individual who is citizen of Pakistan or Bangladesh
or an entity which is registered/ incorporated in Pakistan or Bangladesh), may purchase convertible
notes issued by an Indian startup company for an amount of twenty five lakh rupees or more in a
single tranche.(2)A startup company, engaged in a sector where investment by a person resident
outside India requires Government approval, may issue convertible notes to a person resident
outside India only with such approval. Further, issue of equity shares against such convertible notes
shall be in compliance with the entry route, sectoral caps, pricing guidelines and other attendant
conditions for foreign investment.(3)A startup company issuing convertible notes to a person
resident outside India shall receive the amount of consideration by inward remittance through
banking channels or by debit to the NRE/ FCNR (B)/ Escrow account maintained by the person
concerned in accordance with the Foreign Exchange Management (Deposit) Regulations, 2016.
Repayment or sale proceeds may be remitted outside India or credited to NRE/ FCNR (B) account
maintained by the person concerned in accordance with the Foreign Exchange Management
(Deposit) Regulations, 2016.(4)A NRI or an OCI may acquire convertible notes on non-repatriation
basis in accordance with Schedule 4 of these Regulations.(5)A person resident outside India may
acquire or transfer by way of sale, convertible notes, from or to, a person resident in or outside
India, provided the transfer takes place in accordance with the entry routes and pricing guidelines as
prescribed for capital instruments.
9. Merger or demerger or amalgamation of Indian companies.
(1)Where a Scheme of merger or amalgamation of two or more Indian companies or a
reconstruction by way of demerger or otherwise of an Indian company, has been approved by
National Company Law Tribunal (NCLT)/ Competent Authority, the transferee company or the new
company, as the case may be, may issue capital instruments to the existing holders of the transferor
company resident outside India, subject to the following conditions, namely:(a)The transfer or issue
is in compliance with the entry routes, sectoral caps or investment limits, as the case may be, and
the attendant conditionalities of investment by a person resident outside India;Provided that where
the percentage is likely to breach the Sectoral caps or the attendant conditionalities, the transferor
company or the transferee or new company may obtain necessary approvals from the Central
Government.(b)The transferor company or the transferee company or the new company shall not
engage in any sector prohibited for investment by a person resident outside India; and(2)Where a
Scheme of Arrangement for an Indian company has been approved by National Company Law
Tribunal (NCLT)/ Competent Authority , the Indian company may issue non-convertible
redeemable preference shares or non-convertible redeemable debentures out of its general reserves
by way of distribution as bonus to the shareholders resident outside India, subject to the following
conditions, namely:(a)the original investment made in the Indian company by a person resident
outside India is in accordance with these Regulations and the conditions specified in the relevant
Schedule;(b)the said issue is in accordance with the provisions of the Companies Act, 2013 and the
terms and conditions, if any, stipulated in the scheme approved by National Company Law Tribunal
(NCLT)/ Competent Authority have been complied with;(c)the Indian company shall not engage in
any activity/ sector in which investment by a person resident outside India is prohibited.Foreign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

10. Transfer of capital instruments of an Indian company by or to a person
resident outside India.
- A person resident outside India holding capital instruments of an Indian company or units in
accordance with these Regulations or a person resident in India, may transfer such capital
instruments or units so held by him in compliance with the conditions, if any, specified in the
respective Schedules of these Regulations and subject to the terms and conditions specified
hereunder;(1)A person resident outside India, not being a non-resident Indian or an overseas citizen
of India or an erstwhile overseas corporate body may transfer by way of sale or gift the capital
instruments of an Indian company or units held by him to any person resident outside
India;Explanation: It shall also include transfer of capital instruments of an Indian company
pursuant to liquidation, merger, de-merger and amalgamation of entities/ companies incorporated
or registered outside IndiaProvided that(i)prior Government approval shall be obtained for any
transfer in case the company is engaged in a sector which requires Government approval.(ii)where
the person resident outside India is an FPI and the acquisition of capital instruments made under
Schedule 2 of these regulations has resulted in a breach of the applicable aggregate FPI limits or
sectoral limits, the FPI shall sell such capital instruments to a person resident in India eligible to
hold such instruments within the time stipulated by Reserve Bank in consultation with the Central
Government. The breach of the said aggregate or sectoral limit on account of such acquisition for the
period between the acquisition and sale, provided the sale is within the prescribed time limit, shall
not be reckoned as a contravention under these Regulations. The guidelines issued by Securities and
Exchange Board of India in this regard shall be applicable.(2)An NRI or an OCI holding capital
instruments of an Indian company or units on repatriation basis may transfer the same by way of
sale or gift to any person resident outside India;Provided that(i)prior Government approval shall be
obtained for any transfer in case the company is engaged in a sector which requires Government
approval.(ii)where the acquisition of capital instruments by an NRI or an OCI under the provisions
of Schedule 3 of these regulations has resulted in a breach of the applicable aggregate NRI/ OCI
limit or sectoral limits, the NRI or the OCI shall sell such capital instruments to a person resident in
India eligible to hold such instruments within the time stipulated by Reserve Bank in consultation
with the Central Government. The breach of the said aggregate or sectoral limit on account of such
acquisition for the period between the acquisition and sale, provided the sale is within the
prescribed time, shall not be reckoned as a contravention under these Regulations.(3)A person
resident outside India, holding capital instruments of an Indian company or units in accordance
with these Regulations may transfer the same to a person resident in India by way of sale/ gift or
may sell the same on a recognised stock exchange in India in the manner prescribed by Securities
and Exchange Board of India;Provided that(i)the transfer by way of sale shall be in compliance with
and subject to the adherence to pricing guidelines, documentation and reporting requirements for
such transfers as may be specified by Reserve Bank from time to time;(ii)where the capital
instruments are held by the person resident outside India on a non-repatriable basis, conditions at
proviso (i) above shall not apply(4)A person resident in India holding capital instruments of an
Indian company or units, or an NRI or an OCI or an eligible investor under Schedule 4 of these
Regulations, holding capital instruments of an Indian company or units on a non-repatriation basis,
may transfer the same to a person resident outside India by way of sale, subject to the adherence to
entry routes, sectoral caps/ investment limits, pricing guidelines and other attendant conditions asForeign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

applicable for investment by a person resident outside India and documentation and reporting
requirements for such transfers as may be specified by Reserve Bank from time to time; Provided
the entry routes, sectoral caps/ investment limits, pricing guidelines and other attendant conditions
shall not apply in case the transfer is to an NRI or an OCI or an eligible investor under Schedule 4 of
these Regulations acquiring such investment on non-repatriation basis.(5)A person resident in India
holding capital instruments or units of an Indian company or an NRI or an OCI an eligible investor
under Schedule 4 of these Regulations holding capital instruments or units of an Indian company on
a non-repatriation basis may transfer the same to a person resident outside India by way of gift with
the prior approval of the Reserve Bank, in the manner prescribed, and subject to the following
conditions:(a)The donee is eligible to hold such a security under relevant schedules of these
Regulations;(b)The gift does not exceed 5 percent of the paid up capital of the Indian company/
each series of debentures/ each mutual fund scheme;Explanation: The 5 percent will be on
cumulative basis by a single person to another single person(c)The applicable sectoral cap in the
Indian company is not breached;(d)The donor and the donee shall be 'relatives' within the meaning
in section 2(77) of the Companies Act, 2013;(e)The value of security to be transferred by the donor
together with any security transferred to any person residing outside India as gift during the
financial year does not exceed the rupee equivalent of USD50,000;(f)Such other conditions as
considered necessary in public interest by the Reserve Bank;(6)An NRI or an OCI or an eligible
investor under Schedule 4 of these Regulations holding capital instruments of an Indian company or
units on a non-repatriation basis, may transfer the same by way of gift to an NRI or an OCI or an
eligible investor under Schedule 4 of these Regulations who shall hold it on a non-repatriable
basis;(7)A person resident outside India holding capital instruments of an Indian company
containing an optionality clause in accordance with these Regulations and exercising the option/
right, may exit without any assured return, subject to the pricing guidelines prescribed in these
Regulations and a minimum lockin period of one year or minimum lock-in period as prescribed in
these Regulations, whichever is higher;(8)An erstwhile OCB may transfer capital instruments
subject to directions issued by the Reserve Bank from time to time in this regard.Explanation:
'Overseas Corporate Body (OCB)' means an entity derecognized through Foreign Exchange
Management [Withdrawal of General Permission to Overseas Corporate Bodies (OCBs)]
Regulations, 2003;(9)In case of transfer of capital instruments between a person resident in India
and a person resident outside India, an amount not exceeding twenty five percent of the total
consideration(a)can be paid by the buyer on a deferred basis within a period not exceeding eighteen
months from the date of the transfer agreement; or(b)can be settled through an escrow arrangement
between the buyer and the seller for a period not exceeding eighteen months from the date of the
transfer agreement; or(c)can be indemnified by the seller for a period not exceeding eighteen
months from the date of the payment of the full consideration, if the total consideration has been
paid by the buyer to the seller.Provided the total consideration finally paid for the shares shall be
compliant with the applicable pricing guidelines.(10)In case of transfer of capital instruments
between a person resident in India and a person resident outside India, a person resident outside
India may open an Escrow account in accordance with the Foreign Exchange Management (Deposit)
Regulations, 2016. Such Escrow account may be funded by way of inward remittance through
banking channels and/ or by way of guarantee issued by an authorized dealer bank, subject to terms
and conditions as specified in the Foreign Exchange Management (Guarantees) Regulations,
2000.(11)The pricing guidelines prescribed in these Regulations shall not be applicable for anyForeign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

transfer by way of sale done in accordance with Securities and Exchange Board of India regulations
where the pricing is prescribed by Securities and Exchange Board of India.(12)The transfer of capital
instruments of an Indian company or units of an Investment Vehicle by way of pledge is subject to
the following terms and conditions:(a)Any person being a promoter of a company registered in
India (borrowing company), which has raised external commercial borrowing (ECB) in compliance
with the Foreign Exchange Management (Borrowing and Lending in Foreign Exchange)
Regulations, 2000 may pledge the shares of the borrowing company or that of its associate resident
companies for the purpose of securing the external commercial borrowing (ECB) raised by the
borrowing company subject to the following conditions:(i)the period of such pledge shall be
co-terminus with the maturity of the underlying external commercial borrowing;(ii)in case of
invocation of pledge, transfer shall be in accordance with these Regulations and directions issued by
the Reserve Bank;(iii)the Statutory Auditor has certified that the borrowing company will utilise/
has utilised the proceeds of the external commercial borrowing for the permitted enduse/s
only;(iv)no person shall pledge any such share unless a no-objection has been obtained from an
Authorised Dealer bank that the above conditions have been complied with.(b)Any person resident
outside India holding capital instruments in an Indian company or units of an investment vehicle
may pledge the capital instruments or units, as the case may be:(i)in favour of a bank in India to
secure the credit facilities being extended to such Indian company for bona fide purposes,(ii)in
favour of an overseas bank to secure the credit facilities being extended to such person or a person
resident outside India who is the promoter of such Indian company or the overseas group company
of such Indian company,(iii)in favour of a Non-Banking Financial Company registered with the
Reserve Bank to secure the credit facilities being extended to such Indian company for bona fide
purposes,(iv)subject to the Authorised Dealer bank satisfying itself of the compliance of the
conditions stipulated by the Reserve Bank in this regard.(c)In case of invocation of pledge, transfer
of capital instruments of an Indian company or units shall be in accordance with entry routes,
sectoral caps/ investment limits, pricing guidelines and other attendant conditions at the time of
creation of pledge.
11. Pricing Guidelines.
- Unless otherwise specified in these Regulations or the relevant Schedules, the price of capital
instruments of an Indian company -(1)issued by such company to a person resident outside India
shall not be less than:(a)the price worked out in accordance with the relevant Securities and
Exchange Board of India guidelines in case of a listed Indian company or in case of a company going
through a delisting process as per the Securities and Exchange Board of India (Delisting of Equity
Shares) Regulations, 2009;(b)the valuation of capital instruments done as per any internationally
accepted pricing methodology for valuation on an arm's length basis duly certified by a Chartered
Accountant or a Securities and Exchange Board of India registered Merchant Banker or a practicing
Cost Accountant, in case of an unlisted Indian Company.Explanation: in case of convertible capital
instruments, the price/ conversion formula of the instrument should be determined upfront at the
time of issue of the instrument. The price at the time of conversion should not in any case be lower
than the fair value worked out, at the time of issuance of such instruments, in accordance with these
Regulations.(2)transferred from a person resident in India to a person resident outside India shall
not be less than:(a)the price worked out in accordance with the relevant Securities and ExchangeForeign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

Board of India guidelines in case of a listed Indian company;(b)the price at which a preferential
allotment of shares can be made under the Securities and Exchange Board of India Guidelines, as
applicable, in case of a listed Indian company or in case of a company going through a delisting
process as per the Securities and Exchange Board of India (Delisting of Equity Shares) regulations,
2009;(c)the valuation of capital instruments done as per any internationally accepted pricing
methodology for valuation on an arm's length basis duly certified by a Chartered Accountant or a
Securities and Exchange Board of India registered Merchant Banker or a practicing Cost
Accountant, in case of an unlisted Indian Company.(3)transferred by a person resident outside India
to a person resident in India shall not exceed:(a)the price worked out in accordance with the
relevant Securities and Exchange Board of India guidelines in case of a listed Indian company;(b)the
price at which a preferential allotment of shares can be made under the Securities and Exchange
Board of India Guidelines, as applicable, in case of a listed Indian company or in case of a company
going through a delisting process as per the Securities and Exchange Board of India (Delisting of
Equity Shares) regulations, 2009;Provided that the price is determined for such duration as
specified in the Securities and Exchange Board of India Guidelines, preceding the relevant date,
which shall be the date of purchase or sale of shares;(c)the valuation of capital instruments done as
per any internationally accepted pricing methodology for valuation on an arm's length basis duly
certified by a Chartered Accountant or a Securities and Exchange Board of India registered
Merchant Banker or a practicing Cost Accountant, in case of an unlisted Indian
Company.Explanation: The guiding principle would be that the person resident outside India is not
guaranteed any assured exit price at the time of making such investment/ agreement and shall exit
at the price prevailing at the time of exit.(4)in case of swap of capital instruments, subject to the
condition that irrespective of the amount, valuation involved in the swap arrangement will have to
be made by a Merchant Banker registered with Securities and Exchange Board of India or an
Investment Banker outside India registered with the appropriate regulatory authority in the host
country.(5)where shares in an Indian company are issued to a person resident outside India in
compliance with the provisions of the Companies Act, 2013, by way of subscription to Memorandum
of Association, such investments shall be made at face value subject to entry route and sectoral
caps.(6)in case of share warrants, their pricing and the price/ conversion formula shall be
determined upfront.Provided these pricing guidelines shall not be applicable for investment in
capital instruments by a person resident outside India on non-repatriation basis.
12. Taxes and Remittance of sale proceeds.
- 12.1 Taxes. - All transaction under these regulations shall be undertaken through banking channels
in India and subject to payment of applicable taxes and other duties/ levies in India.12.2Remittance
of sale proceeds. - (1) No remittance of sale proceeds of an Indian security held by a person resident
outside India shall be made otherwise than in accordance with these Regulations and the conditions
specified in the relevant Schedule.(2)An authorised dealer may allow the remittance of sale proceeds
of a security (net of applicable taxes) to the seller of shares resident outside India -Provided -(i)the
security was held by the seller on repatriation basis; and(ii)either the security has been sold in
compliance with the pricing guidelines or the Reserve Bank's approval has been obtained in other
cases for sale of the security and remittance of the sale proceeds thereof;Foreign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

13. Reporting requirements.
- 13.1. The reporting requirement for any Investment in India by a person resident outside India
shall be as follows:(1)[ ***.] [Deleted by Notification No. G.S.R. 823(E), dated 30.8.2018 (w.e.f.
7.11.2017).](2)Form Foreign Currency-Gross Provisional Return (FC-GPR): An Indian company
issuing capital instruments to a person resident outside India and where such issue is reckoned as
Foreign Direct Investment, for the purpose of these regulations, shall report such issue in Form
FC-GPR to the Regional Office concerned of the Reserve Bank under whose jurisdiction the
Registered office of the company operates, not later than thirty days from the date of issue of capital
instruments. Issue of 'participating interest/ rights' in oil fields shall be reported Form
FC-GPR.(3)Annual Return on Foreign Liabilities and Assets (FLA): An Indian company which has
received FDI or an LLP which has received investment by way of capital contribution in the previous
year(s) including the current year, should submit form FLA to the Reserve Bank on or before the
15th day of July of each year.Explanation: Year for this purpose shall be reckoned as April to
March.(4)Form Foreign Currency-Transfer of Shares (FC-TRS):(a)Form FCTRS shall be filed for
transfer of capital instruments in accordance with these Regulations between:(1)a person resident
outside India holding capital instruments in an Indian company on a repatriable basis and person
resident outside India holding capital instruments on a nonrepatriable basis; and(2)a person
resident outside India holding capital instruments in an Indian company on a repatriable basis and
a person resident in India,The onus of reporting shall be on the resident transferor/ transferee or
the person resident outside India holding capital instruments on a non-repatriable basis, as the case
may be.Note: Transfer of capital instruments in accordance with these Regulations by way of sale
between a person resident outside India holding capital instruments on a non-repatriable basis and
person resident in India is not required to be reported in Form FC-TRS.(b)Transfer of capital
instruments on a recognised stock exchange by a person resident outside India shall be reported by
such person in Form FC-TRS to the Authorised Dealer bank.(c)Transfer of capital instruments
prescribed in regulation 10(9), shall be reported in Form FC-TRS to the Authorised Dealer on
receipt of every tranche of payment. The onus of reporting shall be on the resident transferor/
transferee.(d)Transfer of 'participating interest/ rights' in oil fields shall be reported Form
FC-TRSThe form FCTRS shall be filed with the Authorised Dealer bank within sixty days of transfer
of capital instruments or receipt/ remittance of funds whichever is earlier.(5)Form Employees' Stock
Option (ESOP): An Indian company issuing employees' stock option to persons resident outside
India who are its employees/ directors or employees/ directors of its holding company/ joint
venture/ wholly owned overseas subsidiary/ subsidiaries shall submit Form-ESOP to the Regional
Office concerned of the Reserve Bank under whose jurisdiction the registered office of the company
operates, within 30 days from the date of issue of employees' stock option.(6)Form Depository
Receipt Return (DRR): The Domestic Custodian shall report in Form DRR, to the Reserve Bank, the
issue/ transfer of depository receipts issued in accordance with the Depository Receipt Scheme,
2014 within 30 days of close of the issue.(7)Form LLP (I): A Limited Liability Partnerships (LLP)
receiving amount of consideration for capital contribution and acquisition of profit shares shall
submit Form LLP (I) to the Regional Office of the Reserve Bank under whose jurisdiction the
Registered Office of the Limited Liability Partnership is situated, within 30 days from the date of
receipt of the amount of consideration(8)Form LLP (II): The disinvestment/ transfer of capital
contribution or profit share between a resident and a non-resident (or vice versa) shall be reportedForeign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

in Form LLP(II) to the Authorised Dealer Bank within 60 days from the date of receipt of
funds.(9)LEC(FII): The Authorised Dealer Category I banks shall report to the Reserve Bank in
Form LEC (FII) the purchase/ transfer of capital instruments by FPIs on the stock exchanges in
India.(10)LEC(NRI): The Authorised Dealer Category I banks shall report to the Reserve Bank in
Form LEC (NRI) the purchase/ transfer of capital instruments by Non-Resident Indians or Overseas
Citizens of India stock exchanges in India.(11)[ Downstream Investment : (i) An Indian entity or an
investment vehicle making downstream investment in another Indian entity which is considered as
indirect foreign investment for the investee Indian entity in terms of these Regulations, shall notify
the Secretariat for Industrial Assistance, DIPP within 30 days of such investment, even if capital
instruments have not been allotted, along with the modality of investment in new / existing ventures
(with / without expansion programme). [Substituted by Notification No. G.S.R. 823(E), dated
30.8.2018 (w.e.f. 7.11.2017).](ii)Form DI : An Indian entity or an investment Vehicle making
downstream investment in another Indian entity which is considered as indirect foreign investment
for the investee Indian entity in terms of Regulation 14 of these Regulations shall file Form DI with
the Reserve Bank within 30 days from the date of allotment of capital instruments.](12)Form
Convertible Notes (CN):(a)The Indian startup company issuing Convertible Notes to a person
resident outside India shall report such inflows to the Authorised Dealer bank in Form CN within 30
days of such issue.(b)A person resident in India, who may be a transferor or transferee of
Convertible Notes issued by an Indian startup company shall report such transfers to or from a
person resident outside India, as the case may be, in Form CN to the Authorised Dealer bank within
30 days of such transfer.(c)The Authorised Dealer bank shall submit consolidated statements to the
Reserve Bank. Provided, the format, periodicity and manner of submission of such reporting shall
be as prescribed by Reserve Bank in this regard.(13)[ Form InVi : An Investment vehicle which has
issued its units to a person resident outside India shall file Form InVi with the Reserve Bank within
30 days from the date of issue of units.] [Inserted by Notification No. G.S.R. 823(E), dated
30.8.2018 (w.e.f. 7.11.2017).]Provided further that unless otherwise specifically stated in these
regulations all reporting shall be made through or by an Authorised Dealer bank, as the case may
be.13.2Delays in reporting. - The person/ entity responsible for filing the reports provided in
regulation 13.1 above shall be liable for payment of late submission fee, as may be decided by the
Reserve Bank, in consultation with the Central Government, for any delays in reporting.
14. Downstream Investment.
(1)For the purpose of this regulation:(a)'Ownership of an Indian company' shall mean beneficial
holding of more than 50 percent of the capital instruments of such company. 'Ownership of an LLP'
shall mean contribution of more than 50 percent in its capital and having majority profit
share.(b)'Company owned by resident Indian citizens' shall mean an Indian company where
ownership is vested in resident Indian citizens and/ or Indian companies, which are ultimately
owned and controlled by resident Indian citizens. An 'LLP owned by resident Indian citizens' shall
mean an LLP where ownership is vested in resident Indian citizens and/ or Indian entities, which
are ultimately owned and controlled by resident Indian citizens.(c)'Company owned by persons
resident outside India' shall mean an Indian company that is owned by persons resident outside
India. An 'LLP owned by persons resident outside India' shall mean an LLP that is owned by persons
resident outside India.(d)'Control' shall mean the right to appoint majority of the directors or toForeign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

control the management or policy decisions including by virtue of their shareholding or
management rights or shareholders agreement or voting agreement. For the purpose of LLP,
'Control' shall mean the right to appoint majority of the designated partners, where such designated
partners, with specific exclusion to others, have control over all the policies of an LLP.(e)'Company
controlled by resident Indian citizens' means an Indian company, the control of which is vested in
resident Indian citizens and/ or Indian companies which are ultimately owned and controlled by
resident Indian citizens. An 'LLP controlled by resident Indian citizens' shall mean an LLP, the
control of which is vested in resident Indian citizens and/ or Indian entities, which are ultimately
owned and controlled by resident Indian citizens.(f)'Company controlled by persons resident
outside India' shall mean an Indian company that is controlled by persons resident outside India.
An 'LLP controlled by persons resident outside India' shall mean an LLP that is controlled by
persons resident outside India.(g)'Downstream Investment' shall mean investment made by an
Indian entity or an Investment Vehicle in the capital instruments or the capital, as the case may be,
of another Indian entity:(h)'Holding Company' shall have the same meaning as assigned to it under
Companies Act, 2013;(i)'Indirect Foreign Investment' means downstream investment received by an
Indian entity from:(i)another Indian entity (IE) which has received foreign investment and (i) the IE
is not owned and not controlled by resident Indian citizens or (ii) is owned or controlled by persons
resident outside India; or(ii)an investment vehicle whose sponsor or manager or investment
manager (i) is not owned and not controlled by resident Indian citizens or (ii) is owned or controlled
by persons resident outside IndiaProvided no person resident in India other than an Indian entity
can receive Indirect Foreign Investment.(j)'Total Foreign Investment' means the total of foreign
investment and indirect foreign investment and the same will be reckoned on a fully diluted
basis;(k)'Strategic downstream investment' means investment by banking companies incorporated
in India in their subsidiaries, joint ventures and associates.(2)Indian entity which has received
indirect foreign investment shall comply with the entry route, sectoral caps, pricing guidelines and
other attendant conditions as applicable for foreign investment.Explanation: Downstream
investment by an LLP not owned and not controlled by resident Indian citizens or owned or
controlled by persons resident outside India is allowed in an Indian company operating in sectors
where foreign investment up to 100 percent is permitted under automatic route and there are no
FDI linked performance conditions.(3)With effect from 31st day of July, 2012, downstream
investment/s made under Corporate Debt Restructuring (CDR), or other loan restructuring
mechanism, or in trading book, or for acquisition of shares due to defaults in loans, by a banking
company, as defined in clause (c) of section 5 of the Banking Regulation Act, 1949, incorporated in
India, which is not owned and not controlled by resident Indian citizens or owned or controlled by
persons resident outside India, shall not count towards indirect foreign investment. However, their
strategic downstream investment shall be counted towards indirect foreign investment for the
company in which such investment is being made.(4)Guidelines for calculating total foreign
investment in Indian companies:(a)Any equity holding by a person resident outside India resulting
from conversion of any debt instrument under any arrangement shall be reckoned for total foreign
investment;(b)FCCBs and DRs having underlying of instruments in the nature of debt, shall not be
reckoned for total foreign investment;(c)The methodology for calculating total foreign investment
would apply at every stage of investment in Indian companies and thus in each and every Indian
company;(d)For the purpose of downstream investment, the portfolio investment held as on March
31 of the previous financial year in the Indian company making the downstream investment shall beForeign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

considered for computing its total foreign investment;(e)The indirect foreign investment received by
a wholly owned subsidiary of an Indian company will be limited to the total foreign investment
received by the company making the downstream investment;(5)Downstream investment made into
Indian companies will be subject to the following conditions:(a)The downstream investment should
have the approval of the Board of Directors as also a Shareholders' Agreement, if any;(b)For the
purpose of downstream investment, the Indian entity making the downstream investment shall
bring in requisite funds from abroad and not use funds borrowed in the domestic markets.
Downstream investments can be made through internal accruals. For this purpose, internal accruals
will mean profits transferred to reserve account after payment of taxes.Further raising of debt and
its utilisation shall be in compliance with the Act, rules or regulations made thereunder.(c)Capital
instrument of an Indian company held by another Indian company which has received foreign
investment and is not owned and not controlled by resident Indian citizens or is owned or controlled
by persons resident outside India may be transferred to:(i)A person resident outside India, subject
to reporting requirements in Form FCTRS;(ii)A person resident in India subject to adherence to
pricing guidelines.(iii)An Indian company which has received foreign investment and is not owned
and not controlled by resident Indian citizens or owned or controlled by persons resident outside
India.(d)The first level Indian company making downstream investment shall be responsible for
ensuring compliance with the provisions of these regulations for the downstream investment made
by it at second level and so on and so forth. Such first level company shall obtain a certificate to this
effect from its statutory auditor on an annual basis. Such compliance of these regulations shall be
mentioned in the Director's report in the Annual Report of the Indian company. In case statutory
auditor has given a qualified report, the same shall be immediately brought to the notice of the
Regional Office of the Reserve Bank in whose jurisdiction the Registered Office of the company is
located and shall also obtain acknowledgement from the RO.(e)The provisions at (c) and (d) above
shall be construed accordingly for an LLP.Note: Downstream investment made in accordance with
the guidelines in existence prior to February 13, 2009 would not require any modification to
conform to these regulations. All other investments, after the said date, would come under the ambit
of these regulations. Downstream investments made between February 13, 2009 and June 21, 2013
which is not in conformity with these regulations should have been intimated to the Reserve Bank
by October 3, 2013 for treating such cases as compliant with these regulations.
15. Prohibited activities for investment by a person resident outside India.
- Unless otherwise specifically stated in the Act or the rules or regulations framed thereunder,
investment by a person resident outside India is prohibited in:(1)Lottery Business including
Government/ private lottery, online lotteries(2)Gambling and betting including casinos(3)Chit
funds.Explanation: The Registrar of Chits or an officer authorised by the state government in this
behalf, may, in consultation with the State Government concerned, permit any chit fund to accept
subscription from Nonresident Indians and Oveseas Citizens of India who shall be eligible to
subscribe, through banking channel and on non- repatriation basis, to such chit funds, without limit
subject to the conditions stipulated by the Reserve Bank of India from time to time(4)Nidhi
company(5)Trading in Transferable Development Rights (TDRs)(6)Real Estate Business or
Construction of Farm Houses.Explanation: For the purpose of this regulation, "real estate business"
shall not include development of townships, construction of residential /commercial premises,Foreign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

roads or bridges and Real Estate Investment Trusts (REITs) registered and regulated under the
SEBI (REITs) Regulations 2014.(7)Manufacturing of Cigars, cheroots, cigarillos and cigarettes, of
tobacco or of tobacco substitutes(8)Activities/ sectors not open to private sector investment e.g. (I)
Atomic energy and (II) Railway operations(9)Foreign technology collaboration in any form
including licensing for franchise, trademark, brand name, management contract is also prohibited
for Lottery Business and Gambling and Betting activities
16. Permitted sectors, entry routes and sectoral caps for total foreign
investment.
- Unless otherwise specified in these Regulations or the relevant Schedules the entry routes and
sectoral caps for the total foreign investment in an Indian entity shall be as follows:A. Entry
Routes(1)Automatic Route means the entry route through which investment by a person resident
outside India does not require the prior Reserve Bank approval or Government
approval.(2)Government Route means the entry route through which investment by a person
resident outside India requires prior Government approval. Foreign investment received under this
route shall be in accordance with the conditions stipulated by the Government in its
approval.(3)Aggregate Foreign Portfolio Investment up to 49 percent of the paid-up capital on a
fully diluted basis or the sectoral/ statutory cap, whichever is lower, will not require Government
approval or compliance of sectoral conditions as the case may be, if such investment does not result
in transfer of ownership and control of the resident Indian company from resident Indian citizens or
transfer of ownership or control to persons resident outside India. Other investments by a person
resident outside India will be subject to conditions of Government approval and compliance of
sectoral conditions as laid down in these regulations.B. Sectoral CapsSector-Specific Policy for Total
Foreign Investment(1)Sectoral cap for the following sectors/ activities is the limit indicated against
each sector. The total foreign investment shall not exceed the sectoral/ statutory cap.(2)Foreign
investment in the following sectors/ activities is, subject to applicable laws/ regulations, security
and other conditionalities(3)In sectors/ activities not listed below or not prohibited under
regulation 15 of these Regulations, foreign investment is permitted up to 100 percent on the
automatic route, subject to applicable laws/ regulations, security and other
conditionalities.Provided foreign investment in financial services other than those indicated under
serial number "F" below would require prior Government approval.(4)Wherever there is a
requirement of minimum capitalization, it shall include premium received along with the face value
of the capital instrument, only when it is received by the company upon issue of such instruments to
the person resident outside India. Amount paid by the transferee during post-issue transfer beyond
the issue price of the capital instrument, cannot be taken into account while calculating minimum
capitalization requirement.(5)[ (a) Foreign Investment in investing companies not registered as
Non-Banking Financial Companies with the Reserve Bank and in core investment companies
(CICs), both engaged in the activity of investing in the capital of other Indian entities, will require
prior Government approval. [Substituted by Notification No. G.S.R. 279(E), dated 26.3.2018 (w.e.f.
7.11.2017).]Note: Compliance to these Regulations by the core investment companies is in addition
to the compliance of the regulatory framework prescribed to such companies as NBFCs under the
Reserve Bank of India Act, 1934 and regulations framed thereunder.(b)Foreign investment in
investing companies registered as Non-Banking Financial Companies (NBFCs) with the ReserveForeign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

Bank, will be under 100% automatic route.](6)For undertaking activities which are under automatic
route and without FDI linked performance conditions, an Indian company which does not have any
operations and also has not made any downstream investment, may receive investment in its capital
instruments from persons resident outside India under automatic route. However, approval of the
Government will be required for such companies for undertaking activities which are under
Government route. As and when such a company commences business or makes downstream
investment, it will have to comply with the relevant sectoral conditions on entry route,
conditionalities and caps.(7)The onus of compliance with the sectoral/ statutory caps on such
foreign investment and attendant conditions, if any, shall be on the company receiving foreign
investment.(8)[ Wherever the person resident outside India who has made foreign investment
specifies a particular auditor/ audit firm having international network for the audit of the Indian
investee company, then audit of such investee company shall be carried out as joint audit wherein
one of the auditors is not part of the same network.] [Inserted by Notification No. G.S.R. 279(E),
dated 26.3.2018 (w.e.f. 7.11.2017).]
Sl. No Sector/ ActivitySectoral
CapEntry Route
1. Agriculture & Animal Husbandry   
1.1(a) Floriculture,Horticulture and Cultivation of vegetables &
mushrooms undercontrolled conditions;(b) Development
andproduction of seeds and planting material;(c) Animal
Husbandry(including breeding of dogs), Pisciculture,
Aquaculture andApiculture; and(d) Services related toagro
and allied sectors.Note: Other than the above, foreign
investmentis not allowed in any other agricultural sector/
activity.100% Automatic
1.2 Other Conditions   
 The term 'undercontrolled conditions' covers the
following:'Cultivation under controlled conditions' for
thecategories of Floriculture, Horticulture, Cultivation
ofvegetables and Mushrooms is the practice of cultivation
whereinrainfall, temperature, solar radiation, air humidity
and culturemedium are controlled artificially. Control in these
parametersmay be effected through protected cultivation
under green houses,net houses, poly houses or any other
improved infrastructurefacilities where micro-climatic
conditions are regulatedanthropogenically.
2. Plantation   
2.1(a) Tea sector includingtea plantations(b) Coffee
plantations(c) Rubber plantations(d) Cardamom
plantations(e) Palm oil treeplantations(f) Olive oil
treeplantationNote: Foreign investment is not allowed in
anyplantation sector/ activity other than those listed above.100% AutomaticForeign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

2.2 Other Conditions   
 Prior approval of the State Government concerned isrequired
in case of any future land use change.
3. Mining   
3.1Mining and Exploration of metal and non-metal oresincluding
diamond, gold, silver and precious ores but excludingtitanium
bearing minerals and its ores; subject to the Mines
andMinerals (Development & Regulation) Act, 1957.100% Automatic
3.2 Coal and Lignite   
 (a) Coal & Lignitemining for captive consumption by power
projects, iron &steel and cement units and other eligible
activities permittedunder and subject to the provisions of Coal
Mines(Nationalization) Act, 1973.(b) Setting up coal
processing plants likewasheries, subject to the condition that
the company shall not docoal mining and shall not sell washed
coal or sized coal from itscoal processing plants in the open
market and shall supply thewashed or sized coal to those
parties who are supplying raw coalto coal processing plants
for washing or sizing.100% Automatic
3.3Mining and mineral separation of titaniumbearing minerals
and ores, its value addition and integratedactivities
 (a) Mining and mineral separation of titaniumbearing
minerals & ores, its value addition and integratedactivities
subject to sectoral regulations and the Mines andMinerals
(Development and Regulation) Act, 1957.100% Government
3.4 Other Conditions   
 (a) Foreign investmentfor separation of titanium bearing
minerals & ores will besubject to the following conditions:(i)
Value additionfacilities are set up within India along with
transfer oftechnology;(ii) Disposal oftailings during the
mineral separation shall be carried out inaccordance with
regulations framed by the Atomic EnergyRegulatory Board
such as Atomic Energy (Radiation Protection)Rules, 2004 and
the Atomic Energy (Safe Disposal of RadioactiveWastes)
Rules, 1987.(b) Foreign investmentwill not be allowed in
mining of "prescribed substances"listed in the Notification No.
S.O. 61(E), dated 18.1.2006,issued by the Department of
Atomic Energy.Clarification:(i) For titanium bearingores such
as Ilmenite, Leucoxene and Rutile, manufacture oftitanium
dioxide pigment and titanium sponge constitutes
valueaddition. Ilmenite can be processed to produce Synthetic
Rutileor Titanium Slag as an intermediate value addedForeign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

product.(ii) The objective is to ensure that the rawmaterial
available in the country is utilized for setting updownstream
industries and the technology availableinternationally is also
made available for setting up suchindustries within the
country. Thus, if with the technologytransfer, the objective of
this regulation can be achieved, theconditions prescribed at
(a)(i) above shall be deemed to befulfilled.
4. Petroleum & Natural Gas
4.1Exploration activities of oil and natural gasfields,
infrastructure related to marketing of petroleum productsand
natural gas, marketing of natural gas and petroleum
products,petroleum product pipelines, natural gas/ pipelines,
LNGRegasification infrastructure, market study and
formulation andPetroleum refining in the private sector,
subject to the existingsectoral policy and regulatory
framework in the oil marketingsector and the policy of the
Government on private participationin exploration of oil and
the discovered fields of national oilcompanies.100% Automatic
4.2Petroleum refining by the Public SectorUndertakings (PSUs),
without any disinvestment or dilution ofdomestic equity in the
existing PSUs.49% Automatic
5. Manufacturing 100% Automatic
5.1A manufacturer ispermitted to sell its products manufactured
in India throughwholesale and/ or retail, including through
e-commerce withoutGovernment approval.Notwithstanding
the provisions of these regulationson trading sector, 100
percent foreign investment underGovernment approval route
is allowed for trading, includingthrough e-commerce, in
respect of food products manufactured and/or produced in
India. Applications for foreign investment in foodproducts
retail trading would be processed in the Department
ofIndustrial Policy & Promotion before being considered by
theGovernment for approval.
6. Defence   
6.1 Defence Industry subjectto Industrial license under the
Industries (Development &Regulation) Act, 1951;
andManufacturing of small arms and ammunition underthe
Arms Act, 1959100% Automatic route
up to 49%
Government
route beyond49%
wherever it is
likely to result in
access to
moderntechnology
or for otherForeign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

reasons to be
recorded.
6.2 Other Conditions
 (a) Fresh foreigninvestment within the permitted automatic
route, in a company notseeking industrial license, resulting in
change in the ownershippattern or transfer of stake by existing
investor to new foreigninvestor, will require Government
approval.(b) Licence applicationswill be considered and
licences will be given by the Departmentof Industrial Policy &
Promotion, Ministry of Commerce &Industry, in consultation
with Ministry of Defence and Ministryof External Affairs.(c)
Foreign investmentin this sector is subject to security
clearance and guidelines ofthe Ministry of Defence.(d)
Investee company should be structured to beself-sufficient in
areas of product design and development. Theinvestee/ joint
venture company along with manufacturingfacility, should
also have maintenance and life cycle supportfacility of the
product being manufactured in India.
7. Broadcasting   
7.1 Broadcasting Carriage Services   
7.1.1(a) Teleports (settingup of up-linking HUBs/ Teleports);(b)
Direct to Home(DTH);(c) Cable Networks(Multi System
Operators (MSOs) operating at National or State orDistrict
level and undertaking up-gradation of networks
towardsdigitalization and addressability);(d) Mobile TV;(e)
Head-end-in-the Sky Broadcasting Service (HITS)100% Automatic
7.1.2Cable Networks (Other MSOs not undertakingup-gradation of
networks towards digitalization andaddressability and Local
Cable Operators (LCOs)).100% Automatic
7.1.3Note: Infusion of fresh foreign investment forsectors specified
in 7.1.1 and 7.1.2 above, beyond 49 percent ina company not
seeking license/ permission from sectoral Ministry,resulting
in change in the ownership pattern or transfer of stakeby
existing investor to new foreign investor, will
requireGovernment approval
7.2 Broadcasting Content Services   
7.2.1Terrestrial Broadcasting FM (FM Radio), subject tosuch terms
and conditions, as specified from time to time, byMinistry of
Information and Broadcasting, for grant of permissionfor
setting up of FM Radio stations.49% Government
7.2.2 Up-Linking of 'News & Current Affairs' TVChannels 49% Government
7.2.3 100% AutomaticForeign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

Up-linking of Non-'News & Current Affairs' TVChannels/
Down-linking of TV Channels
7.3 Other Conditions   
 (a) Foreign investmentin companies engaged in all the
afore-stated services will besubject to relevant regulations and
such terms and conditions, asmay be specified from time to
time, by the Ministry ofInformation and Broadcasting.(b)
Foreign investmentin the afore-stated broadcasting carriage
services will besubject to the terms and conditions as may be
specified by theMinistry of Information and Broadcasting,
from time to time, inthis regard.(c) Licensee shallensure that
broadcasting service installation carried out by itshould not
become a safety hazard and is not in contravention ofany
statute, rule or regulations and public policy.(d) In the l&
Bsector where the sectoral cap is up to 49 percent, the
companyshould be owned and controlled by resident Indian
citizens orIndian companies which are owned and controlled
by residentIndian citizens.(i) For this purpose,the equity held
by the largest Indian shareholder shall be atleast 51 percent of
the total equity, excluding the equity heldby Public Sector
Banks and Public Financial Institutions, asdefined in Section
4A of the Companies Act, 1956 or Section 2(72) of the
Companies Act, 2013, as the case may be. The term`largest
Indian shareholder' used in this clause, will includeany or a
combination of the following:(1) In the case of anindividual
shareholder,(aa) The individualshareholder,(bb) A relative of
theshareholder within the meaning of Section 2 (77) of
CompaniesAct, 2013.(cc) A company/group ofcompanies in
which the individual shareholder/HUF to which hebelongs
has management and controlling interest.(2) In the case of
anIndian company,(aa) The Indian company(bb) A group of
Indiancompanies under the same management and ownership
control.(3) For this purpose,"Indian company" shall be a
company which must have aresident Indian or a relative as
defined under Section 2 (77) ofCompanies Act, 2013/ HUF,
either singly or in combination holdingat least 51percent of
the shares.(4) Provided that, in case of a combination of allor
any of the entities mentioned in Sub-Clauses (d)(i) above,each
of the parties shall have entered into a legally
bindingagreement to act as a single unit in managing the
matters of theapplicant company
8. Print Media   
8.1 Publishing of newspaper and periodicals dealingwith news 26% GovernmentForeign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

and current affairs
8.2Publication of Indian editions of foreign magazinesdealing
with news and current affairs26% Government
8.2.1 Other conditions   
 (a) 'Magazine', for thepurpose of these guidelines, will be
defined as a periodicalpublication, brought out on non-daily
basis, containing publicnews or comments on public news.(b)
Foreign investment shall also be subject to theGuidelines for
Publication of Indian editions of foreignmagazines dealing
with news and current affairs issued by theMinistry of
Information & Broadcasting on 4-12-2008.
8.3Publishing/ printing of Scientific and TechnicalMagazines/
specialty journals/periodicals, subject to compliancewith the
legal framework as applicable and guidelines issued inthis
regard from time to time by Ministry of Information
andBroadcasting.100% Government
8.4 Publication of facsimile edition of foreignnewspapers 100% Government
8.4.1 Other conditions:   
 (a) Foreign investmentshould be made by the owner of the
original foreign newspaperswhose facsimile edition is
proposed to be brought out in India.(b) Publication
offacsimile edition of foreign newspapers can be undertaken
only byan entity incorporated or registered in India under
theprovisions of the Companies Act, 2013.(c) Publication of
facsimile edition of foreignnewspaper would also be subject to
the Guidelines for publicationof newspapers and periodicals
dealing with news and currentaffairs and publication of
facsimile edition of foreignnewspapers issued by Ministry of
Information & Broadcastingon 31-3-2006.
9. Civil Aviation
9.1 The Civil Aviationsector includes Airports, Scheduled and
Non-Scheduled domesticpassenger airlines, Helicopter
services/ Seaplane services,Ground Handling Services,
Maintenance and Repair organizations,Flying training
institutes, and Technical training institutions.For the
purposes ofthe Civil Aviation sector:(a) "Airport"means a
landing and taking off area for aircrafts, usually withrunways
and aircraft maintenance and passenger facilities andincludes
aerodrome as defined in clause (2) of section 2 of theAircraft
Act, 1934;(b) "Aerodrome"means any definite or limited
ground or water area intended to beused, either wholly or in
part, for the landing or departure ofaircraft, and includes allForeign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

buildings, sheds, vessels, piers andother structures thereon or
pertaining thereto;(c) "Air transportservice" means a service
for the transport by air ofpersons, mails or any other thing,
animate or inanimate, for anykind of remuneration
whatsoever, whether such service consists ofa single flight or
series of flights;(d) "Air TransportUndertaking" means an
undertaking whose business includesthe carriage by air of
passengers or cargo for hire or reward;(e)
"Aircraftcomponent" means any part, the soundness and
correctfunctioning of which, when fitted to an aircraft, is
essential tothe continued airworthiness or safety of the
aircraft andincludes any item of equipment;(f)
"Helicopter"means a heavier than air aircraft supported in
flight by thereactions of the air on one or more power driven
rotors onsubstantially vertical axis;(g) "Scheduled airtransport
service" means an air transport service undertakenbetween
the same two or more places and operated according to
apublished time table or with flights so regular or frequent
thatthey constitute a recognizably systematic series, each
flightbeing open to use by members of the public;(h)
"Non-Scheduledair transport service" means any service
which is not ascheduled air transport service and will include
Cargo airlines;(i) "Cargoairlines" would mean such airlines
which meet the conditionsas given in the Civil Aviation
Requirements issued by theMinistry of Civil Aviation;(j)
"Seaplane"means an aeroplane capable normally of taking off
from andalighting solely on water;(k) "Ground Handling"
means (i) ramphandling, (ii) traffic handling both of which
shall include theactivities as specified by the Ministry of Civil
Aviation throughthe Aeronautical Information Circulars from
time to time, and(iii) any other activity specified by the
Central Government tobe a part of either ramp handling or
traffic handling.
9.2 Airports   
 (a) Greenfield projects 100% Automatic
 (b) Existing projects 100% Automatic
9.3 Air Transport Services   
 (a) [ (i) Scheduled Air Transport Service/ Domestic Scheduled
Passenger Airline(ii) Regional Air Transport Service
[Substituted by Notification No. G.S.R. 279(E), dated
26.3.2018 (w.e.f. 7.11.2017).]100%Automatic up to
49%Government
route beyond
49%(Automatic
up to 100% for
NRIs and OCIs)]Foreign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

 (b) Non-Scheduled Air Transport Service 100% Automatic
 (c) Helicopter services/ seaplane servicesrequiring DGCA
approval100% Automatic
9.4 Other Services under Civil Aviation sector   
 (a) Ground Handling Services subject to sectoralregulations
and security clearance100% Automatic
 (b) Maintenance and Repair organizations; flyingtraining
institutes and technical training institutions100% Automatic
9.5 Other Conditions   
 (a) Air TransportServices would include Domestic Scheduled
Passenger Airlines,Non-Scheduled Air Transport Services,
helicopter and seaplaneservices.(b) Foreign airlines
areallowed to make foreign investment in Cargo airlines,
helicopterand seaplane services, as per the limits and entry
routesmentioned above.(c) Foreign airlines areallowed to
invest in the capital of Indian companies, operatingscheduled
and nonscheduled air transport, services up to thelimit 49
percent of the paid up capital of the Indian investeecompany.
Such foreign investment would be subject to thefollowing
conditions:(i) It shall be underthe Government approval
route.(ii) The foreigninvestment shall comply with the
relevant regulations ofSecurities and Exchange Board of India
as well as otherapplicable rules and regulations.(iii) A
ScheduledOperator's Permit can be granted only to a
company:a. (1) that isregistered and has its principal place of
business within India;b. (2) the Chairman andat least
two-thirds of the Directors of which are citizens ofIndia; andc.
(3) the substantialownership and effective control of which is
vested in Indiancitizens.(iv) All foreignnationals likely to be
associated with Indian scheduled andnon-scheduled air
transport services, as a result of such foreigninvestment shall
be cleared from security view point beforedeployment; and(v)
All technicalequipment that might be imported into India as a
result of suchforeign investment shall require clearance from
the relevantauthority in the Ministry of Civil Aviation.[(d) In
addition to the above conditions, foreign investment in M/s
Air India Limited shall be subject to the following
conditions:(i) Foreign investment in M/s Air India Ltd.,
including that of foreign airline(s), shall not exceed 49% either
directly or indirectly.(ii) Substantial ownership and effective
control of M/s Air India Ltd. shall continue to be vested in
Indian Nationals] [Inserted by Notification No. G.S.R. 279(E),
dated 26.3.2018 (w.e.f. 7.11.2017).]Note:(1) The sectoralForeign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

caps/entry routes, mentioned at paragraph 9.3(a) and 9.3(b)
above, areapplicable in the situation where there is no
investment byforeign airlines.(2) The dispensation forNRIs
and OCIs regarding foreign investment up to 100% shall
alsobe applicable in respect of the investment regime specified
at9.5(c) above.[(3) ***] [Omitted by Notification No. G.S.R.
279(E), dated 26.3.2018 (w.e.f. 7.11.2017).](4) The investee
company additionally shall have tofollow guidelines issued by
the concerned ministry of the CentralGovernment.
10Construction Development: Townships, Housing,Built-up
infrastructure  
10.1Construction-development projects (which wouldinclude
development of townships, construction
ofresidential/commercial premises, roads or bridges,
hotels,resorts, hospitals, educational institutions,
recreationalfacilities, city and regional level infrastructure,
townships)100% Automatic
10.2 Other Conditions   
10.2 (a) Each phase of theconstruction development project would
be considered as aseparate project.(b) The investor will
bepermitted to exit on completion of the project or
afterdevelopment of trunk infrastructure i.e. roads, water
supply,street lighting, drainage and sewerage.(c)
Notwithstandinganything contained at (b) above, a person
resident outside Indiawill be permitted to exit and repatriate
foreign investmentbefore the completion of project under
automatic route, providedthat a lock-in-period of three years,
calculated with referenceto each tranche of foreign investment
has been completed.Further, transfer of stake from a person
resident outside Indiato another person resident outside
India, without repatriation offoreign investment will neither
be subject to any lock-in periodnor to any government
approval.(d) The project shallconform to the norms and
standards, including land userequirements and provision of
community amenities and commonfacilities, as laid down in
the applicable building controlregulations, bye-laws, rules,
and other regulations of the StateGovernment/ Municipal/
Local Body concerned.(e) The Indian investeecompany will be
permitted to sell only developed plots. For thepurposes of this
policy "developed plots" will meanplots where trunk
infrastructure i.e. roads, water supply, streetlighting, drainage
and sewerage, have been made available.(f) The Indian
investeecompany shall be responsible for obtaining allForeign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

necessaryapprovals, including those of the building/ layout
plans,developing internal and peripheral areas and other
infrastructurefacilities, payment of development, external
development andother charges and complying with all other
requirements asprescribed under applicable rules/ bye-Laws/
regulations of theState Government/ Municipal/ Local Body
concerned.(g) The StateGovernment/ Municipal/ Local Body
concerned, which approves thebuilding/ development plans,
will monitor compliance of the aboveconditions by the
developer.Note:(1) Foreign investmentis not permitted in an
entity which is engaged or proposes toengage in real estate
business, construction of farm houses andtrading in
transferable development rights (TDRs).(2) Condition of
lock-inperiod will not apply to Hotels and Tourist Resorts,
Hospitals,Special Economic Zones (SEZs), Educational
Institutions, Old AgeHomes and investment by NRIs/
OCIs.(3) Completion of theproject will be determined as per
the local bye-laws/ rules andother regulations of State
Governments.(4) Foreign investmentup to 100 percent under
automatic route is permitted in completedprojects for
operating and managing townships, malls/
shoppingcomplexes and business centres. Consequent to such
foreigninvestment, transfer of ownership and/ or control of
the investeecompany from persons resident in India to
persons residentoutside India is also permitted. However,
there would be alock-in-period of three years, calculated with
reference to eachtranche of foreign investment and transfer of
immovable propertyor part thereof is not permitted during
this period.(5) "Transfer",in relation to this sector, includes,-a.
the sale, exchange orrelinquishment of the asset; orb. the
extinguishment ofany rights therein; orc. the
compulsoryacquisition thereof under any law; ord. any
transactioninvolving the allowing of the possession of any
immovableproperty to be taken or retained in part
performance of acontract of the nature referred to in section
53A of the Transferof Property Act, 1882 (4 of 1882) ; ore. any
transaction, byacquiring capital instruments in a company or
by way of anyagreement or any arrangement or in any other
manner whatsoever,which has the effect of transferring, or
enabling the enjoymentof, any immovable property.(6) Real
estatebusiness' means dealing in land and immovable
property with aview to earning profit therefrom and does not
include developmentof townships, construction of residential/
commercial premises,roads or bridges, educationalForeign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

institutions, recreationalfacilities, city and regional level
infrastructure, townships;[(7) Real estate broking services
shall be excluded from the definition of "real estate business"
and 100% foreign investment is allowed in real estate broking
services under automatic route] [Inserted by Notification No.
G.S.R. 279(E), dated 26.3.2018 (w.e.f.
7.11.2017).]Explanation:a. Investment in unitsof Real Estate
Investment Trusts (REITs) registered and regulatedunder the
Securities and Exchange Board of India (REITs)regulations
2014 shall also be excluded from the definition of"real estate
business".b. Earning of rentincome on lease of the property,
not amounting to transfer, willnot amount to real estate
business.c. Transfer in relationto real estate includes,(i) the
sale, exchangeor relinquishment of the asset; or(ii) the
extinguishmentof any rights therein; or(iii) the
compulsoryacquisition thereof under any law; or(iv) any
transactioninvolving the allowing of the possession of any
immovableproperty to be taken or retained in part
performance of acontract of the nature referred to in section
53A of the Transferof Property Act, 1882 (4 of 1882); or(v) any
transaction, by acquiring capitalinstruments in a company or
by way of any agreement or anyarrangement or in any other
manner whatsoever, which has theeffect of transferring, or
enabling the enjoyment of, anyimmovable property.
11. Industrial Parks 100% Automatic
11.1 For the purpose of thissector:(a) "IndustrialPark" is a project
in which quality infrastructure in theform of plots of
developed land or built up space or acombination with
common facilities, is developed and madeavailable to all the
allottee units for the purposes ofindustrial activity.(b)
"Infrastructure"refers to facilities required for functioning of
units located inthe Industrial Park and includes roads
(including approachroads), railway line/ sidings including
electrified railway linesand connectivity to the main railway
line, water supply andsewerage, common effluent treatment
facility, telecom network,generation and distribution of
power, air conditioning.(c) "CommonFacilities" refer to the
facilities available for all theunits located in the industrial
park, and include facilities ofpower, roads (including
approach roads), railway line/ sidingsincluding electrified
railway lines and connectivity to the mainrailway line, water
supply and sewerage, common effluenttreatment, common
testing, telecom services, air conditioning,common facility
buildings, industrial canteens, convention/conference halls,Foreign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

parking, travel desks, security service, firstaid centre,
ambulance and other safety services, trainingfacilities and
such other facilities meant for common use of theunits located
in the Industrial Park.(d) "Allocablearea" in the Industrial
Park means-(i) in the case of plotsof developed land - the net
site area available for allocation tothe units, excluding the area
for common facilities.(ii) in the case ofbuilt up space - the
floor area and built-up space utilized forproviding common
facilities.(iii) in the case of acombination of developed land
and built-up space - the net siteand floor area available for
allocation to the units excludingthe site area and built-up
space utilized for providing commonfacilities.(e) "Industrial
Activity" meansmanufacturing; electricity; gas and water
supply; post andtelecommunications; software publishing,
consultancy and supply;data processing, database activities
and distribution ofelectronic content; other computer related
activities; basic andapplied research and development on
bio-technology,pharmaceutical sciences/ life sciences, natural
sciences andengineering; business and management
consultancy activities; andarchitectural, engineering and other
technical activities.
11.2Foreign investment inIndustrial Parks would not be subject to
the conditionalitiesapplicable for construction development
projects etc. spelt outin para 10 above, provided the Industrial
Parks meet with theunder-mentioned conditions:(a) it would
comprise ofa minimum of 10 units and no single unit shall
occupy more than50 percent of the allocable area;(b) the
minimum percentage of the area to beallocated for industrial
activity shall not be less than 66percent of the total allocable
area.
12. Satellites - Establishment and operation   
 Satellites Establishment and operation, subject tothe sectoral
guidelines of Department of Space/ ISRO100% Government
13. Private Security Agencies 49% Government
14.Telecom services (including TelecomInfrastructure Providers
Category-l)  
14.1 All telecom services including TelecomInfrastructure
Providers Category-I, viz. Basic, Cellular, UnitedAccess
Services, Unified license (Access services), UnifiedLicense,
National/ International Long Distance, Commercial
V-Sat,Public Mobile Radio Trunked Services (PMRTS), Global
MobilePersonal Communications Services (GMPCS), all types
of ISPlicenses, Voice Mail/ Audiotex/ UMS, Resale of IPLC,100% Automatic up to
49%;
Government
route beyond
49%Foreign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

MobileNumber Portability services, Infrastructure Provider
Category-I(providing dark fibre, right of way, duct space,
tower) exceptOther Service Providers.
14.2 Other Conditions   
 The licensing and security conditions as notifiedby the
Department of Telecommunications (DoT) from time to
time,shall be observed by licensee as well as investors except
forforeign investment in "Other Service Providers", whichis
allowed up to 100 percent under the automatic route.
15. Trading   
15.1Cash and Carry Wholesale Trading/ WholesaleTrading
(including sourcing from MSEs)100% Automatic
15.1.1Definition:(a) Cash and CarryWholesale trading (WT)/
Wholesale trading, shall mean sale ofgoods/ merchandise to
retailers, industrial, commercial,institutional or other
professional business users or to otherwholesalers and related
subordinated service providers.(b) Wholesale trading shall,
accordingly, implysales for the purpose of trade, business and
profession, asopposed to sales for the purpose of personal
consumption. Theyardstick to determine whether the sale is
wholesale or not shallbe the type of customers to whom the
sale is made and not thesize and volume of sales. Wholesale
trading shall include resale,processing and thereafter sale,
bulk imports with export/exbonded warehouse business sales
and B2B e-Commerce.
15.1.2 Other Conditions   
 (a) For undertaking'WT', requisite licenses/ registration/
permits, as specifiedunder the relevant Acts/ Regulations/
Rules/ Orders of the StateGovernment/ Government Body/
Government Authority /LocalSelf-Government Body under
that State Government should beobtained.(b) Except in cases
ofsales to Government, sales made by the wholesaler shall
beconsidered as 'cash and carry wholesale trading/
wholesaletrading' with valid business customers, only when
WT is made tothe following entities:(i) Entities holdingsales
tax/ VAT registration/ service tax/ excise duty/Goods
andServices Tax (GST) registration; or(ii) Entities
holdingtrade licenses i.e. a license/ registration
certificate/membership certificate/ registration under Shops
andEstablishment Act, issued by a Government Authority/
GovernmentBody/ Local Self-Government Authority,
reflecting that theentity/ person holding the license/
registration certificate/membership certificate, as the caseForeign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

may be, is itself/ himself/herself engaged in a business
involving commercial activity; or(iii) Entities holdingpermits/
license etc. for undertaking retail trade (liketehbazari and
similar license for hawkers) from GovernmentAuthorities/
Local Self Government Bodies; or(iv) Institutions
havingcertificate of incorporation or registration as a society
orregistration as public trust for their self-consumption.Note:
An Entity, towhom WT is made, may fulfil any one of the 4
conditions at (b)(i)to (iv) above.(c) Full recordsindicating all
the details of such sales like name of entity,kind of entity,
registration/ license/ permit etc. number, amountof sale etc.
should be maintained on a day to day basis.(d) WT of goods
shall bepermitted among companies of the same group.
However, such WT togroup companies taken together shall
not exceed 25 percent of thetotal turnover of the wholesale
venture.(e) WT can be undertakenas per normal business
practice, including extending creditfacilities subject to
applicable regulations.(f) A wholesale/ cash and carry trader
canundertake single brand retail trading, subject to the
conditionsmentioned in para 15.3. An entity undertaking
wholesale/ cash andcarry as well as retail business will be
mandated to maintainseparate books of accounts for these two
arms of the business andduly audited by the statutory
auditors. Conditions under theseRegulations for wholesale/
cash and carry business and for retailbusiness have to be
separately complied with by the respectivebusiness arms.
15.2 E-Commerce   
15.2.1 B2B E-commerce activities 100% Automatic
 Such companies would engage only in Business toBusiness
(B2B) e-commerce and not in retail trading, inter aliaimplying
that existing restrictions on FDI in domestic tradingwould be
applicable to e-commerce as well.
15.2.2 Market place model of e-commerce 100 % Automatic
15.2.3 Other Conditions:   
 (a) E-commerce' meansbuying and selling of goods and
services including digitalproducts over digital & electronic
network;(b)['E-commerce entity' means a company
incorporated under the Companies Act 1956 or the Companies
Act, 2013] [Substituted ''E-commerce entity' means a
company incorporated under Companies Act, 2013 ' by
Notification No. G.S.R. 78(E), dated 31.1.2019 (w.e.f.
7.11.2017).]or aforeign company covered under section 2 (42)
of the CompaniesAct, 2013 or an office, branch or agency inForeign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

India as provided inSection 2 (v) (iii) of FEMA, 1999, owned
or controlled by aperson resident outside India and
conducting the e-commercebusiness;(c) 'Inventory
basedmodel of e-commerce' means an e-commerce activity
where inventoryof goods and services is owned by
e-commerce entity and is soldto the consumers directly;(d)
'Market place modelof e-commerce' means providing of an
information technologyplatform by an ecommerce entity on a
digital & electronicnetwork to act as a facilitator between
buyer and seller.(e) Digital &electronic network will include
network of computers, televisionchannels and any other
internet application used in automatedmanner such as web
pages, extranets, mobiles etc.(f) Marketplacee-commerce
entity will be permitted to enter into transactionswith sellers
registered on its platform on B2B basis.(g)
E-commercemarketplace may provide support services to
sellers in respect ofwarehousing, logistics, order fulfilment,
call centre, paymentcollection and other services.[(h)
E-commerce entity providing a marketplace will not exercise
ownership or control over the inventory i.e. goods purported
to be sold.Explanation.- Inventory of a vendor will be deemed
to be controlled by e-commerce marketplace entity if more
than 25% of purchases of such vendor are from the
marketplace entity or its group companies which will render
the business into inventory based model.] [Substituted by
Notification No. G.S.R. 78(E), dated 31.1.2019 (w.e.f.
7.11.2017).][(i) An entity having equity participation by
e-commerce marketplace entity or its group companies or
having control on its inventory by e-commerce marketplace
entity or its group companies, will not be permitted to sell its
products on the platform run by such marketplace entity.]
[Substituted by Notification No. G.S.R. 78(E), dated 31.1.2019
(w.e.f. 7.11.2017).](j) Goods/ services madeavailable for sale
electronically on website should clearlyprovide name, address
and other contact details of the seller.Post sales, delivery of
goods to the customers and customersatisfaction will be
responsibility of the seller.(k) Payments for salemay be
facilitated by the e-commerce entity in conformity withthe
guidelines issued by the Reserve Bank in this regard.(l) Any
warranty/guarantee of goods and services sold will be the
responsibilityof the seller.[(m) E-commerce entities providing
marketplace will not, directly or indirectly, influence the sale
price of any goods or services and shall maintain level playing
field. Services should be provided by e-commerce marketplaceForeign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

entity or other entities in which e-commerce marketplace
entity has direct or indirect equity participation or common
control, to vendors on the platform at arm's length and in a
fair and non-discriminatory manner. [Substituted by
Notification No. G.S.R. 78(E), dated 31.1.2019 (w.e.f.
7.11.2017).]Explanation.- Such services will include but not
limited to fulfilment, logistics, warehousing,
advertisement/marketing, payments, financing etc. Cash back
provided by group companies of marketplace entity to buyers
shall be fair and non-discriminatory. For the purposes of this
clause, provision of services to any vendor on such terms
which are not made available to other vendors in similar
circumstances will be deemed unfair and discriminatory.](n)
Guidelines on cash and carry wholesale trading as given in Sl
No. 15.1.2 above shall apply to B2B e-commerce activities.[(o)
No e-commerce marketplace entity shall mandate any seller to
sell any of their product exclusively on its platform.(p) All
existing investments shall have to be in compliance with the
above conditions from the date of issue of this Notification.]
[Inserted by Notification No. G.S.R. 78(E), dated 31.1.2019
(w.e.f. 7.11.2017).]Note:Foreign investment is not permitted
ininventory based model of e-commerce.
15.2.4Sale of services through e-commerce shall be underautomatic
route subject to the sector specific conditions,applicable laws/
regulations, security and otherconditionalities.
15.3Single Brand Product Retail Trading Foreigninvestment in
Single Brand Product Retail Trading (SBRT) is aimedat
attracting investments in production and marketing,
improvingthe availability of such goods for the consumer,
encouragingincreased sourcing of goods from India and
enhancingcompetitiveness of Indian enterprises through
access to globaldesigns, technologies and management
practices.100%[Automatic]
[Substituted
'Automatic up to
49%;
Government
route beyond
49%' Notification
No. G.S.R.
279(E), dated
26.3.2018 (w.e.f.
7.11.2017).]
15.3.1 Other conditions   
 (a) Products to be soldshould be of a 'Single Brand' only.(b)
Products should besold under the same brand internationally
i.e. products should besold under the same brand in one or
more countries other thanIndia.(c) 'Single
Brand'product-retail trading would cover only products which
arebranded during manufacturing.[(d) A person residentForeign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

outside India, whether owner of the brand or otherwise, shall
be permitted to undertake 'single brand' product retail trading
in the country for the specific brand, either directly by the
brand owner or through a legally tenable agreement executed
between the Indian entity undertaking single brand retail
trading and the brand owner.] [Substituted by Notification
No. G.S.R. 279(E), dated 26.3.2018 (w.e.f. 7.11.2017).](e) In
respect ofproposals involving foreign investment beyond 51
percent,sourcing of 30 percent of the value of goods
purchased, will bedone from India, preferably from MSMEs,
village and cottageindustries, artisans and craftsmen, in all
sectors. The quantumof domestic sourcing will be
self-certified by the company, to besubsequently checked, by
statutory auditors, from the dulycertified accounts which the
company will be required tomaintain. The procurement
requirement is to be met in the firstinstance as an average of
five years total value of goodspurchased beginning 1st April of
the year of the commencement ofthe business. Thereafter it
shall be met on an annual basis. Forthe purpose of
ascertaining the sourcing requirement, therelevant entity
would be the company, incorporated in India,which is the
recipient of foreign investment for the purpose ofcarrying out
single brand product retail trading.(f) Subject to theconditions
mentioned in this Para, a single brand retail tradingentity
operating through brick and mortar stores, is permitted
toundertake retail trading through e-commerce.[(g) *]
[Omitted by Notification No. G.S.R. 279(E), dated
26.3.2018 (w.e.f. 7.11.2017).][(h) *] [Omitted by
Notification No. G.S.R. 279(E), dated 26.3.2018 (w.e.f.
7.11.2017).][(i) Single brand retail trading entity shall be
permitted to set off its incremental sourcing of goods from
India for global operations during initial 5 years, beginning 1st
April of the year of the opening of first store, against the
mandatory sourcing requirement of 30% of purchases from
India. For this purpose, incremental sourcing shall mean the
increase in terms of value of such global sourcing from India
for that single brand (in INR terms) in a particular financial
year from India over the preceding financial year, by the
non-resident entities undertaking single brand retail trading,
either directly or through their group companies. After
completion of this 5 years period, the SBRT entity shall be
required to meet the 30% sourcing norms directly towards its
India's operation, on an annual basis.] [Inserted by
Notification No. G.S.R. 279(E), dated 26.3.2018 (w.e.f.Foreign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

7.11.2017).]Note:(1) Conditions mentionedat (b) and (d) above
shall not be applicable for undertaking SBRTof Indian
brands.[(2) and (3) ***] [Deleted by Notification No. G.S.R.
279(E), dated 26.3.2018 (w.e.f. 7.11.2017).](4) Indian brands
shouldbe owned and controlled by resident Indian citizens
and/ orcompanies which are owned and controlled by resident
Indiancitizens.[(5) Sourcing norms will not be applicable up to
three years from commencement of the business i.e. opening
of the first store for entities undertaking single brand retail
trading of products having 'state-of-art' and 'cutting-edge'
technology and where local sourcing is not possible.
Thereafter, condition mentioned at 15.3.1(e) above will be
applicable. A Committee under the Chairmanship of
Secretary, DIPP, with representatives from NITI Aayog,
concerned Administrative Ministry and independent technical
expert(s) on the subject will examine the claim of applicants
on the issue of the products being in the nature of 'state-of-art'
and 'cutting-edge' technology where local sourcing is not
possible and give recommendations for such relaxation.]
[Substituted by Notification No. G.S.R. 279(E), dated
26.3.2018 (w.e.f. 7.11.2017).]
15.4 Multi Brand Retail Trading (MBRT) 51% Government
15.4.1 Other Conditions   
 (a) Fresh agriculturalproduce, including fruits, vegetables,
flowers, grains, pulses,fresh poultry, fishery and meat
products, can be unbranded.(b) Minimum amount to
bebrought in as foreign investment would be USD 100
million.(c) At least 50 percentof the total foreign investment
brought in the first tranche ofUSD 100 million, shall be
invested in 'back-end infrastructure'within three years, where
'back-end infrastructure' will includecapital expenditure on all
activities, excluding that onfront-end units; for instance,
back-end infrastructure willinclude investment made towards
processing, manufacturing,distribution, design improvement,
quality control, packaging,logistics, storage, warehouse,
agriculture market produceinfrastructure etc. Expenditure on
land cost and rentals, if any,will not be counted for purposes
of back-end infrastructure.Subsequent investment in the
back-end infrastructure would bemade by the MBRT retailer
as needed, depending upon its businessrequirements.(d) At
least 30 percentof the value of procurement of manufactured/
processed productspurchased shall be sourced from Indian
micro, small and mediumindustries, which have a totalForeign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

investment in plant &machinery not exceeding USD2 million.
This valuation refers tothe value at the time of installation,
without providing fordepreciation. The 'small industry' status
would be reckoned onlyat the time of first engagement with
the retailer and suchindustry shall continue to qualify as a
'small industry' for thispurpose, even if it outgrows the said
investment of USD2 millionduring the course of its
relationship with the said retailer.Sourcing from agricultural
co-operatives and farmersco-operatives would also be
considered in this category. Theprocurement requirement
would have to be met, in the firstinstance, as an average of five
years total value of themanufactured/ processed products
purchased, beginning 1st Aprilof the year during which the
first tranche of foreign investmentis received. Thereafter, it
would have to be met on an annualbasis.(e) Self-certificationis
required by the company, to ensure compliance of
theconditions at serial nos. (b), (c) and (d) above, which could
becross-checked, as and when required. Accordingly, the
investorsshall maintain accounts, duly certified by statutory
auditors.(f) Retail sales outletsmay be set up only in cities with
a population of more than 10lakh as per the 2011 Census or
any other cities as per thedecision of the respective State
Governments, and may also coveran area of 10 kms. Around
the municipal/ urban agglomerationlimits of such cities; retail
locations will be restricted toconforming areas as per the
Master/ Zonal Plans of the concernedcities and provision will
be made for requisite facilities suchas transport connectivity
and parking.(g) Government will havethe first right to procure
agricultural products.(h) The above policy isan enabling policy
only and the State Governments/ UnionTerritories would be
free to take their own decisions in regardto implementation of
the policy. Therefore, retail sales outletsmay be set up in those
States/ Union Territories which haveagreed, or agree in
future, to allow foreign investment in MBRTunder this policy.
The States/ Union Territories which haveconveyed their
agreement are mentioned at 15.4.2. Such agreement,in future,
to permit establishment of retail outlets under thispolicy,
would be conveyed to the Government of India through
theDepartment of Industrial Policy and Promotion and
additions wouldbe made to the said list. The establishment of
the retail salesoutlets will be in compliance of applicable
State/ UnionTerritory laws/ regulations, such as the Shops
and EstablishmentsAct etc.(i) Retail trading, inany form, by
means of e-commerce, would not be permissible,Foreign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

forcompanies with foreign investment engaged in multi-brand
retailtrading.(j) Applications would be processed in
theDepartment of Industrial Policy and Promotion, to
determinewhether the proposed investment satisfies the
notifiedguidelines, before being considered for Government
approval.
15.4.2States/ Union Territories are Andhra Pradesh,Assam, Delhi,
Haryana, Himachal Pradesh, Jammu & Kashmir,Karnataka,
Maharashtra, Manipur, Rajasthan, Uttarakhand, Daman &Diu
and Dadra and Nagar Haveli (Union Territories)
15.5 Duty Free Shops 100% Automatic
15.5.1 Other Conditions:   
 (a) Duty Free Shopswould mean shops set up in custom
bonded area at InternationalAirports/ International Seaports
and Land Custom Stations wherethere is transit of
international passengers.(b) Foreign investmentin Duty Free
Shops is subject to compliance of conditionsstipulated under
the Customs Act, 1962 and other laws, rules
andregulations.(c) Duty Free Shop entity shall not engage into
anyretail trading activity in the Domestic Tariff Area of
thecountry.
16 Pharmaceuticals   
16.1 Greenfield 100% Automatic
16.2 Brownfield 100%Automatic up to
74%;
   Government
route beyond
74%
16.3 Other Conditions   
 (a) 'Non-compete' clausewould not be allowed except in
special circumstances with theGovernment approval.(b) The
prospectiveinvestor and the prospective investee are required
to provide acertificate given at 16.4 along with the application
submittedfor Government approval.(c) Government
approvalmay incorporate appropriate conditions for foreign
investment inbrownfield cases.(d) Foreign investmentin
brownfield pharmaceuticals, irrespective of entry route,
isfurther subject to the following conditions(i) The production
levelof National List of Essential Medicines (NLEM) drugs
and/ orconsumables and their supply to the domestic market
at the timeof induction of foreign investment, being
maintained over thenext five years at an absolute quantitativeForeign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

level. The benchmarkfor this level would be decided with
reference to the level ofproduction of NLEM drugs and/ or
consumables in the threefinancial years, immediately
preceding the year of induction offoreign investment. Of
these, the highest level of production inany of these three
years would be taken as the level.(ii) Research
andDevelopment (R&D) expenses being maintained in value
termsfor 5 years at an absolute quantitative level at the time
ofinduction of foreign investment. The benchmark for this
levelwould be decided with reference to the highest level of
R&Dexpenses which has been incurred in any of the three
financialyears immediately preceding the year of induction of
foreigninvestment.(iii) The administrativeMinistry will be
provided complete information pertaining to thetransfer of
technology, if any, along with induction of foreigninvestment
into the investee company.(iv) The administrativeMinistry (s)
i.e. Ministry of Health and Family Welfare,Department of
Pharmaceuticals or any other regulatoryAgency/Development
as notified by Central Government from time totime, will
monitor the compliance of conditionalities.Note :(1) Foreign
investmentup to 100% under the automatic route is permitted
formanufacturing of medical devices. The abovementioned
conditionswill, therefore, not be applicable to greenfield as
well asbrownfield projects of this industry.(2) Medical device
means:-(a) Any instrument,apparatus, appliance, implant,
material or other article, whetherused alone or in
combination, including the software, intended byits
manufacturer to be used specially for human beings or
animalsfor one or more of the specific purposes of:-(aa)
Diagnosis,prevention, monitoring, treatment or alleviation of
any diseaseor disorder;(ab) diagnosis,monitoring, treatment,
alleviation of, or assistance for, anyinjury or[disability]
[Substituted 'handicap' by Notification No. G.S.R. 279(E),
dated 26.3.2018 (w.e.f. 7.11.2017).];(ac)
investigation,replacement or modification or support of the
anatomy or of aphysiological process;(ad) supporting
orsustaining life;(ae) disinfection ofmedical devices;(af)
control ofconception;and which does notachieve its primary
intended action in or on the human body oranimals by any
pharmacological or immunological or metabolicmeans, but
which may be assisted in its intended function by
suchmeans;(b) an accessory to suchan instrument, apparatus,
appliance, material or other article;[(c) in-vitro diagnostic
device which is a reagent, reagent product, calibrator, controlForeign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

material, kit, instrument, apparatus, equipment or system,
whether used alone or in combination thereof intended to be
used for examination and providing information for medical
or diagnostic purposes by means of examination of specimens
derived from the human bodies or animals.] [Substituted by
Notification No. G.S.R. 279(E), dated 26.3.2018 (w.e.f.
7.11.2017).][(3) ***] [Omitted by Notification No. G.S.R.
279(E), dated 26.3.2018 (w.e.f. 7.11.2017).]
16.4Certificate to beFurnished by the Prospective Investor as well
as the ProspectiveRecipient Entity It is certified that the
following is thecomplete list of all inter-se agreements,
including theshareholders agreement, entered into between
foreign investor(s)and investee brownfield pharmaceutical
entity1. ..................2. ...................3. ...................(copies of
allagreements to be enclosed)It is also certifiedthat none of
the inter-se agreements, including the
shareholdersagreement, entered into between foreign
investor(s) and investeebrownfield pharmaceutical entity
contain any non-compete clausein any form whatsoever.It is
further certifiedthat there are no other contracts/agreements
between the foreigninvestor(s) and investee brownfield
pharma entity other thanthose listed above.The foreign
investor(s) and investee brownfieldpharma entity undertake
to submit to the FIPB any inter-seagreements that may be
entered into between them subsequent tothe submission and
consideration of this application.|-17Railway
Infrastructure  
17.1Construction, operation and maintenance of thefollowing: (i)
Suburban corridor projects through PPP, (ii)high-speed train
projects, (iii) Dedicated freight lines, (iv)Rolling stock
including train sets, and locomotives/ coachesmanufacturing
and maintenance facilities, (v) RailwayElectrification, (vi)
Signalling systems, (vii) Freightterminals, (viii) Passenger
terminals, (ix) Infrastructure inindustrial park pertaining to
railway line/ sidings includingelectrified railway lines and
connectivity to main railway lineand (x) Mass Rapid
Transport Systems.100% Automatic
17.2 Other Conditions   
 (a) Foreign investmentin this sector open to private-sector
participation is subject tosectoral guidelines of Ministry of
Railways.(b) Proposals involving foreign investment
beyond49 percent sensitive areas from security point of view,
will bebrought by the Ministry of Railways before the Cabinet
Committeeon Security (CCS) for consideration on a case toForeign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

case basis.
FFINANCIAL SERVICESInvestment in financial services, other
than thoseindicated below, would require prior Government
approval.
F.1 Asset Reconstruction Companies 100% Automatic
F.1.1 Other Conditions   
 (a) Investment limit ofa sponsor in the shareholding of an
ARC will be governed by theprovisions of Securitisation and
Reconstruction of FinancialAssets and Enforcement of
Security Interest Act, 2002. Similarly,investment by
institutional/ non-institutional investors willalso be governed
by the said Act.(b) FPIs can invest inthe Security Receipts
(SRs) issued by ARCs. FPIs may be allowedto invest up to 100
percent of each tranche in SRs issued byARCs, subject to
directions/ guidelines of Reserve Bank. Suchinvestment
should be within the relevant regulatory cap asapplicable.(c)
All investments would be subject to provisionsof the
Securitisation and Reconstruction of Financial Assets
andEnforcement of Security Interest Act, 2002.
F.2 Banking - Private sector 74%Automatic up to
49% Government
route beyond
49%and up to
74%
F.2.1 Other conditions:   
 (a) At all times, atleast 26 percent of the paid up capital will
have to be held byresidents, except in regard to a
wholly-owned subsidiary of aforeign bank.(b) In case of
NRIsindividual holdings is restricted to 5 percent of the total
paidup capital both on repatriation and non-repatriation basis
andaggregate limit cannot exceed 10 percent of the total paid
upcapital both on repatriation and non-repatriation basis.
However,NRI holdings can be allowed up to 24 percent of the
total paid upcapital both on repatriation and non-repatriation
basis subjectto a special resolution to this effect passed by the
bankingcompany's general body.(c) Applications forforeign
investment in private banks having joint venture/subsidiary in
insurance sector may be addressed to the ReserveBank for
consideration in consultation with the InsuranceRegulatory
and Development Authority of India (IRDAI) in order
toensure that the 49 percent limit of investment applicable for
theinsurance sector is not breached.(d) Transfer of
sharesunder FDI from residents to non-residents will requireForeign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

approvalof the Reserve Bank and/ or the Government,
wherever applicable(e) The policies andprocedures prescribed
by RBI and other institutions such asSecurities and Exchange
Board of India, Ministry of CorporateAffairs and IRDAI on
these matters will apply.(f) RBI guidelinesrelating to
acquisition by purchase or otherwise of capitalinstruments of
a private bank, if such acquisition results in anyperson owning
or controlling 5 percent or more of the paid upcapital of the
private bank will apply to foreign investment aswell.(g)
Setting up of asubsidiary by foreign banks(i) Foreign banks
willbe permitted to either have branches or subsidiaries but
notboth.(ii) Foreign banksregulated by banking supervisory
authority in the home countryand meeting Reserve Bank's
licensing criteria will be allowed tohold 100 percent paid-up
capital to enable them to set up awholly-owned subsidiary in
India.(iii) A foreign bank mayoperate in India through only
one of the three channels viz., (i)branches (ii) a wholly-owned
subsidiary (iii) a subsidiary withaggregate foreign investment
up to a maximum of 74 percent in aprivate bank.(iv) A foreign
bank willbe permitted to establish a wholly-owned subsidiary
eitherthrough conversion of existing branches into a
subsidiary orthrough a fresh banking license. A foreign bank
will be permittedto establish a subsidiary through acquisition
of shares of anexisting private sector bank provided at least 26
percent of thepaid-up capital of the private sector bank is held
by residentsat all times consistent with para (c) above.(v) A
subsidiary of aforeign bank will be subject to the licensing
requirements andconditions broadly consistent with those for
new private sectorbanks.(vi) Guidelines forsetting up a
wholly-owned subsidiary of a foreign bank will beissued
separately by RBI.(vii) All applicationsby a foreign bank for
setting up a subsidiary or for conversionof their existing
branches to subsidiary in India will have to bemade to the
RBI.(h) The present limit of10 percent on voting rights in
respect banking companies may benoted by the potential
investor.(i) All investments shall be subject to theguidelines
prescribed for the banking sector under the
BankingRegulation Act, 1949 and the Reserve Bank of India
Act, 1934.
F.3 Banking - Public Sector   
F.3.1Banking - Public Sector subject to BankingCompanies
(Acquisition & Transfer of Undertakings) Acts,1970/ 80. This
ceiling is also applicable to the State Bank ofIndia.20% GovernmentForeign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

F.4 Infrastructure Companies in the SecuritiesMarket   
F.4.1Infrastructure Companies in the Securities
MarketInfrastructure companies in Securities Markets,
namely, stockexchanges, commodity derivative exchanges,
depositories andclearing corporations, in compliance with
Securities and ExchangeBoard of India Regulations49% Automatic
F.4.2 Other conditions:   
 (a) Foreign investment,including investment by FPIs, will be
subject to the Guidelines/Regulations issued by the Central
Government, Securities andExchange Board of India and the
Reserve Bank from time to time.(b) Words and expressions
used herein and notdefined in these regulations but defined in
the Companies Act,2013 (18 of 2013) or the Securities
Contracts (Regulation) Act,1956 (42 of 1956) or the Securities
and Exchange Board of IndiaAct, 1992 (15 of 1992) or the
Depositories Act, 1996 (22 of 1996)or in the concerned
Regulations issued by Securities and ExchangeBoard of India
shall have the same meanings respectively assignedto them in
those Acts/ Regulations.
F.5 Commodities Spot Exchange 49% Automatic
F.5.1Investment shall be subject to guidelinesprescribed by the
Central/ State Government
F.6 Power Exchanges   
 Power Exchanges under the Central ElectricityRegulatory
Commission (Power Market) Regulations, 201049% Automatic
F.6.1 Other conditions   
 (a) [***] [Deleted by Notification No. G.S.R. 279(E), dated
26.3.2018 (w.e.f. 7.11.2017).](b) A person residentoutside
India including persons acting in concert should not holdmore
than 5 percent.(c) The investment would be in compliance
withSecurities and Exchange Board of India Regulations,
otherapplicable laws/ regulations, security and other
conditionalities
F.7 Credit Information Companies 100% Automatic
F.7.1 Other conditions   
 (a) Foreign investmentin Credit Information Companies is
subject to the CreditInformation Companies (Regulation) Act,
2005 and regulatoryclearance from the Reserve Bank.(b) FPI
investment wouldbe permitted subject to the following
conditions:(i) A single entityshall directly or indirectly hold
below 10 percent equity;(ii) Any acquisition inexcess of 1
percent will have to be reported to Reserve Bank asForeign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

amandatory requirement; and(iii) FPIs investing in Credit
InformationCompanies shall not seek a representation on the
Board ofDirectors based upon their shareholding.
F.8 Insurance   
F.8.1(a) Insurance Company(b) Insurance Brokers(c) Third
PartyAdministrators(d) Surveyors and LossAssessors(e) Other
Insurance Intermediaries appointed underthe provisions of
Insurance Regulatory and Development AuthorityAct, 1999
(41 of 1999)49% Automatic
F.8.2 Other Conditions   
 (a) Foreign investmentin this sector shall be subject to
compliance with the provisionsof the Insurance Act, 1938 and
subject to necessary license/approval from the Insurance
Regulatory & DevelopmentAuthority of India for undertaking
insurance and relatedactivities.(b) An Indian
Insurancecompany shall ensure that its ownership and control
remains atall times with resident Indian entities as
determined by CentralGovernment/ Insurance Regulatory and
Development Authority ofIndia as per the rules/ regulation
issued.(c) Where an entity likea bank, whose primary business
is outside the insurance area, isallowed by the Insurance
Regulatory and Development Authority ofIndia to function as
an insurance intermediary, the foreignequity investment caps
applicable in that sector shall continueto apply, subject to the
condition that the revenues of suchentities from their primary
(i.e., non-insurance related)business must remain above 50
percent of their total revenues inany financial year.(d) The
provisions ofparagraphs F.2.1 relating to 'Banking-Private
Sector', shall beapplicable in respect of bank promoted
insurance companies.(e) Terms 'Control', 'Equity Share
Capital','Foreign Direct Investment' (FDI), 'Foreign Investors',
'ForeignPortfolio Investment', 'Indian Insurance Company',
'IndianCompany', 'Indian Control of an Indian Insurance
Company','Indian Ownership', 'Non-resident Entity', 'Public
FinancialInstitution', 'Resident Indian Citizen', 'Total
ForeignInvestment' will have the same meaning as provided
inNotification No. G.S.R 115 (E), dated 19th February, 2015
issuedby Department of Financial Services and regulations
issued byInsurance Regulatory and Development Authority of
India from timeto time.
F.9 Pension Sector 49% Automatic
F.9.1 Other conditions   
 Foreign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

(a) Foreign investmentin this sector shall be in accordance
with the Pension FundRegulatory and Development Authority
(PFRDA) Act, 2013.(b) Foreign investmentin Pension Funds
will be subject to the condition that entitiesinvesting in capital
instruments issued by an Indian Pension Fundas per Section
24 of the PFRDA Act, 2013 shall obtain necessaryregistration
from the PFRDA and comply with other requirements asper
the PFRDA Act, 2013 and Rules and Regulations framed
under itfor so participating in Pension Fund Management
activities inIndia.(c) An Indian pension fund shall ensure that
itsownership and control remains at all times with resident
Indianentities as determined by the Government of India/
PFRDA as perthe rules/ regulation issued by them.
F.10 Other Financial Services 100% Automatic
F.10.1 Other Conditions   
 (a) Other FinancialServices will mean financial services
activities regulated byfinancial sector regulators, viz., Reserve
Bank, Securities andExchange Board of India, Insurance
Regulatory and DevelopmentAuthority, Pension Fund
Regulatory and Development Authority,National Housing
Bank or any other financial sector regulator asmay be notified
by the Government of India.(b) Foreign investmentin 'Other
Financial Services' activities shall be subject
toconditionalities, including minimum capitalization norms,
asspecified by the concerned Regulator/Government
Agency(c) 'Other FinancialServices' activities need to be
regulated by one of the FinancialSector Regulators. In all such
financial services activity whichare not regulated by any
Financial Sector Regulator or where onlypart of the financial
services activity is regulated or wherethere is doubt regarding
the regulatory oversight, foreigninvestment up to 100 percent
will be allowed under Governmentapproval route subject to
conditions including minimumcapitalization requirement, as
may be decided by the Government.(d) Any activity whichis
specifically regulated by an Act, the foreign investmentlimits
will be restricted to those levels/ limit that may bespecified in
that Act, if so mentioned.(e) Downstream investments by any
of these entitiesengaged in "Other Financial Services" will be
subjectto these Regulations.Foreign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

Schedule 1
[See Regulation 5(1)]Purchase/ Sale of capital instruments of an Indian company by a person
resident outside India
1. Purchase/sale of capital instruments of an Indian company by a person
resident outside India. - (1) An Indian company may issue capital instruments
to a person resident outside India subject to entry routes, sectoral caps and
attendant conditionalities specified in Regulation 16;
(2)A person resident outside India may purchase capital instruments of a listed Indian company on
a stock exchange in India provided that:(a)The person resident outside India making the investment
has already acquired control of such company in accordance with SEBI (Substantial Acquisition of
Shares and Takeover) Regulations, 2011 and continues to hold such control;(b)The amount of
consideration may be paid as per the mode of payment prescribed in this Schedule or out of the
dividend payable by Indian investee company in which the person resident outside India has
acquired and continues to hold the control in accordance with SEBI (Substantial Acquisition of
Shares and Takeover) Regulations, 2011 provided the right to receive dividend is established and the
dividend amount has been credited to a specially designated non-interest bearing rupee account for
acquisition of shares on the recognised stock exchange.(3)A wholly owned subsidiary set up in India
by a non-resident entity, operating in a sector where 100 percent foreign investment is allowed in
the automatic route and there are no FDI linked performance conditions, may issue capital
instruments to the said non-resident entity against pre-incorporation/ preoperative expenses
incurred by the said non-resident entity up to a limit of five percent of its authorised capital or USD
500,000 whichever is less, subject to the following conditions:(a)Within thirty days from the date of
issue of capital instruments but not later than one year from the date of incorporation or such time
as Reserve Bank or Central Government permits, the Indian company shall report the transaction in
the Form FC-GPR to the Reserve Bank;(b)A certificate issued by the statutory auditor of the Indian
company that the amount of pre-incorporation/ pre-operative expenses against which capital
instruments have been issued has been utilized for the purpose for which it was received should be
submitted with the Form FC-GPR.Explanation: Pre-incorporation/ pre-operative expenses shall
include amounts remitted to Investee Company's account, to the investor's account in India if it
exists, to any consultant, attorney or to any other material/ service provider for expenditure relating
to incorporation or necessary for commencement of operations.(4)[ An Indian company may issue,
subject to compliance with the conditions prescribed by the Central Government and/or the Reserve
Bank from time to time, capital instruments to a person resident outside India, if the Indian investee
company is engaged in an automatic route sector, against:(a)Swap of capital instruments;
or(b)Import of capital goods/ machinery/ equipment (excluding second-hand machinery);
or(c)Pre-operative/ pre-incorporation expenses (including payments of rent etc.).Provided
Government approval shall be obtained if the Indian investee company is engaged in a sector under
Government route. The applications for approval shall be made in the manner prescribed by the
Central Government from time to time.] [Substituted by Notification No. G.S.R. 279(E), dated
26.3.2018 (w.e.f. 7.11.2017).](5)An Indian company may issue equity shares against any fundsForeign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

payable by it to a person resident outside India, the remittance of which is permitted under the Act
or the rules and regulations framed or directions issued thereunder or does not require prior
permission of the Central Government or the Reserve Bank under the Act or the rules and
regulations framed or directions issued thereunder or has been permitted by the Reserve Bank
under the Act or the rules and regulations framed or directions issued thereunder.Provided in case
where permission has been granted by the Reserve Bank for making remittance, the Indian
company may issue equity shares against such remittance provided all regulatory actions with
respect to the delay or contravention under FEMA or the rules or the regulations framed thereunder
have been completed(6)[ ***] [Deleted by Notification No. G.S.R. 279(E), dated 26.3.2018 (w.e.f.
7.11.2017).](a)Swap of capital instruments if the Indian investee company is engaged in a sector
under Government route;(b)Import of capital goods/ machinery/ equipment (excluding
second-hand machinery) subject to compliance with the conditions specified by the Central
Government and the Reserve Bank from time to time; or(c)Pre-operative/ pre-incorporation
expenses (including payments of rent etc.), subject to compliance with the conditions specified by
the Central Government and the Reserve Bank from time to time.
2. Mode of payment. - (1) The amount of consideration shall be paid as
inward remittance from abroad through banking channels or out of funds
held in NRE/ FCNR(B)/ Escrow account maintained in accordance with the
Foreign Exchange Management (Deposit) Regulations, 2016.
Explanation: The amount of consideration shall include:(i)Issue of equity shares by an Indian
company against any funds payable by it to the investor(ii)Swap of capital instruments.(2)Capital
instruments shall be issued to the person resident outside India making such investment within
sixty days from the date of receipt of the consideration.Explanation: In case of partly paid equity
shares, the period of 60 days shall be reckoned from the date of receipt of each call
payment(3)Where such capital instruments are not issued within sixty days from the date of receipt
of the consideration the same shall be refunded to the person concerned by outward remittance
through banking channels or by credit to his NRE/ FCNR(B) accounts, as the case may be within
fifteen days from the date of completion of sixty days.Provided Prior approval of the Reserve Bank
shall be required for payment of interest, if any, as laid down in the Companies Act, 2013, for delay
in refund of the amount so received.(4)An Indian company issuing capital instruments under this
Schedule may open a foreign currency account with an Authorised Dealer in India in accordance
with Foreign Exchange Management (Foreign currency accounts by a person resident in India)
Regulations, 2016.
3. Remittance of sale proceeds. - The sale proceeds (net of taxes) of the
capital instruments may be remitted outside India or may be credited to the
NRE/ FCNR(B) of the person concerned.Foreign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

Schedule 2
[See Regulation 5(2)]Purchase/ Sale of capital instruments of a listed Indian company on a
recognised stock exchange in India byForeign Portfolio Investors
1. Purchase/sale of capital instruments. - A Foreign Portfolio Investor (FPI)
may purchase or sell capital instruments of an Indian company on a
recognised stock exchange in India subject to the following conditions.
(1)The total holding by each FPI or an investor group as referred in SEBI (FPI) Regulations, 2014,
shall be less than 10 percent of the total paid-up equity capital on a fully diluted basis or less than 10
percent of the paid-up value of each series of debentures or preference shares or share warrants
issued by an Indian company and the total holdings of all FPIs put together shall not exceed 24
percent of paid-up equity capital on a fully diluted basis or paid up value of each series of debentures
or preference shares or share warrants. The said limit of 10 percent and 24 percent will be called the
individual and aggregate limit, respectively. Provided the aggregate limit of 24 percent may be
increased by the Indian company concerned up to the sectoral cap/ statutory ceiling, as applicable,
with the approval of its Board of Directors and its General Body through a resolution and a special
resolution, respectively.(2)In case the total holding of an FPI increases to 10 percent or more of the
total paid-up equity capital on a fully diluted basis or 10 percent or more of the paid-up value of
each series of debentures or preference shares or share warrants issued by an Indian company, the
total investment made by the FPI shall be re-classified as FDI subject to the conditions as specified
by Securities and Exchange Board of India and the Reserve Bank in this regard and the investee
company and the investor complying with the reporting requirements prescribed in regulation 13 of
these Regulations.(3)An FPI may purchase capital instruments of an Indian company through
public offer/ private placement, subject to the individual and aggregate limits prescribed under this
Schedule.Provided:(i)in case of Public Offer, the price of the shares to be issued is not less than the
price at which shares are issued to residents, and(ii)in case of issue by private placement, the price is
not less than (a) the price arrived in terms of guidelines issued by the Securities and Exchange
Board of India, or (b) the fair price worked out as per any internationally accepted pricing
methodology for valuation of shares on arm's length basis, duly certified by a Securities and
Exchange Board of India registered Merchant Banker or Chartered Accountant or a practicing Cost
Accountant, as applicable(4)An FPI may, undertake short selling as well as lending and borrowing
of securities subject to such conditions as may be stipulated by the Reserve Bank and the Securities
and Exchange Board of India from time to time.(5)Investments made under this schedule shall be
subject to the limits and margin requirements prescribed by the Reserve Bank/ Securities and
Exchange Board of India as well as the stipulations regarding collateral securities as specified by the
Reserve Bank from time to time.
2. Mode of payment. - (1) The amount of consideration shall be paid as
inward remittance from abroad through banking channels or out of funds
held in a foreign currency account and/ or a Special Non-Resident RupeeForeign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

(SNRR) account maintained in accordance with the Foreign Exchange
Management (Deposit) Regulations, 2016.
(2)The foreign currency account and SNRR account shall be used only and exclusively for
transactions under this Schedule
3. Remittance of sale proceeds. - The sale proceeds (net of taxes) of the
investments made under this schedule may be remitted outside India or may
be credited to the foreign currency account or a SNRR account of the FPI.
4. Saving. - All investments made by deemed FPIs in accordance with the
regulations prior to their registration as FPI shall be continued to be valid
and taken into account for computation of aggregate limits.
Schedule 3
[See Regulation 5(3)]Purchase/ Sale of Capital Instruments of a listed Indian company on a
recognised stock exchange in India by Non-Resident Indian (NRI) or Overseas Citizen of India
(OCI) on repatriation basis
1. Purchase/sale of capital instruments. - A Non-resident Indian (NRI) or an
Overseas Citizen of India (OCI) may purchase or sell Capital Instruments of a
listed Indian company on repatriation basis, on a recognised stock exchange
in India, subject to the following conditions:
(1)NRIs or OCIs may purchase and sell Capital Instruments through a branch designated by an
Authorised Dealer for the purpose;(2)The total holding by any individual NRI or OCI shall not
exceed 5 percent of the total paid-up equity capital on a fully diluted basis or should not exceed 5
percent of the paid-up value of each series of debentures or preference shares or share warrants
issued by an Indian company and the total holdings of all NRIs and OCIs put together shall not
exceed ten percent of the total paid-up equity capital on a fully diluted basis or shall not exceed ten
percent of the paid-up value of each series of debentures or preference shares or share warrants;
Provided that the aggregate ceiling of 10 percent may be raised to 24 percent if a special resolution
to that effect is passed by the General Body of the Indian company.
2. Mode of payment. - (1) The amount of consideration shall be paid as
inward remittance from abroad through banking channels or out of funds
held in a Non-Resident External (NRE) account maintained in accordance
with the Foreign Exchange Management (Deposit) Regulations, 2016.Foreign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

(2)The NRE account will be designated as an NRE (PIS) Account and the designated account shall
be used exclusively for putting through transactions permitted under this Schedule.
3. Remittance of sale proceeds. - The sale proceeds (net of taxes) of the
capital instruments may be remitted outside India or may be credited to NRE
(PIS) account of the person concerned.
4. Saving. - Any account designated as NRO (PIS) shall be re-designated as
NRO account.
Schedule 4
[See Regulation 5(4)]Investment on non-repatriation basisA. Purchase or Sale of Capital
Instruments or convertible notes of an Indian company or Units or contribution to the capital of an
LLP by Non-Resident Indian (NRI) or Overseas Citizen of India (OCI) on Non-Repatriation basis
1. Purchase/ sale of capital instruments or convertible notes or units or
contribution to the capital of an LLP. - (1) A Non-resident Indian (NRI) or an
Overseas Citizen of India (OCI), including a company, a trust and a
partnership firm incorporated outside India and owned and controlled by
NRIs or OCIs, may purchase/ contribute, as the case may be, on
non-repatriation basis the following:
(a)Any capital instrument issued by a company without any limit either on the stock exchange or
outside it.(b)Units issued by an investment vehicle without any limit, either on the stock exchange
or outside it.(c)The capital of a Limited Liability Partnership without any limit.(d)Convertible notes
issued by a startup company in accordance with these Regulations.(2)The investment detailed at
sub-para 1 above will be deemed to be domestic investment at par with the investment made by
residents
2. Prohibition on purchase of capital instruments of certain companies. -
Notwithstanding anything contained in paragraph 1, an NRI or an OCI
including a company, a trust and a partnership firm incorporated outside
India and owned and controlled by NRIs or OCIs, shall not make any
investment, under this Schedule, in capital instruments or units of a Nidhi
company or a company engaged in agricultural/ plantation activities or real
estate business or construction of farm houses or dealing in Transfer of
Development Rights.
Explanation : Real estate business will have the same meaning as laid down in regulation 16.Foreign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

3. Mode of Payment. - The amount of consideration shall be paid as inward
remittance from abroad through banking channels or out of funds held in
NRE/ FCNR(B)/ NRO account maintained in accordance with the Foreign
Exchange Management (Deposit) Regulations, 2016.
4. Sale/ maturity proceeds. - (1) The sale/ maturity proceeds (net of applicable
taxes) of capital instruments purchased or disinvestment proceeds of a LLP
shall be credited only to the NRO account of the investor, irrespective of the
type of account from which the consideration was paid;
(2)The amount invested in capital instruments of an Indian company or the consideration for
contribution to the capital of a LLP and the capital appreciation thereon shall not be allowed to be
repatriated abroad.B. Investment in a firm or a proprietary concern
1. Contribution to capital of a firm or a proprietary concern. - An NRI or an
OCI may invest, on a non-repatriation basis, by way of contribution to the
capital of a firm or a proprietary concern in India provided such firm or
proprietary concern is not engaged in any agricultural/plantation activity or
print media or real estate business.
Explanation: Real estate business will have the same meaning as laid down in regulation 16.
2. Mode of payment. - The amount of consideration shall be paid as inward
remittance from abroad through banking channels or out of funds held in
NRE/ FCNR(B)/ NRO account maintained in accordance with the Foreign
Exchange Management (Deposit) Regulations, 2016.
3. Sale/ maturity proceeds. - (1) The disinvestment proceeds shall be credited
only to the NRO account of the person concerned, irrespective of the type of
account from which the consideration was paid;
(2)The amount invested for contribution to the capital of a firm or a proprietary concern and the
capital appreciation thereon shall not be allowed to be repatriated abroad.
Schedule 5
[See Regulation 5(5)]Purchase and sale of securities other than capital instruments by a person
resident outside IndiaForeign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

1. Permission to persons resident outside India
A. Permission to Foreign Portfolio Investors (FPIs). - An FPI may purchase the following
instruments on repatriation basis subject to the terms and conditions specified by the Securities and
Exchange Board of India and the Reserve Bank:(a)dated Government securities/ treasury
bills;(b)non-convertible debentures/ bonds issued by an Indian company;(c)commercial papers
issued by an Indian company;(d)units of domestic mutual funds;(e)Security Receipts (SRs) issued
by Asset Reconstruction Companies up to 100 percent of each tranche, subject to directions/
guidelines of the Reserve Bank;(f)Perpetual Debt instruments eligible for inclusion as Tier I capital
and Debt capital instruments as upper Tier II capital issued by banks in India to augment their
capital (Tier I capital and Tier II capital as defined by Reserve Bank) provided that the investment
by all eligible investors in Perpetual Debt instruments (Tier I) shall not exceed an aggregate ceiling
of 49 percent of each issue and investment by a single FPI shall not exceed the limit of 10 percent of
each issue;(g)non-convertible debentures/ bonds issued by Non-Banking Financial Companies
categorized as 'Infrastructure Finance Companies'(IFCs) by the Reserve Bank;Provided this will
include such instruments issued on or after November 3, 2011 and held by deemed FPIs;(h)Rupee
denominated bonds/ units issued by Infrastructure Debt Funds;Provided this will include such
instruments issued on or after November 22, 2011 and held by deemed FPIs.(i)Credit enhanced
bonds;(j)Listed non-convertible/ redeemable preference shares or debentures issued in terms of
Regulation 9 of these Regulations;(k)Security receipts issued by securitization companies subject to
conditions as specified by the Reserve Bank and/ or Securities and Exchange Board of
India;(l)Securitised debt instruments, including (i) any certificate or instrument issued by a special
purpose vehicle (SPV) set up for securitisation of asset/s with banks, Financial Institutions or
NBFCs as originators; and/ or (ii) any certificate or instrument issued and listed in terms of the
Securities and Exchange Board of India (Regulations on Public Offer and Listing of Securitised Debt
Instruments), 2008.(m)[ Municipal bonds.] [Added by Notification No. G.S.R. 312(E), dated
18.4.2019 (w.e.f. 7.11.2017).]Provided that FPIs may offer such instruments as permitted by the
Reserve Bank from time to time as collateral to the recognized Stock Exchanges in India for their
transactions in exchange traded derivative contracts as specified in sub-Regulation 5 of Regulation
5.B. Permission to Non-resident Indians (NRIs) or Overseas Citizens of India (OCIs) - Repatriation
basis. - (1) A Non-resident Indian (NRI) or an Overseas Citizen of India (OCI) may, without limit,
purchase the following instruments on repatriation basis,(a)Government dated securities (other
than bearer securities) or treasury bills or units of domestic mutual funds;(b)Bonds issued by a
Public Sector Undertaking (PSU) in India;(c)Shares in Public Sector Enterprises being disinvested
by the Central Government, provided the purchase is in accordance with the terms and conditions
stipulated in the notice inviting bids;(d)Bonds/ units issued by Infrastructure Debt Funds;(e)Listed
non-convertible/ redeemable preference shares or debentures issued in terms of Regulation 9 of
these Regulations;(2)An NRI or an OCI may purchase on repatriation basis perpetual debt
instruments eligible for inclusion as Tier I capital and Debt capital instruments as upper Tier II
capital issued by banks in India to augment their capital, as stipulated by Reserve Bank. The
investments by all NRIs or OCIs in Perpetual Debt Instruments (Tier I) should not exceed an
aggregate ceiling of 24 percent of each issue and investments by a single NRI or OCI should not
exceed 5 percent of each issue. Investment by NRIs or OCIs in Debt Capital Instruments (Tier II)
shall be accordance with the extant policy for investment by NRIs or OCIs in other debtForeign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

instruments.(3)An NRI may subscribe to National Pension System governed and administered by
Pension Fund Regulatory and Development Authority (PFRDA), provided such person is eligible to
invest as per the provisions of the PFRDA Act. The annuity/ accumulated saving will be
repatriable.Provided that NRI/ OCIs may offer such instruments as permitted by the Reserve Bank
from time to time as collateral to the recognized Stock Exchanges in India for their transactions in
exchange traded derivative contracts as specified in sub-Regulation 5 of Regulation 5.C. Permission
to Non-resident Indians (NRIs) or Overseas Citizens of India (OCIs) - Non-Repatriation basis. - (1)
An NRI or an OCI may, without limit, purchase on non-repatriation basis, dated Government
securities (other than bearer securities), treasury bills, units of domestic mutual funds, units of
money Market Mutual Funds, or National Plan/ Savings Certificates.(2)An NRI or an OCI may,
without limit, purchase on non-repatriation basis, listed non-convertible/ redeemable preference
shares or debentures issued in terms of Regulation 9 of these Regulations.(3)An NRI or an OCI may,
without limit, on non-repatriation basis subscribe to the chit funds authorised by the Registrar of
Chits or an officer authorised by the State Government in this behalf.D. Permission to Foreign
Central Banks or a Multilateral Development Bank for purchase of Government Securities. - (1) A
Foreign Central Bank may purchase and sell dated Government securities/ treasury bills in the
secondary market subject to the conditions as may be stipulated by the Reserve Bank.(2)A Foreign
Central Bank, may purchase and sell dated Government securities/ treasury bills subject to the
conditions as may be stipulated by Reserve Bank.(3)A Multilateral Development Bank which is
specifically permitted by Government of India to float rupee bonds in India may purchase
Government dated securities.E. Permission to other non-resident investors for purchase of
securities. - (1) Long term investors like Sovereign Wealth Funds (SWFs), Multilateral Agencies,
Endowment Funds, Insurance Funds, Pension Funds which are registered with Securities and
Exchange Board of India as eligible investors in Infrastructure Debt Funds may purchase on
repatriation basis Rupee Denominated bonds/ units issued by Infrastructure Debt Funds.(2)Long
term investors like Sovereign Wealth Funds (SWFs), Multilateral Agencies, Endowment Funds,
Insurance Funds, Pension Funds and Foreign Central Banks registered with Securities and
Exchange Board of India may purchase, on repatriation basis the following instruments and subject
to such terms and conditions as may be specified by the Reserve Bank and the Securities and
Exchange Board of India:(a)dated Government securities/ treasury bills;(b)commercial papers
issued by an Indian company;(c)units of domestic mutual funds;(d)listed non-convertible
debentures/ bonds issued by an Indian company;(e)listed and unlisted non-convertible debentures/
bonds issued by an Indian company in the infrastructure sector. The term 'Infrastructure Sector' has
the same meaning as given in the Harmonised Master List of Infrastructure sub-sectors approved by
Government of India vide Notification F. No. 13/06/2009-INF dated March 27, 2012 as amended/
updated;(f)non-convertible debentures/bonds issued by Non-Banking Finance Companies
categorized as 'Infrastructure Finance Companies (IFCs)' by the Reserve Bank;(g)security Receipts
(SRs) issued by Asset Reconstruction Companies up to 100 percent of each tranche, subject to
directions/ guidelines of the Reserve Bank;(h)perpetual Debt instruments eligible for inclusion as
Tier I capital and Debt capital instruments as upper Tier II capital issued by banks in India to
augment their capital (Tier I capital and Tier II capital as defined by Reserve Bank) provided that
the investment by all eligible investors in Perpetual Debt instruments (Tier I) shall not exceed an
aggregate ceiling of 49 percent of each issue, and investment by a single long term investor shall not
exceed the limit of 10 pe cent of each issue;(i)primary issues of non-convertible debentures/ bondsForeign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

provided such non-convertible debentures/ bonds are committed to be listed within 15 days of such
investment. In the event of the instruments not being listed within 15 days of issuance then the long
term investor shall immediately dispose such instruments by way of sale to a third party or to the
issuer and the terms of offer to the long term investors should contain a clause that the issuer of
such instruments shall immediately redeem/ buyback those securities from the long term investors
in such an eventuality;(j)credit enhanced bonds;(k)listed non-convertible/ redeemable preference
shares or debentures issued in terms of Regulation 9 of these Regulations;(l)security receipts (SRs)
issued by securitization companies subject to conditions as specified by Reserve Bank and/ or
Securities and Exchange Board of India
2. Mode of Payment. - (1) The amount of consideration for purchase of
instruments by FPIs shall be paid out of inward remittance from abroad
through banking channels or out of funds held in a foreign currency account
and/ or Special Non-Resident Rupee (SNRR) account maintained in
accordance with the Foreign Exchange Management (Deposit) Regulations,
2016. The foreign currency account and SNRR account shall be used only
and exclusively for transactions under this Schedule.
(2)The amount of consideration for purchase of instruments by NRIs or OCIs on repatriation basis
shall be paid out of inward remittances from abroad through banking channels or out of funds held
in NRE/ FCNR(B) account maintained in accordance with the Foreign Exchange Management
(Deposit) Regulations, 2016.(3)The amount of consideration for (a) purchase of instruments by
NRIs or OCIs on non-repatriation basis and (b) subscriptions to the National Pension System by
NRIs shall be paid out of inward remittances from abroad through banking channels or out of funds
held in NRE/ FCNR(B)/ NRO account maintained in accordance with the Foreign Exchange
Management (Deposit) Regulations, 2016.(4)The amount of consideration for purchase of
Government dated securities by a Foreign Central Bank or a Multilateral Development Bank shall be
paid out of inward remittances from abroad through banking channels or out of funds held in an
account opened with the specific approval of the RBI.(5)The amount of consideration for purchase
of instruments by other non-resident investors shall be paid out of inward remittances from abroad
through banking channels.
3. Permission for Sale of instruments. - A person resident outside India who
has purchased instruments in accordance with this Schedule may sell/
redeem the instruments subject to such terms and conditions as may be
specified by the Reserve Bank and the Securities Exchange Board of India.
4. Remittance/ credit of sale/ maturity proceeds. - (1) The sale/ maturity
proceeds (net of taxes) of instruments held by Foreign Portfolio Investors
(FPIs) may be remitted outside India or may be credited to the foreign
currency account or SNRR account of the FPI.Foreign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

(2)The net sale/ maturity proceeds (net of taxes) of instruments held by NRIs or OCIs, may
be:(a)Credited to the NRO account person concerned where the instruments were held on
non-repatriation basis(b)Credited to the NRO account person concerned where the payment for the
purchase of the instruments sold was made out of funds held in NRO account, or(c)Remitted abroad
or at the NRI/ OCI investor's option, credited to his NRE/ FCNR(B)/ NRO account, where the
instruments were purchased on repatriation basis.(3)In all other cases, the sale/ maturity proceeds
(net of taxes) may be remitted abroad or credited to an account opened with the prior permission of
the Reserve Bank.
Schedule 6
[See Regulation 5(6)]Investment in a Limited Liability Partnership (LLP)
1. Investment in an LLP. - (1) A person resident outside India (other than a
citizen of Pakistan or Bangladesh) or an entity incorporated outside India
(other than an entity incorporated in Pakistan or Bangladesh), not being a
Foreign Portfolio Investor (FPI) or a Foreign Venture Capital Investor (FVCI),
may contribute to the capital of an LLP operating in sectors/ activities where
foreign investment up to 100 percent is permitted under automatic route and
there are no FDI linked performance conditions.
(2)Investment by way of 'profit share' will fall under the category of reinvestment of
earnings(3)Investment in an LLP is subject to the compliance of the conditions of Limited Liability
Partnership Act, 2008.(4)A company having foreign investment, engaged in a sector where foreign
investment up to 100 percent is permitted under the automatic route and there are no FDI linked
performance conditions, can be converted into an LLP under the automatic route.(5)An LLP having
foreign investment, engaged in a sector where foreign investment up to 100 percent is permitted
under the automatic route and there are no FDI linked performance conditions, may be converted
into a company under the automatic route.(6)Investment in an LLP either by way of capital
contribution or by way of acquisition/ transfer of profit shares, should not be less than the fair price
worked out as per any valuation norm which is internationally accepted/ adopted as per market
practice (hereinafter referred to as "fair price of capital contribution/ profit share of an LLP") and a
valuation certificate to that effect shall be issued by the Chartered Accountant or by a practicing Cost
Accountant or by an approved valuer from the panel maintained by the Central Government.(7)In
case of transfer of capital contribution/ profit share from a person resident in India to a person
resident outside India, the transfer shall be for a consideration not less than the fair price of capital
contribution/ profit share of an LLP. Further, in case of transfer of capital contribution/ profit share
from a person resident outside India to a person resident in India, the transfer shall be for a
consideration which is not more than the fair price of the capital contribution/ profit share of an
LLP.Foreign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

2. Mode of payment. - Payment by an investor towards capital contribution of
an LLP shall be made by way of an inward remittance through banking
channels or out of funds held in NRE or FCNR(B) account maintained in
accordance with the Foreign Exchange Management (Deposit) Regulations,
2016.
3. Remittance of disinvestment proceeds. - The disinvestment proceeds may
be remitted outside India or may be credited to NRE or FCNR(B) account of
the person concerned.
Schedule 7
[See Regulation 5(7)]Investment by a Foreign Venture Capital Investor (FVCI)
1. Investment by Foreign Venture Capital Investor. - (1) Subject to the terms
and conditions as may be laid down by the Reserve Bank, a Foreign Venture
Capital Investor (FVCI) may purchase
(a)securities, issued by an Indian company engaged in any sector mentioned at para 4 of this
Schedule and whose securites are not listed on a recognised stock exchange at the time of issue of
the said securities;(b)securities issued by a startup;(c)units of a Venture Capital Fund (VCF) or of a
Category I Alternative Investment Fund (Cat-I AIF) or units of a scheme or of a fund set up by a VCF
or by a Cat-I AIF.Provided if the investment is in capital instruments, then the sectoral caps, entry
routes and attendant conditions shall apply;(2)An FVCI may purchase the securities/ instruments
mentioned above either from the issuer of these securities/ instruments or from any person holding
these securities/ instruments. The FVCI may invest in securities on a recognized stock exchange
subject to the provisions of the Securities and Exchange Board of India (FVCI) Regulations,
2000.(3)The FVCI may acquire, by purchase or otherwise, from, or transfer, by sale or otherwise, to,
any person resident in or outside India, any security/ instrument it is allowed to invest in, at a price
that is mutually acceptable to the buyer and the seller/ issuer. The FVCI may also receive the
proceeds of the liquidation ofVCFs or of Cat-I AIFs or of schemes/ funds set up by the VCFs or Cat-I
AIFs.
2. Mode of payment. - (1) The amount of consideration shall be paid as
inward remittance from abroad through banking channels or out of funds
held in a foreign currency account and/ or a Special Non-Resident Rupee
(SNRR) account maintained in accordance with the Foreign Exchange
Management (Deposit) Regulations, 2016.
(2)The foreign currency account and SNRR account shall be used only and exclusively for
transactions under this Schedule.Foreign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

3. Remittance of sale/ maturity proceeds. - The sale/ maturity proceeds (net
of taxes) of the securities may be remitted outside India or may be credited to
the foreign currency account or a Special Non-resident Rupee Account of the
FVCI.
4. List of sectors in which a Foreign Venture Capital Investor is allowed to
invest
(1)Biotechnology(2)IT related to hardware and software development(3)Nanotechnology(4)Seed
research and development(5)Research and development of new chemical entities in pharmaceutical
sector(6)Dairy industry(7)Poultry industry(8)Production of bio-fuels(9)Hotel-cum-convention
centres with seating capacity of more than three thousand.(10)Infrastructure sector. The term
'Infrastructure Sector' has the same meaning as given in the Harmonised Master List of
Infrastructure sub-sectors approved by Government of India vide Notification F. No.
13/06/2009-INF dated March 27, 2012 as amended/ updated.
Schedule 8
[See Regulation 5(8)]Investment by a person resident outside India in an Investment Vehicle
1. Investment in units of an Investment Vehicle. - (1) A person resident
outside India (other than a citizen of Pakistan or Bangladesh) or an entity
incorporated outside India (other than an entity incorporated in Pakistan or
Bangladesh) may invest in units of Investment Vehicles.
(2)A person resident outside India who has acquired or purchased units in accordance with this
Schedule may sell or transfer in any manner or redeem the units as per regulations framed by
Securities and Exchange Board of India or directions issued by the Reserve Bank.(3)An Investment
vehicle may issue its units to a person resident outside India against swap of capital instruments of a
Special Purpose Vehicle (SPV) proposed to be acquired by such Investment Vehicle.(4)Investment
made by an Investment Vehicle into an Indian entity shall be reckoned as indirect foreign
investment for the investee Indian entity if the Sponsor or the Manager or the Investment Manager
(i) is not owned and not controlled by resident Indian citizens or (ii) is owned or controlled by
persons resident outside India.Provided that for sponsors or managers or investment managers
organized in a form other than companies or LLPs, Securities and Exchange Board of India shall
determine whether the sponsor or manager or investment manager is foreign owned and
controlled.Explanation: 'Control' of the AIF should be in the hands of 'sponsors' and 'managers/
investment managers', with the general exclusion to others. In case the 'sponsors and 'managers/
investment managers' of the AIF are individuals, for the treatment of downstream investment by
such AIF as domestic, 'sponsors' and 'managers/ investment managers' should be resident Indian
citizens.(5)An Alternative Investment Fund Category III which has received any foreign investment
shall make portfolio investment in only those securities or instruments in which a FPI is allowed to
invest under the Act, rules or regulations made thereunder.Foreign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

2. Mode of payment. - The amount of consideration shall be paid as inward
remittance from abroad through banking channels or by way of swap of
shares of a Special Purpose Vehicle or out of funds held in NRE or FCNR(B)
account maintained in accordance with the Foreign Exchange Management
(Deposit) Regulations, 2016.
3. Remittance of sale/ maturity proceeds. - The sale/ maturity proceeds (net
of taxes) of the units may be remitted outside India or may be credited to the
NRE or FCNR(B) account of the person concerned.
Schedule 9
[See Regulation 5(9)]Investment in Depository receipts by a person resident outside India
1. Issue/ transfer of eligible instruments to a foreign depository for the
purpose of issuance of depository receipts by eligible person(s). - (1) Any
security or unit in which a person resident outside India is allowed to invest
under these regulations shall be eligible instruments for issue of Depository
Receipts in terms of Depository Receipts Scheme, 2014 (DR Scheme, 2014).
(2)A person will be eligible to issue or transfer eligible instruments to a foreign depository for the
purpose of issuance of depository receipts in accordance with the DR Scheme, 2014 and guidelines
issued by Central Government in this regard.(3)A domestic custodian may purchase eligible
instruments on behalf of a person resident outside India, for the purpose of converting the
instruments so purchased into depository receipts in terms of DR Scheme 2014.(4)The aggregate of
eligible instruments which may be issued or transferred to foreign depositories, along with eligible
instruments already held by persons resident outside India, shall not exceed the limit on foreign
holding of such eligible instruments under the Act, rules or regulations framed thereunder.(5)The
eligible instruments shall not be issued or transferred to a foreign depository for the purpose of
issuing depository receipts at a price less than the price applicable to a corresponding mode of issue
or transfer of such instruments to domestic investors under the applicable laws.
2. Saving. - Depository Receipts issued under the Issue of Foreign Currency
Convertible Bonds and Ordinary Shares (Through Depository Receipt
Mechanism) Scheme, 1993 shall be deemed to have been issued under the
corresponding provisions of DR Scheme 2014 and have to comply with the
provisions laid out in this Schedule.Foreign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017

