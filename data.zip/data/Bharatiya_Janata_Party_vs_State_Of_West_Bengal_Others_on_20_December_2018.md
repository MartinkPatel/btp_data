Bharatiya Janata Party vs State Of West Bengal & Others on 20
December, 2018
Author: Tapabrata Chakraborty
Bench: Tapabrata Chakraborty
                                                   1
     20.12.18
            Item No.13
            Court No.15
              rpan
           W.P. No. 25614 (W) of 2018
           Bharatiya Janata Party
                  - Versus -
       State of West Bengal & Others
  Mr. S. K. Kapoor,
  Mr. Saptangsu Basu,
  Mr. Kumar Jyoti Tewari,
  Mr. Phiroze Edulji,
  Mr. Rajdeep Biswas,
  Mr. Brajesh Jha,
  Mr. Tarun Jyoti Tewari,
  Mr. Subassis Das Gupta,
  Mr. Rajdeep Biswas,
  Mr. Indrajit Das Gupta,
  Mr. Subhas Ray,
  Mr. Gautam Sardar,
  Mr. Pradip Kumar Mondal,
  Mr. Soumen Sarkar,
  Ms. Mainalini Majumdar,
  Mr. C. S. Jha,
  Mr. Soumen Bhattacharya,
  Ms. Debjani Ghosal,
  Mr. Pramod Kumar Darolia,
  Mr. Daya Sankar Mishra,
  Mr. Ravi Ranjan Kumar,
  Mr. Manabendra Bandopadhyay,
  Mr. Chirantan Dan,
  Mr. Debasis Saha,
  Mr. Partha Ghosh,
  Mr. Subhojit Seal
                    ... for the petitioner.
  Mr. Kishore Datta, Ld. A. G.,
  Mr. Abhratosh Majumdar, Ld. A.A.G.,
  Mr. Sirsanya Bandopadhyay,
  Ms. S. Shaw,Bharatiya Janata Party vs State Of West Bengal & Others on 20 December, 2018

  Mr. Arka Kumar Nag
                   ... for the State respondents.
Mr. Anand Grover, Mr. Suhaan Mukherji, Ms. Kajal Dalal ... for the respondent nos.5-6.
The present writ petition has been preferred challenging inter alia an order dated 15th December,
2018 passed by the Chief Secretary, Government of West Bengal, the Principal Secretary,
Department of Home & Hill Affairs and the Director General of Police, Government of West Bengal,
being the respondent nos.2, 3 and 4 respectively.
Shorn of unnecessary details the facts are that the petitioner is the West Bengal Unit of Bharatiya
Janata Party, a political party within the meaning of the Representation of People Act, 1951. A
programme was undertaken by the petitioner to organise three yatras/rallies under the banner of
"Ganatantra Banchao Yatra". By a letter dated 29th October, 2018, the respondent no.3 was
requested to allow a small delegation of the petitioner to meet with him on 5th November, 2018 or
earlier as per his convenience to place the programme itineraries and other details. A similar prayer
was made to the Home Secretary, Government of West Bengal through a letter dated 5th November,
2018. As the said letters were not responded to, a further letter was submitted to the Home
Secretary, Government of West Bengal on 12th November, 2018. Intimating the respondent no.2
about some changes in the overall plan of the yatras/rallies itineraries, a further letter was issued on
20th November, 2018 attaching the synopsis of yatra / rally programmes. In the midst thereof
another letter was issued to the respondent no.4 on 14th November, 2018 giving the details of three
yatras/rallies. On and from 26th November, 2018 to 5th December, 2018 several letters were also
issued by the petitioner to the Superintendents of Police and the District Magistrates of various
districts. None of the said letters was replied to and aggrieved thereby the petitioner preferred a writ
petition, being W. P. No.24263 (W) of 2018 inter alia praying for issuance of necessary directions
upon the respondents to grant permission to organise the three yatras/rallies. The said writ petition
was listed for hearing on 4th December, 2018 and was taken up for hearing on 5th December, 2018.
In course of hearing on 5th December, 2018, Mr. Datta, learned Advocate-General appearing for the
respondent nos.1, 2 and 3 submitted that the petitioner's prayer would be considered by the
competent authority and a decision would be taken and that he would be apprising the Court about
such decision on 6th December, 2018. On 6th December, 2018, Mr. Datta placed before this Court a
letter dated 5th December, 2018, issued by the District Magistrate, Cooch Behar to the Additional
Secretary to the Government of West Bengal, Department of Home & Hill Affairs and a letter of the
same date issued by the Superintendent of Police, DIB, Cooch Behar to the respondent no.4. In both
the letters it was observed that permission for such yatras/rallies should not be granted. By an order
dated 6th December, 2018, passed in W. P. No. 24263 (W) of 2018, this Court issued a direction
upon the Superintendents of Police of all the districts to grant an opportunity of hearing to the
district president or the district secretary of the petitioner in the respective districts and to take a
decision as to whether permission can be granted to the petitioner to hold the rallies and to
communicate a decision to the petitioner peremptorily by 21st December, 2018 and the writ petition
was made returnable on 9th January, 2019. Aggrieved by the said order the petitioner preferred an
appeal, being MAT No.1522 of 2018 and in the same an order was passed on 7th December, 2018.
The operative part of the said order runs as follows:Bharatiya Janata Party vs State Of West Bengal & Others on 20 December, 2018

"In such circumstances as stated above, we propose to modify the order dated 6th
December, 2018, passed by the learned Single Judge as follows:
The Chief Secretary, Government of West Bengal, the Principal Secretary,
Department of Home & Hill Affairs and the Director General of Police, Government
of West Bengal, shall meet the authorised representatives of the appellant/writ
petitioner (not exceeding three) latest by next Wednesday (12.1.2.2018) and take a
decision in the matter supported with cogent reasons and communicate the same to
the appellant/writ petitioner by next Friday (14.12.2108)".
Pursuant to such direction the committee consisting of the respondent nos.2, 3 and 4 heard the
representatives of the petitioner and communicated an order dated 15th December, 2018.
Mr. Kapoor, learned senior counsel appearing for the petitioner submits that it would be explicit
from the impugned order that the decision communicated was at the behest of the State
Government. The committee constituted by the Hon'ble Appeal Court was vested with the authority
to decide the dispute but the order passed does not reflect any independent application of mind on
the part of the members of the said committee and as such, the said order is not sustainable in law.
From the contents of the said order passed by the Hon'ble Appeal Court, it would be explicit that the
Court reposed faith upon the highest officials of the State. However, the said officers rejected the
petitioner's prayer in a mechanical manner. The said committee did not even consider the
petitioner's representations forwarded to them by the Additional Secretary to the Hon'ble Governor.
He further submits that the perusal of the impugned order would reveal that the petitioner has been
denied permission to organise the yatras/rallies merely on the basis of an apprehension that the
yatras/rallies would lead to a major breach of peace and communal violence. Such apprehension is,
however, not based on requisite evidence. The consequence of such an order is very serious
inasmuch as the same affects the fundamental right of the petitioner.
Drawing the attention of this Court to a letter dated 5th December, 2018 issued by the
Superintendent of Police, DIB, Cooch Behar, which was produced on the date of hearing of the
earlier writ petition, he submits that the Superintendent of Police, DIB, Cooch Behar observed that
permission for such yatras/rallies should not be granted in the background of overall communal
scenario and happenings around the country and as the said district is highly sensitive. On the basis
of such vague intelligence input, the petitioner cannot be denied to organise the yatras/rallies.
Referring to a further letter issued on the self-same date by the District Magistrate, Cooch Behar to
the Chief Secretary to the Government of West Bengal, Department of Home & Hill Affairs, he
submits that the said officer observed that permission cannot be provided as the persons named
therein would be holding a meeting and their associates may be backed by communal forces. The
said observations are based on individualistic and egocentric perception of the concerned officers.
The State Government wants to stop the yatras/rallies on the basis of such vague inputs. The said
order has no reasonable basis and has been passed on mere surmises. As the State is not agreeable
to grant inspection of the intelligence inputs to the learned advocate appearing for the petitioner,
the Court need not look into the same. In support of such contention he has placed reliance upon aBharatiya Janata Party vs State Of West Bengal & Others on 20 December, 2018

judgment delivered in the case of Hindustan Motors Limited & Ors. vs. T. N. Kaul & ors., reported in
1971 CLJ 181.
According to Mr. Kapoor, holding of a yatra / rally, is a natural demonstration of political activities
of a political party and a decision to restrict or prohibit such yatra / rally must invoke an element of
subjectivity on cogent and convincing materials. The yatras/rallies cannot be restricted by law as
long as they are within the limits of public law and order. It is an inherent duty of the State to
maintain such law and order for which they can only impose reasonable restrictions. The highest
officials of the State, however, have totally denied such permission to the petitioner to hold such
yatras/rallies and have not even applied their minds and have not considered as to whether such
permission can be granted upon imposition of reasonable restrictions and as such the said order is
not sustainable in law and the petitioner should be permitted to hold the yatras/rallies, as prayed
for. In support of such argument, reliance has been placed upon a judgment delivered in the case of
State of West Bengal & Ors. vs. Dr. Anindya Gopal Mitra & Ors., reported in 1997 CWN 587.
Placing reliance upon the judgment delivered in the case of Ramlila Maidan (supra), Mr. Kapoor
submits that no person can be divested of his fundamental rights and they are incapable of being
taken away or abridged. All that State can do, by exercise of its legislative power, is to regulate those
rights by imposition of reasonable restriction on them. Such restriction must have a direct and
proximate nexus with the object sought to be achieved. Merely by making a statement that there is
an apprehension of breach of peace, the State cannot divest itself of its jurisdiction to ensure law and
order in society.
Per contra, Mr. Datta, learned Advocate General appearing for the respondent nos. 1 to 3 submits
that the right exercised under Article 19 of the Constitution of India is not an inchoate or absolute
right but is subject to the public order meaning thereby the sovereign can restrict and prohibit any
individual or group to conduct a yatra/rally. If an order is passed by the State of law and order, it
cannot be impinged on the ground of unreasonableness. The fact that the religious overtone of the
yatras/rallies will turn into communal propaganda would be explicit from the contents of the leaflets
annexed at page 212 of the writ petition. The State respondents should be allowed to use an
affidavit-in-opposition to specifically deal with the allegations levelled against them in the writ
petition.
He further submits that in the order dated 7th December, 2018 the Hon'ble Appeal Court has
observed that all the issues raised in the letters dated 5th December, 2018, as annexed at pages 176
to 178 of the present petition, may have serious consequences all over the State and that the issues
need to be considered by the highest officials of the State. The maintenance of the law and order is
within the realm of the executive powers and executive functions leave hardly any scope for
interference by the judiciary in exercise of the power of judicial review under Article 226 of the
Constitution of India. Wisdom in administrative action is the property of the executive and judicial
interference is very limited.
He further submits that a perusal of the impugned order would reveal that the decision denying
permission to the petitioner to organize such yatras/rallies stand supported with requisite evidenceBharatiya Janata Party vs State Of West Bengal & Others on 20 December, 2018

and is an informed decision. The same is neither perverse nor illogical and has not been issued on
extraneous consideration. When the order was passed by the highest officials of the State, it should
be presumed that the discretion vested in such high authority will not be an abuse. There is always a
presumption that public officers discharge their duties honestly and in accordance with the rules of
law. The Court should not go into the correctness of the decision taken by the highest officers of the
State and it should not substitute its own decision. Scope of judicial review is limited to the
deficiency in the decision making process and not the decision, otherwise the rule of law would
stand replaced by the individual perception.
In support of such argument, reliance has been placed upon the judgments delivered in the case of
Organo Chemical Industries & Anr. Vs. Union of India & Ors. reported in (1979) 4 SCC 573, Ram
Saran vs. IG of Police CRPF & Ors. reported in (2006) 2 SCC 541, State of Karnataka & Anr. Vs. Dr.
Praveen Bhai Thogadia reported in (2004) 4 SCC 684, State of U.P. & Anr. Vs. Johri Mal reported in
(2004) 4 SCC 714, State of U.P. & Ors. vs. Rakesh Kumar Keshari & Anr. reported in (2011) 5 SCC
341, Dharam Chand vs. Chairman, New Delhi Municipal Council & Ors. reported in (2015) 10 SCC
612, State of Punjab & Anr. Vs. Gurdial Singh & Ors. reported in (1980) 2 SCC 471.
Drawing the attention of this Court, provision of Section 12 of the Police Act, 1861 and Regulation
134 of the Police Regulation of Bengal he submits that on the basis of authority conferred by Section
12, regulations have been framed which permit the State to refuse permission with a view to secure
public safety and convenience.
He further submits that the expression 'regulation' is a term which is capable of being interpreted
broadly and that in a given case, it may amount to total prohibition. The decision taken to that effect
by the highest officials of the State is based on the intelligence inputs received from several districts
and as such it cannot be argued that the decision is perverse. Such a decision taken by the highest
officials of the State do not have adjudicative disposition and may not strictly fall for consideration
before a judicial review court. In support of such argument reliance has been placed upon a
judgment delivered in the case of Talcher Municipality vs. Talcher Regulated Market Committee &
Anr. reported in (2004) 6 SCC 178.
Placing reliance upon a judgment delivered in the case of Wasiuddin Ahmed vs. District Magistrate,
Aligarh, U.P. and others reported in (1981) 4 SCC 521, Mr. Datta submits that there is no provision
towards supply of copy of the intelligence inputs as received by the State to the petitioner. On the
basis of the said inputs, the highest officials of the State, in exercise of their discretion have decided
to deny permission to the petitioner. Such a decision can neither be termed as perverse nor it can be
said to be unreasonable.
Mr. Datta further submits that judgment delivered in the case of Himmatlal vs. Commissioner of
Police, Ahmedabad & Ors. reported in (1973) 1 SCC 227 is not applicable to the facts of the present
case inasmuch as the Court was only dealing with the rules pertaining to holding of public meeting
and the rule for any procession was not under challenge in the same.Bharatiya Janata Party vs State Of West Bengal & Others on 20 December, 2018

Reliance has also placed on the judgment in the case of Ramlila Maidan Incident In Re: reported in
(2012) 5 SCC 1 in support of his argument that for maintenance of public order the State has every
authority to restrict a procession and that public order as referred to under Article 19(2) of the
Constitution of India may qualify for a greater degree of restriction.
Mr. Datta submits that the judgment delivered in the case of Dr. Anindya Gopal Mitra (supra) is
totally distinguishable on facts inasmuch as the Court was considering an issue pertaining to refusal
of permission in respect of a meeting held in a single date. In the instant case the petitioner wants to
organize three rallies and from the averments made in paragraph 29 of the writ petition it has been
stated by the petitioner that each of such rally is expected to be of 1,500 persons. The judgment
delivered in the case of Hindustan Motors Limited (supra) is also distinguishable on facts.
Mr. Grover, learned senior advocate appearing for the respondent nos. 3 to 5 submits that the
nature of the yatras needs to be taken into consideration prior to grant of any permission. The said
yatras/rallies would be continuing for more than a month and would be covering all the districts of
West Bengal. The petitioner is intending to organize the yatras/rallies describing the same as 'Rath
Yatra', as would be explicit from the graffiti and posters. In the same, image of Rath has been
incorporated which gives rise to a perception of religious overtone. Such perception is also backed
by intelligence inputs which cannot be ignored. Applying the 'apprehension of breach of peace', to
the facts of the present case the authorities have rightly refused permission to organise the
yatras/rallies. In support of such contention reliance has been placed upon the judgment delivered
in the case of Majdoor Kishan Shakti Sangathan vs. Union of India & Ors. reported in (2018) SCC
Online 724.
Placing reliance upon a judgment delivered in the case of Pratap & Anr. Vs. Union of India reported
in (1997) 5 SCC 87 and in the case of Laxmikant vs. Union of India reported in (1997) 4 SCC 739, he
submits that imposition of total prohibition is permissible on the part of the State.
Mr. Grover, however, has submitted that in the event the petitioner approaches the authorities for
holding some meetings, the authorities would certainly consider the same and grant permission, in
accordance with law.
In reply, Mr. Kapoor submits that a decision is an authority for what it decides and not what can
logically be deduced therefrom. Even a slight distinction in fact or an additional fact may make a lot
of difference in the decision making process.
In the case of Johorimal (supra), the issue was pertaining to appointment and selection of advocates
as government counsel. In the case of State of Punjab (supra), the Court was dealing with an issue of
acquisition of land. The case of Ramsaran (supra) was pertaining service conditions of a constable.
The said judgments are distinguishable on facts, however, in the same it has also been observed that
on the ground of unreasonableness, the Court can interfere with administrative action.
In Talcher Municipality (supra), the issue was involving requisition and the constitutional validity of
a regulatory statute was under consideration. In the case of K. Ramanathan (supra), theBharatiya Janata Party vs State Of West Bengal & Others on 20 December, 2018

constitutional validity of a regulatory statute was being examined. In the case of Mirzapur Moti
Quereshi Kassab Jamat (supra) the Court was considering the provisions of Article 19(1)(g) and
Article 48 of the Constitution of India. In the case of Pratap Pharma (supra) the Court was
considered in the prohibition imposed upon a drug and interference was called for since the
prohibition was found to be reasonable a restriction. In the case of Laxmikant (supra) the Court did
not interfere with the ban imposed with the use of tobacco in toothpaste and toothpowder as the
same was found to be prone to cancer.
The provisions under the Police Act of 1981 and the Police Regulation of Bengal as relied upon apply
in a different field occasioning applications for permission when apprehension is anticipated of
public tranquility on an impeccable and discreet materials and report and not on mere surmises and
conjecture, assumption or presumption. There should be a reasonable basis to form an opinion and
the provisions of Police Regulation of Bengal do not vest upon the State, an absolute power to
prohibit a rally.
The maintenance of law and order is within the domain of the State and the decision to prevent and
protect any untoward incident should be founded on convincing materials and not merely on the
basis of an apprehension that the yatras would turn into communal propaganda. The standard of
judging reasonability of restriction or restriction amounting to prohibition remains the same,
excepting that a total prohibition must also satisfy the test that a lesser alternative would be
inadequate.
Indisputably, none of the representations submitted by the petitioner on and from 29th October,
2018 till 5th December, 2018, as annexed to the present writ petition, were answered by the
respondents. No reason was given as to why the same were not responded to. During the said
period, there was no intelligence input. Answering the query of the Court when the earlier writ
petition was first taken up for hearing on 5th December, 2018, it was submitted that the petitioner's
prayer would be considered by the competent authority and a decision would be taken and the Court
would be apprised of the same on the next date. Accordingly, on 6th December, 2018 two letters
were produced. In the first letter dated 5th December, 2018 issued by the District Magistrate, Cooch
Behar it was observed as follows:
"Mr. Amit Shah, an M.P. of BJP, Mr. S. S. Ahluwalia, MOS, Electronic & IT, GoI, Mr.
Biplab Deb, Chief Minister of Tripura, Mr. Sarbananda Sonewal, Chief Minster of
Assam, Mr. Kailash Vijaybarjiya, Mr. Mukul Roy, Mr. Dilip Ghosh, MLA and Ms.
Roopa Ganguly, M.P. will hold a meeting and Rath Yatra on 7th December, 2018
without permission at or nearby Cooch Behar and such exercise of them and their
associates may be backed by communal forces. It appears from Intelligence police
inputs that there is every apprehension that this exercise will instigate serious
communal disharmony which may cause deep fault lines and violence in civic society
resulting harm to property and even to life.
Under such circumstances permission could not be provided."Bharatiya Janata Party vs State Of West Bengal & Others on 20 December, 2018

In the second letter dated 5th December, 2018 issued by the Superintendent of Police, DIB, Cooch
Behar, it was observed as follows:
"Information indicates that some communal provocateurs and rowdy elements have
already become active and they have designs to create disturbances in the backdrop
of this programme. In the background overall communal scenario and happenings
around the country and also because of the ill designs of the communal provocateurs
in the district there has been an alarming incidents of assault and attempted lynching
by "Gorakshak" of persons of different community carrying cow meat which has
generated huge tension and apprehension in the locality. On this issue vide Kotwali
PS Case No.738/18 dated 01-12-2018 u/s 143/ 341/ 325/ 307/ 379/ 506 IPC has been
started and 3 (three) persons have been arrested."
Both the said letters were pertaining to the district of Cooch Behar and in support of the input, it
was only stated in one letter that only one criminal case has been registered, being Kotwali P. S. Case
no.738 of 2018 dated 1st December, 2018. On that date, admittedly, no further intelligence input
from any other district was existing. The Hon'ble Appeal Court heard the matter on 7th December,
2018 and a meeting was fixed on 12th December, 2018 and a decision was stating inter alia that the
said officers had 'obtained intelligence inputs from D.Ms., CPs and SPs and also the assessment of
the Intelligence Branch' and that according to said officers the 'areas proposed to be covered by the
Yatra are because of publicity and propaganda gradually turning into communally sensitive pockets.'
It was also observed that the intelligence reports indicated 'that public perception is that the
religious overtones of the Yatra will be termed into communal propaganda' and that 'in several
districts organizations with overtly communal agenda such as the RSS, Bajrang Dal and VHP would
actively join the Yatra.' From the said remarks, it appears that the concerned officials were
considering intelligence reports in several districts. However, the names of the concerned districts
were not disclosed and even without any form of report pertaining to the other districts, the
petitioner has been mechanically denied permission to organise the yatras/rallies. The letters, which
were first produced before this Court on 6th December, 2018, were, however, in respect of a single
district and an apprehension of beach of peace occasioned, according to the authorities, since one
criminal case was registered.
In the said conspectus of facts, it cannot be stated that the concerned officials had sufficient material
to totally deny permission to the petitioner to organise the said yatra/rally without even making an
endeavour to ascertain as to whether the yatra can be allowed to be organised by imposing
reasonable restrictions. The judgments, upon which reliance have been placed as regards the scope
of judicial review, disclose a consistent stand that the discretion exercised by the administrative
authorities can certainly be interfered with in exercise of this Court's power of judicial review when
such power has been exercised in a whimsical and unreasonable manner. In the instant case,
without providing for reasonable restrictions, the authorities have passed an order towards total
exclusion, which in my opinion, does not satisfy the test of reasonableness. When the yatras/rallies
are not for any unlawful purposes, the same ought not to be totally prohibited unless there is an
imminent threat to the breach of public order; even then, the restraint must be just and reasonable.
The threat to public peace and tranquility should be real and not imaginary or a mere likelyBharatiya Janata Party vs State Of West Bengal & Others on 20 December, 2018

possibility.
Till 5th December, 2018, several representations made by the petitioner were not attended to. When
the earlier writ petition came up for hearing, two letters were produced pertaining to one district. No
reason is forthcoming as to why intelligence inputs were not called for immediately upon receipt of
the first representation of the petitioner submitted on 29th October, 2018. Whenever the State
proposes to impose a restriction on the exercise of fundamental rights, such restriction has to be
reasonable and free from arbitrariness. The order impugned does not disclose the data on the basis
of which a total prohibition was required. It also does not disclose that any attempt was made by the
concerned officers to weigh the circumstances and for issuance of reasonable restriction.
Applying the proposition of law to the facts of the present case, I am of the opinion that it would be
appropriate to permit the petitioner to organise the yatras/rallies, as prayed for. The impugned
order dated 15th December, 2018 is, accordingly, set aside.
The petitioner, through its learned advocate, undertakes before this Court that:
a) the petitioner shall inform the Superintendent of Police of the concerned district in
which the yatra/rally shall enter, at least 12 hours before entering the concerned
district;
b) the petitioner will ensure conducting the yatra/rally in an orderly fashion, in a
peaceful manner and abiding by all ecological norms;
c) the yatra/rally shall not impede the normal movement of vehicular traffic;
d) the yatra/rally shall be held in consonance with the rules and regulations
governing and regulating the traffic system.
It is made clear that the petitioner shall abide by every just direction of the State administration and
the petitioner shall also be vicariously liable for any wrongful loss and damage to the public.
The police administration shall deploy adequate police force to ensure that there is no breach of law
and order.
With the above observations and directions, the writ petition is disposed of. There shall, however, be
no order as to costs.
After the order is passed, Mr. Datta, learned Advocate General appearing for the State respondents,
prays for stay of operation of the order.
Such prayer is considered and rejected.Bharatiya Janata Party vs State Of West Bengal & Others on 20 December, 2018

Photostat plain copy of this order, duly counter-signed by the Assistant Registrar (Court), be given
to the learned advocates appearing for the parties on their usual undertakings.
(Tapabrata Chakraborty, J.)Bharatiya Janata Party vs State Of West Bengal & Others on 20 December, 2018

