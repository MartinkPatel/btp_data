Eshwari vs The State Of Tamil Nadu on 14 February, 2020
Author: T.Raja
Bench: T.Raja, B.Pugalendhi
                                                              H.C.P(MD)No.632,641 and 643 of 2019
                          BEFORE THE MADURAI BENCH OF MADRAS HIGH COURT
                                          DATED : 14.02.2020
                                                   CORAM:
                                THE HONOURABLE MR.JUSTICE T.RAJA
                                              and
                             THE HONOURABLE MR.JUSTICE B.PUGALENDHI
                             H.C.P(MD)Nos.632, 641 and 643 of 2019
                Eshwari            ... Petitioner in HCP(MD)No.632 of 2019
                Nagajothi          ... Petitioner in HCP(MD)No.641 of 2019
                Lakshmi            ... Petitioner in HCP(MD)No.643 of 2019
                                                    Vs.
                1.The State of Tamil Nadu,
                  Represented by its
                    Principal Secretary,
                  Home, (Prohibition and Excise Department),
                  Secretariate, Chennai -9.
                2.The District Collector / District Magistrate,
                  Collectorate,
                  Ramanathapuram,
                  Ramanathapuram District.
                3.The Superintendent of Central Prison,
                  Madurai Central Prison,
                  Madurai District.    ... Respondents in all petitions
                Prayer in HCP(MD)No.632 of 2019 : Habeas Corpus Petition
                filed     under   Article   226    of     the    Constitution       of   India
                praying     for   the   issuance    of    a     Writ   of   Habeas     Corpus,
                calling for the entire records in detention order passedEshwari vs The State Of Tamil Nadu on 14 February, 2020

                1/13
http://www.judis.nic.in
                                                                 H.C.P(MD)No.632,641 and 643 of 2019
                in        TN.P.D.A.B.C.D.F.G.I.S.S.V.No.10/Goonda/2019                        dated
                02.07.2019 passed by the respondent No.2 and set aside the
                same as illegal and direct the respondents to produce the
                body or person of the petitioner's son namely, S.Arun
                Kumar      (25/2019)       S/o.    Shanmugavel       who       is   confined     at
                Central Prison, Madurai District before this Court and set
                him at liberty.
                Prayer in HCP(MD)No.641 of 2019 : Habeas Corpus Petition
                filed      under     Article      226   of   the    Constitution         of   India
                praying        for   the   issuance     of   a     Writ   of    Habeas    Corpus,
                calling for the entire records in detention order passed
                in        TN.P.D.A.B.C.D.F.G.I.S.S.V.No.12/Goonda/2019                        dated
                02.07.2019 passed by the respondent No.2 and set aside the
                same as illegal and direct the respondents to produce the
                body or person of the petitioner's son namely, Harish @
                Harish Babu, S/o.Rajendran, who is confined at Central
                Prison, Madurai District before this Court and set him at
                liberty.
                Prayer in HCP(MD)No.643 of 2019 : Habeas Corpus Petition
                filed      under     Article      226   of   the    Constitution         of   India
                praying        for   the   issuance     of   a     Writ   of    Habeas    Corpus,
                calling for the entire records in detention order passed
                in        TN.P.D.A.B.C.D.F.G.I.S.S.V.No.11/Goonda/2019                        dated
                02.07.2019 passed by the respondent No.2 and set aside the
                same as illegal and direct the respondents to produce the
                body      or    person     of     the   petitioner's           brother    namely,
                Anandaraj, aged about 30 years, who is confined at Central
                2/13
http://www.judis.nic.in
                                                            H.C.P(MD)No.632,641 and 643 of 2019
                Prison, Madurai District before this Court and set him at
                liberty.
                          For Petitioner             : Mr.K.Kulanthai Vikram
                          For Respondents            : Mr.K.Dinesh Babu
                                               Additional Public ProsecutorEshwari vs The State Of Tamil Nadu on 14 February, 2020

                                                                 in all petitions
                                               COMMON ORDER
(Order of the Court was made by T.RAJA, J.) One Eswari, mother of the detenue is the petitioner in
HCP(MD)No.632 of 2019; Lakshmi, sister of the detenu is the petitioner in HCP(MD)No.641 of
2019; and Nagajothi, mother of detenu is the petitioner in HCP(MD)No.643 of 2019. Challenging
the impugned order of detentions dated 02.07.2019 passed by the second respondent, branding the
detenue as “Goondas” under the provisions of Section 3[1] of the Tamil Nadu Prevention of
Dangerous Activities of Boot leggers, Cyber Law Offenders, Drug Offenders, Forest Offenders,
Goondas, Immoral Traffic Offenders, Sand Offenders, Sexual Offenders, Slum Grabbers and Video
Pirates Act, 1982 (Tamil Nadu Act 14/1982), they have filed the present habeas corpus petitions.
http://www.judis.nic.in H.C.P(MD)No.632,641 and 643 of 2019
2.A perusal of the Grounds of Detention dated 02.07.2019, passed by the second respondent would
show that the detenue came to the adverse notice in Crime No. 166 of 2019, Kenikarai Police Station,
for the offence under Sections 147, 148, 324, 302 and 201 IPC. It is further stated in the grounds of
detention that when the defacto complainant, namely, Padmanaban, was bathing in Purandi
Kanmoi, he heard a noise in Puzhuthikulam Kanmoi and when he went there he found that the
detenu loaded the sand from the Kanmoi and used hitachi vehilcle and when his brother in law and
others questioned about the loading of sand, the accused attacked them with sickle, iron rod and
wooden log and in that incident, his brother in law Mohan died. In this regard, a case was registered
in Crime No.166 of 2019 for the offence under Sections 147, 148, 324, 302 and 201 IPC.
3.The detenu surrendered before the learned Judicial Magistrate No.II, Ramanathapuram on
18.06.2019 and they were ordered to be remanded to judicial custody. I http://www.judis.nic.in
H.C.P(MD)No.632,641 and 643 of 2019
4.The Detaining Authority, on a perusal and consideration of the materials, has derived the
subjective satisfaction that the activities of the detenue were prejudicial to the maintenance of the
public peace and order and as such, branded them as Goondas and detained them under the
provisions of the Tamil Nadu Act 14 of 1982, by clamping the impugned orders of detention and
challenging the legality of the same, the present Habeas Corpus Petitions are filed.
5.The learned Counsel appearing for the petitioners, attacking the validity of the impugned
detention orders submitted the detenu were arrested and remanded into judicial custody in
connection with the case registered by the Kenikarai Police Station in Crime No.166 of 2019, for the
offence punishable under Sections 147, 148, 324, 302 and 201 IPC and the detenu filed bail petitions
before the Principal District and Sessions Judge, Ramanathapuram in Crl.M.P.(MD).Nos.1610 and
1609 of 2019 respectively and they were dismissed on 19.06.2019. Subsequently, the detenu filed
Criminal Original Petitions in Crl.O.P(MD)Nos.8933 and 8932 of 2019, respectively
http://www.judis.nic.in H.C.P(MD)No.632,641 and 643 of 2019 which were pending before this
Court and pending these criminal original petitions, the impugned detention orders were passed
without there being any basis to entertain the apprehension in the mind of the detaining authorityEshwari vs The State Of Tamil Nadu on 14 February, 2020

that the detenu while coming out on bail, there is high possibility for further indulging in similar
activities in future, which will be prejudicial to the maintenance of public peace and order.
6.Immediately, after the detention orders have been passed on 02.07.2019, the bail petitions
pending before this Court were also withdrawn that would also clearly show that there is no fear or
apprehension in the mind of the detaining authority to pass the detention orders. Therefore, a
representation dated 06.07.2019 was moved requesting the second respondent to recall the
impugned detention orders and one another detailed representation was also sent to the
respondents. After receipt of the same, the 3rd respondent, the Superintendent of Prison, Madurai
Central Prison, has willfully and deliberately failed to forward the same as per the mandate of Article
22(5) of the Constitution of India. A similar http://www.judis.nic.in H.C.P(MD)No.632,641 and 643
of 2019 issue has already been dealt with by this Court, in H.C.P. (MD)No.108 of 2019, wherein, this
Court by order dated 24.07.2019, specifically held that if any representation is given by the
petitioner even after a short time of passing the detention order, the detaining authority as a matter
of fact is duty bound to forward the same to the Government, failing which, the detention order
itself is liable to be quashed. Therefore, the same ratio is binding on the respondents herein. The
similar case referred to by the detaining authority is not a similar case, since, in the said case the
detenu was the father of the deceased. In the present case, there is no such relationship between the
deceased and the detenu. Hence, the orders of detention are liable to be set aside.
8.The learned Additional Public Prosecutor appearing for the respondents, justifying the action
taken by the 3rd respondent for not forwarding the representation dated 06.07.2019 to the first
respondent, reiterated the stand that the detention order was passed on 02.07.2019 and the said
representation was made on 06.07.2019, i.e. within 12 days from the date of passing of detention
order and therefore, the 3rd respondent thought it fit for not forwarding the representation
http://www.judis.nic.in H.C.P(MD)No.632,641 and 643 of 2019 to the 1st respondent, since no
subsequent events have taken place.
9. This Court has considered the rival submissions and also perused the entire materials placed
before it.
10. As rightly pointed out by the learned Counsel for the petitioners, the similar case referred to by
the detaining authority is not similar for the reason that the accused therein was the father of the
deceased, but in the present case there is no such relationship between the deceased and the detenu.
Moreover, a Full Bench of this Court in the decision reported in (2007) 2 MLJ (Crl.) 1841, in the
case of G.Kalaiselvi vs. State of Tamil Nadu, has held that the Detaining Authority is required to
come to a conclusion that there is a imminent possibility of the detenue being released on bail. The
question as to whether there is a possibility of being released on bail depends upon several factors,
such as, nature of offence, stage of the investigation, the availability of statutory bail as envisaged
under Section 167(2) proviso of Cr.P.C. Even though it is not possible nor desirable to enumerate
http://www.judis.nic.in H.C.P(MD)No.632,641 and 643 of 2019 the circumstances in which bail is
likely to be granted, one can venture to say that it is very rare for a Court of law to grant bail during
pendency of the investigation, when there are allegations of serious offences, such as, punishable
under Section 302 or 395 IPC. In the light of the above reasons, it is wholly incorrect to say thatEshwari vs The State Of Tamil Nadu on 14 February, 2020

there is a possibility of the detenu being released on bail.
12.Insofar as the non-forwarding the representation of the detenu is concerned, we are unable to
accept the explanation given by the learned Additional Public Prosecutor, since the impugned order
has been passed just 12 days prior to the representation dated 06.07.2019, it is only the perspective
from which the case of the petitioner should be considered. The mandate of Article 22(5) of the
Constitution of India has been completely forgotten.
13. A Division Bench of this Court, in H.C.P. (MD)No.108 of 2019, has also followed the ratio laid
down in Agalya Bhai vs. State of Tamil Nadu, reported in 1997 http://www.judis.nic.in
H.C.P(MD)No.632,641 and 643 of 2019 (III) CTC 486 (DB), wherein, it was observed that the
failure of jail superintendent to forward the detenu's representation to the Central Government
amounts to deprivation of the right of the detenue to have his detention revoked and found fault
with the authorities for non-forwarding the representation submitted by the detenu through the
Superintendent of Prison to the first respondent/Government as well as to the Chairman, Advisory
Board, that it turn would definitely vitiate the orders of detention. In view of the above dictum the
non-forwarding of the representation of the defence is violative of Article 22(5) of the Constitution,
hence, the impugned orders stand vitiated.
14.In the result, the Habeas Corpus Petitions are allowed and the orders of detention in
TN.P.D.A.B.C.D.F.G.I.S.S.V.No.10/Goonda/2019, dated 02.07.2019,
TN.P.D.A.B.C.D.F.G.I.S.S.V.No.10/Goonda/2019 dated 02.07.2019 and
TN.P.D.A.B.C.D.F.G.I.S.S.V.No. 11/Goonda/2019 dated 02.07.2019 passed by the second
respondent, are set aside. The detenu, namely, Arunkumar, son of Shanmugavel, aged about 25
years, Harish @ Harish http://www.judis.nic.in H.C.P(MD)No.632,641 and 643 of 2019 Babu, aged
about 23 years S/o.Rajendran,and Anandaraj, aged about 30 years, S/O. Karuppaiah, who are now
detained at Central Prison, Madurai, is directed to be released forthwith unless their presence [or]
custody [or] detention is required in connection with any other case/proceedings.
                                                  [T.R., J.]          [B.P., J.]
                                                             14.02.2020
                Index        : Yes / No
                Internet     : Yes / No
                dsk
http://www.judis.nic.in
                                                  H.C.P(MD)No.632,641 and 643 of 2019
                To
                1.The Principal Secretary,Eshwari vs The State Of Tamil Nadu on 14 February, 2020

Home, (Prohibition and Excise Department), Secretariate, Chennai -9.
2.The Superintendent of Police, Madurai District.
3.The Inspector of Police, Othakadai Police Station, Madurai District.
4.The Additional Public Prosecutor, Madurai Bench of Madras High Court, Madurai.
http://www.judis.nic.in H.C.P(MD)No.632,641 and 643 of 2019 T.RAJA, J.
and B.PUGALENDHI, J.
dsk and 643 of 2019 14.02.2020 http://www.judis.nic.inEshwari vs The State Of Tamil Nadu on 14 February, 2020

