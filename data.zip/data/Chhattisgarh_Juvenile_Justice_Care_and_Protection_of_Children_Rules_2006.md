Chhattisgarh Juvenile Justice (Care and Protection of Children)
Rules, 2006
CHHATTISGARH
India
Chhattisgarh Juvenile Justice (Care and Protection of
Children) Rules, 2006
Rule
CHHATTISGARH-JUVENILE-JUSTICE-CARE-AND-PROTECTION-OF-CHILDREN-RULES-2006
of 2006
Published on 14 December 2006• 
Commenced on 14 December 2006• 
[This is the version of this document from 14 December 2006.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
Chhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006Published vide
Notification No. F 1-78/2006/sw/26(1), dated the 14th December, 2006Last Updated 14th October,
2019Notification No. F 1-78/2006/sw/26(1) dated the 14th December, 2006. - In exercise of the
powers conferred by the Section 68 of the Juvenile Justice (Care and Protection of Children) Act,
2000 (Central Act No. 56 of 2000), the State Government of Chhattisgarh is hereby pleased to make
the following rules, namely : -
Chapter I
Preliminary
1. Short title and commencement.
(1)These rules may be called as the Chhattisgarh Juvenile Justice (Care and Protection of Children)
Rules, 2006.(2)These rules shall extend to the whole of the State of Chhattisgarh.(3)It shall come
into force from the date of its publication in the Official Gazette.
2. Definitions.
- In these rules, unless the context otherwise requires : -(a)"Act" means the Juvenile Justice (Care
and Protection of Children) Act, 2000 (Central Act No. 56 of 2000) ;(b)"Adoption" means taking
into custody and responsibility permanently of a Juvenile or a Child who has not completedChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

eighteen years of age and who shall have all the rights and privileges of a natural born
child;(c)"Child with special needs" Child with special needs is a child for whom specialized services
or interventions are necessary to facilitate proper care and rehabilitation;(d)"Place of safety" means
any place or institution (not being a police lock up or jail) the person in charge of which is willing to
temporarily receive and take care of the child and which, in the opinion of the Competent Authority,
may be a place of safety for the child;(e)"Foster Care" means placement of a child with a nuclear
family or group foster home;(f)"Pre-adoptive foster Care" means placement of a child in a family
temporarily till the child can be rehabilitated in a permanent home;(g)"Foster Child" means a child
placed with a foster parent or foster family;(h)"Foster Parent/s" means the person/s who is not the
parents of the child, but is willing to undertake the responsibility for care and maintenance of the
child as his or her parents without necessarily legal rights of property etc;(i)"Extended family"
means relatives of the child with whom he/she can be placed in foster care;(j)"Group Foster Care"
means care of a group of children in one family or a group foster home run by a Non-Government
Organisation;(k)"Social Workers" means social workers duly recognized and impanelled by the
Competent Authority, who are professionals or specially trained to provide Social Work expertise in
areas such as counseling, adoption, Community Service, foster care, sponsorship and any other such
service;(l)"Form" means the form annexed to these rules;(m)"Institution" for the purpose of these
rules, means an observation home or a special home or a children's home or a shelter home set up
under section 8, 9, 34 and 37 of the said Act;(n)"Officer-in-Charge" means a person appointed for
the control and management of institution certified or recognized as such under the
Act;(o)"Government" means the Government of Chhattisgarh;(p)"Secondary Victimization" means
and refers to behaviours and attitudes of authorities and personnel in the child justice system
towards children within the system, which further traumatizes victims;(q)"Sexual abuse" occurs
when any adult uses a child for sexual pleasure. Sexual abuse can be physical, verbal or emotional
and includes;(i)Sexual touching and fondling;(ii)Exposing Children to adult sexual activity or
pornographic movies and Photographs;(iii)Having children pose, undress or perform in a sexual
fashion on film or in person;(iv)Rape or attempted rape;(v)Forcing, tricking, bribing, threatening or
pressuring a child into sexual awareness or activity;(r)"take responsibility" means being responsible
for the physical, mental, emotional and over all health and safety of the child;(s)CARA Guidelines :
means the Guidelines issued by the Central Adoption Resource Agency from time to time to regulate
matters relating to adoption of Indian children.
Chapter II
Juvenile in Conflict with law
3. Juvenile Justice Board.
(1)The Juvenile Justice Board shall consist of a Metropolitan/Chief Judicial Magistrate or a Judicial
Magistrate of the first class, as the case may be, and two social workers of whom atleast one shall be
a woman, forming a bench.(2)Every such bench shall have the powers conferred by the Code of
Criminal Procedure, 1973 (No. 2 of 1974).(3)A Magistrate with special knowledge/training in child
psychology or child welfare shall be appointed as a Principal Magistrate of the Juvenile Justice
Board.(4)In case the Principal Magistrate with such special knowledge and training is not available,Chhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

then the State Governments shall provide for such short-term training.(5)The two social workers, of
whom atleast one shall be woman, shall be appointed by the State Government.
4. Selection of the members of Juvenile Justice Board.
(1)The selection of the social workers members of the board shall be made by a selection committee
consisting of the following persons namely : -(a)District and Session's Judge;(b)District
Collector;(c)Commissioner of Police/District Superintendent of Police.(2)There shall be panel of not
more than five names identified from willing and competent persons in the district chosen by the
committee.(3)The Government shall appoint social workers members to the board, only from the
persons recommended by the selection committee. No persons shall be eligible for appointment
unless he is recommended by the selection committee.
5. Qualifications of Social Worker.
(1)The social worker to be appointed as a member of the Board shall be a person, who(a)has been
actively engaged in planning, implementing and administering health, education or other welfare
activities pertaining to child rights issues for atleast five years;(b)a graduate from a recognised
University;(c)a teacher, a doctor, retired public servant or a professional who is involved in the work
concerning juveniles; or(d)a social worker who has been directly engaged in child welfare.(2)No
practicing lawyer shall be appointed a chairman or member of the Board.(3)The appointment of
Member may be terminated by the State Government in accordance with the provisions of
sub-section (5) of Section 4 of the Act.(4)A member may at any time resign by giving, one month
notice in writing to the State Government.(5)A casual vacancy among the members may be filled by
appointment of another member for the remaining period of tenure of the member in whose place
the appointment is made.
6. Term of the Member of the Board.
- The term of the Member of the Board shall be five years from the date of his appointment provided
that a social worker member of the Board shall be eligible for appointment for a maximum of two
term's. One shall not be more than 65 year's of age.
7. Time and Place of sitting of the Juvenile Justice Board.
(1)The Board shall hold its sittings in the premises of a Observation Home. The board shall meet on
two working days of a week on Wednesday and Friday from 11.00 a.m. to 5.00 p.m. and seen the
more number of case. The board may think of additional meetings.(2)The final disposition of the
enquiry shall be passed by atleast two members of whom one shall be the Principal Magistrate.(3)In
case of difference of opinion in the process of disposition or interim order if any to be made, the
opinion of the majority shall prevail, but, where there is no such majority, the opinion of the
Principal Magistrate shall prevail. In such cases, the Principal Magistrate shall record in writing the
circumstances that led to him to take the final decision.,Chhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

8. Honorarium.
- The social worker member of the Juvenile Justice Board shall be paid a Honorarium as the State
Government may determine from time to time.
9. Procedure through which a child may be produced before the Board.
(1)Persons through whom a child alleged to be in conflict with law may be produced before the
Board.(a)The officers of the Special Juvenile Police Unit(b)Any Police Officer(c)The Child
herself/himself(d)Any recognized voluntary organization willing to take responsibility.(2)Wherever
possible, all such persons shall, except at the time of arrest, only wear civil clothes and not a uniform
unless specific circumstances require the said officer to wear a Police uniform in the interest of the
child. However, they shall at all times have their identification card that shall be produced on
demand.(3)The concerned Police Officer shall perform the role of friend of the child. He/she shall
perform all the specific roles and responsibilities required by Police with regard to children alleged
to be in conflict with law. He/she shall work in close co-ordination with the Social Workers in the
Special Juvenile Police Unit and perform only specialized roles expected by the police. All Police
Officers are ultimately responsible for the care and protection of the children.(4)The social workers
at the Special Juvenile Police Unit shall be the caseworker in relation to the Children alleged to be in
conflict with law and shall also perform on the role of friend of the child. He/she shall receive the
child in a sensitive and friendly manner and enable him or her to feel at ease during the entire
process of first and preliminary inquiry.(5)As soon as a child in conflict with the law is apprehended
by the Police, the Police shall place the child under the charge of the special juvenile police unit or
the designated police officer. In case a recognized voluntary organization takes a child to the
Juvenile Justice Board, the voluntary Organization shall also inform the concerned Police
Station.(6)The special juvenile police unit or any other producing agent shall produce the child
before the Magistrate or a Member or the Board within 24 hours of his apprehension (excluding the
time taken to bring the child from the Police Station/place of safety to the Board). In case of delay in
production before the Magistrate/Board, the details of not doing so are recorded in the Police
Daily/General Diary. Preliminary inquiries should be completed as soon as possible and care shall
be taken not to cause any stress to the child for purposes of extracting information for assessment or
the initial reports.(7)The child shall be informed promptly and directly of the charges against
her/him in a language and manner that she/he understands so as to ensure full comprehension of
the same.(8)On arrest the child shall be given all possible assistance to enable her/him to fulfill
her/his right to call any person of her/his choice over the phone or otherwise.(9)The child shall not
be compelled to confess or give testimony. No form of torture or harassment shall be used in order
to extract information from the child.(10)On arrest, the child shall not be kept in the lock up of the
police station or jail in order to conduct the preliminary inquiries. Instead, in the shortest possible
time not exceeding eight hours, she/he shall be taken to observation home or a place of safety such
as the Special Juvenile Police Unit or other such organization wherever such organization is present.
When a child is kept in a place other than the special juvenile police unit, the officer in charge of the
said place shall immediately inform the special juvenile Police unit of that jurisdiction and shall as
far as possible work in co-ordination. All such places shall be child friendly places with an
environment, services and facilities which respect the children as person and enable them to relax,Chhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

play, express their opinions, participate in decisions concerning them and have access to caring and
responsible adults. The Police/recognized voluntary organization shall be responsible to ensure the
safety of the children apprehended or kept under their charge.(11)The child alleged to be in conflict
with law shall be provided with nurturing care as well as other services deemed necessary at that
time, such as immediate medical attention, basic needs, counselling, etc.(12)The special juvenile
police unit to which the child is brought, shall inform the concerned Probation Officer of such
apprehension in Form IX to obtain information regarding the antecedents and family background of
the child and other material circumstances likely to be useful for assistance to the Board for making
the inquiry.(13)The Designated Child Welfare Officer or officers from the special juvenile police unit
shall in the shortest possible time, inform the parents or legal guardian about arrest of the child in
Form X. During any further questioning of the child, they shall ensure the presence of the parent or
legal guardian. The concerned officer may also make a concerted attempt to identify someone as a
'fit person' - preferably a social worker who knows and is willing to take responsibility of the child.
The Officer along with the fit person shall consult the child and determine together, whether it is in
her/his interest to inform the parent/legal guardian, taking into account the cases where the
parents/legal guardians allegedly exploit or abuse children.(14)The social worker of the special
juvenile police unit or the Senior Social Worker in case of the recognized voluntary organization,
shall as far as possible make a visit to the place of the child as well as to the place of the alleged
crime and prepare a social investigation report narrating the circumstances of apprehension and
offence committed and with the description on the possible reasons why the child has allegedly
committed the crime.(15)The producing agent may make a report with recommendations to the
Board. Such recommendations may include immediate release after admonition or reconciliation to
be facilitated by the Child Welfare Officer at the special juvenile police unit itself. Whenever
appropriate and possible, children alleged to have committed petty offences may be released from
the special juvenile police unit itself, when one member or the bench of the Board accepts such
recommendations within the maximum 24 hour period for preliminary inquiry. If the Board ratifies
such a recommendation, the said child shall be released from the place of safety itself. If the Board
decides not to take this recommendation into account, then the child may be transferred to the
Observation Home and produced before the Board.
10. Procedure to be followed by a juvenile justice board in holding inquiries.
(1)In every case in connection with a child, the Board shall obtain a birth certificate or medical
opinion regarding his age and his physical and mental conditions.(2)The Board shall satisfy itself
either from the declaration of Police in writing or otherwise that the child was not kept in Police lock
up or jail prior to the production of the child before the Board and that he/she was produced within
24 hours of taking charge. The Board shall also satisfy that the child has not been subjected to ill
treatment or harassment either by the Police or by any other person from the time of taking charge.
The Board shall also ensure that no girl was taken into charge by police between sunset and sunrise,
provided if the circumstances warrant, that she was kept under the care of a woman in a place of
safety or in an Observation Home.(3)No juvenile or the child shall be handcuffed or fettered under
the provisions of the Act and the rules made thereunder.(4)When the child is presented first time
before the Board, the Board shall immediately determine whether the child can be released on bail.
If the child can be released on bail, then the court shall release the child either to a parent, guardianChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

and fit person/institution or on personal bond by the child.(5)When the child is presented before
the Board, the Board shall communicate to the child in a child friendly manner in a home like
environment, and in a manner that the child can understand the substance of the charge against
him/her. The child shall be asked whether he/she committed the offence of which he or she is
accused.(6)If the child accepts that he/she committed the offence of which he or she is accused, then
the Board records the acceptance and issue the appropriate order. If offence is not serious, the
Board shall wherever possible issue a reprimand and release the child.(7)When witnesses are
produced for examination, the Board shall exercise the power conferred on it by Section 165 of the
Indian Evidence Act, 1872, so as to question them as to bring out any point which may go in favour
of the child.(8)If the child does not accept the substance of the charge, then the Board shall proceed
to hear the prosecution and take all evidence produced by the prosecution and also hear the accused
and take all evidence as he/she produces in his/her defence.(9)The Board may if it thinks fit on the
application of the prosecution side or the child, issue a summons to any witness directing him to
attend or to produce any document or thing.(10)The Board shall address its inquiry with the
question that why the child committed the offence and how best to redress the causative factors. In
accordance with sub-section (2) of Section 10, the Board shall also order in Form I to a Probation
Officer, or otherwise to conduct a social investigation, reporting on the character and antecedents of
the child with a view to assessing the best possible mode for placement, such as, with the family, an
institution or otherwise permissible under the Act.(11)The order to be issued by the Board shall take
into account -(a)the views of the child(b)the best interest of the child(c)the fact that detention
should be a last resort and for the shortest possible period of time. Only in the case of serious
offences or chronic repeaters the Board shall order detention.(12)The State Government shall
recognize registered voluntary organizations to supervise and submit periodical reports and directed
by the Board regarding the orders passed under clause (b) and (c) of sub-section (1) of Section 15 of
the Act.(13)When a child is placed under the care of a parent or a guardian and if the Juvenile
Justice Board deems it expedient to place the child under the supervision of a probation officer, it
shall issue a supervision order in Form II.(14)The Competent Authority may, while making an order
placing a juvenile under the care of a parent, guardian or fit person, as the case may be direct such
parent, guardian or fit person to execute a bond with or without sureties in Form IV.(15)Whenever
the Juvenile Justice Board orders a child to be kept in an institution, it shall, forward to the
Officer-in-Charge of such institution a copy of its order in Form III with particulars of the home and
parents or guardian and previous record.(16)All children shall be kept in such a home which is
nearest to where he/she belongs, unless it is not in his/her interest to do so, such as in situations of
conflict/disaster.(17)The Officer-in-Charge of an institution certified as Special Home under
subsection (2) of Section 9 of the Act shall be informed in advance by the Board before any child is
committed to it.(18)The Officer-in-Charge of the said institution may on receipt of the information
intimate in writing objections, if any, to the committal of the child and the objections shall be fully
taken into consideration by the Board before the child is committed to the said institution.(19)In
case the board orders in Form VIII to the parent of the child or the child to pay a fine, the amount
realized will be deposited in the Government Treasury.(20)When a child is produced before an
individual member of the Board, the order given by the member shall be ratified in the next meeting
of the Board.(21)The Board shall initiate action against any media for publishing any matters
relating to children in need of care and protection, if such material leads to the identification of the
child.Chhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

11. Procedure in respect of sections 23, 24, 25 and 26 of the Act.
- The offences against the juvenile or child specified in sections 23, 24, 25 and 26 shall be either
bailable or non bailable besides being cognizable under the provisions of the Code of Criminal
Procedure, 1973 (2 of 1974) and the provisions of bail or otherwise, shall apply on the police, the
Board and the concerned accordingly.
Chapter III
Child in need of care and protection
12. Child Welfare Committee.
(1)The Committee shall consist of a Chairperson and four other members as the State Government
may think fit to appoint, of whom atleast one shall be a woman, and another an expert on matters
concerning children.(2)The Committee shall function as a bench of Magistrate and shall have the
powers conferred by the Code of Criminal Procedure, 1973 on a Metropolitan Magistrate or a
Judicial Magistrate.(3)State Government may, be notification in the Official Gazette, constitute for a
district or a group of districts specified in the notification, one or more child welfare
committees.(4)The Selection Committee shall consist of following seven members, namely -(i)a
retired judge of the High Court or retired Secretary to the State Government having experience in
social Welfare shall be the Chairperson of the Selection Committee,(ii)Two representatives or
reputed non-governmental organizations working in the area of child welfare,(iii)A representative
from an academic body,(iv)Two representatives of the concerned department of the State
Government, and(v)A representative of the State Human Rights Commission or such recognized
agency or cell or a retired special Judicial Magistrate.
13. Selection of the Chairperson and Members of Child Welfare Committee.
(1)The selection of Chairperson and members of Child Welfare Committee shall be made by a
Committee consisting of the following persons :(I)District and Sessions Judge;(II)District
Collector;(III)Commissioner of Police/District Superintendent of Police.(2)There shall be a panel of
not less than ten names identified from willing and competent persons in the District chosen by the
Selection Committee.(3)The Government shall appoint Chairperson/Members of the committee
only from the list of persons recommended by the Selection Committee.(4)No person shall be
eligible for appointment unless he is recommended by the Selection Committee.
14. Qualifications of Chairperson and Members of Child Welfare Committee.
(1)A person to be selected as a Chairperson/member of the Child Welfare Committee shall have
either of the following qualifications, with five years experience in their respective field.(a)a
graduate from a recognised university;(b)Respectable, well educated citizen with the background of
special knowledge of social work, child psychology, Education, Sociology or Home Science;(c)AChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

teacher or a doctor or a senior retired public servant who has been involved in work concerning
child welfare; or(d)A Social Worker of repute who has been directly engaged in work on child
rights.(2)No practicing Lawyer shall be appointed.(3)The appointment of Chairperson/Member may
be terminated by the State Government at any time in accordance with the provisions of sub-section
(4) of Section 29 of the Act.(4)Any Chairperson/Member may at any time resign by giving one
month's notice in writing to the State Government.(5)Any vacancy may be filled by appointment of
another Social Worker for remaining period of the term of the member in whose place he is
appointed.
15. Tenure of the Committee.
- The tenure of the Chairperson and the members of the Committee shall be five years provided a
member of the Committee shall be eligible for appointment for a maximum of two terms and shall to
be age of 35 to 65 years.
16. Time and Place of sitting of the Child Welfare Committee.
(1)The Committee shall hold its sittings in the premises of a children's Home or any other place as
may be determined by the Government from time to time and the Committee meet atleast two days
in a week on Friday and Saturday from 11.00 a.m. to 5.00 p.m. However, the Chairperson may
extend the sitting time in case any important business is to be transacted.(2)The quorum for
the-meeting shall be three members which may include the Chairperson.(3)Any decision taken by
an individual member, when the committee is not sitting shall require ratification by the committee
in its next sitting.(4)The final disposal of cases relating to children in need of care and protection,
shall take place in the office of the committee, by the order of atleast two members.
17. Honorarium.
- Members of the committee shall be paid honorarium as the State Government may determine from
time to time.
18. Procedure of the Child Welfare Committee.
(1)When any person/ organisation authorised under the Act receives a child in need of care and
protection, he/she/they may also produce the child before the Committee with the social
investigation report of the circumstances in Form-XIII under which the child came to their notice.
They may also be encouraged to assist in efforts to trace the family.(2)If the child has been received
by a Police person other than officers of the Special Juvenile Police Unit, she/he shall, as far as
possible transfer the case of the child to the Special Juvenile Police Unit, or any other appropriate
non-police person under Section 32 of the Act.(3)In case the Committee is not sitting, the child shall
not be kept in the police station or jail, but shall be taken to a place of safety such as a designated
Shelter Home run by a recognized or authorised non government organization and if not then to a
Child help line or other such organization, wherever such organization is available. Such authoritiesChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

shall give the highest priority to the most expeditious processing of such cases to ensure the shortest
possible duration of such detention pending inquiry, which itself should be a measure of last
resort.(4)The child shall be admitted at any time and the Officer Incharge of the Children's
Home/Reception Unit shall receive the child irrespective of the time. A child brought during the
night shall be produced before the Committee at its next sitting for obtaining order.(5)The child's
access to caring responsible adults and provision of Other basic needs shall be ensured during this
period of institutionalisation. A medical check up shall be done if it is found that the child requires it
or if the child specifically requests for the same. Special attention shall be given to girls and other
children requiring specialized care.(6)(i)The producing agent on his own or with the assistance of
any other person shall immediately inform the parents or guardian. The producing agent shall
ensure that the parents/guardian of the child is present at the time of preliminary enquiry. An
exception may be made when it is considered by the case worker/Probation Officer in consultation
with the child who has specifically expressed his/her right not to inform the parents/Guardian, that
it is against the best interest of the child to do so. Reasons for these exceptions shall be expressed in
writing.(ii)Where a child's parents or guardian cannot be contacted earlier, or as mentioned in
clause (i), if the child specifically wishes that they not be contacted, any other fit person accepted by
the child and considered appropriate by the case worker/probation officer, shall be informed of the
child's desire to seek assistance under the Act so that he or she can attend the preliminary
inquiry.(7)A preliminary inquiry shall be completed as soon as possible, Care shall be taken not to
cause any stress to the child for purposes of extracting information for the assessment/initial
reports, keeping in mind that many children are not ready to share information at this initial stage.
Every possible effort shall be made to engage the child through making a positive relationship of
trust. The person handling the child's case shall make every attempt to trace and associate the family
in the inquiry, unless such procedure is believed to cause undue stress to the child or such an
interaction is not in his/her best interests. Assistance of the police recognized voluntary
organizations/child line may also be taken. The Social Worker/Probation Officer of the institution/
organization in which the child is admitted at the initial stage shall as far as possible make a visit to
the home of the child and prepare a social investigation report which is to be recorded.(8)In case,
the child is found to be lost or missing detailed inquiries shall be made as provided in sub-rule (7) of
Rule 18.(9)Children who are more than two years of age, shall be produced before the Committee
within twenty four hours after the reception of the child excluding the journey time by the
organization. For children under two years of age, the organization shall send a written report along
with the photograph, within 48 hours of admission, excluding the journey time.
19. Persons through whom a child may be produced before the Committee.
- Any child in need of care and protection shall be produced before the committee by the following
persons. -(a)Any Police Officer of Special Juvenile Police Unit or a Designated Police Officer;(b)Any
public servant;(c)Childline, a registered voluntary organization, or by such other voluntary
organization or an agency as may be recognized by the State Government;(d)Any Social worker or a
public spirited citizen authorised by the State Government; or(e)by the child himself.Chhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

20. Procedure for detailed Inquiry after Producing the Child before the
Committee.
(1)When a child is brought before the committee, the committee shall assign the case to a Probation
Officer/Social Worker/Case Worker/Child Welfare Officer/Officer-in-charge, as the case may be, of
the home or any appropriate recognized agencies for conducting a detailed inquiry. The producing
agent shall be encouraged to participate in the detailed inquiry, so as to avoid multiple
inquiries.(2)The Committee shall direct the concerned person/organization the details/particulars
to be enquired into for suitable rehabilitation. The direction for the inquiry under Section 33 of the
Act must be in Form I. The Committee shall also maintain.a list of experts in the field of psychology,
counselling, etc. in consultation with the Department of Social Welfare, who are willing to provide
such services. The Committee may direct such professionals to furnish a special report about the
child in need of care and protection.(3)The detailed inquiry must be completed within 4 months
unless special circumstances do not permit to do so in the interest of the child. Under such
circumstances written extension must be taken by the Inquiring Officer/agency under section 33 (2)
of the Act.(4)Medical Check up/assistance may be done/given if the personnel concerned think fit or
if the child specifically requests for the same. Care shall be taken to ensure that such medical
examination is conducted in a sensitive manner.(5)Where a child's parents or guardian cannot be
contacted earlier, or as mentioned in sub-rule (6) of rule 18 and, if the child specifically wishes that
they not be contacted, the Probation Officer shall make a concerted effort to identify any other fit
person accepted and considered appropriate by the child and shall inform him or her of the child's
desire to seek assistance under the Act so that he or she can attend the inquiry.(6)The committee
shall make arrangement to send the child to the designated place of safety, or the Children's Home
having appropriate facilities, regarding Age and sex during the pending detailed inquiry. Children
should as far as possible be lodged in a home closest to where they belong, unless it is not in their
interest such as in situations of disaster/conflict.(7)The Committee may refuse temporary custody of
the child to parents/guardians if the release is found likely to be against the best interests of the
child. Such reasons shall be recorded in writing and further detailed inquires shall be made for
suitable placement.(8)The child may be escorted by a representative of a voluntary organization or a
Police Officer, or by any other arrangement- deemed appropriate by the Committee. Escort by Police
shall be a measure of last resort. The preference shall be given to designated Police Officers or those
attached to a Special Juvenile Police Unit.(9)After completion of the inquiry, if the child is ordered
to continue in the children's home, the Committee shall carry out an annual review of the progress
of the child in the home.(10)Whenever the Committee orders a child to be kept in an institution. It
shall forward to the Officer-in-Charge of such institution a copy of its order in Form III with
particulars of the home and parent's or guardian and previous record.(11)The Competent Authority
may while making an order placing a child under the care of a parent, guardian or fit person as the
case may be direct such parent, guardian or fit person to enter into a bond in Form IV with or
without sureties.
Chapter IV
Establishment of Institutions under the ActChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

21. Observation Home.
(1)The State Government may establish and maintain Observation Home either by itself or under an
agreement with voluntary organization in every district or a group of districts as may be required or
the temporary reception of any child alleged to be in conflict with law during the pendency of any
inquiry regarding them under the Act.(2)Separate institutions shall be maintained for boys and
girls.(3)Inmates of the institutions shall be classified and separated in accordance with their degree
of offence and their age as follows -Age group up to 12 yearsAge group of 12 to 16 yearsAge group of
16 to 18 years(4)The State Government may also certify or recognise any institution as Observation
Home for the purpose of this Act.
22. Objective of the Observation Home.
(1)Opportunities to pursue Education shall be offered through the provision of creative non-formal
classes that enable the child to sustain his/her interest in formal education especially if the child has
attended such school.(2)Special counselling sessions may be conducted by trained persons to enable
children alleged to be in conflict with law to deal with their feelings and fears about their situation
and to offer them legal aid.(3)In any case, children shall be offered opportunities to make
constructive use of their time even during this short period of observation.
23. Management of Observation Home.
- Management of Observation Home shall be maintained by an Officer in charge specifically
appointed to hold office as superintendent of the institution, who is under the control and
supervision of the Commissioner/Director of Social Welfare. The custody of children in conflict with
law in the Observation Home shall be Judicial Custody.
24. Admission of a Child.
(1)Admission of child in the Observation Home shall be made round the clock and the Officer
Incharge of Observation Home is bound to receive the child irrespective of the time.(2)Admission of
child in the Observation Home or a place of safety shall be made by the Juvenile Justice Board by
issuing a placement order duly signed and seal affixed. No child other than a child in conflict with
law shall be kept in an Observation Home.(3)The Officer-in-Charge shall be authorised to detain in
the Observation Home a child brought during the night till he is produced before the Juvenile
Justice Board, the next day for obtaining an order.(4)The Officer-in-Charge shall refuse admission
of a child whose age, identification marks and offence for which he is charged etc. has not been
mentioned specifically. Provided further admission can also be refused if the placement order is not
signed duly or corrections not attested properly or brought without any seal affixed.(5)The
Superintendent/Officer-in-charge will be personally responsible to see that no child is admitted
unauthorised. He will keep a proper check when a child is admitted at odd hours.Chhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

25. Special Homes.
(1)The State Government may establish and maintain Special Home either by itself or under an
agreement with voluntary organization in every district or a group of districts as may be required for
the reception, care, treatment and rehabilitation of children in conflict with law who have been
directed to undergo institutional training for his activities against law.(2)Separate institutions shall
be maintained for boys and girls.(3)Inmates of the institutions shall be classified and separated in
accordance with their degree of offence and their age as follows. -Age group of 12 yearsAge group of
12 to 16 yearsAge group of 16 to 18 years(4)The State Government may also certify or recognise any
institution as Special home for the purpose of this Act.
26. Objectives of Special Home.
- The objectives of the Special Homes shall be -(1)(a)to receive a juvenile in conflict with law who
has been ordered by Juvenile Justice Board;(b)to provide opportunities to receive emotional and
psychological support;(c)to facilitate the child to receive proper health care, education, vocational
training behaviour modification programmes etc.;(d)to ensure the child to be protected from
secondary victimization and assist the child for development and growth;(e)to prepare the child for
reintegration within the community as a changed person;(f)Special Programmes : Programmes may
be to -(i)Assist the child to accept rather than to avoid responsibility for his/her actions;(ii)Help the
child to focus on helping to resolve problems identified as contributing to their offending
behaviour;(iii)Assist the child to develop practical alternative ways of coping with
stressors;(iv)Involve, wherever possible, families of offenders to work on family issues likely to
reduce offending;(v)Remediating educational deficits in basic skills to raise social
competence;(vi)Help to develop market place work skills, which can lead to further training
opportunities, qualifications and real jobs;(vii)Assist the child in establishing and strengthening
relationships with significant others who can then become mentors and role models;(viii)Involve the
child in empowering experiences of assessing their own needs and planning and monitoring their
own case plans;(ix)Help the child to develop skills and confidence to assert positive leadership and
self-discipline;(2)Efforts may be made to develop a Victim Offender Reconciliation Programme
(Concept taken from Victim Offender Reconciliation Programme, www.vorp.com) with such experts
involving interested and competent Non-Government Organizations. The objective of such
programmes may be to offer avenues for communication, responsibility reconciliation and
restitution;(3)A programme for Group Counselling and other such services shall be evolved with the
help of experts in the field;(4)A programme to offer and monitor meaningful and effective
community service to children in conflict with law, who are ordered to undergo for the same, may be
evolved with the help of competent and sensitive Non-Governmental Organizations/ experts. The
objective of such community service shall be to enable the child to move towards becoming an
adjusted member of the community and it shall in no way further stigmatize the child or violate his
rights.Chhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

27. Management of Special Home.
- Management of Special Home shall be maintained by an Officer in charge specifically appointed to
hold office as superintendent of the institution, who is under the control and supervision of the
department district officer District Collector and Commissioner/Director of Social Welfare.
28. Admission of Child.
(1)A child in conflict with law shall be admitted on a written placement order issued and duly signed
by the Juvenile Justice Board for the purpose of receiving the institutional programme.(2)No child
shall be admitted or kept in the Special Home without any valid placement order issued by the
Juvenile Justice Board or any other Competent Authority exercising the powers of the Juvenile
Justice Board.(3)No child shall be kept in the Special Horne beyond the date upto which the child
can be kept as per orders of Juvenile Justice Board.(4)If a child is to be kept in Special Home
beyond the date up to which the child was ordered to be kept in the institution, the formal order of
the Juvenile Justice Board shall be obtained in advance to complete the academic or vocational
training till the closure of the academic year.
29. Children Home.
(1)The State Government may establish and maintain Children Home either by itself or under an
agreement with voluntary organization in every district or a group of districts as may be required for
children in need of care and protection.(2)Separate institutions shall be maintained for boys and
girls.(3)Inmates of the institutions shall be classified and separated in accordance with their age as
follows. -Age group up to 12 yearsAge group of 12 to 16 yearsAge group of 16 to 18 years(4)The State
Government may also certify or recognise any institution as Children Home for the purpose of this
Act.(5)Each Children Home should be a comprehensive child care centre.
30. Objectives of the Children Home.
- The objectives of the Children Home shall be -(a)to receive a child in need of care and
protection;(b)to facilitate the child to receive educational and vocational training, behaviour
modifications programmes for personal growth and developments;(c)to ensure that the child
develops positive attitude towards family and creates a linkage with the family.
31. Management of Children Homes.
- Management of Children Homes shall be maintained by an officer in charge specifically appointed
to hold office as superintendent of the institution, who is under the control and supervision of the
senior department District Officer, District Collector and Commissioner/Director of Social Welfare.Chhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

32. Admission of child.
(1)Children who are in need of care and protection shall be admitted in the Children Home as per
the orders of the Child Welfare Committee.(2)Children in conflict with law can not be admitted in
Children Home under any circumstances.
33. Reception Unit.
(1)There shall be a Reception Unit in every Children Home which shall take care of children during
the pendency of enquiries by the Child Welfare Committee.(2)Admission of Children in the Children
Home shall be made by the order of the Child Welfare Committee. No children shall be admitted in
the institution without a formal order from the Child Welfare Committee.(3)The Officer in charge of
the institution shall not discharge the admitted child from the institution in any manner without the
consent of the Child Welfare Committee.(4)No girl child, during admission, shall be subjected to
scrutiny and checkup by any male staff of the institution.(5)Every girl child shall be subjected to
medical examination within 24 hours of her admission by a lady Medical Officer either by the
Government doctor or by the panel of approved lady doctors maintained in the institution. Every
child on admission shall be kept in the Reception Unit till such time the enquiry related to the child
is completed by the Child Welfare Committee.
34. Disposition of Children from Reception Unit.
- Children in the Reception Unit shall be discharged from the Reception Unit on the orders of the
Child Welfare Committee. The child welfare committee may order that -(a)the child shall be
restored to the care of parents or relatives as per the orders of the Child Welfare Committee;
or(b)the child shall be shifted to the regular unit of the Children Home for further development
activities of the child; or(c)the child shall be transferred to a similar Children Home or a Shelter
Home or a fit institution or under the care of fit person; or(d)if a child belongs to some other
State/District the child shall be transferred to the respective Child Welfare Committee for further
enquiry and disposition.
35. Transfer/Escorts.
(1)The transfer of a child to any of the Children Homes or Shelter Homes in other State shall be
made within a week of the orders of the Child Welfare Committee and the cases related to transfer to
another State shall be completed within 30 days by arranging proper escorts.(2)The transfer of
children shall be given effect by a travel document issued by the Officer Incharge of the
institution.(3)Girl child shall be escorted by female staff accompanied by a male staff.
36. After Care Homes.
(1)After Care Homes may be set up to take care of children after they leave Special Homes and
Children's Homes. These after care services shall be offered to all children/youth between the agesChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

of 18-20 years in order to empower them and facilitate their smooth transition from institutional life
into the community.(2)Objective of these homes would be to enable such children to learn life skills,
which will enable them to adapt to society. During their stay in these homes these children should
be encouraged to move away from an institution based life to a normal one.(3)Target groups shall
include who have either left Special Homes or Children's Homes.(4)The Key components of the
model may include setting up of temporary homes for a group of youth, who can be encouraged to
learn a trade and contribute towards the rent as well as the running of the home. There should also
be provision for a peer counsellor. The counsellor may be in regular contact with these youths to
discuss their rehabilitation plans and provide creative outlets for their energy, to tide over crisis
periods in their life.(5)The programmes under the scheme of after Care Programmes shall include
-(a)facilitating employment generation for these youth. When a youth has saved a sufficient amount,
she/he can be encouraged to stay in a place of his/her own and move out of the group home, or the
youth must continue staying in the home. The youth who are learning a vocational trade could be
given a stipend. This shall be stopped when the youth gets a job;(b)Loans to these youth to set up
entrepreneurial activities would also be arranged;(c)Micro-credit and entrepreneurship training as
well as income generation programmes should be offered;(d)Girls especially shall be encouraged to
take up further education and take admission in other Government Hostels. Though they may be
financially and otherwise supported in case they opt to be married, such an option shall not be the
only one offered, to them as a reintegration strategy. When on discharge from the After Care Home,
a youth who has absolutely no parent or guardian or mentor, youth shall be referred to appropriate
recognized agencies or Non-Government Organizations for further training or apprenticeship or
other such rehabilitative measure;(e)A peer counsellor would also be available for youth at these
homes since at this stage of life they can be lured into crime or drug dependence and such other
habits or deviant behaviour, hence the need for a counsellor;(f)As far as possible, these after care
homes shall be located within the community in areas that enable the youth to come in contact with
a healthy social and community life. Each home would house 6-8 youths who could opt to stay
together. One peer counsellor can be in-charge of a cluster of 5 homes;(g)Wherever possible, the
State Government may make efforts to dovetail the After Care Home Programme with other State
and Central Government Schemes that may enable the youth to take advantage of opportunities to
secure a better future on his or her own.
37. Shelter Homes.
(1)For the children in urgent need of care and protection, such as destitutes, street children etc. the
State Government support creation of the requisite number and not less than one Shelter Home
through voluntary organizations. Local Authority Children with special needs from Children's
Homes may also be referred to these Shelter Homes for special care, if such special care is
available.(2)The Shelter homes may be run in a manner, which facilitates following two stages of
intervention during the period of initial contact with children, -(a)First contact. - The first stage of
intervention shall be made through initiating first contact intervention similar to street contact
centers located on Railway Stations or other areas of high density of children at risk;(b)Transit care.
- The second stage shall be to facilitate a more settled setting for children in crisis who require
transit care prior to long-term placement.(3)Infrastructure. - The first contact centers of the Shelter
Home shall have a fairly large physical space for reception of children along with attached bathingChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

and toilet facilities. The Shelter Homes for transit care shall have the minimum facilities of boarding
and lodging besides the provision for fulfillment of basic needs in terms of clothing food, heath care
and nutrition etc. as well educational facilities for education, vocational training and recreation.
Both these centers of the Shelter Home shall be managed in such a way as to provide child centered
community based reception centers for children.(4)The Child Welfare Committees, Special Juvenile
Police Units, Public Servants, Child Lines, Voluntary organizations, Social Workers and the children
themselves may refer a child to such facilities.(5)The legal requirements of investigation and
disposal shall not apply in cases of children residing in the Shelter Home, except giving information
to the committee and the police about the missing or homeless children besides initiating legal
action in the interest of the child in terms of the Act or other child related laws.(6)Duration of stay
in the Shelter Homes. - The Staff of the Shelter Home shall make a case plan for each child and work
with the child to try and find a suitable placement as soon as possible. No child shall ordinarily stay
in the transit care Shelter Home for more than 3 to 6 months, in case of Government funding, all
children who have not been placed in such home shall be referred to other Non Governmental
Organization for further follow up. A list of such Non Governmental Organization shall be
maintained and effective liaison and networking initiated to facilitate such
referrals.(7)Management. - The Shelter Home shall be run by recognized or authorized voluntary
organizations having a minimum of one year in dealing with children in especially difficult
circumstances. The Shelter Home shall to the extent possible, be managed by taking into account
the principles and standards outlined in the Rules listed in the Chapter VII on Institutional
management, in accordance with the needs of the child.
38. Objectives of the Shelter Home.
(1)There shall be following objectives of the Shelter homes. -(a)identify and receive children who are
at risk and in need of urgent care and protection as well as those who specifically seek help in that
jurisdiction;(b)build up a friendly relationship with the child so as to enable him/her to understand
and share the reasons for his/her present situation as well as to participate in a decision regarding
his/her placement;(c)offer quick assessment services and referrals to detailed assessment and other
services;(d)offer services of counselling, recreation, medical attention, non-formal education and
temporary, open and freely accessible 24 hour shelter;(e)directly link up with competent authorities
and institutions under the Act coming under that jurisdiction as well as network with the Child Help
Line of the area and all other recognized fit persons, voluntary organizations and fit person willing
to assist in the work of the Shelter Home.(2)Location (Establishment). - The Shelter Home shall
preferably be located in areas of high density of children in difficult circumstances such as Railway
Stations, market Stations, market places and other commercial areas.(3)Jurisdiction. - The State
Governments shall encourage for setting up atleast one Shelter Home in every District.(4)Affiliation
to the Jurisdictional Police Station. - Every Shelter Home shall be affiliated to the Jurisdictional
Police Station and to the Child Help Line for any specific assistance.(5)Staffing pattern. - The
staffing pattern of the Shelter Home may be as under : -(a)One Senior Social Worker who is
qualified or has special training or experience in working with children in especially difficult
circumstances;(b)One Junior para professional with special training or experience in working with
children in especially difficult circumstances;(c)One helper;(d)Two youth peer counsellors
performing the role of friends of children.(6)Shelter Homes for Children with Special Needs: SuchChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

as Mentally Challenged Children. - The State Government may run Children's Homes for mentally
challenged children and children with multiple disabilities as per need. All Rules of Chapter VII of
these Rules shall be applicable in these Homes.
39. Children Affected by Displacement, Disaster and Conflict.
- Children affected by displacement, disaster and conflict shall be dealt with as children in need of
care and protection under these Rules. However, certain additional principles and Rules to provide
for special care shall be observed as stated below : -(1)Special Provisions for children affected by
displacement, disaster and conflict. -(a)children shall to informed for their own situations as well as
the details of their family if known, the progress in resettlement and any other issue that may be
relevant to the child;(b)there shall be no discrimination based on caste, language, ethnic origin,
gender, or any other status by either staff or other children. Due consideration shall be given to the
dynamics associated with conflict or other such situation;(c)respect for cultural needs : Keeping in
mind that the child may be from a diverse cultural background every effort shall be made to be
sensitive to the child's cultural and social needs. Such efforts may be to cook food familiar the child,
identify persons who speak the language of the child to interact with the child and make the child
comfortable and secure so as to reduce the stress of being in an alien environment. The child shall
be allowed to follow his or her own religion, rituals and festivals;(d)family and community-based
re-integration shall be given priority. However, with due regard to the root cause and special
circumstances of the case, exceptions may be made with reasons recorded in writing;(e)the
competent authorities shall respect and ensure respect for relevant rules of international
humanitarian law applicable in situations of armed conflict.(2)Reporting. - Only a trained social
worker, child psychologist or child psychiatrist shall assess the situation of the child and prepare the
report. Personnel shall make every effort to understand, report and respond to the Tourism Officer
deep psychological impact on such children and shall strive to receive and deal with the child
sensitively. In preparation of the report and during all other procedures, every effort shall be made
to avoid secondary victimization.(3)Procedure. - Need Assessment of child shall be done by a child
psychologist or trained social worker within four days of arrival of the child in the contact. All other
procedures may be such as prescribed in Chapter III of these Rules.(4)Non-institutional care. - As
far as possible, the child shall not be institutionalized in a State Institution but kept in a foster home
under the foster care scheme, by foster parents who are specially oriented and trained to care for
such children. The foster home shall serve as a home for interim care. During the child's stay in the
interim home a basic standard of care that will meet with the child's physical, emotional,
developmental and other needs shall be ensured.(5)Counselling and trauma care. - Children who
have been sexually abused, mentally disturbed or traumatized due to such disaster, conflict or
displacement etc., or who have particular needs such as those arising from having a HIV positive
status shall, wherever possible be attended to by a child psychologist, a trained social worker or a
psychiatrist and given immediate medical attention and counselling. Regular counselling sessions
with children (not less frequently than once a week) with trained personnel shall be
facilitated.(6)Education. - As far as possible, education that facilitates the continuation of the child's
previous education, must be imparted to the child during stay in foster home or any other further
long-term placement during the interim period. Such education may also be facilitated through
non-formal methods.(7)Legal protection and assistance. - Special care shall be taken to ensure thatChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

the legal rights of such children are respected and action taken under the relevant laws.(8)Family
Tracing. - For a child who has been found and who has not been admitted through voluntary
procedures, the immediate task shall be to trace the family or the nearest known relative. This task
shall be completed within the shortest appropriate period of time as under : -(a)every effort must be
made to trace the family/extended family and understand the history of the child, before placing the
child in any long term care. Community based initiatives that are found to be sustainable and in the
interest of children may be identified and availed of after due consideration. If children are
orphaned and have no extended family then keeping in mind the principle of best interest of the
child, alternative foster or adoptive families may be identified preferably from within the child's
community;(b)When it has come to the notice of the competent authorities that there is a cause
connected with the children, especially girls are being abused, exploited during such situations such
children shall be identified and referred to recognized Non Governmental Organizations, civil
society organizations fit persons or other state run Institutions for long term care, and the adult
offenders dealt with under the relevant laws. Special care shall be taken to prevent such children
from being arbitrarily transferred or placed with persons who do not have the best interest of the
child at heart such as those who arrange the marriage of such children for their supposed protection
during such time of disturbance.(9)Follow up. - Probation Officer or any other recognized voluntary
organization or civil society organization that will follow up on the child must be identified. This
organization must communicate within a month of resettlement about the well being of the child.
The following issues shall be addressed at time of resettlement -(a)Condition in home state and a
report on the desirability of the child continuing to stay in the home state considering the present
condition of disaster, conflict or other such reasons for displacement;(b)Situation of family or other
persons who have been caring for the child prior to displacement;(c)Care plan for re-integration and
rehabilitation taking into account the feelings and opinion of the child about
placement.(10)Sponsorship. - If the family is unable to take care of the child for financial reasons,
sponsorship support for the family shall be considered.(11)Alternate arrangement. - If the child is
not placed back to his/her home state, or placed in foster care or adoption, he or she may be referred
to a Shelter Home for special care.
40. Referral Services for Children with Special Needs.
(1)The Competent Authority shall identify the recognized institutions providing specialized services
to children with special needs and refer the children to these institutions so that their particular
needs are met.(2)Such services shall be provided for physically challenged children, street children,
sexually abused children, children with HIV/AIDS, children of prisoners, child prostitutes, children
addicted to substances, terminally/chronically ill children and any other such type of
children.(3)Children with special needs, referred to other specialized services or institutions run by
recognized voluntary organizations, shall be covered under the sponsorship scheme under this Act
so that the child is covered with costs on referral.
Chapter V
Juvenile Police UnitChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

41. Special Juvenile Police Unit.
(1)The State Government shall create a minimum one Special Juvenile Police Unit at the district
which shall operate as a Centre for Comprehensive First Contact Care for children under the
Act.(2)Objective of the Special Juvenile Police Unit. - The objectives of the Special Juvenile Police
Unit shall be as under. -(a)to identify and receive children at the point of First contact, undertake
outreach work in the jurisdiction to identify children at risk and conduct home visits of
children;(b)to build up a friendly relationship with the child so as to enable her/him to understand
and share reasons for her/his present situation as well as to participate in a decision regarding
proceedings concerning her/him;(c)to conduct an individualized quick assessment and inquiry and
offer counselling, medical attention, recreation services as well as referral to detailed assessment
and other services;(d)to provide Child Help Line and emergency outreach services through
1098;(e)to network with the Child Help Line of the area and all other recognized fit
persons/institutions and voluntary organizations willing to assist in the work of the SJPU as well as
directly link up with competent authorities and institutions under the Act coming under that
jurisdiction;(f)to take on the role of the Child Friendly First Intervention Centres and perform the
function of a Community Based Reception Unit of the Observation Home/Children's Home to
receive, undertake preliminary inquiries, provide timely counseling and early intervention by
operationalising the principle of diversion;(g)to co-ordinate and upgrade the police treatment
towards children;(h)to operate a mobile Special Juvenile Police Unit which may be called upon by
the concerned police station whenever a child is either apprehended or received under the Act;(i)to
function as a place of safety for children;(j)any other tasks which the unit shall have to perform in
the course of their ordinary duties in a child centered manner.(3)Location of Special Juvenile Police
Unit. - The Special Juvenile Police Unit shall not be located within the precincts of a Police Station,
but it shall be located within the premises of a space being utilized by a recognized voluntary
organization or a public-educational institution or any such place. In addition mobile unit for the
Special Juvenile Police Unit may be set up, which shall liaison with the respective jurisdictional
Special Juvenile Police Unit.(4)Jurisdiction. - (a) The Special Juvenile Police Unit shall have the
jurisdiction on a number of Police Stations in a particular zone as identified as necessary by the
SJPU for taking into account the density of children at risk in the area by the Special Juvenile Police
Unit. Every District shall have a minimum of one Special Juvenile Police Unit;(b)Affiliation to the
Jurisdictional Police Station. - Every Special Juvenile Police Unit shall be affiliated to the nearest
police station for documentation and for any specific assistance.(5)Staff of the Special Juvenile
Police Unit. - (a) A Child Welfare Officer shall be designated in term of Section 63 of the Act not
below the rank of Inspector or Sub-Inspector of Police;(b)The Juvenile Police Unit at the district
level shall function under the supervision of a Child Welfare Officer and two Voluntary Social
Workers of whom one shall be a woman and another preferably child expert or having relevant
experience;(c)One Junior Social Worker who is qualified or experienced as a para professional with
a minimum of one year experience in dealing directly with children in especially difficult
circumstances. (One of these two Social Workers shall be a women);(d)A minimum of one Police
constable who shall be a woman;(e)One helper;(f)Two youth counsellors taking on the role of
'friends of Children' who come to the Special Juvenile Police Unit;(g)One Police Officer;(h)Clothing
to be worn by persons designated to deal with children under the Act. - Wherever possible, all such
persons shall, except at the time of arrest, only wear civil clothes and not a uniform unless specificChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

circumstances require the said Officer to wear a Police uniform in the interest of the child. However,
they shall at all time have on their person, an identification that shall be produced on
demand.(6)Management. - (a) Every Special Juvenile Police Unit may net work by a recognized
voluntary organization having experience and training in directly working with children in especially
difficult circumstances;(b)All Special Juvenile Police Unit's shall report directly to the
Commissioner/ Superintendent of Police.(7)Procedure. - (a) The staff of the Special Juvenile Police
Unit shall receive the child who has been identified as needing the services provided under the Act
according to the principles outlined in these Rules and proceed to conduct preliminary inquiries and
offer services that the child may need at this point of initial contact;(b)Special investigations and
reports that are required to be undertaken by the Police shall be made in addition to which social
investigation reports may also be made by the social workers of the Special Juvenile Police Unit. The
social investigation report of the social worker attached to the Special Juvenile Police Unit may be
considered;(c)Every police station shall display the main features of Juvenile Justice Act on the
board in the entrance of the police station.(8)Missing Children's Bureau. - (a) The State Government
shall set up a Missing Children's Bureau for documentation and publishing information relating to
Missing Children. Computerized software shall be put in place to facilitate such a service. Attempts
shall be made to network with all other similar facilities set up around the country so as to facilitate
speedy scanning and transmission of information about such children around the country. This shall
serve as a database of missing Children;(b)The Missing Children's Bureau shall be linked up to the
Child Help Line wherever available as well as to all major Police Stations in each District;(c)All
citizens found to be directly related to or otherwise authorised to access this information shall be
allowed free access to this data base. Persons found to be abusing this database against the interests
of children shall be investigated and the necessary action shall be taken.
Chapter VI
Recognition and Certification of Institutions
42. Recognition of fit person or fit institution.
(1)Any suitable individual, body of individuals, any association, place or institution, the occupier or
manager of which is willing temporarily to receive a child in need of care, protection or treatment
for so long a period as may be necessary and to bring or to give facilities for bringing up any child
entrusted to its care in conformity with the religion of his birth may be recognized by the Competent
Authority as fit person or fit institution.(2)A list of names and the addresses of fit person and fit
institutions approved by the Competent Authority shall be kept in the office of the
Board/Committee and shall be used when necessary. Efforts shall be made to identify and recognize
institutions, which meet the needs of children requiring specialized intervention and
services.(3)After committal of a child by the competent authority to an institution recognized as a fit
institution with collateral branches, the manager of such institution may send the child to any of the
branches of such institution after giving an intimation to the Competent Authority under whose
orders the child was committed.(4)Before declaring any person/institution as fit person/fit
institution, the Competent Authority shall hold due enquiry and only on satisfaction shall give
recognition as such.Chhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

43. Certification/recognition and Transfer of Institution.
(1)If the management of any organization desires that its organization may be certified or
recognized under the Act, the same shall make a written application in Form XIX together with a
copy each of the rules, bye-laws, articles of association, list of members of the society/association
running the organization, office bearers and a statement showing the status and past record of social
or public service of the organization and the society running the organization to the Director Social
Welfare through District Collector, Director Social Welfare shall recommend the application to State
Government.(2)The State Government shall, after verifying the provisions made in the organization
for the boarding and lodging, general health, education, vocational training and treatment services
may grant certification/recognition under Section 8, 9, 34, 37 and 44 of the Act, as the case may be.
This shall be on the condition that the organization comply with the standards and offer services as
laid down under the Act and these rules and. agrees to ensure an all round growth and development
of children placed under its charge.(3)The State Government may transfer the management of any
State run institution under this Act to a voluntary organization of repute that has the capacity to run
such an institution and certify that said voluntary organization as a fit institution to own the
requisite responsibilities.
44. Joint Management.
(1)State run institutions may also be managed by Non-Governmental Organisations. Roles and
responsibilities as well as other details of management may be finalized after specific and
individualized consultation with the said organization and these may be agreed on through a
Memorandum of Understanding for a specified period of time.The Memorandum of Understanding
shall be signed by the parties in the following manner, namely : -(a)the roles and responsibilities of
each party;(b)the areas in which financial/programmatic inputs will be made by the collaborating
agency;(c)mechanisms for the review of the joint management;(d)space for the participation of the
children;(e)the roles and responsibilities of the staff/volunteers who come into these institutions as
part of the joint management efforts;(f)any other matter relevant to the particular situation at the
time.(2)The institution and the infrastructure already available with the State Government as under
the Juvenile Justice, Act, 1986 shall be suitably used for implementing the Act.(3)The State
Government, if dissatisfied with the conditions, rules, or management of the organization certified
or recognized under the Act may at any time, giving two months notice served on the manager of the
organization, declare that the certificate or recognition of the organization as the case may be, shall
stand withdrawn as from a date specified in the notice. From the said date the organization shall
cease to be an organization certified or recognized under Section 8, 9, 34, 37 or 44 of the Act, as the
case may be.(4)The decision to withdraw or to restore the certificate, or recognition of the
organization may be taken on the basis of a thorough investigation by a specially constituted
advisory board under Section 62 of the Act. On the report of the Advisory Board, the
Officer-in-Charge of the home shall be asked to show cause to give an explanation within 30
days.(5)When an organization ceases to be an organization certified or recognized under Section 8,
9, 34, 37 or 44 of the Act, the children kept therein shall under orders of the Designated Officer
empowered in this behalf by the State Government be either -(a)discharged absolutely on such
conditions as the Officer may impose; or(b)transferred to some other institution established,Chhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

certified or recognized under Section 8, 9, 34, 37 or 44 of the Act, in accordance with the provisions
of the Act and rules relating to discharge and transfer. Intimation of such discharge or transfer shall
be given to the Board or the Committee as the case may be.
45. Grant-in-aid to certified or recognized organization.
(1)An organization certified or recognized under Section 8, 9, 34, 37 or 44 of the Act may, while the
period of certification or recognition is in force, apply for grant-in-aid to the State Government for
maintenance of children received by them and or the provisions of the Act and for expenses incurred
on their education, treatment, vocational training, development and rehabilitation. The grant-in-aid
may be granted by the State Government at such rates, which shall be able to meet the prescribed
norms in such manner and subject to such conditions as may be mutually agreed by both
parties.(2)In case of transfer of management of Government run homes under Section 8, 9, 34, 37
and 44 of the Act to voluntary organization, the same budget which the government was spending
on that home, shall be given to the voluntary organizations as grant-in-aid under the memorandum
of understanding signed between both parties describing other role and obligations.
Chapter VII
Institutional Management
46. Protection of the rights of the more vulnerable children within institution.
(1)(a)All authorities, officers and personnel shall, at all times sensitive to the needs of children who
are vulnerable because of age, sex, gender, sexual orientation, HIV status, serious illness or any
other reason. Affirmative action shall be encouraged;(b)The State Government/voluntary
organization shall set up separate institutions for boys and girls. Separate facilities shall be set up for
girls who are above the age of 10 years and below the age of 10 years. With respect to institutions for
boys, separate facilities for the age groups up to 12 years, 12-16 and 16-18 years shall be set up.
Separate facilities shall be set up for children in the age group up to 0-5 years with appropriate
facilities for the infants.(2)Reception of the child. - (a) The placement of children in institutions
shall only take place under conditions that take full account of their particular needs and special
requirements according to their age, personality, sex and type of offence if applicable, as well as
mental and physical health, and which ensure their protection from harmful influences and risk
situations;(b)The principal criterion for the separation of different categories of children, shall be
the best suited care to the particular needs of the individuals concerned and the protection of their
physical, mental and moral integrity and well-being;(c)The child shall be received in a caring
manner by personnel who have been trained and sensitized to the special needs and feelings of
children being institutionalized. The child shall be administered a hair cut, if necessary and given a
bath in a manner that protects and affirms the dignity of the child. Lice lotion shall be used
whenever possible as an alternative to shaving;(d)The child shall be allotted a locker to store his or
her personal belongings and other valuables;(e)The immediate needs and apprehensions of the
child such as the need for urgent medical care and the need to contact parents shall be attended to in
a prompt efficient and nurturing manner;(f)The Officer-in-Charge shall verify the orders of theChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

Juvenile Justice Board before receiving the child;(g)A copy of the rules governing the
observation/Special Home/Children Home and a written description of their rights and obligations
in a language they can understand, together with the address of the authorities competent to deceive
complaints such as Child Line, Child Welfare Committee, Juvenile Justice Board, neighbourhood
committees, District level committees as well as the address of public or private agencies and
organizations which provide legal assistance shall be provided to the child at the time of reception.
The child shall have access to these at any time on request;For those children who are illiterate or
who cannot understand the language in the written form or in any other way need assistance, the
information should be conveyed in a manner enabling full comprehension;(h)The child shall be
oriented to understand the regulations governing the internal organization of the institution, the
goals and methodology of the care provided, the disciplinary requirements and procedures, other
authorised methods of seeking information and of making complaints, and all such other matters as
are necessary to enable him/her to understand fully their rights and obligations during the period of
institutionalization.
47. Maintenance of Registers.
(1)The Officer-in-Charge shall maintain in the office such registers and forms as may be prescribed
by the Act and these Rules.(2)Case file. - The case file shall contain the following particulars -(a)All
reports, including social investigation reports, legal records, medical records and records of
disciplinary proceedings, and all other documents relating to the form, content and details of
treatment, shall be placed in a confidential individual file. These files shall be kept up to date,
accessible only to authorised persons including the child himself or herself and classified in such a
way as to be easily understood;(b)Where possible, every child shall have the right to contest any fact
or opinion contained in his or her file so as to permit rectification of inaccurate, unfounded or unfair
statements. In order to exercise this right, any person shall be allowed who is authorised by the
Juvenile Justice Board or the Child Welfare Committee to have access to and to consult the file on
request. Upon release, the records of children shall be sealed, and, at an appropriate time shall be
destroyed;(c)The case file of each child shall be maintained in the institution containing the
following information as applicable, -(i)Central index number(ii)Annual photograph(iii)Report of
the person/agency who produced the child before the Competent Authority ; (same as the format of
the Social investigation report)(iv)Probation Officer's report (also in the format of the Social
Investigation Report)(v)Information from previous institution;(vi)Observation reports from staff
members relating to the child's progress in education, health, report of menstruation (in case of
girls), emotional status, Social history.(vii)Summary Report by Officer-in-Charge(viii)Reports from
Medical Officer. I. Q. testing, aptitude testing, educational/ vocational tests ;(ix)Initial classification
sheet and Care plan of the child.(x)Special precautions to be taken, including those relating to diet,
allergies, allergic reactions to any medicine, details of person who may not be provided access to the
child, etc.(xi)Leave and other privileges granted ;(xii)Quarterly progress report from various
sections ;(xiii)Review sheet including violation of rules, regulations(xiv)Pre-release
programme(xv)Final progress report ; (records of education/vocational training, health and other
progress reports may be included here with a conclusion summarizing all of the above)(xvi)Leave of
absence/release on license.(xvii)Final discharge (shall include the pre-release report and final
decision that has been made on the recommendations of that report)(xviii)Remarks.(3)Care andChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

Rehabilitation Plan - The care and rehabilitation plan shall be prepared in the following manner
-(a)the incharge, counsellor, wherever available, along with the Probation Officer, caseworker or
social worker shall after consultation, prepare a Care plan for every child in the home. The care plan
shall be based on a case history of the child admitted to an institution, which shall be maintained on
a quarterly basis. This information may be collected through all possible and available sources,
including home, parents or guardians, employer, school, friends and community and interview with
the child himself or herself. The report shall also identify psychological and social factors relevant to
the specific type and level of care and programme required by the child;(b)the educational level and
vocational aptitude shall be assessed on the basis of test and interview conducted by the teacher, the
vocational trainer and other technical staff, wherever possible;(c)the care plan shall be reviewed
from time to time for appropriate development and rehabilitation including options for restoration
to family/foster care/adoption and review shall not be delayed beyond a year. The focus should be
on providing family and community based re- integration programmes. Children shall be consulted
while determining their care plan. When special rehabilitative treatment is required, and the length
of stay in the institution permits, trained functionaries of the institutional shall prepare a written,
individualized treatment plan specifying treatment objectives and time-frame and the means, stages
and delays with which the objectives shall be approached;(d)based on the above care plan the
appropriate linkage may be established with outside specialists and community-based welfare
agencies, psychologists, psychiatrists, child guidance clinic, hospital and local doctors, open school
etc. so as to access the best appropriate care for each child;(e)this report, together with the report
prepared by a Medical Officer who has examined the child upon admission, shall be forwarded to
the 'Monitoring and Evaluation Committee' of each Home for purposes of determining the most
appropriate placement for the child within the institution and the specific type and level of care and
programme required to be pursued.
48. Participation of children.
(1)The Voluntary organisations related to the Welfare activities of Children shall be involved in
planning of programmes, reception of children, management of the homes and grievance redressal.
Wherever possible the Voluntary organisations shall be facilitated experts or functionaries trained in
mobilizing participatory process with children. The Voluntary organisations shall work in close
coordination with the Monitoring and Evaluation Committee.(2)Children who are unable to play
their role effectively in the interests of all the children in the institution may be asked by the
children to step down through a suitable process. Whenever possible involvement of parents in the
running of the institutions shall be facilitated.
49. Identity.
- No child who is received into the institution shall have his or her name changed by the personnel.
The authorities shall respect each child's religious, cultural and social identity.Chhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

50. Daily activities.
(1)Each institution shall have a well-planned daily schedule, which endeavour to fulfill the basic
needs and rights of the child.(2)The schedule shall be arrived at in consultation with the inmates,
Non-Government Organization working in the area of child rights, neighbourhood committees,
District Level Committee specially those partnering with the institution shall to the greatest extent
possible facilitate this planning of the schedule.(3)The institution shall involve the outside
community including students, NGO's clubs and societies in planning and conducting various
activities including games, music education, excursion etc.(4)Special programmes may be organized
for Sundays and holidays.
51. Nutrition.
(1)Every Officer in charge shall ensure that every child has the right to adequate and appropriate
nutrition. Residents shall receive food that is suitably prepared and presented at normal meal times
and of a quality and quantity to satisfy the standards of dietetics, hygience and health and as far as
possible, religious and cultural requirements. Clean drinking water should be available to every
child at any time.(2)The State Government shall prepare a Diet Scale for children in consultation
with nutrition experts so that the diet becomes balanced, nutritious and varied. Special diet may be
provided on holidays and festivals and to the sick children as required. The suggested dietary scale
could be as follows :-
Article Recommended Dietary Allowance
Flour 300 gms. per head per day
Rice 300 gms. per head per day
Vegetables 250 gms. per head/day
Pulses 125 gms. per head per day
Sugar 40 gms. per head per day
Vegetables oil/fats 40 gms. per head per day
Milk/curd 300 gms. per head per day without adding water
Break fast (Ground nuts, chana,
Poha)50 gms. per head per day
Tea leaves 4 gms. per head per day
Fruits 45 gms. per head per day (Three times a week)
Spices10 gms. per head per day Mixed as per regional
requirements
Salt 15 gms. per head per day
Other Items  
Tooth Powder 50 gms. per month
Hair oil 100 gm. per month
Bath Soap 1 per monthChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

Soap (for washing clothes) 2 Nos. per month
Note. - The suggested dietary scale could be modified according to the local needs. Where no LPG
Gas available, firewood/fuel scale will apply during the period of non-availability of gas also.
52. Clothing bedding and other articles.
(1)To the extent possible children shall have the right to use their own clothing other than uniform.
Institutions shall ensure that each child has personal clothing suitable for the climate and adequate
to ensure good health, and which in no manner is degrading or humilitation. Children removed
from or leaving an institution for any purpose shall be allowed to wear their own clothing. They shall
not wear uniforms, taking into account that such procedure tends to label and stigmatize
children.(2)Each child shall be provided with clothing and bedding including customary
under-garments, towels, jersey for winter, school uniform for children attending outside schools,
durry, bed-sheets, blanket, pillow, chappal or shoes, utensils as required ; and tooth powder, soap,
oil, comb etc. as per the scale laid down by the State Government from time to time. The minimum
suggested scale for clothing and bedding could be as follows : -
Articles Norms (per resident)
 Non school going childrenMentally
Challenged
children
Shirts 3 Terricot/cotton shirts per year5 Terricot/cotton
shirts per year
Nickers/Pyjama/Skirt3 Terricot/cotton half pant per year
upto 12years.5 Terricot/cotton
half pants per year
 3 Terricot/cotton trousers per year
above 12years 
Kachha 4 per year 6 per year
Banian 4 per year 4 per year
Brassieres for girls above 13 years 4 per year 4 per year
Towels 2 per year 2 per year
Scarf/Chunni for girls only above 12
years ofage2 per year 2 per year
Leather Shoes 1 per year1 canvas shoes per
year
Chappal to girls 1 per year 1 per year
Handkerchiefs - -
Canvas PT shoes  1 per year
Half sleeves sweater 1 in 2 years 1 per year
Woolen Jersey 1 in 2 years 1 per year
Sanitary pads for girls above 13 years as needed as neededChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

Socks Nylon 2 per year 2 per year
Note. - Additional one set of all these articles shall be kept as reserved stock @ of 20% of the
strength of the children. School going children shall be provided all sets of school uniforms on time.
The suggested clothing and bedding scale could be modified according to the local needs.
53. Services, which conform to requirements of the health and dignity of the
child.
(1)Children deprived of their liberty have the right to facilities and services that meet all the
requirements of health and human dignity.(2)The design of the institutions and the physical
environment to the extent possible, shall be in keeping with the rehabilitative aim of residential
treatment, with due regard to the need of the child for privacy, sensory stimuli, opportunities for
association with peers and participation in sports, physical exercise and leisure-time activities.
Though existing infra structure available with the State Government may be utilized, a concerted
effort shall be made to re-organize the decor of all State institutions so that they project the image of
child centred Homes and not that a Jail or government office. Coloured paint for walls and
furniture, posters and exhibition boards shall be made available to children themselves who may use
the same to decorate their home.(3)The design and structure of the homes shall be such as to
minimize the risk of fire and to ensure safe evacuation from the premises. There shall be an effective
alarm system in case of fire, as well as formal and drilled procedures to ensure the safety of the
children. Facilities shall not be located in areas where there are known health or other hazards or
risks.(4)Sleeping accommodation shall normally consist of small group dormitories, while bearing
in mind local standards. During sleeping hours there should be regular, unobstrusive supervision of
all sleeping areas and group dormitories, in order to ensure the protection of each child. Every child
shall be provided with separate and sufficient bedding, which shall be clean when issued, kept in
good order and changed often enough to ensure cleanliness.(5)Sanitary installations should be so
located and of a sufficient standard to enable every child to comply, as required, with their physical
needs in privacy and in a clean and decent manner. Children shall not be made to clean the
toilets.(6)Sanitation and Hygiene - Each institution shall have the following facilities -a. Sufficient
and treated drinking water;b. Sufficient water for bathing and washing clothes, maintenance and
cleanliness of the premises;c. Proper drainage system;d. Arrangements for disposal of garbage;e.
Protection from mosquitoes;f. Sufficient number or latrines in the proportion of at least one latrine
for seven children;g. Sufficient number of bathrooms in the proportion of atleast one bathroom for
ten children;h. Sufficient space for washing;i. Cleanliness in the Kitchen;j. Fly-proof kitchen;k.
Sunning of bedding and clothing;l. Availability of medical facility.(7)Accommodation - The
minimum standard of accommodation shall be as follows to the extent possible : -Dormitory : 40
square feet per juvenileClassroom : Sufficient accommodationWorkshop : Sufficient workspace.Play
ground. - Sufficient playground area should be provided in each institution according to the total
number of children in the institution and all children/children allowed to play for at least two hours
in a day in the playground.(8)The dormitories, classrooms and workshops shall have sufficient cross
ventilation and light.Chhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

54. Education and vocational training.
(1)Education shall be provided outside the institution wherever possible in formal schools run by the
State/State Aided Institution/Institutions recognized by the State. Such education shall be provided
by qualified teachers through programmes integrated with the education system of the country so
that, after release, children may continue their education without difficulty.(2)Every child of
compulsory school age in any facility including the Observation home has the right to education
suited to his or her needs and abilities and designed to prepare him or her for return to society.
Special methodologies based on Minimum Levels or Learning as prescribed by the National Council
of Educational Research and Training, as far as possible be incorporated into the educational system
within correctional institutions to meet the special learning needs of children such as street
children, etc. Special attention shall be given by the administration of the facilities to the education
of children with particular cultural or ethnic needs or any other special needs. Children who are
illiterate or have cognitive or learning difficulties shall have the right to special
education.(3)Children above compulsory school age who wish to continue their education shall be
permitted and encouraged to do so, and every effort shall be made to provide them with access to
appropriate educational programmes.(4)Diplomas or educational certificates awarded to children
while under the Act shall not indicate in any way that the child has been institutionalised in such
institution.(5)Every institution should provide access to a library that is adequately stocked with
both instructional and recreational books and periodicals suitable for the children, who should be
encouraged and enabled to make full use of it.(6)Every child, except those in temporary care in the
Observation home, above the age of compulsory school education shall have the right to receive
vocational training in occupation likely to prepare him or her for future employment.(7)Each home,
except the Observation home, shall facilitate suitable vocational training under the guidance of
trained instructors. The home shall develop networking with Institute of technical Instruction (ITI),
Government and Private Organization/ Enterprises, Agencies/Non Government Organizations with
expertise and placement agencies.(8)With due regard to proper vocational selection and to the
requirements of institutional administration, children should be encouraged to choose the type of
work they wish to perform.(9)Children shall be provided, where possible and in accordance with the
Child Labour Act, with opportunities to pursue work, remuneration and continue education or
training, but shall not be required to do so. Work, education or training shall not cause the
continuation of the child's stay within the institution.(10)Wherever possible, children shall be
provided with the opportunity to perform remunerated labour, if possible within the local
community, as a complement to the vocational training provided in order to enhance the possibility
of finding suitable employment when they return to their communities. The type of work shall be
such as to provide appropriate training that will be of benefit to the children following release. The
organization and methods of work offered in facilities shall resemble as closely as possible those of
similar work in the community, so as to prepare children for the conditions of normal occupational
life.(11)Earnings. - Every child who performs work shall have the right to an equitable remuneration,
if such work is remunerative. The interests of the children and of their vocational training shall not
be subordinated to the purpose of making a profit for the juvenile justice institution or a third party.
3/4 Part of the earnings of a child may be set aside to constitute a saving fund to be handed over to
the child on release. The child may have the right to use the remainder of those earnings to purchase
articles for his or her own use or to indemnify the victim injured by his or her offence or to send it toChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

his or her family or other persons outside the institution.(12)Reward. - Rewards to the children as
may be fixed to by the management of the home from time to time may be granted by the
Officer-in-Charge as an encouragement to steady work and good behaviour. These rewards shall be
presented to the child within a period of two months of his earning it after obtaining a proper receipt
from the child.(13)The religious beliefs of children shall be duly respected and no classes shall be
conducted which attempt to proselytize in the name of education.(14)Inspection of academic and
vocational training. - The monitoring and Evaluation Committees shall report to the Inspection
Committee or to any other relevant specialized Inspection Committee set up in the State having
special jurisdiction on the issue of education, such as the District Educational Officer, Director of
Technical Education, any recognized Education Consultants.
55. Medical Care.
(1)Every child shall receive adequate medical care, preventive and remedial, including dental,
ophthalmologic and mental health care, etc., as well as pharmaceutical products and special diets as
medically indicated. All such medical care shall, where possible, be provided to children through the
appropriate health facilities and services of the community in which the institution is located, in
order to prevent stigmatization of the child and promote self-respect and integration into the
community.(2)Each institution shall provide for the necessary medical facilities to ensure that,
-(a)Regular facilities are available for the medical treatment;(b)Arrangements are made for the
immunization coverage;(c)A system is evolved for referral of serious cases to the nearest civil
hospital or treatment centers;(d)That sick children shall be constantly under medical treatment
supervision;(e)In the event of break out of contagious/infectious diseases, segregation must be
ensured.(3)Each child admitted in any home shall be medically examined by the Medical Officer
within 24 hours and also at the time of transfer/release/leave of the child to a Special Home or in
case of children in need of care and protection before any family/community placement, within a
similar period before transfer and further at any other time that may be considered necessary by the
Medical Officer or the Officer-in-Charge. The child shall be oriented to the need for such an
examination. Such medical examination shall be conducted by trained and sensitized medical
professionals in a manner that protects the dignity and rights of the child.(4)No Surgical treatment
shall be carried out on any child without the previous consent of his parents or guardian, unless
either the parent or guardian cannot be found and the condition of the child is such that any delay
would, in the opinion of the Medical Officer, involve unnecessary suffering or injury to the health of
the Juvenile. Proper direction to this effect must be obtained from the Juvenile Justice Board or the
Child Welfare Committee at the earliest.(5)A health record of each child in the institution shall be
maintained in Form XXII on the basis of quarterly medical check-up. The medical record of each
child shall be meticulously maintained in the file of the child. The record shall also include weight
and height record, any sickness and treatment and other physical/mental problem if any.(6)Any
medical officer who has reason to believe that the physical or mental health of a child, has been or
will be injuriously affected or any other condition, should report this fact immediately to the
superintendent in question and to the concerned authority for safeguarding the well-being of the
child.(7)A child, who is suffering from mental illness, should be treated in a specialized institution
under independent medical management. Steps should be taken by arrangement with appropriate
agencies, to ensure any necessary continuation of mental health care afterChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

release.(8)Observation/Special homes/Children's homes shall refer such children who require
specialized drug abuse prevention and rehabilitation programmes to an approved place
administered by qualified functionaries. These programmes shall be adapted to the age, sex and
other requirements of the children concerned.(9)Medicines should be administered only for
necessary treatment on medical grounds and, when possible, after having obtained the informed
consent of the child concerned. In particular, they must not be administered with a view to eliciting
information or a confession, as a punishment or as a means of restraint. Children shall never be
tested in the experimental use of drugs and treatment. The administration of any drug should
always be authorised and carried out by qualified medical functionaries.(10)Each home shall as far
as possible, have the service of a trained counsellor, according to the counsellor or child ratio
prescribed. Service of Child Guidance Centers, Psychology and Psychiatric Department or similar
Agencies may also be availed.(11)The family or guardian of a child and any other person designated
by the child have the right to inquire about the State of health of the child the family or guardian
shall be informed.(12)The superintendent of the juvenile justice institution should immediately
notify the family or guardian of the child concerned, or other designated person, in case of death,
illness requiring transfer of the child to an outside medical institution, or a condition requiring
clinical care within the home for more than 48 hours. Notice shall also be given to the authorities of
the State of which a child is a resident.
56. Mode of Dealing with Child suffering from contagious diseases or mental
complaint.
(1)When a child kept in a home under the provisions of the Act or placed under the care of a fit
person or a fit institution is found to be suffering from a disease requiring prolonged medical
treatment or physical or mental complaint that will respond to treatment or is found addicted to a
narcotic drug or pyschotropic substance, the child may be shifted by an order of the authority
empowered on this behalf to an approved place set up for such purpose for the remainder of the
term for which he has to be kept in custody under the order of the competent authority or for such
period as may be certified by Medical Officer to be necessary for the proper treatment of the
child.(2)Where it appears to the authority ordering the shifting of the child under sub-rule (1) that
the child is cured of the disease or physical or mental complaint he may, if the child is still liable to
be kept in custody, order the person having charge, send child to the home or fit person from which
or from whom he was shifted or if the child is no longer liable to be kept in home, order him to be
discharged.(3)Where it is found that the child has been institutionalized because his or her partner
in marriage or parent or guardian is suffering from a contagious disease, support through the
sponsorship scheme shall be given to the said person to enable the child to be restored to the family
as soon as possible. The best interest of the child shall be the paramount consideration. As far as
possible, all new cases coming for voluntary admission to the Child Welfare Committee shall be
screened and appropriate non-institutional options explored.(4)If there is no organization either
within the jurisdiction of the competent authority or nearby State for sending the child suffering
from contagious diseases as required in Section 58 of the Act, necessary organization shall be set up
by the State Government at such places as may be deemed fit by the Government for necessary
treatment.(5)Institutional authorities shall also provide children and institutional staff with access
to HIV related prevention information and education. Facilities for voluntary testing andChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

counselling, means of prevention, treatment and care shall be provided in a phased manner.
Confidentiality should be assured and mandatory testing, segregation and denial of access to
facilities and privileges prohibited. Compassionate early release or referral of residents living with
AIDS shall be considered.
57. Recreation.
(1)Every child shall have the right to at least two hours for daily free exercise, in the open air
whenever whether permits, during which time appropriate recreational and physical training shall
normally be provided. Adequate space, installations and equipment shall be provided for these
activities.(2)Every child shall have additional time for daily leisure activities, part of which should be
devoted, if the child so wishes, to arts and crafts skill development.(3)The institution shall ensure
that each child is physically able to participate in the available programmes of physical education.
Remedial physical education and therapy shall be offered, under medical supervision, to children
needing it.
58. Religion.
- Every child shall be allowed to satisfy the needs of his or her religious and spiritual life, by
performing/attending the service or prayers provided in the institution or by conducting his or her
own prayers, and having possession of the necessary books or items of religious observation and
instruction of his or her religion.
59. Visits and outside communication.
(1)Every Child shall have the right to receive regular and frequent visits, particularly' once a week
and not less than once a month, in circumstances that respect the need of the child for privacy,
contact and unrestricted communication with the family and wherever applicable the defence
counsel.(2)Every means shall be provided to ensure that children, have adequate communication
with the outside world, which is an integral part of the right to fair and humane treatment and is
essential to the preparation of children for their return to society.(3)Children, shall be allowed to
communicate with their families, friends and other persons or representatives of reputable outside
organizations, to leave the home for a visit to their home and family and to receive special
permission to leave the home for educational, vocational or other important reasons. The time spent
outside the institution shall be counted as part of the period of sentence.(4)The receipt of letters by
the children of the institution shall not be restricted and they shall have freedom to write as many
letters as they like at all reasonable times. Wherever the probation officers are of the opinion that it
would be in the child's best interest to communicate with his or her parents, the children should be
encouraged to keep their links to the family alive by writing atleast one letter a month for which the
postage shall be provided.(5)Every child shall have the right to make local telephone calls at least
twice a week to his Parents/Guardian/close relatives etc. and shall be assisted as necessary in order
effectively to enjoy this right. The cost of the call may be borne by the child herself or himself. For
children who do not have savings or any other such financial support, the institution may support
the child to contact his or her parents or guardian over the phone for immediate communication.Chhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

The institution may offer such assistance if possible. Every child shall have the right to receive
telephone calls. Every child shall have the right to contact the Child Helpline atleast once a week and
anytime during an emergency.(6)Children shall have the opportunity to keep themselves informed
regularly of the news by reading newspapers, periodicals and other publications, through access to
radio and television programmes and motion pictures and through the visits of the representatives
of any association, youth society, club or organization in which the child is interested.
60. Privacy.
(1)The possession of personal effects is a basic element of the right to privacy and essential to the
psychological well being of the child. The right of every child to possess personal effects and to have
adequate storage facilities for them shall be fully recognized and respected.(2)Every institution shall
have a locker for each child where he or she can store his or her personal belongings.(3)In every
institution, a register of money, valuables and other articles, which the child wishes to entrust for
safekeeping, shall be maintained which may be called the "Personal Belonging Register". The entries
relating to each child shall be read over to child in the presence of a witness whose signature shall be
obtained in token of the correctness of such entries. All such entries shall be countersigned by the
Officer-in-Charge.(4)The money, valuables and other articles shall be kept with the
Officer-in-Charge in safe custody.(5)When such child is transferred from one institution to another,
all his property, valuables, shall be sent along with the child to the Officer-in-Charge of the
institution to which he has been transferred together with a full and correct statement of the
description and estimated value thereof.(6)At the time of the release of such juvenile, the property
or valuables kept in safe custody and the money deposited in the name of child shall be handed over
to the child and an entry made in that behalf in the register. Such entry shall be signed by the
Officer-in-Charge.(7)When a child of an institution dies, therein the property left by the deceased
and the money deposited in the name of the child shall be handed over by the Officer-in-Charge to
any person who established his claim thereto and executes an indemnity bond. A receipt shall be
obtained from such person for having received such property and the amount. If no claimant
appears within a period of six months from the date of death/escape of such juvenile the property
and amount shall be disposed of as per the decision taken by the monitoring and evaluation
committee.(8)Prohibited Articles - No person shall bring into institution the following prohibited
articles.(a)Fire-arms or other weapons, whether requiring license or not (like, lathi, spears, swords
etc.);(b)Alcohol and spirit of every description;(c)Bhang, Ganja, Opium and other
Narcotic/psychotropic substances;(d)Tobacco; or(e)Any other article specified in this behalf by the
State Government by general or special order.
61. Leave of the child.
(1)A child shall be informed at the earliest possible time of the death. Serious illness or injury of any
immediate family member and shall be provided with the opportunity to attend the funeral of the
deceased to go to the beside of a critically ill relative.(2)The child from any institution, may be
allowed to go on leave of absence/or released on license and stay with his family during
examination, emergencies or special occasions like marriage in the family etc.(3)The leave of
absence for short period not exceeding seven days excluding the journey time may be recommendedChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

by the Officer incharge but such leave shall be granted by the Board in Form VII.(4)The parents or
guardian of the child shall submit an application to the Superintendent requesting for release of the
child on leave, stating clearly the purpose for the leave and the period of leave.(5)If the
Superintendent considers that granting of such leave is for the reason mentioned above or otherwise
in the interest of the child, he shall call for a report of the Probation Officer on the advisability or
otherwise and forward the case to the Competent Authority/Board.(6)The parent or guardian shall
arrange to escort the child from and to the institution and bear the travelling expenses in
exceptional cases or during an emergency, the Officer-in-Charge may arrange to escort the child to
the place of the family and back.(7)If the child runs away from family during the leave period, the
parent or guardian are required to inform the Officer-in-Charge of the institution immediately and
try to trace the child and if found, send the child to the institution.(8)If the Juvenile or Child does
not return to the institution on expiry of the sanctioned leave the Board shall refer the case to the
police for taking the charge of the Juvenile or child and bring him back to the institution.(9)The
period of such leave shall be deemed to be part of the period of stay in the institution. Only in the
case of children in conflict with the law, the time which elapses after the failure of a child to return
to the institution within the stipulated period shall be excluded in computing the period of his
detention in the institution.(10)Well-rounded programme of pre-release planning and follow up of
cases discharged from Special Homes shall be organized in all institutions in close collaboration
with existing Government and Voluntary Welfare Organizations.
62. Procedure for sending a child outside the jurisdiction of the Competent
Authority.
(1)In the case of child whose ordinary place of residence lies outside the jurisdiction of the
competent authority and if the competent authority deems it necessary to take action under section
50 it shall direct a Probation Officer to make enquiries as to the fitness and willingness of the
relative or other person to receive the child at the ordinary place of residence and whether such
relative or other fit person can exercise proper care and control over the child.(2)Any child who is a
foreign national and who has lost contact with the family shall also be entitled for protection. The
child shall be repatriated, at the earliest, to the country in Co-ordination with the Ministry of
External Affairs and respective Embassy or High Commission.(3)On being satisfied on the report of
the probation officer/case worker/child welfare officer as the case may be, the competent authority
may send the child, if necessary on execution of a bond in Form V by the child to the said relative or
fit person or giving an undertaking by the said relative of fit person in Form VI.(4)A copy of the
order passed by the competent authority under section 50 shall be sent to : -(a)The Probation
Officer who was directed to submit a report under sub-rule (i);(b)The Probation Officer, if any,
having jurisdiction over the place where the child is to be sent;(c)The Competent Authority having
jurisdiction over the place where the child is to be sent; and(d)The Relative or the person who is to
receive the child.(5)Any breach of a bond or undertaking or the both given under sub-rule (3) above
shall render the child liable to be brought before the Competent Authority who may make an order
directing the child to be sent to home.(6)During the pendency of the orders under sub-rule (3), the
child shall be sent by the competent authority to an Observation Home/Children Home.(7)In the
case of a child where the Competent Authority deems it expedient to send the child back to his
ordinary place of residence under section 50, the Competent Authority shall inform the relative ofChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

the fit person who is to receive the child accordingly and shall invite the said relative or fit person to
come to the home to take charge of the child on such date as may be specified by the Competent
Authority.(8)The Competent Authority inviting the said relative or fit person under sub-rule (7) may
also direct, if necessary, the payment to be made by the Officer-in-Charge of the home of the actual
expenses of the relative or first person's journey both ways by the appropriate class and the child's
journey from the home to his ordinary place of residence, at the time of sending the child.(9)If the
relative of the fit person fails to come to take charge of the child on the specified date the child shall
be taken to his ordinary place of residence by the escort of the home under the Act. In the case of a
girl atleast one escort shall be a female.
63. Transfer.
(1)The transport of children shall be carried out at the expense of the administration in conveyances
with adequate ventilation and light, in conditions that in no way subjects them to hardship or
indignity. Children shall not be transferred from one institution to another arbitrarily.(2)During the
enquiry, if it is found that the child hails from the place outside the jurisdiction of the Competent
Authority the Competent Authority shall order the transfer of the child to the Competent Authority
having jurisdiction over the place of residence of the child.(3)The Juvenile/child in an institution
can be transferred to any other institution by the Commissioner/Director of Social Welfare
Department. The proposal for transfer of juvenile child shall be made by the Superintendent with
proper justification.(4)No transfer shall or ordinarily be proposed on the ground that the child has
created problems or is difficult to be managed in the existing institution.(5)The proposed transfer
would bring the juvenile near his family and would help him in his rehabilitation.(6)Any other
reason for which the transfer would be in the interest of the welfare of the juvenile child.(7)No child
shall be transferred out of the district/city for the purposes of adoption without the concurrence of
the Child Welfare Committee or the Juvenile Justice Board.(8)On receipt of transfer order, the
Superintendent shall arrange to escort the child at the government cost to the place/person as
specified in the order. The child case file and records shall be sent along with the child.
64. Release.
(1)The Officer-in-Charge shall maintain a rooster of the cases to be released on the expiry of the
period of stay as ordered by the Board. Each case shall be placed before the Monitoring and
Evaluation Committee to ensure that there is a smooth transition back to society. With regard to
those extreme cases in which the child is kept for the maximum period, action may be initiated six
months before they attain the age of 18 years.(2)Timely information of the release of a child and of
the probable date of release shall be given to the parent or guardian and the parent or the guardian
shall be invited to come to the institution to take charge of the child on the date. Parents shall be
informed six months prior to release and the child is prepared for release through a formal
counseling session with the counsellor. The child, family all counsellor in co-ordination with each
other shall make the rehabilitation plan. If necessary, the actual expenses of the parent or guardian's
journey both ways and of the juvenile's journey from the institution shall be paid to the parent or
guardian by the Officer-in-Charge at the time of the release of the juvenile. If the parent or guardian
as the case may be, fails to come to take charge of the child on the appointed date, the escort of theChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

institution shall take the child. A female escort shall escort girls.(3)At the time of release or
discharge from Special Home and Juvenile Home the Officer-in-Charge shall provide a set of
summer/winter clothing as the case may be and Pocket money of Rs. 50/- to the Child along with
any other savings.(4)If the child has no parent or guardian and all placement options with
Non-Government Organizations has failed then he may be sent to an aftercare organization.(5)The
Officer-in-Charge of a girl's institution shall in consultation with the girls generate suitable life
options for the girls and if the girls are so inclined consider getting them married in accordance with
the procedure laid down by the Competent Authority.(6)The Officer-in-Charge shall order the
discharge of any juvenile, the period of whose detention has expired and inform the competent
authority within 7 days of the action taken. If the date of release falls on a Sunday or another public
holiday, the child may be released on the preceding day, entry to that effect being made in the
register of discharge. The Officer-in-Charge shall in all cases, order the payment of an allowance,
which shall take care of living and travel expense.(7)In appropriate cases, the Officer-in-Charge may
provide the child with such necessary financial aid through the sponsorship programme under the
provisions of the Act or through a sponsor identified, provide small tools as may be necessary, to
start a business subject to such maximum cost as may be fixed and also identify organizations where
the children who cannot start businesses can work as apprentices.(8)The Officer-in-Charge may,
subject to the approval of the competent authority, allow at their own request such girls or boys as
have no place to go to stay in the institution/or foster homes identified after the period of their
detention has expired, till some other suitable arrangements are made.
65. Escape.
(1)The Officer-in-Charge shall immediately send the guards in search of the child at places like
Railway Station, Bus Stand and other places where the child is likely to go.(2)The parents or
guardians shall be informed immediately about such escape if known.(3)A report shall be sent to the
area Police Station along with the details/description of the juvenile, with identification marks and a
photograph, with a copy to Juvenile Justice Board and the authorities concerned.(4)The
Superintendent shall hold an inquiry about each escape and send his report to the concerned
competent authority.(5)In the event of a child leaving the home without permission, the information
shall be sent to the police and the family, if known. The detailed report along with the efforts to trace
the child shall be sent to the committee for information in the subsequent sitting of the committee.
66. Disciplinary procedures.
(1)Disciplinary measures and procedures in all institutions under the Act shall maintain the interest
of safety and in order of community life. It shall be consistent with the upholding of the inherent
dignity of the child and the fundamental objective of institutional are, namely, instilling a sense of
justice, self-respect and respect for the basic rights of every person.(2)All disciplinary measures
constituting cruel, inhuman or degrading treatment shall be strictly prohibited. These shall include
corporal punishment such as beating the child, placement in a dark cell, closed or solitary
confinement or any other punishment that may compromise the physical or mental health or access
to education of the child concerned. The reduction of diet and the restriction or denial of contact
with family members shall be prohibited for any purpose. Labour shall always be viewed as anChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

educational tool and a means of promoting-the self-respect of the child in preparing him or her for
return to the community and shall not be imposed as a punishment. No child shall be punished
more than once for the same offence. Collective or mass punishments shall be
prohibited.(3)Recourse to instruments of restraint or force for any purpose shall be prohibited.
Instruments of restraint and force can only be used in exceptional cases, where all other control
methods have been exhausted and failed, and only as explicitly authorised and specified by law and
regulation. They should not cause humiliation or degradation and shall be used destructively and
only for the shortest possible period of time. By order of the Superintendent of the administration,
such instruments might be resorted to in order to prevent the child from inflicting self-injury,
injuries to others or serious destruction of property. In such instances, the Superintendent should at
once consult medical and other relevant functionaries and report to the Competent Authority.(4)The
general unauthorized carrying and use of weapons or any other instruments of violence such as
canes, sticks, chains, belts, ropes and whips by functionaries shall be prohibited in all institutions
established under the Act.(5)The concerned Probation Officer/Case Worker or the Superintendent
shall be the only persons competent to impose punishments. All other functionaries as well as
children shall not be competent to impose punishments.(6)A report of misconduct should be
presented promptly to the competent authority, which should decide on it without undue delay. The
concerned Competent Authority should conduct a thorough examination of the case.(7)No child
shall be punished except in strict accordance with the terms with these Rules. No child shall be
punished unless he or she has been informed of the alleged offence in a manner appropriate to the
full understanding of the juvenile, and given a proper opportunity of presenting his or her defence,
including the right of appeal to the concerned Competent Authority or the Inspection Committee.
Complete records should be kept of all disciplinary proceedings.(8)No children shall be responsible
for disciplinary functions except in the supervision of specified social, educational or sports
activities or in self Government programmes.
67. Procedure on the death of a Child.
- On the occurrence of any case of death or suicide the following procedure shall be adopted : -(a)If a
child dies within 24 hours of his admission to the institution an inquest and post-mortem
examination shall be held;(b)Whenever a sudden or violent death or death from suicide or accident
takes place, immediate information shall be given to the Officer-in-Charge and the Medical Officer.
The Officer-in-Charge and the Medical Officer should examine and inspect the dead body. In case a
child dies due to causes other than natural causes or if the cause of death is not known or if the
death has occurred due to suicide or violence or accident or whenever there is any doubt or
complaint or question concerning the cause of death of any child, the Officer-in-Charge shall inform
the Officer-in-Charge of the Police Station having jurisdiction. The Officer-in-Charge shall also
immediately give intimation to nearest Magistrate empowered to hold inquests;(c)Upon the death of
a child during the period of stay in the institution, the nearest relative shall have the right to inspect
the death certificate, see the body and determine the method of disposal of the body. In such
circumstance, there shall be an independent inquiry by a sub-committee appointed by the
Inspection Committee to inquire into the causes of death, the report of which shall be made
accessible to the nearest relative. This inquiry should also be made when the death of a child occurs
within six months from the date of his or her release from the institution and there is reason toChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

believe that the death is related to the period of detention;(d)The Medical Officer shall report to the
Officer-in-Charge about the happening of the natural death of a child and see that the body is
decently removed to the mortuary;(e)In case of natural death or due to illness of child of an
Observation Horne or Special Home the Officer-in-Charge shall obtain a report of the Medical
Officer stating the cause of death. A written intimation about the death shall be given immediately to
the nearest Police Station, Juvenile Justice Board, Child Welfare Committee, National Human
Rights Commission and the authority concerned;(f)The parents or guardians of the deceased child
shall be contacted and the Officer-in-Charge shall wait for 24 hours for the arrival of relatives. After
the inquest is held, the body should be disposed of in accordance with the known religion of the
Juvenile.
68. Procedure in the case of custodial rape or sexual abuse.
(1)In the event of custodial rape and/or sexual abuse, the action shall be taken as follows : -(a)In
case any resident or any other person has observed, known or has reason to suspect that sexual
abuse has occurred and makes a complaint to the Superintendent or through the grievance box or
through Child Line or through any other means or it comes to the notice of the Medical Officer or
other staff that one or more of the following general behaviour changes has been observed in a child,
a report shall be made to the Juvenile Justice Board or the Child Welfare Committee for a special
investigation into the possibility of sexual abuse. It shall be the responsibility of all functionaries to
report such suspicions immediately. The report shall be based on observations of sudden onset of
behaviour changes such as : -(i)Copying adult sexual behaviour;(ii)Persistent sexual play with other
children, themselves, toys or pets;(iii)A sudden increase in sexual knowledge, through language or
behaviour, that is beyond what is normal for their age and circumstances;(iv)Unexplained pain,
swelling, bleeding or irritation of the mouth, genital or anal area; urinary infections; sexually
transmitted diseases;(v)Hints, indirect comments or statements about the abuse.(2)The Juvenile
Justice Board shall direct the Special Juvenile Police Unit in the local police station, wherever
present to register case against the accused person under the relevant section of the Indian Penal
Code. The Special Juvenile Police Unit will conduct necessary investigations under the supervision
of specialized agencies wherever possible. If a functionary of the institution is suspected to be
involved the functionaries concerned shall be immediately suspended during pending further
inquiry.(3)If the person suspected of sexually abusing a child is himself or herself a child then the
child shall be referred to a specialized institution or any other such agency, for consultation/
counselling who shall prescribe the appropriate course of action.(4)If the child reports sexual
abuse/rape after leaving the institution to any person, the person shall bring the same to the notice
of the Juvenile Justice Board or Child Welfare Committee who will then institute an inquiry.(5)In
the event of any other crime committed in respect of residents, the Juvenile Justice Board Child
Welfare Committee will take cognizance and arrange for necessary investigation to be carried out by
Special Juvenile Police Unit under the supervision of specialized agencies wherever possible.(6)Care
shall be taken to ensure that the victimized child receives proper care and physical and psychological
treatment and that due care is taken to avoid secondary victimization during the investigation.Chhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

69. Monitoring and Evaluation Committee.
(1)There shall be Monitoring and Evaluation Committee constituted in each institution and
programme under the Act, which shall meet periodically to ensure that the procedures laid down
above are complied with so as to ensure that the rights of children are guaranteed. They shall meet
atleast once a month to review on the basis of Form XIV and make recommendations on all cases
within the institution. They shall also fulfil responsibilities associated with decision making on
placement and assessment of the care provided to the child during stay in the institutions.(2)The
Monitoring and Evaluation Committee shall be constituted in each institution consisting of the
following functionaries, -
Officer-in-Charge/Superintendent Chairperson
Probation Officer/Psychologist Member/Secretary
Medical Officer Member
House Master/Matron Member
Instructor/Vocational Teacher Member
Counsellor if any Member
Representative of the children residing in the institution Member
Representative of Neighbourhood Committee if any Member
(3)There shall be a Mess Committee in each institution consisting of Matron, Cook and two
representatives of inmates to finalise the menu of Break fast/Lunch/Dinner to ensure that the
Children can have the food according to their taste, liking and interest accordingly.(4)A grievance
box, which is freely accessible to children to deposit anonymous complaints, shall be maintained by
each institution established under the Act. Children shall not be subjected to any punishment for
having accessed these grievance redressal systems. Appropriate guidance may be given by the
counsellor/probation officer of each institution as to the responsible use of the same.
Chapter VIII
Functionaries under the Act
70. General duties of functionaries.
(1)The State Government shall ensure that the qualifications, knowledge, attitudes and skills
expected from each functionary are in line with basic standards. The administration section along
with persons responsible for social audit, inspection, monitoring and evaluation shall specifically
listen to, monitor and address the issues emerging out of monthly staff meetings and Children
groups meetings in each institution under the Act.(2)All functionaries under the Act shall be deemed
to be public servants, and hence be legally accountable for the performance of the duties assigned to
them. Further all voluntary organizations, social workers and others voluntering under this Act shall
be accountable to the competent authorities and the Inspection Committees/Social Audit.(3)In the
performance of their duties, functionaries of residential facilities shall respect and protect theChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

human dignity and fundamental human rights of all children, in particular, as follows : -(a)No
member of the institution or institutional functionaries shall inflict, instigate or tolerate any act of
torture or any form of hearsh, cruel, inhuman or degrading treatment, punishment, correction or
discipline under any pretext or circumstances whatsoever ;(b)All functionaries shall rigorously
oppose and combat any act of corruption, reporting it without delay to the competent authorities
;(c)All functionaries shall function under these Rules. Functionaries who have reason to believe that
a serious violation of the these Rules has occurred or is about to occur should report the matter to
their superior authorities vested with reviewing or remedial power ;(d)All functionaries should
ensure the full protection of the physical and mental health of children, including protection from
physical sexual and emotional abuse and exploitation, and should take immediate action to secure
medical attention whenever required ;(e)All functionaries should respect the right of the child to
privacy, and in particular should safeguard all confidential matters concerning children or their
families learned as a result of their professional capacity ;(f)All functionaries should seek to
minimize any differences between life inside and outside the institution which tend to lesson due
respect for the dignity of children as human beings.
71. Duties of the Superintendent.
- The Superintendent shall be responsible for the following. - (1) The general duties, functions and
responsibilities of the officer in charge will be as follow : -(a)Ensuring that the rights of the child are
protected and all the procedures laid down in the Rules are complied with ;(b)Providing homely
atmosphere of love affection, care development and Welfare of Children ;(c)Planning
implementation and co-ordinating all institutional activities, programmes and operations
;(d)Handling discipline problems keeping in mind the rights of the child as well as the procedures
laid down ;(e)Maintaining minimum standards in the Home ;(f)Monitoring of children, training and
treatment programmes and correctional activities ;(g)Allocation of duties to functionaries
;(h)Attending to functionaries welfare and staff discipline ;(i)Preparation of budget and control over
financial matters ;(j)Proper storage and inspection of food stuff;(k)v Standby arrangement for water
storage, emergency lighting etc. ;(l)Careful handling of plant and equipment;(m)Accident and fire
prevention measures ;(n)Supervision over office administration ;(o)Monthly office inspection and
maintaining of order book. This book shall record and display order of the Superintendent as well as
any follow up details ;(p)Daily inspections and round of institution ;(q)Inspections and tasting food
prepared for child from the main vessel in the kitchen itself and managing the menu to ensure that
the basic principles of good nutrition such as colour, texture, taste, smell and variety are complied
with.(r)Taking prompt action to meet emergencies ;(s)Taking appropriate rehabilitation measures
;(t)Conducting staff meetings every month during which he/she shall elicit and respond to problems
relating to staff, children and other matters relating to the institution. A minute book shall be
maintained for this purpose and every resolution or discussion shall be given due consideration and
process.(2)The Superintendent shall ensure the maintenance of report and case files of children.
The case file of each child shall be maintained in the institution containing the following
information as applicable : -(a)Report of the person/agency who produced the child before the
Board;(b)Probation Officer's report; shall be confifdential.(c)Information from previous institution
;(d)Initial interview material, information from family members, relatives, community, friends and
miscellaneous information ;(e)Source of further information ;(f)Observation reports from staffChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

members ;(g)Reports from Medical Officer, I.Q. testing, aptitude testing, educational/ vocational
tests ;(h)Social history ;(i)Summary and analysis by Officer-in-Charge ;(j)Initial Classification
sheet;(k)Instruction regarding training and treatment programme and about special precautions to
be taken ;(l)Leave and other privileges granted ;(m)Violation of rules, regulations, special
achievement (to be recorded in review report and not in this report)(n)Quarterly progress report
from various sections ;(o)Review sheet;(p)Menstruation report (in case of girls ) ;(q)Pre-release
programme ;(r)Final progress report ; (records of education/vocational training, health and other
progress reports may be included herewith a conclusion summarizing all of the above) ;(s)Leave of
absence/release on license ;(t)Final discharge (shall include the pre-release report and final decision
that has been made on the recommendations of that report) ;(u)Follow up reports ;(v)Central index
number ;(w)Annual photograph ;(x)Remarks.(3)All the case files maintained by the Institutions and
the Juvenile Justice Board shall be computerized and networked so that the data is centrally
available.All data relating to missing children shall be disseminated as widely as possible. Data
relating to missing or lost children shall be specially computerized and networked locally and
centrally through the setting up of Missing Children's Bureaus which shall facilitate the scanning of
children's photographs alongwith their basic identifying information.
72. Duties of the Probation Officer.
(1)On receipt of information from the Officer-in-Charge the Special Juvenile Police unit under
clause (b) of Section 13, the probation officer shall inquire into the antecedents and family history of
the child and such other material circumstances, as may be necessary and submit a social
investigation report in Form XI as early as possible to the Board.(2)Every Probation Officer shall
carry out all directions given by a Board/ Committee or concerned authority and shall perform the
following duties : -(a)To make inquiries regarding the home and school conditions, conduct,
character and health of juvenile/child under their supervision.(b)To attend regularly the
proceedings of Juvenile Justice Board or the Child Welfare or the Child Welfare Committee and
submit reports ;(c)To maintain diary case file and such register as may be prescribed from time to
time ;(d)To visit regularly the residence of the juvenile/child under their supervision and also place
of employment or school attended by such children and to submit regularly fortnightly reports in
Form XII ;(e)To accompany children wherever possible, from the office of the board to observation
home, special home, children's home or fit person, as the case may be ;(f)To bring before the
board/committee, immediately children who have not been of good behaviour during the period of
supervision ;(g)Follow-up of children after their release from the organizations and extending help
and guidance to them ;(h)Establishing linkages with voluntary workers and organizations to
facilitate rehabilitation and social reintegration of children and to ensure the necessary follow up
;(i)Enquiring from each child under his/her care as to whether his/her need of food and clothing are
met as per standard ;(j)Enquiring from each child under his/her care as to whether the cleanliness '
of the premises and maintenance of physical infrastructure including provisions of water and
electricity etc. have been complied with;(k)Doing a social investigation of the child through personal
interview and from the family, social agencies and other sources;(l)Ensuring that the rights of the
child are protected and all procedures laid down in the rules are complied with;(m)Facilitating the
orientation, monitoring, education, vocational and rehabilitation programmes;(n)Facilitating the
pre release programme and helping the child to establish contacts, which can provide emotional andChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

social support to the child after their release;(o)to prepare follow up reports in the Form XXI about
the Juvenile who is released on licence.(3)The Probation Officers shall not employ children under
their supervision for their own purposes or take any private service from them.(4)To augment the
existing probation service, Probation Officers may be appointed from the voluntary organization
and social workers found fit for the purpose by the Competent Authority. Similarly honorary and
voluntary probation services may also be co-opted into implementation machinery by the orders of
the Competent Authority.
73. Duties of the Case Worker.
- The general duties functions and responsibilities of case worker or Child Welfare Officer shall be as
follows :(a)Making social investigations/case history of the Juvenile or the child through personal
interview and from the family "Social agencies and other sources in Form XXIII;(b)Clarifying
problems of the Juvenile or the child and dealing with their difficulties in institutional
life;(c)Participating in the orientation, monitoring, education, vocational and rehabilitation
programmes;(d)Establishing co-operation and understanding between the Juvenile or the child and
the Officer-in-Charge;(e)Assisting the Juvenile or the child to develop contacts with family and also
providing assistance to family members;(f)Participating in the pre-release-programme and helping
the juvenile or the child to establish contact which can provide emotional and social support to
juvenile or child after their release;(g)Ensuring that the children's need of food and cloth are met as
per the specified standard. Ensure the cleanliness of the premises and maintenance of physical
infrastructure including provisions of water and electricity.
74. Key Duties of House Master/Matron.
- The general duties, functions and responsibilities of the House Master/Matron shall be as follows :
-(a)Ensuring that the rights of the child are protected and all procedures laid down in the Rules are
complied with;(b)He shall perform the role of parent, friend, mentor and guide to the children
under his/her care. In this capacity he/she shall play with the children, nurture them as persons,
listen to and within their means, respond to their individual needs;(c)Handling discipline problems
keeping in mind the rights of the child as well as the procedures laid down;(d)Maintenance,
sanitation and hygiene;(e)Implementing daily routine in an effective manner and ensuring
children's participation through the Children Group;(f)Escorting children whenever they go out of
the home.
75. Recognition of Honorary Probation Officers.
- The State Government shall I recognize the services of a panel of trained voluntary personnel who
may be also attached I to a recognized voluntary organization to serve as honorary Probation
Officers, in I addition to the list of honorary Probation Officers. This procedure may be undertaken
to | reduce the number of inquiries of each case.Chhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

76. Training of functionaries.
- The Directorate of Panchayat & Social Welfare I shall provide for training of functionaries of each
of category of staff in keeping with their statutory responsibilities and specific jobs requirements.
The training programme shall include : -(a)Orientation and Training of the newly-recruited
staff;(b)Refresher training courses for every staff member at least once in three . years;(c)Staff
conferences, seminars, workshops, along with the various components/functionaries of Juvenile
Justice System, government etc., at various levels of the functionaries organization.
77. Organization of functionaries.
(1)The strength of functionaries per home shall be determined according to the duty, posts, hours of
duty per day as the base for each category of staff. The institutional organizational set up shall be
fixed in accordance with the size of the home, the capacity, workload, distribution of functions and
requirements of programmes.(2)The whole time staff in a home may consist of Superintendent,
Probation Officer (in case of Observation Home/Special Home), Case Workers (in case of children's
home/shelter home/after care organization), Child Welfare Officers, Counsellor, Educator,
Vocational Training Instructor. Medical Staff, Administrative staff, Care Takers, house
master/matron, store keeper, cook, helper, washerman, cleaners, gardeners as required.(3)The
part-time staff, may include qualified doctor Psychiatrist, Psychologist, occupational therapist and
other professionals as may be required by time to time.(4)The staff of the home shall be subject to
the overall supervision of^the Superintendent who by order shall determine their specific
responsibilities and shall keep the concerned authority informed of such orders made by him from
time to time. The duties and responsibilities of the staff under him shall be fixed in keeping with the
statutory requirements of the Act. The Superintendent and such other staff who may be required,
shall live in the quarters provided for them within the premises of the home.(5)The number of posts
in each category of staff shall be fixed on the basis of capacity of the institution. The staff shall be
appointed in accordance with the educational qualifications, training experience, etc. required for
each category. The suggested staffing pattern for an institution with a capacity of 100 children could
be as mentioned below : -
S. No. Designation No. of post
1. Superintendent 1
2. Counsellor 2
3. Case Worker/Probation Officer 3
4. House Master/Matron 4
5. Educator 2
(Voluntary/part-time)   
6. Vocational Instructor 1
7. Doctor 1 (part-time)
8. Paramedical staff 1
9. Store Keeper cum Accountant 1Chhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

10. Driver 1
11. Cook 2
12. Helper 2
13. Sweeper 2
14. Art & Craft cum Music Teacher 1 (part-time)
15. Gardener 1 (part-time)
16. Peon 1
 Total 25
The number of posts in the category of counsellor, Case worker/Probation Officer, House
Master/Matron, educator and vocational instructor shall proportionally increase with the increase
in the capacity of the institution.
Chapter IX
Rehabilitation and Social Reintegration
78. Adoption.
- As the family is the best option to provide care and protection for children, adoption shall be the
first alternative for rehabilitation and social reintegration of children who are orphaned, abandoned,
neglected and abused.(1)Adoption Agencies. -(a)The State Government shall recognise children's
home or State run Government homes for orphans as adoption agencies both for scrutiny and
placement of such children within the country;(b)The process of scrutiny and placement of children
on adoption shall be done by Probation Officer;(c)Any Government run hospitals or private nursing
homes etc. which find an infant as abandoned within the premises shall report to recognised
adoption agency;(d)The agency which receives a child or an infant should report to the nearest
police station and also the child Welfare Committee at the earliest within six hours. Police on receipt
of such reports shall make an entry in register and an intimation shall be sent to the Juvenile Police
Unit for appropriate enquiry. The Police should 111c a status report to Child Welfare Committee
within a week;(e)Any child who is eligible for adoption and residing in an unrecognised home shall
for the purpose of adoption be transferred to a recognised home.(2)Procedure in the case of
abandoned children. - (a) An abandoned child can be given in a adoption only when the committee
declares such a child to be legally free for adoption an order to that effect is signed by atleast two
members of the committee of which one shall be a Chairperson.(b)Before declaring the child as
abandoned and certifying him as legally free for adoption, the committee shall institute a process of
enquiry, which shall include -(i)A thorough enquiry shall be conducted by the Probation Officer or
case worker or Special Juvenile Police Unit as the case may be, shall be conducted and a report in
Form XVI containing finding submitted within a maximum period of 1 month;(ii)Declaration by the
placement agency, stating that there has been no claimant for the child even after making
notification in atleast one leading newspaper, television and radio announcement and after waiting
for a period of one month the time which shall run Concurrently to the inquiry to be conducted and
report submitted under clause (a);(iii)The Committee shall make a release order declaring the child
legally free for adoption within the period of six weeks from the date of application in the case ofChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

children below the age of two years and three months in the case of children above two years.
Provided that no child above seven years who can understand and express his opinion shall be
placed in adoption without his consent.(3)Procedure in the case of surrender of child. - The
following procedure shall be adopted in the case of surrendered child who has parents or guardian.
Any parent who voluntarily surrenders his/her right over the child/children in various
circumstances the following guidelines shall be adopted by the agency concerned : -(a)The Social
Worker of the concerned agency shall counsel the parents explaining the consequences of adoption
and explore the possibility of parents retaining the child;(b)If the surrender is inevitable to deed of
surrender documents shall be executed in a non judicial stamp paper in the presence of Child
Welfare Committee;(c)Such a surrendered deed shall explain the reason for surrender and other
relevant information of the child. It shall be written in the regional language. The document shall
contain the information that parent has a right to revoke the surrendered deed within two months
from the date of execution of the said deed;(d)If both the parents are living, both of them should
execute the deed;(e)If a surrender deed is executed by any one of the parent, in such case the person
who executes deed should declare the present position of the second parent. In case of the death of
any one parent, the death certificate shall be produced. In such circumstances the report of the
Probation Officers shall be called by the Child Welfare Committee and the procedure relating to the
abandoned children shall be followed.(4)Role of licensed or recognised Government and non
Government agencies for adoption -(a)In the case of an abandoned child the recognized agency shall
within 48 hours report to the Committee alongwith the copy of the report file with the Police Station
in whose jurisdiction the child was found abandoned;(b)The adoption agencies may initiate the
process of clearance at the earliest, in the case of abandoned children for the purpose of adoption
within a period of two months and for placing application before the committee for declaring the
child legally free for adoption;(c)In case of a child surrendered by his biological parent or parents by
executing a document of surrender, the adoption agency shall make an application directly to the
board for giving the child in adoption;(d)The adoption agencies shall wait for completion of
reconsideration time of two months given to the parent or parents;(e)Serious efforts shall be made
for counselling the parents so as to persuade them to retain the child and if the parents are still
unwilling to retain then such children shall be kept initially in foster care or arranged for their
sponsorship;(f)In the case of a surrendered or abandoned child who is legally free for adoption the
licensed agency shall have the discretion to place the child in pre-adoption foster care under
intimation to the board, within one week of its placement pending the final order.(5)Role of children
homes/State run orphanages as placement agencies. - The recognised children home and State run
orphanages recognised by the State Government as placement agencies, shall perform the following
duties and responsibilities : -(a)Receiving of applications, screening and identification of
prospective adoptive parents;(b)Conduct a home study report of the prospective adoptive parents
upon identification;(c)Matching a child with the prospective adoptive parents and place the child on
temporary Foster Care for a maximum period of six months;(d)Regular follow-up during Foster
Care period and report preparations;(e)Process the adoption procedure in the Child Welfare
Committee and Juvenile Justice Board;(f)Co-ordination with voluntary co-ordinating
agency;(g)Maintenance of records relating to adoption;(h)Profile of children;(i)Follow-up for at
least three years after adoption.(6)Guidelines for the preparation of home study report. - The
following shall be the criteria for the preparation of home study report, -(a)Social status and family
background;(b)Description of homes;(c)Standard of living as it appears in the home;(d)CurrentChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

relationship between husband and wife;(e)Current relationship between the parents and children (if
any children);(f)Development of already adopted children (if any);(g)Current relationship between
the couple and the members of each others family;(h)Employment status of the couple;(i)Health
details such as clinical tests, health conditions, past illness, etc.;(j)Economic status of the
couple;(k)Accommodation for the child;(l)Schooling facilities;(m)Amenities in the home;(n)Reason
for wanting to adopt a child;(o)Attitude of grand parents and relatives towards
adoption;(p)Anticipated plans for the adoptive child;(q)Legal status of the prospective
parents.(7)Follow-up. - The follow-up of child placed within the country will be as follows: -(a)If any
replacement (foster care) is effected there should be a regular monitoring and evaluation of the
foster care. A professionally trained social worker should visit the family regularly;(b)The follow up
format should be completed and forwarded by the recognised placement agency to voluntary
coordinating agency and the director/ commissioner social welfare once in six months;(c)The
agency should see that legal adoption is effected at the earliest thereby safeguarding the interest of
the child;(d)Even after legal adoption the agency should keep in touch with the family for a period of
three years;(e)Post adoptive counselling should be provided by the agency to the adoptive
parents.(8)Records. - The following records and registers shall be maintained by every recognised
Children's Home and State run Orphanages : -(a)Admission register;(b)A separate file on each child
in the prescribed format giving full details/history. Relevant legal documents of every adoption and
child's background/history should be maintained atleast for a period of 18 years for future
reference;(c)Register of prospective adoptive parents with details.(9)Disruption proceedings.
-(a)Adopted children or Adoptive Parents or Probation Officers or Social Workers of accredited
Children's Homes shall have the right to make complaints or initiate disruption processes by writing
to the Child Welfare Committee/Juvenile Justice Board;(b)After the Child Welfare Committee has
consented to the disruption, the child shall be returned to the Children's Home from where he or she
was taken. A report of the circumstances under which this decision was taken and the efforts made
to sort out any problems shall be recorded and submitted to the Child Welfare Committee, the
Department of Social Welfare and the Voluntary Co-ordinating Agency;(c)The child may be
removed and placed in an alternate home/transit home whenever there is serious mal-adjustment,
after obtaining the consent of the Child Welfare Committee;(d)Upon disruption of a placement the
Committee shall recommend alternate placement of the child with adequate provisions for
counselling and care.(10)Juvenile Justice Board in Adoption. - Children who has been dealt with
under the various provisions of Juvenile Justice (Care and Protection of Children) Act, 2000 shall be
placed in adoption. The Juvenile Justice Board is the Competent Authority to place such children in
adoption. In addition to the guideline issued by the Government, the guideline on adoption issued
by the Central Adoption Resource Agency and the Supreme Court judgment issued from time to
time shall apply : -(a)In the case of surrendered child it shall be the duty of the Juvenile Justice
Board to ascertain from the parents about the authenticity of the declaration given by the biological
parents. While doing so the parents can be informed that their declaration can be used against them
as witness;(b)The Board shall ensure that the child is placed on adoption within the country and
licensed agency alone can approach the Juvenile Justice Board for adoption;(c)The list of approved
agencies should be kept in every Juvenile Justice 'Board.(11)Juvenile Justice Board and Adoption
Procedure. - The Juvenile Justice Board shall ensure the following process for declaring adoption of
a children : -(i)The licensed agency shall furnish the following documents with their application for
Adoption order(a)License certificate issued by the Government,(b)RegistrationChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

Certificate,(c)Surrender deed, if any,(d)Abandonment certificate issued by the Child Welfare
Committee (if any),(e)Authorisation letter from the authorised signatory of the agency, authorising
the social worker to file the application before the Juvenile Justice Board,(f)Child study report and
medical report,(g)Home study report about the prospective parents done by a social worker
voluntary co-ordinating agency or any other licensed adoption agency,(h)Income certificate of the
prospective adoptive parents,(i)Property certificate of the prospective adoptive parents,(j)Job
certificate of the prospective adoptive parents,(k)Health certificate of the prospective adoptive
parents,(l)Marriage certificate or evidence of marriage of the prospective adoptive parents,(m)three
referral letters from the respectable people of the society,(n)A letter of consent for
adoption,(o)Photos of the child and the adoptive parents duly attested by competent person;(ii)The
prospective adoptive parents alongwith the placement agency shall file a joint petition before the
Juvenile Justice Board with all the relevant documents. In case of single parent the person shall
alone file a petition;(iii)The concerned institution or agency which offer the child for adoption shall
be the co-respondent;(iv)On admission of an application from a recognised agency for adoption the
board shall call for independent enquiry by recognised scrutinizing agency and the scrutiny report
shall be submitted within a period of two weeks;(v)The Board shall undertake a process of enquiry
which will include interviewing the prospective parents, verifying the documents and the report of
the scrutinizing agency. If the board is satisfied that the placement is. in the best interest of the
child, it will pass a final order giving permanent custody to the adoptive parent/parents. An order of
adoption shall be signed by the Principal Magistrate besides atleast any one of the two members of
the Board;(vi)The Board shall fix the date of birth on the report of the medical experts. The Juvenile
Justice Board shall direct the appropriate authority to issue a birth certificate incorporating the date
of birth, date of adoption and the names of adoptive parents.(vii)As far as possible the time taken for
passing an adoption order shall not exceed 3 months of the date of filing. The order shall also
include provision for a periodic follow up report either by the Probation Officer/Case Worker or
adoption agency to ensure the well beings of the child. The period of such follow up shall be not less
than 3 years and such other period as the Juvenile Justice Board may direct. The follow up shall be
made once in 6 months.(12)Child Welfare Committee and Adoption Procedure. - The Child Welfare
Committee shall ensure the following process for declaring a child who is legally free for adoption :
-(A)The licensed or approved agency should furnish the following documents with petition in
duplicate for declaring a child who is legally free for adoption : -(a)Photograph of the child be affixed
on both the petitions,(b)Fit Institution Certificate Copy,(c)Licence Certificate issued by the
Government,(d)Discharge Summary and Hospital Records in case the child was abandoned in the
hospital,(e)Any orders of the Government authorising the Institution to take custody of the children
who are abandoned in hospitals or public places,(f)A copy of the temporary custody
order,(g)Registration Certificate,(h)Surrender Deed (if any),(i)Authorisation letter from the
authorised signatory of the agency authorising Social Worker to file the petitions before the Child
Welfare Committee.(j)Publication of the photograph and other details of the child,(k)Photos of the
child being taken at the time of admission and the recent photo of the child with a declaration that
both photos relate to the same child,(l)Copy of the report sent to the nearest Police Station together
with acknowledgement received from the Police Station,(m)Health status of the child with probable
age,(n)Descriptive marks of the child duly certified,(o)Declaration by the Agency that it has
furnished all the information available with them and they are bonafide to the best of their
knowledge;(B)If the Application from the agency shall be rejected if any of the documents is missingChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

and agency has to file a fresh petition subsequently;(C)If the application is filed along with the
relevant documents as specified in clauses (a) to (o) above the application shall be admitted by the
Committee. On admission of an application the committee shall call for a report of Probation
Officer;(D)The Child Welfare Committee shall determine the date of birth in the interest of the child
based on the report of the medical expert;(E)As far as possible the time taken for passing an order
shall not exceed 6 weeks in respect of a child who is below two years of age and in respect of child
above two years of age, within three months from the date of filing;(F)The Child Welfare Committee
shall ensure that no child is kept unauthorisedly in any of the organization which is not recognized
under the provisions of the Act, either as a fit institution or as Children's Home or as licensed agency
for adoption.
79. Foster Care.
(1)As far as possible younger children who have been relinquished or destitute shall be referred to
adoption rather than foster care in the interest of continued care.(2)Younger children who arc not
placed in adoption shall preferably be placed with a couple in individual foster care/group foster
care till the child is able to return home whenever family circumstances are considered
conducive.(3)Pre-adolescents may be referred to group foster homes.(4)Older children may be
encouraged to live in peer group homes under the foster care of persons willing to supervise such
arrangements.(5)Foster care, though temporary in nature, may continue, if necessary until
adulthood, but should not preclude either prior return to the child's own parents or adoption.(6)In
all matters of foster family care, the prospective foster parents, the appropriate child and his or her
own parents shall adequately be participated. The Child Welfare Committee shall be responsible for
supervision to ensure the welfare of the child.(7)Twins and siblings shall not be separated by a foster
placement except under extraordinary circumstances. If for some reason they have been separated,
arrangement shall be made for them to remain in contact.(8)The wishes of the child concerning the
proposed fostering shall be taken into account before placement.
80. Short term/temporary foster care.
(1)The temporary foster care refers to physical custody/care of the child till he/she is above to return
to the biological family as soon as the family circumstances improve. Temporary short-term foster
care shall not exceed four months and temporary long term foster care shall not exceed five years.
After five years if the child cannot return to the biological family, the foster care period may be
extended or the child placed in a group foster home. The procedure for placements shall be as
prescribed by the Central Adoption Resource Agency Guidelines.(2)The temporary foster care shall
be carried out by the Probation Officer/case worker/social worker, as the case may be under the
supervision of the Competent Authority. The total period of temporary foster care shall not exceed
five years.(3)Persons competent to be foster parents. - The following persons may apply to be foster
parents : -(a)A Single Parent(b)Couple(c)Members of the extended family of the child(d)Non
Governmental Organisations or other recognized person or agency willing to take responsibility of
child/children in individual or group foster care.(4)Procedure for foster care :(A)Procedure for
selection of parents. - (a) An application to foster a child shall be given to the Competent Authority
in Form XVIII through a Probation Officer, case worker or to the person in charge of the approvedChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

residential home who shall forward the application to the Department of Social Welfare/the Child
Welfare Committee.(b)If the application is prima facie satisfactory then the Child Welfare
Committee shall authorize the Probation Officer to undertake the following steps : -(i)Probation
Officer/Case Worker to interview the prospective foster parent/s and assess that he/she is suitable
to foster a child. In particular the Probation Officer shall investigate the motivations of the
prospective foster parents so as to ensure that the intention is not to employ the child as domestic
help.(ii)To visit the home of the prospective foster parent/s and confirm that it is likely to meet the
requirements of the particular child and that the conditions in it arc satisfactory. The family home
should provide adequate rooms based on the number of children with bath and kitchen and provide
a safe environment with adequate sanitary and living conditions to promote health and well being of
the child. The Home study report of Foster family shall be given in Form XVII to the Child Welfare
Committee.(iii)To ensure at least two persons who have known the foster parent/s well can vouch
for his/her good character and suitability to care for the child;(iv)To establish the person-in-charge
of any Government medical unit in the area that no person in the house hold of the prospective
foster parent/s is suffering from any physical or mental illness likely to affect the child adversely
;(v)To establish from the local authorities or from the Officer in charge of the Police Station in the
area that no person in the home has a police record or has been convicted of a serious criminal
offence rendering it undesirable for the child to associate with that person ;(vi)to ensure that the
foster parent/parents have a stable emotional environment within the family ;(vii)To ensure that the
foster parent/parents have minimum income to meet their needs and not be dependent on the foster
care maintenance payment.(viii)To ensure that the foster care family is willing to follow rules laid
down including regular visits to pediatrician, maintenance of child health record etc. ;(ix)To ensure
that the family shall be willing to sign an agreement to return the child to the agency under specified
circumstances like disruption, abuse and neglect to the child and where the child has been unable to
adjust to the foster family ;(x)To ensure that the foster parent is willing to attend training/
orientation programmes prior to placement and thereafter when found necessary ;(xi)To ensure that
in case of employed parents, adequate childcare arrangements are made after school hours ;(xii)To
ensure that the members of the immediate family living in the same house give their consent to the
placement of the foster child.(B)Procedure for placement of the child. -(a)The Committee shall
ensure that the child is examined by a qualified medical practitioner who shall report in writing on
the child's physical and mental condition prior to placement. However in the case of an emergency
the medical report shall be made within four weeks after the placement.(b)Ensure that efforts have
been made to trace the family before the child is placed.(c)Ensure that the child has been through a
preliminary assessment including :(i)Mental/Development Assessment - Suggested reference by the
Denver Development Scale or any other suitable instrument.(ii)Educational Assessment. - As per
the Minimum Levels of Learning Schedule.(iii)Temperament Assessment. - An assessment of the
Child's temperament needs to be made based on emotionally, level of activity, attention and
concentration ability, sociability levels, aggression, rhythm of food and sleep, child's motivations,
dependability, adaptability.(d)Ensure that the child has been introduced to the couple and has had a
minimum of three interactions and two home visits as well as the requisite number of counselling
sessions with the concerned Social Welfare Officer/Probation Officer.(e)On completion of the above
process the Probation Officer shall prepare a Home study Report in Form XVII.(f)If the Home Study
Report is approved by the Child Welfare Committee, then the foster parents shall enter into a foster
care agreement in Form XX, which includes the rights and responsibilities of the foster parents.Chhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

Each foster parent shall be given a copy of the agreement. A copy of the undertaking shall also be
sent to the concerned Probation Officer/Case worker and to the Commissioner/ Director of Social
Welfare Department.(g)The child shall then be placed with the couple/single parent/Group
home.(C)Target Group(a)The children from dysfunctional in a state families or from institutions or
the children whose biological parents arc cither incapacitated or in a state of crisis and unable to
provide the care and protection to the child.(b)Foster care is a boon to children without roots
growing up in orphanages and child welfare institutions to find an opportunity to lead a family life
;(c)Children who can not be placed on adoption due to various reasons can be considered for Foster
Care ;(d)Foster Care can be either short term or long term depending upon the
needs;(e)De-institutionalization of children and placing them in Foster Care can be made with the
concurrence of Child Welfare Committee.(D)Programme implementation. - The Foster Care shall be
implemented in each district or for a group of districts through Non-Government Organization
which are recognised as fit institutions by Child Welfare committee/ Juvenile Justice Board on the
advice of the Commissioner/Director of Social Welfare specifically for this purpose.(E)Follow-up
:(a)There shall be regular visits carried out by the Probation Officer/Child Welfare Officer/Social
Case Worker, as the case may be so as to protect the best interest of the child ;(b)Review of the
placement report to be made every six months' by the Monitoring and Evaluation Committee. These
Reports shall be submitted to the Child Welfare Committee and the Department of Social Welfare
;(c)In case of victimization of the child in the foster home, appropriate action shall be taken against
the parents ;(d)When the foster placement begins the person placing the child shall submit to the
foster parent a list of immunizations carried out in respect of the child and indicate to the foster
parent the list of the other immunization required to be effected in respect of the child and foster
parent shall ensure that those immunizations are carried out. The foster parents and the District
Probation and Social Welfare Officer shall at all times keep a record of the immunizations in respect
of the child ;(e)Where the child placed with a foster parent is under five years of age, the child shall
be medically examined by a Competent Medical Officer: -(i)Within one month after the date of
placement and (ii) Thereafter once every six months.(f)Where a child placed with a foster parent is
above the age of five years, the child shall be medically examined by medical functionaries once in a
year;(g)The Probation Officer/Case worker concerned shall, so far as possible assist the foster
parent in ensuring the carrying out the requirements.(F)Disruption. -(a)If the Probation
Officer/Case Worker feels that it is in the best interest of the child, he/she may make a report
regarding the necessity for disruption and submit it to the Child Welfare Committee.(b)The
Probation Officer/Case Worker shall also produce before the Child Welfare Committee the record of
efforts put into the remedy the maladjustment;(c)The child may be removed and placed in an
alternative home/transit home wherever maladjustment occurs, after obtaining the consent of the
Child, Welfare Committee and giving the foster parents an opportunity to be heard ;(d)In the case of
an emergency the child may be removed based on the discretion of the Probation Officer/Case
Worker in consultation with the Superintendent and other staff of the children's home, according to
conditions such as physical, or sexual abuse, or exploitation ;(e)Upon disruption of a placement the
Child Welfare Committee shall recommend alternate placement of the child with adequate
provisions for counselling and care.(G)In case of sickness/death of the child or death of the foster
parents. -(a)If a child is seriously ill the foster parent shall as soon as possible inform to the
concerned Probation Officer/Case Worker who shall inform the parents/guardians and the Child
Welfare Committee.(b)If the foster child dies, the foster parent shall make every effort to obtain aChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

medical certificate of death and a post mortem report within 24 hours ;(c)He or she shall also
immediately inform the Probation Officer/Case Worker concerned, who shall inform the
parents/guardians, Department of Social Welfare and the Child Welfare Committee.(d)In the case
where the child has been placed with a single foster parent who has died the child shall be returned
to the approved home from where the child was received.(H)Responsibilities of Child Welfare
Committee/Placement Agencies/ Children's Home :(a)Foster care placements shall be made only
through recognized/ accredited bodies and Probation Officers/Case Workers by the Child Welfare
Committee ;(b)The Child Welfare Committee shall develop, maintain update and employ a written
policy and procedures manual ;(c)The placement agencies/children's home shall satisfy itself that all
alternatives to keep the child in his/her family have been explored and that foster care is the optimal
choice of care for the child ;(d)The placement agency/children's home shall identify, screen, orient
and provide training to the foster families ;(e)The placement agencies/children's home along with
the Child Welfare Committee shall device a system to ;(i)assess the needs of the child and the foster
family ;(ii)match the needs of the child with the abilities and resources of the foster
family.(iii)prepare both the child and the foster family for the placement.(f)The Child Welfare
Committee/Placement Agencies/Children's Home Competent Authority or agency shall support the
child's contact with the biological family whenever possible and when conducive to the child's best
interest.(g)The Placement Agencies/Children's Home along with the Child Welfare Committee shall
begin permanency planning for the child soon after the placement.(h)The Child Welfare Committee
alongwith the Placement agencies/ Children's Home shall develop a procedure for participation with
the foster family in a periodic mutual review. This review will evaluate the strengths and needs of
the foster family for caring for the child and the relationship between the competent authority or
agency and the foster family.(i)The Child Welfare Committee alongwith placement agencies/
Children's home shall develop a policy to recognize the positive contributions made by foster
families to the field of child welfare.(j)The Child Welfare Committee shall develop written policies
and procedures for the closure of foster homes under the different circumstances. This will include
voluntary withdrawal of service by foster families as well. The procedure shall provide the foster
parent/parents an opportunity to be heard before the decision to withdraw the service is arrived
at.(k)The placement agency/children's home shall develop individual case records which shall
include periodic narrative reports relating to the child's and the biological family's involvement with
foster care.
81. Sponsorship.
(1)Sponsorship services shall be considered to supplement the resources of the child and his or her
parent or guardian so as to support efforts to reintegrate the child into the community and finance
his or her education, vocational training, health care, etc., or to supplement the family income to
encourage parent or guardian to fulfill their responsibility to the child.(2)The State shall provide for
the sponsorship of children based on need and availability of resources when they are discharged
from the reception unit/shelter home/children's home/special home/after care institution.(3)The
State Government may allow individuals, institutions, corporate sectors financial institutions,
industries etc. to sponsor or support the following without expecting any gain in return.(i)Any child
or his family shall be supported under sponsorship to withdraw children from child labour/bonded
labour for higher education.(ii)Any activities pertaining to improve the behaviour of children,Chhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

through personality development Programme.(iii)Cultural programmes, picnics, holiday camps,
medical assistances, immunisation programmes, special medical assistance, etc. inter school sports
activities, creative arts and competition seminars for children involving eminent personalities
etc.(iv)Any activities pertaining to the job oriented training programmes, establishment of
vocational rehabilitation centres, community college etc.(v)Establishment of libraries, sports
activities, horticulture/sericulture, creative arts and competitions etc. or any other developmental
programme.(vi)Improving infrastructure and amenities, construction or alteration of building
etc.(4)Management. - (a) The financial assistance under the sponsorship programme shall be
administered by the District Advisory Board. The Board shall process application for sponsorship
put up as per provisions on a case by case basis and then accord sanction for the same.(b)The
payment shall be made through the institution from where the child was discharged.(c)The
agency/institution receiving sponsorship shall maintain proper and separate accounts of all the
receipts and payments for the programme.(5)Criteria for Selection of Children for sponsorship. -
The Children shall be eligible for sponsorship on the following conditions : -(a)Children reinstated
with single Parent/biological families who are under below poverty line.(b)Disabled and other
special needs children requiring specialized intervention/treatment and referred from any
institution or programme under this Act.(c)Children reinstated into the family, where the parent is
disabled or chronically ill but is willing and able to take care of the child.(d)Where the child requires
sponsorship to complete his/her ongoing education/vocational training after discharge from the
institution, up to a maximum period of two years.(e)Any other cases after due
consideration.(6)Duration of the Sponsorship. - The duration of the sponsorship support shall be
decided by District Advisory Board on a case by case basis, based on the recommendations of the
Probation Officer/Case Worker which has been endorsed by the monitoring and evaluation
committee. However the support shall be renewed every year and shall not exceed three years unless
under exceptional circumstances.(7)Procedure for sponsorship support. - (a) The Probation
Officer/Case Worker and Social Worker of the respective reception unit/shelter home/children's
home/after care institution shall visit the home of the child and verify that the child fulfills the
criteria mentioned in clause (5) of Rule 82.(b)Each institution availing of the sponsorship support
under the Act, shall accord the responsibility of undertaking all assessments, home visits,
documentation, review and follow up of sponsored children to the qualified Probation Officer/Case
Worker and Social Worker.(c)Appropriate proof or record of
death/divorce/separation/disability/illness/income Of parent or child, shall be verified and
attached to the case file and a report shall be prepared and submitted to the District Advisory Board
by the Probation Officer/Case Worker and Social Worker.(d)Follow up of the child once in six
months to get an update on the family situation shall be made and a report shall be submitted to the
District Advisory Board. Care shall be taken to ensure that the child is getting adequate education,
nutrition and health care and the child is free from abuse and exploitation.(e)All sponsored children
shall regularly attend formal schooling/skill training/vocational training unless under special
instances of disability or illness of the child, which shall be verified by the Caseworker.(f)In the
event of death of parents at any time the child has to be institutionalized and the sponsorship shall
be discontinued. But institutionalisation shall be the last resort.(g)The child shall not receive
sponsorship support from any other source.(h)Wherever possible, the child shall be referred to
other existing education schemes and services.(i)Appropriate action shall be taken against persons
found to be deliberately misusing the sponsorship support.(j)There shall be a yearly evaluation ofChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

the rehabilitation outcomes for children as far as possible and independent consultants shall be
employed.(k)The Department of Social Welfare shall work out the additional modalities of the
sponsorship programme through a suitable scheme.
Chapter X
Monitoring of Juvenile Justice System
82. Inspection.
(1)The Director/Commissioner Social Welfare Department and any other Officer authorised by him
shall inspect such organization. The programme development monitoring and evaluation cell. The
District Advisory Committee, Local Government Authority shall inspect, monitor and evaluate the
institutional and non-institutional programmes on Juvenile Justice Administration.(2)The
inspection should not be a fault finding mechanism rather it should be constructive. The Inspecting
Officer shall furnish a report to the Director/Commissioner Social Welfare for necessary follow
up.(3)The team may visit the home cither by prior intimation or by surprise.
83. Reporting.
(1)After completing the inspection, the Committee shall be required to submit a report on the
findings within the shortest possible time not exceeding fifteen days. The report should include the
suggestion, request or complaint as made by the concerned person, an objective evaluation of the
compliance of the facilities with the relevant provisions of these rules.(2)Opinion of other relevant
persons including those directly responsible for or named in the complaints shall also be noted and
their reasons and explanations noted verbatim.(3)The inspection committee shall finally make any
recommendation regarding any steps considered necessary to ensure compliance.(4)Any facts
discovered by the Inspection Committee which indicate the violation of legal provisions concerning
the rights of children or the operation of a juvenile justice institution has occurred shall be
communicated to the Competent Authorities for investigation and prosecution.
84. Follow up action.
- The findings of the inspection and the suggestion of the children shall be taken into consideration
by all concerned authorities.
85. Openness and Transparency.
(1)All Home shall be open to visitors with the permission of the Superintendent particularly for the
representatives of Local Self Government, voluntary organisations, Social Workers, researchers,
medicos, academicians, prominent personalities, media and any other person, as the
Superintendent considers appropriate keeping in view the security, welfare and the interest of the
child.(2)The Superintendent of the home shall encourage active involvement of local community inChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

improving the conditions in the homes, if the members of the community want to serve the
institution or want to contribute through their expertise.(3)The Superintendent shall maintain a
visitors book. The remarks of the visitors given in visitors Book shall be considered by the Advisory
inspecting authority.(4)While visiting an institution, the visitors shall not say or do anything that
undermines the authority of the superintendent is in contravention of the Act or rules or impinges
on the dignity of the child.
86. Social Auditing.
- The State Government shall maintain professional research based social audit to monitor and
evaluate the functioning of the Homes and programmes/schemes under the Act on the annual basis.
This shall be done with the help of leading organizations working with the children, besides
Autonomous bodies like National Institute of Public Cooperation and Child Development Indian
Council for Child Welfare, Indian Council for Social Welfare, Indian Social Institute, Childline India
Foundation, National Institute of Social Defence Central and State level Social Welfare Boards,
School of Social Work etc.
87. Monitoring and Evaluation.
(1)Children in need of care and protection are being taken care not only by institutions either run by
Government on its own or by a supporting non-Governmental Organisation financially but also by
voluntary organisation on its own resources. All actions concerning children whether undertaken by
Government or administrative bodies or court or by voluntary organisation the best interest of the
children shall be the prime consideration.(2)In each district there shall be a child protection
committee being represented by non-governmental organisation, media academicians,
philanthropists, Government representatives to monitor and evaluate the child care programmes
with the objective of not only to prevent child abuse, illegal trafficking, child prostitution etc., but
also to ensure qualitative services to children and intervene in all issues concerning children.(3)The
State Government shall ensure to facilitate the optimum usage of community resources to ensure
child protection. To monitor and evaluate child protection there shall be an Ethic Committee
consisting of the following persons : -
(1) Commissioner/Director, Panchayat and SocialWelfare Chairperson
(2) District Collector Member
(3) Superintendent/Commissioner of Police Member
(4)Vice Chancellor, Principal or Professor or Readerof an academic institution
specialized in Psychology,Criminology, Social Work, Home Sciences, Rural
Development etc.Two
members
(5) Media personnelTwo
members
(6) Non Governmental OrganisationsThree
membersChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

(7) Corporate personnelThree
members
(8) Joint Director/Deputy Director, Panchayat &Social Welfare Member
(9) Superintendent of Homes Member
(4)The member specified in serial number (3) to (6) of sub-rule (3) shall be nominated by the State
Government.(5)The committee shall meet once in six months and review the issue concerning the
children related programmes and intervene all matters concerning children. The Chairperson and
members shall visit any child care institution whether run by Government on its own or by
voluntary organisation with or without financial support from Government.(6)The term of the
committee shall be three years and shall be constituted by the District Collector after three years.
88. State Advisory Board.
(1)The State Government shall constitute an Advisory Board as required under Section 62 of the Act,
consisting of the following :
Minister Social Welfare Chairman
Secretary Social Welfare Member
Secretary Education Member
Secretary Health Member
Secretary Home Member
Secretary Law/Judicial Member
Secretary Labour & Employment Member
Secretary Cottage & Small Scale Industries Member
Secretary Technical Education Member
Secretary Industries Member
Secretary Finance Member
Director General of Police Member
A representative of UNICEF Member
An Industrialist Member
A Journalist Member
A representative of Press Council Member
TwoSocial Workers/representatives of Voluntary
OrganisationsCommissioner/Director Social Welfare MemberMember,
Secretary
(2)The advisory Board may advise to the State Government on the following matters namely :
-(a)development of Juvenile Justice Services through various official and Community based Welfare
agencies.(b)the ways and means of mobilising human and material resources to ensure social justice
to the juveniles of both categories.(c)the development of facilities for educational vocational training
and rehabilitation for various categories of juveniles coming within the purview of the Juvenile
Justice System.(d)the co-ordination between various sectors of child development in dealing withChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

the problems of Juveniles processed through the law.(3)The non official members of the Advisory
Board shall be nominated by the State Government on the recommendation of the
Director/Commissioner Social Welfare Department. The non official members shall hold office for a
term of 3 years from the date of nomination and shall be eligible for re-nomination. The non official
member may be terminated by the State Government after giving reasonable opportunity. Any
casual vacancy among non official members shall be filled by the appointment of another non
official who shall hold office so long as the person in whose place is appointed would have held it if
the vacancy had not occurred. The procedure for the meetings of the Advisory Board shall be laid
down by the State Government.
89. District Advisory Board.
(1)The State Government shall constitute a District Advisory Board which shall also perform the role
of inspecting the programme and activities for the effective implementation of the Act.The District
Advisory Board shall consist of the following :
1.Collector Chairperson
2.Superintendent of Police Member
3.Representative of Zila Panchayat Member
4.Chief Medical Officer Member
5.Deputy Director Education Member
6.Secretary Red Cross Member
7.Chairperson Rotary/Lions club Member
8.Two Social Workers Member
9.Two members of Neighbourhood Committee Member
10.Businessman Member
11.Two Donor Member
12.Deputy Director Panchayat & Social Welfare Member, Secretary
13.Superintendent of concerning Home Member
(2)Objective. - The District Advisory Board shall review the activities relating to the Administration
of Juvenile Justice in the District on the following lines :(a)Review the administration and activities
of institutions established under the provisions of the Act.(b)Inspect the institutions established
under the provisions of the Act and report to the Director/Commissioner of Social Welfare
Department.(c)Propose suitable programmes for the up-gradation & development of the
homes.(d)Review the probation work in the district & propose suitable suggestions for effective
implementation.(e)To give support to the programme for the rehabilitation of inmates in the
society.(f)To generate financial support to the inmates for their entire development and
rehabilitation.(g)To create linkages between various agencies working in the field of social welfare
for coordination and cooperation. To bring the inmates in the main stream of the society. ,(h)To
review the minimum standards ensured in the institutions set up under the Act.(i)To review the non
institutional services like Probation, Foster care, Adoption, Sponsorship Programmes etc.(j)To
review the inter coordination between the various departments, community based programmes etc.Chhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

and suggest the suitable remedial measures for effective functioning.(k)To propose necessary
suggestions to improve the quality of institutional and non institutional services
effectively.(3)Nomination of non official members :(a)Nomination of the non official members of
District Advisory Board shall be made by the concerning Collector of the district.(b)The tenure of
the Non Official members shall be for a period of 3 years. The non official member may be
terminated by the Collector after giving reasonable opportunity.(4)Meetings. - The District Advisory
Board shall meet once in 3 months.
Chapter XI
Miscellaneous
90. Juvenile Justice Fund.
(1)The State Government shall create a fund at State level under section 61 of the Act to be called the
'Juvenile Justice Fund' (hereinafter in this rule referred to as fund) for the Welfare and
rehabilitation of the child dealt with under the provisions of the Act. Besides voluntary
donation.(2)The fund shall be used, -(a)to secure the rights and implement programmes for the
welfare and rehabilitation of children ;(b)to pay grant-in-aid to non-official organizations ;(c)to
meet the expenses of State Advisory Board and its purpose ;(d)to do all other things that are
incidental and conducive to the above purposes.(3)The Fund shall be managed and administered by
the State Advisory Board.(4)The assets of the fund shall include all such grants and contributions,
recurring or non-recurring, from the central and State Governments or any other statutory or
non-statutory bodies set up by the Central or State Government as well as the voluntary donations
from any individual or organization.(5)Withdrawals shall be made by cheques or requisitions, as the
case may be of the State Advisory Board in the case of amounts not exceeding Rs. 10,000 (Rupees
ten thousand) shall be duly signed by the Secretary and the amount exceeding rupees ten thousand
shall be duly signed by the Secretary and the Member of the Board of Management to be nominated
by the State Advisory Board.(6)Regular accounts shall be maintained of all money and properties
and all income and expenditure of the Fund and shall be audited by notified firm of Chartered
Accountants or any other recognized authorities as may be appointed by the Board. The auditors
shall also certify that the expenditure from the funds shall be maintained by the Secretary. All
contracts and other assurances shall be in the name of the board of management and signed on their
behalf by the Secretary and one Member of the Board of Management authorised by it for the
purpose.(7)The Advisory Board may delegate to one or more the members such of its powers, which
in its opinion are merely a procedural arrangement.
91. Pending Cases.
(1)No juvenile in conflict with law or a child shall be denied the benefits of the Act and the rules
made thereunder.(2)All pending cases which have not received a finality shall be dealt with and
disposed of in terms of the provision of the Act and the rules made thereunder.(3)Any juvenile in
conflict with law a child shall be given the benefits under sub-rule (1) and it is hereby clarified that
such benefits shall be made available not only to those accused who was a child at the time ofChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

commission of an offence, but also to those who ceased to be a child during the pendency of any
enquiry or trial.(4)While computing the period of detention of stay of child in conflict with law or of
a child, all such period which the juvenile or the child has already spent in custody, detention or stay
shall be counted as a part of the period of stay or detention contained in the final order to the
competent authority.
92. Disposal of records/documents.
- The records/documents in respect of children should be kept in a safe place for a period of 7 years
and thereafter be destroyed by the order of Juvenile Board/Child Welfare Committee.
93. Data Bases.
(1)All the case files maintained by the Institutions, the Child Welfare Committee and the Juvenile
Justice Board should be computerized and networked so that the data is centrally available.(2)Data
relating to missing or lost children shall be specially computerized and networked locally and
centrally through the setting up of Missing Children's Bureau, which shall facilitate the scanning of
children's photographs along with their basic identifying information. All data relating to missing
children shall be disseminated as widely as possible.(3)Names and addresses of all recognized
Children's Homes, fit institutions and other data base of organization, Voluntary Probation Officers,
other support service shall be maintained and updated regularly by the competent authorities. Age
and sex appropriate facilities as prescribed under section 34 of the Act, shall also be mentioned in
the list.
94. Repeal and Saving.
- The Madhya Pradesh Juvenile Justice Rules, 1988 shall stand repealed immediately after the
commencement of these Rules :Provided that any action taken, order, made under the provisions of
the Rules so repealed shall be deemed to have been taken or made under the corresponding
provisions of the Rules.Form I[See sub-rule (10) of Rule 10 and sub-rule (2) of Rule 20]Order for
Social Investigation ReportTo,Probation Officer/Person-in-chargeVoluntary Organisation/Social
Worker/Case Worker.Whereas (1) a report/complaint under section..........................of the Juvenile
Justice (Care and Protection of Children) Act, 2000 has been received from............... in respect of
(name of the child) son/daughter of........................................ residing
at................................(1)....................son/daughter of....................residing at..............has been
produced before the Board/Committee under section........................of the Juvenile Justice (Care
and Protection of Children) Act, 2000.You are hereby directed to enquire into the character and
social antecedents of the said child and submit your social investigation report on or
before.........................or within such time allowed to you by the Board/Committee.Dated
this..................day of...............20.........
Seal (Signature)
 Principal Magistrate/Juvenile Justice BoardChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

 Chairperson, Child Welfare Committee.
Form II[See sub-rule (13) of Rule 10]Supervision OrderWhen the Child is placed under the care of a
parent, guardian or other fit personProfile No ........of....................... 20...........Whereas (name of the
child) has this day found to have committed an offence and has been placed under the care of
(name)........................(address)...................on executing a bond by the said...................and the court
is satisfied that it is expedient to deal with the said child by making an order placing him/her under
supervision.It is hereby ordered that the said child be placed under the supervision of.............
probation officer/case worker, for a period of..................subject to the following conditions. -
1. That the child along with the copies of the order and the bond executed by
the said.............will be produced before the Probation Officer/case worker
named therein.....................
2. That the child will be submitted to the supervision of the Probation Officer.
3. That the child resides at.................for a period of.....................
4. That the child will not be allowed to quit the district jurisdiction
of....................without the permission of the probation officer/case worker.
5. That the child will not be allowed to associate with bad characters.
6. That the child will live honestly and peacefully, and will go to school
regularly/ endeavour to earn an honest livelihood.
7. That the child will attend the attendance centre regularly.
8. That the person under whose care the child is placed will arrange for the
proper care, education and welfare of the child.
9. That preventive measures will be taken by the person under whose care
the child is placed to see that the child does not commit any offence
punishable by any law in force in India.
10. That the child will be prevented from taking narcotic drugs or
psychotropic substances or any other intoxicants.Chhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

11. That the directions given by the Probation Officer/case worker from time
to time, for the due observance of the conditions mentioned above, will be
carried out.
Dated this...........day of.......20...........
Seal (Signature)
 Principal Magistrate/Juvenile Justice Board
 Chairperson, Child Welfare Committee.
*Additional conditions, if any, may be inserted by the Juvenile Justice Board/Child Welfare
Committee.Form III[See sub-rule (15) of Rule 10 and sub-rule (10) of Rule 20]Order of
detentionVide sub-section..................of..................Section.............., sub-section..........of Section and
sub-section................of Section.............To,The Officer in charge/Project
Manager..................................Whereas on the................day of...........200.......(of the child)
son/daughter of..............aged.......residing at...............being found in Profile..........to be child in
conflict with law/child in need of care protection under section is ordered by me...............Principal
Magistrate, Juvenile Justice Board/Chairperson, Child Welfare Committee, under section..............
of Juvenile Justice Act, 2000 kept in the Special Home/Children Home/Shelter Home............... for
a period of.............This is to authorize and require you to receive the said child into your care and to
keep him/her in the Special Home/Children Home/Shelter Home..........................for the aforesaid
order to be carried into according to law.Given under my hand and the seal of Juvenile Justice
Board/Child Welfare Committee.This................day of.........20......(Signature)Principal Magistrate,
Juvenile Justice Board/Chairperson, Child Welfare CommitteeEncl. :Copy of the judgment, if any,
of orders, particulars of home and record :Strike, which is not required.Previous history under the
Juvenile Justice (Care and Protection of Children) Act, 2000.Date.............
Order passed including period of detention ifany Section
 Competent Authority.
Form IV[See sub-rule (14) of Rule 10 and sub-rule (11) of Rule 20]Bond to be executed by a
Parent/Guardian/Relative or fit person in whose care a child is placed under Clause (e), sub-section
(1) of Section 15/sub-section (3) of Section 39Whereas I.............. being the parent, guardian, relative
or fit person under whose care (name of the child has been ordered to be placed by the Juvenile
Justice Board/Child Welfare Committee..................... have been directed by the said Juvenile Justice
Board/Child Welfare Committee to execute a bond in the sum of Rs.................. (Rupees.................)
with one surety*/two sureties. I hereby bind myself on the said...............being placed under my care
I shall have the said................... properly taken care of and I do further bind to myself to be
responsible for the good behaviour of the said................. and to observe the following conditions for
a period of...............years commencing from...................
2. That I shall not change my place of residence without giving previous
intimation in writing to the Juvenile Justice Board/Child Welfare Committee
through the Probation Officer/Child Welfare Officer.Chhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

(2)That I shall not remove the said....................from the limits of the jurisdiction of the Juvenile
Justice Board/Child Welfare Committee without previously obtaining the written permission of the
Board/Committee.(3)That I shall send the said..........................(Name of Child) daily to school/to
such daily work as is approved by the Board/Committee unless prevented from so doing by
circumstances beyond my control;(4)That I shall send the said.................(Name of Child) to an
Attendance Centre regularly unless prevented from so doing by circumstances beyond my
control;(5)That I shall report immediately to the Board/Committee whenever so required;(6)That I
shall produce the said................if he/she seriously misbehaves or absconds from my care;(7)That I
shall render all necessary assistance to the Probation Officer/Case Worker to enable him to carry out
the duties of supervision;(8)In the event of my making default herein. I bind myself to forfeit to
Government the sum of Rs.....................(Rupees......................).Dated this................day
of.................20...............Before me signedSignature of person executing the bond.The Juvenile
Board Justice/Child Welfare Committee may enter additional conditions, if any, numbering them
properly.(Where a bond with sureties is to be executed add)I/We of.....................(place of residence
with full particulars).................. hereby declare myself, surety/ourselves sureties for the
aforesaid............................(name of the person executing the bond)....... do and perform and in case
of his making fault therein; I/We hereby bind myself/ourselves jointly and severally to forfeit to
government the sum of Rs.........dated this the............day of...............20..........in the presence
of.(Signed)Form V[See sub-rule (3) of rule 62]Bond to be signed by child who has been
orderedWhereas, I..............inhabitant of.......(give full particulars) such as house No., road,
village/town, tehsil, district, State........have been ordered to be sent back to my native place by the
Juvenile Justice Board/Child Welfare Committee............................................under section.........of
the Juvenile Justice (Care and Protection of Children) Act, 2000 on my entering into a bond under
sub-rule..............of rule.............of the Juvenile Justice (Care and Protection of Children) Rules,
2003.................................to observe the conditions mentioned herein below. Now, therefore, I
solemnly promise to abide by these conditions during the period..................I hereby bind myself as
follows :(1)That during the period.....................I shall not ordinarily leave the village/town/district
to which I am sent and shall not ordinarily return to.........or go anywhere also beyond the said
district without the prior permission of the Board/Committee;(2)That during the said period I shall
attend work/school in the village/town or in the said district to which I am sent;(3)That in case of
my attending work/school at any other place in the said district I shall keep the Board/Committee
informed of my ordinary place of residence.Signature(Name of Child)Form VI[See sub-rule (3) of
rule 62]I..................... resident of........................(give full particulars such as house No., road,
village/town, tehsil, district, State...........................................do hereby declare that I am willing to
take charge of.................aged........under the orders of the Juvenile Justice Board/Child Welfare
Committee..........................................subject to the following terms and conditions :(1)If his/her
conduct is unsatisfactory I shall at once inform the 'competent authority'.(2)I shall do my best for
the welfare and education of the said...............................................as long as he/she remains in my
charge and shall make proper provision for his/her maintenance.(3)In the event of his/her illness,
he/she shall have proper medical attention in the nearest hospital.(4)I undertake to produce
him/her before the 'competent authority' when so required.Dated this................day
of..............20...SignatureSignature and address of witness(es):Form VII[See sub-rule (3) of rule 61]I,
.....................name and designation of the releasing authority.................. State Govt./UT
Administration, do by this order permit........................................................son/daughterChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

of........caste...................residence..................number.............who was ordered to be detained in a
observation home, special home children home, shelter home, after care home by the Juvenile
Justice Board/Child Welfare Committee......................................................under section............of the
Juvenile Justice (Care and Protection of Children) Act, 2000, for term of............on the..............day
of........20............. and who is now in the.................... homes, at..............to be discharged from the
said...........................on condition that he/she be placed under the supervision and the authority
of.........................................................during the remaining position of the aforesaid period of
stay.This order is granted subject to the conditions endorsed hereon, upon the breach of any which
it shall be liable to revoked.
Dated.......................... Signature and Designation of Releasing
Place.............. Ordering Authority
Conditions :(1)The released person shall proceed to.............and live under the supervision and
authority of..................until the expiry of the period of his/her detention unless the remission is
sooner cancelled.(2)He/She shall not, without the consent of
the.........................................................remove himself/herself from that place or any other place,
which may be named by the said................(3)He/She shall obey such instructions as he/she may
receive from the said................ with regard to punctual and regular attendance at employment or
otherwise.(4)He/She shall attend the Attendance Centre at...............regularly.(5)He/She shall
abstain from committing any offence and shall lead a sober and industrious life to the satisfaction
of............(6)In the event of his/her committing a breach of any of the above conditions the
remission of the period of detention hereby granted shall be liable to be cancelled and on such
cancellation he/she shall be dealt under sub-section (3) of Section 59 of the Juvenile Justice (Care &
Protection of Children) Act, 2000.I hereby acknowledge that I am aware of the above conditions
which have been read over/explained to me and that I accept the same.(Signature or mark of the
released person)Certified that the conditions specified in the above order have been read
over/explained to (Name)........................and that he/she has accepted them as the conditions upon
which the remission of the period of detention has been granted to him/her and that he/she has
been realized accordingly on the.....................Signature and Designation of the Certifying Authority
(i.e. Officer-in-Charge of the institution)Form VIII[See sub-rule (19) of rule 10]Order of fineCase
No.................of..............200.....Whereas....................(name of the juvenile) resident
of.......................... .................(give full address such as house no., road, village, town, District, etc.)
has this day been found guilty of offence under section.................and has been ordered to pay fine of
Rs............and the Juvenile Justice Board is satisfied that it is expedient to deal with the said
Juvenile by making an order placing him/her under supervision.It is hereby ordered that the said
Juvenile be placed under the supervision of........... and shall observe the following conditions
namely : -(1)that he will present himself within 14 days from the date of this order before the
Probation Officer named herein and will produce the copy of the order;(2)that he will submit
himself to the supervision of the Probation Officer;(3)that he will during the period specified herein
keep the Probation Officer advised of his place of residence and means of livelihood/place of
work/place of education and progress in education;(4)that he will attend the attendance centre
regularly;(5)that he will not associate with bad character to lead to dissolute life;(6)that he will live
honestly and peaceably and will go to school regularly/endeavour to earn an honest
livelihood;(7)that he will not commit any offence punishable by any Law in force in India;(8)that heChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

will abstain from taking intoxicants; and(9)that he will carry out such directions as may from time
to time be given by the Probation Officer, for the due observance of the conditions mentioned
above.Dated this...................day of...............200......SignaturePrincipal MagistrateJuvenile
Court*Additional conditions, if any, may be inserted by the Juvenile Court if necessary.To be
renumbered if necessary.Form IX[See sub-rule (12) of rule 9]Information of arrest of a
Child/Juvenile to the Probation Officer
Name of the Juvenile .............................................................................
Age ................................................................................
Son/Daughter of ...............................................................................
Residing at ..............................................................................
Under the care of ...........................................................................
Date and time of arrest ..............................................................................
Place of arrest .............................................................................
Section under which arrested ............................................................................
Brief history of the case .............................................................................
Whetherkept in the Observation Home and if so
name of the ObservationHome ?............................................................................
Date Signature
 Officer-in-Charge of the Police Station
Form X[See sub-rule (13) of Rule 19]Information of arrest of a juvenile to his/her parent or
guardianWhereas name of the juvenile.....................son/daughter
of............................................................. aged.........resident of..................has been arrested under
section..............and has been kept in the Observation Home at......................will be produced before
the Juvenile Court at...............(on date)....................Name of the parent/GuardianResident
of..........................is hereby directed to be present at the Juvenile Justice
Board......................on.................at (time)............
Date Signature
 Officer-in-Charge of the Police Station
Form XI[See sub-rule (1) of Rule 72]Social Investigation ReportSl. No.........Submitted to the
Juvenile Justice Board/Child Welfare Committee...................................................................
...............(Address)
Introductory Information Probation Department
Profile No. Profile No.
 Under section
Title of ProfilePolice StationDetails of Producing AgentName of the person/agency who received,
contacted or apprehended the child :Address :Phone/Fax/E-mail :Reason for Child Coming Under
the Purview of the LawIf the child is alleged to be in conflict with law, under what Section :If the
child is in need of care and protection, what is the child classified as :Missing/Lost
childOrphaned/abandoned childRunaway childMentally challenged childOthersDemographic Data
of the
ChildName.........................................................................................................................Age........................Sex.....................Religion/Occupation.......................................................Education...................................................................................................................PermanentChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

Address and all contact information................................................................................Last address
before coming under the purview of the law......................................................................Three nearest
landmarks to child's present home..............................................................................Family
CompositionMembers of Family
Name......................Age.........Occupation/Wages.....................................................Other
Details...................................................School...............................................such as.healthFather/Step
FatherMother/Step MotherSiblingsOther relatives.First Contact Data(Data collected at the time of
reception, prior to any visit or detailed inquiry)Date and time the child was found :Place where the
child was found giving details of at least three nearest landmarks Condition in which the child was
received with specific remarks about Emergency: any serious injury/abuse requiring medical
attention- Description of activity the child was engaged in at the time of being contacted, if relevant
such as begging, roaming etc.Dress : the colour and type of dress worn at the time, condition in
which the clothes were, etc.- Physical condition : hygiene, general health, hunger, injuries any
observable disability, etc.- Emotional conditions : whether the child was distressed, appeared lost,
asking for help, whether he/she was willing to share information readily, etc. Any specific stress that
the child may be currently under and reason for the same as given by the child.Name and details of
relatives/significant persons/organizations known to the child who can provide any further
information about him/her.Details of any personal belongings that the child may choose to reveal
on his/her person at the time, which could provide further information about his/her background or
circumstances at the time.Reason for the present circumstances as given by the child :- Push factors
(i.e. reasons why child was forced to leave home such as whether he/she complains of
abuse/violence within the home/previous residence)- Pull factors (i.e. reasons why child was
attracted out of the home by outside influences)- Attitude towards parents/family as expressed by
the child (fear, affection, whether he/she wants to go back home or is seeking alternate shelter,
etc.)Home Study ReportDescription of home and living conditionsInitial impression of the
homeNature of place of residence (kutcha, pucca, number of rooms, pavement dwelling, locality,
etc.)Present living conditionsComment on Economic statusFunctionality of the family and family
membersEmotional factorsPhysical conditionSocial factorsEconomic factorsReligious
factorsRelationship between family membersRelationship between parents (according to the child
and other family members)Relationship between parents and children (according to the child and
other family members)Relationship with child under investigation (according to the child and other
family members)Parenting skills and practicesParent attitude towards discipline in the home and
child's reactionIs there any violence or abuse against the child or other family members ? (According
to the child and other family members)History of ChildPhysical condition - any serious illness,
etc.Medical history/Mental illness/MR etc.Friends/associates of the child and significant details
about them Habrts, interests (moral, recreational, etc.)Child's interest in education/schooling as
expressed by his/her School (attitude towards school, Teachers, class mates and vice-versa)Work
record (jobs held, reasons for leaving if any)Vocational interests, (attitude towards job or
employers)Outstanding characteristicsReasons for Coming Under the Purview of The LawIf the
child is considered as being in need of care and protection, what are the reasons given by the child
for his/her present circumstances ?If the child is alleged to be in conflict with the law what are the
reasons given by the child for having allegedly committed the crime ?Any other significant person's
(parent/guardian/social worker/neighbour, etc. known to the child) opinion of the same ?Reason
given by the person who first met/received/apprehended the child In the case of Children affectedChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

by Displacement/Disaster/Conflict, the social investigation report shall contain the following
additional information :Place of originPlace of separation from familySituation at place of origin and
reasons for displacementReason for coming to Chhattisgarh specifically if the child has come from
another State.Period of stay in ChhattisgarhAny other family member displaced with the childOther
institutions, camps lived in (In Chhattisgarh and outside Chhattisgarh)Adult who accompanied the
child to Chhattisgarh if not transferred from an Institution under the Act:Child's relationship with
that adult:Need of the child as assessed by the primary case worker and other expert
assessmentsNeeds, desires and plans as expressed by the child :Result of InquiryAnalysis of the case
and tentative conclusions as to the reasons for neglect or actions deemed to be in conflict with the
law.Problem analysisSummary of personal historyPresent situation and context of child Focusing on
nature, description and cause of neglect/behaviour deemed as being in conflict with law, educational
background, relationship with family, history of abuse, history of institutionalization, etc.)Summary
of family HistoryImpression of functionality of familyOther facts of importance if any such as
significant incidents, which may contribute to the understanding of the child.Need analysisNeeds of
the child as perceived by the childNeeds of the child as perceived by the probation officer/case
workerAny opinion or specific request expressed by the child at the timeTentative conclusions :Is
the child likely to have run away from home, is he/she a lost/missing child, any other tentative
conclusion for the child coming to be in the present circumstances.Any other remarks or specific
observations such as any out of the ordinary remarks, behaviour, whether the details given by the
child seem to be genuine, etc.Recommendation regarding treatment and plan for the
same.According to the child taking into account the future plans/aspirations of the child.As
recommended by the Producing agent/Probation Officer/Child Welfare Officer.Signature of the
Probation Officer/Caseworker.Form XII[See clause (d) sub-rule (2) of Rule 72]Fortnightly Progress
report of Probationer
Part I – Name of the Probation Officer/Case Worker
For the month ofRegister No.Competent AuthorityProfile No.Name of the ChildDate of Supervision
OrderAddress of the ChildPeriod of Supervision
Part II – {|
|-| Places of interview| Dates|-| .....................................| ............................|-| ....................................|
.............................|-| .....................................| ..............................|}
1. Where the child is residing ?
2. Progress made in any educational/training course
3. What work he/she is doing and his/her monthly average earning, if
employedChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

4. Savings kept in the Post Office
5. Savings Bank Account in his/her name
6. Remarks on his/her general conduct and progress
7. Whether properly cared for ?
Part III – 8. Any proceedings before the competent authority of
or
(a)Variation of conditions of bond(b)Change of residence(c)Other matters.
9. Period of supervision completed on.......................
10. Result of supervision with remarks (if any)
11. Name and addresses of the parent or guardian or fit person under whose
care the child is to live after the supervision is over.
Date of report Signature of the Probation Officer/Case Worker
Form XIII[See sub-rule (1) of Rule 18]Report of producing agent on first stage of productionReport
of the person/agency who produced the child in need of care and protection before any authority.
(Points to be taken care of while filling the form).
1. As far as possible the child/juvenile should not be coerced into providing
information for this report.
2. This form shall be filled as soon as possible to the time of receiving the
child/juvenile at the time of being found.
3. Any changes in the information provided by the child/juvenile should be
mentioned in this report.
1. Name of the person/agency referring the juvenile/child :
2. Address :Chhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

3. Phone/fax/E-mail
4. Name of the nearest police station
5. Date and time the child/juvenile was found
6. Name of the authority before whom the child/juvenile was produced
7. Details of the child/juvenile when found :
8. Name and alias of the child/juvenile as and if given by the child/juvenile
9. Approximate age of the child/juvenile
10. Name and Address of the school if given by the child/juvenile
11. Name of place of work if the child/juvenile was employed
12. Name and details of relatives or agencies known to the child/juvenile
13. Details of any personal belonging found on his/her person at the time
14. Details of any family as given by the child at the time
15. Reasons for the present circumstances as given by the child/juvenile -
what was the predisposing factor in terms of what incident provoked the
child/juvenile to leave his/her previous residence and come to be in the
present circumstances.
- Push factors i.e. reasons why the child/juvenile was forced to leave such as whether he/she
complains of abuse/violence within the home/previous residence.- Pull factors i.e. reasons why
child/juvenile was attracted out of the home by outside influences.
16. Place where the child/juvenile was found giving details of atleast three
nearest landmarks.
17. Condition in which the child/juvenile was found with specific remarks
aboutChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

- Emergency : whether there was any serious injury/abuse requiring medical attention.- Description
of the activity the child was engaged in at the time of being found- Dress : the colour and type of
dress worn at the time, condition in which the clothes were- Physical condition : Hygiene, general
health, hunger, injuries, any observable disability- Emotional condition : whether the child was
distressed, appeared lost, asking for help, whether he/she was willing to share information readily.-
Attitude towards parents/family as expressed by the child/juvenile (fear, affection, whether he/she
was willing to go back home or is seeking alternate shelter)- Any outstanding observations (any out
of the ordinary remarks, behaviour, whether the details given by the child seem to be genuine, etc.)-
Any opinion or specific request expressed by the child at the time.Note. - Information for this report
should be taken from documents maintained by the previous institution and Xerox copies of the
same should he enclosed.Form XIV[See sub-rule (1) of Rule 69]Review sheet(1)Degree of overall
adjustment to placementPoor Average Fair Good Very goodAccording to the childAccording to the
Primary case workerReasons for the same as given by the childReasons for the same as concluded by
the Primary Case WorkerRecommendations for the future(2)Participation in the daily activities of
the InstitutionPoor Average Fair Good Very goodAccording to the childAccording to the Primary
Case WorkerReasons for the same as given by the childReasons for the same as concluded by the
Primary Case WorkerRecommendations for the future(3)Performance in academics (if
applicable)Poor Average Fair Good Very goodReasons for the same as given by the childReasons for
the same as concluded by the Primary Case WorkerReasons for the same given by the
teacher/sReasons for the same as given by the parents/guardians (if applicable)Recommendations
for the future.(4)Performance in vocational training (if applicable)Poor Average Fair Good Very
goodReasons for the same as given by childReasons for the same as concluded by the Primary Case
WorkerReasons for the same given by the teacher/sReasons for the same as given by the
parents/guardian (if applicable)Recommendations for the future(5)General Behaviourany
significant changes in behaviour (positive or negative with specific observations on emotional status,
coping strategies)Opinion of the child and reasons for the same as given by the childReasons for the
same as concluded by the Primary Case WorkerRecommendations for the future(6)Health Statusany
significant changes in healthas reported by the medical officeras observed by the primary case
workerany specific complaints that the child has to make at the time of the reviewReasons for the
same as given by the childReasons for the same as concluded by the Primary Case WorkerReasons
for the same as given by the parents/guardians (if applicable)Action to be taken(7)Attempts of the
child to enhance his/her behaviour/performance recordPoor Average Fair Good Very goodReasons
for the same as given by childReasons for the same as concluded by the Primary Case WorkerAny
special achievementsSuggestions/Recommendations for the future(8)Any incidents that have taken
place during the interim period of previous review and the present review that needs to be
recordedNature of incidentOpinion of the child, parent/guardian and case worker about the cause
and result of that incidentImplications for the child's progress(9)Any points brought up by the child
with regard to his/her review report(10)Any other relevant observations or
informationRecommendationsForm XV[See clause (a) of Rule 73]Classification of children &
problem identification with regard to children in need of care and
protectionMissingAbandonedMentally ill or seriously RetardedAlleged to be in conflict with
lawSocial HistoryNote. - This information shall be recorded by the Social Case Worker and updated
regularly as and when additional information is received about the child.(1)Parents :Both alive and
togetherBoth alive but separatedMother and step mother aliveFather and step father aliveOne of theChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

parent dead (single parent)Looked after by step mother/fatherBoth not aliveNot
known(2)GuardiansMaternal uncles/auntsRelativesGrandmother/father/parentsNeighbours
community(3)Child and the addressVery clear and can be locatedClear but difficult to locate-nearby
major places told by the child is locatedClear but not locatable-describes family surroundings in
detailDescription very poor(4)Economic situation at homeEarnings of the family per
monthHome-jhopdi, small thatched house, small concrete house, good house Family-begging,
migrating, stationeryMeals per dayAt home-cycle, Car, Fan, TV, Radio, CookerClothes worn are
tom. Last a child had a new one.Footwear.(5)Child wants to go homeAfraid of homeCrying to go
homeIndifferentNot wanting to go home(6)Parents/relatives are awareParents know that the child
is here - voluntary admissionParents have been told by the child but do not know that the child is
hereParents/guardian do not knowChild did not tell anybody(7)Torture to the child/loved by
whomFather drinks and beatsWork situation - owner beats repeatedlyIf the child do not earn the
family members beatBeaten by friendsBeaten by teachersLoved by parents/guardiansLoved by
whom in the family other than the parentsLoved by someone outside the family(8)Child leaving
home-habitChild has left home for the first timeHas left home more than onceChild has a habit of
leaving home and returning home repeatedlyChild is advised by the parents to leave
home.(9)Members in the child's family and their workFather/guardianMotherYounger brotherElder
brotherYounger sisterElder sister(10)Reasons as to why the child left home.Form XVI[Item (i) of
clause (b) of sub-clause (2) of Rule 78]Enquiry Report of Probation Officer to declare a Child as
Legally Free for AdoptionName of the Probation OfficerDistrict
P.E. No. Date:
(1)Details of the child against Whom the abandoned certificate is
requested.(a)Name(b)Age(c)Identifications marks etc.(2)Name & address of the organisation which
has filed the petition before the Child Welfare Committee.(3)Whether the Organisation was
Licenced to process Adoption If so, the details are to be furnished including the validity of the period
of licence granted.(4)Date of application filed before the Child Welfare Committee.(5)Child Welfare
Committee No. and Date of reference to the Probation Officer.(6)How the organisation received the
child (The details such as sources information, place of abandoned, date and time to take charge of
the child etc., are to be furnished)(7)Whether the organisation has sent a report to the nearest Police
Station about the Receipt of the child. If so, details are to be furnished.(8)Whether the organisation
has sent a report to the Child Welfare Committee about the Receipt of the child (details are to be
furnished)(9)The action taken by the Police to identify the Biological parents or the interested
guardians. Details are to be furnished.(10)The action initiated by the organisation to trace the
Biological parents or the interested guardians. Details are to be furnished.(11)The detailed enquiry
conducted by the Probation Officer.(12)RecommendationProbation Officer/Social WorkerForm
XVII[See item (ii) of sub clause (b) of clause (A) of sub rule (4) of Rule 80]Home Study of Foster
FamilyHome Study Report shall contain the following :
1. Identifying information such as background information of the foster
parent/ parents including identifying information, education, family history,
medical history, employment history, residence & facilities, lifestyle,
parenting/child care experience and the motivation to take child in fosterChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

care, duration of foster care offered, supported by necessary documents
such as certificates of proof of age, proof of marriage, general health
certificate, income statement, letters of reference, consent of persons
residing in the family photographs of the couple, photos of child. Case study
of the child.
2. Antecedents of the prospective foster family including :
Their own childhood experiences, upbringing and interpersonal relationships. Information on other
members of the familyAttitude of the children and relatives of the foster family towards the foster
care planSocial, ethno-cultural, linguistic and religious identity of the prospective foster
familySanctions against any charges of criminal offence and child abuse.
3. Recent photograph of the family
4. Physical, intellectual, emotional and educational status of prospective
foster family.
5. Medical report on the family's health status and health history
6. Employment and financial assets
7. Accommodation and community environment
8. Motivation
9. Ability to provide nurturing care and supervision in an atmosphere of
affection and moral and material security.
10. Statement of positive reference and emotional support from relatives,
friends community.
11. Assessment by a multidisciplinary support team of professionals (as far
as possible) stating :
Their reasons for approving the prospective foster parent/sDetails of the child (age, sex, acceptance
of siblings, special needs child etc.) they would prefer to adopt and are capable of parenting.Form
XVIII[See sub clause (a) of clause (A) of sub rule (4) of Rule 80]Application Format for Foster
CareName of the
Applicant.....................................................................Married/Single......................................Age...................................Address...................................................................................Tel.Chhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

No...................................................................................Number of
children..................................Age...................................Employment of
Applicant...................................................................Employment of
Husband.....................................................................Employment of Wife :Other Sources of
Income...................................................................Have you ever fostered a child before ? (If so give
particulars)
Name of the Child Age Period of Foster Care
........................................ .......................... ...................................
.......................................... ............................ ....................................
Reasons to Foster:......................................................................................Are you willing to undertake
short-term foster care ?Yes NoIf Yes, Specify the Period........................................References (Name
& Address of two persons)Age, Sex and other specifications of child you desire to foster
:Date..............Form XIX[See sub rule 1 of Rule 43]Application for Certification
Taluk Town/village
District:  
1. Name of the institution .............................................................
2. Date of establishment ...............................................................
3. Please furnish the details under which Act,the
registration is made with No. Date place of
registration etc................................................................................
4. Sources of funds with details .................................................................
5. Names of members of governing body and their addresses
...................................................................................
6. Activities of the organisation ................................................................
7. If financial assistance is received for any activities/ programmes from
State/Central Quasi
Govt./other funding Agencies including foreign grant the Details may be furnished
..................................................................................
8. Infrastructure available
(a) Total area of the campus .......................................................................................
(b) Plinth area of each floor of the
buildingand number of floors........................................................................................Chhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

(c) Play grounds .......................................................................................
(d) Details of buildings for academic
programmescubical areas of each Class
room........................................................................................
(e) Details of vocational inputs and the
Plinthareas for Vocational centre. Cubical
areas as each trade........................................................................................
(f) Kitchen, dormitories, prayer hall etc. .......................................................................................
(g) Facilities for Primary education
Secondaryeducation, Higher Secondary
Education........................................................................................
(h) If no school Section is attached
theDistance of outside school from the
campus........................................................................................
(i) Details of library, indoor games,
sciencelab etc. (if available).......................................................................................
Nearest hospital (Govt.) address & distance. ........................................................................................
9. Sanitary conditions in the institutions .......................................................
10. Water resources whether adequate or not should be spelled out
..............................................................................
11. Address for communication including grams, Fax, E-mail
etc.............................................................................
12. Name & address of the contact persons....................:....................................
13. Details of staff in their existing programmes.................................................
14. Any other relevant
information................................................................................................................................
15. Resolution of the governing body..............................................................
DeclarationOn behalf of the management of the organisation. I hereby declare that the Management
shall fulfil all conditions specified in the Juvenile Justice (Care and Protection of Children) Act,
2000 and the rules relating thereto and I promise to comply with all the conditions laid down for
certificate being dealt with by the Juvenile Justice (Care and Protection of Children) Act, 2000 as
laid down by the said Act and rules relating thereto and to furnish such returns as may be required
by the Commissioner/Director Panchayat & Social Welfare.Authorised SignatoryForm XX[See sub
clause (f) of clause (B) of sub clause (4) of Rule 80]Foster care agreementI/We (name of fosterChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

parent/s ...........................................who received (name of child).................in my/our home on
(date)...............from......................... undertake that we will do all the following :Ensure that the
child's Physical Needs are met:Meet the child's basic needs for food, clothing and shelter Feed the
child nourishing meals on a regular basis. Regularly check the child clothing needs and keep the
child well clothed year around. Provide for the child's personal care, health and hygiene needs.
See that the child is clean and well groomed. Teach personal hygiene methods when necessary.
That the child's medical needs are regularly checked and met. Assure that the child follows a
healthy, structured daily routine. Provide opportunities for the child to get regular and sufficient
exercise.Ensure that the child's emotional needs are met : Include the child in all family activities.
Express affection often. Demonstrate affection in appropriate, healthy ways. Seek to establish
supportive relationship with child's biological family. Never speak negatively about the child's
family or history. Listen and empathize. Help children advance through the grieving and
adjustment process that accompanies removal from their homes and placement. Respect
confidentiality of the child.Ensure that the child's Educational needs are met: Enroll the child in a
school. Provide for daily attendance at school. Provide a quiet physical space for the child to
complete school assignments. Monitor the child's educational progress. Attend any after school
meeting required. Provide access to after school activities, sports etc..Ensure Discipline tasks are
undertaken : Provide consistent and realistic discipline and guidance that is age appropriate and
does not involve corporal punishment!Work with Probation Officer/Social Welfare Officer : Attend
all meetings and participate fully. Provide adequate information regarding the child's progress,
behaviors at home and school to the probation officer/social welfare officer. Notify the probation
officer/social welfare officer immediately in all emergencies. Submit all requested documents in a
timely manner. Participate in planning for the child-permanency, treatment, options etc.. Inform
the probation officer/social welfare officer concerned immediately of plans to change residence and
address. Adhere to procedures and principles laid down in the Juvenile Justice (Care and
Protection of Children) Act, 2000 and Rules. Agree that the social welfare officer/probation officer
can remove the child from the home in the case of violation of any of the rules laid down under this
Act.
 .....................................
(Address of Foster Parents) (Signed Foster Mother)
Form XXI[See clause (o) of sub-rule (2) of Rule 72]History Sheet(History Sheet of Licence
discharged pupils)
1.Serial number .....................................................................................................................
2.Name of the pupil
discharged on licence.....................................................................................................................
3.Sex, Age, Religion .....................................................................................................................
4.Address of the child .....................................................................................................................
5.Name of the institution
& child's
admissionnumber.....................................................................................................................
6.Order No. & date of
Competent Authority.....................................................................................................................Chhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

 Who orders the
placement.....................................................................................................................
7.Period of placement &
Actual date ofdischarge.....................................................................................................................
8.Date of Discharge on
Community based
Programme.....................................................................................................................
9.Educational standard
in the Institution.....................................................................................................................
10.Vocational Training (if
any) undergone in
theInstitution.....................................................................................................................
11.Number & Date of
release on Community
BasedProgramme.....................................................................................................................
12.Whether discharged on
Community based
underProgramme
under Family
Assistance Scheme.....................................................................................................................
Name of the Supervising Probation Officer..............................................................Address of the
Probation Officer.......................................................................Date from which the Probation Officer
takes Charge of this Licence.....................................(Follow up sheet shall be added)Continuation
Sheet/Follow-Up Sheet
Date of admission in the
Main UnitRecommendation of the Classification
CommitteeReason for admission
  Detail of the caustic factors for
admission
 (a) Educational input  
 (b) Vocational training  
 (c) Personality Development
Programmes 
 (d) Other treatment programmes  
Date.......... Follow-Up Details Signature of Probation Officer
Form XXII[See sub-rule (5) of Rule 55]Medical History SheetName of the
child.........................................................................................................Adm.
No................................Age......................................Address of the
parent/guardian...................................permanent...........................Present.............................Date of
admission..........................................................................................Order No. and date of the
Competent Authority who orders the Admission.....................................Probable date of
discharge.................................................................................Height & Weight at the time of
admission...................................................................PhysicalChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

structure.........................................................................................Health status of the child at the time
of admission .......................................................Present/Absent/Not known(a)Respiratory
disorder(b)Hearing impairment(c)Eye diseases(d)Dental diseases(e)Cardiac diseases(f)Skin
diseases(g)Sexually transmitted diseases(h)Neurological disorders(i)Mental handicap(j)Physical
handicap(k)Others (pl. Specify)Medical History of child (in gist)Medical History of parent/guardian
(gist)Form XXIII[See clause (a) of rule (5) of Rule 73]Case History Format
A. Personal Data  
1. Name Male/Female
  (Tick the appropriate category)
2. (a) Age at the time of admission  
 (b) Present age  
3. Religion Hindu - O.C./B.C./M.B.C./S.C./S.T.
  Muslim
  Christian
  Others (Please specify)
4. Location of Residence Urban/Sub-urban/Rural/Slum/
  Industrial/Others (Please specify)
5. Native District and State
6. Description of the Housing
(i)Concrete building/tiled House/Hut/On the Street/others (Please specify)(ii)Three bed room/two
bed room/one bed room/no separate bed room(iii)Owned/rental
7. By whom the Juvenile was brought before the Child Welfare Committee
(i)Police Local Police/Juvenile Aid Police Unit/railway Police/women Police(ii)Probation
Officers/Social Welfare(iii)Social Welfare Organisation(iv)Social Worker(v)Parent (s) Guardian (s)
(Pl. specify the relationship)(vi)Child himself/herself
8. Reasons for leaving the family
(i)Abuse by Parent(s) Guardian(s)/Step parent(s)(ii)In search of employment(iii)Peer group
influence(iv)Incapacitation of parents(v)Criminal behaviour of parents(vi)Separation of
parents(vii)Demise of parents(viii)Poverty(ix)Others (Pl. specify)
9. Types of abuse met by the child
(a)Verbal abuse-Parents/Siblings/Employers/Others (Pl. specify)(b)Physical abuse(c)Sexual abuse
Parent/Siblings/Employers/Others (Pl. specify)(d)Others Parent/Siblings/employers/Others (Pl.
specify)Chhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

10. Types of ill-treatment met by the child
 (i) Denial of foodParents/Siblings/Employers/Others (Pl.
specify)
 (ii) Beaten mercilesslyParents/Siblings/Employers/Others (Pl.
specify)
 (iii) Causing injuryParents/Siblings/Employers/Others (Pl.
specify)
 (iv) Others (Pl. specify)Parents/Siblings/Employers/Others (Pl.
specify)
11. Exploitation faced by the child.
(i)Extracted work without payment(ii)Little (Low) wage with longer duration of work#(iii)Others
(Pl. specify)
12. Health Status of the child before admission
 (i) Respiratory disordersPresent/Not
known/Absent
 (ii) Hearing impairmentPresent/Not
known/Absent
 (iii) Eye diseasesPresent/Not
known/Absent
 (iv) DentalPresent/Not
known/Absent
 (v) Cardiac diseasesPresent/Not
known/Absent
 (vi) Skin diseasesPresent/Not
known/Absent
 (vii) Sexually transmitted diseasesPresent/Not
known/Absent
 (viii) Neurological disordersPresent/Not
known/Absent
 (ix) Mental handicapPresent/Not
known/Absent
 (x) Physical handicapPresent/Not
known/Absent
 (xi) Others (Pl. specify)Present/Not
known/Absent
13. With whom the
child was staying
prior toadmission Chhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

(i) Parent(s)
Mother/Father/Both 
(ii) Guardian(s)
Relationship 
(iii) Friends   
(iv) On the Street   
(v) Night Shelter   
(vi)
Orphanages/Similar
Homes/Hostels 
(vii) Others (Pl.
specify)  
14.Visit of the parents
to meet the child
priorto
institutionalisationFrequently/Occasionally/Rarely/Never
After
institutionalisation Frequently/Occasionally/Rarely/Never
15. Visit of the child
to his family prior
toinstitutionalisationFrequently/Occasionally/Rarely/during
festivaltimes/during summer holidays/
whenever fallen sick/never
After
institutionalisation Frequently/Occasionally/Rarely/during
festivaltimes/during summer holidays/
whenever fallen sick/never
16. Correspondence
with parents prior
toinstitutionalisationFrequently/Occasionally/Rarely/during
festivaltimes/during summer holidays/
whenever fallen sick/never
After
institutionalisation Frequently/Occasionally/Rarely/during
festivaltimes/during summer holidays/
whenever fallen sick/never
B. Childhood History (Upto the age of 12 years)
17. Diet of Mother during pregnancy
(i)Taken nutritious diets(ii)Ordinary diet(iii)Inadequate food intake.
18. Health during pregnancy
(i)Mother infected with contagious diseases(ii)Mother consumed/used contraceptives(iii)Mother
met with accident/injured(iv)Intake of antibiotics(v)No such details availableChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

19. Birth details
(i)Normal delivery/prolonged delivery/caesarian(ii)Under weight/Normal weight/over weight
20. Details of immunisation provided
21. Details of handicap
 (i) Hearing impairment By Birth/After accident/diseases
 (ii) Speech impairment By Birth/After accident/diseases
 (iii) Physical handicap By Birth/After accident/diseases
 (iv) Mental handicap By Birth/After accident/diseases
 (v) Others (Pl. specify)  
Family Details
22. Household composition
S.
No.Relation-ship Age Sex Education Occupation Income HealthHistory
of
Mental
illnessHandicaps Habit Socialisation
            
23. Type of family
Nuclear family/Extruded family/Joint family/Broken family
24. Relationship among the family members
 (i) Father and mother Cordial/Not cordial/Not known
 (ii) Father and child Cordial/Not cordial/Not known
 (iii) Mother and child Cordial/Not cordial/Not known
 (iv) Father and siblings Cordial/Not cordial/Not known
 (v) Mother and siblings Cordial/Not cordial/Not known
 (vi) Juvenile and siblings Cordial/Not cordial/Not known
25. History of crime committed by family members.
S.
No.RelationshipNature of
CrimeArrest if any
madePeriod of
confinementPunishment
awarded
1. Father     
2. Step Father     Chhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

3. Mother     
4. Step mother     
5. Brother     
 (i)     
 (ii)     
 (iii)     
 (iv)     
6. Sister     
 (i)     
 (ii)     
 (iii)     
 (iv)     
7. Child     
8.Others
(uncle/aunty/grandmother)   
26. Properties owned by the family (I) Landed properties (Pl. specify the area)
(ii) Household articles Cows/Cattle/Bull/others (iii) vehicle two wheeler/Four
wheeler/ (lorry/bus/car/tracker/jeep) (iv) Other (Pl. specify)
27. Marriage details of family members
 (i) Parents Arranged/Special Marriage/Local Union
 (ii) Brothers Arranged/Special Marriage/Local Union
 (iii) Sisters Arranged/Special Marriage/Local Union
28. Social activities of family members
(i)Participate in social and religious function(ii)Participate in cultural activities(iii)Does not
participate in social and religious function(iv)Not known
29. Parental care towards Juvenile before admission
(i)Over protection(ii)Affectionate(iii)Attentive(iv)Not affectionate(v)Not attentive(vi)RejectionC.
Adolescence History (Between 12 and 18 Years)
30.
PubertyEarlyMiddle ageLateChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

31.
Details of delinquent behaviour if any(i)Stealing(ii)Pick pocketing(iii)Arrack selling(iv)Drug
pedaling(v)Petty offences(vi)Violent crime(vii)Rape(viii)None of the above(ix)Others (Pl. specify)
32.
Reason for delinquent Behaviour(i)Parental neglect(ii)Parental overprotection(iii)Parents criminal
Behaviour(iv)Parents influence (negative)(v)Peer group influence(vi)To buy
drugs/alcohol(vii)Others (Pl. specify)
33. Habits
 A B
 (i) Smoking (i) Watching T.V.
 (ii) Drinking (ii) Go to movie
 (iii) Drug abuse (specify) (iii) Reading books
 (iv) Gambling (iv) Religious activities
 (v) Prostitution (v) None of the above
 (vi) None of the above  
34. Employment details
Employmentdetails of the Juvenile prior to entry
into Juvenile Home
 S.
No.Details of
EmploymentDurationWage
earned
 (i) Cooly   
 (ii) Rag picking   
 (iii) Mechanic   
 (iv) Hotel Work   
 (v) Tea Shop Work   
 (vi) Cycle Shop work   
 (vii) Shoe Polish   
 (viii) House hold works   
 (ix) Others (Pl. specify)   
D. Employment Details :Chhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

35. Details of income utilisation
(i)Sent to family to meet family need(ii)For dress materials(iii)For gambling(iv)For
prostitution(v)For alcohol(vi)For drug(vii)For smoking(viii)Savings
36. Details of Savings
(i)With employers(ii)With friends(iii)Bank/Post Office(iv)Others (Pl. specify)
37. Duration of working hours
(i)Less than six hours(ii)Between six and eight hours(iii)More than eight hoursE. Educational
Details
38. The details of education of the Juvenile prior to the admission to Juvenile
Home.
(i)illiterate(ii)Studied upto V std.(iii)Studied above V Std. but below VIII Std.(iv)Studied above VIII
Std. but below X Std.(v)Studied above X Standard.
39. The reason for leaving the school
(i)Failure in the class last studied(ii)Lack of interest in the school(iii)Indifferent attitude of the
teachers(iv)Peergroup influences(v)To earn and support the family(vi)Sudden demise of
parents(vii)Rigid school atmosphere(viii)Abstention followed by running away from school(ix)Other
(Please specify).
40. The details of the school in which studied last
(i)Corporation/Municipal/Panchayat Union(ii)Government/Backward Class Welfare
School(iii)Private Management(iv)Convents.
41.
Medium of instruction HindiTamilEnglishMalayalamTeluguKannadaOther language (Place specify)
42. After admission to Juvenile Home the educational attainment from the
date of admission till date.
 No. of years Class studied Promoted/DetainedChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

43. Vocational training undergone from the date of admission into Juvenile
Home till date.
 No. of years Name of Vocational trade Proficiency attained
44. Extra curricular activities developed from the date of admission into
Juvenile Home till date.
(i)Scout(ii)Sports (Please specify)(iii)Athletics (Please specify)(iv)Drawing(v)Painting(vi)Others
(Please specify)F. Social History
45. Details of friendship prior to admission into Juvenile Home.
(i)Co-workers(ii)School/Classmate(iii)Neighbours(iv)Others (Pl. specify)
46. Majority of the friends are
(i)Educated(ii)Illiterate(iii)The same age group(iv)Older in age(v)Younger in age(vi)Same
sex(vii)Opposite sex
47. Details of membership in group
(i)Associated with cine fans association (Pl. mention the name)(ii)Associated with Religious
group(iii)Associated with arts and sports club(iv)Associated with gangs(v)Associated with voluntary
social service league(vi)Others (Pl. specify)
48. The position of the juvenile in the groups/league
(i)Leader(ii)Second level leader(iii)Middle level functionary(iv)Ordinary member
49. Purpose of taking membership in the group
(i)For Social service activities(ii)For leisure time spending(iii)For pleasure seeking activities(iv)For
deviant activities(v)Others (Pl. specify)
50. Attitude of the group/league.
(i)Respect the social norms and follow the rules(ii)Interested in violating the norms(iii)Impulsive in
violating the ruleChhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

51. The location/meeting point of the groups
(i)Usually at a fixed place(ii)Places are changed frequently(iii)No specific places(iv)Meeting point is
fixed conveniently
52. The reaction of the society when the Juvenile first come out of the family.
(i)Supportive(ii)Rejection(iii)Abuse(iv)Ill-treatment(v)Exploitation
53. The reaction of the police towards children whenever they were dealt with
(i)Passionate(ii)Cruel(iii)Abuse(iv)Exploitation(v)Ill-treatment.
54. The response of the general public towards the children.Chhattisgarh Juvenile Justice (Care and Protection of Children) Rules, 2006

