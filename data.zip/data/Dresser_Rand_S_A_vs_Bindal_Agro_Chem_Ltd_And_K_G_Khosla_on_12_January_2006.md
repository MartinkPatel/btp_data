Dresser Rand S.A vs Bindal Agro Chem Ltd And K. G. Khosla ...
on 12 January, 2006
Equivalent citations: AIR 2006 SUPREME COURT 871, 2006 (1) SCC 751, 2006
AIR SCW 277, 2006 CLC 153 (SC), (2006) 3 ALLMR 21 (SC), 2006 (2) SRJ 375,
2006 (1) ARBI LR 171, 2006 (1) SCALE 218, 2006 (1) KCCR 28 SN, 2006 (3)
ALL MR 21 NOC, (2006) 1 ARBILR 171, (2006) 2 MAD LW 849, (2006) 86 DRJ
630, (2006) 2 SCJ 366, (2006) 70 CORLA 135, (2006) 1 SUPREME 212, (2006) 1
SCALE 218, MANU/SC/151/2006, (2006) 131 COMCAS 805, (2006) 126 DLT 437
Bench: Arun Kumar, R V Raveendran
           CASE NO.:
Appeal (civil)  8357 of 2003
PETITIONER:
Dresser Rand S.A.                               
RESPONDENT:
BINDAL Agro Chem Ltd and K. G. Khosla Compressors Ltd.
DATE OF JUDGMENT: 12/01/2006
BENCH:
Arun Kumar & R V Raveendran
JUDGMENT:
J U D G M E N T With Civil Appeal No. 8358 of 2003 Raveendran J., These appeals arise from the
judgment of the Delhi High Court in FOA (OS) Nos. 94, 113, 136 and 137 of 2002 dated 04.3.2003
affirming the order dated 14.2.2002 passed by a learned single Judge of High Court of Delhi in I.A.
Nos. 5795/93, 9246/93 in Suit No. 1362/93 and I.A. Nos. 5819/93, 9355/93 in Suit No. 1380 of
1993.
2. For convenience, Dresser Rand S.A. [Appellant in both the appeals], BINDAL Agro Chem. Ltd.,
[Respondent No. 1 in both appeals] and K. G. Khosla Compressors Ltd. [Respondent No. 2 in both
appeals] will also be hereinafter referred to as DR, BINDAL and KGK respectively.
3. BINDAL has filed Suit Nos. 1363/1993 in the Delhi High Court, for a declaration that there exists
no arbitration agreement between itself and DR and for a consequential injunction restraining DR
from proceeding with the arbitration before the International Chamber of Commerce, Paris. KGK
has also filed Suit No. 1380/1993 in the said court for similar relief.
4. BINDAL and KGK have filed IA Nos. 5795/93 and 5819/1993 respectively in their respective suits,Dresser Rand S.A vs Bindal Agro Chem Ltd And K. G. Khosla ... on 12 January, 2006

under Order 39 Rules 1 and 2 CPC seeking a temporary injunction to restrain DR from proceeding
with the arbitration.
5. DR has filed I.A. No. 9246/1993 in Suit No. 1363/1993 and I.A. No. 9355/1993 in Suit No.
1380/1993 under Section 3 of the Foreign Awards (Recognition and Enforcement) Act, 1961 [for
short 'Foreign Awards Act'] for staying further proceeding in the said suits. DR contended that there
was an arbitration agreement between itself and BINDAL and KGK and consequently, further
proceedings in the suits filed by BINDAL and KGK should be stayed under section 3 of the Foreign
Awards Act.
6. A learned single Judge of the High Court heard the four applications in the two suits and passed a
common order dated 14.2.2002. He held that the plaintiffs in the two suits (BINDAL and KGK) had
made out a prima facie case for grant of a temporary injunction restraining DR from proceeding
with the arbitration. He also held that DR had failed to prove that any provisional concluded
arbitration agreement had come into existence between either DR and BINDAL or DR and KGK. He
also held that in the absence of any tripartite arbitration agreement, it may not be possible to decide
the obligations between BINDAL and KGK. He, therefore, allowed the applications for temporary
injunction filed by BINDAL and KGK and restrained DR from proceeding with the arbitration,
subject however to BINDAL and KGK furnishing a bank guarantee to an extent of 5% [3% by
BINDAL and 2% by KGK] of French Francs 4,93,00,000 and 5,26,25,000. The learned single Judge
dismissed the applications filed by DR under section 3 of the Foreign Awards Act by holding that no
valid or operative agreement capable of being performed had come into existence by issue of Letters
of Intent signed by KGK and counter-signed by DR. The said order dated 14.2.2002 in so far as it
grants temporary injunction is an interim order and in so far as it rejects DR's applications for stay
under section 3 of the Foreign Awards Act is a final order. The said common order granting
temporary injunction restraining it from proceeding with the arbitration was challenged by DR in
FAO (OS) No.136/2002. The said common order rejecting the two applications for stay under
Section 3 of the Foreign Awards Act was challenged by DR in FOA (OS) No.137 of 2002. BINDAL
and KGK challenged the said common order in so far as it imposed a condition (relating to
furnishing of Bank Guarantee) for temporary injunction, in FAO (OS) No.94/2002 and FAO (OS)
No.113/2002 respectively.
7. A Division Bench of the Delhi High Court by common order dated 4.3.2003 dismissed the appeals
filed by DR and allowed the appeals filed by BINDAL and KGK. The Division Bench affirmed the
finding of the learned single Judge of the High Court that there was no arbitration agreement and
consequently, upheld the rejection of the applications under section 3 of the Foreign Awards Act.
The Division Bench while affirming the temporary injunction granted by the learned Single Judge
restraining DR from proceeding with the Arbitration, deleted the requirement imposed by the
learned Single Judge relating to furnishing of bank guarantee by BINDAL and KGK.
8. Feeling aggrieved, DR has filed these civil appeals by special leave [CA No.8357/2003 and CA
No.8358/2003] challenging the rejection of FAO (OS) No.136/2002 and FAO (OS) No.137/2002.
On the contentions urged, the following questions arise for consideration in these appeals :-Dresser Rand S.A vs Bindal Agro Chem Ltd And K. G. Khosla ... on 12 January, 2006

(i) Whether there is an arbitration agreement between DR and BINDAL;
(ii) Whether there is an arbitration agreement between DR and KGK;
(iii) Whether BINDAL and KGK are estopped from contending that there is no
arbitration agreement, in view of their counsel having stated in his telex dated
11.4.1993, that his clients were in the process of jointly appointing an arbitrator.
FACTUAL BACKGROUND :
9. BINDAL wanted to invite global tenders for supply of various equipments and materials for its
Shahjahanpur Fertilizer Project. For that purpose, it prepared its standard 'Invitation to Bid'
comprising "Conditions of Purchase for Supply of Equipment and Material under ICB Procedure -
Shahjahanpur Fertilizer Project". The said Invitation to Bid consisted of the following sections :-
(i) Attachment I  Instructions to bidders (Articles 1 to
34);
(ii) Attachment II  General conditions of purchase (Articles 1 to 36);
(iii) Attachment III to XVI : Special conditions of purchase (Attachment-III),
schedule of requirements (Attachment-IV), Technical Specifications (Attachment-V)
Bid Form and Price Schedules (Attachment VI), Purchase Order Form (Attachment
VII), Spare Parts List (Attachment-VIII), Vendor Data Requirements
(Attachment-IX), List of Lubricants (Attachment-X), Progress Trend Charts
(Attachment- XI), Draft form of Performance Guarantee (Attachment-XII), Draft
Form of Bank Guarantee for Advance/Progress Payments to Supplier (Attachment-
XIII), Bid Security Form (Attachment-XIV), General specifications for packing
(Attachment-XV) and check list (Attachment-XVI).
10. BINDAL sent a telex dated 12.1.1990 to DR informing that it was implementing a Gas-based
Fertilizer Plant at Shahjahanpur and it was in the process of exploring possibilities for securing
various equipments including Synthesis Gas Compressors, Process Air Compressors, Refrigeration
Compressors and CO2 Compressors and enquired whether DR would be interested in supplying the
equipments. DR sent a reply dated 18.5.1990 offering to supply Syn-Gas Compressor and indicating
the total price of the compressor and spare parts. The matter was dormant for some times. By letter
dated 16.3.1991, BINDAL informed DR that the necessary Government approval for fertilizer project
has been received and, therefore, it wished to revive the discussions for supply of Syn. Gas
compressors and CO2 compressors. By fax dated 5.4.1991, BINDAL requested DR for a quotation to
be followed by a formal Bid for Syn-Gas and CO2 compressors and informed DR that having regard
to the tight foreign exchange situation, the Government of India had allocated only 50% of its total
foreign exchange requirement and, therefore, it had decided to limit its imports only to moving
machinery, cutting out static equipment. DR sent a reply dated 16.5.1991, quoting its price for Syn.Dresser Rand S.A vs Bindal Agro Chem Ltd And K. G. Khosla ... on 12 January, 2006

Gas compressor and proposed to discuss the modalities of DR having overall responsibility for
various compressor turbines/auxiliaries not included in the scope of supplies, as also commercial
points. This was followed by a meeting between the representatives of DR and BINDAL wherein the
technical details in regard to performance of the syn. gas compressor discussed.
11. Thereafter, DR gave its comments/modifications to the terms and conditions of BINDAL termed
as "Revision 4 (Attachment IV)" dated 10.6.1991 wherein it set out the amendments/modifications it
required to BINDAL's 'General Conditions of Purchase'. The said "Revision 4" was initialled by the
representatives of DR and BINDAL, presumably in token of the changes agreed in the standard
General Conditions of Purchase of BINDAL.
12. We extract below relevant portions of clauses 1 and 27 in the BINDAL's 'General Conditions of
Purchase' and the modifications thereto by DR (Note : We are not referring to other clauses of
'General Conditions of Purchase' or the modifications thereto by DR, as they are not relevant for our
immediate purpose) :
Clause No. BINDAL's General Conditions of Purchase Modifications made by DR 1.0
DEFINITIONS In this General Conditions of Purchase the following terms shall be
interpreted as indicated.
1.1 The PURCHASE ORDER means the agreement entered into between OWNER or
by CONTRACTOR on behalf of OWNER and the SUPPLIER as recorded in the
PURCHASE ORDER Form, signed by the parties, including all attachments and
annexures thereto and all documents incorporated by reference therein together with
any subsequent modifications thereof in writing.
No change 1.5 OWNER shall mean BINDAL AGRO-CHEM LIMITED having their
Registered office at Gopala Tower, 12th Floor, Rajindra Place, New Delhi 110 008,
India, and shall include all their legal representatives, successors and assignees.
No change 1.7 SUPPLIER or VENDOR shall mean the individual or firm supplying
the GOODS and SERVICES under this PURCHASE ORDER.
No change 27.0 RESOLUTION OF DISPUTES/ ARBITRATION 27.1 The OWNER
and the SUPPLIER shall make every effort to resolve amicably by direct informal
negotiations any disagreement or dispute arising between them under or in
connection with the PURCHASE ORDER.
No change 27.2 If, after thirty (30) days from the commencement of such informal
negotiations, the OWNER and the SUPPLIER have been unable to resolve amicably a
PURCHASE ORDER dispute, either party may require that the dispute, be referred
for resolution to the formal mechanisms as specified hereunder.Dresser Rand S.A vs Bindal Agro Chem Ltd And K. G. Khosla ... on 12 January, 2006

No change 27.3 Legal Construction Subject to the provision of Article 27.4 the
PURCHASE ORDER shall be, in all respects, construed and operated as an Indian
Contract and in accordance with Indian Laws as in force for the time being and is
subject to the jurisdiction of the Courts in Delhi.
Deleted 27.4 27.4.1 Arbitration In case of indigenous PURCHASE ORDERS all
disputes which cannot be settled by mutual negotiations, the matter shall be referred
for arbitration in accordance with Indian Arbitration Act, 1940 of any statutory
modification of enactment thereof for the time being in force.
Deleted 27.4.2 In case of foreign SUPPLIER all disputes which cannot be settled by
mutual negotiations shall be settled under the Rules of Conciliation and Arbitration
of International Chamber of Commerce, Paris by one or more arbitrators appointed
in accordance with rules.
No change 27.4.3 Execution of the PURCHASE ORDER shall be continued by the
SUPPLIER during the Arbitration proceedings unless otherwise directed in writing
by the CONTRACTOR/OWNER.
Deleted 27.4.4 The venue of Arbitration in all cases shall be Delhi and shall be
conducted in English language only.
Deleted
13. According to DR, after Revision No.4 dated 10.6.1991 was initialled, negotiations and discussions
continued, and they were concluded late in the evening of 12.6.1991. It is stated that at that stage,
the representative of BINDAL delivered two letters described as "Letters of Intent" dated 12.6.1991
issued on the letterhead of K.G. Khosla Compressors Ltd. (KGK) stating the intention to place an
order for the following :
(a) One Dresser Rand Model 463 B.5/5 and one Model 373 BR8/1 vertically split
compressor for Synthesis Gas Service and Steam turbine driver model SBQ at a price
of FF 49,300,000 (French Francs).
(b) Two Dresser Rand Model 3M9.8 and Two Model 260-8B5/4 Centrifugal
compressors for CO2 service and team turbine driver Model QUBVT at a price of FF
52,625,000.
Except the description of the machinery and the price, the Letters of Intent were identical in its
terms and relevant portions thereof are extracted below (not seriatim) :-
I. PURCHASE ORDER This Letter of Intent will be followed by a regular and detailed
Purchase Order to be issued by KGK simultaneous with the establishment of the
Letter of Credit mentioned at para B of this letter.Dresser Rand S.A vs Bindal Agro Chem Ltd And K. G. Khosla ... on 12 January, 2006

C. TERMS AND CONDITIONS The Purchase Order shall be subject to the "General
Conditions of Purchase" included in inquiry and as amended by DR's comments
thereto, Revision 4 dated June 10, 1991, initialled by DR and KGK separately.
M. GOVERNMENT OF INDIA APPROVALS This Letter of Intent is being issued
subject to the necessary approvals to be given by Indian Government Authorities.
The Letters of Intent also contained terms relating to price, manner of making
payment of price, opening of Letter Guarantee, date for delivery, and consequences of
not opening Letter of Credit by the stipulated date. The relevant clauses are extracted
below :-
B. PRICE AND TERMS OF PAYMENT
1. ....
"2. Payment shall be made through an irrevocable and confirmed Letter of Credit
(Confirmation charges being to DR's account) allowing partial payments releasable in
one or several drafts, and according to the terms and conditions of this Letter of
Intent, to be opened by 31st August, 1991 by Bank of America, Barakhamba Road,
New Delhi, or any other Bank acceptable to DR., notified and payable to DR by Bank
of America, Paris. The said Letter of Credit will be construed in accordance with the
Uniform Customs and Practices for Documentary Credits of the International
Chamber of Commerce. Draft of such Letter of Credit is provided for in Attachment II
of this Letter of Intent and is subject to changes proposed by KGK or its bankers and
prior written agreement by DR or its bankers. The said Letter of Credit shall be valid
for a period of 15 months from its notification to DR and shall be extendable by two
(2) months period at DR's request in order to allow complete drawings of the said
Letter of Credit."
x x x D. DELIVERY DATE The delivery date (last shipment) shall be 15-1/2 (Fifteen & One Half
Months) after DR's receipt of this Letter of Intent. For the purpose of assessing liquidated damages
for delivery, delivery time shall be calculated on the basis of issuance of DR's Certificate of readiness
to ship, after inspection by KGK or its authorized agents and in the event of their failure to do so, a
declaration by DR that one month's notification of readiness to ship and invitation to inspect was
given. The time lag between the first and the last shipment will not exceed 12 weeks.
G. OPTIONAL PERFORMANCE TEST KGK has an option of asking DR to carry out shop
performance test (PTC-10 class III) for the equipment described in this LOI for an extra price of FF.
875,020/-. The said option shall be exercised by 19th June, 1991 in writing by KGK. It is agreed that
the delivery period described in para D of this Letter shall be extended by three week in case
performance test is desired to be carried out.Dresser Rand S.A vs Bindal Agro Chem Ltd And K. G. Khosla ... on 12 January, 2006

F. AUTHORISATION TO PROCEED This Letter of Intent shall serve as DR's authorization to
proceed with this order.
L. ENTRY INTO FORCE This contract will come into force upon receipt of this Letter of Intent by
Supplier.
If by August 31, 1991 KGK is unable to fulfil the obligations described in this LOI, the contract
performance schedule and prices may be revised.
DR alleges that when the Letters of Intent dated 12.6.1991 were delivered by BINDAL on 12.6.1991,
it enquired as to why the Letters of Intent were being issued in the name of KGK, when all its
negotiations, discussions and correspondence were only with BINDAL, and as the equipment supply
was also for BINDAL. DR further alleges that BINDAL's representatives informed that for its own
convenience, the Letters of Intent were being issued in the name of KGK and assured that full and
total responsibility for performance would, however, be that of BINDAL; and that acting on the said
representation, DR's representatives countersigned the Letters of Intent in token of its acceptance
and returned one copy each to BINDAL. According to DR, except the Letters of Intent dated
12.6.1991 (and a subsequent clarification dated 15.6.1991 from KGK that it did not require the shop
performance test), there was no discussions, negotiations or communications either in writing or
verbal, between KGK and DR at any time. According to DR, it did not meet any official of KGK at
any point of time and it always proceeded on the basis that the said letters of intent were issued by
KGK as an agent/consultant of BINDAL and not independently on its own account.
14. BINDAL neither placed any purchase order nor issued any confirmation that the Letters of
Intent dated 12.6.1991 were placed by KGK on its behalf. However, the Chairman of BINDAL sent a
communication dated 26.8.1991 to DR stating that in spite of its efforts, procedural matters at
Government level did not move as fast as it expected, and that it was fully conscious of the position
in which DR had to receive the Letters of Credit before making major financial commitments for
castings etc. and requested DR to wait till 31.10.1991. BINDAL also stated that it was confident to
open the Letters of Credit before 31.10.1991 and will accept a corresponding delay in the delivery
schedule.
14.1) Thereafter, DR by communication dated 24.10.1991, after referring to the discussions with
BINDAL (wherein the Commercial Director of BINDAL had assured that all approvals from the
Government were received and the Letter of Credit was likely to be opened before the end of
November, 1991) advised BINDAL that in view of the delay, there will be a price increase of 4.5%
(provided the LOC was established by 30.11.1991) apart from the corresponding delay in supply.
14.2) By communication dated 9.12.1991, BINDAL informed DR that it was not possible to accept
the Syn. Gas Compressor turbine manufactured by DR as it found after a visit to DR's works at
France that DR did not have any experience in manufacturing large mechanical turbines, and
therefore it was proposing to obtain the drive turbine for Syn. Gas Compressor from an alternative
source who has supplied similar turbines. By a subsequent letter dated 23.12.1991, BINDAL
informed DR that it was not agreeable to any revision in prices and it would like to discuss certainDresser Rand S.A vs Bindal Agro Chem Ltd And K. G. Khosla ... on 12 January, 2006

other issues in January, 1992. This was followed by a communication dated 13.2.1992 from BINDAL
stating that the Bank required a purchase order for opening the Letter of Credit and, therefore, it
was taking action to re-write all their foreign letters of intent in the format of letter of intent and
labelling them as purchase orders, and that consequently, some of the clauses of the Letters of
Intent (C, F, H, I, L etc.) would undergo changes and a draft of a purchase order cleared by the Bank
will be faxed. However, no such draft purchase order was sent by BINDAL nor any Letter of Credit
was opened by BINDAL. No purchase order was issued. Ultimately, DR was given to understand by
the Commercial Director of BINDAL that Indian Government had pressurized BINDAL to buy
Indian equipment and, therefore, BINDAL proposed to purchase the equipment from BHEL and not
from DR.
15. Thereafter, DR through its counsel, issued notices dated 9.1.1993 to BINDAL and KGK referring
to the Letters of intent dated 12.6.1991 issued by KGK and informing that if the Letter of Credit was
not opened in terms of Letters of Intent dated 12.6.1991 within 10 days, DR will proceed on the basis
that BINDAL and KGK had repudiated the contract and committed breach. As there was no reply,
counsel for DR sent notices dated 29.1.1993 to BINDAL and KGK stating that DR had treated the
inaction of BINDAL and KGK as repudiation of the contract. This was followed by notices dated
4.2.1993 to BINDAL and KGK whereby DR's counsel sought return of all papers and technical
information furnished by DR to BINDAL/KGK. Again by notices dated 5.2.1993, DR's counsel
informed BINDAL and KGK that in terms of clause 27.4.2 of general conditions of purchase
incorporated in the "agreement" dated 12.6.1991, DR intended to refer the disputes relating to the
"agreement" to the International Chamber of Commerce, Paris, ('ICC' for short) for resolution by
arbitration. It also proposed a panel of 3 names for appointment of the sole arbitrator. As there was
no reply, DR lodged a request for arbitration with ICC (received by ICC on 8.3.1993) in respect of its
claim against BINDAL and KGK for the following reliefs :-
1. an award for US $ 10,411,000 or alternatively, damages in such sum as the
Arbitrator may determine;
2. delivery to DR, of the documents enumerated in Appendix I thereto (with all copies
thereof made by BINDAL and KGK);
3. an injunction restraining BINDAL/KGK by themselves, their agents or contractors
from using any of the said documents for any purposes; and
4. for interest, costs etc. ICC issued a notice dated 10.3.1993 to BINDAL and KGK in
regard to lodgment of the said claim by DR.
16. One Bishwajit Bhattacharyya, Advocate, acting under instructions from BINDAL
and KGK sent a telex dated 11.4.1993 to ICC in reply to the notice of Lodgment dated
10.3.1993 stating that BINDAL and KGK were in the process of jointly nominating an
arbitrator and that his clients were not agreeable for appointment of a sole arbitrator.
This was, however, followed by two different communications from different counsel.
Mr. R. S. Gill, Advocate sent a communication dated 27.4.1993 to ICC stating that heDresser Rand S.A vs Bindal Agro Chem Ltd And K. G. Khosla ... on 12 January, 2006

had been instructed to represent BINDAL in place of Mr. Bhattacharyya. Similarly,
one Mr. J.S. Sinha, Advocate sent a communication dated 28.4.1993 to ICC stating
that he had been instructed to represent KGK in place of Mr. Bhattacharyya. The
written replies of BINDAL and KGK were enclosed with the said communications
dated 27.4.1993 and 28.4.1993. In those communications, BINDAL and KGK denied
the very existence of any arbitration agreement and sought rejection of the claim
lodged by DR. On 28.5.1993, ICC informed the parties that the advance on costs in
regard to arbitration would be US $ 2,70,000 and directed the counsel for claimant
and counsel for defendants to deposit US $ 67,500 each towards 50% of advance as
costs of arbitration.
17. At that stage, BINDAL filed Suit No.1363 of 1993 on 1.6.1993 in the Delhi High
Court, for a declaration that there was no arbitration agreement between BINDAL
and DR and for an injunction restraining DR from proceeding with the arbitration.
KGK also filed a suit (Suit No.1380 of 1993) on 28.6.1993 for similar reliefs. I.A.
Nos.5795/93 and 5819/93 were filed by BINDAL and KGK in the said suits for
temporary injunction restraining DR from proceeding with the Arbitration.
On 4.10.1993, DR filed application under Section 3 of the Foreign Awards (Recognition &
Enforcement) Act, 1961 for stay of suits. What happened thereafter is detailed in paras 6 & 7 above.
Re : Points (i) and (ii) :
18. Section 3 of the Foreign Awards Act providing for stay of proceedings in respect of
matters to be referred to arbitration reads thus :
"Notwithstanding anything contained in the Arbitration Act, 1940, or in the Code of
Civil Procedure, 1908, if any party to an agreement to which Article II of the
Convention set forth in the Schedule applies, or any person claiming through or
under him commences any legal proceedings in any court against any other party to
the agreement or any person claiming through or under him in respect of any matter
agreed to be referred to arbitration in such agreement, any party to such legal
proceedings may, at any time after appearance and before filling a written statement
or taking any other step in the proceedings, apply to the court to stay the proceedings
and the court, unless satisfied that the agreement is null and void, inoperative or
incapable of being performed or that there is not, in fact, any dispute between the
parties with regard to the matter agreed to be referred, shall make an order staying
the proceedings."
Article II of the Schedule to the Foreign Awards Act which contains the Convention on the
Recognition and Enforcement of Foreign Arbitral Awards is extracted below :-
"1. Each Contracting State shall recognize an agreement in writing under which the
parties undertake to submit to arbitration all or any differences which have arisen orDresser Rand S.A vs Bindal Agro Chem Ltd And K. G. Khosla ... on 12 January, 2006

which may arise between them in respect of defined legal relationship, whether
contractual or not, concerning a subject-matter capable of settlement by arbitration.
2. The term "agreement in writing" shall include an arbitral clause in a contract or an
arbitration agreement, signed by the parties or contained in an exchange of letters or
telegrams.
3. The Court of a Contracting State, when seized of an action in a matter in respect of
which the parties have made an agreement within the meaning of this article, shall, at
the request of one of the parties, refer the parties to arbitration, unless it finds that
the said agreement is null and void, inoperative or incapable of being performed."
19. In Renusagar Power Co. Ltd. vs. General Electric Company [1984 (4) SCC 679], this Court
considered the scope of section 3 of Foreign Awards Act and formulated the following six conditions
required to be fulfilled for invoking section 3 :-
(i) there must be an agreement to which Article II of the Convention set forth in the
Schedule applies;
(ii) a party to that agreement must commence legal proceeding against another party
thereto;
(iii) the legal proceedings must be "in respect of any matter agreed to be referred to
arbitration" in such agreement;
(vi) the application for stay must be made before filing the written statement or
taking any other step in the legal proceedings;
(v) the Court has to be satisfied that the agreement is valid, operative and capable of
being performed; this relates to the satisfaction about the "existence and validity"
of the arbitration agreement;
(vi) the Court has to be satisfied that there are disputes between the parties with
regard to the matters agreed to be referred; this relates to effect (scope) of the
arbitration agreement touching the issue of arbitrability of the claims.
This Court also held that section 3 of Foreign Awards Act combines in its own ambit both sections
33 and 34 of the Arbitration Act,1940 and questions regarding the existence, validity or effect
(scope) of the Arbitration agreement which can be decided under section 33 of the Arbitration Act,
are required to be decided under section 3 of the Foreign Awards Act before a stay of legal
proceedings contemplated therein could be granted. This Court stated the scope of enquiry under
section 3 of the Foreign Awards Act thus :-Dresser Rand S.A vs Bindal Agro Chem Ltd And K. G. Khosla ... on 12 January, 2006

"Here we are concerned with Section 3 which makes it obligatory upon the Court to
stay the legal proceedings if the conditions of the section are satisfied and what is
more the section itself requires that before any stay is granted the Court should be
satisfied that the arbitration agreement is valid, operative and capable of being
performed and that there are disputes between the parties with regard to the matters
agreed to be referred to arbitration [conditions (v) and (vi) mentioned earlier]. In
other words, the section itself indicates that the proper stage at which the Court has
to be fully satisfied about these conditions is before granting the relief of stay in a
Section 3 petition and there is no question of the Court getting satisfied about these
conditions on any prima facie view or a pro tanto finding thereon. Parties have to put
their entire material before the Court on these issues (whichever may be raised) and
the Court has to record its finding thereon after considering such material."
Therefore, the question whether there is an arbitration agreement or not squarely falls for decision
of the Court under section 3 and will have to be finally decided by the Court.
20. It is clear from Clause (2) of Article II that an 'agreement in writing' includes not only an arbitral
clause in a contract or a separate arbitration agreement, signed by the parties, but a term contained
in an exchange of letters or telegrams agreeing to submit their differences to arbitration. The
question, therefore, is whether there is an "agreement in writing" under which parties have agreed
to submit their differences to arbitration.
21. The principle as to how to find out whether the correspondence shows consensus ad idem, was
stated by this Court in Rickmers Verwaltung Gmbh v. Indian Oil Corporation Ltd. [1999 (1) SCC 1] :
"The submission of Mr. Nariman that an agreement, even if not signed by the parties,
can be spelt out from correspondence exchanged between the parties admits of no
doubt. In fact, various judgments cited by him at the bar unmistakably support this
assertion. The question, however, is can any agreement be spelt out from the
correspondence between the parties in the instant case? In this connection the
cardinal principle to remember is that it is the duty of the court to construe
correspondence with a view to arrive at a conclusion whether there was any meeting
of mind between the parties, which could create a binding contract between them but
the Court is not empowered to create a contract for the parties by going outside the
clear language used in the correspondence, except insofar as there are some
appropriate implications of law to be drawn. Unless from the correspondence it can
unequivocally and clearly emerge that the parties were ad idem to the terms, it
cannot be said that an agreement had come into existence between them through
correspondence. The Court is required to review what the parties wrote and how they
acted and from that material to infer whether the intention as expressed in the
correspondence was to bring into existence a mutually binding contract. The
intention of the parties is to be gathered only from the expressions used in the
correspondence and the meaning it conveys and in case it shows that there had been
meeting of mind between the parties and they had actually reached an agreement,Dresser Rand S.A vs Bindal Agro Chem Ltd And K. G. Khosla ... on 12 January, 2006

upon all material terms, then and then alone can it be said that a binding contract
was capable of being spelt out from the correspondence."
22. According to DR, the arbitration agreement is contained in "the General Conditions of Purchase"
forming part of the Invitation to Bid issued by BINDAL, as modified by Revision No.4 dated
10.6.1991 agreed to between DR and BINDAL, incorporated by reference in the Letters of Intent
dated 12.6.1991 placed by KGK on DR and accepted by DR by counter signing them. The said
contention of DR that there is an arbitration agreement by correspondence is elaborated thus :-
(a) BINDAL's "general conditions of purchase" which is forming part of the tender
documents/Invitation to Bid contains an arbitration agreement in Clause 27.4.
The suggestions made by DR for modification of the arbitration clause (Clause 27.4) in the "General
Conditions of Purchase", as per Revision No.4 dated 10.6.1991, were agreed to by BINDAL.
Consequently, the "General Conditions of Purchase" contain the following arbitration clause :
"In cases of foreign supplier, all disputes which cannot be settled by mutual
negotiations shall be settled under the Rules of Conciliation and Arbitration of
ICC......."
(b) Clause 'C' of the letters of intent dated 12.6.1991 issued by KGK as an agent/authorized
consultant of BINDAL to DR provided that "the purchase order shall be subject to the 'general
conditions of purchase' included in inquiry and as amended by DR's comments thereto, Revision
No.4 dated 10.6.1991 initialled by DR and KGK separately";
(c) The Letters of Intent are the purchase orders and they have been accepted by DR by
counter-signing them. Therefore, there are concluded contracts between DR on the one hand and
KGK representing BINDAL on the other, for supply of the machinery mentioned in the Letters of
Intent which are governed by BINDAL's 'general conditions of purchase' which contain an
arbitration clause. Thus there is an arbitration agreement between the parties in terms of clause
27.4.2 of the 'General Conditions of Purchase".
23. We find that the said submission of DR is based on two premises. The first is that there is an
'arbitration agreement' between 'DR' on the one hand and 'BINDAL' on the other as per clause
27.4.2 of the 'General Conditions of Purchase'. The second is that even if clause 27.4.2 of General
Conditions of Purchase itself may not operate as an arbitration agreement between the parties, the
Letters of Intent by KGK are purchase orders placed on behalf of BINDAL which are made subject to
the General Conditions of Purchase including the arbitration clause (clause 27.4.2) and therefore,
there is an arbitration agreement between DR and BINDAL/KGK. On a careful examination, we find
that both premises are erroneous and are baseless assumptions.
Whether clause 27.4.2 of 'General Conditions of Purchase' is an 'Arbitration agreement'Dresser Rand S.A vs Bindal Agro Chem Ltd And K. G. Khosla ... on 12 January, 2006

24. The tender document or the invitation to bid of BINDAL (containing the "instructions to
bidders" and the "general conditions of purchase"), by itself, is neither an agreement nor a contract.
The instructions to bidders informed the intending bidders how the bid should be made and laid
down the procedure for consideration and acceptance of the bid. The process of bidding or
submission of tenders would result in a contract when a bid or offer is made by a prospective
supplier and such bid or offer is accepted by BINDAL. The second part of the Invitation to Bid
consists of the 'General Conditions of Purchase', that is, the conditions subject to which the purchase
order will be placed or offer will be accepted. The 'General Conditions of Purchase' were made
available as a part of the Invitation to bid, so as to enable the prospective suppliers to ascertain their
obligations and formulate their offers suitably.
25. Where a tenderer is not willing to make his offer subject to the 'General Conditions of Purchase'
prescribed and stipulated by the purchaser, he would either suggest his own terms and conditions or
suggest modifications to the 'General Conditions of Purchase' prescribed by the intending purchaser
(person inviting the offers). Many 'Invitations to Bid' contain a condition that the tenderers will not
be entitled to make any changes in the 'General Conditions of Purchase', in which event he is
required to mould his offer strictly in accordance with the 'General Conditions of Purchase'
stipulated by the purchaser. The reason for insisting upon adherence to Purchaser's 'General
Conditions of Purchase' is not far to seek. If several persons submit their offers subjecting them to
different terms and conditions of supply, it will be difficult or virtually impossible to evaluate them
with reference to a common denominator. The general conditions of purchase act as a common
denominator for all tenderers to base their offers and for evaluation of such offers. Further, the said
General Conditions stipulated by the purchaser enable the tenderer to assess his obligations and
calculate the offer price accordingly. For example, there will be a marked difference in the
responsibility of a supplier and the pricing, if the purchaser seeks a three year warranty instead of
one year warranty, or seeks delivery of machinery at site instead of at supplier's factory, or seeks
delivery to be expedited instead of the normal period. Many a time the supplier is able to persuade
the purchaser to agree for modification of the 'conditions of purchase' stipulated by the purchaser,
particularly where a supplier is in a position of strength and the purchaser is keen to purchase a
particular product of that supplier. There are also several suppliers who stipulate their own
'conditions of sale' and refuse to go by the conditions of purchase stipulated by the purchaser. The
intending purchaser and the intending supplier are at liberty to negotiate and agree upon the terms
subject to which offers will be made and accepted. As contrasted from sale of ready Goods sold off
the shelf across the counter, sale/purchase of complex machinery/ equipment made to order, to suit
particular requirements of the purchaser, have several facets relating to pricing, period of delivery,
mode of delivery, period and nature of warranty, suitability for the intended purpose, patent rights,
packing, insurance, incidental services, consequences of delay and breach, rejection/replacement
force mejeure etc. Agreeing upon the terms subject to which offer is to be made and accepted, is
itself a complicated and time consuming process. But, reaching an agreement as to the terms subject
to which a purchase will be made, is not entering into an agreement to purchase.
26. Therefore, when DR suggested modifications to the general conditions of purchase, and when
BINDAL agreed to them, and both parties initialled Revision No. 4 containing the modifications to
the General Conditions of Purchase, on 10.6.1991, no contract or agreement came into existence as itDresser Rand S.A vs Bindal Agro Chem Ltd And K. G. Khosla ... on 12 January, 2006

did not involve either an offer or acceptance or performance of any promise. "Revision No.4" dated
10.6.1991 only consisted of the modifications to the General Conditions of Purchase, subject to
which it was willing to enter into a contract with BINDAL for sale of machinery. Revision No.4 dated
10.6.1991 cleared the decks by finalizing the general conditions which would be applicable if and
when BINDAL decided to place a purchase order. In other words, the 'General Conditions of
Purchase' and Revision No.4 dated 10.6.1991 containing the modifications thereto, merely set out
the terms on which the parties were ready to do business with each other if and when purchase
order was placed by BINDAL. Parties merely agreed that when an order was placed or contract was
entered for supply of a machinery by DR to BINDAL, it will be subject to the 'General Conditions of
Purchase' stipulated by BINDAL as modified by Revision No.4 dated 10.6.1991 agreed by both
parties.
27. The following observations of this Court in Chatturbhuj Vithaldas Jasani v. Moreshwar
Parashram (AIR 1954 SC
236) though in a different context, are apposite :
"... The letters merely set out the terms on which the parties were ready to do
business with each other if and when orders were placed and executed. As soon as an
order was placed and accepted a contract arose. It is true this contract would be
governed by the terms set out in the letters but until an order was placed and
accepted there was no contract."
In Rickmers Verwaltung (supra), the appellant contended that though the agreement drawn up on
11.11.1993 was not formally signed by the parties, the contemporaneous correspondence between
them showed that a binding contract came into existence between the parties in terms of such draft
dated 11.11.1993 and clause 53 of the said 'agreement' provided for arbitration and therefore, the
claim raised by the appellant had to be settled by reference to arbitration. The first Respondent
(Indian Oil Corporation Ltd) on the other hand contended that no arbitration agreement had been
executed between the parties and the correspondence between the parties did not bring about any
enforceable contract between the parties, because the fundamental conditions of the terms of the
bargain were neither agreed upon nor fulfilled by the parties. This Court accepted the contention by
the first respondent that there was no 'arbitration agreement' on the following reasoning:-
"From a careful perusal of the entire correspondence on the record, we are of the
opinion that no concluded bargain had been reached between the parties as the terms
of the standby letter of credit and performance guarantee were not accepted by the
respective parties. In the absence of acceptance of the standby letter of credit and
performance guarantee by the parties, no enforceable agreement could be said to
have come into existence. The correspondence exchanged between the parties shows
that there is nothing expressly agreed between the parties and no concluded
enforceable and binding agreement come into existence between them. Apart from
the correspondence relied upon by the learned single Judge of the High Court, the
Fax messages exchanged between the parties, referred to above, go to show that theDresser Rand S.A vs Bindal Agro Chem Ltd And K. G. Khosla ... on 12 January, 2006

parties were only negotiating and had not arrived at any agreement. There is a vast
difference between negotiating a bargain and entering into a binding contract. After
negotiation of bargain in the present case, the stage never reached when the
negotiations were completed giving rise to a binding contract. The learned single
Judge of the High Court was, therefore, perfectly justified in holding that Clause 53 of
the Charter Party relating to Arbitration had no existence in the eye of law, because
no concluded and binding contract ever came into existence between the parties."
[Emphasis supplied]
28. Parties agreeing upon the terms subject to which a contract will be governed, when made, is not
the same as entering into the contract itself. Similarly, agreeing upon the terms which will govern a
purchase when a purchase order is placed, is not the same as placing a purchase order. A prelude to
a contract should not be confused with the contract itself. The purpose of Revision No. 4 dated
10.6.1991 was that if and when a purchase order was placed by BINDAL, that would be governed by
the "general conditions of purchase" of BINDAL, as modified by Revision No.4. But when no
purchase order was placed, neither the 'general conditions of purchase' nor the arbitration clause in
the 'General Conditions of Purchase' became effective or enforceable. Therefore, initialling of
'Revision No. 4' by DR and BINDAL on 10.6.1991 containing the modifications to General
Conditions of Purchase, did not bring into existence any arbitration agreement to settle disputes
between parties.
Whether Letters of Intent dated 12.6.1991 contain an arbitration agreement.
29. We will next examine whether any arbitration agreement came into existence by issue of Letters
of Intent dated 12.6.1991 by KGK countersigned by DR and if so who are the parties to such
arbitration agreement.
30. The circumstances in which the Letters of Intent dated 12.6.1991 by KGK 'surfaced' is strange
and illogical if not mysterious. It is admitted by DR that at no point of time, it held any negotiation
or discussion or exchanged correspondence with KGK in this matter. The case of DR is that BINDAL
was corresponding and negotiating with it for purchase of certain types of compressors for its
Shahjahanpur Fertilizers Project; that neither BINDAL nor KGK ever informed DR that KGK was
the agent/consultant of BINDAL; and that the modifications to 'General Conditions of Purchase'
were discussed and finalized on 10.6.1991, as per Revision No. 4 initialled by the representatives of
DR and BINDAL. In the circumstances, there appears to be no logical reason for two letters of intent
being prepared and issued on the letterhead of KGK on 12.6.1991 out of the blue, particularly when
no representative of KGK was present during discussions on 12.6.1991 nor were the Letters of Intent
signed by anyone on behalf of KGK in the presence of DR's representatives. According to DR, the
representative of BINDAL handed over the Letters of intent issued on the letterhead of KGK stating
that though the Letters of intent were issued by KGK, the compressors were for BINDAL and
payment and performance will be the BINDAL. No one has chosen to explain why the letters of
intent were not issued by BINDAL or why the letters of intent were issued by KGK. What is strange
is the acceptance of such letters of intent by DR without protest and without insisting that the lettersDresser Rand S.A vs Bindal Agro Chem Ltd And K. G. Khosla ... on 12 January, 2006

of intent should be issued by BINDAL or at least that BINDAL should confirm in writing that the
KGK was issuing the letters of intent on its behalf. If BINDAL had delivered the letters of intent
prepared on the letterhead of KGK instead of its own, clearly it was with some ulterior motive. But
we are not considering the business ethics of BINDAL nor the negligence on the part of DR in not
insisting upon something in writing from BINDAL to show that Letters of Intent of KGK were issued
on its behalf. The question for consideration is whether there is an arbitration agreement in the
Letters of Intent.
31. There is sufficient material to show that BINDAL proceeded on the basis that KGK's letters of
intent dated 12.6.1991 were issued on its behalf, though there is no direct reference to the Letters of
Intent dated 12.6.1991 in any of BINDAL's correspondence. We may briefly refer to the following
circumstances which clearly lead to an inference as that KGK's Letters of Intent, were on behalf of
BINDAL :-
i) In its letter dated 23.12.1991, the Chairman of BINDAL refers to DR's intention to
revise the prices due to BINDAL not opening the LCs in time.
ii) In BINDAL's communications dated 13.2.1992, there is a reference to BINDAL's
proposal to rewrite LOIs by labelling them as purchase orders and consequently,
Clauses C, F, H, I and L of letters of intent undergoing changes, in view of the Bank
requiring purchase orders instead of letters of intent, for opening the letters of credit.
In the absence of any letter of intent by BINDAL itself, it has to be inferred that the
letters of intent referred by BINDAL are the letters of intent dated 12.6.1991 issued by
KGK.
iii) When DR sent notices dated 9.1.1993 to BINDAL and KGK, alleging that KGK
acted as agent of BINDAL in issuing the Letters of Intent dated 12.6.1991, there was
no denial either by BINDAL or KGK
iv) When DR lodged a request for arbitration with ICC making a claim jointly against
BINDAL and KGK specifically alleged that KGK acted as agent of BINDAL in issuing
of Letters of Credit, and when copies of such request for arbitration were forwarded
by ICC to BINDAL and KGK, significantly, BINDAL and KGK sent a common reply
through a common counsel (Mr. Bishwajit Bhattacharyya) stating that both (BINDAL
and KGK) were proposing to jointly nominate an Arbitrator.
v) Even when BINDAL and KGK subsequently decided to challenge the arbitration
agreement and issued separate notices dated 27.4.1993 and 28.4.1993 though
different counsel, such notices were sent through two counsel who shared the same
office and telephones.
The conduct of BINDAL subsequent to 12.6.1991 leads to an inescapable inference that letters of
intent issued by KGK on 12.6.1991 were on behalf of BINDAL. In fact, even otherwise, we will
assume for the purpose of this case that KGK was acting on behalf of BINDAL as its agent orDresser Rand S.A vs Bindal Agro Chem Ltd And K. G. Khosla ... on 12 January, 2006

consultant in issuing the letters of intent dated 12.6.1991. The question is whether that will take DR
any further in establishing that there is an arbitration agreement.
32. The Preamble to the Letters of Intent states that KGK "hereby confirms its intention to place an
order on Dresser Rand". This is further made clear from Clause (I) of each letter of intent which
provides that "this letter of intent" will be followed by a regular and detailed purchase order to be
issued by KGK simultaneous with the establishment of the Letter of Credit mentioned in Para B of
letter of intent. This makes it clear that the letter of intent is only a prelude to the purchase order
and not itself the purchase order. The last para of Letters of Intent requires DR to sign and return
the duplicate copy of the letter as token acceptance of DR having agreed to the Letters of Intent. This
would mean that the person issuing the Letters of Intent wanted concurrence of DR to the terms
contained in the Letter of Intent so that it can place an order in terms of the conditions mentioned
in the Letters of Intent. The concurrence sought was to the contents of Letters of Intent and not
acceptance of any order for supply.
33. Clause 'C' of Letters of Intent provides that the Purchase Order shall be subject to the "General
Conditions of Purchase"
included in the inquiry, as amended by DR's comments thereto, Revision 4 dated
10.6.1991". Therefore, the General Conditions of Purchase which contains the
arbitration clause, is not made a part of the Letters of Intent nor are the Letters of
Intent made subject to the General Conditions of Purchase. The Letters of Intent
merely provide that if and when the purchase order is placed, the purchase order will
be subject to the General Conditions of Purchase, as modified by Revision No.4.
Therefore, the point of time at which the General Conditions of Purchase will become
applicable, is the point when the purchase order is placed and not earlier.
Consequently, Clause 27.4.2 of the General Conditions of Purchase containing the
arbitration clause would become applicable and available to the parties only when the
purchase order was placed and not earlier. The term 'purchase order' has a specific
meaning and connotation. The purchase order is the "agreement entered into
between BINDAL and the prospective supplier as recorded in the purchase order
form (prepared in the form of Attachment-VII to the General Conditions of Purchase)
signed by the parties, including all Attachments and annexures thereto and all
documents incorporated by reference therein together with any subsequent
modifications thereof in writing." Admittedly, no such purchase order was placed by
either BINDAL or any one authorized by BINDAL. It is also evident from Clause (I) of
the Letters of Intent that the purchase order was to be issued simultaneously with the
Letter of Credit. Clause (M) made it clear that the Letters of Intent were being issued
subject to necessary approvals being given by the Authorities of the Indian
Government. These provisions clearly indicate that the Letters of Intent were only a
step leading to purchase orders and were not, by themselves, purchase orders.
Therefore, issue the Letters of Intent by KGK, assuming that it was done on behalf of
BINDAL, did not mean that the General Conditions of Purchase which contains the
provision for arbitration became a part of the Letters of Intent or becameDresser Rand S.A vs Bindal Agro Chem Ltd And K. G. Khosla ... on 12 January, 2006

enforceable.
34. It is now well-settled that a Letter of Intent merely indicates a party's intention to enter into a
contract with the other party in future. A Letter of Intent is not intended to bind either party
ultimately to enter into any contract. This Court while considering the nature of a Letter of Intent,
observed thus in Rajasthan Co-operative Dairy Federation Ltd. V. Maha Laxmi Mingrate Marketing
Service Pvt. Ltd. [1996 (10) SCC 405] :
"... The Letter of Intent merely expressed an intention to enter into a contract. There
was no binding legal relationship between the appellant and Respondent 1 at this
stage and the appellant was entitled to look at the totality of circumstances in
deciding whether to enter into a binding contract with Respondent 1 or not."
It is no doubt true that a Letter of Intent may be construed as a letter of acceptance if such intention
is evident from its terms. It is not uncommon in contracts involving detailed procedure, in order to
save time, to issue a letter of intent communicating the acceptance of the offer and asking the
contractor to start the work with a stipulation that the detailed contract would be drawn up later. If
such a letter is issued to the contractor, though it may be termed as a Letter of Intent, it may amount
to acceptance of the offer resulting in a concluded contract between the parties. But the question
whether the letter of intent is merely an expression of an intention to place an order in future or
whether is a final acceptance of the offer thereby leading to a contract, is a matter that has to be
decided with reference to the terms of the letter. Chitty on Contracts (Para 2.115 in Volume 1- 28th
Edition) observes that where parties to a transaction exchanged letters of intent, the terms of such
letters may, of course, negative contractual intention; but, on the other hand, where the language
does not negative contractual intention, it is open to the courts to hold the parties are bound by the
document; and the courts will, in particular, be inclined to do so where the parties have acted on the
document for a long period of time or have expended considerable sums of money in reliance on it.
Be that as it may.
35. Learned counsel for DR referred to Clauses (B), (D), (F), and (L) of the Letters of Intent to
contend that they were the purchase orders. Clause (B) mentioned the total price exclusive of taxes
and duties payable and provided that the Letter of Credit should be opened by 31.8.1991 by a bank
acceptable to DR. Clause (D) provided that delivery date shall be 15 = months from the date of
receipt of the Letter of Intent by DR. Clause (F) stated that "this Letter of Intent shall serve as DR's
authorization to proceed with this order". Clause (L) stated that 'This contract will come into force
upon receipt of this letter of intent by supplier'. DR contends that as the Letters of Intent were
referred to as "this order" and 'this contract' in clauses (F) and (L), and as clause (F) authorized DR
to proceed with the order, the Letters of Intent were, in fact, purchase orders.
36. When all the terms of the Letter of Intent are harmoniously read, what is clear is that Letters of
intent merely required the supplier to keep the offer open till 31.8.1991 with reference to the price
and delivery schedule. They also made it clear that if the purchase orders were not placed and Letter
of Credit was not opened by 31.8.1991, DR was at liberty to alter the price and the delivery schedule.
In other words, the effect of Letters of intent was that if the Purchase Orders were placed and LCsDresser Rand S.A vs Bindal Agro Chem Ltd And K. G. Khosla ... on 12 January, 2006

were opened by 31.8.1991, DR would be bound to effect supply within 15= months, at the prices
stated in the Letter of Intent. Therefore, it may not be possible to treat the Letters of Intent as
Purchase Orders.
37. Even if we assume that the Letters of Intent were intended to contracts for supply of machinery
in accordance with the terms contained therein, it may only enable DR to sue for damages or sue for
the expenses incurred in anticipation of the order and opening of LC. But that will not be of any
assistance to contend that there was an arbitration agreement between the parties.
38. We have already noticed that the letters of intent dated 12.6.1991, do not contain any arbitration
clause. The contention of DR is that arbitration clause in the General Conditions of Purchase is
incorporated by reference, having regard to clause (C) of Letters of Intent. But clause (C) specifically
provided that 'the purchase order' shall be subject to General Conditions of Purchase as amended by
Revision No. 4. Clause (C) did not say that "this letter of intent is subject to the general conditions of
purchase as amended in Revision No. 4". One other aspect may be noticed. Clause (C) refers to
Revision No. 4 initialled by DR and KGK. It is now admitted by DR that there is no document
(Revision No.4 or otherwise) modifying the general conditions of purchase, which is initialled by DR
and KGK. The Revision No. 4 was initialled only by DR and BINDAL. Therefore, the general
conditions of purchase containing the arbitration clause, never became a term of the letters of intent
dated 12.6.1991. Clause (C) of the letters of intent made it clear that it is only the purchase orders
which were to be placed in future on or before 31.8.1991 (along with opening of LC) that was to be
subject to the General Conditions of Purchase. Therefore, we hold that the letters of intent, even if
assumed to result in any binding contract, did not provide for arbitration.
39. The learned counsel for DR next contended that the words "the purchase order" in Clause (C)
should be read as "this purchase order". For this purpose, he referred to several provisions of the
General Conditions of Purchase, some of which use the words "the purchase order" whereas other
use the words "this purchase order". He contended that the words "the" and "this" are loosely used
in the General Conditions of Purchase and in the Letters of Intent and are, therefore,
interchangeable. We cannot agree. Firstly, it is not open to us to change the terms of any document.
Secondly, the use of the words "this purchase order" in some clauses of the General Conditions of
Purchase was not inappropriate. It should be remembered that the General Conditions of Purchase,
in entirety, were intended to be treated as a part to the purchase order as and when the purchase
order was placed. Therefore, when the General Conditions of Purchase were read as part of the
purchase order, use of the words 'this purchase order' in the 'General Conditions of Purchase' would
be appropriate. Therefore, it is impermissible to read the words 'the purchase order' in clause (C) of
Letters of Intent as 'this purchase order.
40. Thus, neither the General Conditions of Purchase forming part of Invitation of Bid nor Revision
No.4 dated 10.6.1991, nor the Letters of Intent dated 12.6.1991 contain any arbitration agreement.
There is also no other document or correspondence which can be read as containing a provision that
can be interpreted as an agreement to resolve disputes by arbitration. We are, therefore, of the view,
though for slightly different reasons, that the decision of the learned Single Judge and the Division
Bench of the High Court holding that there is no arbitration agreement, does not suffer from anyDresser Rand S.A vs Bindal Agro Chem Ltd And K. G. Khosla ... on 12 January, 2006

infirmity.
Re: Point No. (iii) :
41. DR contends that the conduct of BINDAL and KGK clearly showed that they proceeded on the
basis that there was an arbitration agreement. DR referred to the notices dated 9.1.1993, 29.1.1993
and 4.2.1993 issued by its Counsel culminating in the final notice dated 5.2.1993 seeking reference
to arbitration. It is pointed out that neither BINDAL nor KGK issued any reply to the said notice
dated 5.2.1993 thereby indicating an implied acceptance of an arbitration agreement. DR also points
out that when notice was sent by ICC to BINDAL and KGK in respect of the request for arbitration
lodged by DR, Mr. Bhattacharyya, Advocate, sent a reply dated 11.4.1993 acting on behalf of both
BINDAL and KGK, stating that they are in the process of jointly nominating an arbitrator. It is
contended that if there was really no arbitration agreement, the counsel for BINDAL and KGK
would not have stated that they were in the process of nominating an arbitrator. It is contended that
only by way of an afterthought, BINDAL and KGK changed their stand to contend that there was no
arbitration agreement, when their changed the counsel and sent a further reply dated 27.4.1993 and
28.4.1993 respectively. It is submitted that there is acquiescence on the part of BINDAL and KGK in
regard to arbitration.
43. This is countered by BINDAL and KGK by pointing out that Mr. Bhattacharyya had stated that
an Arbitrator will be appointed by BINDAL and KGK without examining or knowing the full facts,
while sending the letter dated 11.4.1993. They point out that immediately thereafter, by issuing
notices dated 27.4.1993 and 28.4.1993, they made it clear that there was no arbitration agreement.
It is contended that even if Mr. Bhattacharyya had stated that an arbitrator was being appointed,
that would not come in the way of either BINDAL or KGK subsequently pointing out that there was
no arbitration agreement, when they examined the legal position or when an application under
section 3 of Foreign Awards Act was filed.
44. In U.P. Rajkiya Nirman Nigam Ltd. vs. Indure Pvt. Ltd. [1996 (2) SCC 667] negativing a
contention based on acquiescence in matters concerning challenge to arbitrability, this Court
observed thus :-
"Acquiescence does not confer jurisdiction........................ The clear settled law thus is
that the existence or validity of an arbitration agreement shall be decided by the
Court alone. Arbitrators, therefore, have no power or jurisdiction to decide or
adjudicate conclusively by themselves the question since it is the very foundation on
which the arbitrators proceed to adjudicate the disputes. Therefore, it is rightly
pointed out by Shri Adarsh Kumar Goel, learned counsel for the appellant that they
had by mistake agreed for reference and that arbitrators could not decide the
existence of the arbitration agreement or arbitrability of the disputes without
prejudice to their stand that no valid agreement existed. Shri Nariman contended
that having agreed to refer the dispute, the appellant had acquiesced to the
jurisdiction of the arbitrators and, therefore, they cannot exercise the right under
Section 33 of the Act. We find no force in the contention. As seen, the appellant isDresser Rand S.A vs Bindal Agro Chem Ltd And K. G. Khosla ... on 12 January, 2006

claiming adjudication under Section 33 which the Court alone has jurisdiction and
power to decide whether any valid agreement is existing between the parties. Mere
acceptance or acquiescing to the jurisdiction of the arbitrators for adjudication of the
disputes as to the existence of the arbitration agreement or arbitrability of the dispute
does not disentitle the appellant to have the remedy under Section 33 through the
Court. In our considered view the remedy under Section 33 is the only right royal way
for deciding the controversy."
[Emphasis supplied] What is stated above with reference to section 33 of Arbitration Act, 1940, will
apply with equal force in regard to section 3 of Foreign Awards Act. Therefore, the fact that at some
point of time, BINDAL or KGK had stated that they would appoint an Arbitrator will not come in the
way of their demonstrating that there is no arbitration agreement when the matter comes up before
the court under section 3 of the Foreign Awards Act. Therefore, there is no question of either waiver
or acquiescence.
Conclusion
45. We, therefore, do not find any reason to interfere with the decision of the Division Bench of the
High Court. The appeals are, therefore, dismissed. Parties to bear their respective costs.Dresser Rand S.A vs Bindal Agro Chem Ltd And K. G. Khosla ... on 12 January, 2006

