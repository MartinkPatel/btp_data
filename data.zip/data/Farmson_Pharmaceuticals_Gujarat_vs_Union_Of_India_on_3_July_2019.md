Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July,
2019
Author: A. P. Thaker
Bench: S.R.Brahmbhatt, A. P. Thaker
         C/SCA/5278/2019                                         JUDGMENT
            IN THE HIGH COURT OF GUJARAT AT AHMEDABAD
             R/SPECIAL CIVIL APPLICATION NO. 5278 of 2019
FOR APPROVAL AND SIGNATURE:
HONOURABLE MR.JUSTICE S.R.BRAHMBHATT
and
HONOURABLE DR.JUSTICE A. P. THAKER
================================================================
1     Whether Reporters of Local Papers may be allowed to                  No
      see the judgment ?
2     To be referred to the Reporter or not ?                              No
3     Whether their Lordships wish to see the fair copy of the             No
      judgment ?
4     Whether this case involves a substantial question of law             No
      as to the interpretation of the Constitution of India or any
      order made thereunder ?
================================================================
            FARMSON PHARMACEUTICALS GUJARAT PVT.LTD.
                             Versus
                         UNION OF INDIA
================================================================
Appearance:
MR SN SOPARKAR FOR GARGI R VYAS(7983) for the Petitioners
MR RAVI PRAKASH WITH MR DEVANG VYAS(2794) for the Respondents
No.1,3,4
MR NIRZAR S DESAI(2117) for the Respondent(s) No. 2
==========================================================Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

    CORAM: HONOURABLE MR.JUSTICE S.R.BRAHMBHATT
           and
           HONOURABLE DR.JUSTICE A. P. THAKER
                               Date : 03/07/2019
                          ORAL JUDGMENT
(PER : HONOURABLE DR.JUSTICE A. P. THAKER) C/SCA/5278/2019 JUDGMENT
1. Heard learned counsels for the parties. As the counsels for the parties have exchanged their
pleadings and argued the matter extensively for final disposal, this matter is being heard and
disposed of finally.
2. The present petition has been preferred by the petitioners under Article 226 of the Constitution of
India for the following prayers.
A. This Hon'ble Court be pleased to issue a writ of certiorari or a writ in the nature of certiorari, so
as to quash and set aside Impugned Final Finding No.7/16/2018-DGAD dated 29.01.2019 along
with Disclosure Statement dated 15.01.2019 issued by the Respondent no.2 and annexed at
Annexure - G and H hereto; and B. Pending admission, hearing and final disposal of this petition,
this Hon'ble Court be pleased to direct Respondent No.3 not to refrain from taking any steps in
furtherance of the Impugned Final Finding dated 29.01.2019 issued by it and annexed as Annexure -
G and Annexure - H hereto;
C. Pending admission, hearing and final disposal of this petition, this Hon'ble Court be pleased to
direct the Respondent nos.1 to 4 to ensure that subject goods that may be cleared are duly accounted
for and further the importers be notified about pendency of the present petition before this Hon'ble
Court and subject to the outcome of the same;
D. Ad-interim reliefs in terms of prayers (B) and (C) above;
E. Ex parte ad-interim reliefs in terms of prayer (D) above;
F. For cost; and G. Such other and further orders as may be considered fit and expedient in the facts
of the case be passed.
3. It is contended that the petitioner No.1 is a company incorporated under the provisions of the
Companies Act, 1956 and is engaged in the business of manufacturing "Paracetamol" (hereinafter be
referred to as "the subject goods) in the State of Gujarat and petitioner No.2 is a shareholder of
petitioner No.1 and concerned with the day to day activities of the company. Whereas, respondent
No.1 is the Ministry of Commerce, Government of India and control respondent No.2, the
Designated Authority (DA) is C/SCA/5278/2019 JUDGMENT functioning and respondent No.4 is a
Central Board of Indirect Taxes and Customs is the Nodal National Agency Responsible for
Administering Customs, GST, Central Excise, Service Tax and Narcotics in India. It is contendedFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

that respondent No.2 is the Designated Authority constituted under the provisions of Rule 3 of the
Customs Tariff (Identification, Assessment and Collection of Anti- Dumping Duty on Dumped
Articles and for Determination of Injury) Rules, 1995 (hereinafter be referred to as "the Rules") and
carried out its duties and functioning of a quasi judicial authority as provided under Rule 6 of the
Rules.
3.1 It is contended by the petitioners that the India being a signatory to World Trade Organization
and also a party to the Agreement on Implementation of Article VI of the General Agreement on
Tariffs and Trade, 1994 which provides the principles and procedure of determination and
imposition of Anti-Dumping Duties and methodology for determination thereof etc. It is contended
that Section 9A(1) of the Customs Tariff Act, 1975 (hereinafter be referred to as "the Act") envisages
the imposition of a duty namely Anti-Dumping Duty on the margin of dumping on an article
exported to India where its export price is less than its normal value. It is contended that Section
9A(6) thereof also provides for determination of margin of dumping and imposition of such duty
and necessity of conducting inquiry and duty. It is contended that Rules also provide for
determining likelihood of continuation or recurrence of dumping and injury.
3.2 It is contended that the subject goods is a common analgesic and antipathetic drug that is used
for the relief of fever, headache and other minor aches and pains. According to the petitioners,
producers - exporters from China PR (hereinafter be referred to as "the subject country") were
exporting the subject goods to India for quite sometime and dumping intensified during 2001. Due
to that Domestic Industry (hereinafter be referred to as "the DI") C/SCA/5278/2019 JUDGMENT
requested imposition of Anti-dumping Duty (hereinafter be referred to as "the ADD") on the
imports of subject goods. Thereafter, on the basis of the inquiry conducted by respondent No.2, a
Final Finding Notification No.60/1/2000-DGAD dated 22.01.2002 was issued recommending
imposition of ADD. The definitive anti- dumping duties in the form of benchmark were imposed by
respondent No.2. It is contended that at the end of 5th year, the DI filed an application for 'sunset
review" in the year 2006 whereupon investigation was initiated by respondent No.2 to examine
whether the expiry of the duty would lead to continuation or recurrence of dumping and inquiry.
Respondent No.3 vide its Notification No.83/2006 extended the definitive Anti-dumping Duties in
terms of Section 9A(5) for a period of one year up to 05.09.2007.
3.3 It is contended by the petitioners that after conducting a detailed investigation, respondent No.2
issued final finding vide its Notification No.15/20/2006-DGAD recommending continuation of
ADD. In pursuance thereof, respondent No.3 issued Notification No.99/2007-Customs (ADD)
levying ADD for a further period of five years.
3.4 It is contended by the petitioners that despite imposition of ADD, the imports from China
continued to enter market in dumped prices and, therefore, being aggrieved towards the end of the
5th year, again the representative of the Domestic Industry approached respondent No.2 in
accordance with Section 9A(5) of the Act read with Rule23 of the Rules. Thereafter, being prima
facie satisfied, the DA initiated a sunset review investigation vide Notification
No.14/1009/2012-DGAD to review the need for continued imposition of duties in respect of the
subject goods originating in or exported from the subject country and to examine whether the expiryFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

of such duty is likely to lead to continuation or recurrence of dumping and injury to the DI and,
thereafter, the validity of the anti-dumping duty on the imports of the subject goods from the
subject country was C/SCA/5278/2019 JUDGMENT extended upto 02.09.2013 by respondent No.3
vide Notification No.42/2012-Customs(ADD). That after conducting detailed investigation,
respondent No.2 issued Final Finding No.14/1009/2012-DGAD recommending extension of duties
in revised form changing from bench mark of duty to fix form of duty to provide adequate protection
to the DI. In pursuance thereof, respondent No.1 issued Notification No.26/2013-Customs dated
28.10.2013 imposing fixed form of ADD for a period of another five years i.e. 27.10.2018.
3.5 According to the petitioners, despite the change in the form of ADD, the dumping continuous
from subject country which forced the petitioners along with Shri Krishna Pharmaceuticals Ltd to
again approached the authority with duly substantiated application on behalf of DI for extension of
the ADD with prima facie evidence of likelihood of dumping and injury in accordance with law. It is
contended by the petitioners that respondent No.2 provided pre- initiation hearing to petitioner
No.1 on 14.05.2018 and, thereafter, the DI filed detailed submission on 17.05.2018. Pursuant to that
respondent No.2 initiated the sunset review vide Notification No.07/16/208-DGAD to review the
need for continued imposition of the duties in force in respect of the subject goods originating in or
exported from the subject country and to examine whether the expiry of such duty is likely to lead to
continuation or recurrence of dumping and injury to the domestic industry. That pending such
sunset review, the anti-dumping duties imposed earlier have been extended by respondent No.3 for
a period of six months i.e. upto 26.04.2019 vide Notification No.29/2018-Customs (ADD) dated
20.08.2018. It is contended that on 29.08.2018, respondent No.2 granted public / oral hearing to all
the interested parties to present their views orally and on 07.09.2018, petitioner No.1 submitted a
detailed written submission justifying the need for the continuation of the duty.
          C/SCA/5278/2019                                         JUDGMENT
3.6     It is contended by the petitioners that on 15.01.2019,
respondent No.2 issued Disclosure Statement under the provisions of Rule 16 of the Rules, which
require disclosure of essential facts received and interpreted by it which are under consideration for
the purpose of arriving at a final conclusion. According to the petitioner, therefore, it filed its
comments on the disclosure statement submitting that the disclosure statement is incomplete as it
has not addressed the certain major submission made by petitioner No.1 and requested the
authority to disclose the essential facts before issuing the Final Finding. However, respondent No.2,
without appreciating the submission made by petitioner No.1 issued impugned Final Finding vide
Notification F No.7/16/2018-DGAD where DA has finally decided not to continue the ADD and
thereby rejected / ignored all the submissions made on behalf of petitioner No.1.
3.7 According to the petitioners, respondent No.2 i.e. DA has issued Disclosure Statement as
follows.Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

i. Product under Consideration and Like Article : The product under consideration in the present
Sunset Review investigation is Paracetamol and the goods produced by the Domestic Industry and
imported from the subject country are like articles in terms of the Rule 2(d) of the Anti- Dumping
Rules.
ii. Standing: M/s. Farmson Pharmaceuticals Gujarat Private Limited and M/s. Sri Krishna
Pharmaceuticals Limited constitutes "a major proportion of total Indian production"
and hence, satisfies the standing requirements for the subject goods under Rule 2(b)
and Rule 5(3) of the AD Rule.
iii. Dumping : The dumping margins are significant for the cooperating exporters /
producer and as well as for the country as a whole.
iv. Injury / Likelihood of injury: As regards the likelihood analysis, it is evident that
there are surplus capacities in China and the Chinese producers are export oriented.
China is highly export oriented country and in the event of cessation of ADD, there is
probability that the exporters / producers would resort to dumping of subject goods
to India.
        C/SCA/5278/2019                                           JUDGMENT
       v.     Non-attribution analysis : Other known factors are not
the factors contributing to or causing injury to the domestic industry.
3.8 It is contended that the petitioners herein have called for the following data and
made submission in order to enable them to come to a meaningful conclusion before
issuing the Final Finding:
i. The public at large is already well protected through a regulatory mechanism as
Paracetamol is covered under National List of essential medicine in Pharmaceutical
Policy, 2015.
ii. Paracetamol is one of the cheapest API available in the country.
iii. The production of product under consideration is quite limited globally. As, about
86% of global production is in India and China only and out of which 62% of the
production is in China alone, while India commands the remaining 24%. Thus, any
sickness in this industry would leave the Indian users at the mercy and monopoly of
the Chinese producers.
iv. Adverse effect of first dumping and thereafter insufficient form of duty led to
large-scale production suspension in the country, which was primarily in the last twoFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

decades (all these closures are more than 5 years old and are prior to previous
extension of ADD).
v. As per 145th Parliamentary Standing Committee on Commerce which assessed the
impact of Chinese goods on India industry, it is clearly stated that API sector needs
protection from imports and the Government of India also endeavours to revive the
API sector in India.
vi. Katoch Committee Report dated 24th September, 2015 on Active Pharmaceuticals
Ingredients (APIs) specifically states that a long term strategy for strengthening API
sector by involving Ministry of Commerce as well as other regulatory authorities is
required which involves judicious and liberal use of measures like anti-dumping.
vii. FICCI report February 2018 edition on "Trends and Opportunities for Indian
Pharma" highlights that dependence on China for API supplies exposes the pharma
industry to raw material supply disruptions and price volatility.
viii. Office Memorandum dated 18th April, 2018 issued by the Government of India,
Ministry of Chemicals and Fertilizers, Department of Pharmaceuticals, constituted a
Tast force to formulate a road map for enhanced production of APIs in the country as
there is need for concerted efforts to harness the opportunities in pharmaceutical
sector.
C/SCA/5278/2019 JUDGMENT 3.9 It is contended by the petitioners that without
providing such data and dealing with submissions of the petitioners, the DA has
passed the impugned Final Findings on the basis of the following reasons.
i. Evidence on record do not indicate that the dumped imports from China will lead to injury to
Domestic Industry.
ii. Import of the subject goods from China PR has remained at insignificant level throughout the
injury period.
iii. Domestic Industry failed to substantiate its claim in relation to likelihood of injury to the
domestic industry if the current ADD ceases to exist.
iv. The domestic injury has shown improvement in terms of all injury parameters and there is no
injury to the Domestic industry. Furthermore, the production of subject goods by domestic industry
is sufficient to cater to Indian demand.
v. The analysis of the price attractiveness by the Authority does not position India as price attractive
for Chinese Exports so far as subject goods are concerned.Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

vi. The ADD was in force since September, 2001 and the condition of domestic industry has
improved. Therefore, the ADD has served its intended purpose.
P. Recommendation
127. The Authority notes that the investigation was initiated and notified to all interested parties and
adequate opportunity was given to domestic industry, exporters, importers, users and other
interested parties to provide relevant information on the aspect of dumping, injury and causal link.
Having initiated and conducted the investigation into dumping, injury, causal link and likelihood of
dumping post cessation of ADD in force in terms of the provisions laid down under the Anti
Dumping Act and Rules, the Authority holds that Domestic Industry failed to provide any
satisfactory evidence that the expiry of the said anti-dumping duty is likely to lead to continuation or
recurrence of dumping and injury to the domestic industry due to reasons and/or analysis given
above. Therefore, the Authority does not recommend continuation of the anti-dumping duty on the
imports of subject goods from China PR.
4. Being aggrieved and dissatisfied with the aforesaid impugned Final Findings, the petitioners have
challenged the same on the following main grounds.
 C/SCA/5278/2019                                              JUDGMENT
(a)      Inadequate disclosure of essential facts thereby
violating the principles of natural justice and denying the domestic industry an opportunity to
defend its interests.
(b) Impugned Final Finding is a non-speaking order and does not address all the issues and
concerns raised by the domestic industry in violation of the requirements of reasoned explanation
under Rule 17 of the Anti-Dumping Rules.
(c) Error on the part of respondent No.2 in considering import as insignificant which constituted
98% of the total import and 6% of consumption in India.
(d) Conclusions arrived at by respondent No.2 are contrary to the facts showing likelihood of injury
to domestic industry in the event of revocation of duty.
(e) Current / continued injury to the domestic industry not a mandatory pre-condition in sunset
review investigation conducted under Section 9A(%) of the Act read with Rule 23 of the Rules.
(f) In an anti-dumping investigation, once the domestic industry has provided prima facie sufficient
evidence of likelihood of dumping and injury and the Designated Authority has initiated
investigation then the onus to show absence of likelihood of dumping and injury is on the exporters.Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

(g) Failure on the part of respondent No.2 to note that the domestic industry is vulnerable due to
C/SCA/5278/2019 JUDGMENT price sensitivity of the product in Indian market.
(h) Failure on the part of respondent No.2 to consider the fact that the domestic industry is
effectively protected for a period of last five years and not since September 2001.
(i) The impugned Final Finding has been issued in gross violation of the principles of natural justice
and has prevented the petitioners from effectively defending its interests
(j) For a period of which anti-dumping is levied cannot be ground for the termination of Anti-
Dumping Duties.
5. At the initial stage, this Court has passed the following order on 13.03.2019:-
Notice for final disposal, returnable on 27th March, 2019.
Learned counsel for the petitioner has invited our attention to the discloser statement
and laid emphasis upon page No.206 and 207 to indicate that the columns which
have been left blank or extract marks are provided, ordinarily ought not to have been
left blank and therefore, this was specifically brought to the notice of the authority
under the objection dated 22.1.2019. The authority without there being any decision
thereon, rendered its final findings, which could be seen from the page No. 261 and
262. In view thereof the Court is of the view that as there is a prima-facie breach of
principle of natural justice as the decisions have been rendered prima-facie without
affording appropriate material to the concerned, the Court has issued Notice for final
disposal and have been expected from the other side to file reply, if any, by the
returnable date, in case if notice is served within a reasonable time from today.
Learned counsel further submitted that conclusions are diametrical opposite to the
final findings recorded.
Direct service is permitted.
6. Thereafter, this Court has passed the following order on 11.04.2019:-
       C/SCA/5278/2019                                             JUDGMENT
     Leave to amend.
On 13.03.2019, this Court passed the following order:
Notice for final disposal, returnable on 27th March, 2019.Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

Learned counsel for the petitioner has invited our attention to the discloser statement
and laid emphasis upon page No.206 and 207 to indicate that the columns which
have been left blank or extract marks are provided, ordinarily ought not to have been
left blank and therefore, this was specifically brought to the notice of the authority
under the objection dated 22.1.2019. The authority without there being any decision
thereon, rendered its final findings, which could be seen from the page No. 261 and
262. In view thereof the Court is of the view that as there is a prima-facie breach of
principle of natural justice as the decisions have been rendered prima-facie without
affording appropriate material to the concerned, the Court has issued Notice for final
disposal and have been expected from the other side to file reply, if any, by the
returnable date, in case if notice is served within a reasonable time from today.
Learned counsel further submitted that conclusions are diametrical opposite to the
final findings recorded.
Direct service is permitted."
Thereafter, time and again the matter has been adjourned.
Today, Shri Desai, learned advocate appears for the designated authority and
submitted that the anxiety expressed on behalf of the petitioner that the anti
dumping duty for extended period also would come to an end by 26.04.2019 and he
is yet to receive instructions and reply, if any, for conducting the matter finally. In
that view of the matter, he seeks time up to 22.04.2019 only. Learned counsel for the
petitioner strongly opposes and apprehends that the period thereafter may not be
sufficient to conduct the main matter and by efflux of time the entire matter may be
rendered infructuous.
In that view of the matter, we are of the view that in case if the matter is not
conducted on 22.04.2019, the appropriate orders, including directing the authority to
extend the anti dumping duty at least for one month period may be considered to be
issued. S.O. to 22.04.2019.
7. This Court has passed the following order on 24.04.2019:-
1. Ms. Vyas, learned cousenl for the petitioner mentioned this C/SCA/5278/2019
JUDGMENT matter in the morning indicating that the matter was listed on
22.4.2019 and the same was requested for posting on the next day I.e. today.
Inadvertantly instead of 24.4.2019 it was posted on 25.4.2019 and as there is an
urgency the matter is requested to be taken up today with the intimation to all the
parties and their counsels. Accordingly the Court granted permission and the matter
listed today itself.Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

2. The learned counsel appearing for respondent No.2 states that he is in fact aware
of the orders passed in this matter but he received softcopy of the reply to be filed and
the same could be served upon the petitioner and hardcopy duly affirmed be placed
on record by tomorrow I.e. 25.4.2019 as he has been informed that the affirmed copy
is already dispachted.
3. The learned counsel appeairng for petitioner submited that in fact looking to the
fact that the notification of 20.8.2018 would come to an end by 26.4.2019 in case if
sometime is taken in filing rejoinder, if any, or the hearing of the matter is spilled
over and not completed by then, the irretrivable situation may be created and,
therefore, he urges the Court that the Court may by further interim direction direct
the authorities to extend the antidumping duty for a further period of two months as
it may take care of intervening summer vacation also and the matter be heard prior
thereot and that would serve the interst of justice.
4. This Court is of the view that while issuing the notice on 13.3.2019 an order was
passed indicating therein that the notice was being issued for final disposal and it was
made returnable on 27.3.2019 the Court did advert there into the requirement of
issuing of notice for final disposal bearing in mind that the notification of 20.8.2018
would expire on 26.4.2019. The matter thereafter was required to be adjounred at the
instance of respondent as could be seen from the order of 11.4.2019 wherein also the
Court in fact had reproduced the earlier order only with a view to infuse the sense of
urgency which appears to have worked but not to the fullest as though the reply has
come but in a soft copy which cannot be placed on record and there is a justification
on the part of the counsel for the petitioner with respect to the appropriate direction
for extending the antidupming duty so that the subject matter of petiton may not be
rendered infructuous and irretrivable situation may be avoided. The Court is,
therefore, of the view that let there be a direction to respodnent No.1 that the
antidumping duty as mentinon in Notification No.39-2018-Custom( ADD) for the
product paracetamol dated 20.8.2018 at page 119 shall be extended for a further
period of two months that would take care of hearing aspect as by then the pleading
would be completed. The antidumping duty as mentioned in the notification dated
20.8.2018 be extended for a further period upto 24.6.2019.
The matter may be posted for hearing on 12.6.2019 and the parties shall exchange their pleadings, if
any, in the meantime so that on 12.6.2019 the matter can be taken up peremptorily.
5. It would be open for the petitioner to serve copy of the order to the Director, Tax Research Unit,
Department of Commerce, C/SCA/5278/2019 JUDGMENT Ministry of Finance for compliance.
Direct service today is permitted.
8. This Court has passed the following order on 20.06.2019:-Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

The learned counsel for the petitioners as well as learned counsel for the respondents
have concluded their submissions today at around 5:00 p.m. Learned counsel for the
respondent no.2 urges the Court to permit him to place on record the written
submissions, if any on behalf of the respondent nos.1 and 2 both. The gist of the
written submissions, if any, be placed by tomorrow i.e. 21st June 2019. At this stage
Shri Soparkar, learned counsel for the petitioner submitted that the notification
whereby the anti dumping duty is extended is expiring on 24th June 2019. He further
urges that on account of the fact that anti dumping duty notification if ended that
may render the entire hearing and proceedings infructuous in light of the observation
of Supreme Court in case of Union of India and another Vs. Kumho Petrochemicals
Company Limited and another, therefore at least till the Court pronounce the
judgment and order let there be a direction to the concerned respondent no.1 for
further extending the anti dumping duty so that these proceedings may not be
rendered infructuous. We find substance in this matter as the arguments have been
continuously going on and concluded only today. Besides, there is a request from
respondent side to permit respondent no.1 to place on record the written submission.
We have granted permission to respondent no.2 also to place written submission on
record by 21st June 2019. In that view of the matter, casting an order and judgment
may take some time therefore, it is observed that the respondent nos.1, 3 & 4 shall
extend the anti dumping duty notification in respect of product in question at least
till 9th July 2019 before the existing notification comes to an end. Put-up on 21st
June 2019. Direct service permitted.
9. Learned advocate for the petitioners has placed on record the brief submissions, which verbatim
reproduced as under:-
THE IMPUGNED FINAL FINDING HAS BEEN ISSUED IN GROSS VIOLATION OF
HTE PRINCIPLES OF NATURAL JUSTICE AND HAS PREVENTED THE
PETITIONERS FROM EFFECTIVELY DEFENDING THEIR INTERESTS :
1. Respondent no.2 has erroneously applied Rule 7 in the present investigations, in so
far as it has failed to disclose the details of the Dumping Margin calculations to the
petitioners no.1 in para 52 3 (a) (b).
Determination of Dumping Margin for china PR as a whole.
a) Comparing the normal value and export price at ex- factory level for the country as a whole, the
dumping margin C/SCA/5278/2019 JUDGMENT for the subject country is determined as below:
     Particulars                            US$/Kg                    Rs/kg
     US$/kg.Rs/kg (POI)
     Normal value                           ***                       ***
     Net Export Price                       ***                       ***
     Dumping Margin                         ***                       ***
     Dumping Margin %                       ***                       ***Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

     Range %                                10-20                     10-20
    b.       After details analysis of DGCIS transaction wise data
it has been observed that out of total imports of china PR i.e *** MT *** % imports are dumped and
*** % are injurious.
2. The Dumping margin is the difference between the Normal Value and export price. In the facts of
the present case, the Normal Value has been determined based on the information furnished by the
petitioner, which has been disclosed to the petitioner. However, export price based on DGCI&S data
which, are available in public domain ought to have been disclosed to the petitioners.
3. Similarly, injury parameters have been determined based on the information furnished by the
petitioner no. 1 ( para 60 to 80 of the Impugned Final Ending (page nos. 265 to 279) the respondent
no. 2 ought to have disclosed these figures to he petitioners. Further conclusion based on these
information cannot be kept confidential from petitioners as held int he following judgments:
i. Reliance Industries Ltd. Vs Designated Authority, (2006) 10 SCC 368 (Para 44).
ii.UOI vs. Union of India vs. M/s. Meghmani Organics Ltd. & Ors. (2016) 10 SCC
(para 29) and iiiNirma Limited Versus Union of India (2017 (358) E.L.T 146 (Guj.)]
(Para-32.12)(upheld by Hon'ble Supreme Court).
4. During the course of final hearing, respondent no. 2 has tendered a printout of alleged email sent
to petitioner no.1 and contended that all the information has been shared with petitioner no.1. At the
outset, it is submitted that such contention or a copy of the email have not by respondent no.2 in its
affidavit-in-reply.
5. It is submitted that petitioner no.1 has received information only pertaining to construction of
Normal Value and break down of non-injurious price (NIP) as is evident from the content of mail
itself. However, it did not receive any information pertaining to injury parameters which was
claimed confidential and asterisk mark were used int he disclosure statement and impugned final
finding despite the fact that the information has been furnished by the domestic C/SCA/5278/2019
JUDGMENT industry itself. the computation of the various factors referred in (para 60 to 80 of the
impugned final finding (page nos 265 to 279)] has not been furnished to the domestic industry.
6. It was incumbent upon respondent no. 2 to furnish the relevant facts which have been used by it
as the basis for arriving at its conclusion on the essential facts for the purpose of arriving at a
decision as to whether or not the definitive measures are required to be applied. Non-disclosure of
the essential facts is therefore, clearly in breach of the principles of natural justice.
II THE IMPUGNED FINAL FINDING IS BAD IN LAW AND PERVERSE AND BASED ON
EXTRANEOUS FACTORS:Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

7. The present case being a sunset review investigation, the respondent no. 2 was required to
examine the likelihood of continuation or recurrence of dumping or injury, as provided under
proviso to Section 9A(5), extracted herein below:
"(5) The anti-dumping duty imposed under this section shall, unless revoked earlier,
cease to have effect on the expiry of five years from the date of such imposition:
Provided that if the Central Government, in a review, is of the opinion that the
cessation of such duty is likely to lead to continuation or recurrence of dumping and
injury, it may, from time to time, extend the period of such imposition for a further
period of five years and such further period shall commence from the date of order of
such extension.
8. Respondent no. 2 has acted in violation of the provisions of section 9A (5) of the Act read with
Rule 23 of the Rules in as much as it has lent unwarranted weightage to the fact that the petitioner
No.1/Domestic Industry is allegedly not suffering injury during the current period. While issuing the
impugned final finding, respondent no.2 stated that "the domestic injury has shown improvement in
terms of all injury parameters and there is no injury to the Domestic industry". [Para-126(3) of
Impugned Final findings (page no.
281)].
9. The assessment whether injury will continue, or recur, would entail a counter-factual analysis of
future events, based on projected levels of dumped imports, prices and impact on domestic industry.
Therefore, in a sunset review investigation respondent no. 2 needs to address the question as to
whether the domestic industry is likely to be materially injured again, if duties are lifted.
Respondent No. 2 has therefore, failed to appreciated the fact that if the anti- dumping duty has had
the desired effect, the condition of the domestic industry is expected to have improved during the
period anti-dumping duty was in force.
III THE IMPUGNED FINAL FINDING ARE DIAMETRICALLY OPPOSITE TO THE ESSENTIAL
FACTS RECORDED INT HE DISCLOSURE STATEMENT AND FINAL FINDING:
C/SCA/5278/2019 JUDGMENT
10. Following are essential facts recorded in the impugned final findings which are diametrically
opposite to conclusions reached by respondent :
Sr. FACTS RECORDED IN THE DIAMETRICALLY No IMPUGNEDFINAL
FINDINGS OPPOSITE CONCLUSION REACHED IN THE IMPUGNED FINAL
FINDINGS 1 86.(a) A significant rate of Import of the increase of dumped imports
into subject goods from India indicating the likelihood of China PR has substantially
increased remained at importation. insignificant level throughout the Parti Uni 201
201 201 PO injury period.Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

cular ts 4- 5- 6-17 15 16 [paragraph 126(2) (page no. 281).] Chin MT 435 193 220 296
r Total MT 443 204 223 303
87. The Authority notes that while there was a considered decline in the volume of
imports compared to base year.
88. An analysis of transaction wise data of the co-operative producers with their
respective exporters so as to arrive at dumped and injurious imports of the
co-operative producer of the present investigation is as follows :-
a) M/s Anqiu Lu An Pharmaceutical Co. Ltd.
b) M/s Anqiu Lu An Pharmaceutical Co. Ltd.
The total exports to India by the said producer with trader of the subject goods are
*** MT oput which *** MT are dumped imports and *** MT are injurious imports.
c) M/s Lianyungang Kangle Pharmaceuticals Co. Ltd.
Total exports to India by the said producer of the subject goods through its exporters
is *** MT C/SCA/5278/2019 JUDGMENT out which dumped imports constitute***
MT. No injurious imports were found for the said producer through its exporter.
d) M/s Hebei Jiheng (group) Pharmaceutical Co. Ltd.
Total exports to India by the said producer of he subject goods is *** MT. All imports
of the said producer are dumped and *** MT are injurious.
[para no. 85-87 (page no. 273-
274).
SUBMISSION Respondent no. 2 erred in considering import as insignificant which
constituted 98% of the total import and 6% of consumption in India (more than
insignificant as define in Rule 14(d), Even otherwise Rule 14 of the Rules dealing with
the termination of investigation on the basis of insignificant imports is explicitly
excluded from Rule 23(3) and therefore issuance of the impugned final findings by
respondent no. 2 in the present case on the basis of the volume of insignificant
import are contrary to the mandate of law.
* Imports are 5.84% (above diminimus level) (paragraph no.62 table at page no.265); and * Rule
14(d) at defines volume of significant import (page no.99) 1 (b) Sufficient freely Domestic Industry
failed disposable, or an imminent, to substantiate its claim substantial increase in, in relation to
likelihood capacity of the exporter of injury to the domestic indicating the likelihood of industry ifFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

the current substantially increased ADD ceases to exist.
          dumped exports to Indian
          markets, taking into account       [paragraph 126(3) (page
          the availability of other          no.)]
          export markets to absorb
          any additional exports.
          89. The Authority evaluated
          the      existing       surplus    The analysis of the price
          capacities, capacity addition,     attractiveness by the
          if any, with the responding        Authority    does     not
          exporters, possibility of trade    position India as price
          diversion      from        third   attractive for Chinese
          countries to India, freely         Exports so far as subject
          disposable          production     goods are concerned.
          capacities       with        the
          responding exporters. The          [paragraph 126(5) (page
 C/SCA/5278/2019                                                  JUDGMENT
          analysis shows as follows:            no.281)]
          a.    Capacity,   production,
          surplus capacities, exports to
          India
           Nam U      Anq     Lia    Heb T
           e of ni    iu      ny     ei   ot
           Prod ts    Lu      un     Jihe al
           ucer       An      ga     ng
                      Pha     ng     (gro
                      rma     Ka     up)
                      ceu     ngl    Pha
                      tical   e      rma
                      Co.     Pha    ceut
                      Ltd.    rm     ical
                              ace    Co.
                              utic   Ltd.
                              al
                              Co.
                              Ltd
                              .
           Cap M      ***     ***    ***   **
           acity T                         *Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

           Prod M     ***     ***    ***   **
           ucti T                          *
           on(P
           OI)
           Cap % ***          ***    ***   **
           acity                           *
           utilis
           atio
           n
           Dom M      ***     ***    ***   **
           estic T                         *
           Con
           sum
           ptio
           n
           Exp    M   ***     ***    ***   **
           orts   T                        *
           to
           Indi
           a
           Exp    M   ***     ***    ***   **
           orts   T                        *
           to
           RO
           W
           Tota M     ***     ***    ***   **
           l    T                          *
           Exp
           orts
           %      R ***       ***    ***   3
 C/SCA/5278/2019                                      JUDGMENT
           orts ge                       -
           on
          b. After analysis of the
          capacities of the cooperative
          exporters,     the   Authority
          notes that the capacities of
          the       following       non-
          cooperative      exporters   /
          producers as per the dataFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

          submitted by the petitioner
          and the information available
          in public domain.
           S      Producers        in Capa
           N      China               city
                                      (MT
                                      per
                                      annu
                                      m)
           1      Anhui      BBCA 1000
                  Pharmaceutical
           2      Changshu           8000
                  Huagang
                  Pharmaceutical
           3      Jiangsu   World 1000
                  Pharmaceutical
           4      Wenzhou            6000
                  Pharmaceuticals
                  factory
           5      Jiangsu Guoheng 2500
                  Pharmaceutical
                  Co. Ltd.
           6      Runqi trading Co. 1200
           7      Shanghai Bailion 5000
                  Chemicals    Co.    0
                  Ltd.
           8      Lianoyuan   City     500
                  Baikang
                  Pharmaceutical
           9      Total capacity of 9900
                  non             -    0
                  cooperative
                  entitles
           10 Total capacity of 7500
              producers
           11 Total capacity of 1740
 C/SCA/5278/2019                                     JUDGMENT
           12 Indian demand            5106Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

          c. However, it is observed
          from the analysis of the
          cooperating producers that
          the trading companies do
          not    have      their    own
          production facilities and they
          quote the capacity of the
          producers on their websites.
          d.     Considering     the
          capacity utilisation and
          export orientation of the
          responding      producers
          and evidence provided by
          the domestic industry, it
          is evident that there are
          surplus    capacities   in
          China and the Chinese
          producers    are    export
          oriented.
          (C) Inventories of the
          article being investigated
          90.   The    questionnaire
          response filed by the
          Chinese producer's shows
          that level of inventories
          with    the    cooperative
          producers / exporters is
          quite significant.
           Producer Uni 2     2    2    PO
                    ts 0      0    0    I
                        1     1    1
                        5     6    7
           M/s.Anqi MT ** ** ** **
           u Lu An     * * * *
           Pharmac
           eutical
           Co. Ltd.
           Lianyun MT ** ** ** **
           gang       * * * *
           Kangle
           Pharmac
           eutical
           Co. Ltd.
           Hebei   MT ** ** ** **
           Jihen      * * * *
           (group)
           PharmacFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

           eutical
 C/SCA/5278/2019                                     JUDGMENT
           Co. Ltd.
           Total       MT ** ** ** **
                          * * * *
          (D) Price attractiveness of
          Indian mark
          91. Analysis of the China
          PR Custom data with
          regard to export from
          China PR to the rest of
          the world, indicate that
          with the revocation of
          ADD, the Indian prices
          would be attractive for
          the Chinese producers /
          Exporters     to    increase
          their exports to India and
          the same can be deducted
          from the table given below:
           Country     Quan Valu      Pri
                       tity e         ce
                       (kg) USD       US
                                      D/k
                                      g
           India (IN) ***     ***     ***
           Congo,      ***    ***     ***
           DR
           Cuba        ***    ***     ***
           (CU)
           Kenya       ***    ***     ***
           (KE)
           Mauritius ***      ***     ***
           (MU)
           Indonesia ***      ***     ***
           (ID)
           S. Africa ***      ***     ***
           (ZA)
           Iraq (IQ)   ***    ***     ***
           Zambia      ***    ***     ***
           (ZM)Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

           Russia      ***    ***     ***
           (RU)
           Iran (IR)   ***    ***     ***
           Syrian      ***    ***     ***
           (SY)
           Benin (BJ) ***     ***     ***
           Mozambi     ***    ***     ***
           que (MZ)
 C/SCA/5278/2019                                            JUDGMENT
           United     ***    ***     ***
           Arab
           Emirates
           (AE)
           Tanzania   ***    ***     ***
           (TZ)
           Lithuania ***     ***     ***
           (LT)
          Source : China Custom
          92. The Authority notes
          that ***% total volume of
          exports to third countries
          is at a price lower than
          the price at which China
          exports to India. Whereas
          ***% of the total exports
          are exported are above
          the price at which China
          exports the subject goods
          to India.
          (E) Export Orientation of
          China PR
          93. As per the data of
          China Customs and other
          evidence filed by the
          Domestic Industry, the
          Authority notes that the
          producers in China are
          oriented towards exports
          globally.Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

          In the event of cessation
          of    ADD,     there     is
          probability    that    the
          exporters    /  producers
          would resort to dumping
          of subject goods to India.
          [paragraph no.88 - 93 (page
          no.273-277)]
     SUBMISSION:
Conclusions arrived by Respondent no.2 are contrary to the facts showing likelihood of injury to
domestic industry in the event of revocation of duty. Despite the fact and evidences brought by the
petitioner and examination of the evidences by Respondent no.2 clearly showing that likelihood of
dumping and injury in the event of cessation of anti- dumping duty, the Respondent no.2 went
beyond the evidence and information examined in the Impugned Final Finding and concluded volt
face without any basis that there is inadequate evidence submitted by the domestic industry to
substantiate the likelihood of injury.
     3                             The ADD was in force since
        C/SCA/5278/2019                                           JUDGMENT
                                         September'2001     and     the
                                         condition of domestic industry
                                         has improved. Therefore, the
                                         ADD has served its intended
                                         purpose.
                                         [paragraph     126(6)       (page
                                         no.281)]
            SUBMISSION:
Duration of levy of anti-dumping is not a relevant parameter. Anti-dumping duty is required to be
imposed so long as the investigation shows that the cessation of such duty is likely to lead to
continuation or recurrence of dumping and injury. The Act and the Rules do not prescribe any time
limit beyond which the Anti-dumping duty cannot be extended.
11. In light of the foregoing, the present petition and the prayers sought therein deserve to be
allowed.
9.1 Learned advocate for the petitioners has relied upon the following decisions.Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

1. In the case of Nirma Limited Vs. Union of India, reported in 2017 (358) E.L.T. 146 (Gujarat).
2. In the case of Reliance Industries Limited Vs. Designated Authority and others reported in (2006)
10 SCC 368;
3. In the case of Union of India and another Vs. Meghmani Organics Limited reported in (2016) 10
SCC 28;
4. In the case of DCW Limited Vs. Union of India, rendered on 11.06.2018 by this Court in Special
Civil Applications No.14202 of 2017 and allied matters .
10. Learned advocate for respondent No.3 has placed on record the written submissions which
reproduced as under:-
Re: The Notification dated 16.04.2019 (Rescinding Notification) issued by the
Department of Revenue is not impugned in the Writ by way of a formal amendment.
1. At the very outset, it is respectfully stated that the Notification dated 16.04.2019
(Rescinding Notification) which was issued by the Respondent No. 3, Ministry of
Finance under Rule 18 of the Anti-Dumping Rules, 1995 have not been
C/SCA/5278/2019 JUDGMENT impugned in the present Writ Petition preferred by
the Petitioner.
2. Albeit the Petitioner herein had filed an application, bearing No. IA No. 1 of 2019
in the present Writ Petition, praying for, inter alia, quashing the Rescinding
Notification of the Respondent No. 3 as well staying the operation and effect thereof;
it is pertinent that till date no formal amendment has been preferred in the present
Writ Petition, impugning the said Rescinding Notification issued by Respondent No.
3 under Rule 18 of the Anti-Dumping Rules, 1995.
3. It is also noteworthy that the prayers in the Writ Petition (at page 87) only seek
directions from this Hon'ble Court qua the Disclosure Statement dated 15.01.2019
and the Final Findings dated 29.01.2019, both of which have been issued by the
Respondent No. 2 (Directorate General of Trade Remedies).
4. In view thereof, it is respectfully submitted that the present Writ Petition qua the
Respondent No. 3 is wholly misconceived and ought to be dismissed, for reasons,
inter alla, that the Rescinding Notification has not even been impugned in the Writ
Petition (even vide an amendment), and as such, no prayers have been sought against
the Respondent No. 3.
Re: The Petitioner has an alternate remedy in Customs Excise and Service Tax Appellate Tribunal
(CESTAT)Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

5. Without prejudice to the aforesaid submission, It is stated that the Petitioner has erred in
approaching this Hon'ble High Court in as much as it is an established principle of law that the writ
jurisdiction of this Hon'ble High Court is an extraordinary jurisdiction, and ought not to be invoked
till the statutory remedy has been exhausted.
6. It is submitted with due deference to this Hon'ble Court that the writ jurisdiction of this Hon'ble
Court ought not to have been invoked by the Petitioner, in light of an alternative remedy available to
the Petitioner under the provisions of the Custom Tariff Act, 1975. It is respectfully submitted that
the appeal against the findings of the designated authority viz. Directorate General of Trade
Remedies lies with the CESTAT under Section 9C of the Customs Tariff Act, 1975. Section 9C of the
Custom Tariff Act, 1975 is reproduced below for ease of reference of this Court:
"SECTION 9C - Appeal -
(1) An appeal against the order of determination or review thereof regarding the
existence, degree and effect of any subsidy or dumping in relation to import of any
article shall lie to the Customs, Excise and Service Tax Appellate Tribunal constituted
under section 129 of the Customs Act, 1962 (hereafter referred to as the Appellate
Tribunal). (1A)......
C/SCA/5278/2019 JUDGMENT (3) The Appellate Tribunal may, after giving the
parties to the appeal an opportunity of being heard, pass such order thereon as it
thinks fit, confirming, modifying or annulling the order appealed against.
(4) The provisions of sub-section (1), (2), (5) and (6) or section 129C of the Customs
Act, 1962 shall apply to the Appellate Tribunal in the discharge of its functions under
this Act as they apply to it in the discharge of its functions under the Customs Act,
1962.
(5) Every appeal under sub-section (1) shall be heard by a Special Bench constituted
by the President 0f the Appellate Tribunal for hearing such appeals and such Bench
shall consist of the President and not less than two members and shall include one
judicial member and one technical member.
7. In this regard, it may not be out of place to place reliance on the recent judgment of Designated
Authority V. San Disk, reported in 2018 13 SCC 402, wherein the domestic industry had raised
similar issues, including without limitation that the Designated Authority had violated principles of
natural justice and/ or that all material / information was not provided to it. In such similar
circumstances as well, the Hon'ble Supreme Court was pleased to opine that in view of the statutory
remedy provided under section 9C of the Customs Tariff Act. 1975, the writ petition under Article
226 would not be entertained. Several other High Courts in India, including without limitation the
High Court of Delhi, Calcutta, Madras as well as Bombay have been pleased to direct the parties to
invoke the statutory remedy of CESI'AT instead of invoking the extraordinary writ remedy under
Article 226 of the Constitution.Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

8. In this context, it is stated with utmost humility and deference to this Hon'ble Court that in the
recent decision of Hindustan Lever v. Union of India [2017 SCC Online Del 8354], the Division
Bench of the High Court of Delhi has taken note of the decision of Nirma Ltd. v. Union of India
(judgment dated 23rd February, 2017 in C/SCA/16426/201 of the this Hon'ble High Court of
Gujarat) and categorically dismissed the writ petition, on the ground of the alternative remedy
available to the petitioners therein. The relevant extract of the aforementioned Hindustan Lever v.
Union of India (supra) judgement is reproduced below for the ease of reference of this Hon'ble
Court:
"6. The Court is unable to be persuaded to agree with the above conclusion reached
by the DB of the Gujarat High Court 777e reasons that weighed with the Gujarat High
Court to conclude that it will not be possible for the party aggrieved to challenge the
disclosure statement before the CESTAT is unable to be discerned from the above
passage. If the Final Finding can be appealed against before the CESTA 7; there is no
reason why the CESTA T cannot examine the correctness of the assertions made in
the disclosure statement which constitutes the very foundation of the entire exercise
leading up to the Final Finding by the DA.
C/SCA/5278/2019 JUDGMENT
7. The relevant portion of Section 9 C of the CTA reads thus:
8. Given the scope of the appellate power of the CESTA T as spelt out Section 9 C of
the CTA, there is nothing to indicate that the CESTAT would be precluded from
examining the validity of the disclosure statement issued under Rule 16 of the Rules.
It is like saying that an appellate Court which Is in exercise of its powers under
Section 96 of the Code of 0W Procedure 1908 (0°C) judicially reviewing a decree and
judgment in a suit would be precluded ham examining the correctness of the
assertions made in a plaint or a written statement. In the context of the proceedings
before the DA, the disclosure statement would be comparable to a plaint.
Consequently, the Court is not persuaded that the grounds urged in the writ petition cannot be
urged before the CESTAT. It is not without significance that the Gujarat High Court makes no
reference in the above passage in Nirma Ltd. v. Union of India (supra) to Section 9C of the CTA.
9. We Court is also not persuaded to take a view different the one it has in Alcatel-lucent India Ltd. v
Designated Authority (supra); PTA Users Association v. Union of India (supra) and Balaji Action
Buildwell v. Union of India (supra).
10. The question is not whether this Court can entertain the present writ petition. The question is
whether, in the facts and circumstances, it should? The power under Article 226 of the Constitution
is an extra-ordinary one and should not be exercised in a routine manner especially when the
Petitioner has an efficacious and adequate alternative statutory remedy available. Otherwise, the
Court would be supp/anting the functioning of the statutory appellate authority tasked specificallyFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

with reviewing the correctness of the orders of the subordinate statutory authorities. Therefore,
while acknowledging that this Court does have the jurisdiction to entertain the writ petition, in the
facts and circumstances of the present case the Court lines that no case has been made out to
persuade it to exercise its jurisdiction under A/tic/e 226 of the Constitution to examine the
correctness of the Fina/ Finding of the DA. 777e Court is of the firm view that every ground urged in
the present writ petition can well be urged before the CESTAT.
11. The writ petition and applications are accordingly dismissed. However, this will not preclude the
Petitioner from availing the statutory remedy of an appeal before the CESTA T in accordance with
law and from urging all the grounds raised here, and any other ground it may have, to challenge the
Final Finding of the DA. The Petitioner may request the CESTA T for an expedited hearing of its
appeal . "
(emphasis supplied)
9. Further, there are no extraordinary circumstances pleaded by the Petitioner in the
present case that warrant the invocation of Article 226 of the Constitution of India
and there C/SCA/5278/2019 JUDGMENT has been no violation of their fundamental
right or any situation as grave as may have required imminent intervention of this
Hon'ble High Court in extraordinary jurisdiction even while no cause of action had
arisen.
10. In view of the aforesaid, it is most respectfully submitted that given the highly
specialized nature of the subject, the statutory remedy would be a more appropriate
course of action for an aggrieved party, and the Hon'ble High Court under their writ
jurisdiction cannot don the mantle of an economic analyst to decide whether the DA
adopted the correct approach; and therefore, as long as the final findings are in
accordance with law, this Hon'ble High Court ought not to interfere under Article 226
of the Constitution.
Re: The Central Government is not empowered to review its own order / notifications
11. The Petitioner herein while challenging the Disclosure Statement and the Final
Finding before this Hon'ble Court has failed to appreciate that the notification No.
35/2018Cus (ADD) dated 20.8.2018 was rescinded by way of the notification No.
19/2019-Cus (ADD) dated 16.4.2019 (Rescinding Notification). The said rescinding
was undertaken after obtaining the approval of the Finance Minister,' whereby the
final finding of the DA was upheld.
12. Without prejudice to the aforementioned submissions, it is respectfully submitted
that in view of the fact that Anti Dumping Duty on the 'paracetamol' has come to an
end, owing to the Rescinding Notification dated 16.04.2019, this Hon'ble Court
cannot revive the notification which is already dead in the eyes of law, and neither
can the same be enforced. The Petitioner herein has failed to appreciate that in such aFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

case (apart from preferring an appeal before CESTAT), the Petitioner is empowered
under law to freshly initiate the process for levy of duty under the provisions of the
Custom Tariff Act, 1975 and the Anti Dumping Rules, 1995; but once the Anti
Dumping Duty has been rescinded in accordance with the provisions of law, neither
can the said rescinding be suspended by the court, nor can the Anti Dumping Duty be
extended without following the due process of law as provided in the Custom Tariff
Act, 1975 and the Anti Dumping Rules, 1995.
13. In this regard, the second proviso to Section 9A (5) of the Customs Tariff Act, 1975
is instructive and reads as follows:
"Provided further that where a review initiated before the expiry of the aforesaid
period of have years has not come to a conclusion before such expiry, the
anti-dumping duty may continue to remain in force pending the outcome of such a
review for a further period not exceeding one year."
14. It is respectfully submitted that the plain reading of the above quoted section envisages that any
notification imposing anti-dumping duty can only be extended pending the outcome of sunset
review investigation. In the present case, the C/SCA/5278/2019 JUDGMENT Designated Authority
(DA) after initiating sunset review investigations recommended extension of anti-dumping duty till
26.04.2019 which was done vide notification No. 39/2018- Cus (ADD). Subsequently, DA issued
their sunset review final findings and did not recommend continuation of anti-dumping duty.
Thereafter vide notification No. 19/2019-Cus (ADD) dated 16th April, 2019 the same was rescinded
with the approval of Finance Minister. Thus, extension of anti-dumping duty under these
circumstances will be contrary to the provisions of Section 9A (5) of the Customs Tariff Act, 1975. It
is an established principle of law that if the law directs something to be done in a particular way, it
ought not to be done in any other way. In view of the above, and in the absence of any inherent
power to review its own decision, the directions as prayed for by the Petitioner ought not be granted
by this Hon'ble Court. Reliance is placed on the judgment of the Hon'bie Supreme Court in the case
of Union of lndia (U01) and Ors. V Kumho Petrochemicals Company Limited and Ors. [AIR 2017 SC
3357] in this regard.
15. In any event, if it is the case of the Petitioner that the Final Findings need to be set aside for
reasons, inter alia, that there Is a violations of principles of natural justice, in that event also, the
matter ought to be remanded to the DA to cure the alleged defect, and it is not open to this Hon'ble
High Court to extend the notification to impose Anti-Dumping Duty and/or suspend the rescinding
notification of the Central Government. The aforesaid submission is without prejudice to the legal
assertion that principles of natural justice as applicable to investigation/inquiries against
individuals, may not have a strict application to the investigation under the Anti-dumping Rules,
1995, and therefore the assertions of the Petitioner qua alleged non-compliance of the rules of
natural justice by the DA are liable to be rejected. In any case, the Petitioner has failed to show how
any prejudice has been caused to him due to the alleged non-compliance of the rules of natural
justice by the DA, and as such In the absence of any prejudice to the Petitioners, its plea qua the
alleged non- compliance ought to be rejected by this Hon'ble High Court.Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

16. Without prejudice to the aforesaid submissions, it is further respectfully submitted that it is well
settled, the writ jurisdiction of the Hon'bIe High Court cannot be used to give a direction to the
legislature or the subordinated legislature (as in the present case) to enact a particular law; and
neither can the writ jurisdiction of the Hon'ble High Court be invoked to interfere in matters related
to policy and economic matters. It is humbly stated that the issuance/ withdrawing/ rescinding of
the notification is a policy decision and extending the period of the notification and keeping
notification In abeyance cannot be interfered by the court unless the validity of such actions is
challenged on its own merits before the court. In the present circumstances, the subject goods are in
the category of generic and mass consumption medicines, which are being routinely consumed by
the all sections of the population. Hence, India, which is a welfare state, is duty bound to provide the
subject goods at an affordable price to its citizens. As submitted In the preceding paragraphs, the
Imposition of C/SCA/5278/2019 JUDGMENT the anti-dumping duty for 17 years has met Its
objective and it is opportune time to allow free import of this essential drug without any extra duty.
In view of this policy, the Answering Respondent deemed It appr0priate to affirm the Final Findings
of the DA and rescind the duty on the Imported goods. It Is reiterated that if the member of the
domestic industry Is aggrieved by the said findings, it may invoke the appeal provisions in law and/
or file a fresh application for imposition of Anti Dumping Duty, but is refrained from approaching
this Hon'bie Court under Article 226 of the Constitution.
17. In view of above submissions, it is prayed that Petitioners have no case on merits or otherwise
and hence, the present Petition deserves to be dismissed.
Re:List of Judgements
18. The Respondent annexes herewith an index of judicial pronouncements, sought to be relied
upon by the Respondent No. 3 in support of its aforementioned contentions.
10.1 Learned advocate for respondent No.3 has relied upon the following decisions.
1. In the case of Rishiroop Polymers (P) Ltd. Vs. Designated Authority and Additional Secretary,
reported in (2006) 4 SCC 303;
2. Indian Metal and Ferro Alloys Ltd. Vs. Designated Authority, Ministry, reported in (2008) 224
ELT 375;
3. M/s. Kanoria Chemicals and Industries Ltd Vs. Designated Authority, Directorate General of
Allied Duties and others, reported in 2015 SCC Online CESTAT 284;
4. In the case of Designated Authority Vs. Sandisk International Ltd., reported in (2018) 13 SCC
402;
5. Jindal Poly Film Ltd. Vs. Designated Authority and others, reported in 2018 (362) ELT 994;
C/SCA/5278/2019                                      JUDGMENTFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

6.      Suncity   Sheets       Pvt.     Ltd.   Vs.      Designated
Authority, reported in 2017 SCC Online Del 9412;
7. Spacewood Furnishers Vs. Designated Authority and others, reported in 2010 (112) Bom L.R.
2045;
8. Shew Kumar Agarwal and Others Vs. Union of India, reported in (2002) 1 CALLT 588 HC;
9. Union of India (UOI) and others Vs. Kumho Petrochemicals Company Limited and others,
reported in AIR 2017 SC 3357;
10. Eveready Industries India Ltd. Vs. Union of India, reported in 2019 SCC Online Del 7865;
11. Sterlite Industries (India) Ltd. Vs. Designated Authority, reported in 2003 (158) E.L.T. 673 (SC);
12. Fragrances Flavours Association of India Vs. Designated Authority, reported in 2011 (270) E.L.T.
733;
13. Huawei Tech. Co. Ltd. Vs. Designated Authority, reported in 2011 (273) E.L.T. 293 (Tri.-Del.);
14. Supreme Court Employees Welfare Association Vs. Union of India reported in (1989) 4 SCC 187;
15. Census Commissioner and others Vs. R. Krishnamurthy, reported in (2015) 2 SCC 796;
C/SCA/5278/2019 JUDGMENT
16. Kerala Colour Lab Association Vs. UOI, reported in 2003 (156) ELT 17;
17. R. K. Garg Vs. UOI, reported in 1981 AIR 2138;
18. Rusom Cavasiee Cooper Vs. Union of India, reported in (1970) 1 SCC 248;
19. Suresh Seth Vs. Commr., Indore Municipal Corporation reported in (2005) 13 SCC 287;
20. Haridas Exports Vs. All India Float Glass Manufacturer Association and others, reported in
(2002) 6 SCC 600;
11. Mr.Desai, learned advocate for respondent No.2 has vehemently opposed the present petition
and has submitted that the petitioners has challenged the Final Finding and DA on the basis that the
informations were not supplied to it. While inviting the attention of the Court to the email,
Mr.Desai, learned advocate has submitted that the necessary informations have already beenFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

supplied to the petitioners by email and the other particulars which are available on public domain
has also made available to the petitioners' representative. While referring to extract of the page of
register of the non-confidential informations public file, Mr.Desai has submitted that the
representative of the petitioners has accessed the public file and, therefore, the question for
non-furnishing of informations is devoid of merits. Regarding data available at DGCSI which was
made used by DA, Mr.Desai, learned advocate has submitted that the data available on website is
not accessible to everybody and one has to make payment of charge and, therefore, it cannot be
treated as on public domain. While referring to Disclosure Statement, he has submitted that all facts
were made C/SCA/5278/2019 JUDGMENT available to concerned parties and the informations
were supplied in spread sheet form through email. According to him, there was substantial
compliance of providing informations to the petitioners and there is no breach of any Rules as to
non-disclosure of the important facts and informations to the petitioners. He has contended that
equal treatments have been given to everybody and any other confidential facts has not disclosure,
however, the facts which are confidential for the petitioner itself are supplied to him.
11.1 While referring the Rules 16 and 17 of the Rules, Mr.Desai, learned advocate has submitted that
the Final Finding be always based on the observation made in Disclosure Statement and there is
hardly any further inquiry needed after disclosure statement and, therefore, it could be assailed on
the ground of similarity in the Disclosure Statement and Final Finding. He has contended that the
Disclosure Statement is always based on data and there is no any exercise is taken during the period
between the Disclosure Statement and Final Finding. According to him, on the basis of the
informations, after conclusion of the Disclosure Statement, the question remain is only regarding
evaluation of the data, which is being carried out and on that basis, the Final Finding could be
arrived at. He has submitted that there is no breach of any natural justice and there is no allegation
in the pleadings of the petitioners as to perversity in the action of the DA.
11.2 Regarding maintainability of the petition on the ground of availability of alternative remedy,
Mr.Desai, learned advocate has also submitted that the appeal can be preferred by the petitioners
before the CESTATE and the question raised by the petitioners could be gone into by the said
Tribunal and the methodology could also be tested by the CESTATE. According to him, this is not a
forum for the petitioners to revoke the jurisdiction of this Court under Article 226 of the
Constitution of India. While relying on the following C/SCA/5278/2019 JUDGMENT decisions on
the point of jurisdiction, Mr.Desai, learned advocate has requested the Court to relegate the
petitioners to prefer alternative remedy of approaching the CESTATE.
1. In the case of Jindal Poly Film Ltd. Vs. Designated Authority, reported in 2018 E.L.T. 994 (Delhi);
2. In the case of Kesoram Rayon Vs. Designated Authority, reported in 2018 (359) E.L.T. 475
(Delhi);
3. In the case of Outokumpu Oyj Vs. Union of India, reported in 2018 (360) E.L.T. 679 (Delhi);
12. In rejoinder, Mr.Soparkar, learned senior advocate for the petitioners has vehemently submitted
that though his clients have received email but no annexure has been received by them regardingFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

information on spread sheet. He has submitted that the Disclosure Statement is dated 21.01.2019,
whereas, the email in question has sent on 15.01.2019. According to him, this was the earlier
information sent before the Disclosure Statement was issued. He has submitted that there is no
email or information sent by the authority after 22.01.2019. While referring to the affidavit-in-reply
filed by the respondent authority, Mr.Soparkar has also submitted that sending of informations to
the petitioners by the Designated Authority has not been specifically mentioned in such affidavit and
it is only oral submissions made during the course of arguments, which cannot be accepted at all.
12.1 Regarding public file, Mr.Soparkar, learned senior advocate has also submitted that this is a
public file which can be inspected by anyone and it is not confidential. Regarding substantial
informations, Mr.Soparkar has submitted that the question is to provide every information and
there is no question of any C/SCA/5278/2019 JUDGMENT percentage of data to be provided to the
party concerned.
12.2 Regarding decisions relied upon by Mr.Desai, learned advocate on the point of jurisdiction,
Mr.Soparkar, learned senior advocate has submitted that there is no bar to the High Court to
entertain the writ petition under Article 226 of the Constitution of India considering the fact that
there is non-compliance on the part of the Designated Authority in providing the informations to the
petitioners and considering the fact that the conclusion arrived at in Final Finding is diametrically
opposed to the reasons given in report itself as well as in the disclosure statement, this Court has
jurisdiction to entertain the petition and pass necessary order. He has prayed to allow the petition.
13. The Court has heard learned counsels for the parties and perused the pleadings. Before adverting
to the rival contentions of learned advocates for the parties, it would be most appropriate to set out
hereinbelow few indisputable aspects emerging therefrom -
(i) This petition is in respect of the goods imports of paracetamol originating in or exported from
China PR.
(ii) On 22.01.2002, respondent No.2, on the basis of the inquiry conducted, issued the Final Finding
Notification No.60/1/2000- DGAD recommending imposition of Anti -
Dumping Duty on paracetamol from China PR.
(iii) On 27.03.2002, respondent No.1 vide Notification No.29/2002 - Customs (ADD) recommended
the definitive anti-dumping duties in the form of benchmark.
       (iv)         On 25.07.2006,at the end of 5th year on the
 C/SCA/5278/2019                                              JUDGMENTFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

basis of the duly substantiated application filed on behalf of the domestic inquiry, respondent No.2
initiated a 'sunset review' investigation to examine whether the expiry of the duty would lead to
continuation or recurrence of dumping and injury.
(v) On 31.08.2006, respondent No.3 vide its Notification No.87/20067 extended the definitive
Anti-Dumping Duties in terms of Section 9A(5) for a period of one year upto 05.09.2007.
(vi) On 23.07.2007, after conducting a detailed investigation, respondent No.2 issued Final Finding
vide its Notification No. 15/20/2006
- DGAD recommending continuation of Anti- Dumping Duty.
(vii) On 03.07.2007, in pursuance of such recommendation, respondent No.3 issued the
Notification No.99/2007-Customs (ADD) levying Anti-Dumping Duty for a further period of five
years.
(viii) On 28.08.2012, respondent No.2 initiated a sunset view investigation vide Notification
No.14/1009/2012-DGAD to review the need for continued imposition of duties.
(ix) On 19.09.2012, the Anti-Dumping Duty was extended upto 02.09.2013 by respondent No.3 vide
Notification No.42/2012-Customs (ADD).
(x) On 26.08.2013, After due investigation, respondent No.2 issued Final Finding No. 14/1009/2012
- DGAD recommending extension of duties in revised form changing C/SCA/5278/2019
JUDGMENT from benchmark form of duty of fixed form of duty.
(xi) On 28.10.2013, in pursuance of the aforesaid recommendation of respondent No.2, respondent
No.1 issued the Notification No.26/2013-Customs imposing fixed form of Anti-Dumping Duty for a
period of another five years.
(xii) In 2018, the petitioner along with other, again approached respondent No.2 with duly
substantiated application for extension of Anti-Dumping Duty.
(xiii) On 14.05.2018, respondent No.2 provided pre-initiation hearing to petitioner No.1.
(xiv) On 17.05.2018, a detailed written submission was made by the Domestic Industry.
(xv) On 24.05.2018, respondent No.2 initiated the sunset view to review vide Notification
No.07/16/2018-DGAD.
(xvi) On 20.08.2018, respondent No.3 extended the Anti-Dumping Duty for a period of six months
i.e. upto 26.04.2019 vide Notification No.39/2018-Customs (ADD). (xvii) On 29.08.2018,Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

respondent No.2 granted public / oral hearing to all the interested parties.
(xviii) On 07.09.2018, petitioner No.1 filed a detailed written submission.
(xix) On 15.01.2019, respondent No.2 issued Disclosure Statement under the provisions of Rule 16
of the Rules as mentioned in pages starting from page No.187 to 226.
C/SCA/5278/2019 JUDGMENT The relevant extract thereof is reproduced hereinbelow.
27. Submissions made by the interested parties with regard to confidentiality and considered
relevant by the Authority are examined and addressed accordingly. Information provided by the
interested parties on confidential basis was examined with regard to the need for treating them as
confidential. On being satisfied, the Authority has accepted the confidentiality claims of all the
parties and accordingly not disclosed such information to other interested parties. Wherever
possible, parties providing information on confidential basis were directed to provide
non-confidential summary of the information filed on confidential basis. The Authority made
available the non-confidential version of the evidence submitted by various interested parties in the
form of public file.
             H. NORMAL VALUE, EXPORT PRICE                       AND
             DETERMINATION OF DUMPING MARGIN.
             H.1    Views of the Domestic Industry
41. The following are the submissions made by the domestic industry, during the course of present
investigation and considered relevant by the Authority:-
i. China needs to be treated as non-market economy for the reason that the costs and
prices in China do not reasonably reflect the market forces. Para 8 to Annexure - I
specifies the parameters which should be considered for grant of market economy
status. This also implies that unless these conditions are not fulfilled / satisfied, the
Chinese costs and prices cannot be adopted.
ii. Chines produces are required to be treated as companies operating under
non-market economy environment and the Authority may proceed to determine the
normal value on the basis of Para 7 of Annexure - I. iii. The imports are entering the
Indian market at dumped prices.
iv. There is difference in prices in different important transactions which mean that
Chinese producers are selling very same product at a price which differs significantly
even at the same time period and is not a peculiar phenomenon of POI, but extends
to the entire injury period.Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

v. It is a fit case where wighted average normal value cannot be compared with
weighted average export price. The Designated Authority is, therefore,
C/SCA/5278/2019 JUDGMENT requested to compute the weighted average normal
value and compare the same with individual export price and in all those import
transactions where the dumping margin is negative, the same are required to be
excluded for determination of dumping margin.
vi. There can be no plausible reason/justification for such significant difference in the
prices in respect of imports being reported at the same time.
H.2 Views of the interested parties
42. The submissions made by the producers / exporters / importers / other interested parties are as
follows :-
i. Determination of the normal value for subject country in the current investigation
as computed by the domestic industry is not in accordance with the legal provisions
and therefore, the determination of dumping margin in the current investigation by
the petitioners is flawed.
ii. Normal value for the companies in China PR in the current investigation may
please be determined on the basis of their domestic sales and the cost of the subject
goods.
iii. It is in view of the fact that the period of 15 years for disregarding the domestic
prices or costs of Chinese producers not being on market economy conditions as
provided in para 15(a)(ii) of the Protocol of Accession of the People's Republic of
China to WTO, has expired on 11th December 2016 in terms of para 15(d) and has
become non-operational.
iv. At present, no provisions which enable the Hon'ble Authority for considering
Chinese producers as operating on non-market economy principles for disregarding
their domestic prices and costs and the normal value for China may be determined on
the basis of their domestic prices and cost of the subject goods.
v. Any other methodology used for the determination of normal value for Chinese
exporters would be in violation of the obligations of India under the WTO.
vi. Without prejudice to above submission it is submitted that determination of
normal value for Chinese exporters on the basis of their records without following
any additional procedure, domestic industry has arbitrarily determined the normal
value for Chinese exporters without following the due procedure as laid down under
the Indian Anti- Dumping Rules.Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

             vii.    The constructed normal value proposed by
 C/SCA/5278/2019                                            JUDGMENT
the domestic industry is based on the costs of production in India and considering
the rate of profit at 5%. However, the item-wise cost details of the constructed normal
value have not been provided.
viii. The methodology of relying upon the Indian costs and prices is to be followed
only when it was not possible to construct the normal value on the basis of other
alternatives prescribed in the opening sentence of Para 7.
ix. In terms of the provisions of Para 7, the market economy third country is required
to be first identified for determination of normal value and only where it is not
possible to obtain necessary data from such third country, the normal value can be
determined on any other reasonable basis, including the price actually paid or
payable in India for the like product, duly adjusted if necessary, to include a
reasonable profit margin.
x. The domestic industry is under obligation to inform, without reasonable delay the
selection of market economy third country to the parties concerned so as to provide
an opportunity to respond to the same.
xi. Mandatory procedure prescribed by the law has not been followed, as the
interested parties have not been put to notice about selection of the third country.
Nor have the interested patties been requested to suggest and make necessary
information available about the third country.
xii. In the absence of following the mandatory procedure, the present proceeding
cannot continue in view of the decision of the Hon'ble Supreme Court in the case of
Shenyang Matsushita 2005 (181) ELT 320 (SC).
xiii. The failure to follow the mandatory procedure of Para 7 has substantive implications on the
determination of the normal value and resultantly the dumping margin.
Xiv. Therefore, the Hon'ble Authority is requested to follow the procedure prescribed in Para 7 of
the Annexure I in the current investigation.
H.3 Examination b the Authority a. Normal Value in ChinaFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

43. Upon initiation, the Authority advised the producers / exporters in China to respond to the
notice of initiation and provide information relevant to determination of normal value. The
Authority sent copies of the Supplementary questionnaire to all the known producers / exporters for
rebutting C/SCA/5278/2019 JUDGMENT presumption of non-market economy in accordance with
criteria laid down in Para 8(3) of Annexure-I to the AD Rules. The Authority also requested
Government of China to advise the producers / exporters in their country to provide the relevant
information. However, none of the Chinese producers filed any response to the Supplementary
questionnaire issued by the Authority.
44. Accordingly, the normal value and export price for the all the producers / exporters from the
subject country have been determined as below.
a. Determination of Normal Value for producers and exporters in China PR
45. As none of the producers from China PR have filed the Supplementary Questionnaire response,
the normal value has been determined in accordance with Para 7 of Annexure - I of Anti-Dumping
Rules. In the absence of sufficient information on record regarding the other methods as are
enshrined in Para 7 of Annexure I of the AD rules, the Authority has determined the normal value by
adopting the method "any other reasonable basis".
46. The Authority has, therefore, constructed the normal value for China PR on the basis of cost of
production in India duly adjusted, including selling, general and administrative expenses.
Accordingly, the constructed normal value for Chinese exporters is determined Rs.***** per Kg.
b. Determination of export price of China PR
47. The Authority notes that below mentioned exporters from China PR have furnished information
to the Authority, which was used for determination of export price and individual dumping margin.
i. M/s. Anqiu Lu An Pharmaceutical Co., Ltd.
ii. M/s.A.H.A. International Co., Ltd. iii. China Sinopharm International Corporation iv. Zhejiang
Chemcials Import and Export Corporation v. Lianyungang Kangle Pharmaceutical Co., Ltd.
vi. Zhejiang Kangle Pharmaceutical Col.,Ltd.
vii. Hebei Jiheng (group) Pharmaceutical Co. Ltd.
In view of the responses filed, the Authority has analysed the response made by the producers /
exporters as follows:-
C/SCA/5278/2019 JUDGMENT M/s. Anqiu Lu An Pharmaceutical Co., Ltd. (Producer) and
M/s.A.H.A. International Co., Ltd. China Sinopharm International Corporation and Zhejiang
Chemicals Import and Export Corporation.Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

48. The Authority notes that M/s.Anqiu Lu An Pharmaceutical Co., Ltd has exported *** MT of the
subject goods directly to India and *** MT through its traders M/s.A.H.A. International Co., Ltd.
China Sinopharm International Corporation and Zhejiang Chemicals Import and Export
Corporation. The Authority notes that whereas Anqiu Lu An Pharmaceutical Co has reported an
export price of US$*(**/MT and A.H.A. International Co., Ltd., China Sinopharm International
Corporation and Zhejiang Chemicals Import and Export Corporation have reported net export price
of US$***, US$***/MT and US$***/MT respectively.
49. The producers-exporters have claimed price adjustments on account of inland freight, ocean
freight, and marine insurance, credit cost, port expenses and VAT. Ex-factory export price has been
determined for each producer/exporter. Weighted average export price of the said producer and its
respective traders have thereafter been determined as US$***/MT considering the total volume of
exports made by the said exporter.
M/s.Lianyungang Kangle Pharmaceutical Co., Ltd. (producer) and M/s. Zhejiang Kangle
Pharmaceutical Co., Ltd.
50. The Authority notes that M/s.Lianyungang Kangle Pharmaceutical Co., has exported *** MT
through its trader namely M/s. Zhejiang Kangle Pharmaceutical Co., Ltd. They have claimed price
adjustments on account of inland freight, ocean freight, marine insurance, credit cost, port expenses
and VAT. After adjustment of the expenses claimed by the producer / trader, the authority has
determined the ex-factory export price as US$***/MT.
M/s.Hebei Jiheng (group) Pharmaceutical Co. Ltd. (producer)
51. The Authority notes that M/s.Hebei Jiheng (group) Pharmaceutical Co. Ltd have exported ***
MT directly to India. The exporters have claimed price adjustments on account of inland freight,
ocean freight, marine insurance, credit cost, port expenses and VAT. After adjustment of the
expenses claimed by the producer / trader accordingly, the authority has determined the ex-factory
export price as ***US$/MT.
             c.     Determination of Dumping Margin
 C/SCA/5278/2019                                                    JUDGMENT
    Name           of Name      of    the CNV        NEP    Dumping     DM%       Range
    company           company             US$/       US$/   margin
    (Producer)        (Exporter)          MT         MT     US$/MT
    (POI)Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

    M/s.Anqiu Lu An M/s.A.H.A.                 ***    ***      ***        ***      0-10
Pharmaceutical International Co., Co., Ltd. Ltd.
China Sinopharm International Corporation Zhejiang Chemicals Import and Export Corporation
Lianyungang Zhejiang Kangle *** *** *** *** 0-(10) Kangle Pharmaceutical Pharmaceutical Co.,
Ltd.
Co., Ltd.
    Hebei     Jiheng                           ***    ***      ***        ***     10-20
    (group)
    Pharmaceutical
    Co., Ltd.
52. The dumping margin during the POI for all exporters/producers from the subject country has
been determined as provided in the table below:-
Determination of Dumping Margin
a) Comparing the normal value and export price at ex-factory level for the country as
a whole, the dumping margin for the subject country is determined as below:
Particulars US$ / Kg - Rs. / Kg. (POI) US$/Kg Rs./Kg Normal Value *** *** Net
Export Price *** *** Dumping Margin *** *** Dumping Margin % *** *** Range %
10-20 10-20
b) After details analysis of DGCIS transaction wise data it has been observed that out
of total imports of China PR i.e. ***MT***% imports are dumped and ***% are
injuries.
I. INJURY DETERMINATION AND EXAMINATION OF INJURY AND CAUSAL LINK I.3
Examination of the Authority
55. According to Section 9(A) of the Customs Tariff Act, anti-dumping duty imposed shall, unless
revoked earlier, cease to have effect on the expiry of five years from the date of such imposition,
provided C/SCA/5278/2019 JUDGMENT that if the Central Government, in a review, is of the
opinion that the cessation of such duty is likely to lead to continuation or recurrence of dumping and
injury, it may, from time to time, extend the period of such imposition for a further period of five
years and such further period shall commence from the date of order of such extension.
             (i)  Assessment            of    Demand       /   Apparent
             ConsumptionFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

60. The Authority has defined, for the purpose of the present investigation, demand or apparent
consumption of the subject goods in India as the sum of domestic sales of the India producers and
imports from all sources. The demand for the product under consideration is given below:-
Demand Unit 2014-15 2015-16 2016-17 POI Sales of Domestic MT *** *** *** ***
Industry Indexed 100 104 108 108 Sales of other Indian MT *** *** *** *** Producers
Indexed 100 114 108 110 Imports from MT China MT 4,356 1,930 2,205 2,969 Total
Demand 48,251 50,295 49,603 50,770
61. The Authority notes that the demand has shown increase over the injury period, even though it
had marginally declined in 2016-17 as compared to the preceding year. The demand increased once
again in the period of investigation as compared to both the preceding year and base year.
(ii) Volume Effect of Dumped Imports and impact on Domestic Industry:
Import volume and Market Share.
62. With regard to volume of the dumped imports, the Authority is required to consider whether
there has been a significant increase in dumped imports either in absolute terms or relative to
production or consumption in India. The table below summarizes the factual position with regard to
import volumes and market share :-
Particulars Units 2014-15 2015-16 2016-17 POI China MT 4,356 1,930 2,205 2,969
C/SCA/5278/2019 JUDGMENT Total imports MT 4,4,34 2,045 2235 3,034 Market
Share in Demand Sale of Domestic % *** *** *** *** Industry Sale of other Indian %
*** *** *** *** Producers Import from subject % 9% 3.8% 4.44% 5.84% country
Import from other % 0.16% 0.22% 0.06% 0.11% countries Total Demand % 100 100
100 100
63. It is seen that the import volume declined till 2015-16 and increased thereafter. Also, the market
share in demand of the domestic industry has remained more or less constant.
(iii) Price Effect of the Dumped Imports on the Domestic Industry.
a. Price Undercutting
64. With regard to the effect of dumped imports on prices, the Designated Authority is required to
consider whether there has been a significant price undercutting by the dumped imports when
compared with the price of like product in India, or whether the effect of such imports is otherwise
to depress prices to a significant degree or prevent price increase, which otherwise would have
occurred, to a significant degree. In this regard, a comparison has been made between the landed
value of the product and the selling price of the domestic industry net of all rebates and taxes, at theFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

same level of trade. The Authority has compared landed price of imports with the selling price of the
domestic industry for the subject goods.
             Price Undercutting
              Particulars                                    Unit            POI
              Landed price of imports from China Rs./Kg                250.06
              PR
              Net Sales Realization                     Rs./Kg         ***
              Price undercutting                        Rs./Kg         (***)
              Price undercutting                        %              (***)
              Range                                                    (0-10)
From the above, the Authority notes that there is no C/SCA/5278/2019 JUDGMENT price
undercutting.
65. The domestic industry submitted and opposing interested parties have not disputed that the
entirety of the imports were made under advance license and therefore neither customs duty nor
ADD was paid on these imports.
b. Price Suppression / Depression
66. In order to determine whether the dumped imports are suppressing or depressing the domestic
prices and whether the effect of such imports is to suppress prices to a significant degree or prevent
price increases which otherwise would have occurred to a significant degree, the Authority
considered the changes in the costs and prices over the injury period. The position is shown as per
the table below :-
Particulars Units 2014-15 2015-16 2016-17 POI Cost of sales Rs./Kg *** *** *** ***
Trend 100 89 87 99 Selling price Rs./Kg *** *** *** *** Trend 100 93 89 103 Landed
price of Rs./Kg 265 266 238 250 imports Trend 100 102 87 94
67. The Authority notes that whereas the selling price has increased in the POI as compared to the
base year, the cost of sales has marginally declined in POI. The landed value of imports from subject
country has declined in POI as compared to the base year. The Authority notes that the domestic
industry increased its selling price in proportion to increase in cost of sales throughout the injury
period. Therefore, there is no price suppression or depression.
69. Accordingly, various economic parameters of the Domestic Industry are analyzed herein below :-
             a)      Production,      Capacity,                               Capacity
             Utilization and Sales VolumeFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

             70.      Production, sales, capacity                        &     capacity
utilization details are as follows :-
Particulars Units 2014-15 2015-16 2016-17 POI Capacity MT *** *** *** *** Trend
Indexed 100 100 100 100 Production MT *** *** *** *** Trend Indexed 100 103 111
126 C/SCA/5278/2019 JUDGMENT Capacity % *** *** *** *** utilization Domestic
MT *** *** *** *** Sales for PUC
b) Demand
71. From the above information, the Authority notes the following:-
a) Capacity of the domestic industry has remained constant over the period.
b) The production, sales and capacity utilization of the Domestic Industry has
increased over the injury period.
Demand Unit 2014-15 2015-16 2016-17 POI Sales of Domestic MT *** *** *** *** Industry Indexed
100 104 108 108 Sales of other MT *** *** *** *** Indian Producers Indexed 100 114 108 110
Imports from China MT 4,356 1,930 2,205 2,969 Total Demand MT 48,251 50,295 49,603 50,770
c) Market Share in Demand
72. The details of market share of the Domestic Industry in demand are given in table below.
        Particulars              Units 2014-15 2015-16 2016-17                   POI
        Sale of       Domestic    %           ***     ***            ***         ***
        Industry
        Sale of other Indian      %           ***     ***            ***         ***
        Producers
        Import from subject       %        9%        3.8%          4.44%         5.84
        country                                                                   %
        Import from other         %       0.16%      0.22%         0.06%         0.11
        countries                                                                 %
 C/SCA/5278/2019                                                  JUDGMENTFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

74. Performance of the Domestic Industry with regard to profits, return on investment and cash flow
is as follows:-
Particulars Units 2014-15 2015-16 2016-17 POI Profit / (Loss) Rs./Kg. *** *** *** ***
Trend Indexed 100 375 225 325 Cash Profit Rs.Lacs *** *** *** *** Trend Indexed
100 240 165 255 Return on % *** *** *** *** Capital Employed - NFA Trend Indexed
100 173 90 136
75. It is seen from the above table that the profitability, cash profits and return on investments have
increased in the POI when compared to he base year/.
80. The Non-injuries price of the subject goods produced by the domestic industry as determined by
the Authority in terms of Annexure III to the AD Rules has been compared with the landed value of
the exports from the subject country for determination of injury margin during the POI and the
injury margin so worked out is as under.
          SN                  Particular                UOM             China (POI)
           1               Import Volume                    MT             2969
           2              Non Injurious Price          Rs./KG               ***
           3                Landed Price               Rs./KG               ***
           4                Injury Margin              Rs./KG               (***)
           5                Injury Margin                   %               (***)
                      Injury Margin RANGE                                 0-(10)
               J. LIKELIHOOD   OF  CONSTINUATION                         OR
               RECURRENCE OF DUMPING AND INJURY
J.1 Submissions by the Domestic Industry
82. Following are the submissions made by the Domestic Industry with regard to likelihood of
continuation of dumping and consequent recurrence of injury -
i. A perusal of Article 11.1 of AD Agreement and Section 9A(5) of the Customs Tariff Act, clearly
suggests that the main intent behind the legislation of Sunset Review investigation is to examine:-
 C/SCA/5278/2019                                            JUDGMENT
             a)    Whether the dumping continued and if so,
             whether it is likely to continue;
             b)     In case where dumping did not continue,
whether the dumping would recur in the event of revocation of anti-dumping duties;Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

c) Whether the Domestic Industry continued to suffer injury; and if so, whether injury to the
domestic industry is likely to continue;
d) In case where the Domestic Industry has not suffered continued injury, whether injury to the
Domestic Industry is likely to recur in the event of revocation of anti-dumping duties.
ii. The original investigation and the subsequent Sunset Review investigations also established the
existence of significant dumping. The dumping margin in the previous as well as the first SSR was
quite high.
iii. There is a long history of dumping of subject goods from China in domestic market as well as in
other countries such as South Africa and Indonesia.
iv. The continued dumping was only reduced after the last concluded sunset review investigation.
Prior to that, the domestic industry was suffering continued injury on account of significant dumped
imports, as stated by the Authority in the final findings earlier notified in the review cases.
v. The significant level of these imports only started declining since 20151-16. However, it is
pertinent to note that the domestic industry is still healing from the past injuries effects of dumping
and thus is in a vulnerable state. Cessation of anti- dumping duties is likely to cause intensified
injury to the domestic industry.
vi. It would appear that the domestic industry has enjoyed anti-dumping duty protection for the last
15 years, the fact is that the domestic industry has been effectively protected for only last five years.
The Chinese producers continued dumping and the same caused injury to the domestic industry for
one decade, despite the ADD being in force.
vii. The change in the form of duty from benchmark to fixed quantum has led to reduction in
imports. Cessation of anti-dumping duly is likely to increase the imports as significant surplus
capacities are available with the producers. The decline in the imports is because of existence of
ADD.
viii. Due to continuous dumping several plants producing the PRODUCT UNDER
CONSIDERATION have been closed down in the country namely :-
 C/SCA/5278/2019                                            JUDGMENT
             *       M/s.Triton Labratories Ltd.
             *       M/s.Vamsi Labs Ltd.
             *       M/s.Srinivasa Agro Industries & Drugs
                     Ltd.
             *       M/s. Pan Drug
             *       M/s.Alpha DrugFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

             *       M/s.Glaxosmithkline Pharmaceuticals
                     Ltd.
             *       M/s.Thexa Pharma Pvt. Ltd.
             *       M/s.Vani Pharma Labs Ltd.
             *       Rohini Chemical
             *       Fortune Chemical
             *       Dinesh Pharmaceutical
             *       Dr. Jain's Company
             *       Saboo Medichem
             ix.     The     production     of    product    under
consideration is quite limited globally. About 86% of global production is in India and China. 62% of
the production is in China alone, while India commands 24%. Thus, any sickness in this industry
would leave the global demand at the mercy of the Chinese producers.
x. The questionnaire responses filed by the exporters, establish that there is import of subject goods
from subject country at dumped price.
xi. The domestic industry in the present scenario is still reeling from the adverse effects of the
dumping and has shown marginal growth in terms of its economic parameters. The same growth
would be reversed if the Anti-dumping duty is ceased by the Authority.
xii. The only reason the domestic industry has not suffered further deterioration in its performance
is that the volume of imports was low due to the duties in force. However, the producers in the
subject country has significant idle capacities, which are sufficient to meet the entire demand in
India. In the event of cessation of duty, the exports are likely to utilize these unutilized capacities
and flood the Indian market.
xiii. The foreign producers are export oriented, in as much as their capacities are far more than the
domestic demand in the subject country. The production of the subject goods in subject country is in
the range of 1 lacs MT, as against 2.21 lac MT capacities; whereas the domestic demand for the
product in China is far lower nearly 20,000 MT. This clearly shows that the exporters have built up
capacities in excess of the demand in the subject country out of 1 lac MT production, about 80% are
meant for exports.
             xiv.    The exporters have not only been dumping in
 C/SCA/5278/2019                                            JUDGMENTFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

India, but also in other countries. Further, the prices at which the goods have been supplied to these
countries are lower than the non-injuries prices. It is, therefore, reasonable to conclude that the
exporters are likely to sell at dumped and injurious prices in India as well in case the duty is
revoked.
xv. The export price from subject country to various countries globally are far lower than the export
price to India in respect of significant proportion of exports from subject country to various
countries globally. The dumping margin and injury margin in these third countries exports are
higher than the dumping margin and injury margin in respect of exports to India.
xvi. Since India is a more price attractive market as compared to third countries, the exporters
would prefer to divert their goods from other countries to India in case of revocation of duty, in
order to increase their profits and capture the market. Considering that the exporters have no
commitments in these third country markets and the sole criteria for them to price their product is
price received by them.
xvii. Decline in imports post imposition of duty and positive dumping margin in such imports
implies likelihood of dumping in the event of withdrawal of duty and in itself justifies extension of
anti-dumping duty.
J.2 Submission of exporters
83. There is no likelihood of recurrence of injury as per Article 9A(5) of the Customs and Tariffs Act.
i. The petitioners have not given the details of excessive capacity available with the Chinese
producers and their likelihood of being exported to India, the petitioners have failed to make out a
case of likelihood of dumping.
ii. This clearly indicates that there is no likelihood of injury to the domestic industry in the current
investigation and the present investigation deserves termination.
J.3 Examination by the Authority
84. The Authority examined the likelihood of continuation or recurrence of injury considering the
parameters relating to the threat of material injury in terms of Annexure II (vii) of the Anti-dumping
Rules. The domestic industry has submitted the details of exports of China to third countries as per
China customs which shows that ***% volume of exports to third countries are at a price lower than
price at which China exports to India and ***% of the volume C/SCA/5278/2019 JUDGMENT of
exports to third countries are at a price above than price at which China exports to India.
85. The Authority has taken into consideration the submissions made by the domestic industry and
the evidence presented in support of their submissions. The Authority has examined the likelihood
of continuation of recurrence of injury under following heads:Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

a. A significant rate of increase importation; of dumped imports into India indicating
the likelihood of substantially increased importation.
b. Sufficient freely disposable, or an imminent, substantial increase in, capacity of the
exporter indicating the likelihood of substantially increased dumped exports to India
markets, taking into account the availability of other export markets to absorb any
additional exports;
c. Whether imports are entering at prices that will have a significant depressing or
suppressing effect on domestic prices, and would likely increase demand for further
imports; and d. Inventories of the article being investigated.
86 A significant rate of increase of dumped imports into India indicating the likelihood of
substantially increased importation.
              Particulars      Units 2014-15 2015-16 2016-17               POI
              China             MT      4,356     1,930        2205       2969
              Others            MT        79       115           30        65
              Total imports MT          4,434     2,045       2,235      3,034
              *April 17 to Mar 18
              87     The Authority notes that while there was a
consistent decline in the volume of imports compared to base, year.
88. An analysis of transaction wise data of the cooperative producers with their respective exporters
so as to arrive at dumped and injurious imports of the cooperative producer of the present
investigation is as follows:-
a) M/s.Anqiu Lu An Pharmaceutical Co., Ltd.
The total exports to India by the said producer with trader of the subject goods are ***MT out which
***MT are dumped imports and ***MT are injurious imports.
             b)        M/s.            Lianyungang                Kangle
 C/SCA/5278/2019                                                     JUDGMENT
                Pharmaceutical Co., Ltd.Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

Total exports to India by th said producer of the subject goods through its exporters is ***MT out
which dumped imports constitute ***MT. No injurious imports were found for the said producer
through its exporter.
c) M/s.Hebei Jiheng (group) Pharmaceutical Co. Ltd.
Total exports to India by the said producer of the subject goods is ***MT. All imports of the said
producer are dumped and ***MT are injurious.
(b) Sufficient freely disposable, or an imminent, substantial increase in, capacity of the exporter
indicating the likelihood of substantially increased dumped exports to India markets, taking into
account the availability of other export markets to absorb any additional export.
89. The Authority evaluated the existing surplus capacities, capacity addition, if any, with the
responding exporters, possibility of trade diversion from third countries to India, freely disposable
production capacities with the responding exporters. The analysis shows as follows:
a. Capacity, production, surplus capacities, exports to India and rest of the world,
volume of exports to India.
  Name of Producer    Units      Anqiu Lu An        Lianyungang     Hebei Jiheng    Total
                              Pharmaceutical Co.        Kangle         (group)
                                    Ltd.           Pharmaceutical   Pharmaceutic
                                                       Co., Ltd.     al Co., Ltd.
  Capacity             MT            ***                ***               ***         ***
  Production (POI)     MT            ***                ***               ***         ***
  Capacity              %            ***                ***               ***         ***
  utilisation
  Domestic             MT            ***                ***               ***         ***
  Consumption
  Exports to India     MT            ***                ***               ***         ***
  Exports to ROW       MT            ***                ***               ***         ***
  Total Exports        MT            ***                ***               ***         ***
  %          Exports Rang            ***                ***               ***       35-45
  Orientation         e%
                b.      After analysis of the capacities of the
cooperative exporters, the Authority notes that the capacities of the following
non-cooperative exporters/producers as per the data submitted by the petitioner and
the information available in public domain.
 C/SCA/5278/2019                                                 JUDGMENTFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

              S.No                 Producers in China               Capacity (MT
                                                                     per annum)
                   1     Anhui BBCA Likang Pharmaceutical               10000
                   2     Changhu Huagang Pharmaceutical                  8000
                   3    Jiangsu World kindly Pharmaceutical             10000
                   4      Wenzhou Pharmaceuticals factory                6000
                   5    Jiangsu Guoheng Pharma Chemicals                 2500
                                     Co., Ltd.
                   6            Runqi Trading Co., Ltd.                 12000
                   7    Shanghai Bailion Chemicals Col., Ltd.           50000
                                   Pharmaceutical
                   9     Total capacity of non- cooperative             99000
                                       entitles
                   10        Total capacity of cooperative              75000
                                      producers
                   11         Total capacity of China PR                174000
                   12               Indian demand                       51069
              c.    However, it is observed from the analysis of
the cooperating producers that the trading companies do not have their own
production facilities and they quote the capacity of the producers on their websites.
b. Considering the capacity utilisation and export orientation of the responding
producers and evidence provided by the domestic industry, it is evident that there are
surplus capacities in China and the Chinese producers are export oriented.
(C) Inventories of the article being investigated
90. The questionnaire response filed by the Chinese producer's shows that level of inventories with
the cooperative producers / exporters is quite significant.
                  Producer              Units   2015    2016 2017 POI
                  M/s Anqiu Lu An MT            ***     ***      ***      ***
                  Pharmaceutical
                  Co., Ltd.
                  Lianyungang           MT      ***     ***      ***      ***
                  Kangle
                  Pharmaceutical
                  Co., Ltd.
                  Hebei       Jiheng MT         ***     ***      ***      ***
                  (group)
                  Pharmaceutical Co.
                  Ltd.Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

 C/SCA/5278/2019                                                    JUDGMENT
                  Total                  MT      ***     ***        ***      ***
              (D)         Price attractiveness of Indian Market
91. Analysis of the China PR Custom data with regard to export from China PR to the rest of the
world. Indicate that with the revocation of ADD, the Indian prices would be attractive for the
Chinese producers / Exporters to increase their exports to India and the same can be deduced from
the table give below:
              Country                   Quantity       Value          Price
              India (IN)                ***            ***            ***
              Congo, DR                 ***            ***            ***
              Cuba (CU)                 ***            ***            ***
              Kenya (KE)                ***            ***            ***
              Mauritius (MU)            ***            ***            ***
              Indonesia (ID)            ***            ***            ***
              S. Africa (ZA)            ***            ***            ***
              Iraw (IQ)                 ***            ***            ***
              Zambia (ZM)               ***            ***            ***
              Russia (RU)               ***            ***            ***
              Iran (IR)                 ***            ***            ***
              Syrian (SY)               ***            ***            ***
              Benin (BJ)                ***            ***            ***
              Mozambique (MZ)           ***            ***            ***
              United        Arab ***                   ***            ***
              Emirates (AE)
              Tanzania (TZ)             ***            ***            ***
              Lithuania (LT)            ***            ***            ***
              Source : China Custom
92. The Authority notes that ***% total volume of exports to third countries is at a price lower than
the price at which China export to India. Whereas ***% of the total exports are exported are above at
price at which China exports the subject goods to India.
(E) Export Orientation of China PR
93. As per the data of China Customs and other evidence filed by the Domestic Industry, the
Authority notes that the producers in China are oriented toward exports globally.Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

In the event of cessation of ADD, there is probability that the exporters/producers would resort to
dumping of subject goods to India.
C/SCA/5278/2019 JUDGMENT K. CASUAL LINK AND NON ATTRIBUTION ANALYSIS OF
OTHERS KNOWN FACTORS
94. Having examined the existence of continued dumping, volume and price effects of dumped
imports on the prices of the Domestic Industry, other indicative parameters listed under the Indian
Rules and Agreement on Anti-Dumping have been examined herein below by the Authority to see
whether any other factor, other than the dumped imports could have contributed injury to the
Domestic Industry.
(xx) On 21.01.2019, the petitioners have submitted its submissions regarding Disclosure Statement,
which starts from page No.227 to 243. The relevant extract thereof is reproduced hereinbelow.
A. Preliminary submissions
1. The petitioner requests the disclosure of following facts, in order to enable them to come a
meaningful conclusion.
a Copy of the Communications sent by the Authority and copy of the replies filed by the interested
parties. The Authority may kindly make available a copy of all the communications sent via mail or
letter, to the opposing interested party and replies filed by the interested party. The applicant is not
requesting any confidential information. The applicant is requesting only NCV of this information.
b Submissions by interested parties: A copy of all the communications filed by the interested parties.
In case there is anything confidential, petitioner requests non confidential version of the same.
c Copy of the rejoinder submissions: Petitioner requests a copy of the rejoinde submissions filed by
other interested parties. In case there is anything confidential, petitioner requests non confidential
version of the same.
d Verification Report: Petitioner requests a copy of the verification report prepared by the Authority
after due verification visits made for both the domestic industry. In case there is anything
confidential, petitioner requests non confidential version of the same.
e Normal Value: Since it is based on the domestic industry date and information publicaly available/
used. In case there is anything confidential, petitioner requests C/SCA/5278/2019 JUDGMENT non
confidential version of the same.
f NIP breakdown:- showing therein expenses allowed and disallowed for the purpose of NIP
computation, optimization of raw materials, utilities and overhead expenses in case the Designated
Authority found that there were some inefficiencies in the same. This is all the more important, as
(i) it appears that the NIP determined is unduly low, (ii) there appears an assumption with regardFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

utilization of raw materials, utilities and production capacities.
g Actual data in injury assessment:- Since this data pertains to the domestic industry, petitioners
request disclosure of this data to the petitioners on actual basis.
2. The above is vital for the domestic industry to offer their meaningful comments on the disclosure
statement. However, pending such disclosure, the domestic industry hereunder makes following
preliminary submissions to the Disclosure Statement. The domestic industry craves leave to make
further submissions, as and when the above essential facts are disclosed.
B. Emerging essential facts flowing from the Disclosure Statement issued are as follows:
3. Following are the emerging essential facts flowing from the Disclosure Statement. Petitioner
believes that the Authority has concluded the following and is making submissions under this belief.
Further, petitioner is reproducing some of the facts presented by it earlier only as a matter of
reiteration, despite these facts already having been established by the Designated Authority in favor
of a positive final determination.
i Product under Consideration and Like Article: The product under consideration in the present
Sunset Review investigation is Paracetamol and the goods produced by the Domestic Industry and
imported from the subject country are like articles in terms of the Rule 2(d) of the Anti-Dumping
Rules.
ii Standing: M/s Farmson Pharmaceuticals Gujarat Private Limited and M/s Sri Krishna
Pharmaceuticals Limited constitutes "a major proportion of total Indian production"
and hence, satisfies the standing requirements for the subject goos under Rule 2(b)
and Rule 5(3) of the AD Rules.
iii Dumping: The dumping margins are significant for the cooperating exporters /
producer and as well as for the country as a whole , iv Injury/Likelihood of injury: As
regards the likelihood analysis, it is evident that there are surplus capacities in China
and the Chinese producers are export oriented and China is highly export oriented
country and in the event of cessation of ADD, there is probability that the
C/SCA/5278/2019 JUDGMENT exporters/producers would resort to dumping of
subject goods to India v Non attribution analysis: Other known factors are not the
factors contributing to or causing injury to the domestic industry.
C. Information/ submission on which no disclosure of Authority's Examination is
made in the present disclosure statement:-
4. The disclosure statement has not addressed the following submission therefore the Authority is
requested to disclose essential facts on the below mentioned information/submission before issued
the Final Finding:-Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

By Domestic Industry:
i. The production of product under consideration is quite limited globally. As, about
86% of global production is in India and China only and out of which 62% of the
production is in China alone, while India commands the remaining 24%. Thus, any
sickness in this industry would leave the Indian users at the mercy and monopoly of
the Chinese producers.
ii That due to the adverse effect of the insufficient form of duty there were large-scale
production suspension in the country, which was primarily in the last two decades
(all these closures are more than 5 years old and are prior to previous extensions of
ADD).
iii As per 145th Parliamentary standing committee on commerce which assessed the
impact of Chinese goods on Indian industry, it is clearly stated that API sector needs
protection from import and the government of India also endeavors to revive the API
sector in India.
iv Katoch Committee Report dated 24 September, 2015 on Active Pharmaceuticals
Ingredients (APIs) specifically states that a long term strategy for strengthening API
sector by involving Ministry of Commerce as well as other regulator authorities is
required which involved judicious and liberal use of measures like anti-dumping.
v FICCI report February 2018 edition on "Trends and Opportunities for Indian
Pharama" highlights that dependence on China for API supplies exposes the pharma
industry to raw material supply disruptions and price volatility.
vi Office Memorandum dated 18th April, 2018 issued by the Government of India,
Ministry of Chemicals and Fertilizers, Department of Pharmaceuticals, constituted a
Task Force to formulate a road map for enhanced production of APIs in the country
as there is need for concerted efforts to harness the opportunities in pharmaceutical
sector.
C/SCA/5278/2019 JUDGMENT vii The public at large is already well protected
through a regulator mechanism as Paracetamol is covered under National List of
essential medicine in Pharmaceutical Policy, 2015.
viii Paracetamol is one of the cheapest API available in the country.
By other Interested Parties:
i The anti-dumping duties against the import of subject goods are in existence for
more than 17 years and the present case is not a special case where duties are
required to be extended for a further period of 5 years. (Para. 54 ii) ii The majority ofFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

imports to India from subject country are under duty free schemes such as advance
license. DEPB etc. run by the Govt. of India which are not subject to duty.
iii Even if such imports are included for analysis of injury and likelihood of injury and
anti-dumping duty is recommended, the imports made under said duty free schemes
would not be subject to any anti-dumping duty and would continue to come to India.
iv The largest producer of the subject goods i.e. Granules India having sales of Rs.
579 Cores in the period of investigation in India have been abstained from all the 3
sunset review investigations and provided no injury information. Therefore. the
analysis of injury and likelihood of injury on the basis of limited information in all the
3 SSR investigations cannot give the true picture of the state of the domestic industry
and therefore, in the current case. there is no need to extend duty for another period
of five years.
v The Authority while issuing the Final Finding concerning Dry Cell Batteries from China PR (Case
No. 15/2/2011-DGAD & Final Findings dated 20th May 2013) has held that the anti-dumping duties
beyond 10 years be imposed in Special cases only.
5. Petitioner has further following submissions:
D. Scope of Product under Consideration & Like Article
6. With regard to the scope of the product under consideration and like article the Designated
Authority has rightly noted at Para. 13 and 17 of the Disclosure Statement that the product under
consideration (PUC) and like article in the present Sunset Review investigation remains the same as
that of the earlier investigations which is Paracetamol.
7 Paracetamol is also known as "acetaminophen"
C/SCA/5278/2019 JUDGMENT which is classified under Customs sub heading No 29222933 under
chapter 29 of the Customs Tariff Act, 1975 and the same is however indicative only and not binding
on the scope of the present investigation. Designated Authority has also correctly held that the
goods produced by the domestic: industry are comparable to the PUC in terms of physical
characteristics, manufacturing process & technology, functions & uses, product specifications and
tariff classification of the goods. The two are technically and commercially substitutable since they
are being used interchangeably by the consumers. Therefore, the goods produced by the Domestic
industry and imported from the subject country are like articles in terms of the Rule 2(d) of the
Anti-Dumping Rules.
E. Scope of the Domestic Industry & standing
8. With regard to the scope of the Domestic industry & Standing the Designated Authority has
rightly at Para. 23 have noted that the petitioner companies are eligible domestic industry in termsFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

of AD Rules. Further. production of the petitioner companies namely M/s Farmson Pharmaceuticals
Gujarat Private Limited and M/s Sri Krishna Pharmaceuticals Limited constitutes "a majo
proportion of total Indian production" and hence, satisfies the standing requirements for the subject
goods under Rule 2(b) and Rule 5(3) of the AD Rules. it is further submitted that at Para.22 of
Disclosure Statement the Authority has noted that M/s Bharat Chemicals has provided all the
necessary information. However, the Authority has not considered the same as the Designated
Authority considers that the same was filed at belated stage of investigation.
9. It is submitted that the Designated Authority at Para. 22 of the Disclosure Statement have noted
that "in case of Sunset review it would be desirable to have the same composition of domestic
industry as in original investigation". However, it is submitted that there is no legal mandate under
the provisions of Anti-dumping law which states that in all the subsequent investigation there
should be same composition of the domestic industry as of the original investigation.
10. Para. 23 of the Disclosure statement contains confidential figures of the domestic industry
hence, the Authority is requested to make it confidential before issuing the Final finding.
F. Determination of Normal Value Export Price And Dumping Margin Normal Value
11. Para 45 of the Disclosure Statement clearly shows that post initiation Designated Authority has
sent copies of the supplementary questionnaire to all the known producers / exporters and
Government of China for C/SCA/5278/2019 JUDGMENT rebutting presumption of non-market
economy in accordance with criteria laid down in Para8(3) of Annexure-l to the AD Rules. However,
none of the producers / exporter from China PR has filed the Supplementary Questionnaire
response to claim market economy status. Therefore in the absence of sufficient information on
record the Authority has rightly determined the normal value on the basis of cost of production in
India for the like product, duly adjusted, including selling, general and administrative expenses, in
terms of Rule 6(8) of the Rules.
Export Price
12. In the present case, as already submitted that the export price from subject country significantly
differs in terms of time period and therefore it is a fit case where weighted average normal value
cannot be compared with weighted average export price. The Designated Authority was requested to
consider weighted average normal value and compare with individual export price and in all those
import transactions where the dumping margin is negative, the same are required to be excluded for
determination of dumping margin.
13. It is further submitted that the determination of export price by the in the present case is not
consistent with the SOP manual issued which state as follows:
" 12. 23.2 Alternatively, if it is established that the producer has exported through an
unrelated exporter, then take the sale price of the subject goods from producer to first
exporter and adjusted for ex-factory expenses to arrive at NEP. In this case it shouldFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

be unrelated exporter should have made the exports at profits. In case exporter has
posted losses (as verifies from appendix 5&9) then a reasonable profit has to be
deducted for computation of ex factory export price"
14. Therefore in a case like present where the producers have exported the goods through unrelated
trader and where it does not appear a case that the traders have made losses, the export price should
be determined considering the selling price of the producer.
15. Even otherwise, the petitioners submit that the export price reported by the producers should be
rejected and export price reported by the trader/exporter should be adopted only when it is found
that the trader has sold the product at a lower price. As noted in the SOP manual, only in a case
where the traders suffer a loss, the selling price of trader can be adopted. However, if traders earn
profits. the selling price of producer should be adopted.
16. The export price determined is therefore not appropriate.
        Dumping margin
 C/SCA/5278/2019                                           JUDGMENT
17. Designated Authority at Para. 52 (b) has rightly noted that out of total imports of China PR
i.e.*** MT "* % imports are dumped and "" % are injurious. This clearly shows that despite Anti
dumping duty in force. subject goods are being dumped from subject country at significant level.
Hence. there is need for continuation of Anti dumping duty and the Designated Authority is
requested to consider the same.
G. Assessment of injury
18. The Designated Authority has noted at Para 61 of the disclosure statement that the demand of
subject goods has shown increase over the injury period.
19. Designated Authority at Para. 63 has noted that the import volume decline till 2015-16 and
increased thereafter however, it is submitted that there is a declined in the volume of import in
2015-16 and thereafter it increased significantly despite Anti dumping duty in force.
20. With the reference to issues regarding M/s Granules not providing the information in the
present investigation. the petitioner earlier submitted that Granules 'India is undertaking significantFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

exports with some special arrangements with some buyer and therefore its production to that extent
is not even available in the market. The company is not suffering injury to such an extent.
H. Economic Parameters of the domestic industry
21. As per the provisions of the Anti dumping Law unlike original investigation current injury to the
Domestic industry in not required in a sunset review investigation (SSR). SSR are prospective in
nature. as they focus on the likelihood of the continuation or recurrence of dumping and injury, in
case cessation of anti dumping duties. Therefore the Designated Authority is requested to focus on
as to whether the domestic industry is likely to be materially injured again, if duties are lifted.
22. The Designated Authority has noted as follows with regard to various economic parameters:
i At 71 of the Disclosure Statement Designated Authority note the fact that the
production, sales and capacity utilization of the Domestic Industry has increased over
the injury period. This however only shows absence of current injury and in itself
insufficient to hold absence of likelihood.
ii At Para 75 of the Disclosure Statement Designated Authority has noted that
profitability, cash profits and return on investments have increased in the POI when
compared to base year. The Designated C/SCA/5278/2019 JUDGMENT Authority is
requested to consider the fact this improvement is due to anti-dumping duty in force.
Further, this only shows absence of current injury and in itself insufficient to hold
absence of likelihood.
iii At Para 77 of the Disclosure Statement Designated Authority has rightly noted that
the average inventory level of the subject goods has shown an increasing trend.
Injury Margin
23. Without prejudice, it is submitted that injury margin is not germane to likelihood of dumping
and injury analysis. NIP is determined only for the purpose of quantification of duty, and is not
relevant for the determination regarding existence of injury or likelihood thereof. Rule 17(2) to the
Rules also makes it evident that the question of quantum of injury shall arise only when the
Designated Authority finds injury to the domestic industry:-
[(b) recommending the amount of duty which, if levied, would remove the injury
whereapplicable, to the domestic industry after considering the principles laid down
in the Annexure III to these rules] `
24. Similar view has been held by the Hon'ble Court in matter of Nirma Ltd. v. Union of India
2017(358) E.L.T. 146 (Guj) that injury margin and NIP is determined only for the purpose of
quantification of duty, and is not relevant for the determination regarding existence of injury
provided for in Annexure II" to the Anti dumping Rules. 1995. Relevant extract are reproducedFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

below:
"Para. 34 ... It may be noted that injury margin is required to be determined when the
designated authority comes to the conclusion that there is material injury requiring
imposition of anti-dumping duty, whereupon the quantum of anti- dumping duty to
be levied is based upon the injury margin. Therefore,determination of injury margin
would come into play only in case the designated authority comes to the conclusion
that determinative measures are required to be applied. Where the designated
authority comes to the conclusion that no determinative measures are required to be
imposed, as in the present case, the question of determining the injury margin would
not arise.
"Para 34.1" However, for the purpose of rule 16 which requires the designated
authority to disclose the essential facts under consideration which form the basis for
its decision whether or not to apply determinative measure, determination of
non-injurious price is irrelevant, as the same has no relevance so far as determination
of injury is concerned. While the designated authority may compute the
non-injurious price for the purpose of giving the panties an opportunity to make their
comments in respect of such computation at the stage of disclosure statement,
C/SCA/5278/2019 JUDGMENT however, such non-injurious price cannot be taken
into consideration for the purpose of determination of injury. Non-injurious price
having no relevance insofar as determination of injury is concerned, would not form
an essential fact for the purpose of arriving at a decision as to whether or not
determinative measures are required to be applied. It is only after coming to the
conclusion that there is injury necessitating imposition of or continuance of
anti-dumping duty, that the designated authority is required to determine the injury
margin, for which purpose it has to determine the non-injurious price as per the
principles laid down in Annexure Ill to the rules for the purpose of fixing the
quantum of anti-dumping duty to be imposed."
25. It is submitted that the Designated Authority is required to determine injury margin only in
those cases where the Authority finds that the imports are causing injury. However, if the
Designated Authority does not find injury to the domestic industry, like in the present case, the
Designated Authority is not required to and should not determine injury margin. In fact, when there
is no injury, there can be no need for determining injury margin. And, a negative injury margin only
shows that the domestic industry is not suffering current injury. Therefore, in a situation where the
Designated Authority finds absence of injury, the Designated Authority is not required to determine
injury margin and proceeds with the investigation and issue finding based on likelihood analysis.
and confirm the same quantum of ADD, which is required to be done in the present case.
26. In the past also Designated Authority has not modified the quantum of ADD both in MTR and
SSR when the Designated Authority found that the need for continuation/extension is based on
likelihood of injury. Domestic industry refers to the following illustrative cases where the
Designated Authority declined to modify the quantum of ADD and merely extended existing ADD.Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

In some of these cases, the injury margin was found negative in the review investigation period.
         SN NAME OF THE CASE                   INJURY   DUTY
                                                        IMPOSED
         1        Zinc Oxide from China PR No           Continuation
                                           Injury       of   definitive
                                                        anti dumping
                                                        duty
         2        Front Axle Beam' and No          Continuation
"Steering Knuckles from material of definitive China PR injury anti dumping duty 3 Choloroquine
phosphate Zero Continuation from China PR imports of definitive in period anti dumping of duty
C/SCA/5278/2019 JUDGMENT investig ation as well as injury period 4 Diclofenac Sodium from
Negativ Continuation China PR e of definitive dumping anti dumping and duty injury margin in POI
5 Acetone originating in or Negativ Extended the exported from European e Injury Anti dumping
Union, South Africa, duty Singapore and USA 6 Polypropylene from Negativ Continuation
Singapore e Injury of definitive Margin anti dumping duty I. Likelihood of continuation of
Recurrence of Dumping and Injury
27. It is submitted that Article 11.1 of Anti Dumping Agreement and Section 9A (5) of the Customs
Tariff Act, clearly suggests that the main intent behind the legislation of Sunset Review investigation
is to examine:
i Whether the dumping continued and if so, whether it is likely to continue;
ii In case where dumping did not continue, whether the dumping would recur in the
event of revocation of anti-dumping duties;
iii Whether the Domestic Industry continued to suffer injury; and if so, whether
injury to the domestic industry is likely to continue;
iv In case where the Domestic Industry has not suffered continued injury, whether
injury to the Domestic Industry is likely to recur in the event of revocation of
anti-dumping duties.
28. The Authority has examined the likelihood of continuation or recurrence of injury considering
the parameters relating to the threat of material injury in terms of Annexure II (vii) of the
Anti-Dumping Rules at Para. 86-93 of the Disclosure statement.
29. The Designated Authority has noted as follows With regard to likelihood of injury in the present
case i For Cooperating exporter / producer Authority at C/SCA/5278/2019 JUDGMENT Para. 89(d)
has rightly noted that "Considering the capacity utilization and export orientation of the responding
producers and evidence provided by the domestic industry, it is evident that there are surplus
capacities in China and the Chinese producers are export oriented.Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

ii Capacities of the following Non-cooperative exporters/producers: Further at Para. 89(c) the
Authority has noted that on the basis of analysis of the Co- operating producers that the trading
companies do not have their own production facilities and they quote the capacity of the producers
on their websites.
iii Authority at Para. 90 have noted that on the basis of "the questionnaire response filed by the
Chinese producer's shows that level of inventories with the cooperative producers/ exporters is quite
significant.
iv Authority at Para. 91 have noted that "..export' from China PR to the rest of the world indicate
that with the revocation of ADD the Indian prices would be attractive for the Chinese
producers/Exporters to increase their exports to India"
v As rightly noted by the Authority at Para. 93 of the Disclosure statement that "the
producers in China are oriented towards exports globally. In the event of cessation of
ADD there is probability that the exporters/producers would resort to dumping of
subject goods to India".
30. The above disclosure of various parameters clearly indicates that in a situation like present, the
anti dumping duty needs to be extended.
J. Causal link and Non Attribution Analysis of Other Known Factors
31.Under the provisions of law the Designated Authority is required to undertake a non-attribution
analysis, wherein, the authority is required to compulsorily examine other possible factors as listed
under the law. This is akin to "rule out test" wherein a number of parameters listed under the law
are required to be examined to ascertain whether the domestic industry has suffered injury on
account 0t any of these factors. Even if none of the interested parties have pointed to possible
existence of these factors, the authority is obliged to undertake analysis and rule out that the injury
to the domestic industry is not primarily on account of these listed other factors. This is popularly
known as "non- attribution analysis".
32. It is submitted that at Para. 95-100 the Designated Authority has noted that listed known other
factors have not caused injury to the domestic industry and if no other C/SCA/5278/2019
JUDGMENT factor causing injury to the domestic industry has in fact been examined by the
Authority, then, the only inference to be drawn is that dumped imports have caused injury to the
domestic industry.
33. Without prejudice it is submitted that in case of a sunset review, Article 11.3 of the Anti Dumping
Agreement only requires investigating authorities to determine whether the expiry of the duties
would be likely to lead to continuation or recurrence of dumping and injury. Once it has been
established that cessation of duties is likely to cause recurrence or continuation of dumping and
injury to the domestic industry, there is no requirement to establish the existence of a causal link
between the likely dumping and likely injury. As observed by the Appellate Body in the case ofFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

United States Anti-Dumping Measures on Oil Country Tubular Goods (OCTG) from Mexico
[WT/DS282/AB/R], in a review investigation, it is determined whether expiry of duty is likely to
lead to a continuation or recurrence of dumping or injury, and "it is reasonable to assume that,
where dumping and injury continues or recurs. the causal link between dumping and injury,
established in the original investigation, would exist and need not be established anew." "Therefore,
what is essential for an affirmative determination under Article 11.3 is proof of likelihood of
continuation or recurrence of dumping and injury, if the duty expires"
and there is no requirement to establish a causal link between the likely dumping and
the likely injury to the domestic industry.
K. NIP determined is too low leading to insufficient injury margin
34. The non injurious price determined is too low resulting into negative injury margin. The non
injurious price has been reduced on account of number of factors. The domestic industry requests
the authority to kindly consider the followings with regard to Capital Employed.
35. Capital employed should be determined considering present value of fixed assets, or at the least
gross value of fixed assets. in any case, adoption of net fixed assets is highly inappropriate and. in
fact. unfair to the domestic industry, considering that some of the investments are significantly old
and therefore net fixed assets does not represent true value of investments. In fact, the most
appropriate value for the purpose is present value of the investments.
L. Period for which Anti dumping is imposed is not relevant
36. As already submitted by the petitioner that anti dumping duty is required to be imposed so long
as the investigation shows that the cessation of such duty is likely to lead to continuation or
recurrence of dumping and injury. The Act and the Rules do not prescribe any C/SCA/5278/2019
JUDGMENT time limit beyond which the anti dumping duty should not be extended. Section 9A(5)
clearly provides that the anti- dumping duty imposed shall, unless revoked earlier, cease to have
effect on the expiry of five years from the date of such imposition, provided that if the Central
Government, in a review, is of the opinion that cessation of such duty is likely to lead to continuation
or recurrence of dumping and injury, in which case,the Central Govt. may, from time to time extend
the period of such imposition for a further period of five years. Thus, the legal provision clearly is
that the anti dumping duty can be extended further from time to time. if it is found that dumping
and consequent injury to the domestic industry is likely in the event of cessation of anti dumping
duty . Further, there is no requirement under the law that it should be a "special" case as argued by
the other interested parties in view of Final Finding concerning Dry Cell Batteries from China PR
(Case No. 15/2/2011-DGAD & Final Findings dated 20th May 2013), which is not applicable in the
facts and circumstances of the present case.
Illustrative list of cases where Anti-dumping duties have been extended by India beyond 15 years SN
Product Country Duty since Time period Year Days 1 Acrylic Fibre (Still Thailand & 3/31/1997 21 82
in force) Korea 2 Vitamin C (Still in China 3/11/1998 20 87 force) 3 Vitamin E (Still in ChinaFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

12/2/2003 15 14 Force) 4 Sodium Nitrite China 4/6/200 18 80 (Still in force) 5 Nylon Tyre Cord
China 6/30/2004 14 56 Fabric (NTCF) (Still in force) 6 Narrow Woven China 6/9/2004 14 62
Fabrics (Still in Taiwan force) Illustrative list of cases where Anti-dumping duties have been
extended by global authorities even beyond 20-30 years
86. Table below shows statement of cases wherein USA has imposed Anti dumping duty pursuant to
third sunset reviews also. It would be seen that Anti-dumping duties have been in operation in USA
for much longer period.
     SN       Product             Country Duty since           Time period
 C/SCA/5278/2019                                                    JUDGMENT
                                                              Year       Days
     1       Stainless   Steel India            2/21/1995     23         92
             Bar
     2       Sulfanitic Acid     India          3/2/1993      35         90
     3       Pressure            Italy          10/21/1977    41         27
             Sensitive
             Plastic Tape
     4       Prestressed    Japan               12/8/1978     40         14
             Concrete Steel
             Wire
     5       Silico              Ukraine 10/31/1994           24         24
             manganese
     6       Circular Welded Korea              11/2/1992     26         23
             Non-alloy steel
             Pipe
     7       Circular Welded Mexico             11/2/1992     26         23
             Non-alloy steel
             Pipe
     8       Clad Steel Plate Japan             7/2/1996      22         56
     9       Crawfish       Tail China          9/15/1992     26         36
             Meat
     10      Freesh Garlic       China          11/16/1994    24         19
     11      Furfuryl Alcohol China             6/21/1995     23         60
     12      Glycine             China          3/29/1995     23         83
     13      Granular            Italy          8/30/1988     30         41
             Polytetrafluoro
             ethylene Resin
     14      Gray Portland Japan                5/10/1991     27         72Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

             Cement      &
             Clinker
     15      Hammers           & China          2/19/1991     27         93
             Sledges
     16      Helical Spring China               10/19/1993    25         27
             Lock Washer
     17      Helical Spring Taiwan              6/28/1993     25         58
             Lock Washer
     18      Potassium           China          1/31/1984     34         99
             Permanganate
     19      Petroleum Wax China                8/28/19856    32         42
             Candles
     20      Porcelain-on-   China              12/2/1986     32         15
             steel   Cooking
             Ware
     21      Iron                Canada         3/5/1986      32         90
             Construction
             Casting
     22      Iron                China          5/9/1986      32         72
             Construction
 C/SCA/5278/2019                                                     JUDGMENT
              Casting
              Rectangular
              Pipe
87. Canada has extended anti-dumping duties in following cases. It would be seen that some of these
duties are in force for the past 20-25 years.
     Sn       Product             Country        Duty since         Time period
                                                                    Year         Days
              SteelFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

88. Similarly Brazil has also extended anti-dumping duties in following cases beyond 15 years.
       Sn    Product             Country           Duty since
                                                                    Time
                                                                    period
                                                                    Year Day
       1     Sacks and bags Bangladesh             2/10/1992        26      96
             of jute
             cardboard
       3     Garlic, fresh or China                18/1/1196        23      2
             refrigerated
       4     Permanent       China                 8/6/1998         20      47
             magnets ferrite
             rings and discs
       5     Vacuum flasks       China             21/7/1999        19      51
       7     Sacks and bags India                  2/10/1992        26      96
             of jute
             chloride resins
 C/SCA/5278/2019                                          JUDGMENT
89. It is further submitted that Domestic industry is vulnerable to injury from dumped imports at
present. Current levels of import volumes and dumping margins from the subject country clearly
shows that expiry of duty will result in intensified dumping of subject goods from the subject
country. As earlier requested Authority should also consider followings a. Limited production of the
product globally : As earlier submitted petitioner again requests the Authority to consider that the
production of product under consideration is quite limited globally. As, about 86% of global
production is in India and China only and out of which 62% of the production is in China alone,
while India commands the remaining 24%. Thus, any sickness in this industry would |eave the
global demand only at the mercy and monopoly of the Chinese producers.
b. Large scale production suspension in India: As already submitted petitioner again requests the
Authority to consider the fact that due to the adverse effect of the insufficient form of duty there
were large scale production suspension in the country which was primarily in the last two decades
(all these closures are more than 5 years old and are prior to previous extension of ADD), c.Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

Paracetamol formulation prices are covered under DPCO and NPPA therefore no adverse effect on
the consumers The NPPA regulates the prices of Paracetamol formulation and therefore even Iife
the product under consideration is not a formulation, considering that the cost of the product under
consideration forms majority of the cost of Paracetamol formulation, there is an automatic; check on
the prices at which the producers of the product under consideration can sell the product in the
market. The Authority further notes that Paracetamol .is listed under National List of Essential
Medicines and it is one of the cheapest pain killer being most widely used in the Country. Thus,
while the price of both formulation and bulk drug are capped, the producers of Paracetamol have
been selling the product at a price listed to regulated product.
d. Paracetamol is not a high cost medicine and therefore in any case there should be no concern with
regard to possible adverse impact of the ADD on the consumers. In any case, impact of present ADD
on the consumer is miniscule.
e. While the ADD has been in force for more than 15 years, the domestic industry was effectively
protected only for last five years, which period has seen significant growth in the Country and the
domestic industry requires protection for at least another five years, after which the domestic
industry is expected to be fully viable M. Prayer C/SCA/5278/2019 JUDGMENT
37. In the light of the contentions raised. information provided and submissions advanced, the
Authority may be pleased to conclude that i Dumping has continued despite imposition of ADD ii
Dumping is likely to intensity in the event of cessation of ADD.
iii injury to the domestic industry is likely to recur in the event of cessation of ADD.
iv Recommend extension of anti-dumping duties already imposed on the imports of the subject
goods originating in or exported from China PR.
v Fixed form of anti-dumping duty is required to be imposed for a further period of five years
expressed in US/MT.
Submitted please, (A.K. Gupta) For the Domestic Industry (xxi) On 29.01.2019, respondent No.2
issued impugned Final Findings vide Notification F. No. 7/16/2018-DGAD whereby it has decided to
discontinue the Anti-Dumping Duty rejecting / ignoring all the submissions on behalf of the
petitioners. The relevant extract from the Final Findings set out hereinbelow.
C. LIKE ARTICLE C.1 Submissions by the Domestic industry
15. The domestic industry has claimed that there is no known difference in subject goods exported
from subject country and that produced by the Indian industry. Both the products have comparable
characteristics in terms of parameters such as physical & chemical characteristics, manufacturing
process & technology, functions & uses, product specifications and tariff classification etc.
C/SCA/5278/2019 JUDGMENT C.2 Submissions by the exporters/importers/other interested
partiesFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

16. None of the interested patties have disputed the claims made by the domestic industry in this
regard.
C.3 Examination by Authority l7. The Authority notes from the information available on record that
the product under consideration produced by the Domestic Industry is like article to the goods
imported from the subject country. Product under consideration produced by the Domestic Industry
and imported from the subject country are comparable in terms of physical characteristics,
manufacturing process & technology, functions & uses, product specifications and tariff
classification of the goods. It is further noted that the Designated Authority had examined the issue
of product under consideration and like article in the previous investigations, which mutatis
mutandis is relied upon in the present review investigation. The goods produced by the Domestic
Industry and imported from the subject country are like articles in terms of the Rule 2(d) of the
Anti-Dumping Rules. The two are technically and commercially substitutable. The consumers are
using the two interchangeably.
E. ISSUES RELATING TO CONFIDENTIALLY E.1 Submissions by the Domestic industry
24. The domestic industry has made the following submissions:-
i. The exporter/producers have made unnecessary claims as to confidentially or
provided incomplete information thereby handicapping the domestic industry in
making meaningful comments with regard to the responses filed. The responses me
not properly indexed or summarized.
ii. Information provided in non-confidential version is beyond understanding. The
NCV does not provide clear understanding of the data and the domestic industry is
unable to provide detailed comments on that for the same reason.
iii. Non - confidential version of the questionnaire responses is grossly inadequate
incomplete. The concerned interested party has not disclosed all such information
that they are obligated to disclose under the Rules and practice being followed by the
Designated Authority in this regard.
E.2 Submissions by the exporters/importers/other interested parties
25. The exporters/importers/other interested parties C/SCA/5278/2019 JUDGMENT have made
the following submissions:
a. The petitioners have claimed excessive confidentiality without providing any
legitimate reasons in violation of Rule 7 of the Customs and Tariffs Rules, 1995. The
Petitioners ave not disclosed the following information in their petition:-
b. Soft Copy in excel file of transaction-wise and sorted import data, raw/original
import data and list of excluded transactions from DGCI&S has not been provided.Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

c. The import data has not been provided for the whole POI and has been provided
only for the 9 months.
d. The item-wise details of constructed normal value have been kept as confidential,
e. Company-wise production details of the petitioners, supporting producers and the
domestic producers have been kept as confidential.
f. The annual repent 0f the companies for the P01 and the previous three years have
not been provided. The domestic industry has simply stated that the same may be
seen from the website of the petitioners. However, it may be seen that there are no
annual reports available on the website of the petitioners.
g. In the application, it has been mentioned that Sri Krishna Pharmaceuticals Ltd.
has imported the subject goods. However,the reasons have not been provided by the
domestic industry.
h. The domestic industry has claimed adjustment from export price for ocean freight,
marine insurance, port expenses, bank charges, inland transportation, commission
and VAT adjustment. However, no evidence with regard to the aforesaid adjustments
claimed have been provided by the domestic industry i. Profit/loss and ROCE in
percentage terms have been kept confidential, j. The Hon'ble Authority may kindly
direct the petitioners to disclose and provide the aforesaid information so as to
enable the exporters / producers for making effective comments in this
investigation..
E.3 Examination by the Authority
26. With regard to confidentiality of information, Rule 7 of Anti-dumping Rules provides as follows:
"7. Confidential informations:-
(1) Notwithstanding anything contained in sub rules (2), (3) and (7) of rule 6,
sub-rule (2) of 12, sub-rule (4) of rule 15 and sub-rule (4) of rule 17, the copies of
applications C/SCA/5278/2019 JUDGMENT received under sub-rule (1) of rule 5, or
any other information provided to the designated authority on a confidential basis by
any party in the course of investigation, shall, upon the designated authority being
satisfied as to its confidentiality, be treated as such by it and no such information
shall be disclosed to any other party without specific authorization of the party
providing such information.
(2) The designated authority may require the parties providing information on confidential basis to
furnish non-confidential summary thereof and If in the opinion of a party providing such
information, such information is not susceptible of summary, such party may submit to the
designated authority a statement of reasons why summarization is not possible.Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

(3) Notwithstanding anything contained in sub-rule (2), if the designated authority is satisfied that
the request for confidentiality is not warranted or the supplier of the information is either unwilling
to make the information public or to authorize its disclosure in a generalized or summary form, it
may disregard such information.
"
27. Submissions made by the interested parties with regard to confidentiality and considered
relevant by the Authority are examined and addressed accordingly. Information provided by the
interested parties on confidential basis was examined with regard to the need for treating them as
confidential. On being satisfied, the Authority has accepted the confidentiality claims of all the
patties and accordingly not disclosed such information to other interested patties. Wherever
possible, patties providing information on confidential basis were directed to provide
non-confidential summary of the information filed on confidential basis. The Authority made
available the non-confidential version of the evidence submitted by various interested parties in the
form of public file.
G. NORMAL VALUE EXPORT PRICE AND DETERMINATION OF DUMPING MARGIN
39. The Authority sent questionnaire to known exporters from subject country, advising them to
provide information in the form and manner prescribed. The following producers and exporters
front the subject country tiled the questionnaire response:
i. M/s Anqiu Lu An Pharmaceutical Co., Ltd. ii. M/s A.H.A lntemational Co., Ltd.
iii China Sinophamt International Corporation iv. Zhejiang Chemicals Import and
Export Corporation.
v. Lianyungang Kangle Pharmaceutical Co., Ltd. vi. Zhejiang Kangle Pharmaceutical
Co., Ltd. vii. Hebei Jiheng (group) Pharmaceutical Co. Ltd.
C/SCA/5278/2019 JUDGMENT
40. According to Section 9A (1) (c) of the Customs Tariff Act, 1975 'Normal Value' in
relation to an article means:-
"comparable price, in the ordinary course of trade. for the like article when meant for
consumption in the exporting county or territory as determined in accordance with
the rules made under sub-section (6); or when there are no sales of the like article in
the ordinary course 0ftrade in the domestic market of the exporting country or
territory, or when because of the particular market situation or low volume of the
sales in the domestic market of the exporting country or territory such sales do not
permit a proper comparison. the normal value shall be either-Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

(a) comparable representative price of the like article when exported from the
exporting country or territory or an appropriate third country as determined in
accordance with the rules made under sub-section (6); or The cost of production 0f
the said article in the country of origin along with reasonable addition for
administrative, selling and general costs, and for profits, as determined in accordance
with the rules made under sub-section (6)-:
Provided that in the case of import of the article from a country other than the
country of origin and where the article has been merely transhipped through the
country of export or such article is not produced in the country of export or there is
no comparable price in the country of export, the normal value shall be determined
with reference to its price in the country of origin.
G.1 Views of the Domestic industry
41. The following are the submissions made by the domestic industry, during the
course of present investigation and considered relevant by the Authority:-
i China needs to be treated as non-market economy for the reason that the costs and
prices in China do not reasonably reheat the market forces. Para 8 to Annexure-I
specifies the parameters which should be considered for grant of market economy
status. This also implies that unless these conditions are not fulfilled/satisfied, the
Chinese costs and prices cannot be adopted.
ii. Chinese producers are required to be treated as companies operating under
non-market economy environment and the Authority may proceed to determine the
normal value on the basis of Para 7 of Annexure-I. iii. The imports are entering the
Indian market at dumped prices.
iv. There is difference in prices in different import C/SCA/5278/2019 JUDGMENT
transactions which mean that Chinese producers are selling very same product at a
price which differs significantly even at the same time period and is not a peculiar
phenomenon of POI, but extends to the entire injury period, v. It is a fit case where
weighted average normal value cannot be compared wit weighted average export
price. The Designated Authority is, therefore, requested to compute the weighted
average normal value and compare the same with individual export price and in all
those import transactions where the dumping margin is negative, the same are
required to be excluded for determination of dumping margin.
vi. There can be no plausible reason / justification for such significant difference in
the prices in respect of imports being reported at the same time.
G.2 Views of the interested partiesFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

42. The submissions made by the producers/exporters/importers/other interested
parties are as follows:-
i. Determination of the normal value for subject country in the current investigation
as computed by the domestic industry is not in accordance with the legal provisions
and therefore, the determination of dumping margin in the current investigation by
the petitioners is flawed.
ii. Normal value for the companies in China PR in the current investigation may
please be determined on the basis of their domestic sales and the cost of the subject
goods.
iii. It is in view of the fact that the period of 15 years for disregarding the domestic
prices or costs of Chinese producers not being on market economy conditions as
provided in para 15(a) (ii) of the Protocol of Accession of the People's Republic of
China to WTO, has expired on 11th December 2016 in terms of para 15
(d) and has become non-operational.
iv. At present, no provisions which enable the Hon'ble Authority for considering Chinese producers
as operating on non-market economy principles for disregarding their domestic prices and costs and
the normal value for China may be determined on the basis of their domestic prices and cost of the
subject goods.
v. Any other methodology used for the determination of normal value for Chines exporters would be
in violation of the obligations of India under the WTO.
vi. Without prejudice to above submission it is submitted C/SCA/5278/2019 JUDGMENT that
determination of normal value for Chinese exporters on the basis of their records without following
any additional procedure, domestic industry has arbitrarily determined the normal value for
Chinese exporters without following the due procedure as laid down under the Indian Anti-dumping
Rules.
vii. The constructed normal value proposed by the domestic industry is based on the cost of
production in India and considering the rate of profit at 5%. However, the item-wise cost details of
the constructed normal value have not been provided.
viii. The methodology of relying upon the Indian costs and prices is to be followed only when it was
not possible to construct the normal value on the basis of other alternatives prescribed in the
opening sentence of Para 7.
ix. In terms of the provisions of Para 7, the market economy third country is required to be first
identified for determination of normal value and only where it is not possible to obtain necessary
data from such third country, the normal value can be determined on any other reasonable basis,Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

including the price actually paid or payable in India for the like product, duly adjusted if necessary,
to include a reasonable profit margin.
x. The domestic industry is under obligation to inform, without reasonable delay the selection of
market economy third country to the parties concerned so as to provide an opportunity to respond
to the same.
xi. Mandatory procedure prescribed by the law has not been followed, as the interested parties have
not been put to notice about selection of the third country. Nor have the interested parties been
requested to suggest and make necessary information available about the third country.
xii. In the absence of following the mandatory procedure, the present proceeding cannot continue in
view of the decision of the Hon'ble Supreme Court in the case of Shenyang Matsushita 2005 (181)
ELT 320 (SC).
xiii. The failure to follow the mandatory procedure of Para 7 has substantive implications on the
determination of the normal value and resultantly the dumping margin.
xiv. Therefore, the Hon'ble Authority is requested to follow the procedure prescribed in Para 7 of the
Annexure I in the current investigation.
G.3 Examination by the Authority a. Normal Value in China
43. Upon initiation, the Authority advised the producers/exporters in China to respond to the notice
of C/SCA/5278/2019 JUDGMENT initiation and provide information relevant to determination of
normal value. The Authority sent copies of the Supplementary questionnaire to all the known
producers/ exporters for rebutting presumption of nonmarket economy in accordance with criteria
laid down in Para 8(3) of Annexure-I to the AD Rules. The Authority also requested Government of
China to advise the producers/exporters in their country to provide the relevant information.
However, none of the Chinese producers filed any response to the Supplementary questionnaire
issued by the Authority.
44. Accordingly, the normal value and export price for all the producers/exporters from the subject
country have been determined as below:
b .Determination of Normal Value for producers and exporters in China PR
45. As none of the producers from China PR have filed the Supplementary Questionnaire response,
the normal value has been determined in accordance with Para 7 of Annexure I of Anti-Dumping
Rules. In the absence of sufficient information on record regarding the other methods as are
enshrined in Para 7 of Annexure I of the AD rules, the Authority has determined the normal value by
adopting the method "any other reasonable basis".Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

46. The Authority has, therefore, constructed the normal value for China PR on the basis of cost of
production in India, duly adjusted, including selling, general and administrative expenses
Accordingly, the constructed normal value for Chinese exporters is determined Rs. ***** per Kg.
c. Determination of export price of China PR
47. The Authority notes that exporters mentioned below from China PR have furnished information
to the Authority, which was used for determination of export price and individual dumping margin.
i. M/s Anqiu Lu An Pharmaceutical Co., Ltd.
ii. M/s A.H.A international Co., Ltd.
iii. China Sinopharm international Corporation iv. Zhejiang Chemicals Import and Export
Corporation v. Lianyungang Kangle Pharmaceutical Co., Ltd.
vi. Zhejiang Kanglc Pharmaceutical Co., Ltd.
vii. Hebei Jiheng (group) Pharmaceutical Co. Ltd.
In view of the responses filed, the Authority has analysed C/SCA/5278/2019 JUDGMENT the
response made by the producers /exporters as follows:
M/s Anqiu Lu An Pharmaceutical Co. Ltd. (Producer) and M/s A.H.A International
Co. Ltd . China Sinopharm International Corporation and Zhejiang Chemicals Import
and Export Corporation
48. The Authority notes that M/s Anqiu Lu An Pharmaceutical Co., Ltd. has exported *** MT of the
subject goods directly to India and *** MT through it traders M/s A.H.A International Co., Ltd.,
China Sinopharm International Corporation and Zhejiang Chemicals Import and Export
Corporation. The Authority notes that whereas Anqiu Lu An Pharmaceutical Co has reported an
export price of US$ ***/MT and A.H.A international Co., Ltd., China Sinopharm International
Corporation and Zhejiang Chemicals Import and Export Corporation have reported net export price
of US$ ***, US$ ***/MT and US$***/MT respectively.
49. The producers-exporters have claimed price adjustments on account of inland freight, ocean
freight, and marine insurance, credit cost, port expenses and VAT. Ex-factory export price has been
determined for each producer/exporter. Weighted average export price of the said producer and its
respective traders have thereafter been determined as US$ *** /MT considering the total volume of
exports made by the said exporter.
M/s Lianyungang Kangle Pharmaceutical Co., Ltd.
(produder) and M/s Zhejiang Kangle Pharmaceutical Co., Ltd.Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

50. The Authority notes that M/s Lianyungang Kangle Pharmaceutical Co. has exported *** MT
through its trader namely M/s Zhejiang Kangle Phannaceutical Co., Ltd. They have claimed price
adjustments on account of inland freight, ocean freight, marine insurance, credit cost, port expenses
and VAT. After adjustment of the expenses claimed by the producer/trader, the authority has
determined the ex-factory export price as US$ *** /MT.
M/s Hebei Jiheng (group) Pharmaceutical Co. Ltd.. producer
51. The Authority notes that M/s Hebei Jiheng (group) Pharmaceutical Co. Ltd have exported ***
MT directly to India. The exporters have claimed price adjustments on account of inland freight,
ocean freight, marine insurance, credit cost, port expenses and VAT. After adjustment of the
expenses claimed by the producer/trader accordingly, the authority has determined the ex factory
export price as **** USS/MT.
         d.   Determination of Dumping Margin
 C/SCA/5278/2019                                                  JUDGMENT
         The dumping margin during the POI              for all
exporters/producers from the subject country has been determined as provided in the table below:
Name of Name of the CNV NEP Dumping DM Range company Company US$/ US$/
margin % (producer) (Exporter) MT MT US$/MT (POI) M/s. Anqiu Lu An M/s.
A.H.A. *** *** *** *** 0-10 Pharmaceutical International Co., Co. Ltd. Ltd.
---------------------
China Sinopharm International Corporation
---------------------
                  Zhejiang
                  Chemicals Import
                  and              Export
                  Corporation
 Lianyungang         Zhejiang Kangle ***        ***      ***            ***   0-(10)
 Kangle              Pharmaceutical
 Pharmaceutical      Co. Ltd.Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

 Co., Ltd.
 Hebei    Jiheng                         ***    ***      ***            ***   10-20
 (group)
 pharmaceutical
 Co. Ltd.
   e.     Determination of Dumping Margin for China PR
   as a whole.
   a)        Comparing the normal value and export price at ex-
factory level for the country as a whole, the dumping margin for the subject country is determined as
below:
Particulars US$/Kg-Rs./Kg. (POI) US$/Kg Rs./Kg Normal Value *** *** Net Export
Price *** *** Dumping Margin *** *** Dumping Margin % *** *** Range% 10-20
10-20
b) After detailed analysis of DGCIS transaction wise date it has been observed that
our of total imports of China PR i.e. ***MT ***% imports are dumped and ***% are
injurious.
Para H. INJURY DETERMINATION AND EXAMINATION OF INJURY AND CASUAL LINK (II)
Volume Effect of Dumped Imports and impact on Domestic Industry:
Import volume and Market Share.
62. With regard to volume of the dumped imports, the Authority is required to
consider whether C/SCA/5278/2019 JUDGMENT there has been a significant
increase in dumped import either in absolute terms or relative to production or
consumption in India. The table below summarizes the factual position with regard
to import volumes and market share-:
Particulars Unites 2014-15 2015-16 2016-17 POI China MT 4,356 1,930 2205 2,969
Total imports MT 4,434 2,045 2235 3034 Market Share in Demand Sale of % *** ***
*** *** Domestic Industry Sale of other % *** *** *** *** Indian Producers Import
from % 9% 3.8% 4.44% 5.84 subject country % Import from % 0.16% 0.22% 0.06%
0.11 other countries %
63. It is seen that the import volume declined till 2015-16 and increased thereafter.
Also, the market share in demand of the domestic industry has remained more or less
constant.
70. Production, sales, capacity & capacity utilization details are as follows:-Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

Particulars Unit 2014-15 2015-16 2016-17 POI Capacity MT *** *** *** ***
Production MT *** *** *** *** Capacity % *** *** *** *** Utilization Domestic MT
*** *** *** *** Sales for PUC From the above information, the Authority notes the
following:-
a) Capacity of the domestic industry has remained C/SCA/5278/2019 JUDGMENT
constant over the period.
b) The production, sales and capacity utilization of the Domestic Industry has
increased over the injury period.
    b)        Demand
     Demand           Unit     2014-15        2015-16     2016-17 POI
     Sales          of MT      ***            ***         ***         ***
     Domestic
     Industry
     Indexed                   100            104         108         108
     Sales of Other MT         ***            ***         ***         ***
     Indian
     Producers
     Indexed                   100            114         108         110
     Imports from
     China            MT       4,356          1,930       2205        296
     Total            MT       48,251         50,295      49,603      50,7
71. From the above information it is noted that
i) Sales of DI and other Indian producers have increased from the base year.
ii) Imports from China PR and others countries have declined from the base year despite increase in
total demand during the same period.
c) Market Share in Demand
72. The details of market share of the Domestic Industry in demand are given in table below.
Particulars Unit 2014- 2015 2016- POI 15 -16 17 Sales of Domestic Industry % *** *** *** *** Sale of
other Indian Producers % *** *** *** *** Import from subject country % 9% 3.8% 4.44% 5.84%
Import from other countries % 0.16% 0.22 0.06% 0.11% %
73. It is seen that the market share of Domestic Industry has marginally increased over the injury
period.Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

a. Probability, return on investment and cash profits C/SCA/5278/2019 JUDGMENT
74. Performance of the Domestic Industry with regard to profits, return on investment and cash flow
is as follows:-
Particulars Unit 2014-15 2015-16 2016-17 POI Profit/ (Loss) Rs./Kg. *** *** *** ***
Cash Profit Rs. Lacs *** *** *** *** Return on Capital % *** *** *** ***
Employed-NFA Para J.
82.
J.1 Submissions by the Domestic Industry
82. Following are the submissions made by the Domestic Industry with regard to likelihood of
continuation of dumping and consequent recurrence of injury-
i. A perusal of Article 11.1 of AD Agreement and Section 9A (5) of the Customs Tariff Act, clearly
suggests that the main intent behind the legislation of Sunset Review investigation is to examine:-
a) Whether the dumping continued and if so, whether it is likely to continue;
b) In case where dumping did not continue, whether the dumping would recur in the
event of revocation of anti-
dumping duties;
c) Whether the Domestic Industry continued to suffer injury; and if so, whether injury to the
domestic industry is likely to continue;
(d) In case where the Domestic Industry has not suffered continued injury, whether injury to the
Domestic Industry is likely to recur in the event of revocation of anti- dumping duties.
ii. The original investigation and the subsequent Sunset Review investigations also established the
existence of significant dumping. The dumping margin in the previous as well as the first SSR was
quite high.
iii. There is a long history of dumping of subject goods from China in domestic market as well as in
other countries such as South Africa and Indonesia.
iv. The continued dumping was only reduced after the last concluded sunset review investigation.
Prior to that, the domestic industry was suffering continued injury on account of significant dumped
imports, as stated by the C/SCA/5278/2019 JUDGMENT Authority in the final findings earlier
notified in the review cases.Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

v. The significant level of these imports only started declining since 2015-16. However, it is pertinent
to note that the domestic industry is still healing from the past injurious effects of dumping and thus
is in a vulnerable state. Cessation of anti-dumping duties is likely to cause intensified injury to the
domestic industry.
vi. It would appear that the domestic industry has enjoyed anti-dumping duty protection for the last
15 years, the fact is that the domestic industry has been effectively protected for only last the years.
The Chinese producers continued dumping and the same caused injury to the domestic industry for
one decade, despite the ADD being in force.
vii. The change in the form of duty from benchmark to fixed quantum has led to reduction in
imports. Cessation of anti-dumping duty is likely to increase the imports as significant surplus
capacities are available with the producers. The decline in the imports is because of existence of
ADD.
viii. Due to continuous dumping, several plants producing the PRODUCT UNDER
CONSIDERATION have been closed down in the country namely:
M/s Triton Labratories Ltd.
M/s Vamsi Labs Ltd.
M/s Srinivasa Agro Industries & Drugs Ltd.
M/s Pan Drug M/s Alpha Drug M/s Glaxosmithkline Pharmaceuticals Ltd.
M/s Thexa Pharma Pvt. Ltd.
M/s Vani Pharma Labs Ltd.
Rohini Chemical Fortune Chemical Dinesh Pharmaceutical Dr. Jain's Company
Saboo Medichem ix. The production of product under consideration is quite limited
globally. About 86% of global production is in India and China. 62% of the
production is in China alone, while India commands 24%. Thus, any sickness in
C/SCA/5278/2019 JUDGMENT this industry would leave the global demand at the
mercy of the Chinese producers.
x. The questionnaire responses filed by the exporters, establish that there is import of
subject goods from subject country at dumped price.
xi. The domestic industry in the present scenario is still reeling from the adverse
effects of the dumping and has shown marginal growth in terms of its economic
parameters. The same growth would be reversed if the Anti dumping duty is ceased
by the Authority.Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

xii. The only reason the domestic industry has not suffered further deterioration in its
performance is that the volume of imports was low due to the duties in force.
However, the producers in the subject country have significant` idle capacities, which
are sufficient to meet the entire demand in India. In the event of cessation of duty,
the exports are likely to utilize these unutilized capacities and flood the Indian
market.
xiii. The foreign producers are export oriented. in as much as their capacities are far
more than the domestic demand in the subject country. The production of the subject
goods in subject country is in the range of l lac MT, as against 2.21 lac MT capacities;
whereas the domestic demand for the product in China is far lower nearly 20,000
MT. This clearly shows that the exporters have built up capacities in excess of the
demand in the subject country out of 1 lac MT production, about 80% are meant for
exports.
xiv. The exporters have not only been dumping in India, but also in other countries.
Further, the prices at which the goods have been supplied to these countries are
lower than the non-injurious price. It is therefore, reasonable to conclude that the
exporters are likely to sell at dumped and injurious prices in India as well in case the
duty is revoked.
xv. The export price from subject country to various countries globally are far lower
than the export price to India in respect of significant proportion of exports from
subject country to various countries globally. The dumping margin and injury margin
in these third countries exports are higher than the dumping margin and injury
margin in respect of exports to India.
xvi. Since India is a more price attractive market as compared to third countries, the
exporters would prefer to divert their goods from other countries to India in case of
revocation of duty, in order to increase their profits and capture the market.
Considering that the exporters have no commitments in these third country markets
and the sole criteria for them to price their product is price received by them.
C/SCA/5278/2019 JUDGMENT xvii. Decline in imports post imposition of duty and
positive dumping margin in such imports implies likelihood of dumping in the event
of withdrawal of duty and in itself justifies extension of anti-dumping duty.
J.2 Submission of exporters
83. There is no likelihood of recurrence of injury as per Article 9A (5) of the Customs and Tariffs Act.
i. The petitioners have not given the details of excessive capacity available with the Chinese
producers and their likelihood of being exported to India, the petitioners have failed to make out a
case of likelihood of dumping.Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

ii. This clearly indicates that there is no likelihood of injury to the domestic industry in the current
investigation and the present investigation deserves termination.
J.3 Examination by the Authority
84. The Authority examined the likelihood of continuation or recurrence of injury considering the
parameters relating to the threat of material injury in terms of Annexure II (vii) of the Anti-dumping
Rules. The domestic industry has submitted the details of exports of China to third countries as per
China customs which shows that ***% volume of exports to third countries are at a price lower than
price at which China exports to India and ***% of the volume of exports to third countries are at a
price above than price at which China exports to India.
85. The Authority has taken into consideration the submissions made by the domestic industry and
the evidence presented in support of their submissions. The Authority has examined the likelihood
of continuation or recurrence of injury under following heads:
a. A significant rate of increase importation; of dumped imports into India indicating
the likelihood of substantially increased importation.
b. Sufficient freely disposable, or an imminent, substantial increase in, capacity of the
exporter indicating the likelihood of substantially increased dumped exports to
Indian markets, taking into account the availability of other export markets to absorb
any additional exports;
c. Whether imports are entering at prices that will have a significant depressing or
suppressing effect on domestic prices, and would likely increase demand for further
imports; and d. Inventories of the article being investigated.
C/SCA/5278/2019 JUDGMENT
86. A significant rate of increase of dumped imports into India indicating the
likelihood of Substantially increased importation.
Particulars Units 2014-15 2015-16 2016-17 POI China MT 4356 1930 2205 2969 Total Imports MT
4434 2045 2235 3034 * April 17 to March 18
87. The Authority notes that there was a consistent decline in the volume of imports compared to
base year.
88. An analysis of transaction wise date of the cooperative producers with their respective exporters
so as to arrive at dumped and injurious imports of the cooperative producer of the present
investigation is as follows:-
a) M/s Anqiu Lu An Pharmaceutical Co., Ltd.Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

The total exports to India by the said producer with trade of the subject goods are *** MT out which
*** MT are dumped imports and *** MT are injurious imports.
b) M/s Lianyungang Kangle Pharmaceutical Co. Ltd.
Total exports to India by the said producer of the subject goods through its exporters is *** MT out
which dumped imports constitute *** MT. No injurious imports were found for the said producer
through its exporter.
c) M/s Hebei Jiheng (group) Pharmaceutical Co. Ltd.
Total exports to India by the said producer with trader of the subject goods is *** MT . All imports of
the said producer are dumped and ***MT are injurious.
(b) Sufficient freely disposable, or an imminent, substantial increase in, capacity of the exporter
indicating the likelihood of substantially increased dumped exports to Indian markets, taking into
account the availability of other export markets to absorb any additional exports.
89. The Authority evaluated the existing surplus capacities, capacity addition, if any, with the
responding exporters, possibility of trade diversion from third countries to India, freely disposable
production capacities with the responding exporters. The analysis shows as follows:
C/SCA/5278/2019 JUDGMENT a. Capacity, production, surplus capacities, exports to India and
rest of the world volume of exports to India Name of Unit Anqiu Lu An Lianyungka Hebei Tota
Producer s Pharmaceutic ng Kangle Jiheng l al Co., Ltd. Pharmaceut (group) ical Co., Pharmace Ltd.
utical Co.
Ltd.
    Capacity      MT   ***                    ***            ***               ***
    Productio     MT   ***                    ***            ***               ***
    n (POI)
    Capacity %         ***                    ***            ***               ***
    utilization
    Domestic MT        ***                    ***            ***               ***
    Consumpt
    ion
    Exports to MT      ***                    ***            ***               ***
    India
    Exports to MT      ***                    ***            ***               ***
    ROW
    Total         MT   ***                    ***            ***               ***
    Exports
    % Exports Rag ***                         ***            ***               35-
    nFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

b. After analysis of the capacities of the co-operative exporters, the Authority notes that the
capacities of the following non-cooperative exporters/producers as per the date submitted by the
petitioner and the information available in public domain.
         S. No.    Producers in China                       Capacity
                                                            (MT    per
                                                            annum)
         1.        Anhui       BBCA                  Likang 10,000
                   Pharmaceutical
         2.        Changshu                         Huagang 8000
                   Pharmaceutical
         3.        Jiangsu      World                 kindly 10000
                   Pharmaceutical
4. Wenzhou Pharmaceuticals factory 6000
5. Jiangsu Guoheng Pharma 2,500 Chemicals Co. Ltd.
6. Runqui trading Co. Ltd. 12,000
7. Shanghai Bailion Chemicals Co. 50,000 Ltd.
8. Lianoyuan City Banking 500 C/SCA/5278/2019 JUDGMENT Pharmaceutical
9. Total capacity of non-co-operative 99,000 entitites
10. Total capacity of co-operative 75,000 producers
11. Total capacity of China PR 174,000
12. Indian Demand 51,069 c. However, it is observed from the analysis of the cooperating producers
that the trading companies do not have their own production facilities and they quote the capacity of
the producers on their websites.
d.Considering the capacity utilization and export orientation of the responding producers and
evidence provided by the domestic industry, it is evident that there are surplus capacities in China
and the Chinese producers are export oriented.
(C) Inventories of the article being investigated
90. The questionnaire response filed by the Chinese producer's shows that level of inventories\ with
the cooperative producers/exporters is quite significant.
          Producer              Units          2015   2016       2017        POI
          M/s. Anqiu Lu An MT                  ***    ***        ***         ***
          Pharmaceutical
          Co. Ltd.Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

          Lianyungang           MT             ***    ***        ***         ***
          Kangle
          Pharmaceutical
          Co., Ltd
          Hebei     Jiheng MT                  ***    ***        ***         ***
          (group)
          pharmaceutical
          Co. Ltd.
          Total                 MT             ***    ***        ***         ***
(D) Price attractiveness of Indian market
91. Analysis of the China PR Custom data with regard to export from China PR to the rest of the
world indicate that with the revocation of ADD, the Indian prices would be attractive for the Chinese
producers/exporters to increase their exports to India and the same can be deduced from the table
given below:
         Country                        Quantity      Value       Price
                                        (Kg)          (USD)       USD/kg
         India (IN)                     ***           ***         ***
         Congo, DR                      ***           ***         ***
 C/SCA/5278/2019                                                 JUDGMENT
          Cuba (CU)                     ***         ***         ***
          Kenya (KE)                    ***         ***         ***
          Mauritius (MU)                ***         ***         ***
          Indonesia (ID)                ***         ***         ***
          S. Africa (ZA)                ***         ***         ***
          Iraw (IQ)                     ***         ***         ***
          Zambia (ZM)                   ***         ***         ***
          Russia (RU)                   ***         ***         ***
          Iran (IR)                     ***         ***         ***
          Syrian (SY)                   ***         ***         ***
          Benin (BJ)                    ***         ***         ***
          Mozambique (MZ)               ***         ***         ***
          United Arab Emirates (AE)     ***         ***         ***
          Tanzania (TZ)                 ***         ***         ***
          Lithuania (LT)                ***         ***         ***Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

         Source: China Custom
92. The Authority notes that ***% total volume of exports to third countries is at a price lower than
the price at which China exports to India. Whereas ***% of the total exports are exported are above
the price at which China exports the subject goods to India.
(E) Export Orientation of China PR
93. As per the data of China Customs and other evidence filed by the Domestic Industry, the
Authority notes that the producers in China are oriented towards exports globally.
In the event of cessation of ADD, there is probability that the exporters/producers would resort to
dumping of subject goods to India.
K. CAUSAL LINK AND NON ATTRIBUTION ANALYSIS OF OTHER KNOWN FACTORS
94. Having examined the existence of continued dumping, volume and mice effects of dumped
imports on the prices of the Domestic Industry, other indicative parameters listed under the Indian
Rules and Agreement on Anti- Dumping have been examined herein below by the Authority to see
whether any other factor, other than the dumped imports could have contributed injury to the
Domestic Industry.
(xxii)         Being       aggrieved,      the   petitioners          have
               preferred       this      petition     wherein            on
 C/SCA/5278/2019                                               JUDGMENT
13.03.2019, this Court has allowed the draft amendment.
(xxiii) On 11.04.2009, the Court directed the authority to extend the Anti-Dumping Duty for a
period of one month.
(xxiv) On 16.04.2019, respondents issued Notification decided not to extend Anti- Dumping Duty.
(xxv)        On 24.04.2019, this Court issued direction of
             extension      of    Anti       Dumping       Duty     upto
             24.06.2019.
(xxvi)       On 25.04.2019, the petitioners moved anFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

             application     being       IA   No.1    of    2019       for
seeking quashing and setting aside the Notification No.19/2019-Customs (ADD) dated 16.04.2019
whereby Anti-Dumping Duty was ordered to be rescinded.
(xxvii) On 26.04.2019, this Court has passed the order as referred to hereinabove, in initial part of
the order, suspending the impugned Notification dated 16.04.2019.
(xxviii) On 08.05.2019, the petitioners filed I.A. No.2 of 2019 in this matter.
(xxix) On 09.05.2019, this Court directed the respondents to comply with the aforesaid order and
directed issuance of extension of Notification extending the Anti-Dumping Duty as referred to above
in initial part of the order.
(xxx) On 10.06.2019, Respondents No.1 to 3 have issued Notification No.22/2019-Customs (ADD)
extending the Anti-Dumping Duty upto 24.06.2019.
        C/SCA/5278/2019                                           JUDGMENT
       (xxxi)       On 11.06.2019, the petitioners did not press
                    I.A. No.2 of 2019.
       (xxxii)      On   20.06.2019,        a     final   hearing       was
conducted and this Court has passed order for issuance of Notification for extension of
Anti-Dumping Duty till 09.07.2019.
14. The Court is called-upon to examine the rival contentions of the parties, which needs to be
examined in light of the aforesaid indisputable aspects set-out hereinabove. The position of law in
respect of the remedies on final findings is now clear. The respondents have relied on the following
decisions for their contentions that the alternative remedy in terms of Section 9C of the Act may
persuade this Court in not interfering with the final findings.
1. Designated Authority Vs. Sandisk International Ltd, (2018) 13 SCC 402 - the Supreme Court set
aside the judgment of Delhi High Court allowing a Writ Petition and held that the final findings of
the designated authority cannot be challenged under Article 226 of the Constitution.
2. Jindal Poly Film Ltd. Vs. Designated Authority and others, (2018) (362) ELT 994.
3. Suncity Sheets Pvt. Ltd. Vs. Designated Authority, (2017) SCC Online Del. 9412.
4. Spacewood Furnishers Vs. Designated Authority and others, 2010 (112) Bom.L.R. 2045.
5. Shew Kumar Agarwal and others Vs. Union of India, (2002) 1 Callt. 588 HC.Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

The similar question has arisen before this Court in the case of M/s.Jindal Saw Limited Vs Ministry
of Finance in Special Civil Application No.6896 of 2019, wherein on 21.06.2019 this Court has
observed in para-9 as under:
9. ......The judgments cited at the bar are of Delhi High Court and there cannot be any
dispute to the proposition that the final finding in fact is amounting to determination
or review regarding C/SCA/5278/2019 JUDGMENT the existence, degree and effect
of any dumping in relation to import of any article and hence, it may not have to
await the formal order by the Central Government of accepting the same and issuing
notification based thereupon. The learned counsel for the petitioner resisted the
submission qua alternative remedy by inviting court's attention to the provision of
Section-9C of the Act, which reads as under.
SECTION 9C. Appeal. -- (1) An appeal against the order of determination or review thereof
regarding the existence, degree and effect of any subsidy or dumping in relation to import of any
article shall lie to the Customs, Excise and Service Tax Appellate Tribunal constituted under section
129 of the Customs Act, 1962 (52 of 1962) (hereinafter referred to as the Appellate Tribunal).
(1A) An appeal under sub-section (1) shall be accompanied by a fee of fifteen thousand rupees. (1B)
Every application made before the Appellate Tribunal,-
(a) in an appeal under sub-section (1), for grant of stay or for rectification of mistake or for any other
purpose; or
(b) for restoration of an appeal or an application, shall be accompanied by a fee of five hundred
rupees. (2) Every appeal under this section shall be filed within ninety days of the date of order
under appeal :
Provided that the Appellate Tribunal may entertain any appeal after the expiry of the
said period of ninety days, if it is satisfied that the appellant was prevented by
sufficient cause from filing the appeal in time.
(3) The Appellate Tribunal may, after giving the parties to the appeal, an opportunity
of being heard, pass such orders thereon as it thinks fit, confirming, modifying or
annulling the order appealed against. (4) The provisions of sub-sections (1), (2), (5)
and (6) of section 129C of the Customs Act, 1962 (52 of 1962) shall apply to the
Appellate Tribunal in the discharge of its functions under this Act as they apply to it
in the discharge of its functions under the Customs Act, 1962 (52 of 1962).
(5) Every appeal under sub-section (1) shall be heard by a Special Bench constituted
by the President of the Appellate Tribunal for hearing such appeals and such Bench
shall consist of the President and not less than two members and shall include one
judicial member and one technical member.Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

The counsel for the petitioner contended that sub-Section-3 of Section-9C of the Act does not
provide any express authority and power or jurisdiction in the tribunal to issue direction to the
Union of India for issuing notification extending the anti dumping duty.
C/SCA/5278/2019 JUDGMENT In other words, sub- Section-3 of Section-9C provides that the
appellate tribunal may pass such orders as it thinks fit confirming, modifying or annulling the order
appealed as against in an eventuality like present where the challenge is to the final findings on
sunset review which does not require any issuance of further notification, if the final findings are in
negative then, the provision of Section-9C(3) does not envisaged any further positive direction to the
Union of India or the Central Government for extending the anti dumping duty notification.
10. The learned counsel for the petitioner further submitted that Section-9C of the Act even if is said
to be an alternative remedy, but the same cannot be an alternative remedy so efficacious as to
relegate the petitioner in a given case to the tribunal. The efficacy of the remedy is required to be
adjudged in the light of the circumstances of a matter. In the instant case, looking to the time factors
and the authorities reluctance in issuing even the requisite notification for commencing the sunset
review and the fact that the anti dumping duty extension was come to an end on 09.04.2018 and the
impugned final findings were rendered on 01.04.2019 leaving only 7 to 8 days' time for availing the
remedy in itself would be an indication that the appellate remedy as sought to be canvassed under
Section-9C cannot be said to be efficacious remedy.
11. This Court is of the view that the Court at this stage need not go into the aspect of the tribunal's
power to issue direction to the Central Government in exercise of the power u/s.9C(3) for extending
the anti dumping duty notification. The vital facts and time-line of the instant case are itself
sufficient to indicate that the remedy of appeal in a present case could not have been said to be an
efficacious remedy so as to give sufficient opportunity to the petitioner for seeking appropriate relief
after availing the opportunity of putting forward their case. The Tribunal's jurisdiction is required to
be viewed wherein there is no express indication and provision for enabling the tribunal to grant any
interim relief of such nature and in light of the observation of the Supreme Court in case of Kumho
Petrochemicals Company Ltd., (Supra) the hiatus created on account of non-issuance of the
notification of extending anti dumping duty would be viewed as fatal and therefore, in order to
provide full opportunity and for compliance with the principle of natural justice, the Court is under
obligation to issue appropriate direction at times interim direction for preventing any irretrievable
situation jeopardizing the entire matter without adjudication. If one looks at from this angle, then
one will have no other alternative but to accept the submission of learned counsel for the petitioner
that the alternative remedy of appeal u/s.9C of the Act at-least in facts of the present case cannot be
said to be so efficacious as to dissuade this Court from entertaining the petition and relegating the
parties to the appellate forum.
15. In the case of Designated Authority Vs. Sandisk International Limited reported in (2018) 3 SCC
402, the Supreme Court has held and observed in para-6 as under:-
C/SCA/5278/2019 JUDGMENT "6. Though we would not deem it appropriate to lay down any
inflexible proposition of law that in no case the final findings of the Designated Authority can beFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

subject to challenge under Article 226 of the Constitution of India, we are of the view that in the
facts of the present case the High Court was not justified in exercising its jurisdiction and in setting
aside the final findings of the Designated Authority."
16. Thus, there is no inflexible proposition of law that in no case, the final findings of the Designated
Authority can be subject to challenge under Article 226 of the Constitution of India. It is well settled
principles of law that in a given case even if there is alternative remedy available, the High Court
under Article 226 of the Constitution of India has power to issue necessary order.
17. In the case of Nirma Limited Vs. Union of India (supra), this Court has held and observed in
paras-31, 31.5, 32, 32.11, 32.12, 33.7 and 33.8 as under:-
31. While considering the first contention regarding the designated authority having
failed to disclose the essential facts as contemplated under rule 16 of the rules, before
embarking upon a discussion as to whether there is any failure to disclose essential
facts, it would first be necessary to understand the meaning of the expression
"essential facts" as appearing in rule 16 of the rules. Rule 16 of the rules, which deals
with disclosure statement, mandates that the designated authority shall, before
giving its final findings, inform all interested parties of the essential facts under
consideration which form the basis of its decision.
31.5 Thus, while Article 6.9 does not prescribe a particular form for the disclosure of
the essential facts, it does require in all cases that the investigating authority disclose
those facts in such a manner that an interested party can understand clearly what
data the investigating authority has used, and how those data were used to determine
the margin of dumping. The disclosure statement, therefore, contains the
intermediate findings and conclusions of the designated authority on the essential
facts which would form the basis for the decision whether or not to apply definitive
measures and not final conclusions on whether or not definite measures are required
to be applied. In the opinion of this court, as rightly submitted by the learned counsel
for the petitioners, the disclosure statement should contain the conclusions of the
designated C/SCA/5278/2019 JUDGMENT authority on those essential facts which
would form the basis for its decision as to whether or not to apply definitive measures
and not its conclusions on the basis of those essential facts. The conclusions on the
basis of the essential facts are to be recorded in the final findings, viz., whether or not
on the basis of such facts definitive measures are required to be applied. The
contention that the disclosure statement is in the nature of a draft order, therefore,
does not merit acceptance, inasmuch as, a draft order would also contain conclusions
on whether or not definitive measures are required to be applied.
32. The next question that arises for consideration is whether or not the essential
facts have been disclosed in the disclosure statement.Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

32.11 Thus, the designated authority has taken into consideration the aforesaid
factors while coming to the conclusion as to whether or not definitive measures are
required to be applied. In this regard, it may be noted that the designated authority
has not disclosed the details of dumping margin calculations to the petitioner, viz.,
the difference between the Export Price and Normal Value. The designated authority
has not disclosed the basis for determining Normal Value and Export Price and has
also not disclosed the methodology and computation. The designated authority has
considered the value of Cost of Sales and Selling Price based on the data submitted by
the domestic industry, but has not disclosed what data has been used by it while
determining the price suppression and price depression effect. While determining the
price undercutting, the value for Net Sales Realisation is calculated on the basis of
data provided by the domestic industry but the actual figures and methodology are
not disclosed. The non-injurious price for the post POI has not been disclosed while
determining the Price Underselling and the computation of the NIP has not been
furnished for the POI as well as the post POI. The designated authority has used the
data supplied by the domestic industry while determining data relating to inventories
but has failed to disclose the same. While determining profits and actual and
potential on cash flow, the figures of profit, return on investments, BPIT etc. are
worked out on the basis of the information submitted by the domestic industry, but
not disclosed to the domestic industry. While determining magnitude of injury and
injury margin, the designated authority has failed to disclose post POI NIP as well as
methodology and calculation.
32.12 As can be seen from the findings recorded by the designated authority on
various parameters relevant for the purpose of coming to the conclusion as to
whether or not definitive measures are required to be applied, it has placed reliance
on certain information for the purpose of arriving at its findings which are essential
facts. All the information which are relied upon by the designated authority to the
extent the same is not protected by rule 7 of the rules, was C/SCA/5278/2019
JUDGMENT in the nature of necessary information which should have been
disclosed to the interested parties to enable them to comment on the completeness
and correctness of the facts that were being considered by the designated authority,
and to provide additional information or correct the perceived errors and comment
on or make arguments as to the proper interpretation of those facts. The entire body
of facts essential to the determinations that must be made by the designated
authority before it can decide whether to apply definitive measures are required to be
disclosed to the interested parties. A perusal of the tabular form regarding the data
which are reproduced in the disclosure statement reveals that at various places
instead of the relevant data the table contains asterisks which would indicate that
such information is confidential. While it is true that the such information being
confidential in nature, cannot be disclosed in the disclosure statement itself, it
appears to be the general practice to provide the same to the parties separately.
However, in the facts of the present case, despite the fact that the information has
been furnished by the domestic industry itself, the computation of the various factorsFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

referred to hereinabove, has not been furnished to the domestic industry. In the
opinion of this court, it was incumbent upon the designated authority to furnish the
relevant facts which have been used by it as the basis for arriving at its conclusion on
the essential facts necessary for the purpose of arriving at a decision as to whether or
not the definitive measures are required to be applied. Non-disclosure of the essential
facts is, therefore, clearly in breach of the principles of natural justice.
33.7 Thus, though most of the factors which are required to be taken into
consideration for the purpose of determination of injury, namely, increase in volume,
increase in dumping, increase in margin of dumping and price undercutting are all
positive and only price suppression and price depression are absent, the designated
authority, instead of relying upon the said factors for the purpose of basing his
decision as to whether or not to continue with the determinative measures,has placed
reliance upon an irrelevant factor, viz., injury margin, which is not required to be
taken into consideration while considering the likelihood aspect under clause (vii) of
Annexure II to the rules. Clause (vii) of Annexure II to the rules provides for four
factors which are required to be taken into consideration, viz.:
(a) a significant rate of increase of dumped imports into India indicating the
likelihood of substantially increased importation;
(b) sufficient freely disposable, or an imminent, substantial increase in, capacity of
the exporter indicating the likelihood of substantially increased dumped exports to
Indian markets, taking into account the availability of other export markets to absorb
any additional exports;
(c) whether imports are entering at prices that will have a significant depressing or
suppressing effect on domestic prices, and would likely increase demand for further
C/SCA/5278/2019 JUDGMENT imports; and
(d) inventories of the article being investigated.
Out of the above four factors, the designated authority has taken into consideration the factors
prescribed under subclauses (a) and (c). However, insofar as sub-clause (c) is concerned, the
designated authority has placed reliance upon incorrect facts, namely, though the price undercutting
is positive, it has considered the same to be negative and drawn its conclusions accordingly.
33.8 Insofar as the factors prescribed under sub-clauses
(b) and (d) of clause (vii) of Annexure II to the rules are concerned, it, however, has been contended
on behalf of the respondents that the designated authority has also considered those factors. In this
regard, a perusal of the disclosure statement shows that while the designated authority has taken
into consideration the above two factors, it is manifest that while doing so, it has taken into
consideration incorrect facts, inasmuch as, instead of considering the capacity of production of theFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

exporters indicating the likelihood of substantially increased dumped exports to Indian markets, as
contemplated under sub- clause (b), it has taken into consideration the capacity of production of the
domestic industry; and instead of taking into consideration the existence of inventories of the
dumped imports that could meet any increase or future demand for the imports, has taken into
consideration the inventories of the domestic industry. Evidently therefore, the designated authority
has failed to follow the procedure laid down under clause (vii) of Annexure-II to the rules for the
purpose of determination of threat of material injury in the manner prescribed thereunder.
17.1 In the case of Reliance Industries Limited Vs. Designated Authority (supra), the Supreme Court
has held and observed in paras-41, 43, 44 and 45 as under:-
"41. The DA claimed confidentiality from the appellant about its finding on the data
supplied by the appellant itself. In our opinion, there was nothing confidential in the
mater, and hence reasons for not accepting the appellant's version should have been
stated in the order of the DA.
43. In our opinion, Rule 7 does not contemplate any right in the DA to claim
confidentiality. Rule 7 specifically provides that the right of confidentiality is
restricted to the party who has supplied the information, and that party has also to
satisfy the DA that the matter is really confidential. Nowhere, in the rule has it been
provided that the DA has the right to claim confidentiality, particularly regarding
information which pertains to the party which has supplied the same. In the present
case, the DA has failed to provide the detailed costing information to the appellant on
the basis of which it computed NIP, even though the appellant was the sole
C/SCA/5278/2019 JUDGMENT producer of the product under consideration, in the
country. In our opinion this was clearly illegal, and not contemplated by Rule 7.
44. In this connection, this Court in Sterlite Industries (India) Ltd. v. Designated
Authority observed thus: (SCC pp.286-87, para 3) "3. In our view, it is not necessary
for us to go into the merits of this matter as we propose to send the matter back to
CEGAT after laying down certain guidelines. From what has been argued before us, it
appears that in pursuance of Rule 7 of the Customs Tariff (Identification, Assessment
and Collection of Anti-
Dumping Duty on Dumped Articles and for Determination of Injury) Rules, 1995, the Designated
Authority is treating all material submitted to it as confidential merely on a party asking that it be
treated confidential. In our view, that is not the purport of Rule 7. Under Rule 7, the Designated
Authority has to be satisfied as to the confidentiality of that material. Even if the material is
confidential the Designated Authority has to ask the parties providing information, on confidential
basis, to furnish a non-confidential summary thereof. If such a statement is not being furnished then
that party should submit to the Designated Authority a statement of reasons why summarisation is
not possible. In any event, under Rule 7(3) the Designated Authority can come to the conclusion that
confidentiality is not warranted and it may, in certain cases, disregard that information. It must be
remembered that not making relevant material available to the other side affects the other side asFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

they get handicapped in filing an effective appeal. Therefore, confidentiality under Rule 7 is not
something which must be automatically assumed. Of course in such cases there is need for
confidentiality as otherwsie trade competitors would obtain confidential information, which they
cannot otherwise get. But whether information supplied is required to be kept confidential has to be
considered on a case-to-case basis. It is for the Designated Authority to decide whether a particular
material is required to be kept confidential. Even where confidentiality is required, it will always be
open for the Appellate Authority, namely CEGAT to look into the relevant files."
45. In our opinion, excessive and unwarranted claim of confidentiality defeats the right to appeal. In
the absence of knowledge of the consequences, grounds, reasoning and methodology by which the
DA has arrived at its decision and made its recommendation, the parties to the proceedings cannot
effectively exercise their right to appeal either before the Tribunal or this Court. This is contrary to
the view taken by the Constitution Bench of this Court in S. N. Mukherjee case.
17.2 In the case of Union of India Vs. Meghmani Organics Limited (supra), the Supreme Court has
held and observed in C/SCA/5278/2019 JUDGMENT paras-14, 15, 16 and 19 as under:-
14. Elaborating his points further, learned senior counsel for the Union of India
submitted that the very opening sentence of above quoted para 43 lays down an
incorrect proposition of law that Rule 7 does not permit the DA to claim
confidentiality and that right to make such a claim is vested only in a party who has
supplied the particular information. The use of the term 'any party' in the opening
sentence of Rule 7(1) in place of the expression 'interested party', according to
learned counsel, indicates that the DA may receive in course of his suo motu action
certain confidential informations and in such a situation if he is satisfied that the
confidentiality of such information needs to be protected and should not be disclosed
to any other party without specific authorisation, the DA may be justified in his
action whereby he himself claims confidentiality in appropriate cases without any
party exercising the right of confidentiality.
15. To buttress his aforesaid stand learned senior counsel placed emphasis upon
Articles 6.2 and 6.5 of GATT 1994. By placing reliance upon paragraph 23 of the
judgment in the case of Commissioner of Customs, Bangalore v. G. M. Exports [6] he
submitted that in the light of Article 51(c) of the Constitution of India, in a situation
where India is a signatory to an international Treaty or Agreement and a statute is
made to enforce a treaty obligation, then in case of any difference between the
language of such statute and a corresponding provision of the Treaty, the statutory
language should be interpreted in the same sense as the language of the Treaty. In
abstract the proposition is salutary and needs no caveat. Articles 6.2 and 6.5 have
already been extracted earlier. In essence, Rules 6 and 7 of the Rules ensure the
obligations flowing from Articles 6.2, 6.4 and 6.5. While interested parties are
entitled to have full opportunity to defend their interests, such opportunities need to
be hedged by the need to maintain confidentiality. Informations other than
confidential must be shown to all interested parties whenever practicable in terms ofFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

Article 6.4. Any information which is by nature confidential or which is provided on a
confidential basis is required to be treated as confidential by the authorities but only
on being satisfied by good cause shown for the confidentiality claimed. No doubt the
opening clause of Article 6.5 covers any information which is by nature confidential
but the examples indicated therein clearly reveal that such information is required to
be kept confidential because if revealed it would give significant advantage to a
competitor or would have significant adverse effect upon the person supplying the
information or his resource person from whom he acquired the information. The
submission that DA is entitled to presume such effects without any claim being made
by the party supplying the information is, however, not acceptable for reasons more
than one. The examples are clearly meant to be only a guiding factor for the DA who
C/SCA/5278/2019 JUDGMENT cannot by exercise of discretion presume
confidentiality and thereby restrict the rights of the interested parties to see relevant
informations that may be used by the DA for the investigation. The DA, being a
statutory investigator, cannot assume for himself the role of a party for the purpose of
Rule 7 and to claim as well as accept on information to be confidential.
16. The other reason is provision of appeal under Section 9C of the Act. The appeal
provided is against the order of determination or review thereof regarding the
existence, degree and effect of any subsidy or dumping in relation to import of any
article. It is one thing to use confidential information for the purpose of investigation
on account of statutory provisions and not communicating the same. It is quite
another, not to maintain transparent records of reasons as to why claim of
confidentiality made by any party has been accepted by the DA. Where appeal is
provided, the appellate authority will definitely be entitled to look into the records
including the confidential information as well as into the correctness of the decision
for accepting a claim of confidentiality. The situation is similar to one under the
administrative law where a policy may exempt the authority from requirement of
communicating its reasons for an administrative decision/order affecting rights and
interests of parties but certainly reasons must exist in the records so as to justify the
reasonableness and fairness of the decision if it has adverse effects upon any party.
Any court or tribunal exercising judicial review is entitled to call for the records to
satisfy itself as to the existence of reasons in appropriate cases involving a challenge
to such order. In case the DA is conceded power to gather informations from sources
other than interested parties, he must not treat such information as confidential
unless the party which has supplied the information makes a request to keep the
information confidential. Even in such a situation where an uninterested party claims
confidentiality in respect of information supplied, as per Rule 7, the DA has to take all
necessary precautions to decide the genuineness of such claim. In appropriate cases
he must ask for summary of the information and if that is also not possible, the
reasons as to why it is not possible should be supplied for scrutiny. The reasons of
confidentiality must be discernible on scrutiny of records by the appellate authority
because of mandate of Rule 7(3) that if the claim of confidentiality is not worthy of
acceptance, or the supplier of the information is unwilling to make the informationFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

public without any good reasons, the DA has to disregard such information.
19. Looking at the contents of Rule 7 and the facts and issues involved in Reliance
Industries case, we agree with the submissions of Mr. Patil that fact situation in that
case was entirely different and the Court was not examining the provisions of Rule 7
in any detail but made rather scathing observations against the DA because the DA
claimed confidentiality not in respect of any information but in respect of its findings
based upon C/SCA/5278/2019 JUDGMENT information supplied by the same party
who was aggrieved by non-supply of the findings. The observations in Reliance
Industries case must be understood in the fact situation of that case in view of well
established proposition of law that the ratio decidendi consists in the reasons
formulated by the court for resolving an issue arising for determination and not in
what may logically appear to flow from observations on non issues.
Reference in this regard may be made to law enunciated on this point by a Constitution Bench, in
paragraph 20 of the judgment in the case of Krishena Kumar v. Union of India & Ors. [7] In the
given facts, the observations in paragraph 43 in the case of Reliance Industries are fully justified and
do not require any review. We are in agreement that Rule 7 does not postulate that the DA can claim
confidentiality and that too not in respect of any information supplied by a party but in respect of its
reasons or findings derived from information supplied by the same very party.
17. Considering the matter on merits, it is required to be noted, at this stage, that the submissions
advanced on behalf of the petitioners, which have been set out herein above, have hardly been
refuted by the respondents in proper manner. The respondents by and large have contended that the
authority has observed principles of natural justice and afforded all the informations to the
petitioners and afforded full opportunity for rendering final findings. It is the main contention of the
petitioners that the conclusion reached in final finding is diametrically opposed in the observations
made in the Disclosure Statement as well as the observations made in earlier part of final finding
and the respondents have not provided any information after the Disclosure Statement. Considering
the rival contention and on perusal of the material placed on record, it appears that the respondents
have sent email with a statement that the necessary required information is attached with email.
Now, the receipt of the email by the petitioners is not denied only facts of the receipt of the
annexures therewith has been denied by the petitioners. At this juncture, it is pertinent to note that
the respondent has, first during its submissions, submitted that the information has been provided
but no such fact has been narrated in the affidavit-in-reply. Even no such fact has been taken in the
pleadings itself. It appears that such information was supplied C/SCA/5278/2019 JUDGMENT
before issuance of Disclosure Statement. However, the fact remains that no information whatsoever
as sought for has been supplied after Disclosure Statement.
18. The petitioners have shown how there is diametrical conclusion reached in the Final Finding
from the particulars and objections in the earlier part of Final Finding as well as Disclosure
Statement, in his conclusion reached in the Final Finding in its submissions, which have been
reproduced hereinabove. On analysis of the same, it appears that while considering the import as
insignificant which constituted 98% of the total import and 6% of consumption in India which moreFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

than insignificant as defined in Rule 14(d) of the Rules has not been properly considered by
respondent No.2. The volume of insignificant import has been dealt with in Rule 14(d) which reads
as under:-
RULE 14. Termination of investigation. The designated authority shall, by issue of a
public notice terminate an investigation immediately if -
       (a)   xxxx    xxxx   xxxx
       (b)   xxxx    xxxx   xxxx
       (c)   xxxx    xxxx   xxxx
(d) it determines the volume of the dumped imports, actual or potential, from a
particular country accounts for less than three per cent of the imports of the like
product, collectively account for more than seven per cent of the import of the like
product; or
(e) xxxx xxxx xxxx Thus, according to Rule 14(d), the percentage has been given in
the import of the like product. Now, admittedly, in view of para-62 at page No.265,
the imports are 5.84% which is above the insignificant import as per Rule 14(d).
Thus, the observations made by the DA is misreading of the facts and the DA has not
properly appreciated this very observation while reaching in the conclusion in Final
Finding and this fact is corroborated from the Final Finding C/SCA/5278/2019
JUDGMENT itself.
19. It also appears from the record that the authority has made observations regarding likelihood of
substantially increased dumped exports to Indian market, taking into account the availability of
other export markets to absorb any additional exports from paragraph Nos.85, 90, 91, 92 and 93 at
page Nos.273 to 277 and has specifically observed therein that -
(I) Considering the capacity utilization and export orientation of the responding producers and
evidence provided by the domestic industry, it is evident that there are surplus capacities in China
and the Chinese producers are export oriented.
(II) The questionnaire response filed by the Chinese producer's shows that level of inventories with
the cooperative producers / exporters is quite significant.
(III) Analysis of the China PR Custom data with regard to export from China PR to the rest of the
world, indicate that with the revocation of ADD, the Indian prices would be attractive for the
Chinese producers / Exporters to increase their exports to India.
(VI) The Authority notes that ***% total volume of exports to third countries is at a price lower than
the price at which China exports to India. Whereas ***% of the total exports are exported are aboveFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

the price at which China exports the subject goods to India.
           (V)    In the event of cessation of ADD, there is
        C/SCA/5278/2019                                               JUDGMENT
probability that the exporters / producers would resort to dumping of subject goods to India.
Though all these facts have been narrated by the DA, ultimately, in his conclusion in paras 126(6) to
165, has observed that the DI has failed to substantiate its claim in relation to likelihood of injury to
the domestic industry if the current ADD ceases to exist. It has also observed that -
Analysis of the price attractiveness by the Authority does not position India as price attractive for
Chinese exports so far as subject goods are concerned.
20. The petitioners have shown how there is diametrical conclusion reached in the Final Finding
from the particulars and objections in the earlier part of Final Finding as well as Disclosure
Statement, in his conclusion reached in the Final Finding in its submissions, which have been
reproduced hereinabove. On analysis of the same, it appears that while considering the import as
insignificant which constituted 98% of the total import and 6% of consumption in India which more
than insignificant as defined in Rule 14(d) of the Rules has not been properly considered by
respondent No.2. The volume of insignificant import has been dealt with in Rule 14(d) which reads
as under:-
RULE 14. Termination of investigation. The designated authority shall, by issue of a
public notice terminate an investigation immediately if -
      (a)    xxxx    xxxx    xxxx
      (b)    xxxx    xxxx    xxxx
      (c)    xxxx    xxxx    xxxx
(di) it determines the volume of the dumped imports, actual or potential, from a
particular country accounts for less than three per cent of the imports of the like
product, collectively account for C/SCA/5278/2019 JUDGMENT more than seven
per cent of the import of the like product; orFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

(e) xxxx xxxx xxxx Thus, according to Rule 14(d), the percentage has been given in
the import of the like product. Now, admittedly, in view of para-62 at page No.265,
the imports are 5.84% which is above the insignificant import as per Rule 14(d).
Thus, the observations made by the DA is misreading of the facts and the DA has not
properly appreciated this very observation while reaching in the conclusion in Final
Finding and this fact is corroborated from the Final Finding itself.
21. It also appears from the record that the authority has made observations regarding likelihood of
substantially increased dumped exports to Indian market, taking into account the availability of
other export markets to absorb any additional exports from paragraph Nos.85, 90, 91, 92 and 93 at
page Nos.273 to 277 and has specifically observed therein that -
(I) Considering the capacity utilization and export orientation of the responding producers and
evidence provided by the domestic industry, it is evident that there are surplus capacities in China
and the Chinese producers are export oriented.
(II) The questionnaire response filed by the Chinese producer's shows that level of inventories with
the cooperative producers / exporters is quite significant.
(III) Analysis of the China PR Custom data with regard to export from China PR to the rest of the
world, indicate that with the revocation of ADD, the Indian prices would be attractive for the
Chinese C/SCA/5278/2019 JUDGMENT producers / Exporters to increase their exports to India.
(VI) The Authority notes that ***% total volume of exports to third countries is at a price lower than
the price at which China exports to India. Whereas ***% of the total exports are exported are above
the price at which China exports the subject goods to India.
(VI) In the event of cessation of ADD, there is probability that the exporters / producers would
resort to dumping of subject goods to India.
Though all these facts have been narrated by the DA, ultimately, in his conclusion in paras 126(6) to
165, has observed that the DI has failed to substantiate its claim in relation to likelihood of injury to
the domestic industry if the current ADD ceases to exist. It has also observed that -
Analysis of the price attractiveness by the Authority does not position India as price attractive for
Chinese exports so far as subject goods are concerned.
22. It appears from the Disclosure Statement as well as Final Finding that all the above facts are
narrated therein, but without considering those facts and in diametrically opposed to the same, the
DA has made conclusion. Thus, the submission of the petitioners that the DA has not properly
appreciated the fact and has went beyond the evidence and information examined, is acceptable. It
appears from the record that the conclusion arrived at by DA in Final Finding is not based on the
observations made by him in Disclosure Statement as well as in Final Finding itself. Thus, there is
lack of C/SCA/5278/2019 JUDGMENT non-application of mind on the part of the authorityFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

concerned.
23. The DA has also made observation in para-126(6) that the ADD was in force since September
2001 and the condition of domestic industry has improved. But, this fact has no relevance for
deciding likelihood injury if ADD is not extended. The ADD is required to be imposed so long as the
investigation shows that the cessation of such duty is likely to lead to continuation or recurrence of
dumping and injury.
24. The submission of Mr.Desai, learned advocate for respondent No.2 so far as it relates to the
stand that DGCIS is not a public domain and everybody cannot have accessed to its data is
concerned, the same is devoid of merits. Even if there is fee for charge is recovered, the persons who
access such site of DGCIS then in that case also, it cannot be treated as a private or confidential data.
Whenever any information is made available on website by any particular entity then it will amount
to available on public domain which has been recorded by the DA from the data of DGCIS is also a
breach of Rules and there is detailed information given to the petitioners herein.
25. It appears from the record that after Disclosure Statement, the petitioners herein have sought
certain informations which are not confidential in nature, which have not been supplied by the DA
to the petitioners and thus, there is also breach of principles of natural justice. Considering the facts
narrated in the Disclosure Statement and Finding and ultimate conclusion, it clearly appears that
the DA has not properly appreciated the material placed on record and has not averted all the facts
of likelihood of dumping and injury to the DI and there is non-advertence to the requisite material
placed on record and non-consideration of the facts recorded earlier and there is merely a
foundation of reading to the conclusion in final finding, diametrically opposed to the facts observed
in the C/SCA/5278/2019 JUDGMENT Disclosure Statement and final findings, which render the
final findings not tenable in the eye of law as the final findings are suffering from the aforesaid
omissions and, therefore, it could be termed as perverse so as to render it unsustainable in the eye of
law.
26. Mr.Ravi Prakash, learned advocate for respondent - Union of India has submitted that the
Union of India cannot review its decision and cannot extend the notification which is non-existence
in the eye of law. So far as the present petition is concerned, this matter was listed earlier before this
Court and certain orders came to be passed, which are reproduced hereinabove, which reflects that
pending this petition, respondent has diluted interim order of this Court and issued notification
cancelling ADD. Therefore, when the matter was in session with the Court, whatever action is taken
is subject to the result of the petition. As such, considering the peculiar facts and circumstances of
the case, this Court is of the view that the stand taken by respondent - Union of India cannot be
accepted and it is meritless, especially when it is found from the material placed on record that the
DA has not taken into consideration the material placed on record, as conclusion in final finding is
diametrically opposed to the observations made in the Disclosure Statement as well as in Final
Findings and thus, as there is non-application of mind of the DA, this Court has power and
jurisdiction to direct the concerned authority to extend the period of notification to impose ADD for
a further period.Farmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

27. One of the submissions on behalf of the respondents as made by Mr.Desai, learned advocate for
Union of India is that after Disclosure Statement and before passing of final order, nothing is
required to be done and, therefore, there might be reproduction of facts and material which has
been made in Disclosure Statement in the same in the Final Findings. This submission is devoid of
merits. Had there been real intention of the legislature that nothing is C/SCA/5278/2019
JUDGMENT required to be done after passing the Disclosure Statement, then the Act and Rules
might have provided that the same may be treated as Final Findings. It is an admitted fact that after
Disclosure Statement, the concerned parties are invited to submit their submissions and, thereafter,
the Final Finding has to be arrived at. It shows that it is the duty of the concerned authority to
eventuate, examine and appreciate the material placed by the concerned parties, which have been
submitted by them after Disclosure Statement, in its proper perspective and, thereafter, the
authority has to pass final finding order. This course has to be adopted with a view to afford proper
opportunity to all the parties and to evaluate, examine and appreciate the material supplied by the
concerned parties to the DA regarding Disclosure Statement and after making such exercise by DA,
necessary Final Finding may be arrived at by DA either to positive opinion or negative one
continuation.
28. The law in respect of the final findings and its justiciability is no more res-integra and one can
say that under Article 226 of the Constitution of India when final findings are assailed on the
grounds mentioned in the submissions viz. Omissions on the part of the authority in considering the
detailed put forward by the petitioner, the High Court could interfere in the matter. The omission by
the designated authority in disclosing the material which is not claimed to be confidential and the
omission to follow the methodology in light of the decision in respect of Rule-7 as held by Supreme
Court in case of Reliance Industries Ltd., Vs. Designated Authority reported in 2006 (10) SCC 368
and Union of India Vs. Meghmani Organics Ltd., reported in 2016 (340) E.L.T. 449 can be held to
be sufficient material to persuade this Court to hold that the final findings cannot be said to be
sustainable in eye of law.
29. In view of the aforesaid discussions, we are of the view that the impugned Final Finding
recorded in the Notification No.7/16/2018-DGAD dated 29.01.2019, cannot be said to be strictly
C/SCA/5278/2019 JUDGMENT in accordance with the provision of Rule 23 of the Rules, as there is
nonadvertance to the material placed on record and there is noncompliance with the principle of
natural justice as no requisite information was made available and the conclusions are diametrically
opposed to the material on record. Therefore, we are left with no other alternative, but to remand
back the matter to the concerned authority after quashing and setting aside the same for
reconsideration on the aspects which have been mentioned herein above and record its finding, and
as the extended period of notification of anti dumping duty is ending, the same is also required to be
extended for appropriate time so that assessing the material and recording the final findings afresh
could be undertaken meaningfully and without jeopardizing the parties right and contentions and
rendering it infructuous.
30. In that view of the matter, the respondent no.2 is hereby directed to undertake the exercise of
recording its final finding afresh in accordance with the observations made herein above strictly in
accordance with the provisions of Rule-23 of the Rules and after affording full opportunity to theFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

parties and complying with the principles of natural justice and respondent no.1 shall appropriately
issue notification extending the anti dumping duty on the product in question, till the final findings
are rendered.
31. In view of the aforesaid discussion, the petition is allowed. The impugned final findings dated
29.01.2019 are hereby quashed and set aside.
Sd/-
(S.R.BRAHMBHATT, J) Sd/-
(A. P. THAKER, J) V.R. PANCHALFarmson Pharmaceuticals Gujarat ... vs Union Of India on 3 July, 2019

