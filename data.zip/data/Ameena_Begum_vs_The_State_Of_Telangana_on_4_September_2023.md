Ameena Begum vs The State Of Telangana on 4 September,
2023
Author: Dipankar Datta
Bench: Dipankar Datta, Surya Kant
                                                                           REPORTABLE
2023INSC788
                                    IN THE SUPREME COURT OF INDIA
                                   CRIMINAL APPELLATE JURISDICTION
                                   CRIMINAL APPEAL NO………… OF 2023
                            [ARISING OUT OF SLP (CRIMINAL) NO. 8510 OF 2023]
     AMEENA BEGUM                                                      …APPELLANT
                                                     VS.
     THE STATE OF TELANGANA & ORS.                                     …RESPONDENTS
                                             JUDGMENT
DIPANKAR DATTA, J.
Leave granted.
THE JUDGMENT UNDER CHALLENGE
2. Under assail in this appeal is a judgment and order dated 28th June, 2023 of a Division Bench of
the High Court for the State of Telangana (“High Court”, hereafter). Vide the impugned judgment, a
writ petition1 instituted by the appellant seeking a writ of habeas corpus was dismissed and the
order of detention dated 24th March, 2023 Date: 2023.09.04 15:15:48 IST Reason:
(“Detention Order”, hereafter) of the appellant’s husband (“Detenu”, hereafter),
impugned therein, upheld.
THE ORDER OF DETENTION AND FURTHER PROCEEDINGSAmeena Begum vs The State Of Telangana on 4 September, 2023

3. The Commissioner of Police, Hyderabad City (“Commissioner”, hereafter) passed the Detention
Order against the Detenu under the provisions of section 3(2) of the Telangana Prevention of
Dangerous Activities of Bootleggers, Dacoits, Drug-Offenders, Goondas, Immoral Traffic Offenders,
Land Grabbers, Spurious Seed Offenders, Insecticide Offenders, Fertiliser Offenders, Food
Adulteration Offenders, Fake Document Offenders, Scheduled Commodities Offenders, Forest
Offenders, Gaming Offenders, Sexual Offenders, Explosive Substances Offenders, Arms Offenders,
Cyber Crime Offenders and White Collar or Financial Offenders Act 1986 (“the Act”, hereafter).
Perusal of the Detention Order reveals that the Detenu earlier suffered an order of detention dated
4th March, 2021 under the category of “White Collar Offender”; however, pursuant to an order of
the High Court dated 16th August, 2021 in writ proceedings instituted by his father2, the Detenu
was released from detention on 17th August, 2021; that even after such release, the Detenu did not
mend his habitual nature of committing crimes and in the recent past (during 2022 and 2023), in
quick succession, had committed 9 (nine) more offences within the limits of Hyderabad Police
Commissionerate, as listed therein; that out of such 9 (nine) offences, 5 (five) FIRs3 had been taken
into consideration; and that on examination of the material placed before him, the Commissioner
was satisfied that the Detenu was “habitually committing the offences including outraging the
modesty of women, cheating, extortion, obstructing the public servants from discharging their
legitimate duties, robbery and criminal intimidation along with his associates in an organized
manner in the limits of … and he is a ‘Goonda’ as defined in clause (g) of Section 2” of the Act (bold
in original). The Commissioner, with a view to prevent the Detenu from acting in a manner
prejudicial to maintenance of public order, recorded not only his satisfaction for invoking the
provisions of the Act but also recorded a satisfaction that “the ordinary law under which he was
booked is not sufficient to deal with the illegal activities of such an offender who has no regard for
the society. Hence, unless he is detained under the detention laws, his unlawful activities cannot be
curbed”. After referring to the bail petitions filed by the Detenu in Cr.No.18/2023 of Golconda PS
and Cr.No.35/2023 of Falaknuma PS and bail having been granted despite suitable counters filed by
the prosecution resulting in the Detenu’s release from jail, the Commissioner observed as follows:
“As seen from his past criminal history, background and antecedents and also his
habitual nature of committing crimes one
(i) FIR No. 227/2022 dated 28.07.2022 for offences under Sections 186, 189, 353,
504, 506, IPC; (ii) FIR No. 262/2022 dated 10.10.2022 for offences under Sections
420, 384, 506 r/w 34, IPC; (iii) FIR No. 338/2022 dated 12.10.2022 for offences
under Sections 354, 420, 323, 506 r/w 34, IPC; (iv) FIR No. 18/2023 dated
21.01.2023 for offences under Sections 506, 420, 406 r/w 34, IPC; and (v) FIR No.
35/2023 dated 08.02.2023 for offences under Sections 392, 195A, IPC.
after the other and his efforts to come out of the prison, I strongly believe that if such a habitual
criminal is set free, his activities would not be safe to the society and there is an imminent possibility
of his committing similar offences by violating the bail conditions in one of the cases which would be
detrimental to public order, unless he is preventively detained from doing so by an appropriate
order of detention.” This was followed by the order detaining the Detenu, treated as a ‘Goonda’,
from the date of service of the same with a direction to lodge him in Central Prison, Chanchalguda,Ameena Begum vs The State Of Telangana on 4 September, 2023

Hyderabad.
4. Upon her husband being detained, the appellant submitted a representation dated 29th March,
2023 in terms of section 10 of the Act raising several grounds and seeking revocation of the
Detention Order. Such representation was placed before the Advisory Board constituted under
section 9 of the Act. The Advisory Board vide a report dated 29th April, 2023 opined that “there is
sufficient cause for the detention of the detenu …”, whereupon the Government issued an order
dated 20th May, 2023 under sub-section (1) of section 12 read with section 13 of the Act confirming
the Detention Order and directing that the detention be continued for a period of 12 months from
the date of detention, i.e., 27th January, 2023 (sic, 27th March, 2023). By a further order of even
date, the appellant was informed by the Government of absence of any valid grounds/reasons to set
aside/revoke the Detention Order leading to rejection of her representation.
5. The appellant then invoked the writ jurisdiction of the High Court whereupon the parties were
heard and the impugned judgment delivered containing reasons for dismissing the writ petition.
CONTENTIONS OF THE PARTIES
6. In course of hearing of the appeal, Mr. Luthra, learned senior counsel for the appellant invited our
attention to several paragraphs of the impugned judgment to demonstrate the errors from which the
same suffered, both factual as well as legal. He also placed on record written notes containing
submissions on factual as well as legal aspects. Relying on the authorities referred to therein, he
prayed for interference by this Court to facilitate release of the Detenu from illegal detention.
7. Per contra, Mr. Dave, learned senior counsel for the respondents urged that notwithstanding Mr.
Luthra’s attempt to prick holes in the impugned judgment of the High Court, what is to be seen and
read is the order of detention passed under section 3 and once read, it becomes clear that the
ultimate conclusion recorded in the impugned judgment is defensible based on the grounds for
detention as assigned by the Commissioner in his order dated 24th March, 2023 and the order
dated 20th May, 2023 of the Government. Other contentions raised by Mr. Dave need not be
enumerated here, for, we intend to deal with the same while proceeding further. However, to put it
concisely, the argument of Mr. Dave has been that the satisfaction of the detaining authority cannot
be subjected to objective tests and that the courts are not supposed to exercise appellate powers over
such authorities; and that an order, proper on its face, passed by a competent authority in good faith
is a complete answer to negative a claim such as the one raised by Mr. Luthra. Several authoritative
decisions on preventive detention cases having high precedential value was cited by him and he
contended that the appeal deserves nothing but dismissal. GENERAL DISCUSSIONS ON
PREVENTIVE DETENTION AND JUDICIAL REVIEWABILITY
8. Prior to venturing to decide the contentious issue as to whether the Detention Order is legal or
not, we consider it necessary to remind ourselves of the purpose for which preventive detention in a
particular case could be ordered, the requisites of a valid detention order and the scope of judicial
reviewability of such order.Ameena Begum vs The State Of Telangana on 4 September, 2023

9. Clauses (1) and (2) of Article 22 of the Constitution guaranteeing protection to a person against
arbitrary arrest, effected otherwise than under a warrant issued by a court of law, are regarded as
vital and fundamental for safeguarding personal liberty. Nonetheless, the protection so guaranteed
is subject to clause (3) of Article 22 which operates as an exception to clauses (1) and (2) and ordains
that nothing therein shall apply to, inter alia, any person who is arrested or detained under any law
providing for preventive detention. The purpose of preventive detention, as said by Hon’ble A.N.
Ray, CJ. in Haradhan Saha vs. State of West Bengal4 is to prevent the greater evil of elements
imperiling the security and safety of a State, and the welfare of the Nation. Preventive detention,
though a draconian and AIR 1974 SC 2154 dreaded measure, is permitted by the Constitution itself
but subject to the safeguards that are part of the relevant article and those carved out by the
Constitutional Courts through judicial decisions of high authority which have stood the test of time.
10. It is common knowledge that recourse to preventive detention can be taken by the executive
merely on suspicion and as a precaution to prevent activities by the person, sought to be detained,
prejudicial to certain specified objects traceable in a validly enacted law. Since an order of
preventive detention has the effect of invading one’s personal liberty merely on suspicion and is not
viewed as punitive, and the facts on which the subjective satisfaction of the detaining authority is
based for ordering preventive detention is not justiciable, meaning thereby that it is not open to the
Constitutional Courts to enquire whether the detaining authority has erroneously or correctly
reached a satisfaction on every question of fact and/or has passed an order of detention which is not
justified on facts, resulting in narrowing down of the jurisdiction to grant relief, it is only just and
proper that such drastic power is not only invoked in appropriate cases but is also exercised
responsibly, rationally and reasonably. Having regard to the circumstance of loss of liberty by
reason of an order of preventive detention being enforced without the detenu being extended any
opportunity to place his case, the Constitutional Courts being the protectors of Fundamental Rights
have, however, never hesitated to interdict orders of detention suffering from any of the vices on the
existence whereof such limited jurisdiction of judicial reviewability is available to be exercised.
11. At this stage, a survey of certain authorities outlining the contours of judicial reviewability of an
order of preventive detention may not be inapt.
12. Reading of paragraph 2 of the judgment authored by Hon’ble H.J. Kania, CJ., reveals that A.K.
Gopalan vs. State of Madras5 was the first case where the different articles on Fundamental Rights
came up for discussion before the Supreme Court. Detention was ordered under the Preventive
Detention Act, 1950 (“the Detention Act”, hereafter). The petitioner therein challenged the vires of
the enactment as well as the detention order. The decision of the Supreme Court by its full
complement of 6 (six) Hon’ble Judges rendered within 4 (four) months of India becoming a
Republic, revealed an approach of circumscribing Article 21 by a literal interpretation. Since then,
this Court in Rustomjee Cawasjee Cooper vs. Union of India6 has held that “the assumption in A.K.
Gopalan case that certain articles in the Constitution exclusively deal with specific matters and in
determining whether there is infringement of the individual’s guaranteed rights, the object and the
form of the State action alone need be considered, and effect of the laws on fundamental rights of
the individuals in general will be ignored cannot be accepted as correct”, and it being settled law AIR
1950 SC 27 AIR 1970 SC 564 that the new needs of a person for liberty in the different spheres of lifeAmeena Begum vs The State Of Telangana on 4 September, 2023

can now be claimed as a part of personal liberty under Article 21 and these personal liberties cannot
be restricted either by legislation or law not satisfying Articles 14 and 19, we need not at all be
guided by the view expressed in A.K. Gopalan (supra). Suffice it to observe that A.K. Gopalan
(supra) was decided by this Court at the dawn of the Constitution, keeping in mind the then social
realities, when the true and correct interpretation of the Constitution was yet to take shape and also
without the benefit of any precedent on the point, which permits understanding of various points of
view of Hon’ble Judges and thereby makes it easy for successors to evolve the dynamic facets of the
Fundamental Rights enshrined in the Constitution.
13. This Court in Shibban Lal Saksena vs. State of Uttar Pradesh7 speaking through Hon’ble B.K.
Mukherjea, J. (as the Chief Justice then was) quashed an order of preventive detention under the
Detention Act reasoning that if one of the two grounds for ordering detention was illegal, the order
of detention could not survive on the other ground. Law was laid down in the following words:
“8. The first contention raised by the learned counsel raises, however, a somewhat
important point which requires careful consideration. It has been repeatedly held by
this Court that the power to issue a detention order under Section 3 of the Preventive
Detention Act depends entirely upon the satisfaction of the appropriate authority
specified in that section. The sufficiency of the grounds upon which such satisfaction
purports to be based, provided they have a rational probative value and are not
extraneous to the scope or purpose of the legislative provision AIR 1954 SC 179
cannot be challenged in a court of law, except on the ground of malafides. A court of
law is not even competent to enquire into the truth or otherwise of the facts which are
mentioned as grounds of detention in the communication to the detenue under
Section 7 of the Act. What has happened, however, in this case is somewhat peculiar.
The Government itself in its communication dated 13-3- 1953, has plainly admitted
that one of the grounds upon which the original order of detention was passed is
unsubstantial or non- existent and cannot be made a ground of detention. The
question is, whether in such circumstances the original order made under Section
3(1)(a) of the Act can be allowed to stand. The answer, in our opinion, can only be in
the negative. The detaining authority gave here two grounds for detaining the
petitioner. We can neither decide whether these grounds are good or bad, nor can we
attempt to assess in what manner and to what extent each of these grounds operated
on the mind of the appropriate authority and contributed to the creation of the
satisfaction on the basis of which the detention order was made. To say that the other
ground, which still remains, is quite sufficient to sustain the order, would be to
substitute an objective judicial test for the subjective decision of the executive
authority which is against the legislative policy underlying the statute. In such cases,
we think, the position would be the same as if one of these two grounds was
irrelevant for the purpose of the Act or was wholly illusory and this would vitiate the
detention order as a whole. ***”
14. In Rameshwar Shaw vs. District Magistrate8, a Constitution Bench speaking through Hon’ble
P.B. Gajendragadkar, J. (as the Chief Justice then was) in course of interdicting an order ofAmeena Begum vs The State Of Telangana on 4 September, 2023

detention passed under section 3 of the Detention Act held as follows:
“7. There is also no doubt that if any of the grounds furnished to the detenu are found
to be irrelevant while considering the application of clauses (i) to (iii) of Section
3(1)(a) and in that sense are foreign to the Act, the satisfaction of the detaining
authority on which the order of detention is based is open to challenge and the
detention order liable to be quashed. Similarly, if some of the grounds supplied to the
detenu are so vague that they would virtually deprive the detenu of his statutory right
of making a representation that again may introduce a serious infirmity in the order
of his detention. If, however, the grounds on which the order of detention proceeds
are relevant and germane to the matters which fall to be considered under Section
3(1)(a), AIR 1964 SC 334 it would not be open to the detenu to challenge the order of
detention by arguing that the satisfaction of the detaining authority is not reasonably
based on any of the said grounds.
8. It is, however, necessary to emphasise in this connection that though the
satisfaction of the detaining authority contemplated by Section 3(1)(a) is the
subjective satisfaction of the said authority, cases may arise where the detenu may
challenge the validity of his detention on the ground of mala fides and in support of
the said plea urge that along with other facts which show mala fides the Court may
also consider his grievance that the grounds served on him cannot possibly or
rationally support the conclusion drawn against him by the detaining authority. It is
only in this incidental manner and in support of the plea of mala fides that this
question can become justiciable; otherwise the reasonableness or propriety of the
said satisfaction contemplated by Section 3(1)(a) cannot be questioned before the
Courts.”
15. In his Counter Affidavit (at pgs. 10 and 11) to the special leave petition, the Commissioner
referred to, and extracted a passage from paragraph 8 of the decision of this Court in Khudiram Das
vs. The State of West Bengal9, wherein a Bench of 4 (four) Hon’ble Judges of this Court was
examining a challenge to an order of detention passed under section 3 of the Maintenance of
Internal Security Act, 1971 (“MISA”, hereafter) by a district magistrate. We consider it appropriate
to notice not only paragraph 8 of the decision rendered by Hon’ble P.N. Bhagwati, J. (as His
Lordship then was) in its entirety but also paragraph 9, reading as follows:
“8. Now it is clear on a plain reading of the language of sub- sections (1) and (2) of
Section 3 that the exercise of the power of detention is made dependent on the
subjective satisfaction of the detaining authority that with a view to preventing a
person from acting in a prejudicial manner, as set out in sub-clauses (i), (ii) and (iii)
of clause (a) of sub-section (1), it is necessary to detain such person. The words used
in sub-sections (1) and (2) of Section 3 are ‘if satisfied’ and they clearly import
subjective satisfaction (1975) 2 SCC 81 on the part of the detaining authority before
an order of detention can be made. And it is so provided for a valid reason which
becomes apparent if we consider the nature of the power of detention and theAmeena Begum vs The State Of Telangana on 4 September, 2023

conditions on which it can be exercised. The power of detention is clearly a
preventive measure. It does not partake in any manner of the nature of punishment.
It is taken by way of precaution to prevent mischief to the community. Since every
preventive measure is based on the principle that a person should be prevented from
doing something which, if left free and unfettered, it is reasonably probable he would
do, it must necessarily proceed in all cases, to some extent, on suspicion or
anticipation as distinct from proof. Patanjali Sastri, C.J. pointed out in State of
Madras v. V.G. Row [(1952) 1 SCC 410 : AIR 1952 SC 196 : 1952 SCR 597] that
preventive detention is ‘largely precautionary and based on suspicion’ and to these
observations may be added the following words uttered by the learned Chief Justice
in that case with reference to the observations of Lord Finlay in Rex v. Halliday [1917
AC 260] namely, that ‘the court was the least appropriate tribunal to investigate into
circumstances of suspicion on which such anticipatory action must be largely based’.
This being the nature of the proceeding, it is impossible to conceive how it can possibly be regarded
as capable of objective assessment. The matters which have to be considered by the detaining
authority are whether the person concerned, having regard to his past conduct judged in the light of
the surrounding circumstances and other relevant material, would be likely to act in a prejudicial
manner as contemplated in any of sub-clauses (i),
(ii) and (iii) of clause (1) of sub-section (1) of Section 3, and if so, whether it is necessary to detain
him with a view to preventing him from so acting. These are not matters susceptible of objective
determination and they could not be intended to be judged by objective standards. They are
essentially matters which have to be administratively determined for the purpose of taking
administrative action. Their determination is, therefore, deliberately and advisedly left by the
Legislature to the subjective satisfaction of the detaining authority which by reason of its special
position, experience and expertise would be best fitted to decide them. It must in the circumstances
be held that the subjective satisfaction of the detaining authority as regards these matters
constitutes the foundation for the exercise of the power of detention and the Court cannot be invited
to consider the propriety or sufficiency of the grounds on which the satisfaction of the detaining
authority is based. The Court cannot, on a review of the grounds, substitute its own opinion for that
of the authority, for what is made a condition precedent to the exercise of the power of detention is
not an objective determination of the necessity of detention for a specified purpose but the
subjective opinion of the detaining authority, and if a subjective opinion is formed by the detaining
authority as regards the necessity of detention for a specified purpose, the condition of exercise of
the power of detention would be fulfilled. This would clearly show that the power of detention is not
a quasi-judicial power.
9. But that does not mean that the subjective satisfaction of the detaining authority is wholly
immune from judicial reviewability. The courts have by judicial decisions carved out an area, limited
though it be, within which the validity of the subjective satisfaction can yet be subjected to judicial
scrutiny. The basic postulate on which the courts have proceeded is that the subjective satisfaction
being a condition precedent for the exercise of the power conferred on the Executive, the Court can
always examine whether the requisite satisfaction is arrived at by the authority : if it is not, theAmeena Begum vs The State Of Telangana on 4 September, 2023

condition precedent to the exercise of the power would not be fulfilled and the exercise of the power
would be bad. There are several grounds evolved by judicial decisions for saying that no subjective
satisfaction is arrived at by the authority as required under the statute. The simplest case is whether
the authority has not applied its mind at all; in such a case the authority could not possibly be
satisfied as regards the fact in respect of which it is required to be satisfied. Emperor v. Shibnath
Bannerji [AIR 1943 FC 75 : 1944 FCR 1 : 45 Cri LJ 341] is a case in point. Then there may be a case
where the power is exercised dishonestly or for an improper purpose : such a case would also
negative the existence of satisfaction on the part of the authority. The existence of ‘improper
purpose’, that is, a purpose not contemplated by the statute, has been recognised as an independent
ground of control in several decided cases. The satisfaction, moreover, must be a satisfaction of the
authority itself, and therefore, if, in exercising the power, the authority has acted under the dictation
of another body as the Commissioner of Police did in Commissioner of Police v. Gordhandas Bhanji
[1951 SCC 1088 : AIR 1952 SC 16 : 1952 SCR 135] and the officer of the Ministry of Labour and
National Service did in Simms Motor Units Ltd. v. Minister of Labour and National Service [(1946)
2 All ER 201] the exercise of the power would be bad and so also would the exercise of the power be
vitiated where the authority has disabled itself from applying its mind to the facts of each individual
case by self-created rules of policy or in any other manner. The satisfaction said to have been arrived
at by the authority would also be bad where it is based on the application of a wrong test or the
misconstruction of a statute. Where this happens, the satisfaction of the authority would not be in
respect of the thing in regard to which it is required to be satisfied. Then again the satisfaction must
be grounded ‘on materials which are of rationally probative value’. Machindar v. King [AIR 1950 FC
129 : 51 Cri LJ 1480 : 1949 FCR 827]. The grounds on which the satisfaction is based must be such
as a rational human being can consider connected with the fact in respect of which the satisfaction is
to be reached. They must be relevant to the subject-matter of the inquiry and must not be
extraneous to the scope and purpose of the statute. If the authority has taken into account, it may
even be with the best of intention, as a relevant factor something which it could not properly take
into account in deciding whether or not to exercise the power or the manner or extent to which it
should be exercised, the exercise of the power would be bad. Pratap Singh v. State of Punjab [AIR
1964 SC 72 : (1964) 4 SCR 733]. If there are to be found in the statute expressly or by implication
matters which the authority ought to have regard to, then, in exercising the power, the authority
must have regard to those matters. The authority must call its attention to the matters which it is
bound to consider.” (underlining ours, for emphasis)
16. In Icchu Devi Choraria vs. Union of India10, the judicial commitment to strike down illegal
detention, even when the petition on which Rule was issued did not have the requisite pleadings,
was highlighted in the following words:
“5. *** Where large masses of people are poor, illiterate and ignorant and access to
the courts is not easy on account of lack of financial resources, it would be most
unreasonable to insist that the petitioner should set out clearly and specifically the
grounds on which he challenges the order of detention and make out a prima facie
case in support of those grounds before a rule is issued or to hold that the detaining
authority should not be liable to do any thing more than just meet the specific
grounds of challenge put forward by the petitioner in the petition. The burden ofAmeena Begum vs The State Of Telangana on 4 September, 2023

showing that the detention is in accordance with the procedure established by law
has always been placed by this Court on the detaining authority because Article 21 of
the Constitution provides in clear and explicit terms that no one shall be deprived of
his life or personal liberty except in accordance with procedure established by law.
This constitutional right of life and personal liberty is placed on such a high pedestal
by this Court that it has always insisted that whenever there is any deprivation of life
or personal liberty, the authority responsible for such deprivation must satisfy the
court that it has acted in accordance with the law. This is an area where the court has
been most strict and scrupulous in ensuring observance with the requirements of the
law, and even where a requirement of the law is breached in the slightest measure,
the court has not (1980) 4 SCC 531 hesitated to strike down the order of detention or
to direct the release of the detenu even though the detention may have been valid till
the breach occurred. The court has always regarded personal liberty as the most
precious possession of mankind and refused to tolerate illegal detention, regardless
of the social cost involved in the release of a possible renegade.” (underlining ours,
for emphasis)
17. In a different context, we may take note of the decision in Sama Aruna vs. State of Telangana11
where, S.A. Bobde, J. (as the Chief Justice then was) while construing the provisions of the Act,
held:
“16. There is little doubt that the conduct or activities of the detenu in the past must
be taken into account for coming to the conclusion that he is going to engage in or
make preparations for engaging in such activities, for many such persons follow a
pattern of criminal activities. But the question is how far back? There is no doubt that
only activities so far back can be considered as furnish a cause for preventive
detention in the present. That is, only those activities so far back in the past which
lead to the conclusion that he is likely to engage in or prepare to engage in such
activities in the immediate future can be taken into account.” In holding that the
order of detention therein was grounded on stale grounds, the Court held that:
“The detention order must be based on a reasonable prognosis of the future
behaviour of a person based on his past conduct in light of the surrounding
circumstances. The live and proximate link that must exist between the past conduct
of a person and the imperative need to detain him must be taken to have been
snapped in this case. A detention order which is founded on stale incidents, must be
regarded as an order of punishment for a crime, passed without a trial, though
purporting to be an order of preventive detention. The essential concept of preventive
detention is that the detention of a person is not to punish him for something he has
done but to prevent him from doing it.” (underlining ours, for emphasis) (2018) 12
SCC 150
18. This was further affirmed by this Court in Khaja Bilal Ahmed vs. State of Telangana12, where the
detention order dated 2nd November, 2018 issued under the Act had delved into the history of casesAmeena Begum vs The State Of Telangana on 4 September, 2023

involving the appellant-detenu from the years 2007 - 2016, despite the subjective satisfaction of the
Officer not being based on such cases. In quashing such an order, Hon’ble Dr. D.Y. Chandrachud, J.
(as the Chief Justice then was) observed:
“23. *** If the pending cases were not considered for passing the order of detention,
it defies logic as to why they were referred to in the first place in the order of
detention. The purpose of the Telangana Offenders Act 1986 is to prevent any person
from acting in a manner prejudicial to the maintenance of public order. For this
purpose, Section 3 prescribes that the detaining authority must be satisfied that the
person to be detained is likely to indulge in illegal activities in the future and act in a
manner prejudicial to the maintenance of public order. The satisfaction to be arrived
at by the detaining authority must not be based on irrelevant or invalid grounds. It
must be arrived at on the basis of relevant material; material which is not stale and
has a live link with the satisfaction of the detaining authority. The order of detention
may refer to the previous criminal antecedents only if they have a direct nexus or link
with the immediate need to detain an individual. If the previous criminal activities of
the Appellant could indicate his tendency or inclination to act in a manner prejudicial
to the maintenance of public order, then it may have a bearing on the subjective
satisfaction of the detaining authority. However, in the absence of a clear indication
of a causal connection, a mere reference to the pending criminal cases cannot account
for the requirements of Section 3. It is not open to the detaining authority to simply
refer to stale incidents and hold them as the basis of an order of detention. Such stale
material will have no bearing on the probability of the detenu engaging in prejudicial
activities in the future.” (bold in original) (underlining ours, for emphasis) (2020) 13
SCC 632
19. We may also refer to the decision of a Constitution Bench of this Court in Sunil Fulchand Shah
vs. Union of India13 wherein the need to strictly adhere to the timelines, provided as procedural
safeguards, was stressed upon. It was held thus:
“11. *** The safeguards available to a person against whom an order of detention has
been passed are limited and, therefore, the courts have always held that all the
procedural safeguards provided by the law should be strictly complied with. Any
default in maintaining the time-limit has been regarded as having the effect of
rendering the detention order or the continued detention, as the case may be, illegal.
The justification for preventive detention being necessity a person can be detained
only so long as it is found necessary to detain him. If his detention is found
unnecessary, even during the maximum period permissible under the law then he has
to be released from detention forthwith. It is really in this context that Section 10 and
particularly the words ‘may be detained’ shall have to be interpreted.”
20. On a conspectus of the decisions referred to above and other decisions on preventive detention,
we may observe here that the argument commonly advanced on behalf of detaining authorities in
the early days of the Constitution was that the Court’s enquiry ought to be confined to whether thereAmeena Begum vs The State Of Telangana on 4 September, 2023

is an order of detention or not and the moment such an order, good on its face, is produced, all
enquiry into good faith, sufficiency of the reasons or the legality or illegality of the action comes to
an end. However, with passage of time, and expansion and development of law, it is no longer the
law that a preventive detention action, howsoever lawful it might appear on its face, cannot be
invalidated by the Constitutional Courts. This is so, as at present, there is no administrative order
affecting rights of the subjects that can (2000) 3 SCC 409 legitimately claim to be impregnably
guarded by a protective shield, which judicial scrutiny cannot penetrate.
21. Apart from the aforesaid decisions, multiple decisions have been rendered by this Court over the
years which provide suitable guidance to us to complete the present exercise; however, we wish to
conclude this discussion by referring to one decision of this Court delivered little in excess of a
decade back by a Bench of 3-Judges.
22. In Rekha vs. State of Tamil Nadu14, this Court observed that:
“21. It is all very well to say that preventive detention is preventive not punitive. The
truth of the matter, though, is that in substance a detention order of one year (or any
other period) is a punishment of one year’s imprisonment. What difference is it to the
detenu whether his imprisonment is called preventive or punitive?
(italics in original) ***
29. Preventive detention is, by nature, repugnant to democratic ideas and an
anathema to the Rule of law. No such law exists in the USA and in England (except
during war time). Since, however, Article 22(3)(b) of the Constitution of India
permits preventive detention, we cannot hold it illegal but we must confine the power
of preventive detention within very narrow limits, otherwise we will be taking away
the great right to liberty guaranteed by Article 21 of the Constitution of India which
was won after long, arduous and historic struggles. It follows, therefore, that if the
ordinary law of the land (the Penal Code and other penal statutes) can deal with a
situation, recourse to a preventive detention law will be illegal.”
23. There could be little doubt with the thought process that although the executive would pass an
order under the preventive detention laws as (2011) 5 SCC 244 a preventive or a precautionary
measure, its effect viewed strictly from the stand point of the detenu is simply and plainly punitive.
Significantly, an order of detention is not relatable to an alleged commission of offence which a
court is seized of and, thus, the conduct of the accused complained of is yet to be found
blameworthy; on the contrary, since it relates to an anticipated offence based on past conduct, the
detenu could well feel that he is at the receiving end of a subjective satisfaction of the executive
despite he not being proved to be on the wrong side of the law on any previous occasion. If someone
loses his liberty and lands up in prison not having a semblance of a chance to resist or protest, the
very circumstance of being put behind bars for such period as specified in the order of detention
based on an anticipation that an offence is likely to be committed by him seems to be an aspect
which does not sync with the norms and ethos of our very own Constitution and the decisions of thisAmeena Begum vs The State Of Telangana on 4 September, 2023

Court in which the concept of ‘LIFE’ has been explained in such a manner that ‘LIFE’ has been
infused in the letters of Article 21 (see Common Cause vs. Union of India15). Nonetheless, so long
clause (3) of Article 22 of the Constitution itself authorises detention as a preventive measure, there
can be no two opinions that none can take exception to such a measure being adopted and it is only
a limited judicial review by the Constitutional Courts that can be urged by an aggrieved detenu
wherefor too, in examining challenges to orders of preventive detention, the Courts would be loath
to interfere with or substitute their (1999) 6 SCC 667 own reasoning for the subjective satisfaction
arrived at by the detaining authority. Since the object of a preventive detention law is not punitive
but preventive and precautionary, ordinarily it is best left to the discretion of the detaining
authority.
24. We, however, hasten to observe here that though the decision in Rekha (supra) reflects on an
important aspect of loss of liberty without trial by taking recourse to preventive detention laws, the
decision of the Constitution Bench in Haradhan Saha (supra) still holds the field and to the extent
the learned Judges in Rekha (supra) sound a note discordant with the law laid down in Haradhan
Saha (supra) ought not to be construed as acceptance by us as the correct exposition of law.
25. Be that as it may, culling out the principles of law flowing from all the relevant decisions in the
field, our understanding of the law for deciding the legality of an order of preventive detention is
that even without appropriate pleadings to assail such an order, if circumstances appear therefrom
raising a doubt of the detaining authority misconceiving his own powers, the Court ought not to shut
its eyes; even not venturing to make any attempt to investigate the sufficiency of the materials, an
enquiry can be made by the Court into the authority’s notions of his power. Without being remotely
concerned about the sufficiency or otherwise of the materials on which detention has been ordered,
the Court would be justified to draw a conclusion, on proof from the order itself, that the detaining
authority failed to realize the extent of his own powers. This is quite apart from questioning the
action for want of sufficient materials that were before the detaining authority. The authority for the
detention is the order of detention itself, which the detenu or the Court can read. Such a reading of
the order would disclose the manner in which the activity of the detenu was viewed by the detaining
authority to be prejudicial to maintenance of public order and what exactly he intended should not
be permitted to happen. Any order of a detaining authority evincing that the same runs beyond his
powers, as are actually conferred, would not amount to a valid order made under the governing
preventive detention law and be vulnerable on a challenge being laid. In the circumstances of a
given case, a Constitutional Court when called upon to test the legality of orders of preventive
detention would be entitled to examine whether
(i) the order is based on the requisite satisfaction, albeit subjective, of the detaining authority, for,
the absence of such satisfaction as to the existence of a matter of fact or law, upon which validity of
the exercise of the power is predicated, would be the sine qua non for the exercise of the power not
being satisfied;
(ii) in reaching such requisite satisfaction, the detaining authority has applied its mind to all
relevant circumstances and the same is not based on material extraneous to the scope and purpose
of the statute;Ameena Begum vs The State Of Telangana on 4 September, 2023

(iii) power has been exercised for achieving the purpose for which it has been conferred, or exercised
for an improper purpose, not authorised by the statute, and is therefore ultra vires;
(iv) the detaining authority has acted independently or under the dictation of another body;
(v) the detaining authority, by reason of self-created rules of policy or in any other manner not
authorized by the governing statute, has disabled itself from applying its mind to the facts of each
individual case;
(vi) the satisfaction of the detaining authority rests on materials which are of rationally probative
value, and the detaining authority has given due regard to the matters as per the statutory mandate;
(vii) the satisfaction has been arrived at bearing in mind existence of a live and proximate link
between the past conduct of a person and the imperative need to detain him or is based on material
which is stale;
(viii) the ground(s) for reaching the requisite satisfaction is/are such which an individual, with some
degree of rationality and prudence, would consider as connected with the fact and relevant to the
subject-matter of the inquiry in respect whereof the satisfaction is to be reached;
(ix) the grounds on which the order of preventive detention rests are not vague but are precise,
pertinent and relevant which, with sufficient clarity, inform the detenu the satisfaction for the
detention, giving him the opportunity to make a suitable representation; and
(x) the timelines, as provided under the law, have been strictly adhered to.
Should the Court find the exercise of power to be bad and/or to be vitiated applying any of the tests
noted above, rendering the detention order vulnerable, detention which undoubtedly visits the
person detained with drastic consequences would call for being interdicted for righting the wrong.
ANALYSIS AND DECISION
26. Since in the present case power under section 3 of the Act was exercised, it is reproduced
hereunder for facility of reference:
“3. (1) The Government may, if satisfied with respect to any boot- legger, dacoit,
drug-offender, goonda, immoral traffic offender, Land-Grabber, Spurious Seed
Offender, Insecticide Offender, Fertilizer Offender, Food Adulteration Offender, Fake
Document Offender, Scheduled Commodities Offender, Forest Offender, Gaming
Offender, Sexual Offender, Explosive Substances Offender, Arms Offender, Cyber
Crime Offender and White Collar or Financial Offender, that with a view to
preventing him from acting in any manner prejudicial to the maintenance of public
order, it is necessary so to do, make an order directing that such person be detained.Ameena Begum vs The State Of Telangana on 4 September, 2023

(2) If, having regard to the circumstances prevailing or likely to prevail in any area
within the local limits of the jurisdiction of a District Magistrate or a Commissioner
of Police, the Government are satisfied that it is necessary so to do, they may, by
order in writing, direct that during such period as may be specified in the order, such
District Magistrate or Commissioner of Police may also, if satisfied as provided in
sub-section (1), exercise the powers conferred by the said sub-section:
Provided that the period specified in the order made by the Government under this
sub-section shall not in the first instance, exceed three months, but the Government
may, if satisfied as aforesaid that it is necessary so to do, amend such order to extend
such period from time to time by any period not exceeding three months at any one
time.
(3) When any order is made under this section by an officer mentioned in sub-section
(2), he shall forthwith report the fact to the Government together with the grounds on
which the order has been made and such other particulars as in his opinion, have a
bearing on the matter, and no such order shall remain in force for more than twelve
days after the making thereof, unless, in the mean time, it has been approved by the
Government.” The word used in sub-sections (1) and (2) of section 3 is “satisfied” and
it clearly imports subjective satisfaction on the part of the detaining authority before
an order of detention can be made.
27. We now proceed to examine the Detention Order passed by the Commissioner on 24th March,
2023 under section 3(2) of the Act and whether such ‘subjective satisfaction’ of the Commissioner
stands scrutiny on application of the requisite tests.
28. In the present case, the Detention Order was based on 5 (five) distinct offences, of which there is
a crime allegedly committed by the Detenu in relation to a minor girl. Crimes have also been
registered on allegations of cheating, and obstructing a public official from discharging his duty, as
well as a crime has been registered involving dacoity. In Crime Nos. 262/2022, 18/2023 and
35/2023, charge-sheets are yet to be filed and the Detenu has been released on bail whereas in
regard to Crime Nos. 338/2022 and 227/2022, charge-sheets have been filed without even arresting
him.
29. The issues with the Detention Order which we need to address are these: first, whether the
alleged acts of commission for which the Detenu has been kept under detention are prejudicial to
‘public order’ and secondly, whether all relevant circumstances were considered or whether
extraneous factors weighed in the mind of the detaining authority leading to the conclusion that the
Detenu is a habitual offender and for prevention of further crimes by him, he ought to be detained.
Incidentally, the issue of whether application of mind is manifest in first ordering detention and
then confirming it by continuing such order for a period of 12 (twelve) months upon rejection of the
representation filed on behalf of the Detenu by the appellant could also be answered. Needless to
observe, we need not examine the second and the incidental issues if the appeal succeeds on the first
issue.Ameena Begum vs The State Of Telangana on 4 September, 2023

30. Addressing the first issue first, it has to be understood as a fundamental imperative as to how
this Court has distinguished between disturbances relatable to “law and order” and disturbances
caused to “public order”.
31. It is trite that breach of law in all cases does not lead to public disorder.
In a catena of judgments, this Court has in clear terms noted the difference between “law and order”
and “public order”.
32. We may refer to the decision of the Constitution Bench of this Court in Ram Manohar Lohia vs.
State of Bihar16, where the difference between “law and order” and “public order” was lucidly
expressed by Hon’ble M. Hidayatullah, J. (as the Chief Justice then was) in the following words:
“54. *** Public order if disturbed, must lead to public disorder. Every breach of the
peace does not lead to public disorder. When two drunkards quarrel and fight there is
disorder but not public disorder. They can be dealt with under the powers to
maintain law and order but cannot be detained on the ground that they were
disturbing public order. Suppose that the two fighters were of rival communities and
one of them tried to raise communal passions. The problem is still one of law and
order but it raises the apprehension of public disorder. Other examples can be
imagined. The contravention of law always affects order but before it can be said to
affect public order, it must affect the community or the public at large. A mere
disturbance of law and order leading to disorder is thus not necessarily sufficient for
action under the Defence of India Act but disturbances which subvert the public
order are.
55. It will thus appear that just as ‘public order’ in the rulings of this Court (earlier
cited) was said to comprehend disorders of less gravity than those affecting ‘security
of State’, ‘law and order’ also comprehends disorders of less gravity than those
affecting ‘public order’. One has to imagine three concentric circles. Law and order
represents the largest circle within which is the next circle representing public order
and the smallest circle represents security of State. It is then easy to see that an act
may affect law and order but not public order just as an act may affect public order
but not security of the State.” (underlining ours, for emphasis) (1966) 1 SCR 709
33. For an act to qualify as a disturbance to public order, the specific activity must have an impact
on the broader community or the general public, evoking feelings of fear, panic, or insecurity. Not
every case of a general disturbance to public tranquillity affects the public order and the question to
be asked, as articulated by Hon’ble M. Hidayatullah, CJ. in Arun Ghosh vs. State of West Bengal17,
is this: “Does it [read:
the offending act] lead to disturbance of the current of life of the community so as to
amount a disturbance of the public order or does it affect merely an individual
leaving the tranquillity of the society undisturbed?” In that case, the petitioningAmeena Begum vs The State Of Telangana on 4 September, 2023

detenu was detained by an order of a district magistrate since he had been indulging
in teasing, harassing and molesting young girls and assaults on individuals of a
locality. While holding that the conduct of the petitioning detenu could be
reprehensible, it was further held that it (read: the offending act) “does not add up to
the situation where it may be said that the community at large was being disturbed or
in other words there was a breach of public order or likelihood of a breach of public
order”. In the process of quashing the impugned order, the Chief Justice while
referring to the decision in Ram Manohar Lohia (supra) also ruled:
“3. *** Public order was said to embrace more of the community than law and order.
Public order is the even tempo of the life of the community taking the country as a
whole or even a specified locality. Disturbance of public order is to be distinguished
from acts directed against individuals which do not disturb the society to the extent
of causing a general disturbance of public tranquillity. It is the degree of disturbance
and its affect upon the life of the community in a locality which determines whether
the disturbance (1970) 1 SCC 98 amounts only to a breach of law and order. … It is
always a question of degree of the harm and its affect upon the community.
… This question has to be faced in every case on facts. There is no formula by which one case can be
distinguished from another.”
34. In Kuso Sah vs. The State of Bihar18, Hon’ble Y.V. Chandrachud, J.
(as the Chief Justice then was) speaking for the Bench held that:
“4. *** The two concepts have well defined contours, it being well established that
stray and unorganised crimes of theft and assault are not matters of public order
since they do not tend to affect the even flow of public life. Infractions of law are
bound in some measure to lead to disorder but every infraction of law does not
necessarily result in public disorder. ***
6. *** The power to detain a person without the safeguard of a court trial is too
drastic to permit a lenient construction and therefore Courts must be astute to ensure
that the detaining authority does not transgress the limitations subject to which alone
the power can be exercised. ***” (underlining ours, for emphasis)
35. Turning our attention to section 3(1) of the Act, the Government has to arrive at a subjective
satisfaction that a goonda (as in the present case) has to be detained, in order to prevent him from
acting in a manner prejudicial to the maintenance of public order. Therefore, we first direct
ourselves to the examination of what constitutes ‘public order’. Even within the provisions of the
Act, the term “public order” has, stricto sensu, been defined in narrow and restricted terms. An
order of detention under section 3(1) of the Act can only be issued against a detenu to prevent him
“from acting in any manner prejudicial to the maintenance of public order”. “Public order” is
defined in the (1974) 1 SCC 195 Explanation to section 2(a) of the Act as encompassing situationsAmeena Begum vs The State Of Telangana on 4 September, 2023

that cause “harm, danger or alarm or a feeling of insecurity among the general public or any section
thereof or a grave wide-spread danger to life or public health”.
36. Ram Manohar Lohia (supra) is an authority to rely upon for the proposition that if liberty of an
individual can be invaded under statutory rules by the simple process of making of a certain order,
he can be so deprived only if the order is in consonance with the said rule. Strict compliance with the
letter of the rule, in such a case, has to be the essence of the matter since the statute has the
potentiality to interfere with the personal liberty of an individual and a Court is precluded from
going behind its face. Though circumstances may make it necessary for ordering a detention without
trial, but it would be perfectly legitimate to require strict observance of the rules in such cases. If
there is any doubt whether the rules have been strictly observed, that doubt must be resolved in
favour of the detenu.
37. Rekha too (supra) provides a useful guide. It is said in paragraph 30 that:
“30. Whenever an order under a preventive detention law is challenged one of the
questions the court must ask in deciding its legality is: was the ordinary law of the
land sufficient to deal with the situation? If the answer is in the affirmative, the
detention order will be illegal. In the present case, the charge against the detenu was
of selling expired drugs after changing their labels. Surely the relevant provisions in
the Penal Code and the Drugs and Cosmetics Act were sufficient to deal with this
situation. Hence, in our opinion, for this reason also the detention order in question
was illegal.”
38. At this stage, it would be useful to consider certain events anterior to the Detention Order but
referred to therein. The earlier order of detention dated 4th March, 2021 was challenged by the
Detenu’s father before the High Court. Such order of detention was passed considering 4 (four) FIRs
under sections 420 and 406 of the IPC, wherein the Detenu was arraigned as an accused. In its
reasoned judgment dated 16th August, 2021, the High Court noted this Court having opined in a
catena of decisions that there is a vast difference between “law and order” and “public order”; when
offences are committed against a particular individual it falls within the ambit of “law and order”
whereas when the public at large is adversely affected by the criminal activities of a person, then
such conduct of the person is said to disturb “public order”. Holding that the true distinction
between the areas of ‘law and order’ and ‘public order’ lies not merely in the nature or quality of the
act, but in the proper degree and extent of its impact on the society, it was ruled that the cases do
not fall within the ambit of the words “public order” or “disturbance of public order”, instead, they
fall within the scope of the words “law and order”, and that there was no need for the detaining
authority to pass the impugned order. Based thereon, the impugned order was quashed and the
Detenu set at liberty.
39. In fine, what we find is that the order of detention impugned in that writ petition failed to
differentiate between offences which create a “law and order” situation and which prejudicially
affect or tend to prejudicially affect “public order”. The present Detention Order fares no better.
Even if the offences referred to in the Detention Order, alleged to have been committed by theAmeena Begum vs The State Of Telangana on 4 September, 2023

Detenu have led to the satisfaction being formed, still the same are separate and stray acts affecting
private individuals and the repetition of similar such acts would not tend to affect the even flow of
public life. The offence in respect of the minor girl did exercise our consideration for some time but
we have noted that the Detenu was not arrested because of an order passed by the High Court on an
application under section 438 of the Criminal Procedure Code (“Cr. PC”, hereafter). The
investigating agency not having elected to have such order quashed by a higher forum, the facts have
their own tale to tell. Even otherwise, the gravity of the offences alleged in Arun Ghosh (supra) was
higher in degree, yet, the same were not considered as affecting ‘public order’. The only other
offence that could attract the enumerated category of “acting in any manner prejudicial to the
maintenance of public order” and an order of preventive detention, if at all, is the stray incident
where the Detenu has been charged under section 353, IPC and where the police has not even
contemplated an arrest under section 41 of the Cr. PC.
40. On an overall consideration of the circumstances, it does appear to us that the existing legal
framework for maintaining law and order is sufficient to address like offences under consideration,
which the Commissioner anticipates could be repeated by the Detenu if not detained. We are also
constrained to observe that preventive detention laws—an exceptional measure reserved for tackling
emergent situations—ought not to have been invoked in this case as a tool for enforcement of “law
and order”. This, for the reason that, the Commissioner despite being aware of the earlier judgment
and order of the High Court dated 16th August, 2021 passed the Detention Order ostensibly to
maintain “public order” without once more appreciating the difference between maintenance of “law
and order” and maintenance of “public order”. The order of detention is, thus, indefensible.
41. We could have ended our judgment here, but having regard to the arguments advanced at the
Bar we wish to deal with the other issues too. This, we are persuaded to do, in order to remind the
authorities in the state of Telangana that the drastic provisions of the Act are not to be invoked at
the drop of a hat.
42. Now, we proceed with the second issue as to whether there was proper application of mind to all
relevant circumstances or whether consideration of extraneous factors has vitiated the Detention
Order.
43. Considering past criminal history, which is proximate, by itself would not render an order illegal.
The Commissioner in the Detention Order made pointed reference to the Detenu being a habitual
offender by listing 10 (ten) criminal proceedings in which the Detenu was involved during the years
2019-20, consequent to which the Detenu was preventively detained under the Act vide order of
detention dated 4th March, 2021, since quashed by the High Court by its order dated 16th August,
2021. It is then stated therein that the Detenu had committed 9 (nine) offences in the years
2022-23, and these offences are again listed out in detail. However, the Commissioner states that
the present order of detention is based only on 5 (five) out of these 9 (nine) crimes, which are
alleged to show that the Detenu’s activities are “prejudicial to the maintenance of public order, apart
from disturbing peace and tranquillity in the area.”Ameena Begum vs The State Of Telangana on 4 September, 2023

44. Interestingly, even in paragraph 9 E of his Counter Affidavit, the Commissioner has extracted a
portion of the Detention Order which we have set out in paragraph 3 (supra). The reiteration of
considering past criminal history of the Detenu is not without its effect, as we shall presently
discuss.
45. In Khudiram Das (supra), while examining the ‘history sheet’ of the detenu, this Court had, in
express terms, clarified that a generalisation could not be made that the detenu was in the habit of
committing those offences. Merely because the detenu was charged for multiple offences, it could
not be said that he was in the habit of committing such offences. Further, habituality of committing
offences cannot, in isolation, be taken as a basis of any detention order; rather it has to be tested on
the metrics of ‘public order’, as discussed above. Therefore, cases where such habituality has created
any ‘public disorder’ could qualify as a ground to order detention.
46. Although the Commissioner sought to project that he ordered detention based on the said 5
(five) FIRs, indication of the past offences allegedly committed by the Detenu in the Detention
Order having influenced his thought process is clear. With the quashing of the order of detention
dated 4th March, 2021 by the High Court and such direction having attained finality, it defies logic
why the Commissioner embarked on an elaborate narration of past offences, which are not relevant
to the grounds of the present order of detention. This is exactly what this Court in Khaja Bilal
Ahmed (supra) deprecated. Also, as noted above, this Court in Shibban Lal Saksena (supra) held
that such an order would be a bad order, the reason being that it could not be said in what manner
and to what extent the valid and invalid grounds operated on the mind of the authority concerned
and contributed to his subjective satisfaction forming the basis of the order.
47. It would not be out of place to examine, at this juncture, whether the Commissioner as the
detaining authority formed the requisite satisfaction in the manner required by law, i.e., by drawing
inference of a likelihood of the Detenu indulging in prejudicial activities on objective data. Here, we
would bear in mind the caution sounded by this Court in Rajesh Gulati vs. Govt. of NCT of Delhi19
that a detaining authority should be free from emotions, beliefs or prejudices while ordering
detention as well as take note of the judgment and order (2002) 7 SCC 129 dated 16th August, 2021
of the High Court on the previous writ petition, instituted by the Detenu’s father. On such writ
petition, the High Court held as follows:
“Under these circumstances, the apprehension of the detaining authority that since
the detenus were granted bail in all the crimes, there is imminent possibility of the
detenus committing similar offences which are detrimental to public order unless
they are prevented from doing so by an appropriate order of detention, is highly
misplaced. […] In the instant cases, since the detenus are released on bail, in the
event if it is found that the detenus are involved in further crimes, the prosecution
can apprise the same to the Court concerned and seek cancellation of bail. Moreover,
the criminal law was already set into motion against the detenus. Since the detenus
have allegedly committed offences punishable under the Indian Penal Code, the said
crimes can be effectively dealt with under the provisions of the Indian Penal Code.
The detaining authority cannot be permitted to subvert, supplant or substitute theAmeena Begum vs The State Of Telangana on 4 September, 2023

punitive law of land, by ready resort to preventive detention.”
48. Since the aforesaid order of the High Court went unchallenged and is, thus, binding upon the
parties, it was not open to the Commissioner to refer to the very same antecedent offences again in
the Detention Order under challenge. There was no direct nexus or link with the immediate need to
order detention and we hold extraneous considerations having found their way into the Detention
Order.
49. The other aspect requiring some guidance for detaining authorities and on which we wish to
comment is that there is no requirement in law of orders of detention being expressed in language
that would normally be considered elegant or artistic. An order of detention, which is capable of
comprehension, has to precisely set forth the grounds of detention without any vagueness. The
substance of the order and how it is understood by the detenu determines its nature. An order in
plain and simple language providing clarity of how the subjective satisfaction was formed is what a
detenu would look for, since the detenu has a right to represent against the order of detention and
claim that such order should not have been made at all. If the detenu fails to comprehend the
grounds of detention, the very purpose of affording him the opportunity to make a representation
could be defeated. At the same time, the detaining authority ought to ensure that the order does not
manifest consideration of extraneous factors. The detaining authority must be cautious and
circumspect that no extra or additional word or sentence finds place in the order of detention, which
evinces the human factor - his mindset of either acting with personal predilection by invoking the
stringent preventive detention laws to avoid or oust judicial scrutiny, given the restrictions of
judicial review in such cases, or as an authority charged with the notion of overreaching the courts,
chagrined and frustrated by orders granting bail to the detenu despite stiff opposition raised by the
State and thereby failing in the attempt to keep the detenu behind bars.
50. What we have expressed above is best exemplified by the observations of the Commissioner in
the Detention Order under challenge, which are considered appropriate to be quoted. Therein, the
Commissioner inter alia stated as follows:
“The proposed detenu and his associate are notorious offenders and rowdy sheeters.
… The proposed detenu was surrendered before the Hon'ble Court in Cr.No.35/2023
of Falaknuma PS and the Hon'ble Magistrate remanded him to judicial custody, he
moved bail petitions in Cr.Nos. 18/2023 of Golconda PS and 35/2023 of Falaknuma
PS. The prosecution has filed suitable counters strongly opposing the grant of bail to
him, but the Hon'ble Magistrate granted bail to him in both the cases and ordered for
his release. Subsequently, he was released from judicial remand on bail.
As seen from his past criminal history, background and antecedents and also his
habitual nature of committing crimes one after the other and his efforts to come out
of the prison, I strongly believe that if such a habitual criminal is set free, his
activities would not be safe to the society and there is an imminent possibility of his
committing similar offences by violating the bail conditions in one of the cases, which
would be detrimental to public order, unless he is preventively detained from doingAmeena Begum vs The State Of Telangana on 4 September, 2023

so by an appropriate order of detention.” With respect to the stage of proceedings in
the offences which form its basis, the Detention Order states that despite being
contested by the State, bail has been granted to the Detenu in Crimes No. 4 and 5.
Insofar as grant of bail to the Detenu is concerned, the Commissioner states that:
“I strongly believe that if such a habitual criminal is set free his activities would not
be safe to the society and there is an imminent possibility of his committing similar
offences by violating the bail conditions in one of the cases, which would be
detrimental to public order, unless he is preventively detained from doing so by an
appropriate order of detention.”
51. We are of the opinion that the aforesaid excerpts from the Detention Order lay bare the
Commissioner’s attempt to transgress his jurisdiction and to pass an order of detention, which
cannot be construed as an order validly made under the Act. The quoted observations are reflective
of the intention to detain the Detenu at any cost without resorting to due procedure. It is neither the
case of the respondents that the Detenu had not complied with the terms of the notice issued under
section 41-A of the Cr. PC, nor has it been alleged that the conditions of bail had been violated by the
Detenu. It is pertinent to note that in the three criminal proceedings where the Detenu had been
released on bail, no applications for cancellation of bail had been moved by the State. In the light of
the same, the provisions of the Act, which is an extraordinary statute, should not have been resorted
to when ordinary criminal law provided sufficient means to address the apprehensions leading to
the impugned Detention Order. There may have existed sufficient grounds to appeal against the bail
orders, but the circumstances did not warrant the circumvention of ordinary criminal procedure to
resort to an extraordinary measure of the law of preventive detention.
52. In Vijay Narain Singh vs. State of Bihar20, Hon’ble E.S. Venkataramiah, J. (as the Chief Justice
then was) observed:
32. ...It is well settled that the law of preventive detention is a hard law and therefore
it should be strictly construed. Care should be taken that the liberty of a person is not
jeopardised unless his case falls squarely within the four corners of the relevant law.
The law of preventive detention should not be used merely to clip the wings of an
Accused who is involved in a criminal prosecution. It is not intended for the purpose
of keeping a man under detention when under ordinary criminal law it may not be
possible to resist the issue of orders of bail, unless the material available is such as
would satisfy the requirements of the legal provisions authorising such detention.
When a person is enlarged on bail by a competent criminal court, great caution
should be exercised in scrutinising the validity of an order of preventive detention
which is based on the very same charge which is to be tried by the criminal court.”
(underlining ours, for emphasis) (1984) 3 SCC 14
53. Resonance of these principles are traceable in Banka Sneha Sheela vs. The State of Telangana21.
There, while examining an order of detention passed with reference to 5 (five) offences involving
sections 420, 406 and 506 of the IPC, in respect whereof the detenu had obtained orders ofAmeena Begum vs The State Of Telangana on 4 September, 2023

bail/anticipatory bail, this Court had the occasion to say that:
“A close reading of the Detention Order would make it clear that the reason for the
said Order is not any apprehension of widespread public harm, danger or alarm but
is only because the Detenu was successful in obtaining anticipatory bail/bail from the
Courts in each of the five FIRs. If a person is granted anticipatory bail/bail wrongly,
there are well-known remedies in the ordinary law to take care of the situation. The
State can always appeal against the bail order granted and/or apply for cancellation
of bail. The mere successful obtaining of anticipatory bail/bail orders being the real
ground for detaining the Detenu, there can be no doubt that the harm, danger or
alarm or feeling of security among the general public spoken of in Section 2(a) of the
Telangana Prevention of Dangerous Activities Act is make believe and totally absent
in the facts of the present case.” (underlining ours, for emphasis)
54. On the ground of consideration of extraneous materials too, the Detention Order is
unsustainable.
55. A pernicious trend prevalent in the state of Telangana has not escaped our attention. While the
Nation celebrates Azadi Ka Amrit Mahotsav to commemorate 75 years of independence from foreign
rule, some police officers of the said state who are enjoined with the duty to prevent crimes and are
equally responsible for protecting the rights of citizens as well, seem to be oblivious of the
Fundamental Rights guaranteed by the Constitution and are curbing the liberty and freedom of the
people. The (2021) 9 SCC 415 sooner this trend is put to an end, the better. Even this Court, in
Mallada K Sri Ram vs. State of Telangana22, while deciding an appeal arising from the state of
Telangana, had the occasion to observe:
“17. It is also relevant to note, that in the last five years, this Court has quashed over
five detention orders under the Telangana Act of 1986 for inter alia incorrectly
applying the standard for maintenance of public order and relying on stale materials
while passing the orders of detention. At least ten detention orders under the
Telangana Act of 1986 have been set aside by the High Court of Telangana in the last
one year itself. These numbers evince a callous exercise of the exceptional power of
preventive detention by the detaining authorities and the respondent-state. We direct
the respondents to take stock of challenges to detention orders pending before the
Advisory Board, High Court and Supreme Court and evaluate the fairness of the
detention order against lawful standards.
(underlining ours, for emphasis)
56. Interference by this Court with orders of detention, routinely issued under the Act, seems to
continue unabated. Even after Mallada K Sri Ram (supra), in another decision of fairly recent origin
in the case of Shaik Nazneen vs. The State of Telangana23, this Court set aside the impugned order
of detention dated 28th October, 2021 holding that seeking shelter under preventive detention law
was not the proper remedy.Ameena Begum vs The State Of Telangana on 4 September, 2023

57. It requires no serious debate that preventive detention, conceived as an extraordinary measure
by the framers of our Constitution, has been rendered ordinary with its reckless invocation over the
years as if it were available for use even in the ordinary course of proceedings. To unchain 2022 SCC
OnLine SC 424 Crl. Appeal No.908 of 2022, dated 22nd June 2023 the shackles of preventive
detention, it is important that the safeguards enshrined in our Constitution, particularly under the
‘golden triangle’ formed by Articles 14, 19 and 21, are diligently enforced.
58. Now, we proceed to answer the incidental issue raised before us. Seldom have we found orders
of detention continued, after the advice of the Advisory Board, for less than the maximum period
permissible under the relevant law. Consideration of the matter by the Advisory Board, which
consists of respectable members including retired High Court judges and those qualified to become
High Court judges, was conceived to act as a safety valve against abuse of power by the detaining
authority and/or to check the possibility of grave injustice being caused to a detenu. It is one thing
to say that the Advisory Board has expressed an opinion that there is sufficient cause for the
detention and, therefore, the detention has been continued; yet, it is quite another thing to say that
the detention should continue for the maximum permissible period. In the light of sub-section (2) of
section 11 read with sub-section (1) of section 12 of the Act, the period for which the detention
should continue is left to be specified by the Government with the stipulation in section 13 thereof
that the maximum period shall be 12 (twelve) months from the date of detention. This appears on a
plain reading of the relevant statutory provisions. That apart, Mr. Luthra is right in placing reliance
on the concurring judgment authored by Hon’ble B.K. Mukherjea, J. in Dattatraya Moreshwar
Pangarkar vs. State of Bombay24 that the AIR 1952 SC 181 duration for which a detenu is to be kept
in detention is for the detaining authority to decide and not the Advisory Board. The said opinion
finds approval in the decision of the Constitution Bench of this Court in A.K. Roy vs. Union of
India25. The period of detention and the terminal point has, therefore, to be decided by the
Government. Having observed the uncanny consistency of authorities continuing detention orders
under the preventive detention laws for the maximum permissible span of 12 (twelve) months from
the date of detention as a routine procedure, without the barest of application of mind, we think that
it is time to say a few words with a view to dissuade continuation of detention orders till the
maximum permissible duration unless some indication is provided therefor by the concerned
Government in the confirmation order.
59. Article 22(4) of the Constitution provides that a preventive detention law cannot authorise the
detention of a person for a period longer than 3 (three) months unless an Advisory Board has
reported before the expiration of the said period of 3 (three) months that there is, in its opinion,
sufficient cause for such detention. It is followed by a non- obstante clause which reads thus:
“Provided that nothing in this sub-clause shall authorise the detention of any person
beyond the maximum period prescribed by any law made by Parliament under
sub-clause (b) of clause (7)”
60. What section 13 of the Act, with which we are concerned, provides has been noticed in one of the
preceding paragraphs. However, the regular practice of the authorities treating the maximum period
of detention of (1982) 1 SCC 271 12 (twelve) months as the standard duration, in our view, could beAmeena Begum vs The State Of Telangana on 4 September, 2023

suggestive of a mechanical approach. Inherent in the conferment of power to extend detention for 12
(twelve) months is the discretion to make an order to be operative for any period lesser than the
maximum period.
61. Fagu Shaw vs. The State of West Bengal26 is another Constitution Bench decision of this Court
where challenge was laid to section 13 of the MISA. It was argued that section 13 is bad because it is
violative of the Fundamental Right under Article 14 of the Constitution for the reason that it has
conferred unlimited discretion on the detaining authority to fix the period of detention. Repelling
the challenge, this Court held:
“28. *** The maximum period of detention has been fixed by Section 13 and the
discretion to fix the duration within the maximum has been given to the Government
after considering all the relevant circumstances. Seeing that the maximum period of
detention has been fixed by Section 13 and that the discretion to fix the period of
detention in a particular case has to be exercised after taking into account a number
of imponderable circumstances, we do not think that there is any substance in the
argument that the power of Government to determine the period of detention is
discriminatory or arbitrary.”
62. In A.K. Roy (supra), the Court echoed the above view by holding that:
“77. Dr Ghatate's objection against Section 13 is that it provides for a uniform period
of detention of 12 months in all cases, regardless of the nature and seriousness of the
grounds on the basis of which the order of detention is passed. There is no substance
in this grievance because, any law of preventive detention has to provide for the
maximum period of detention, just as any punitive law like the Penal Code has to
provide for the maximum sentence which can be imposed for any offence. We should
have thought that it would have been wrong to fix a (1974) 4 SCC 152 minimum
period of detention, regardless of the nature and seriousness of the grounds of
detention. The fact that a person can be detained for the maximum period of 12
months does not place upon the detaining authority the obligation to direct that he
shall be detained for the maximum period. The detaining authority can always
exercise its discretion regarding the length of the period of detention.” (underlining
ours, for emphasis)
63. Whenever an accused is tried for an offence under a penal law which carries a maximum
sentence, the Court is obliged while imposing sentence to apply its mind to the specific facts and
circumstances of the case and to either impose maximum sentence or a lesser sentence. It has,
therefore, a discretion regarding imposition of sentence. We are inclined to the view that there could
be no warrant for the proposition that when it boils down to confirming an order of detention under
a preventive detention law, which is not punitive, the Government can seek immunity and enjoy an
unfettered, unguided and unlimited discretion in continuing detention for the maximum period
without even very briefly indicating its mind as to the “imponderables” that were taken into account
for fixing the maximum period. The very term “maximum period” in section 13 vests theAmeena Begum vs The State Of Telangana on 4 September, 2023

Government with discretion, allowing it to be exercised while considering whether the detention is
to be continued for the maximum period of 12 (twelve) months or any lesser period. In our opinion,
the relevant provisions of the Act have to be so read as to inhere a safeguard against arbitrary
exercise of discretionary power.
64. Discretion, it has been held by this Court in Bangalore Medical Trust vs. B.S. Muddappa27, is an
effective tool in administration providing an option to the authority concerned to adopt one or the
other alternative. When a statute provides guidance, or rule or regulation is framed, for exercise of
discretion, then the action should be in accordance with it. Where, however, statutes are silent and
only power is conferred to act in one or the other manner, the authority cannot act whimsically or
arbitrarily; it should be guided by reasonableness and fairness. A legislature does not intend abuse
of the law or its unfair use.
65. While considering the validity of an externment order under the Maharashtra Police Act, 1951,
this Court in Deepak vs. State of Maharashtra28 held:
“When the competent authority passes an order for the maximum permissible period
of two years, the order of externment must disclose an application of mind by the
competent authority and the order must record its subjective satisfaction about the
necessity of passing an order of externment for the maximum period of two years
which is based on material on record.”
66. True it is, Deepak (supra) was not a case arising out of preventive detention laws. However, in
situations where discretion is available with authorities to decide the period of detention, as
articulated by Lord Halsbury in Susannah Sharp vs. Wakefield & Ors.29, this discretion should be
exercised in accordance with “the rules of reason and justice, (1991) 4 SCC 54 2022 SCC OnLine SC
99 [1891] A.C. 173, 179 not according to private opinion; according to law, and not humour; it is to
be, not arbitrary, vague, and fanciful, but legal and regular”.
67. We turn to A.K. Roy (supra) once again where the law is expounded in the following words:
“70. *** We have the authority of the decisions in … for saying that the fundamental
rights conferred by the different articles of Part III of the Constitution are not
mutually exclusive and that therefore, a law of preventive detention which falls
within Article 22 must also meet the requirements of Articles 14, 19 and 21.
***”
68. Having held thus, we are not unmindful of the decision in Vijay Kumar vs. Union of India30
where this Court rejected the contention that the Government had not applied its mind while
confirming the detention of the appellant for the maximum period of 1 (one) year from the date of
detention as prescribed in section 10 of the Conservation of Foreign Exchange and Prevention of
Smuggling Activities Act, 1974. Dealing with the contention that some reason should have been
given why the maximum period of detention was imposed and while holding it to be without merit,Ameena Begum vs The State Of Telangana on 4 September, 2023

the main judgment of the presiding judge of the Bench reasoned that section 10 does not provide
that any reason has to be given in imposing the maximum period of detention and that in
confirming the order of detention it may be reasonably presumed that the Government has applied
its mind to all relevant facts; thus, if the maximum period of detention has been imposed, it cannot
be said that the Government did not apply its mind to the period of detention. It (1988) 2 SCC 57
was also held that in any event section 11 enables revocation and/or modification of the order by the
Government at any time and in the circumstances, the appellant was in the least prejudiced. The
concurring judgment also took the same view that the authority is not required to give any special
reason either for fixing a shorter period or for fixing the maximum period prescribed under section
10.
69. Much water has flown under the bridge since then. It is no longer the law that an administrative
authority is under an obligation to give a reasoned decision only if the statute under which it is
acting requires it to assign reasons. On the contrary, it is only in cases where the requirement has
been dispensed with expressly or by necessary implication that an administrative authority is
relieved of the obligation to record reasons. Further, the presumption of official acts having been
validly performed cannot be pressed into service for upholding the period for which the detention
would continue if the order of detention itself suffers from an illegality rendering it unsustainable.
That apart, the reasoning of no prejudice being suffered by the detenu because a power of
revocation/modification is available to the Government would not be of any consolation if such
power were not exercised at all. In such a case, the prejudice would be writ large. The decision in
Vijay Kumar (supra) is, therefore, distinguishable.
70. Viewed reasonably, the period of detention ought to necessarily vary depending upon the facts
and circumstances of each case and cannot be uniform in all cases. The objective sought to be
fulfilled in each case, whether is sub-served by continuing detention for the maximum period, ought
to bear some reflection in the order of detention; or else, the Government could be accused of
unreasonableness and unfairness. Detention being a restriction on the invaluable right to personal
liberty of an individual and if the same were to be continued for the maximum period, it would be
eminently just and desirable that such restriction on personal liberty, in the least, reflects an
approach that meets the test of Article 14. We, however, refrain from pronouncing here that an
order of detention, otherwise held legal and valid, could be invalidated only on the ground of
absence of any indication therein as to why the detention has been continued for the maximum
period. That situation does not arise here and is left for a decision in an appropriate case.
71. Both Mr. Luthra and Mr. Dave have referred us the recent decision of a 3-Judges Bench of this
Court in the case of Pesala Nookaraju vs. The Government of Andhra Pradesh31, where an order of
detention passed in exercise of power conferred by the Andhra Pradesh Prevention of Dangerous
Activities of Boot-leggers, Dacoits, Drug Offenders, Goondas, Immoral Traffic Offenders and Land
Grabbers Act, 1986 (“1986 Act”, hereafter) was upheld despite the detenu having obtained orders of
bail upon arrest in connection with investigation of 4 (four) F.I.R.s under sections 7B and 8B of the
Andhra Pradesh Prohibition Act, 1995.
Crl. Appeal No.2304 of 2023, decided on 16th August, 2023Ameena Begum vs The State Of Telangana on 4 September, 2023

72. Mr. Luthra intended to rely on the decision in Cherukari Mani vs. Chief Secretary, Government
of Andhra Pradesh32. According to the appellant, the detention could only be in force for a period of
three months in the first instance and that such order on a periodic assessment was required to be
reviewed for continuous detention till the maximum period permissible. The contention was
accepted by this Court.
73. While hearing of the appeal was in progress, came the decision in Pesala Nookaraju (supra)
overruling Cherukari Mani (supra). It was held that the “State Government need not review the
orders of detention every three months after it has passed the confirmatory order”. Fairly, Mr.
Luthra did not seek to rely on Cherukari Mani (supra) further.
74. However, according to Mr. Dave, the decision in Pesala Nookaraju (supra) answered the issue
under consideration. Reference was made to a sentence in paragraph 44 where this Court held that:
“44. *** The Act does not contemplate a review of the detention order once the
Advisory Board has opined that there is sufficient cause for detention of the person
concerned and on that basis, a confirmatory order is passed by the State Government
to detain a person for the maximum period of twelve months from the date of
detention. ***”
75. Mr. Luthra rightly pointed out that the excerpted sentence is part of the discussion made by this
Court while dealing with the first contention of (2015) 13 SCC 722 the appellant that the detention
order was contrary to the proviso to section 3(2) of the 1986 Act.
76. Mr. Dave next relied on the reasons assigned in Pesala Nookaraju (supra) to contend that the
impugned Detention Order should be held legal and unexceptionable.
77. On the merits of the matter, we find the Court in Pesala Nookaraju (supra) to have found the
impugned order of detention to be perfectly valid. This is borne out by paragraphs 65 and 71, which
we quote hereunder:
“65. *** if the detention is on the ground that the detenu is indulging in manufacture
or transport or sale of liquor then that by itself would not become an activity
prejudicial to the maintenance of public order because the same can be effectively
dealt with under the provisions of the Prohibition Act but if the liquor sold by the
detenu is dangerous to public health then under the Act of 1986, it becomes an
activity prejudicial to the maintenance of public order, therefore, it becomes
necessary for the detaining authority to be satisfied on the material available to it that
the liquor dealt with by the detenu is liquor which is dangerous to public health to
attract the provisions of the 1986 Act and if the detaining authority is satisfied that
such material exists either in the form of report of the Chemical Examiner or
otherwise, copy of such material should also be given to the detenu to afford him an
opportunity to make an effective representation.Ameena Begum vs The State Of Telangana on 4 September, 2023

***
71. In the case on hand, the detaining authority has specifically stated in the grounds
of detention that selling liquor by the appellant detenu and the consumption by the
people of that locality was harmful to their health. Such statement is an expression of
his subjective satisfaction that the activities of the detenu appellant is prejudicial to
the maintenance of public order. Not only that, the detaining authority has also
recorded his satisfaction that it is necessary to prevent the detenu appellant from
indulging further in such activities and this satisfaction has been drawn on the basis
of the credible material on record. ***”
78. It is indeed true that the appellant had raised a contention before the Court that the Government
of Andhra Pradesh had directed detention of the appellant for the maximum period of 12 (twelve)
months without any application of mind or providing reasons as to why this is necessary.
79. Having read the decision in Pesala Nookaraju (supra), it seems to us that the Court may not have
considered it necessary to deal with the contention having formed a firm opinion on the materials
on record that the appellant was indulging in activities of selling liquor to consumers which is
harmful for health and, thus, prejudicial to maintenance of public order. It is on such basis that
satisfaction of the detaining authority for ordering detention commended acceptance of the Court.
80. On the contrary, we have come to the conclusion on facts that the activities attributed to the
appellant’s husband as such cannot be branded as prejudicial to maintenance of public order. The
decision in Pesala Nookaraju (supra), therefore, is distinguishable and does not assist Mr. Dave. We
have, thus, no hesitation to reject the contentions of Mr. Dave.
CONCLUSION
81. In view of the foregoing discussion, we cannot uphold the Detention Order. As a consequence,
the impugned judgment and order of the High Court too cannot be upheld. The Detention Order
and the impugned judgment and order stand quashed. The appeal stands allowed, without costs.
82. The appellant’s husband, i.e. the Detenu, shall be released from detention forthwith.
………………………………….J (SURYA KANT) .…………………………………J (DIPANKAR DATTA) NEW
DELHI;
4th SEPTEMBER, 2023.Ameena Begum vs The State Of Telangana on 4 September, 2023

