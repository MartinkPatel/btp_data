Criminal Rules of Practice and Circular Orders, 1990
ANDHRA PRADESH
India
Criminal Rules of Practice and Circular Orders, 1990
Rule
CRIMINAL-RULES-OF-PRACTICE-AND-CIRCULAR-ORDERS-1990
of 1990
Published on 7 March 1991• 
Commenced on 7 March 1991• 
[This is the version of this document from 7 March 1991.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
Criminal Rules of Practice and Circular Orders, 1990Published vide Notification A.P. Gazette, R.S.
to Part 2, Issue No. 6, dated March 7, 1991 at Pages 43 to 361Rules and Orders for the guidance of
the Criminal Courts in the StateRoc. No. 113/SO/86: - Whereas it is expedient to amend, consolidate
and bring up-to-date the Criminal Rules of Practice and Orders, 1966, in accordance with the new
Code of Criminal Procedure, 1973 and incorporate therein the Orders, Notifications and
Administrative Instructions issued from time to time by the Government and the High Court.Now,
therefore, in exercise of the powers conferred by Article 227 of the Constitution of India and Section
477 of the Code of Criminal Procedure, 1973 and of all other powers hereunto enabling and with the
previous approval of the Governor of Andhra Pradesh, the High Court of Andhra Pradesh hereby
makes the following Rules and Orders for the guidance of the Criminal Courts in the State.
Chapter I
Preliminary
1. Short title:
- These Rules may be called the "Criminal Rules of Practice and Circular Orders, 1990".
2. Definitions:
- In these Rules, unless the context otherwise requires -(a)'Code' means the Code of Criminal
Procedure, 1973 ;(b)'Government' means the Government of Andhra Pradesh ;(c)'High Court'
means the High Court of Andhra Pradesh ;(d)'Sessions Judge' includes the Metropolitan Sessions
Judge, "Chief Judicial Magistrate" includes the Chief Metropolitan Magistrate, (d) 'Sessions Judge'Criminal Rules of Practice and Circular Orders, 1990

includes the Metropolitan Sessions Judge, "Chief Judicial Magistrate" includes the Chief
Metropolitan Magistrate, "Magistrate" includes the Metropolitan Magistrate, and "Special
Magistrate" includes Special Metropolitan Magistrate.
3. Hours of Sitting:
- Courts shall ordinarily sit from 10-30 A.M. to 5 P.M. Sessions Judges and Magistrates shall
ordinarily commence their sitting not later than 10-30 A.M. each day, and unless the work for the
day is disposed of earlier, shall not rise before 5-00 P.M. except for lunch in between 2-00 P.M. and
2-30 P.M.
4. Judicial Work on Holidays:
- No case shall be tried or heard and no judicial work Formally announced or done on holidays
declared by the High Court; except in exceptional circumstances and with the consent of both the
parties.
5. Judicial Work to be done in Court House:
(1)Judicial work, in so far as it relates to inquiries and trials, shall be done in Court
Houses.(2)Magistrates appointed to Mobile Courts may hold their sittings at any place within their
territorial jurisdiction.(3)Cases relating to Juvenile Offenders and Women may be tried in
camera.(4)Urgent bail applications presented out of Court hours may be disposed of at the residence
of the Magistrate but no order shall be passed in the case of Non-Bailable Offences without notice to
the prosecution.
6. Working days and hours of Special Judicial Magistrates:
- Special Judicial Magistrates shall hold Court for three days in a week on every alternate working
day commencing from Monday. They shall hold Court between 7-30 A.M. and 10-30 A.M. Special
Judicial Railway Magistrates may hold Court at any time between 7-30 A.M. and 10.00 P.M. after
giving advance intimation of holding Courts to the Chief Judicial Magistrates concerned.
Chapter II
Process Summons and Warrants
7. Witness summons may be signed by Ministerial Officer:
- Summons issued to witnesses shall ordinarily be signed by the Chief Ministerial Officer of the
Court The words "By order of the Court" shall invariably be prefixed to the signature of the Chief
Ministerial Officer in such cases.Criminal Rules of Practice and Circular Orders, 1990

8. Accused summons to be signed by Magistrate:
- Magistrates shall themselves sign summonses to accused persons.In a proceeding instituted upon
a complaint made in writing, the accused shall be furnished with a copy of such complaint as early
as practicable and in any case not later than the first occasion when he appears in CourtNote :- The
copy of the complaint may be sent with the summons or warrant issued to the accused under
sub-section (i) of Section 204 of the Code.
9. Place of hearing to be stated:
- Every summons and every order of adjournment shall state the place in which the cause to which it
relates will be heard.
10. Plural to he used in respect of person summoned:
- In all summonses issued by the Criminal Courts in the regional languages, the plural Form of the
pronoun shall be used in addressing the person summoned.
11. Warrant to bear sign manual of the judge or the Magistrate:
- Fascimile stamps shall not be used for signing warrants or summonses. All warrants should receive
the sign manual of the Judge or Magistrate from whose Court they are issued.
12. Medical witnesses and chemical examiner how to be summoned:
(1)Summonses of the following classes of Medical Officers in the District should be issued in the
manner specified below:-(a)Government Medical Officers in Government Institutions
;(b)Government Medical Officers in Zilla Parishad and Municipal Taluk Headquarters Medical
Institutions ;(c)Government Medical Officers lent for service in Zilla Parishad and Municipal
Medical Institutions ;(d)Zilla Parishad and Municipal Medical Officers ;(e)Rural Medical
Practitioners In-charge of Zilla Parishad Rural Dispensaries (who are neither Zilla Parishad
Servants nor Government Servants) ; and(f)Honorary Medical Officers.In the case of all these
classes of Officers, summons should be served direct on the Medical Officers when their absence
from the station is not involved, and the fact intimated to the District Medical Officer concerned for
information.(2)In cases involving absence from the station, summons should be served through the
District Medical Officer in respect of all classes of Medical Officers referred to above except
Honorary Medical Officers. The District Medical Officer while forwarding the summons to Medical
Officers employed in Zilla Parishad and Municipal Institutions whether they are Government
servants lent to local bodies or are servants of local bodies should simultaneously send intimation to
the Chairman of the Zilla Parishad or the Executive Authority of the Municipal Council through the
Chairman concerned. The same procedure shall be adopted in the case of Rural Medical
Practitioners also. The arrangement for the running of the Medical Institution will be made by the
District Medical Officer, wherever he has to do so and in other cases by the Chairman of the ZillaCriminal Rules of Practice and Circular Orders, 1990

Parishad or the Executive Authority of the Municipal Council through the Chairman
concerned.(3)In the case of Honorary Medical Officers, the summons should be served through the
Superintendent or Medical Officer In-charge of the Medical Institutions so that he may make
necessary arrangements for the relief of the Honorary Medical Officer.(4)In all cases where the time
available is short or the Medical Institution is distant, a telegram may be sent.(5)In cases where
Superintendents of Hospitals and Civil Surgeons are required to attend Criminal Courts to give
evidence on professional matters, the summonses shall be served on them direct, when their
absence from station is not involved. But the fact should be intimated simultaneously to the Director
of Medical Services, Andhra Pradesh In the case of summonses intended for District Medical
Officers to attend Criminal Courts to give evidence on professional matters, the summonses need
not be sent through the Director of Medical Services, Andhra Pradesh, except in cases in which their
absence from their jurisdiction is involved.(6)The Presiding Officer of a Court should see that their
special orders are taken before a summons is issued to a Medical witness and for that a convenient
date is fixed for his examination. If there is more than one Medical Officer in a Hospital, only one
Officer should, as far as possible, be summoned at a time. If possible, it may be previously
ascertained from the Medical Officer as to the time that would best be suitable for him with
reference to his professional duties. A medical witness should be summoned only when the presence
of the accused is certain and when there is no likelihood of the case being adjourned for any other
reason. The Presiding Officer of the Court should see that the time fixed for the examination of the
Medical Officer is adhered to and that the absence of the Medical Officer from his duties is as brief
as possible.(7)Summons for attendance of the Chemical Examiner as a witness in a criminal case
shall invariably be sent through the Chief Judicial Magistrate who will then be able to satisfy himself
whether Chemical Examiner's personal attendance to give evidence is essential.
13. Mode of service:
- When the serving officer delivers or tenders a copy of the summons to the person sought to be
served personally or to an agent or other person on his behalf, he shall require the signature of the
person to whom the copy is so delivered or tendered as an acknowledgement or service endorsed on
the original summons.
13A. [ (1) In all the proceedings under Section 125 of the Code of Criminal
Procedure, 1973 (Central Act 2 of 1974) and under Section 138-A of the
Negotiable Instruments Act, 1881 (Central Act 26 of 1881) and in any other
case where the summons may be ordered to be served through the post
office by registered post with acknowledgement due, sent to the address of
the respondent or the accused therein as the case may be, in the manner
provided under Rule 13 of the Criminal Rules of Practice and Circular Orders,
1990 and in such cases the postal employee tendering the notice shall be
deemed to be the 'serving officer' within the meaning of Rule 13 of the said
Rules.Criminal Rules of Practice and Circular Orders, 1990

(2)Before directing the service of notice by post, the complainants shall be required to bring to the
Court sufficient number of copies of the summons, the complaint and envelopes duly typed with the
name and address of the person on whom the summons sought to be served and bearing adequate
postage for sending the article by registered post with acknowledgement due.] [Added by
Notification ROC No. 2572/SO/91.]
14. Translation of summons:
- When a summons is written in language different from that of the Court within whose jurisdiction
it is to be served, the Court transmitting it for service shall also send a translation thereof in English,
and in cases where the summons has to be returned to any Court outside the State and the return is
not in English or in the language of that Court, the endorsement and the affidavit, if any, mentioned
in Section 68 of the Code with which it is sent back to that Court shall be accompanied by a
translation of the return into English.
15. Service of notice issued by the High Court:
- All notices issued by the high Court under Section 385 and 422 and clause (2) of Section 401 of the
Code shall be in duplicate and shall be served as expeditiously as possible and the duplicate copy
with endorsement of service, if effected, be transmitted to the High Court without delay.
16. Summons to be served on Members of Parliament or State Legislature:
- All summonses intended to be served on Members of Parliament or State Legislature shall be sent
through Court or Police or by Registered Post. Under no circumstances should they be sent to
Presiding Officer of the House for service on the Members.
17. Intimation of arrest of M.Ps. and M.L.As.:
- All arrests, surrenders and releases of Members of Parliament or State Legislature, shall be
intimated to the Presiding Officer of the House. Intimation shall also be given to the Home Ministry,
Government of India; in the case of M.Ps. and the Chief Secretary to the Government, G.A.D., in the
case of Members of State Legislature.
18. Summons to Government Analyst:
- Summons to Government Analyst in Food Adulteration cases shall be sent through the Chief
Judicial Magistrate.
19. Cases in which accused has absconded:
- When process has been issued for the attendance of the accused but the case has remained pending
for a long time owing to his non-appearance, and the Magistrate is satisfied that the presence of theCriminal Rules of Practice and Circular Orders, 1990

accused cannot be secured within a reasonable time or when an accused person found to be of
unsound mind is released under sub-section (1) of Section 330 or detained in safe custody under
sub-section (2) of Section 330 of the Code, the Magistrate shall report the case for the orders of the
Sessions Judge, who may, if he thinks fit, order that the case shall be removed from the register of
cases received and omitted from the quarterly returns. The case shall, however then be entered in a
separate Register of long pending cases which shall be maintained by all Magistrates in
Administration Form No. 26 :Provided that if the charge is withdrawn, or if the accused is reported
dead, whether before or after the entry of the case in the Register of Long Pending Cases, the case
should be closed :Provided further that if the Sessions Judge is of the opinion that the case against
the absent accused is wholly false, he may direct that the case be omitted from the Registers and the
returns altogether and he may at any subsequent time order the case to be entered in the Register of
Long Pending Cases.
20. Cases in which some of the accused have absconded:
- When there are several accused persons in a case, and only some of them have appeared or been
produced, before the Court, if the Magistrate is satisfied that the presence of other accused cannot
be secured within a reasonable time, having due regard to the right of such of the accused as have
appeared to have the case against them enquired into without delay, he shall proceed with the case
as against such of the accused as have appeared and dispose it of according to law. As regards the
accused who have not appeared, he shall give the case a new number and enter it in the Register of
Cases received, and if it remains pending for a long time, and efforts to secure the presence of the
accused have failed and the case against the accused who have appeared has been disposed of, the
Magistrate shall report the whole matter as regards all the accused to the Sessions Judge, who may
direct that the case against the absent accused be removed to the Register of Long Pending Cases, or
if he is of the opinion that the case against the absent accused is wholly false, he may direct that the
case be omitted from the Registers and the returns altogether, provided that he may at any
subsequent time order the case to be entered in the Register of Long Pending Cases. Similarly the
case may be split up against the accused who have been obstructing or persistently disturbing the
proceedings of the Court.
21. Procedure to be observed before transfer of a case to the Register of long
pending cases:
- Before directing transfer of a case, other than a case dealt with under sub-section (1) or sub-section
(2) of Section 330 of the Code to the Register of Long Pending Cases, the Sessions Judge shall satisfy
himself that all reasonable steps have been taken to follow the procedure prescribed in Sections 82
and 83, and also, when practicable, that the provisions of Section 299 of the Code have been
complied with.
22. Procedure on the appearance or the production of accused:
- If subsequently the absent accused or any of them are produced, or appear before the Magistrate orCriminal Rules of Practice and Circular Orders, 1990

the accused who was insane ceases to be insane, or those who have been obstructing or persistently
disturbing the proceedings undertake to co-operate with the Court the case against them shall be
registered under a new number.
23. Cases where an accused has absconded after appearance:
- Rules 19, 20, 21 and 22 shall apply as far as may be to cases where an accused person has appeared
but has subsequently absconded.If the accused has absconded after committal of the case, the
Sessions Judge shall follow the above procedure, and also record the evidence of the witnesses
under sub-section (1) of Section 299 of the Code.Chapter-III Investigation
24. Receipts of F.I.R.:
- Magistrates and Judges receiving F.I.Rs., shall initial each page and put the date stamp and time of
receipt. The name or number of the messenger shall also be noted. If the F.I.R., is received by post,
the envelope shall also be initialled and preserved.The same rule applies to Inquest Reports and
other documents received from the Police or other Prosecuting agencies.
25. Magistrate to insist on production of the accused and copies of
Documents:
- No order under Section 167 of the Code for remand of an accused should be made unless the
accused is produced before the Magistrate and he has been heard. Magistrates shall also insist on
the production of copies of the entries in the Case Diary peruse and initial those documents before
passing orders and also indicate in the order, that the documents are perused.
26. Remand to police custody:
- A Magistrate shall not grant remand to police custody unless he is satisfied that there is good
ground for doing so and shall not accept a general statement made by the investigating or other
Police Officer to the effect that the accused may be able to give further information. In all cases,
where the Magistrate authorises the detention of the accused in the custody of the Police, he shall
record his reasons for so doing.
27. Order of remand by a Magistrate to be forwarded to Sessions Judge:
- Whenever a Magistrate remands an accused person to the custody of police under Section 167 of
the Code, a copy of the order of remand with the reasons recorded therefor, shall be forwarded
within 24 hours to the Sessions Judge.Criminal Rules of Practice and Circular Orders, 1990

28. Computing period of remand:
- In computing the period of fifteen days mentioned in sub-section (2) of Section 167, or the proviso
to Section 309 of the Code, both the days on which the remand order was made and the day on
which the accused is ordered to be produced before the Court shall be included.[While computing
the period of detention as prescribed in the proviso to sub-section (2) of Section 167 of the Code or
any period of detention prescribed by any other Law, the date of actual production of the accused
before the Magistrate or the Judge, as the case may be, shall be excluded.] [Substituted by
G.O.Ms.No. 127, Law (LA & J-Home) (Courts-B), dated 18-8-2008.]
29. Remand under Section 390 of the Code:
- When an accused person is brought before a Subordinate Court under Section 390 of the Code, the
Court shall explain fully to him his right to the assistance of an Advocate at State cost and the
procedure of hearing of appeals by the High Court. If the accused is remanded to custody, the Court
shall forthwith report the action taken to the High Court and if the Warrant issued by the High
Court is a Bailable Warrant, also state its reasons for remand and shall forward a copy of the said
Report to the Collector who will communicate with the Public Prosecutor, Andhra Pradesh.
30. Bail during investigation:
- When an accused is released on bail during investigation he shall be bound over to appear in Court
after the charge-sheet is filed and summons served on him. It is not necessary to bind him to appear
on any earlier date or dates.
31. Requisitions for confessions etc.:
(1)All requisitions for recording of confession of the accused or statements of witnesses or for
holding identification parades shall be made to such Magistrate as is nominated by the Sessions
Judge for particular police station.(2)On receipt of such requisition, the Magistrate shall
immediately fix a date for the purpose and issue summons to the witnesses.(3)Statement of
witnesses and confession of accused shall be recorded in open Court and during Court hours except
for reasons to be recorded in writing. No Police Officer should be allowed to be present in the Court
Hall or in visible distance from the witnesses of the accused, while the statement or confession is
being recorded.
32. Confessions:
(1)No confession shall be recorded unless:(a)the Magistrate has explained to the accused that he is
under no obligation at all to answer any question and that he is free to speak or refrain from
speaking as he pleases; and(b)the Magistrate has warned the accused person that it is not intended
to make him an approver and that anything said by him will be taken down and thereafter be used
against him.(2)Before recording a statement, the Magistrate shall question the accused in order toCriminal Rules of Practice and Circular Orders, 1990

ascertain the exact circumstances in which his confession is made and the extent to which the Police
have had relations with the accused before the confession is made.The Magistrate may usefully put
the following questions to the accused :-(a)When did the police first question you?(b)How often
were you questioned by the Police?(c)Were you detained anywhere by the Police before you were
taken Formally into custody, and if so, in what circumstances?(d)Were you urged by the Police to
make a confession?(e)Have the Statements you are going to make been induced by any
ill-treatment? And if so, by whom?(f)Do you understand that the statement which you are about to
make may be used against you at your trial?These questions and any others which may suggest
themselves and the answers to them shall be recorded by the Magistrate before he records the
accused's statement and shall be appended to the Memorandum prescribed by Section 164(3) of the
Code of Criminal Procedure. The Magistrate shall add to the Memorandum a statement in his own
hand of the grounds on which he believes that the confession is voluntary and shall note the
precautions which he took to remove the accused from the influence of the police and the time given
to the accused for reflection.(3)If the Magistrate has any doubt whether the accused is going to
speak voluntarily, he may, if he thinks fit, remand him to a sub-jail, before recording the statement;
and ordinarily the accused shall be withdrawn from the custody of the Police for 24 hours before his
statement is recorded. When it is not possible or expedient to allow so long a time as 24 hours, the
Magistrate shall allow the accused atleast a few hours for reflection.(4)The statement of the accused
shall not be recorded, nor shall the warning prescribed in paragraph (1) of this Rule be given nor
shall the question prescribed in paragraph (2) of this Rule be asked in the presence of a co-accused
or of the police officers who have arrested him or produced him before the Magistrate or who have
investigated the case.
33. Dying declaration:
(1)While recording a Dying Declaration, the Magistrate shall keep in view the fact that the object of
such declaration is to get from the declarant the cause of death or the circumstances of the
transaction which resulted in death.(2)Before taking down the declaration, the Magistrate shall
disclose his identity and also ask the declarant whether he is mentally capable of making a
declaration. He should also put simple questions to elicit answer from the declarant with a view to
knowing his state of mind and should record the questions and answers, signs and gestures together
with his own conclusion in the matter. He should also obtain whenever possible a certificate from
the Medical Officer as to the mental condition of the declarant.(3)The declaration should be taken
down in the words of the declarant as far as possible. The Magistrate should try to obtain from the
declarant particulars necessary for identification of the accused. Every question put to the declarant
and every answer or sign or gesture made by him in reply shall be recorded.(4)After the statement is
recorded, it shall be read over to the declarant and his signature obtained thereon, if possible, and
then the Magistrate shall sign the statement.
34. Identification parades:
- In conducting identification parades of suspects, the Magistrate shall observe the following
Rules.(i)[ (a) The Police should sent a requisition for holding identification parade by the Magistrate
as nominated by the Sessions Judge. On such requisition, the Magistrate shall conduct theCriminal Rules of Practice and Circular Orders, 1990

identification parade as expeditiously as possible. [Substituted by ROC No. 558/SO/93, Published in
A.P. Gazette, Part II (Extraordinary), dated 8.4.1996.](b)Where bail application is pending for the
release of the accused and on being informed so by the Police Officer, the Magistrate shall as far as
possible fix a date earlier to the date of arguments on the bail application and hold the identification
parade.](ii)(a)As far as possible, non-suspects selected for the parade shall be of the same age,
height, general appearance and position in life as that of the accused. Where a suspect wears any
conspicuous garment, the Magistrate conducting the parade shall if possible, either arrange for
similar wear to other or induce the suspected person to remove such garment.(b)The accused shall
be allowed to select his own position and should be expressly asked if he has any objection to the
persons present with him or the arrangements made. It is desirable to change the order. in which
the suspects have been placed at the parade during the interval between the departure of one
witness and the arrival of another.(iii)(a)The witnesses who have been summoned for the parade
shall be kept out of the view of the parade and shall be prevented from seeing the prisoner before he
is paraded with others.(b)Before a witness is called upon to identify the suspect, he should be asked
whether he admits prior acquaintance with any suspect whom he proposes to identify. He shall also
be asked to state the marks of identification by which he can identify the suspects.(c)Each witness
shall be fetched by a peon separately. The witness shall be introduced one by one and on leaving
shall not be allowed to communicate with witness still waiting to see the persons paraded.(iv)Every
circumstances connected with the identification including the act if any attributed to the person who
is identified shall be carefully recorded by the officer conducting it, whether the accused or any other
person is identified or not. Particularly any objection by any suspect to any point in the proceeding
shall be recorded.
35. Identification of property:
(1)Identification parades of properties shall be held in the Court of the Magistrate where the
properties are lodged.(2)Each item of property shall be put up separately for the parade. It shall be
mixed up with four or five similar objects.(3)Before calling upon the witnesses to identify the
property, he shall be asked to state the identification marks of his property. Witnesses shall be called
in one after the other and on leaving shall not be allowed to communicate with the witness not yet
called in.Chapter-IV General Rules applicable to Trials
36. Defence at State expense:
(1)Sessions Judges and Magistrates shall inform every accused person who appears before them and
who is not represented by an Advocate on account of his poverty and indigence, that he is entitled of
free legal service at the cost of the State, unless he is not willing to take advantage of it. It is not
necessary that the accused should apply for legal aid. If the Court is satisfied that the accused has no
sufficient means to engage an Advocate, it shall assign an Advocate for his defence at the expense of
the State.(2)(a)The Sessions Judge shall prepare a panel of Advocates to defend the accused, who
has no sufficient means to engage an Advocate in a trial before the Court of Session from among the
Advocates practising in the Court of Session.(b)The panel of Advocates shall be known as "State
Brief Panel" and consists of the following two categories, viz.,Category No. 1: - Advocates of not less
than 5 years standing in the Bar to defend an accused, who is charged with an offence punishableCriminal Rules of Practice and Circular Orders, 1990

with death or life imprisonment or any complicated or sensational case.Category No. 2: - Advocates
with not less than 2 years standing in the Bar to defend the accused person, who has been charged
with an offence punishable with a sentence other than death or imprisonment for life.(c)In the Court
of Additional Sessions Judges or Assistant Judges working at outlying stations or Magistrates, a
State Brief Panel shall be prepared by such Judge or Magistrate, subject to the approval of the
Sessions Judge.(d)The "State Brief Panel" shall be prepared once in a year in the order of seniority
of Advocates.(3)Court to decide as to the number of Advocates to be engaged: - Where in a trial
there are several accused not represented by an Advocate or Advocates, only one Advocate shall be
assigned for the defence of all such accused:Provided that, if the Court having regard to the nature of
the defence of the different accused persons considers that it would not be desirable in the interests
of justice to entrust the defence of all the accused persons to a single Advocate, as many Advocates
as the Court considers necessary may be assigned.(4)Facilities to be allowed to Advocates:-
Advocates assigned by the Court to defend an accused shall be furnished with all the necessary
papers and records and allowed sufficient time to prepare the case for the defence of the
accused.(5)(1) Fees Payable to the Advocates: - The Sessions Judge may sanction payment of fee to
each Advocate so assigned at the following rates:-(i)not exceeding Rs. 50/- for each day of the trial,
where an accused is charged with an offence punishable with death or imprisonment for life.
Provided that the fee payable to an advocate for the whole case shall not in the aggregate exceed Rs.
500/-.(ii)not exceeding Rs. 25/- for each day of the trial, where an accused is charged with an
offence other than an offence punishable with death or imprisonment for life. Provided that the fee
payable to an Advocate for the whole case shall not in the aggregate exceed Rs. 250/-.(5)(2) The
Additional Sessions Judge or the Assistant Sessions Judge or the Magistrates working in the
outlaying stations shall exercise the powers mentioned in sub-rule (1) in respect of Advocates before
them.
37. One of the accused may be permitted to represent the other:
- Criminal Courts may in cases where there are more accused than one, permit anyone of them to be
authorised by any other to represent that other in any Criminal Proceeding ; but the authorisation
shall be in writing and shall contain the signature of the person giving it and shall be filed in
CourtAffidavits
38. Affidavits before whom may be sworn or affirmed:
- Affidavits intended for use in Judicial Proceedings may be sworn or affirmed before any Court or
Magistrate (or an Advocate other than the Advocate who has been engaged in such proceedings) or a
Member of Panchayat or a Sub-Registrar, Nazir or Deputy Nazir or a Member of the Legislative
Council or of the Legislative Assembly of the State or a Member of the Zilla Parishad or a Municipal
Councillor or a Retired Gazetted Officer receiving pension from the Government or any other
Gazetted Officer in the service of the State Government or the Central Government or a Notary as
defined in the Notaries Act, 1952, or any Commissioner or other person appointed by the High Court
for the purpose of taking affidavits or affirmations or any Judge or any Commissioner for taking
affidavit in any Court of record in India.Criminal Rules of Practice and Circular Orders, 1990

39. Filing of the affidavits:
- Before any affidavit is used it shall be filed in Court, but the Presiding Officer may, with the
consent of both parties, in case of urgency, allow any affidavit to be presented to the Court and read
on the hearing of application.
40. Form of affidavits:
- Every affidavit used in the Court shall set forth the name and place of the Court and cause title of
the proceeding or other matter in which the affidavit is sought to be used The affidavit shall be
drawn up in the first person, and divided into paragraphs, numbered, consecutively and each
paragraph, as nearly as may be, shall be confined to a distinct portion of the subject.
41. Description of deponent:
- Every affidavit shall state the full name, age, description and place of residence of the Deponent,
and shall be signed by him. The description shall include the father's name of the Deponent also.
42. Writing to be on both sides and each page to be signed:
- When an affidavit covers more than one sheet of paper, then writing shall be on both sides of the
sheet and shall be signed by the deponent at the foot of each page of the affidavit.
43. Alterations, Interlineations and Erasures:
- Alterations, interlineations and erasures, if any, shall before an affidavit is sworn or affirmed, be
authenticated by the initials of the authority before whom the affidavit is taken ; otherwise the same
shall not be filed or made use of in any matter without the leave of the Court.
44. Statement of Officer before whom affidavit is sworn:
- The authority before whom the affidavit is taken shall state the date on which and the place where
the same is taken and sign his name and description at the end, otherwise the same shall not be filed
or read in any matter without the leave of the Court.
45. Blind or illiterate deponent:
- When an affidavit is sworn or affirmed by any person who appears to the authority taking the
affidavit to be illiterate, blind or unacquainted with the language in which the affidavit is written,
the Officer shall certify that the affidavit was read, translated or explained in his presence to the
deponent, that the deponent seemed to understand it, and made his signature in the presence of the
authority, otherwise the affidavit shall not be used in evidence.Criminal Rules of Practice and Circular Orders, 1990

46. Endorsement should state on whose behalf filed:
- Every affidavit shall bear an endorsement stating on whose behalf it is filed.
47. Affidavit stating matter of opinion:
- Every affidavit stating any matter of opinion shall show the qualification of the deponent to
express such opinion by reference to the length of experience, acquaintance with the person or
matter in respect of which the opinion is expressed, or other means of knowledge of the deponent
48. Affidavit on information and belief:
- Every affidavit containing statement made on the information or belief of the deponent shall state
the source or ground of the information or belief.
49. Documents referred to in affidavit to be referred as exhibits:
- Documents referred to in an affidavit shall be referred to as exhibits and shall be marked in the
same manner as exhibits admitted by Court and shall bear a Certificate signed by the Officer before
whom the affidavit is taken.
50. Cross-examination on affidavit:
- The Court may at any time direct that any person shall attend to be cross-examined on his
affidavitOath and Affirmation
51. Administering Oath:
- The Session Judges and Magistrates shall themselves administer the oath to the witness or the
interpreter.
52.
(1)A witness, interpreter or deponent to an affidavit may instead of making oath, make an
affirmation.(a)Oath or affirmation to be taken by a witness: -
I do| Swear in the name of GodSolemnly affirm
that, what I shall state shall be the truth, the whole truth and nothing but the truth :(b)Oath or
affirmation to be taken by an Interpreter other than Court interpreter: -
I do| Swear in the name of GodSolemnly affirm
that I will well and truly interpret and explain all questions put to evidence given by witnesses and
translate correctly and accurately all documents given to me for translation.(c)Oath or affirmation toCriminal Rules of Practice and Circular Orders, 1990

be taken by the deponent to an affidavit -
I do| Swear in the name of GodSolemnly affirm
that this is my name and signature (or mark) and that the contents of my affidavit are true.(2)The
witness, interpreter or deponent to an affidavit shall ordinarily stand while making the oath or
affirmation.(3)In the case of deponent to an affidavit, oath or affirmation shall be made after he
affixes his signature or mark to the affidavit.Explanation: - The officer administering the oath or
affirmation shall write the name of the deponent over/against the mark after the deponent affixes
his mark and read it to the deponent before the Oath or affirmation is administered.(4)No Oath or
affirmation shall be administered to a deponent to an affidavit unless the Officer administering the
Oath or affirmation is satisfied that the deponent understands the nature and contents of the
affidavit.(5)In the case of a child witness under 12 years of age, the Presiding Officer shall record a
finding that the witness understands the duty of speaking the truth.Recording of Evidence
53. Deposition when to be signed by witness:
- After each witness is examined and the requirements of Section 278 Cr.P.C. are complied with, the
witness shall be required to sign or affix his thumb impression on the record of his deposition.
53A. [ Copies of Depositions shall be furnished free of cost only to an
accused who is an indigent person on application made by him.] [Inserted by
G.O.Ms. No. 1328, Law (LA&JHC-B), dated 31-7-2004, Published in A.P.
Gazette Part I, Extraordinary No. 318, dated 6-8-2004.]
54. Evidence as to the age of the accused:
- In every case in which the precise age of the accused person is relevant to the determination of the
sentence or order to be passed, evidence shall be taken on the question and whenever necessary the
opinion of a medical expert shall be obtained.
55. Evidence of Gosha-women:
- When the deposition of a gosha woman has to be taken, the Court shall, if necessary, adjourn to a
place where the witness can be examined with due regard to her privacy, in the presence of the
accused, precautions being of course taken to make sure of her identity.
56. Police Officers not to interpret evidence:
- Police Officers shall not, as a rule, be employed, to interpret the evidence of a witness in cases
prosecuted by the police.Criminal Rules of Practice and Circular Orders, 1990

57. Charges for interpretation:
- Sessions Judges and Chief Judicial Magistrates are authorised to incur under intimation to the
High Court, expenditure to a limit not exceeding Rs. 150/- (Rupees one hundred and fifty only) in
each case on account of interpretation of evidence in a language not understood by the accused of in
a language other than the language of the Court and not understood by the Advocate of the accused
or by the Court. They are also authorised within the limit prescribed to pass similar charges incurred
by Magistrates subordinate to them.Explanation: - The provisions of the foregoing paragraph shall
also apply to cases of interpretation of statements made by the deaf and dumb or the dumb and to
the payment of remuneration to the expert interpreting such statements.
58. Marking of exhibits:
(1)Exhibits admitted in evidence shall be marked as follows :-(i)if filed by the prosecution with the
capital letter 'P' followed by a numeral, P1, P2, P3 and the like ;(ii)if filed by defence with the capital
letter 'D' followed by a numeral, D1, D2, D3 and the like ;(iii)in case of Court exhibits with the
capital letter 'C' followed by a numeral, C1, C2, C3 and the like;(2)All the exhibits filed by the several
accused shall be marked consecutively.All material objects shall be marked in Arabic numbers in
continuous series as M.O.1, M.O.2 and M.O.3 and the like, whether exhibited by the prosecution or
the defence or the CourtCharges
59. Charges of previous conviction to be set out separately:
- If it is proposed to prove several previous convictions against an accused person for the purpose of
affecting his punishment, they shall not be lumped in one head of charge, but shall be set forth
separately, each under a distinct head of charge.
60. Complainant how to be described in a charge:
- The person against whom an offence is alleged to have been committed shall be described in the
charge by his name and not by his accidental position in the case as complainant, prosecutor or
witness.Adjournments
61. Adjournment to be in writing and reasons therefor recorded:
- Every time an inquiry or trial is adjourned, an order of the Court in writing giving the reasons
therefor shall be recorded. The reason for which an adjournment can be granted may be either the
absence of a witness or any other reasonable cause as stated in Section 309 of the Code.
Adjournment shall not ordinarily be granted in order to give time to the Advocates to prepare their
address to the Court as this will lead to unnecessary delay in the disposal of cases.Criminal Rules of Practice and Circular Orders, 1990

62. Order of remand to be endorsed on the warrant:
- When a case adjourned there shall be a written order of remand. It may conveniently be made by
the Judge or Magistrate endorsing his signature on the warrant of commitment under which the
prisoner is brought up the words "Remand until ....................."Sentences
63. Short term Imprisonment generally undesirable:
- Short-term imprisonments are undesirable. Before passing such sentences, the Court should
consider whether the provisions of Probation of Offenders Act (20 of 1958) or Section 360 of the
Code could not appropriately be applied in favour of the accused.
64. Imprisonment in Default of Fine:
- In awarding sentences of imprisonment in default of payment of fine, regard shall always be had to
the economic status of the accused and the sentence shall be so regulated as to induce him to pay
them and not to evade such payment.When an accused is sentenced to pay fine with imprisonment,
in default of such payment, he shall be allowed reasonable facilities for payment of the fine. The
calendar in such cases shall contain information in the column for remarks as to the payment of the
fine and the order passed to facilitate such payment.Judgments
65. No abbreviations in Judgments:
- Abbreviations shall not be used in Judgments or Orders.
66. How Witnesses shall be referred to:
- Witnesses shall be referred by their names or ranking as P.W., or D.Ws. and if the witnesses are
not examined, but cited in the charge-sheet, they should be referred by their names and not by
numbers allotted to them in the charge-sheet.
67. Tabular Form to be annexed to judgment:
- The judgment in original decisions shall be in the Form prescribed by Section 354 of the Code,
with a foot note or side note in a tabular Form giving, in addition, the following particulars, viz.:
-Columns:(1)Serial Number.(2)Name of Police Station and Crime No. of Offence.(3)Description of
accused : Name, Father's Name, Race, Occupation, Residence, Age.(4)Date of : Occurrence,
complaint, apprehension, Release on bail, commitment, commencement of trial, close of trial,
sentence or order.(5)Explanation for delay.Only two copies in manuscript of his statement are
required, one copy for record and one for transmission to the High Court The one for record may
conveniently be written up in a list to be bound up by way of index with the printed judgments for
each year.But in all summons cases the copy for record need not be prepared.Criminal Rules of Practice and Circular Orders, 1990

68. List of witnesses etc., to be appended to judgment:
- There shall be appended to every judgment a list of the witnesses examined by the prosecution and
for the defence and by the Court and also a list of exhibits and material objects marked.
69. Judgment to specify offence in respect of which sentence is passed:
- When an offender is convicted of two or more offences and it is competent to the Court to award
more than one Sentence, the Court shall in its judgment declare in respect of which offence or
offences any sentence awarded is imposed.
70. Sub-section under which convicted to be stated:
- When an accused is convicted under a Section of the Indian Penal Code, e.g., Section 454 which
contains sub-sections with different punishments prescribed for the various offences dealt with, the
judgment shall state under which sub-section the accused was charged and convicted.
71. Judgment to state-whether previous conviction was proved or confessed:
- When enhanced punishment is awarded on account of previous convictions, it shall appear in the
judgment that the previous conviction was charged, and proved or confessed.Furnishing Copies of
Judgments
72. Copies to the prosecution and the accused:
- Copies of Judgments shall be given to the accused and the prosecution. When a person who has
been convicted of an offence, applies for another copy of Judgment in addition to the one required
to be furnished to him under Section 363 of the Code, with a view to memoralising Government, he
shall be furnished with another copy in all cases free of cost except in summons cases.
73. Judgment against the Government Official to be furnished to the heads of
departments:
- In cases where Government Officials are charged with criminal offences, copies of judgments and
orders, and where they are in a regional language, translations thereof in English shall be furnished
by the Courts to the Heads of Departments concerned, free of charge.
74. Copy of judgment when to be sent to the head of department:
- When in a judgment or Order, the Sessions Judge or the Magistrate impugner the character or
conduct of any Government Servant, he should, if he regards the matter as serious enough to call for
Departmental Enquiry or action, forward a copy of the judgment or order to the Head of the
Department or the immediate Gazetted Officer under whom the Government servant is working.Criminal Rules of Practice and Circular Orders, 1990

75. Intimation to be given to the Controller of Defence Accounts on
conviction of Military pensioners:
- Where a Military pensioner is convicted and sentenced to imprisonment, or where such conviction
and sentence of imprisonment are confirmed in Appeal, the Court passing or confirming such a
Sentence shall forward to the Controller of Defence Accounts, Pensions, Allahabad, free of charge, a
copy of such Judgment as soon as possible after it is pronounced stating the place from where the
Pensioner last drew his pension.Magistrates, Assistant Sessions Judges and Additional Sessions
Judges shall forward such Judgment through the Sessions Judge.The Rule shall apply also to
judgments of the High Court exercising powers of an Appeal or Revision.
76. Copies of Judgments in food adulteration cases when to be sent to Food
Inspector:
- In all Food Adulteration cases ending in acquittal, Sessions Judges or Magistrates concerned shall
supply four typed copies of the judgments on plain paper, free of cost, to the Food Inspectors on
their request.
77. Copy of judgment when to be sent to Chemical Examiner:
- Sessions judges and Magistrates shall forward to the Chemical Examiner two copies of their
judgments or final orders in all cases in which reference has been made to him.
78. Copy of judgment when to be sent to Professors/Lecturers in Forensic
Medicine:
- Sessions Judges and Magistrates shall forward copies of the judgments to the Professors/Lecturers
in the Medical Colleges at Hyderabad, Visakhapatnam, Guntur, Kurnool, Tirupathi, Warangal and
Kakinada, as the case may be in which his evidence has been taken.Diary
79. Maintenance of Diary:
- Sessions Judges and Magistrates shall maintain a diary in administrative Form No. 11. The Diary
shall show the time at which the criminal proceedings of each day commenced and the time at which
they ended, and shall indicate clearly the progress made in the hearing of each case (specifying the
number of witnesses examined), in the order in which each case was taken up. The entries shall be
initialled by the Judge or the Magistrate on the day to which they relate.
80. Submission of extracts and calling for the original:
- When a case is committed for trial before the Court of Session or referred to the Chief City
Magistrate an extract from the diary shall be placed with record.It shall be competent to a SessionsCriminal Rules of Practice and Circular Orders, 1990

Judge or the Chief City Magistrate upon a cause shown, to call for the original diary of any
Subordinate Magistrate in order to satisfy himself that the extract submitted is a correct transcript
of the entries relating to the case, or that such entries have not been subsequently
altered.Miscellaneous
81. Accused witness and Advocate to sit:
(1)The accused may be permitted to sit except when they are examined under Section 239, 251 or
313 of the Code or when they are required for the purpose of identification by the witness.(2)The
witnesses may be allowed to sit while giving evidence.(3)Advocates may be allowed to sit while
examining or cross-examining the witness.Note :- Every person shall be required to stand when
addressed by the Court or when he addresses the Court
Chapter V
82. Receipt of Complaints by Magistrates:
- Complaints of offences whether oral or in writing shall be received on all working days at fixed
hours by the Magistrate having Jurisdiction to receive them. When the complaint is in writing, the
complainant shall present along with the complaint as many copies on plain paper of the complaint
as the number of the accused persons complained against.
83.
Whenever a complaint is referred to the police for investigation and report under Section 156(3)
Cr.P.C. and if the investigation officer drops the case against some of the accused referred to in the
complaint, the Magistrate shall give an opportunity to the complainant of being heard before taking
the cognizance of the case against those charge-sheeted by the police.
84. Complaints barred by limitation:
- Where a case is filed after expiration of the period of limitation prescribed by law, the charge-sheet
or the complaint shall show the ground upon which exemption from the law of limitation is claimed
or explain the delay or state how it is necessary to take the case on file in the interest of justice.Cases
triable by Court of Sessions
85. Cases triable by Court of Sessions:
- Magistrates should give preference to preliminary enquiries over other work.Criminal Rules of Practice and Circular Orders, 1990

86. Only cases exclusively triable by the Court of Session shall be committed
to Sessions:
- No case which can be tried and adequately dealt with by a Magistrate shall be committed to
Sessions. If after hearing the evidence, the Magistrate is of the opinion that the accused is guilty and
should receive punishment different in kind from or more severe than that which he is empowered
to inflict, he shall submit the proceedings and forward the case to the Chief Judicial Magistrate, but
not commit the case to the Sessions straightaway.Cases triable by Court Martial
87. Cases triable by Court Martial:
- The following rules framed by the Government of India shall be followed in cases where the
accused person is liable to be tried by the Court Martial.(1)These rules may be called the Criminal
Courts and Court Martial (Adjustment of Jurisdiction) Rules, 1952.(2)In these rules, unless the
context otherwise requires: -(a)"Commanding Officer"(i)in relation to a person subject to Military
law means the Officer Commanding the unit to which such person belongs or is attached;(ii)in
relation to a person subject to Naval Law, means the Commanding Officer of the Ship or Naval
establishment to which such person for the time being belongs ; and(iii)in relation to a person
subject to Air Force Law, means the Officer for the time being in command of the Unit to which such
a person belongs or is attached ;(b)"Competent Air Force Authority" means the Chief of the Air
Staff, the Air or other Officer Commanding any Command, Group, Wing or Station in which the
accused person is serving or where such person is serving in a field area, the Officer commanding
the forces or the Air Forces in the field ;(c)"Competent Military Authority" means the Chief of Army
Staff or Officer Commanding the Army, Army Corps, Division, Area, Sub-Area or Independent
brigade in which the accused person is serving, and except in cases falling under Section 69 of the
Army Act, 1950 (46 of 1950) in which death has result, the Officer commanding the brigade or
sub-area or station in which the accused person is serving ;(d)"Competent Naval Authority" means
the Chief of the Naval Staff or the Flag Officer Commanding in Chief, Western Naval Command,
Bombay or the Flag Officer Commanding-in-Chief Eastern Naval Command, Visakhapatnam or the
Flag Officer Commanding, Southern Naval Area, Cochin or the Flag Officer, Commanding, Western
Fleet or the Flag Officer Commanding, Eastern Fleet or Senior Naval Officer where the accused
person is serving.(3)Where a person subject to Military, Naval or Air Force Law, or any other law
relating to the Armed Forces of the Union for the time being in force is brought before a Magistrate
and charged with an offence for which he is also liable to be tried by a Court Martial, such
Magistrate shall not proceed to try such person or to commit the case to the Court of Sessions unless
;(a)he is moved thereto by a competent Military, Naval or Air Force Authority ; or(b)he is of opinion
for a reason to be recorded that he should so proceed or to commit without being moved thereto by
such authority.(4)Before proceeding under Clause (b) of Rule 3, the Magistrate shall give a written
notice to the Commanding Officer or the competent Military, Naval or Air Force authority, as the
case may be, of the accused and until the expiry of a period of 15 days from the date of service of the
notice he shall not -(a)Convict or acquit the accused under Section 252, sub-sections (1) and (2) of
Section 255, sub-section (1) of Section 256 or Section 257 of the Code of Criminal Procedure, 1973 (2
of 1974), or hear him in his defence under Section 254 of the said Code ; or(b)frame in writing a
charge against the accused under Section 240 or sub-section (1) of Section 246 of the said Code ;Criminal Rules of Practice and Circular Orders, 1990

or(c)make an order committing the accused for trial to the Court of Sessions under Section 209 of
the said Code ; or(d)make over the case for inquiry or trial under Section 192 of the said
Code.(5)Where within the period of 15 days mentioned in Rule 4 or at any time thereafter but before
the Magistrate takes any action or makes any order referred to in that Rule, the Commanding
Officer of the accused or the competent Military, Naval or Air Force authority as the case may be,
gives notice to the Magistrate that in the opinion of such Officer or authority the accused should be
tried by a Court Martial, the Magistrate shall stay the proceedings, and if the accused is in his power
or tinder his control, shall deliver him together with the statement referred to in sub-section (1) of
Section 475 of the said Code to the Officer specified in the said sub-section.(6)Where a Magistrate
has been moved by the competent Military, Naval or Air Force authority, as the case may be under
Clause (a) of Rule 3, and the Commanding Officer of the accused or the competent Military. Naval or
Air Force Authority, as the case may be, subsequently gives notice to such Magistrate that in the
opinion of such Officer or authority, the accused should be tried by a Court Martial, such Magistrate
if he has not taken any action or made any order referred to in Clauses (a), (b), (c) or (d) of Rule 4,
before receiving the notice shall stay the proceedings and if the accused is in his power or under his
control, shall deliver him together with the statement referred to in sub-section (1) of Section 475 of
the said Code to the Officer specified in the said sub-section.(7)(i)When an accused has been
delivered by the Magistrate under Rules 5 and 6, the Commanding Officer of the accused or the
competent Military, Naval or Air Force Authority, as the case may be, shall, as soon as may be,
inform the Magistrate whether the accused has been tried by a Court Martial or other effectual
proceedings have been taken or ordered to be taken against him.(ii)When the Magistrate has been
informed under sub-rule (1) that the accused has not been tried or other effectual proceedings have
not been taken or ordered to be taken against him, the Magistrate shall report the circumstances to
the State Government which may, in consultation with the Central Government, take appropriate
steps to ensure that the accused person is dealt with in accordance with law.(8)Notwithstanding
anything in the foregoing rules, where it comes to the notice of a Magistrate that a person subject to
Military, Naval or Air Force Law, or any other law relating to the Armed Force of the Union for the
time being in force has committed an offence, proceedings in respect of which ought to be instituted
before him and that the presence of such person cannot be procured except through Military, Naval
or Air Force authorities, the Magistrate may by a written notice require the Commanding Officer of
such person either to deliver such person to a Magistrate to be named in the said notice for being
proceeded against according to law, or to stay the proceeding against such person before the Court
Martial if since instituted, and to make a reference to the Central Government for determination as
to the Court before which proceedings should be instituted.(9)Where a person subject to Military,
Naval or Air Force Law, or any other law relating to the Armed Forces of the Union for the time
being in force has committed an offence which in the opinion of competent Military, Naval or Air
Force authority, as the case may be, ought to be tried by a Magistrate in accordance with the Civil
law in force or where the Central Government has, or a reference mentioned in Rule 8, decided that
the proceedings against such person should be instituted before a Magistrate, the Commanding
Officer of such person shall after giving a written notice to the Magistrate concerned, deliver such
person under proper escort to that Magistrate.Frivolous and Vexatious AccusationsCriminal Rules of Practice and Circular Orders, 1990

88. Procedure under Section 250 of the Code:
- At the conclusion of the trial, if the Magistrate means to take action under Section 250 of the Code,
he shall call upon the complainant, if he be present, to show cause why he should not be ordered to
pay compensation under the Section. If the complainant be not present the Magistrate shall issue
notice to him to appear on the day fixed for delivery of judgment to show cause why payment of
compensation should not be ordered.If the complainant cannot be served with notice within a
reasonable time or appears to be keeping out of the way, or having been served with notice, fails to
appear on the appointed day, the Magistrate may proceed ex parte, and make an order under
Section 250 if he deems fit to do so.Chapter - VI Courts of Session
89. Description of the seal of Court of Session:
- The Seal of every Court of Session shall be a circular one, two inches in diameter, bearing the
Andhra Pradesh State Emblem, with the motto "Satyameva Jayate" in Devanagari Script inscribed
in an arc and following the border of the Emblem (but without any border lines) and with the
designation of the Court, viz., "The Court of Session ......... of the Division" inscribed thereon within
two concentric circles round the Emblem without the words "Government of Andhra Pradesh". The
inscriptions on the seal other than the motto shall be in Telugu Language.When new seals are
required, Courts of Session shall indent for them on the General Superintendent, Public Workshop,
Seethanagaram sending their indents through the Registrar of the High Court
90. Sessions work to be given preference:
- Sessions work should usually be given preference over Civil work and should never be
unnecessarily interrupted ; but every Sessions Judge should arrange, as he finds most convenient,
for the disposal of urgent Civil and Criminal Work.
91. Numbering of cases committed to Sessions:
- Cases committed to the Courts of Session shall be filed and numbered on the date of receipt of the
intimation of committal. The cases shall continue to bear the same numbers even when they are
transferred for trial to the Assistant or Additional Sessions Judge.Jurisdiction during Vacation
92. Sessions Judge not to hear Applications made outside Division:
- A Sessions Judge shall decline to hear any application made to him during the recess if he is absent
from his division and shall refer the applicants to the High CourtRelease on acquittal
93. Prisoners to be released immediately on Acquittal:
- A prisoner is entitled to be discharged from custody immediately on a Judgment of acquittal being
pronounced upon him by the Court of Sessions, when there is no other charge pending against himCriminal Rules of Practice and Circular Orders, 1990

and his detention is illegal It is for the jail authorities in whose custody a prisoner remains until the
trial is concluded to satisfy themselves of the result of the trial and no Formal warrant of release
addressed by the Court to the Superintendent of the Jail is necessary.Reasons for Sentence
94. Reasons for severe or lenient punishments to be recorded:
- In every Sessions trial in which a sentence of exceptional severity or unusual leniency is passed or
in which varying degrees of punishments are awarded to different persons convicted of the same
offence in one trial, the reasons which guided the Judge in the determination of the amount of
punishment shall be recorded in the JudgmentSentence of Death
95. Copy of letter of reference in referred trials:
- A prisoner sentenced to death is entitled to obtain a copy of the Judge's letter of reference.
96. Order of High Court in referred trials to be communicated to
Superintendent of Jails within 24 hours:
- Sessions Judges are directed to make arrangements for communicating every order of the High
Court imposing, confirming, reversing or commuting a sentence of death, to the Superintendent of
the Jail, where the prisoner is confined, within 24 hours of the receipt of the order in the Court of
Session.In the case of an order of the High Court confirming or imposing a sentence of death,
Sessions Judges shall immediately on receipt of the Judgment of the High Court, issue a warrant in
Form No. 42 of the Code (suitably amended with regard to cases in which a sentence of death is
imposed by the High Court) accompanied by a copy of that judgment and shall appoint therein as
the date of execution a day not less than 21 days and not more than 28 days from the date of such
receipt.Imprisonment for Life
97. Levy of the fine to be notified to Jail authorities by Courts of Session in
cases of sentences of imprisonment for life and fine:
- When a Court of Sessions imposes a fine in addition to imprisonment for life and the whole or part
of the fine is paid or recovered, the Court shall endorse the fact of such payment or recovery on the
warrant of commitment, or, if that has already been issued, shall notify the fact of the payment or
recovery to the Jail authorities concerned.
98. Recommendation to the Government for action under Section 10-A of the
Borstal Schools Act, 1925:
- Courts of Session sentencing an Offender who is not less than 16 years and not more than 21 years
of age to imprisonment for life shall consider whether a recommendation should be made to the
Government that the offender be detained in a Borstal School under the provisions of the Andhra
Pradesh Borstal School Act, 1925.The name of the Police Station concerned and the Crime NumberCriminal Rules of Practice and Circular Orders, 1990

of the offence should also be noted at the head of the Judgment
99. Sessions Judgments:
- Every Sessions Judgment shall contain at the end a list of witnesses examined by the prosecutions
or by the defence or by the Court and exhibits and material objects marked in the case.
100. Distribution of Copies of Judgments:
(1)Courts of Session shall, within 15 days from the date of pronouncing Judgment, distribute copies
of all their judgments as follows, a sufficient number of copies being typed or cyclostyled for the
purpose of each case :(i)One copy for the Collector of the District.(ii)Three copies in respect of
capital charges and two copies in other cases to the Superintendent of Police/Commissioner of
Police, Superintendent of Police, Crime Branch, C.I.D.(iii)One copy to the High Court as provided
for in the Rules relating to the submission of Judgments and Calendars.(iv)Eight copies to the High
Court as provided for in the Rules relating to the submission of records.(v)One copy for each
accused person with reference to Section 363 of the Code.(vi)One copy (for each prisoner) to the
Superintendent of the Jail to which a prisoner is committed when such prisoner is sentenced to
imprisonment, for being filed with the warrant of committal or used for purpose of memoralizing
Government if required.(vii)Two copies (for each prisoner) to the Superintendent of the Jail to
which a prisoner is committed in cases when such prisoner is sentenced to death, to prevent delay in
the transmission to Government of petitions for mercy.(viii)In cases other than those mentioned in
sub-heads six and seven, one copy shall be furnished to each person convicted of an offence on his
requisition in order to afford facilities for memoralizing Government to exercise its powers under
Chapter XXXII of the Code required by Section 363.(ix)One copy to the Director of Prosecutions,
one copy to the Public Prosecutor and one to the Additional or Special Public Prosecutors who
conducted the case.(x)One copy to be filed with the records.(xi)One copy to be bound up in a volume
of judgments for reference in the Sessions Courts.The copies referred to in sub-heads (i) to (ix)
inclusive shall be supplied free of charge.Where copies can be spared, one may be supplied to a
person not entitled by any law or order to receive a copy free of cost, on payment of the prescribed
charges. All such payments shall be in cash
Chapter VII
Appeals
101. Presentation of Appeals:
- Petitions of appeals from the convictions and orders passed by a Magistrate may be filed in the
Court of Sessions by delivering the same to the Chief Ministerial Officer of that Court at any time
during office hours. The said Officer shall at once endorse on the document the date of presentation
and the serial number.Criminal Rules of Practice and Circular Orders, 1990

102. Defective Petitions return for rectification:
- Petitions and applications filed in the Court of Sessions should conform to the provisions of law. If
any petition or application is found to be defective in any respect, it shall be returned to the party or
Advocate concerned for amendment and representation within a specified time.
103. Separate or Joint Appeals when to be preferred:
- Where several accused persons are convicted in a single trial, each of them can prefer an appeal
against convictions either separately or jointly with one or more of the other accused. But when one
accused has been convicted at different trials, he should prefer a separate appeal in each case.
104. Jail Appeals:
- No appeal forwarded from Jail under Section 383 of the Code shall be summarily dismissed
without giving the appellant a reasonable opportunity of being heard. If he is not in a position to
engage an Advocate, the Court shall assign an Advocate from the State Brief Panel and pay him fees
not exceeding Rs. 200/-.
105. Notice of Appeal to whom given:
- Notice of Appeal under Section 385 of the Code shall be given to the following Officers: -(1)The
Public Prosecutor, or the Additional Public Prosecutor, as the case may be, in appeals heard by the
Sessions Judge, the Additional Sessions Judge or the Assistant Sessions Judge.(2)The General
Manager of the Railway concerned in appeals against convictions in connection with that
Railway.(3)The District Forest Officer in appeals against convictions for forest offences except in
case of offences relating to unserved lands in which cases notices shall be given to the Revenue
Divisional Officer who ordered the prosecution.(4)The Superintendent of Excise concerned in
appeals against convictions under the A.P. Excise Act(5)The Commercial Tax Officer in appeals
against convictions for sales tax and other taxation offences with which commercial taxes
department is concerned.(6)The Commissioner, Corporation of Hyderabad in appeals against
convictions in cases initiated by the Corporation.(7)The Municipal Commissioner in appeals against
convictions in Municipal and Food Adulteration cases and the Executive Officers of the Panchayats
in appeals against convictions in Food Adulteration cases.Every notice issued under this rule shall
be accompanied by a copy of the grounds of appeal on plain paper. The officer receiving notice
should acknowledge receipt of the notice immediately. But the hearing of the appeal will not be
delayed for want of such acknowledgement
106. Suspension of sentence:
- Whenever an Appellate Court orders the suspension of the execution of a sentence of
imprisonment under Section 389 of the Code, it shall send a copy of the order to the Superintendent
or Officer-In-charge of the Jail in which the appellant is confined.Note :- The effect of an order by anCriminal Rules of Practice and Circular Orders, 1990

Appellate Court suspending the execution of a sentence of imprisonment pending disposal of an
appeal, is that the appellant if detained in Jail, is to be treated, in all respects as an undertrial
prisoner.
107. Judgment in Appeals:
- The judgment in appeals shall contain the particulars in a tabular statement as in Judicial Form
No. 75.The point or points for determination in appeal, and the reasons for the decision of the
Appellate Court, shall be stated.In cases in which an appeal is rejected under Section 384 of the
Code, the judgment shall contain a statement, if the fact be so, that the Court has perused the
petition of appeal and a copy of the Judgment or Order appealed against and has heard the
appellant, his counsel, as the case may be.
108. Copy of order of dismissal to be sent to the Superintendent of Jail:
- Whenever an Appellate Court dismisses an appeal, it shall, whether the execution of the sentence is
suspended under Section 389 of the Code or not, send a copy of the order dismissing the appeal to
the Superintendent or Officer-hi-charge of the Jail in which the appellant is, or is to be, confined.
109. Amendment warrant to be sent to Superintendent of Jail when sentence
of imprisonment is modified:
- Whenever an Appellate Court modifies a sentence of imprisonment, it shall prepare a fresh
warrant in accordance with the terms of the order passed and shall send the same along with a copy
of the order direct to the Superintendent or Officer-In-charge of the Jail in which the appellant is, or
is to be, confined, and shall recall and cancel the original warrant of commitment, which shall be
attached to the record of the original Court and returned to it therewith.
110. Warrant of release to be sent to Superintendent of Jail when sentence of
imprisonment is reversed:
- Whenever an Appellate Court reverses a sentence of imprisonment, it shall prepare a warrant of
release and shall send the same by registered post with acknowledgement due along with a copy of
the Order direct to the Officer-In-charge of the Jail in which the appellant is confined. It shall at the
same time recall and cancel the original warrant of commitment which shall be attached to the
record of the original Court and returned to it therewith.
111. Order of refund of fine:
- On receipt of a copy of the Judgment or Order of an Appellate Court reducing or reversing a
sentence of fine, the Court of the first instance shall, if the fine or a portion thereof as the case may
be, has been levied, prepare the necessary payment order and deliver it to the payee or his Advocate,
if any.Criminal Rules of Practice and Circular Orders, 1990

112. Time for presentation of payment order:
- Such payment order shall be presented for payment within three months from the date of its issue.
If not presented within that period, it shall be returned to the Court, and may then, after being
re-dated and initialled by the Magistrate be re-issued to the payee.
113. As may copies of Warrants and Judgments to be sent as there are
prisoners:
- In the cases referred to in Rules 106 and 108 to 110 as many warrants shall be prepared as there
are prisoners, and communicated to the Superintendent or Officer-in-charge of the Jail in which the
prisoners are confined, and shall be accompanied or followed as soon after as possible by the same
number of copies of the judgment or order in accordance with which the warrants are prepared.
114. Manuscript copy of Judgment to be returned to prisoner in Jail:
- The Court disposing of an Appeal by a convict in Jail shall, in communicating its order to the
prisoner return to him through the Jail authorities, the copy of the judgment appealed against which
accompanied the petition of appeal when such copy if in manuscript
115. Return of papers after disposal of appeal etc:
- On the termination of an appeal, Revision Petition or other application, the Criminal Court to
which such appeal, Revision Petition or application is made shall, on an application in writing made
in that behalf by the party or Advocate concerned return, as soon as possible copies of Judgment,
orders and other papers filed as enclosures to such appeal, revision petition or application.An
endorsement on the application for return, signed by the party or Advocate shall be a sufficient for
the return of the copies.Testing Sufficiency of Bail or Security
116. Court to test sufficiency of Bail:
- When a Court of Appeal or Revision orders the release on bail of a person who has been convicted
or committed for trial, the question of the sufficiency of the Bail shall, unless the Court of Appeal or
Revision thinks fit itself to determine the sufficiency of the bail or security, be determined by such
Court or Magistrate subordinate or it as the Court making the order may direct
117. Court to test sufficiency of security under Section 106 or 117 of the
Code:
- When an order to give security is made under Section 106 or 117 of the Code, the question of the
sufficiency of the security shall be determined by the Court or Magistrate by whom the order was
made provided that when an order to give security is made under Section 106 of the Code by an
Appellate Court or by a revisional Court, the question of the sufficiency of the security shall, unlessCriminal Rules of Practice and Circular Orders, 1990

the said Court thinks fit itself to determine, be determined by such other Court or Magistrate
subordinate to it as it may direct
118. Warrant of release to be issued by Court testing sufficiency of bail or
security:
- The Court authorised to test the sufficiency of the bail or security, shall when satisfied as to the
sufficiency of the security, forward to the officers-in-charge of the Jail in which the accused is
confined, a warrant for the release of the prisoner in pursuance of the order and shall further, in
cases where bail is ordered by a superior Court, report to that Court whether or not the bail has been
furnished.Miscellaneous
119. Appeals under Section. 340, 344, 345 and 350 of the Code:
- Appeals filed under Section 351 of Criminal Procedure Code shall be registered as Criminal
Appeals.
120. Appeals under Section 454 of the Code:
- Every appeal under Section 454 of the Code should be registered as a Criminal Miscellaneous
Appeal and dealt with as such.
Chapter VIII
High Court
121. Tappal petitions for exercise of Judicial authority not to be entertained:
- Save as otherwise provided no application or petition for the exercise by the High Court of its
judicial authority will be entertained when forwarded by post
122. Form of Appeals etc.:
- All petitions, applications, affidavits, memoranda of appeal or revision petitions and all
proceedings presented to the High Court, shall be in English and shall be written or typewritten
fairly and legibly on substantial white fullscape folio paper with an outer margin about two inches
wide and separate sheets shall be stitched together bookwise. The writing or printing may be on
both sides of the paper and numbers shall be expressed in figures.The memorandum of Criminal
Appeal or the Criminal Revision Petition shall be accompanied by as many copies of the
memorandum or petition on plain paper as there are respondents to be served upon and another
copy in addition for the Court record.Criminal Rules of Practice and Circular Orders, 1990

123. Cause title of miscellaneous petition:
- Every original miscellaneous petition shall be headed with a cause title setting out the provision of
law under which it is filed and the names and full addresses of the parties to it separately numbered
and described as petitioners and respondents.
124. Cause title of memo of appeal:
- Every memorandum of Criminal appeal, other than an appeal presented to Jail Officer, shall be
headed with a cause title setting out the provision of law under which it is preferred, the name of
Court, the names of appellants and respondents in the High Court and also the full cause title of the
case or matter in the Lower Court or Courts, as the case may be.Where an appellant is in jail, that
fact shall be mentioned in the cause title with an indication of the jail in which he is confined.These
provisions apply, as far as may be, to revision petitions also.
125. Cause title of subsequent proceedings:
- Every proceeding, subsequent to an appeal, revision petition or other application made by headed
with a short cause title setting out the provision of law and the names of the parties and their ranks
and status in the main case.
126. Enclosure of appeal or revision petition:
(1)Every petition of appeal or revision petition shall be accompanied by a certified copy of the
judgment or order of the Court appealed against or sought to be revised, a memorandum of
appearance duly signed, and the necessary vouchers for the verification of any matter or entry in the
petition or enclosures.(2)When a revision petition is presented against a judgment or order passed
in appeal, it must be accompanied also by a certified copy of the judgment or order of the Court of
first instance, obtained either by a fresh application for copy or by a return of enclosures under Rule
115.(3)When the certified copy of the Judgment or order of the lower Court is in manuscript, the
appeal or revision petition shall be accompanied by a typewritten copy of the judgment or order.
127. Petition to excuse delay to accompany appeal or revision petitions
presented out of time:
(1)Where an appeal, on the date of its first presentation is barred by limitation or where revision
petition is presented more than 90 days from the date of judgment or order which the petitioner
seeks to have revised, a petition to excuse delay supported by an affidavit explaining the
circumstances of such delay shall be filed along with the petition or appeal.(2)The period of 90 days
referred to above is exclusive of the time occupied in obtaining a certified copy of the order or
judgment which the petitioner seeks to have revised, but inclusive of the time occupied in obtaining
return of documents under Rule 115.Criminal Rules of Practice and Circular Orders, 1990

128. Separate petition to be filed in each case:
- Every interlocutory application relating to an appeal, revision petition or original petition shall be
made by a separate petition in each case.
129. Court fee to be paid on each petition:
- Every petition filed in Court or presented in the office' shall be stamped with the Court-fee to
which it is liable under the law.
130. Return of defective petitions and their representation:
- Every petition or other application which does not comply with the above requirements or is
otherwise defective shall be returned to the party or Advocate concerned for amendment and
representation within a specified time.
131. Petition to excuse delay to accompany appeals out of time on the date of
representation:
- Every petition or appeal represented after the expiry of the time specified under Rule 130 and
barred by limitation on the date of its representation shall be accompanied by a petition and
affidavit as prescribed in Rule 127.
132. Explanation for delay to accompany other cases:
- Every appeal not governed by the provisions of the preceding Rule and every other petition or
application for which no period of limitation is prescribed by law, shall if represented after the time
allowed, contain an endorsement in explanation of the delay, provided that in the case of revision
petition the period of 90 days allowed by Rule 127 is not exceeded. Where the period of 90 days is
exceeded, a petition to excuse delay supported by an affidavit shall be filed along with the revision
petition as provided by Rule 127.
133. Posting of appeal or revision for Admission:
- Every appeal (other than one preferred from jail or in which the prisoner has been sentenced to
death or has been called upon to show cause why he should not be so sentenced) and every
application or petition or a revision petition shall be posted for admission at the earliest possible
opportunity after it is filed.
134. Motion Cases:
- Every petition or application intended to come up for orders of the High Court as a special motion
should be filed in the office of the Registrar not later than 3 p.m. on the day previous to the day onCriminal Rules of Practice and Circular Orders, 1990

which the motion is to be heard and a separate letter explaining the nature of the urgency, should be
addressed to the Registrar for permission to move.
135. Motion to be taken before the day's regular work:
- Every petition allowed by the Registrar under this rule will be taken up before the regular work of
the Court for the day and shall also have precedence over civil motions.
136. Additional set of papers to be filed in motions before a Bench of two or
more Judges:
- Where a motion has to be heard by a Bench of two or more Judges, additional sets of papers should
be furnished by the party concerned.
137. 24 hours notice to Public Prosecutor to be given in case of transfer:
- No application for transfer shall be accepted as a special motion unless it bears an endorsement or
is accompanied by a satisfactory voucher that notice was given to the Public Prosecutor at least 24
hours before forenoon of the day on which the Court sits to take up the application.
138. Personal notice in the absence of an Advocate:
- Notices in criminal cases shall be served on parties personally unless they are represented by an
Advocate in which case notice shall be given to such Advocate :Provided that, when on admitting a
Criminal Appeal or Revision Petition presented by an Advocate, the Court directs notice to issue to a
party to show cause against enhancement of sentence, notice shall be served on the appellant or
petitioner in person.
139. Notice to Public Prosecutor in cases referred to High Court under
Section 366 of the Code:
- In cases referred to the High Court for the confirmation of capital sentence, the Court will issue
notice to the Public Prosecutor to appear in all cases on behalf of the prosecution.
140. Provisions of Rule 105 to apply to notices issued by High:
- Court Notice of appeal shall under Section 385 of the Code be given to the Public Prosecutor,
Andhra Pradesh and to the Superintendent of Police of the District concerned or the Commissioner
of Police, Hyderabad as the case may be.The provisions of Rule 105 shall apply also to notices issued
by the High Court, Appellant side.Criminal Rules of Practice and Circular Orders, 1990

141. Service on prisoner through Jail, Authorities:
- Notice for service on parties in Jail will be forwarded to the Officer in-charge of the Jail and the
Officer in-charge of the Jail shall cause the notice to be served on the prisoner without delay and
obtain the acknowledgement of the prisoner and shall certify to the Court about the service.
142. Cases in which cyclostyling etc., of record is done:
(a)The record in the following classes of cases will be cyclostyled, typewritten or mechanically
reproduced in any other manner without the special orders of Court.
1. Reference under Section 366 of the Code unless otherwise directed.
2. Appeals under Section 382 of the Code unless otherwise directed.
3. Appeals under sub-section (1) of the Section 378 of the Code on capital
charges.
4. Cases taken up for enhancement of sentence to death.
Note :- Printing in the above cases may be done, if the Court so directs.(b)1. It will not be necessary
ordinarily to cyclostyle or type or mechanically reproduce inquest reports, prior statements or
depositions which are filed merely to prove omissions or motive.
2. Where parts of documents are relied on those parts only be cyclostyled,
typewritten or mechanically reproduced.
In all cases in which the record of the Court is cyclostyled or typed or mechanically reproduced or
printed under this rule, a copy of the same be supplied to the accused at the rate of one rupee per
page.
3. It is not necessary to print statements of the accused recorded under
Section 313 of Code :
Provided that when the Public Prosecutor or Counsel for the accused makes a special request within
4 days from the date of notification of posting of cases on the ready board the statements or
documents filed along with them or portions thereof shall be typed or cyclostyled or mechanically
reproduced.Criminal Rules of Practice and Circular Orders, 1990

143. Other cases to be typed, cyclostyled at Party's cost:
- Records of cases not governed by the preceding rules shall ordinarily be typed or cyclostyled at the
cost of the party applying for in the absence of an express direction of Court to have them (printed)
typed or cyclostyled at the cost of Government
144. Evidence to be typed or cyclostyled only if pleadings are typed or
cyclostyled:
- No party will be permitted to type or cyclostyle the evidence in a case without his having paid for
the typing or cyclostyling of the pleadings.
145. Time for T & P of record:
- No application for the typing or cyclostyling of evidence presented by the petitioner after the expiry
of one week from the date of the admission of his petition or by the respondent after the expiry of 14
days from the date of the service of the notice of the petition shall be received except under orders of
the Registrar.
146. Registrar to permit typing or cyclostyling of fresh documents to be
admitted in evidence:
- When application is made for the translation and typing of any document not on the record of the
cases with a view to its admission in evidence, the translation and typing or cyclostyling may he
ordered by the Registrar, provided that the order shall be made without prejudice to the posting of
the case.
147. Bill to be paid within ten days from its issue:
- A party to whom a bill is issued for typing or cyclostyling charges whether in respect of pleading, or
of evidence shall be called upon to pay the amount therein specified within ten days from the date of
its service on him and no payment shall be received after the expiry of that period except under an
order of the Registrar.
148. No printing in revision cases wherein there is an order of stay:
- In the absence of an express direction to the contrary no record shall be cyclostyled or typed or
mechanically reproduced in a revision case pending disposal of which stay of proceedings in any
criminal case has been ordered by the CourtCriminal Rules of Practice and Circular Orders, 1990

149. Cases in which copies of record are to be supplied free of cost:
- Copies of record shall be supplied free of cost in the following cases(1)One set to the Public
prosecutor in every case in which notice has been issued to him.(2)One set to a practitioner to whom
State brief has been issued.(3)One set to the Advocate for accused in(a)Reference under Section 366
of the Code.(b)Appeals against acquittal(c)Appeals or Revisions for enhancement of sentence to one
of death:Provided that where more than one set are applied for by the Advocate for the accused the
same shall be supplied at such rate as the Registrar may from time to time fix.
150. Application to be made in other cases:
- An Advocate requiring free supply of (typed papers) in any other case should obtain the orders of
Court by means of petition or otherwise.Application for free copies of typed record papers should be
made at the time of the admission of an appeal or petition, and should be supported wherever
possible, by an affidavit as to the means of the accused.Police Officer to whom notice is given in a
case may apply for a set of record and obtain the same by post or personally.
151. Additional sets to be applied before preparation of copies:
- Application for additional set of record will not be entertained unless they are made by parties
paying for the copies before preparation of the copies begins.
152. Payment to be made in other cases:
- Copies of record will not be issued to parties or Advocate not having notice except on payment at
such rate as the Registrar may fix from time to time.
153. List of cases ready for hearing:
- A list of cases other than miscellaneous petitions ready for hearing will be exhibited on the notice
board and no such case shall ordinarily be posted for hearing within a week of its being so exhibited.
154. Cases to be heard by a Bench of two Judges:
- The following classes of cases will ordinarily be heard by a Bench of two Judges.
1. Every reference under Section 366 of the Code and every appeal from the
Judgment of a Criminal Court in which sentence of death or imprisonment
for life has been passed on the appellant or on a person tried with him.Criminal Rules of Practice and Circular Orders, 1990

2. Every appeal against acquittal on a capital charge.
3. Every case enhancement of sentence to one of death.
4. Every appeal, application, reference or revision petition which may be
referred to Bench by a Single Judge.
5. Every other case marked at the time of admission for a Bench of two
Judges.
155. Single Judge cases:
- All Criminal cases not referred to in the Rule 154 will ordinarily be heard by a Single Judge.
156. Reference under Section 366 of the Code to be given precedence:
- Reference under Section 366 of the Code, will have precedence over other cases posted before the
Criminal Bench.
157. Notice in bail cases:
- 1. Subordinate Courts shall give notice of every application for bail under Section 390 of the Code
to the Local Public Prosecutor.
2. In cases where bail is granted the Court granting bail shall report the fact
to the High Court at once.
158. Judgment and order to be despatched with promptness:
- The judgment or order of the High Court, in or relating to, a criminal case on its file shall be
certified to the lower Courts with the least possible delay.
159. Orders on reference under Section 366 of the Code to be communicated
on the same day:
- An order on 3 reference under Section 366 of the Code shall be certified in the Court of Session on
the same day or which judgment is pronounced.Criminal Rules of Practice and Circular Orders, 1990

160. Order to be issued before hand if preparation of judgment is delayed:
- Where in any of the following cases the judgment of the High Court cannot be certified to the lower
Court on the day on which it is pronounced, an order drawn up in conforming with the judgment is
delivered on the next working day.(i)Where a judgment of acquittal or release is passed or upheld
and the accused or any of them is in custody.(ii)Where a sentence passed is enhanced or confirmed
and the accused or any of them is on bail or otherwise at large.(iii)Where a sentence is reduced or
altered entitling the accused to early or immediate release;(iv)Where the case requires urgent or
immediate action.
161. Judgment relating to Sessions trials:
- Judgments in cases relating to trial by a Court of Sessions shall be communicated to -(1)The
Sessions Judge; and(2)The Additional or Assistant Sessions Judge, if any (of the District);(3)The
Collector of the District;(4)The Superintendent of Jail, if any, in which the accused are confined;
where the accused is sentenced to imprisonment; two additional copies;(5)The Inspector General of
Police;(6)The Public Prosecutor, Andhra Pradesh.(7)Standing Counsel-cum-Special Public
Prosecutor for Anti-Corruption Bureau and Special Police Establishment Cases, Andhra
Pradesh.Note :- An additional copy will be forwarded to the Sessions judge in every case in which an
accused person is in jail for communication to him and the acknowledgement of the accused as to
the receipt of the whom judgment shall be obtained in every case.
162. To whom orders to be communicated:
- Orders issued in advance of judgment shall be communicated to the Officer and parties to whom
judgments are communicated.
163. Certificate under Article 132 or 134 of the Constitution:
- In cases where the High Court grants a certificate under Article 132 or 134 of the Constitution to a
person under sentence of death, the date of the issue of the certificate shall forthwith be intimated to
the Government and the Superintendent of the Jail in which the prisoner is confined.
164. Order to be communicated to Subordinate Magistrate through the
Sessions Judge:
- Every order and judgment relating to a Magisterial enquiry or trial shall be communicated to the
Magistrate or Magistrates concerned through the Sessions Judge in the absence of special urgency.
165. Revision Cases:
- Rules 161 and 162 will apply mutatis mutandis to revision cases arising from cases other than
Sessions trials.Criminal Rules of Practice and Circular Orders, 1990

166. Communication of orders dismissing bail:
- Notwithstanding anything contained in the foregoing rules, a copy of the order of the High Court
dismissing an application for bail pending the disposal of a Criminal Revision Case or an appeal or
other proceedings in the High Court shall be sent to the concerned and also to the prisoner through
the Superintendent of the Jail in which he is confined and to no other person provided that where
bail is applied for on behalf of more than one prisoner and bail is granted to one or more prisoners,
Rules 161, 164 and 165 will apply.
167. Order of High Court on Appeal and Revision:
- Whenever the High Court certifies its judgment or order to a lower Court Section 388 or 405 of the
Code, it is the 'duty of the latter Court to issue the necessary warrant of release or modification of
sentence, or order for the refund of a fine, and in doing so it shall be governed by the provisions of
Rules 106, 108 to 111.
168. Duplicate copy of Order of High Court to be sent to Superintendent of
Jail:
- When an order of the High Court in appeal or revision is certified to a lower Court under Section
388 or 405 of the Code, it shall be issued in duplicate and the lower Court shall, on receipt of the
order, forthwith send copy of it to the Superintendent or Officer in-charge of the Jail in which the
prisoner is confined, along with the warrant, if any, required by Rule 167. If the High Court's order is
an order of release, one copy shall be sent direct from the High Court to the Superintendent or
Officer in-charge of the Jail.Note :- In Rules 167 and 168 the expression "Lower Court" means in the
case of a Judgement or order passed by the High Court on a revision petition against the finding,
sentence or order of an Appellate Court, the Appellate Court and not the Court of first instance.
169. State Brief:
- An Advocate shall be engaged at the cost of the State to defend an accused person who does not
engage an Advocate himself in the following cases:(1)Where he is under a sentence of
death.(2)Where he has been called upon to show cause why a sentence of death should not be
passed upon him; and(3)Where an appeal has been filed under Section 378 of the Code in case
involving a sentence of death or imprisonment.
170. Engagement of Advocate in certain cases:
- An Advocate may be engaged at the cost of the State in any other case in which the Court directs.Criminal Rules of Practice and Circular Orders, 1990

171. Fee in High Court:
- The fee payable to the Advocate appointed by the High Court shall be fixed by the High Court in its
discretion.
172. Return of records and material objects:
- On the termination in the High Court of a reference, Appeal, Revision case or other application or
matter the records of the case with the material objects, if any, shall be returned to the Court or
Courts from which they were received along with the judgment or order of the High Court
173. Return of enclosures:
- Copies of judgments, orders or other papers filed by parties in the High Court as enclosures to any
appeal, revision petition or other application shall on the termination of such appeal, revision
petition or application, be returned to them on a requisition made by them in that behalf under the
order of the Registrar.
174. In sentences of death, two sets of papers to be sent to the Government:
- In every case, in which sentence of death is passed or confirmed by the High Court two copies of
the Judgment of High Court with two sets of typed or cyclostyled evidence and of all other material
papers shall be forwarded to the Government in the Home Department
Chapter IX
Execution of Sentence
Warrant of Commitment
175. Committal Warrant to be in English:
- Every warrant of commitment shall be written in the English language or in the language of Court
and sealed with the seal of the Court It should mention the period of remand.
176. Separate Warrant for each Prisoner:
- When two or more persons are convicted and sentenced to imprisonment at the same time, a
separate warrant of commitment shall be issued for each of them.Criminal Rules of Practice and Circular Orders, 1990

177. No fresh warrant need be issued in cases under Section 432 or 433 or
434 of the Code or under Article 72 or 161 of the Constitution:
- Ln cases in which the Central Government or the State Government suspends, remits or commutes
a sentence under Section 432, 433 or 434 of the Code and in cases in which the President or the
Government grants a pardon, reprieve or remission under Article 72 or 161 of the Constitution, no
fresh or revised warrant need be issued.
178. Sessions Judge to fill in the particulars as to Diet etc., in warrant issued
by the High Court:
- Whenever the High Court in a case submitted to it by a Sessions Judge under Section 366 of the
Code, convicts the accused and passes sentence on him and issues a warrant of commitment to the
jail through the Sessions Judge, it is duty of the Sessions Judge, to fill in the particulars as to diet,
classification and other matters shown on the warrant before it is sent to the jail.
179. Convicts to be classified as "Habitual" or "Casual":
- Whenever possible a Court which convicts an accused person should decide whether he is to be
classified as an 'habitual' or 'casual' convict, and make a note of the decision on the warrant of
commitment for the information of the jail authorities.The following persons are liable to be
classified as "Habitual Criminals" viz.,(i)any person convicted of an offence punishable under
Chapters XII, XVII or XVIII of the Indian Penal Code, whose previous conviction or convictions,
taken in conjunction with the facts of the present case, show that he is by habit a robber,
house-breaker, dacoit, thief or receiver of stolen property, or that he habitually commits extortion,
cheating, counterfeiting coin, currency notes or stamps, or forgery ;(ii)any person convicted of an
offence punishable under Chapter XVI of the Indian Penal Code, whose previous conviction or
convictions taken in conjunction with the facts of the present case, show that he habitually commits
offences ;(iii)any person committed to or detained in prison under Section 122 read with Section 109
or Section 110 of the Code ;(iv)any person convicted of any of the offences specified in (i) above,
when it appears from the facts of the case, even though no previous conviction has been proved, that
he is by habit a member of gang of dacoits, or of thieves or a dealer in slaves or in stolen
property;(v)any person convicted by a Court or Tribunal acting outside India under the General or
Special Authority of the Central Government of an offence which would have rendered him liable to
be classified as habitual criminal if he had been convicted in a Court established in
India.Explanation: - For the purpose of this definition, the word "conviction" shall include an order
made under Section 117, r/w the Section 110 of the Code.(1)The classification of a convicted person
as a habitual criminal should ordinarily be made by the convicting Court, but if the convicting Court
omits to do so, such . classification may be made by Chief Judicial Magistrate, or in the absence of
an order by the convicting Court or the Chief judicial Magistrate and pending the result of a
reference to the Chief Judicial Magistrate by the Officer-in-charge of the Jail, where such convicted
person is confined:Provided that any person classified as a habitual criminal may apply for a
Revision of the Order.(2)The convicting Court or the Chief Judicial Magistrate for reasons to beCriminal Rules of Practice and Circular Orders, 1990

recorded in writing may direct that any convicted person or any person committed to or detained in
prison under Section 122 read with Section 109 or Section 110 of the Code, shall not be classified as a
habitual criminal and may revise such direction.(3)Convicting Courts or Chief Judicial Magistrates,
as the case may be, may revise their own classification and the Chief Judicial Magistrate may alter
any classification of prisoner made by a convicting Court or any other authority, provided that the
alteration is made on the basis of facts which were not before such Court or authority.
180. Levy of fine to be endorsed on the warrant or notified to the Jail
Authorities:
- When an accused person is sentenced to imprisonment as well as, or in default of payment of a
fine, the warrant issued to the Jail authorities shall contain definite information as to whether the
fine has been paid or not, in whole or in part If the warrant does not furnish this information, a
reference shall forthwith be made by the Jail authorities to the convicting Court to ascertain whether
the fine has been paid and the purport of the reply shall be noted on the warrant
181. Subsequent levy of fine to be notified to the jail Authorities:
- When the fine is paid or recovered in whole or in part after the admission of the prisoner into jail,
the responsibility for intimating to the jail authorities, the fact of the payment rest entirely with the
Court Such intimation shall invariably be acknowledged by the Jail authorities and the
acknowledgement shall be filed by the Court for future reference. On receipt of the intimation from
the Court, the Jail authorities shall endorse the information on the warrant Intimation sent by post
by the Court under this Rule shall be registered with acknowledgement due.
182. Intimation from Court to bear its seal:
- Intimation sent by a Criminal Court to the Superintendent of a jail that a fine which the prisoner
has been ordered to pay had been paid or recovered in whole or in part shall bear the seal of the
Court.
183. Warrants of commitment returned after execution to Form part of the
records of the cases:
- Warrants of the commitment which are returned to Courts after the execution of sentence should
be filed with the records of the respective cases and dealt with under the Rules for destruction of
records.
184. Notification of residence by released convicts:
(1)When an order has been passed under Section 356 of the Code, that a convict shall notify his
residence and change of residence after release for a specified term, the Court or Magistrate passing
such order shall enter a record thereof in the warrant of commitment issued under Section 418 ofCriminal Rules of Practice and Circular Orders, 1990

the Code in respect of such convict(2)Convict to state particulars of his intended residence: - A
convict in respect of whom such an order has been passed shall, when called upon by the
Officer-In-charge of the Jail in which he is confined, state before his release the place at which he
intends to reside after his release naming the village or town and the street therein.(3)To notify to
nearest Police Station: - After release and an arrival at his residence he shall within 24 hours notify
at the nearest Police Station that he has taken up his residence accordingly.(4)intention to change
residence to be notified: - Whenever he intends to change his residence he shall, not less than two
days before making such change, notify his intention at the nearest Police Station, giving the date on
which he intends to change his residence and the name of the village or the town and street in which
he intends to reside, and on arrival at such residence, he shall, within 24 hours, notify at the nearest
Police Station that he has taken up his residence accordingly.(5)Reasonable time to change his
residence: - The Officer recording a notification under either sub-rule (2) or sub-rule (4) shall
appoint such a period as may be reasonably necessary to enable the convict to take up his residence
in the place notified. If the convict does not take up his residence in such place within the period so
appointed, he shall, not later than the day following the expiry of such period, notify his actual place
of residence to the Officer-In-charge of the Police Station within the limits of which he is
residing.(6)Intimation of absence between sunset and sunrise: - Whenever a released convict
intends to be absent from the residence between sunset and sunrise, he shall notify his intention at
the nearest Police Station stating the time and purpose of such absence and the exact address where
he can be found during that period.(7)Notice to he given to change: - Every notice required to be
given by the foregoing rules shall be given by the released convict in person unless prevented from
doing so by illness or other sufficient cause in which case the notice required shall be sent either by
letter duly signed by him or by an authorised messenger on his behalf.(8)Officer to certify receipt of
notice: - Whenever the released convict gives any notice required by the foregoing rules, he will be
furnished with a certificate to the effect that he has given such notice by the Officer to whom he
gives it.(9)Copy of order and rules to be served on convict: - A copy of the order specified in sub-rule
(1) shall be served on the convict before his release from Jail A copy of these rules in English and the
Regional language shall at the same time be given to him, and the substance thereof fully explained
to him in a language he understands. He shall also be informed for what period he is bound to
observe these rules, and that any neglect or failure to comply with them will render him liable to
punishment as if he had committed an offence under Section 176 of the Indian Penal
Code.(10)Police to call upon convict and serve notice: - If a convict in respect of whom an order has
been passed under Section 356 of the Code shall have been released from Jail without a copy of the
said Order having been served upon by him, and the other Formalities specified in these rules
having been complied with, he may at any time, while the order remains in force, be called upon the
Police to report himself on a given day at a Police Station near the place where he is found, and on
his reporting himself, the copy of the order shall be served on him, and the other Formalities
prescribed in sub-rules (2) and (4) shall be complied with.Note :- In applying the above rules to the
case of a wandering man who has no "residence" in the sense of a fixed place of abode, they may be
reasonably interpreted as meaning that he resides at the place where he sleeps, even if he remains
there only one night On his release he may therefore, be asked under sub-rule (2) where he is going
to stay, and he may be told if he moves about the country, he must always notify the place of the
temporary abode to the police.Rules for levy of FinesCriminal Rules of Practice and Circular Orders, 1990

185. Rules for levy of fine:
- Rules under Section 421 (2) of the Code, for the execution of warrant for levy of fine and for the
summary determination of any claims made by any person other than the offender in respect of any
property attached in execution of such warrant.(1)A warrant for the levy of fine issued under Clause
(a) of sub-section (1) of Section 421 of the Code, shall be directed to a Police Officer and shall be in
Form No. 43 of Schedule II of the Code.(2)The authority issuing the warrant shall specify a time for
the sale of the attached property and for the return of the warrant.(3)The following articles shall not
be liable to attachment to sale viz.,The necessary wearing apparel, cooking vessels, beds and
bedding of the offender, his wife and children and such personal ornaments as in accordance with
custom or religious usage cannot be parted with by a woman, for example, Thali or wedding
ring.(4)The attachment of movable property belonging to the offender shall be made by seizure:
-Provided that, where, in addition to or in lieu of seizure, the Police Officer considers that either or
both of the methods referred to in Clauses (b) and (c) of Sub-section (3) of Section 83 of the Code
should be adopted, he shall obtain an order to that effect from the Court issuing the
warrant(5)When the method referred to in Clause (b) of sub-section (3) of Section 83 of the Code is
adopted and a Receiver is appointed, the powers, duties and liabilities of such Receiver shall be
same as those of a Receiver appointed under Order XL of the First Schedule to the Code of Civil
Procedure, 1908.(6)The Police Officer, who makes an attachment of movables under sub-rules (4)
and (5) may, after attachment, handover the articles attached to a third party on a Bond being
executed in Form No. 15-A of Appendix 'E' to the Code of Civil Procedure, 1908, for their custody
and production before the Court when required.(7)Before making the attachment, the Police Officer
shall deliver or tender a copy of the warrant, to the offender or, in his absence to any adult male
member of his family. If a copy cannot be so delivered or tendered, the Police Officer shall affix a
copy of the warrant at some conspicuous place where the property to be attached is found. After
making the attachment, the Police Officer shall, in like manner, deliver, tender or affix, as the case
may be, an inventory of the property attached.(8)If no claim is preferred to any property attached
within the time prescribed by the Code by any person other than the offender, the Police Officer
executing the warrant shall have power to sell within the time mentioned in the warrant and without
previous reference to the Court issuing the warrant, the property or such portion thereof as may be
sufficient to satisfy the amount to be levied :Provided that if the property attached consists of
livestock or is subject to speedy and natural decay or if its immediate sale would be for the benefit of
the owner, the Court may order the sale at once, but the proceeds of the sale shall not be
appropriated towards the fine until the expiration of two months from the date of the attachment,
and until any claim preferred under Rule 9, has been disposed of.(9)If any claim is preferred to any
property attached under sub-rules (4) and (5) within the time prescribed of the Code, by any person
other than the offender, on the ground that the claimant has an interest in such property and that
such interest is not liable to attachment, the claim shall be enquired into and disposed of as
provided in sub-rules (10) to (12) :Provided that, any claim preferred within the period allowed by
this rule, may, in the event of the death of the claimant, be continued by his legal
representative.(10)Claims may be preferred under sub-rule (9) in the Court by which the warrant is
issued if the claim relates to property attached under warrant endorsed by the District Magistrate
under Section 477 of the Code in the Court of such Magistrate.(11)Every such claim shall be
enquired into and disposed of by the Court in which it is preferred :Provided that, if preferred in theCriminal Rules of Practice and Circular Orders, 1990

Court of a Chief Judicial Magistrate, such Magistrate may make it over to any Magistrate.(12)The
enquiry shall be summary and the Court shall record its decision on the claim with the reasons
thereof. Such decision shall be final and shall forthwith be communicated to the Police Officer
executing the warrant who shall dispose of the property in accordance with such decision.(13)The
Police Officer or other officer authorised to sell, shall, as soon as possible after the sale, produce the
sale proceeds before the Court issuing the warrant or if the property was sold under warrant
endorsed by a District . Magistrate under Section 477 of the Code, in the Court of such
Magistrate.(14)Subject to the proviso to sub-section (1) of Section 421 of the Code and subject also to
Section 70 of the Indian Penal Code if, at any time subsequent to the return of the warrant, the fine,
or any part thereof, remains unpaid, and the Court has reasonable grounds for believing that the
offender has any movable property, it may issue a fresh warrant for the attachment and sale of such
property in accordance with the Code and these rules.Compensation under Section 357 of the Code
186. Payment of amount of Compensation:
- The Court by which a fine or any portion of a fine has been awarded as compensation under
Section 357 of the Code shall, on the application of the person to whom such compensation has been
awarded, grant an order for payment of the amount awarded direct to the Treasury to which such
amount has been remitted, together with a certificate to the effect that either (1) the sentence and
award are not subject to appeal or have been confirmed by the Appellate Court and that no order has
been received from the Court of Revision modifying or reversing the order of compensation, or (2)
where the order as to compensation has been modified in appeal or Revision, that the Payment
Order is in conformity with such modification or (3) that, the appeal time has expired and that no
appeal has been preferred and that no order has been received from the Court of Revision modifying
or reversing the order of compensation.Note :- If the fine is imposed in a case which is subject to
appeal, the order for payment shall not be granted till after the expiry of one or the other of the
periods specified in Section 357(2) of the Code.
187. Certificate as to appeal:
- In cases in which the Court awarding the compensation may be unable to certify whether an appeal
has actually been preferred, the party desirous of obtaining payment of the amount of compensation
in deposit may apply to the Appellate Court to certify whether or not any appeal has been preferred
and on such application being made, the Appellate Court shall grant the required certificate.
188. Compensation otherwise than under Section 357 of the Code:
- Compensation awarded under Sections 250 arid 358 of the Code, and compensation and all other
sums recoverable like fine under any other provision of law and not creditable to 'Administration of
Justice' should be dealt with in the manner provided in the foregoing rules for compensation
awarded under Section 357 provided that, if the order to pay such compensation or other sum is
reversed or modified in appeal or Revision, the payment order on the Treasury shall be given to the
party or parties entitled to draw the money.Reference to Government under Section 432 or Section
433 of the CodeCriminal Rules of Practice and Circular Orders, 1990

189. Application to Government to remit or commute sentence:
- Whenever a Sessions Judge or Magistrate shall be of opinion that there are grounds for
recommending to the Government to exercise the powers vested in them by Section 432 or Section
433 of the Code of remitting or commuting any sentence adjudged by the Criminal Court, the
recommendation for remission or commutation of the punishment shall be submitted to the
Government through the High Court.Every such reference shall be accompanied by a certified copy
of the record of trial or of such record thereof as exists.
190. Reference to Government in cases of infanticide:
- In all cases where women are convicted for the murder of their infant children, a reference should
be made, through the High Court, to the Government with an expression by the Sessions Judge of
his opinion as to the propriety or otherwise of reducing the sentence.Every such reference shall be
accompanied by certified copy of the record of the trial or such record thereof exists.
191. Report of Sessions Judge on reference under Section 432 to be
submitted to Government through High Court:
- In cases in which the opinion of Sessions Judge is called for by the Government under Section 432
of the Code, the Sessions Judge's reply should be forwarded through the High Court whether the
requisition for the opinion has been received through the High Court or not.Chapter-X
RecordsPreservation of Records
192. Custody of Records:
- A Sessions Judge or a Magistrate should not permit the original records of Criminal trials in his
Court to leave his custody except in accordance with the express provisions of law, save as provided
in Rule 204 to 209 and any person not legally competent to demand production of the originds
whether an official in the Government Service or a private individual, should, if he wishes to
examine the record, be required to apply for and obtain certified copies in accordance with the Rules
made in that behalf.
193. Records to be kept in packet, sealed and labelled:
- The Public records or documents shall, so long as they remain in the custody of Court which
required their production, be kept in a sealed packet properly, labelled and the packet shall not be
opened except in the presence of the Presiding Judge or Magistrate.
194. Summons for production of documents in the custody of Parliament or
State Legislature:Criminal Rules of Practice and Circular Orders, 1990

(1)Whenever any document in the custody of Parliament or of any State Legislature is required by a
Court, it should first be seen whether the document is unpublished, in which cause alone, summons
need issue. Published document, such as the proceedings of the Parliament can be proved under
Section 78(2) of the Indian Evidence Act, 1872 by the Production of authorised Parliamentary
publications.(2)As far as possible, only certified copies should be called for in the first instance and
the original documents may be requisitioned only at a later stage of the proceedings, when the
parties, insist upon their strict proof.(3)It should be specifically stated in the summons whether the
production of a certified copy will be sufficient or whether an officer must appear before the Court
with the original document(4)Summons for the production of documents in the custody of Lok
Sabha or the Rajya Sabha may be issued to the Speaker of the Lok Sabha or to the Chairman of the
Rajya Sabha, as the case may be. Similarly, in respect of documents in the custody of a State
Legislative Assembly the Speaker or the Chairman in the case of the Legislative Council, as the case
may be, should be addressed for their production.Production of records from Court and Public
Officers
195. Summoning of documents from another Court or Public Officer:
- Before issuing summons for the production of a document in the custody of another Court, or
Public Officer, the Court shall consider whether the interested party should not be required to
obtain and file a certified copy thereof. The original shall ordinarily be summoned only if the Court
is satisfied that it would entail unreasonable expense or delay to obtain acertified copy or that the
production of the original is necessary for the purpose of justice.
196. A list of records retained by a Court to be given to the producer:
- Where records as documents produced from any Court or Public Officer are retained by the
Criminal Courts requiring their production, a receipt containing a descriptive list thereof shall be
given to the Officer producing them and a duplicate of the receipt shall be placed with the records or
documents. Any apparent erasure or alteration in any paper shall be noted in the said list
197. Packets to be opened in the presence of Judge or Magistrate:
- When any records or official documents are received from any Court or Public Office by post, the
packet shall be opened in the presence of the presiding Judge or Magistrate and the papers
compared with the list accompanying them. The instructions contained in the Rules 193 to 196 shall
then be observed as far as they are applicable.
198. Requisitions from PubliC Officers for production of Judicial Records:
- In complying with requisitions from Public Officers for the production of judicial records, Criminal
Courts should follow the above rules. They should also see that the requisition is in the proper Form
prescribed by the law.Submission of Records to High CourtCriminal Rules of Practice and Circular Orders, 1990

199. Prompt submission of Records:
- Criminal Courts shall see that records called for by the High Court are submitted promptly. Any
delay shall be explained in the letter advising despatch of the records.The following cases shall be
treated as urgent -(i)Reference under Section 366 of the Code ;(ii)Appeals or Criminal Revision
Cases in which the accused have been called upon to show cause why sentence of death should not
be passed on them ;(iii)Appeals against acquittal in which the accused are rearrested and are in
custody ;(iv)Criminal Revision Cases or Appeals in which notice for enhancement of sentence has
been issued and the accused are in jail on short sentence ;(v)Criminal Appeals and Revision Cases in
which bail is refused and the accused are in Jail or short sentences ; and(vi)Criminal Appeals and
Revision Cases where stay of proceedings in any Criminal case is ordered pending their disposal.
200. Records to be submitted to the High Court:
- The following records shall be submitted: -(1)In cases submitted under Section 366 of the Code,
and in all cases of conviction for murder whatever may be the sentence passed by the Court and in
all cases of Appeals against acquittals in Murder cases.(a)The entire original. Sessions record.(b)The
entire original Magisterial record.(c)Translations of such parts of (a) and (b) which are not in
English.Note :- With regard to translations referred to above: -(i)It will suffice if only those parts of
the inquest report which have been admitted in evidence are translated.(ii)It is not necessary to
translate papers which have not been treated as evidence in the case.(iii), Translations of documents
submitted to the High Court shall be written on one side of the paper only. A fair margin shall be left
and the lines shall not be too close to one another.(2)In cases of Appeals not already provided for
and in cases of Revision: -(a)The material part of original case record including an extract from the
Diary.(b)The material part of the Appellate Case Record, if any.(3)Meaning of Entire Original
Sessions Record: - The words "entire original Sessions record" include the evidence, oral and
documentary, the charge, the plea of the accused, the Judgment and the statement of the accused, if
any.(4)Meaning of the Entire Original Magisterial Record: - The words "entire original Magisterial
record" include an extract from the Diary, Register of Preliminary Enquiry, Police occurrence
Reports, Mahazars, the Village Officers Reports,' and Proceedings (if any) before any Magistrate
other than the Committing Magistrate, who may have dealt with the case, but do not include so
much of the Magisterial Record as may have been incorporated in the Sessions Court
record.(5)Covering letter: - The covering letter for all records shall be sent separately from them by
post Any delay in submitting the records shall be explained in the covering letter advising despatch
of records. It shall state when and how and in how many separate files the records are
despatched.(6)In every case sent up to the High Court ;(a)The records in English and in the regional
language: - The English Tart of the Sessions records, if any including translations ;(b)The part of the
Sessions record in the regional language, if any ;(c)The English part of the Magisterial record
including translations; and(d)The part of the Magisterial record in the regional language must be
bound and indexed separately.(7)Copies of Judgment: - Spare copies of Judgment in English in
cases referred under Section 366 of the Code and six copies in other Sessions trials should be sent
with the record.They should not be paged and entered in the index but should be kept separate from
the record.(8)Docket to specify number of cases: - The Docket or the fly-leaf of all records and the
covering letter should specify the number of the case on the lower Court's file and the number of theCriminal Rules of Practice and Circular Orders, 1990

Appeal or Revision Case or Petition on the High Court's file.Note :- The fly-leaf shall be of sufficient
thickness and of foolscap size.(9)Foolscap paper to he used: - The calendar, translations, copies,
notes of evidence etc., shall wherever possible, be written on foolscap paper of sufficient
substance.(10)Examination and certifying before despatch: - Every record shall, before despatch to
the High Court, be examined and certified as complete in accordance with the foregoing rules by the
Head Ministerial Officer of the Court forwarding it.Where copies of depositions, verified as to
accuracy or not, are made out for the use of the Judge or for any other purpose and are available,
they shall be submitted to the High Court with the records in facilitate printing or typing of the
evidence, if necessary. Indication shall, however, be given in the covering letter or in some
prominent place in the copies themselves to show whether the copies are accurate or whether they
require to be compared with original
201. Index, how to be filled up:
- In filling up the indexes accompanying records of Criminal Cases, the names of witnesses shall be
written in full together with their Official designation, if any, within brackets.
202. English translation of statements of the accused in regional language to
be kept in English Record:
- Court of Sessions when sending up the statements of the accused recorded in the regional language
shall place in the corresponding part of the English record, accurate translations of these
statements. The notes made by the Judge during the examination cannot and will not be accepted in
lieu of such translations.
203. Police diaries etc., how to be sent:
- Police Diaries and English translations of or notes from these diaries submitted to the High Court
should be placed in a sealed cover.Inspection of Records
204. Inspection by Officers of the Police or the Excise Department and Public
Prosecutor:
- Whenever it appears to any Officer of the Police or the Excise Department not below the rank of a
Sub-Inspector, that an inspection of the records of any Criminal trial or appeal which facilitate any
detection or prevention of crime is necessary or is desired for examination of the conduct of Officers
connected with the case and whenever the inspection of such records may be desired by a Public
Prosecutor or Asst. Public Prosecutor, in the exercise of his duty as such Officer or Public Prosecutor
or Asst. Public Prosecutor as the case may be, may apply to the Sessions Judge or Presiding
Magistrate of the Court in which the records are lodged for permission to inspect the same.Criminal Rules of Practice and Circular Orders, 1990

205. Procedure on application:
- The application referred to in the preceding rule shall be made in writing and shall contain a
description of the records and shall state the purpose for which the inspection is sought, and the
Sessions Judge or Magistrate may grant or refuse the application as he may, see fit. If the
application is refused, the Sessions Judge or Magistrate shall record the reasons for refusal and shall
communicate a copy thereof to the Officer concerned, or to the Public Prosecutor, as the case may
be. If the application is granted, the Sessions Judge or Magistrate shall make arrangements for
permitting the inspection to be conducted in accordance with Rule 206.
206. Conduct of Inspection:
- Every inspection of records under these rules shall be conducted by an officer of the Police or the
Excise Department not below the rank of Sub-Inspector, or, if the inspection is granted on the
application of a Public Prosecutor or Asst. Public Prosecutor, then by the Public Prosecutor or Asst
Public Prosecutor himself. It shall take place within the precincts of the Court in which the records
are lodged and in the presence of an Officer of the Court who shall be deputed by the Sessions Judge
or Magistrate for the purpose, and no record or part of a record shall be removed by the Inspecting
Officer from the precincts of the Court
207. Inspection by Public Prosecutor, Andhra Pradesh:
- The Public Prosecutor, Andhra Pradesh, if he wishes to inspect the original records of Criminal
Courts should request the High Court through the Registrar.
208. Inspection by Officers of other Departments:
- Subject to the conditions laid down in Rules 204 to 206 the privilege of Inspecting records in a
Criminal proceeding is extended to -(1)Officers of the Salt and Customs Department In-charge of a
Circle, Assistant Inspectors and Inspectors of Excise, Commercial Tax Officers and Gazetted Officers
of the Forest Department, so far as such records relate to their respective Departments and
-(2)Officers of the Income Tax Department including the Special Investigation Branch attached to it,
not below the rank of Income Tax Inspector duly authorised by Income Tax Officer, in respect of
records other than Police case Diaries and reports and any confidential portion of such
records.(3)Officers of the Revenue Department of and above the rank of Mandal Revenue Officer.
209. Taking extracts:
- An officer inspecting records under these rules can take extracts there from, if he considers it
necessary to do so.Criminal Rules of Practice and Circular Orders, 1990

210. Inspection by Collector of Records of Court of Sessions:
- Whenever a Collector requires information with regard to the Sessions trial in addition to that
appearing in the finding and sentence of the Court of Sessions he shall be at liberty, after giving due
intimation to the Sessions Judge to depute one of his clerks to inspect the records and make copies
or extracts of such parts thereof as may appear material for the purposes which the Collector has in
view, and the Sessions Judge shall permit such clerk to inspect the records and take copies or
extracts thereof. Every inspection of records under this rule shall be made within the precincts of the
Court of Sessions in which the records are lodged and in the presence of the Officer of the Court
deputed by the Sessions Judge for the purpose. No record, or part of a record shall be removed by
the Inspecting Officer from the precincts of the CourtCopies of Records
211. Uncertified copies not to be granted:
- No copies of, or extracts from, the record of any proceedings of any Criminal Court subordinate to
the High Court shall be issued unless certified to be true by the proper Officer of the Court This Rule
shall not apply to copies or extracts granted to prisoners in confinement under any order passed in
such proceedings for the purpose of appeal or application for revision.
212. Copies to be given to parties:
- Copies of any portion of the records of a Criminal Case must be furnished to the parties concerned
on payment of the proper stamp and the authorised fee for copying. Where the Judge's note Forms
the only record of the evidence copies of these notes should be given.Explanation: - 'Proper Stamp'
referred to above includes search fee leviable under the Standing Orders of the Board of Revenue,
Board's Standing Order No. 173 (Section I).(2)[ 325-2]Scale of search fee: - When the document
applied for belongs to a year previous to the current calendar year, search fee in Court-fee stamps,
according to the sub-joined scale, must be affixed to the application.
(i)When the document belongs to any year prior to the calendar yearbut is not more than 10
years old -
 Rs.
Ps.
(a) Fee payable for thefirst document or entry applied for or if only one document orentry is
applied for, then for that document or entry.1-00
(b) Fee payable for everydocument or entry other than the first include in the
sameapplication and connected with the same subject0-50
(c) When the applicantdoes not know to which of two or more years a document or
entrybelongs, the fee for searching the records of every year otherthan the first0-50
(ii)When the document is more than 10 years old but does not relateto any year prior to 1858
- 
(a) Fee payable for thefirst document or entry applied for or if only one document orentry is 2-00Criminal Rules of Practice and Circular Orders, 1990

applicable for, then for that document or entry.
(b) Fee payable for everydocument or entry other than the first included in the
sameapplication and connected with the same subject1-00
(c) When the applicantdoes not know to which of two or more years a document or
entrybelongs, the fee for searching the records of every year otherthan the first1-00
(iii) When the document belongs to a year prior to 1858 -  
(a) Fee payable for thedocument or entry applied for or if only the document or entry
isapplied for that document or entry.5-00
(b) Fee payable for everydocument or entry other than the first included in the
sameapplication and connected with the same subject2-50
(c) When the applicantdoes not know to which of two or more years a document or
entrybelongs, the fee for searching the records of every year otherthan the first2-50
Note :- (1) Only one search fee at the rate applicable to the documents need be paid for all papers
filed together and if a person applies for all the depositions relating to Magisterial case, he need only
pay one fee applicable to the whole record in which they are filed. But in the case of Oake's Register
or Stration's Report or Circuit Committee Accounts, separate search fee shall be levied for each item
contained in the same volume.(2)The Search Fee Rules are applicable to Judicial as well as to
revenue records. The fee should be levied in respect of all documents of which copies are applied for
in Civil and Criminal cases, provided that the application of the rules to Judicial Record is not
inconsistent with any special provisions of law or notifications having the force of law by which
Courts may be required to grant copies or to allow the inspection of documents free of charge.
213. Procedure when documents for which copies applied for are in other
Court:
- If the records of the case or the documents of which a copy is applied for have been sent to another
Court, the application for the copy, may, at the option of the applicant, be forwarded to the said
Court for compliance or be returned to him for presentation to the said Court.
214. Copies by whom certified:
- The corrections of all copies of Magisterial records on application of private persons and of all
copies of calendars and Judgments to be submitted to the Sessions Judge or the Chief Judicial
Magistrate may be certified by the Chief Ministerial Officer of the Magistrate's establishment.
215. Endorsement on copies:
- Every copy shall bear an endorsement showing the following dates: -(i)Application made.(ii)Stamp
papers (or charges) called for.(iii)Stamp papers (or charges) deposited.(iv)Copy ready.(v)Copy
delivered or posted.Criminal Rules of Practice and Circular Orders, 1990

216. Notice of certified copies ready for delivery:
- A list of certified copies ready for delivery shall be posted on the Notice Board of the Court
concerned and shall remain there for one week. The list shall state the number of the copy
application and the names of the persons to whom the copies are to be delivered. The list shall be
affixed to the Court Notice Board immediately the Court opens on the following day. After the expiry
of one week, the list shall be taken down and any copies which remain unclaimed shall be sent to the
applicants by post, "Service unpaid".
217.
(1)Copies to Government Officers:- The Gazetted Officers of all Departments and all Officers who
not being Gazetted Officers, are entitled to inspect records can obtain certified copies of the same
Except as regards Officers of the Police and the Excise Departments and Public Prosecutors and
Assistant Public Prosecutors such right extends only to obtaining certified copies of records relating
to the Officer's own Department(2)Order of refusal to contain reasons:- The judge or Magistrate
may in his discretion grant or refuse the application. If the application is refused, the Judge or
Magistrate shall record the reasons for his refusal and shall communicate a copy thereof to the
Officer concerned.(3)Inter departmental Supply of Copies: - Copies of orders of records which one
Department of Government propose to supply to another Department on application, shall be made
on plain unstamped paper and by the ordinary staff.(4)Lengthy records: - If lengthy records are
concerned, the work should be transferred to the Copying Staff and the decision as to who should
prepare the copy rests with the Officer to whom the copy application is made.The Department
applying for copies should furnish copy stamp papers for the purpose and debit the cost thereof to
its contingent charges:Provided that the cost of making copies of Judgments convicting or
acquitting Government servants of criminal offences or of orders discharging such servants which
are supplied on application to the heads of Departments concerned, shall be debited to the
contingent charges of the Courts supplying the copies.Explanation 1: - "The Heads of Departments"
in the foregoing proviso, shall include a Head of Department of the Central Government
also.Explanation 2: - "The Post Master General" Hyderabad shall be deemed a Head of Department
for purposes of the foregoing proviso.(5)Copies to Jail Department: - The Jail Department shall,
however, be supplied with copies of judgment on plain unstamped paper. If extra staff is required
for this purpose, the Government may be addressed for the employment of Section writers
temporarily.(6)Copies to Public Prosecutor: - The above principles also apply to the grant of copies
to Public Prosecutors. Copies of documents which are required by them while the trial or appeal is
pending, should be made by the clerk of the Court of Sessions In-charge of the records or by
someone working in his presence and under his immediate supervision. No charge should be made
by the regular establishment of the Court. In cases where lengthy documents have to be copied and
the work is done by the Copyist Department, the cost of the stamp-papers used for the same should
be debited to the contingent allowances of the Courts issuing copies.(7)Copies of relevant records in
Criminal Appeal to Public Prosecutor: - Copies of relevant records in any criminal proceedings
should be supplied to the Public Prosecutor of the District concerned on his application, with a copy
stamp-paper or on plain-paper at the discretion of the Judge or Magistrate.Note :- "The Director
General of Police is requested to ensure that his subordinate officers do not make unnecessaryCriminal Rules of Practice and Circular Orders, 1990

applications for copies and Criminal Courts should bring to the notice of the Superintendents of
Police, any cases in which the right to ask for the copies appears to them to have been
abused."Return of Records
218. Return of records when no longer required:
- Whenever it shall appear that any public documents received from any Court or Public Officer are
no longer required, they shall be returned to such Court or Office with a descriptive list in a sealed
packet.
219. Return of documents - application to be made therefor:
- Applications from parties or other persons for the return of documents filed in Court shall be made
to the Court in which they were originally filed. If application is made for any document which has
been transmitted to another Court, the Court in which the document was originally filed shall itself
apply for the transmission of the documents and on receipt shall return it to the applicant :Provided
that no document shall be returned unless the Judge or Magistrate is satisfied that it will riot be
required for reference in proceedings pending either before his own Court or the Court of Appeal or
Revision.Chapter-XI Case PropertiesCustody of Case Property
220. Responsibility of Presiding Officers:
- Presiding Officers are personally responsible for the safe custody of the case properties. Only clerks
who have furnished the required security should be placed in-charge of properties, but that does not
relieve the presiding officers of their responsibility to any extent
221. Inspection of Case Properties:
- Every article received in Court should immediately after receipt be inspected by the Presiding
Officer or a responsible Officer of the Court duly authorised by him and entered in the Property
Register then itself.The Presiding Officer should check the valuable and non-valuable items of
property periodically and satisfy himself that all items received in Court are properly accounted for,
that they are safely kept and that orders of disposal are promptly carried out.Whenever there is a
change of Officers the succeeding Officer should examine all the properties other than valuable
relating to the Court as soon as possible after he take charge and certify in the Registers themselves
that he has taken over the properties specifying them with reference to their item numbers. The
valuable properties referred to in Rule 727 should be verified at the time of taking over-charge
necessary certificate affixed in the Register.
222. Valuable Properties:
- All articles of value should be separated from other items. They should be kept in (a) boxes
sufficiently strong and fitted with good-lock and key (b) properly protected against damage byCriminal Rules of Practice and Circular Orders, 1990

moisture, insects, etc. They should invariably be deposited in the Sub-Treasury.Submission of
Material Objects
223. Selection of Material Objects to be sent to the High Court:
- The Sessions Judge shall in his discretion send weapon, substance or article whereby the offence is
said to have been committed and all garments stained with blood, provided the objects can be
conveniently transmitted and are of assistance to the High Court.Courts of Session shall enclose
with the records in Sessions Cases submitted to the High Court a list of material objects in Judicial.
Form No. 129-A.
224. Note to be made, if any Material-Object is retained:
- In every case in which any material object is retained, the order of the Judge directing such
retention should Form part of the record submitted to the High Court, classified under item 8,
"other miscellaneous papers if any" with English part of the Sessions Record, the page assigned to
the paper being shown against item 6(b).
225. Return to be obtained within one month:
- Articles received from lower Courts such as sticks, stones, knives, bill-books, axes, guns, rags of
clothing, earth etc., and all articles of trifling value are ordinarily retained in the High Court and
destroyed there. Any application for the return of these articles (for return to parties or for reference
in any other case) or of any articles that the High Court has omitted to return, shall be made within
one month from the date on which the records of the case are received back in the lower Court
226. Properties in Sessions Cases may be sent to Committing Magistrates for
disposal:
- The properties in Sessions Cases which have to be dealt with under Section 452 of the Code may be
forwarded to the Committing Magistrate excepting in such individual cases where the Sessions
Judge directs otherwise.Disposal of Case Property
227. Judgment to contain Orders for disposal:
- Orders for the disposal of material objects should be passed in the Judgment itself.
228. When Material-Objects are to be disposed:
- Material objects exhibited at the trial of criminal cases should be retained by the Court until the
Court is satisfied that the appeal time has expired and that no appeal has been presented or that any
appeal presented has been disposed of. But when a case is disposed of by High Court, the material
object shall ordinarily be disposed of after the expiry of 90 days from the date of judgment of theCriminal Rules of Practice and Circular Orders, 1990

High Court, unless in the meantime, -(1)the parties interested have, on a proper application,
obtained a direction from the High Court for preservation of such objects, pending disposal of an
application for leave to appeal to the Supreme Court under Article 134(1)(c) of the Constitution of
India, or a Special Leave Petition ; or(2)intimation of Appeal preferred to the Supreme Court of
India under Article 234(1)(a) and (b) of the Constitution is received.After that, they may be
destroyed or otherwise disposed of according to the Rules.
229. Destruction of Case Property:
(1)Orders for the destruction of case property should be carried out in the presence of the Presiding
Officers.(2)It is not desirable to order destruction of valuable property. It should, if it is not ordered
to be delivered to the person entitled to it be confiscated or otherwise disposed of.
230. Confiscated Articles:
(1)When the material object is confiscated weapon other than a fire arm or ammunition and is in the
opinion of the Sessions Judge of a most unusual character or of special interest in the light of the
facts of the case it shall be transferred to the Medical College, Tirupathi in the case of the Sessions
Courts of Anantapur, Chittoor, to the Medical College, Kurnool in the case of Sessions Courts of
Cuddapah, Kurnool and Nellore, to the Medical College, Guntur in the case of Sessions Courts of
Guntur, Krishna and West Godavari and to the Medical College, Visakhapatnam in the case of
Sessions Courts of Visakhapatnam, Srikakularn and East Godavari and to Osmania Medical College,
Hyderabad in case of Sessions Courts in Telangana area. It shall first be ascertained by a reference
to the Medical College concerned whether the article is required by it or not Similar reference should
also be made to the Police Museum, at Hyderabad. If the article is required by both the Medical
College and the Police Museum, the Former will have priority over the latter. Only when the article
is not required by either the Medical College or the Police Museum then it should be destroyed.(2)In
the case of art objects and antiquity the Court shall communicate with the Director of Archaeology
and Museums and if he desires, send them to him.(3)Gold ornaments shall be sent to Mint Master
through a responsible Officer by pre-arrangement
231. Delivery of Case Property to the person entitled:
- When any property ordered to be delivered to a party, notice should be issued to him in Judicial
Form No. He should also be informed that if he does not appear on the date specified in the notice,
the property will either be destroyed or sold and the sale proceeds credited to Government If the
party appears after the sale of the property, the sale proceeds may be paid to him deducting
expenses of the sale.
232. Sale of Case Property:
- Sale of property should be conducted by an Officer of the Court and should be by public auction. It
should be conducted and confirmed as far as may be in the manner prescribed for the sale ofCriminal Rules of Practice and Circular Orders, 1990

movable property by the Code of Civil Procedure and Civil Rules of Practice.
233. Procedure regarding disposal of Excisable Goods:
- In the case of excisable goods held in the custody of Criminal Courts, notice of the date of auction
or other method of disposal shall be issued to the Excise Authority concerned requiring such
authority to arrange for the collection of the duty leviable if any, on the goods and for the issue of
transport permit where necessary. The Excise Authority may also be required to satisfy itself that
the purchaser in auction or otherwise is licensed to deal in such goods.
234. Disposal of Counterfeit coins and Forged Currency Notes:
(1)When counterfeit coins have to be disposed of by a Criminal Court under Sections 452, 457 or 458
of the Code, they shall be forwarded together with any dies, moulds etc., which may have been
produced in the case to the nearest Treasury of Sub-Treasury, with request that they may be
remitted to the Mint for examination. A concise and accurate report should also be sent containing a
description of the case and the sentence imposed.(2)In the cease of forgery of currency notes, the
disposal of implements such as moulds, dies etc., produced in and confiscated by a Court, is a matter
for the decision of the Court which tries the case and when they are ordered by the Court to be
delivered to the Police for destruction, the Police shall themselves arrange for their destruction and
not send them to the currency offices or Mint for destruction, provided that if the Police consider
any particular implements are of special interest and should be preserved, they shall make them
over to the Criminal Investigation Department for this purpose.(3)All forged currency notes brought
before the Court shall be handed over to the Police for being forwarded to the Issue Department of
the Reserve Bank of India, with a brief report of the case.(4)All arms and Ammunitions of preserved
bore which are confiscated should be sent to the nearest Arsenal for disposalChapter-XII Collection
of Process fee and Payment of Batta to Complainants and WitnessesFee for Service of Process
235.
All processes issued by Criminal Courts shall be charged to the Court-fee at the rates set out in the
schedule hereunder -
ScheduleRs.
Ps.
1. Every summons notice or sub-poena  
(a) to an accused, respondent orwitness 0-50
(b) to every additional accused,respondent or witness resident in the same village
orneighbourhood if the summons notice or the sub-poena is appliedfor at the same time0-25
2. Every warrant of arrest 0-75
3. Every order, injunction or warrant not otherwise providedfor 0-50
(1)In Courts outside the cities of Hyderabad and Secunderabad if a process is to be served orCriminal Rules of Practice and Circular Orders, 1990

executed within a radius of six miles from the Court-house, half the above rates only shall be
charged. The Judge of every Court shall determine what villages are within the above radius, and a
list of such villages shall be notified in a conspicuous place in the Court-house.(2)When a warrant
remains unexecuted for 15 days after its delivery to the Officer entrusted with its execution, an
additional fee at the same rate shall be levied from the party at whose instance the warrant was
issued for every 15 days or part thereof until return is made, provided that the delay in executing the
said warrant is not attributable to the Officer of the Court(3)This rule does not apply to proceedings
in Cognizable cases instituted on police reports whether these be calendar cases, appeals or Revision
Cases.Exemption: - No fee shall be levied on processes issued upon complaints by public servants or
Officers or servants of a Railway Administration acting in their official capacity, which under
Section 67, Clause XI of the Andhra Pradesh Court-fee and Suit Valuation Act, 1956 (Act VII of
1956) are exempt from complaint fee.As the Central Government has ruled that a Cantonment
Authority is not a "Public Officer" as defined in the Code of Civil Procedure, 1908, the process fee
and diet money to witness shall in all cases of prosecutions by the Police on their behalf be collected
from the Cantonment Authority. A Cantonment Authority, is however, exempt from the payment of
Court-fee on complaints, under Section 19 of the Court-fee Act, 1870 as it is a "Public Servant" as
defined in Section 21 of the Indian Penal Code.Expenses of Complainants and Witnesses
236. Expenses when payable by Government
: - Subject to the provisions hereinafter contained, the expenses of complainants and witnesses will
be paid on behalf of the Government, in the following classes of cases viz.,(a)Cases shown in the
second schedule of the Code as non-bailable.(b)Cases in which the prosecution is instituted or
carried on under the orders or with the sanction of the Government or of any Public Servant acting
as such.(c)Where the witness in question has been compelled to attend by a process issued under
Section 311 of the Code.(d)Cases in which the Court certifies that the attendance of such witness was
directly in furtherance of Public Justice.If any witness in any of the aforesaid classes of cases is, by
reason tender age, sex or bodily infirmity, unable to travel alone to the Court and is accompanied by
an escort, such an escort may, at the discretion of the Presiding Officer of the Court, be paid his
expenses under these rules, provided that no such payment shall be made to the escort, if he/she is
himself a witness in the case.The Court may make reasonable advances to witness compelled to
attend to give evidence, when such pre-payment is considered necessary.
237. Disallowance of payment of expenses on behalf of Government:
- It shall be competent to the Court before which a complainant or witness appears to disallow
payment of any expenses on behalf of Government, if for any reason to he recorded, such Court
thinks fit to do so, or to pay only the actual expenses incurred by him if the complainant or witness
is a resident of the place in which the Court is situate, or to pay, if the Court thinks fit, expenses at
rates lower than those prescribed in Rule 247.Criminal Rules of Practice and Circular Orders, 1990

238. Disallowance of expenses for defence Witnesses:
- The Court will disallow the whole or part of the expenses of any witness for the defence, whose
evidence may not seem fit to have been material unless it is satisfied that such witness has been
brought to the place in which the Court is situate against his will and that no compensation for his
expenses has been paid or deposited by the accused.
239. No travelling allowance when complaint is dismissed under Section 250
of the Code:
- Whenever a Magistrate dismisses a case as frivolous or vexatious under Section 250 of the Code,
no travelling allowance or batta shall be granted to the complainant.Official Witness
240.
(1)For the purpose of these rules, witnesses are divided into two classes, viz., Officials and
non-officials. Official witnesses, ie., Government Servants to whom the Andhra Pradesh Travelling
Allowance Rules are applicable, summoned to give evidence as officials, are entitled to receive for
their journeys to and from the Court and for the time spent by them in attendance at the Court to
give evidence in cases coming under Rule 236 travelling allowance at the rates prescribed by the
Andhra Pradesh Travelling Allowance Rules for the time being in force. The Court shall not
however, make any payment to official witnesses in such cases, but shall grant them certificates
setting forth that they appeared to give evidence of what had come to their knowledge, or of matters
with which they had to deal in their official capacity, the date on which they appeared and the period
for which were detained, so as to enable them to draw travelling allowance and batta under the
Andhra Pradesh Travelling Allowance Rules.(2)When a Government servant appears in his official
capacity as a witness in other cases (e.g., in cases in which Section 254(3) or 247 of the Code is
applied), the party at whose instance he is summoned shall prepay into Court the travelling and
halting allowances admissible to him under the Andhra Pradesh Travelling Allowance Rules. The
amount so prepaid shall be credited to Government, but the Court shall give the witness a certificate
containing the particulars specified in sub-rule (1) supra, so as to enable him to draw the travelling
and halting expenses admissible under the Andhra Pradesh Travelling Allowances Rules. When a
Government servant appears to give evidence in any case as a private person, travelling allowance
and batta may be paid to him in the ordinary manner, but the Court shall send an advice of all such
payments made to him to the Head of the Office in which he is employed. In this advice, the amount
paid as batta and the period during which the attendance of the witness in Court was necessary shall
be stated.(3)When a Government servant whose emoluments are governed by the Army
Regulations, appears in any case under sub-rule (1) to give evidence in his official capacity, he shall
be paid the travelling allowance and batta admissible under these rules and shall be furnished with a
certificate showing in detail the amount paid. If the amount paid is less than the amount admissible
to him under the Military Rules to which he is subject. the difference will be paid to him by the
Military Authorities on production of the certificate.(4)A retired Government servant who appears
before a Criminal Court to give evidence in respect of his official acts or matters within his officialCriminal Rules of Practice and Circular Orders, 1990

knowledge before retirement shall be paid travelling and subsistence allowance according to the
rates to which he would have been eligible under the Andhra Pradesh Travelling Allowance Rules,
had he not retired from service.(5)When any person who holds an office under the Government in a
honorary capacity appears before any Court at his headquarters to give evidence in that capacity, he
may be paid conveyance allowance at such rate as the Government may by order specify.
241. Witnesses of Local Fund or Municipality:
(1)Government servants whose services are lent to local authorities as defined in Section 3(31) of the
General Clauses Act, 1897, attending Criminal Courts to give evidence in their official capacity, shall
be paid travelling and daily allowance to which they are eligible under the Andhra Pradesh
Travelling Allowance Rules.(2)Medical subordinates in the service of local authorities including
compounders, midwives and nurses attending Criminal Courts to give evidence in their official
capacity shall be paid travelling and daily allowances at the rates admissible to officers of
corresponding grades under the Andhra Pradesh Travelling Allowances Rules.(3)Persons in the
service of Local Authorities other than those governed by sub-rules (1) and (2) shall be paid
travelling and daily allowances at rates to which they are eligible under the Rules, if any, applicable
to them.(4)For purposes of payment of travelling and other expenses, Courts shall follow the
procedure prescribed in sub-rule (1) of Rule 240 for payment of allowances to Government servants.
242. Rural Medical Practitioners:
- Rural Medical Practitioners when attending Court to give evidence in their capacity of Rural
Medical Practitioners shall be paid the same rates of travelling allowances and batta as would be
admissible to Government servants belonging to Grade IX of the Andhra Pradesh Travelling
Allowances Rules.
243. Honorary Medical Officers:
- Honorary Medical Officers when attending Court to give evidence in their official capacity shall be
paid the same rates of travelling allowance and batty as would be admissible to Government
servants belonging to the respective grades of the Andhra Pradesh Travelling Allowances Rules, as
set out below :-
Honorary Surgeons and Honorary Physicians Grade IV
Honorary Assistant Medical Officers Grade V
244. Officials of the Central Government or Governments of other States:
- Officials employed by the Central Government or by the Government of any of the States
mentioned in the first schedule to the constitution of India appearing in cases, in which the State is a
party, as witnesses on summons before the Criminal Courts of other States to give evidence
regarding facts, of which they have official knowledge, will, on production of certificates of
attendance issued by the Courts before which they appear as witnesses, be paid travelling allowanceCriminal Rules of Practice and Circular Orders, 1990

by the Government under whom they are employed at their own rates. In cases where the State is
not a party, such officials will be paid travelling allowance by the summoning Court according to the
rules under which such Government servant draws his travelling allowance for a journey on tour
and the charges will be borne by the Central Government or the State Government according as the
summoning Court is situated in a centrally Administered area or within the local limits of a State.In
order to enable the Court to assess the amount admissible to a Government servant in cases where
the State is not a party, the Government servant should produce before the summoning Court a
certificate duly signed by his Controlling Officer showing the travelling and daily allowance
admissible to him for a journey on tour. If the Government servant is himself a Controlling Officer,
the certificate should be signed by him as such.
245. Employees of Central Government:
- When an employee of the Central Government including Railways appears to give evidence in his
private capacity, the sum due to him as subsistence allowance or compensation should be credited
to the Central Government, and no payment on account of subsistence allowance or compensation
shall be made to him.Non-official Witnesses
246. Class of witnesses:
- For the purpose of these rules, non-official witnesses or complainants shall be classed as belonging
to either of the two classes specified in Rule 247. The Judge or Magistrate shall fix the class of
persons who are required to appear before him either as witnesses or complainants with due regard
to the station in life which they occupy. In the case of witnesses from outside the jurisdiction of such
Judge or Magistrate, the despatching Magistrate shall fix the class.
247. Rates of payments:
- The following are the maximum rates of allowances which may be awarded to the several classes of
witnesses or complainants and no expenses in excess of or other than those hereinafter provided
shall be allowed.
Travelling allowance if
any that may beallowed
Class by RailBy Public
motor servicesBy road otherwise than
by public motor servicesBy Sea
CanalSubsistence
allowance
Twin cities of Hyderabad
& Sec'badOther Districts
I. 1st Class fare Actual fare per K.M. 0.12 Ps.Actual
fareRs. 8/-Rs.
6/-
II. 2nd Class fare Actual fare Per K.M. 0.03 Ps.Actual
fareRs. 4/-Rs.
3/-Criminal Rules of Practice and Circular Orders, 1990

In the cities of Hyderabad and Secunderabad, witnesses may be allowed carriage hire allowance at
Rs. 1/- for a day of actual attendance.Criminal Courts in the Districts are authorised to pay the
necessary and actual expenses of carriage to a witness travelling by road in the case of persons
whose sickness, age position or habits of life render it impossible for them to walk provided the
expenses incurred under this rule shall in no case exceed Rs. 0.50 per K.M.Wherever it is practicable
for witnesses to travell by rail or Steamer they shall be allowed not more than rates prescribed for
those modes of conveyance.Subsistence allowance may be paid for the days occupied in travelling to
the cities of Hyderabad and Secunderabad as well as the return journey. The subsistence allowance
at the cities of Hyderabad and Secunderabad shall cease soon after the conclusion of the enquiry or
trial as the means of quitting the cities became available.
248. Disbursements:
- All disbursements under these rules shall be made by the Courts before which the witnesses
appear.
249. Determination of mileage and batta:
(1)The distance for which mileage and number of days for which batty should be allowed for the
journey to attend from the station at which the Court is held, and for attendance at Court shall be
determined by the Judge or Magistrate ordering the payment in each case.(2)Witnesses sent from
the District will be furnished with a certificate by the despatching Magistrate showing the class to
which they belong, the date of their departure, and the correct distance, if any, to be travelled by
road, and unless such certificate is produced the Court may disallow all or any of the expenses
claimed.
250. Advances to witnesses:
(1)Magistrates in the Districts may make reasonable advances to witnesses summoned by Courts in
the Cities of Hyderabad and Secunderabad and others who require such advance to enable them to
reach Hyderabad or Secunderabad or other place, but shall in every such case note the same on the
certificate referred to in Rule 249. The Courts before which they are directed to appear shall be
advised of such advances and they will refund the amount to the officer making the advance.(2)In
cases falling under Rule 236 the Commissioner of City Police may make reasonable advances to
witnesses-residents in the Cities of Hyderabad and Secunderabad who are summoned by a Court in
the District and who require the advances to enable them to reach the Court. The Court issuing the
summons on being advised by the Commissioner of City Police of the advance made will refund the
amount to him.
251.
. Servants of Panchayat Samithis and Zilla Parishads and Municipal Councils attending Criminal
Courts as witness in cases under the Andhra Pradesh Panchayat Samithis and Zilla Farishads Act,Criminal Rules of Practice and Circular Orders, 1990

1959 and the Andhra Pradesh Municipalities Act, 1965 are eligible to receive travelling allowance
from the revenues of the State at the rates prescribed in the rules applicable to them. The procedure
for payment shall be the same as prescribed in sub-rule (1) of Rule 24.Charges for Conveyance of
Prisoners and Batta to Acquitted Prisoners
252. Cost of Conveyance to be recovered from Court concerned:
- The cost of conveyance of prisoners to and from the Court is to be recovered by the jail authorities
from the Court before which the attendance of the prisoner is required.Road and diet charges in
respect of persons accused of forest offences and produced in custody before a Magistrate by the
Subordinates of the Forest Department shall be paid without delay to the Subordinates of the Forest
Department by the Court concerned.
253. Batta to acquitted prisoners:
- Courts are authorised to grant batta and travelling expenses at the rates prescribed for second class
witness to persons :(1)Who are acquitted or discharged and released from custody or who having
been arrested under Section 390 of the Code, are subsequently released ; and(2)Who are released
under Section 360 of the Code, or wider the Probation of Offenders Act, to enable them to return to
their places of residence, provided that such persons reside at a distance of more than 10 kilometres
from the place where they are released from custody and are not possessed of sufficient means so to
return.
Chapter XIII
Supervision of Subordinate Criminal Courts General rules for
supervision
254. Responsibility of Sessions Judges:
- Sessions Judges are primarily responsible for the supervision of all Criminal Courts Subordinate to
them. Subject to the control of the Sessions Judges, the Chief Judicial Magistrates will exercise
supervision of the Magistrates Courts.
255. Points to be noticed in exercising Supervision:
- Sessions Judges and Chief Judicial Magistrates are directed to note the following points in
particular while exercising their power of supervision.(a)Rash issue of process to the accused,
judicious and indiscriminate use of the provisions of Sections 203 and 245 of the Code.(b)Dealing
with disputed claims of Civil right under colour of Criminal charges.(c)The imposition of heavy fine
in addition to imprisonment in default of payment, the term of imprisonment being beyond the
ordinary powers of the Magistrates to inflict.(d)Indiscriminate extensions of grant of time for the
payment of fine without regard to the principles laid down in Section 424 of the Code.(e)ExcessiveCriminal Rules of Practice and Circular Orders, 1990

sentences of imprisonment out of all reasonable proportion to the offences of which accused has
been convicted.(f)Failure to make judicious use of the provisions of Section 360 of the Code,
Probation of Offenders Act, Children Act, the Borstal Schools Act.(g)Light punishment for offences
requiring severe sentences with special reference to cases which should have been submitted by the
Subordinate Magistrates to the Superior Court for higher punishment.(h)Exaction of excessive bail
or excessive security for keeping the peace or for good behaviour.(i)Avoidable delay and
adjournment at any stage of the trial of the cases and strict adherence to the provisions of Section
309 Cr.P.C.(j)Needless adverse remarks in Judgment against public servants.Inspection of Courts
256.
(1)The High Court will inspect Courts of Sessions, atleast once in 3 years. At the time of inspection of
the Court of Session, the inspecting Judge may, in his discretion, inspect, any of the local
Subordinate Courts also.(2)(i)Sessions Judge shall inspect once a year Courts of Assistant Sessions
Judges and of the Magistrates. He may delegate the power of Inspecting Magistrate Courts to the
[Additional District and Sessions Judge or I Additional District and Sessions Judge] [Substituted for
'Chief Judicial Magistrates' by G.O.Ms.No. 1815, Law (LA&JHC-B), dated 26.10.2014, published in
A.P. Gazette RS to Part I, Extraordinary No. 55, dated 28-10-2004.].(ii)Sessions Judges shall submit
their reports of inspection for orders of the High Court with the least possible delay. [Additional
District and Sessions Judge or I Additional District and Sessions Judge] [Substituted for 'Chief
Judicial Magistrates' by G.O. Ms.No. 1815, Law (LA&JHC-B), dated 26.10.2004, Published in A.P.
Gazette RS to Part I, Extraordinary No. 55, dated 28-10-2004.] should submit their reports to the
High Court through the Sessions Judge.(3)Orders passed on, and instructions issued in, the
inspection reports should be strictly carried out and followed by the Subordinate Courts concerned.
They shall submit compliance report within such time as may be allowed in the inspecting
report.Submission of Judgments and Calendars
257. Courts of Sessions to send typed judgments in Original trials to High
Court:
(1)Courts of Sessions shall transmit to the High Court typed or cyclostyled copies of all their
Judgments in original trials within 15 days from the date of pronouncing Judgment in each
case.(2)Assistant Sessions Judges shall submit copies of the Judgments in original trials through the
Sessions Judge.
258. Delay in trials to be explained:
- Whenever more than three months have elapsed, between the date of apprehension of the accused
and the close of the trial in the Court of Session, an explanation as to the cause of such delay (in
whatever Court it may have occurred) shall invariably be furnished.Criminal Rules of Practice and Circular Orders, 1990

259. Submission of Judgment in Appeals:
- Sessions Judges and Additional Sessions Judges shall within five days from the close of each
month transmit to the High Court copies of all judgments delivered by them as Court of Criminal
Appeal during the course of the month. The appellate Judgment should contain particulars of
previous convictions, if any.
260. When judgments of Courts of first instance to be sent to the High Court:
- When judgments of Appellate Courts which are submitted to the High Court for perusal are
expressed in terms which disclose nothing as to the nature of the offences or evidence relied on to
establish them, or the circumstances which aggravate or extenuate the guilt of the offenders, they
should be accompanied by copies of the Judgments of the Courts of first instance.
261. Special report may be sent in any particular case:
- When a Sessions Judge sees occasion to comment specially on the action of the Magistrates in
connection with a case coming before his Court, he should send in a special report on the subject in
the Form of letter without waiting for the despatch of the monthly calendars or appeal statement.
262. Submission of Judgment by Magistrates:
- Except in cases dealt with under Sections 204(3), 252 and 256 to 258 of the Code Magistrates shall
within a week from the passing of the Judgment or order or from the termination of enquiry send to
the Sessions Judge :(a)all Judgments in the Form prescribed by Section 354 of the Code;(b)all
orders of dismissal of complaints under Section 203 of the Code and Orders of discharge in respect
of which further enquiry can be made or directed under Section 398 of the Code.(c)Extracts from
Registers of Summary Trials ;(d)all proceedings held by them under Chapters VIII, X (except orders
made under Section 143) and XXI of the Code ; and(e)extracts from the Registers of Preliminary
Inquiries.Judgments submitted under this Rule, shall be accompanied by the information given in
the Tabular Form prescribed above in Rule 67.
263. Sessions Statement:
- At the end of each month, a statement in Administrative Form No. 35-A should be submitted to the
High Court.This statement should include cases, if any, tried by Additional and Assistant Sessions
Judges and should show whether a case was tried by the Sessions Judge, Additional Sessions Judge
or Assistant Sessions Judge.
264. Quarterly statement to be furnished by the Sessions Judges to the
Superintendent of Police:Criminal Rules of Practice and Circular Orders, 1990

- Sessions Judges should furnish the Superintendents of Police of their District with a quarterly
statement in Administrative Form No. 54 of the Criminal Appeals and Revision Cases disposed of by
them.
265. Annual Reports:
- The following should be noticed and explained in the report to be submitted to the High Court
annually on the Administration of Criminal Justice.(1)Noticeable variations :(a)In the number of
Magistrates and Special Magistrates who exercised criminal powers ;(b)in the figures returned in
the annual statements No. II, Parts I and III ;(c)in the institutions, disposals and average duration
of cases in the Court of Sessions Judge, Magistrates, including Special Magistrates.(2)Large arrears
and high average duration in any of these Courts.(3)Noticeable increase or decrease in the
percentage of convictions in each class of Courts and in the total number of sentences of each
description passed during the year, such as life imprisonment, imprisonment-simple or rigorous
and fine.Explanation: - In calculating the percentage of convictions the number of persons whose
cases were disposed of by composition or withdrawal, by dismissal under Section 204 of the Code,
by acquittal under Section 256 or by discharge under Section 249 should be excluded. The figures
for such cases, causes compounded, withdrawn or dismissed for default of appearances should he
given separately.(4)High or low percentages of recoveries of fines and of amounts of compensation
awarded to accused and to complainants.(5)Large number of witnesses detained beyond three days
in any of these Courts, and large or small amounts paid to witnesses for diet and travelling expenses
in each class of Courts.(6)Noticeable variations in the number of appeals received, disposed of and
pending in the Courts of Session and in  the average duration of appeals.(7)Also large arrears of
appeals and high average durations thereof.(8)High or low percentage of confirmation on appeals
and any other noticeable point or feature in the crime or the administration of Criminal Justice in
the year.(9)The length of the report should be crutailed as far as possible by the omission of figures
appearing in the annual returns submitted to the High Court(10)Sessions Judges should describe
fully any features of interest in the administration of Criminal Justice in their divisions or District,
and to comment on the working of any provisions of law or Rules of Procedure to which they think
attention should be drawn.
Chapter XIV
Miscellaneous
266. Mode of Communication between Judicial and Executive Officers:
- All correspondence between Judicial Officers and Officers of other Department shall be by letters
or in the Form of endorsement.Sessions Judges may address Magistrates by Proceedings but
Magistrates shall address Sessions Judges only by letters.Criminal Rules of Practice and Circular Orders, 1990

267. Mode of Communication of Orders to Executive Magistrates:
- All proceedings of Court of Session addressed to any executive Magistrate shall, except in cases of
urgency or when the law sanctions a different course, be sent to the Executive Magistrate concerned
through the District Magistrate.
268. Mode of communicating Orders to Executive Magistrates in urgent
cases:
- In cases excepted in Rule 267, the Court of Session shall send the proceedings to the Executive
Magistrate concerned and the District Magistrate simultaneously.
269. Calling for records from the Executive Magistrate:
- In calling for records from an Executive Magistrate under Sections 385(2) or 397 of the Code,
Sessions Judges may address the Executive Magistrates in whose custody the records are, without
the intervention of the District Magistrate. The records so called for, may, likewise, be transmitted
directly to the concerned Courts after the disposal of the case.Wearing of Uniform in Court
270. Wearing of UniForm by the personnel of the Military in Court:
(1)An Officer or Soldier required to attend a Court in his Official capacity should appear in uniForm,
with sword or side arms. Attendance in official capacity includes attendance :(a)as witnesses when
evidence has to be given of matters which come under the cognizance of the Officer or Soldier in his
Military capacity ;(b)as an Officer for the purpose of watching a case on behalf of a Soldier or
Soldiers under his command.(2)An Officer or Soldier required to attend Court otherwise than in his
Official capacity may appear either in plain clothes or in uniform.(3)An Officer or Soldier shall not
wear his sword or side-arms if he appears in the character of an accused person or under Military
arrest, or if the Presiding Officer of the Court thinks it necessary to require the surrender of his
arms, in which case a statement of the reasons for making the order shall be recorded by the
Presiding Officer, and if the Military Authorities so request, forward it for information of the
concerned Chief of the Defence Forces.(4)Fire arms shall under no circumstances be taken into
Court(5)An Officer or Soldier will remove his head dress while the Judge or Magistrate is present,
except when the Officer or Soldier is on duty under the arms with a party or escort inside the Court
271. Wearing of Uniform by the Police in Court:
- Police Officers other than Officers and men of the Criminal Investigation Department, Central
Bureau of Investigation, Anti Corruption Bureau, Intelligence Bureau and Vigilance Branch
appearing in Courts in their official capacity shall be in their uniForm.Criminal Rules of Practice and Circular Orders, 1990

272. Dress of Convicts:
- Convicts sent in custody to the Court either as a witness or an accused person shall wear ordinary
private clothing, their neck-tickets and ankle-rings shall also be removed.
273. Use of Forms:
- The Forms in part II of these Rules shall be used for the purposes for which they are intended with
such variations as the particular circumstances of each case may require.Form No. 1Warrant of
commitment on failure to find security to keep the peace[Section 122, Criminal Procedure Code]In
The Court Of The...........................Magistrate OfCase No. ................. of 19ToThe Superintendent of
the Jail at------------------------------Officer-in-chargeWhereasappeared
before me| in personby his Pleader| on the
day of ............. 19............ , in obedience to a summons calling upon him to show cause why he
should not enter into a bond for Rs. .........
with| one suretywith sureties each| in Rs. ..................
that he, the said would keep the peace for the period of ............... months, and whereas an order was
then made requiring the said .................. to enter into and find such security and he has failed,
[security for] [State the security if it differs from that mentioned in the summons.] to comply with
the said orders and has for such default has been adjudged simple imprisonment for .....................
unless the said security be sooner furnished.
This is to authorise and require you the said| SuperintendentOfficer| to receive the said .................
into your custody together to receive the said ................. into your custody together with
warrant, and safely to keep him in the said jail for the said period of ................... unless he shall, in
the meantime, be lawfully ordered to be released and to return this warrant with an endorsement
certifying the manner of its execution.Given under my hand and seal of the Court, this day of
19(Seal)MagistrateDESCRIPTIVE ROLL
1. Name
2. Father's Name
3. Sex, married or single
4. Race and Religion
5. Previous occupationCriminal Rules of Practice and Circular Orders, 1990

6. Age
Diet -(a)The diet to which the prisoner was accustomed according to his own statement(b)The diet
recommended by the Magistrate.(c)Brief reasons if rice or wheat is recommended.
The distance from the prisoner's residence to the nearest| Railway StationJail| is ................. miles.
The distance (a) by bus from the nearest| JailRailway Station| to the bus stand nearest to the
prisoner's residence is ....... miles, (b) from the bus-stand nearest to the prisoner's to the
bus stand nearest to the prisoner's residence is ....... miles, (b) from the bus-stand nearest to the
prisoner's residence to his residence is ......... miles.The amount of bus fare under (a) above is
.................................Details of the property on the person of the prisoner.
Jail Magistrate
Date of admission to Jail
:Number :Name
:Sentence :Dateof
sentence :Date of release :I, hereby certify that the sentence passed on the prisonernamed in this
warrant has been executed according to law and thathe has, this day,
been released from[custody on] [Appeal/Expiry of Sentence/Bail.]or
having earnedday's permission .....................Jail..............Dated
................... 19 .......
Release on bail or escape and re-admission may be noted below.JailorSuperintendentNote :- In
filling up the particulars under the head "5 previous occupation" in respect of females, Courts shall
use the same classes of previous occupation as are adopted for males.Form No. 2Warrant of
commitment on failure to find security for good behaviour[Section 122, Criminal Procedure Code]In
The Court Of The .................... Magistrate OfMiscellaneous Case No. .................. of 19 ........... .ToThe
Superintendent----------------------------- .................. of the ............. Jail at
.............Officer-in-chargeWhereas it has been made to appear to me that has been and is taking
precautions to conceal his presence within the local limits of my jurisdiction and that there is reason
to believe that he is taking such precautions with a view to committing an offenceOrhas no
obstensible means of substanceoris unable to give a satisfactory account of himselforWhereas
evidence of the general character of ................ has been adduced before me and recorded, from
which it appears that he is* ...................And whereas an order has been recorded stating the same
and requiring the said .................................. to furnish security for his good behaviour for the term of
............ by entering
into a bond with| one suretytwo sureties| himself for Rupees ..................................| and the said
suretyeach of the said sureties| for Rupees ......................... and the said ................. has failed to
comply with the
said order and for such default has been adjudged| simplerigorous| imprisonment for
............................................. unless the said security be sooner furnished.
This is to authorise and require you the said| SuperintendentOfficer-in-charge| to receive the said
into your custody, together with this warrant and safely to keep him in the said jail for the said
period of........ unless he shall, in the meantime, be lawfully ordered to be released and to return this
warrant with an endorsement certifying the manner of its execution.Given under my hand and the
seal of the Court, this day of ... 19....(Seal)Magistrate
Descriptive RollCriminal Rules of Practice and Circular Orders, 1990

1. Name 5. Previous Occupation
2. Father's Name 6. Age
3. Sex, married or single 7. Descriptive marks
4. Race and Religion  
Particulars of previous convictions
Court Calendar number and year Section and Code Sentence
Diet**(a)The diet to which the prisoner was accustomed according to his own statement.(b)The diet
recommended by the Magistrate.(c)Brief reasons if rice or wheat is recommended.
The distance from the prisoner's residence to the nearest| Railway StationJail| is ............... miles.
This distance (a) by bus from the nearest| JailRailway Station| to the bus stand nearest to the
Prisoner's residence is .......... miles ; (b) from the bus stand nearest to the Prisoner's
residence to his residence is ........... miles.The amount of bus fare under (a) above is ..................
Details of the property on the person of the prisoner.
Jail Magistrate
Date of admission to Jail
:Number :Name :Sentence
:Dateof sentence :Date of
release :I, hereby certify that the sentence passed on the prisonernamed in this
warrant has been executed according to law and thathe has this day,
been released from custody on*** having earnedday's remission
.....................JailDated ................... 19 .......
Release on bail or escape and re-admission may be noted below.JailorSuperintendentNote :- In
filling up the particulars under the head "5 previous occupation" in respect of females, Courts shall
use the same classes on previous occupation as are adopted for males.* Here enter habitual robber,
house-breaker, etc.** Particulars to be entered in the Magistrates' own handwriting.***
Appeal/Expiry of Sentence/BailForm No. 3Notice after Magistrate's order for the removal of a
nuisance is made absolute[Sections 136 and 141, Criminal Procedure Code]In The Court Of The
................ Magistrate OfMiscellaneous Case No. ................ of 19 .............Whereas an order, dated the
......... day of ........ 19 ....... was issued under my hand requiring you to or to show cause why such
order should not be enforced, and you have failed to obey such order, or to appear/and show cause
against the order being enforced, the order aforesaid is made absolute and I hereby direct and
require you to obey the said order within ........., on peril of the penalty provided by Section 188 of
the Indian Penal Code for disobedience thereto ;Given under my hand and the seal of the Court, this
day of .......... 19 .........(Seal)MagistrateForm No. 4Order requiring parties concerned in dispute to
put in Written Statements of their claims[Section 145(1), Criminal Procedure Code]In The Court Of
The ................ Magistrate OfMiscellaneous Case No. ............. of 19 .............ToWhereas it has been
made to appear to me and I am satisfied for the reasons set out below that a dispute likely to cause a
breach of the peace exists concerning situate within the local limits of my jurisdiction.I do hereby
require you to attend at my Court in person or by the Pleader within .......... days from the receipt of
this notice and to put in a written statement of your claim as respects the fact of actual possession of
the property aforesaid and also such documents or to adduce by putting in affidavits, the evidence of
such persons, as you rely upon in support of such claim.Given under my hand and the seal of the
Court, this ........ day of 19 ..........(Seal)MagistrateForm No. 5Warrant of attachment in emergent
cases[Section 145(4), Criminal Procedure Code]In The Court Of The ................ Magistrate
OfMiscellaneous Case No. ............. of 19 ........ToWhereas it has been made to appear to me, and I am
satisfied, that a dispute likely to cause a breach of the peace exists concerning situate within theCriminal Rules of Practice and Circular Orders, 1990

local limits of my jurisdiction, and I consider the case one of emergency in which an order of
attachment should be issued pending the decision in the inquiry into the matter under Section 145
of the Code of Criminal Procedure ;This is authorize and require you to attach the said property by
taking and keeping possession thereof, and to hold the same under attachment pending the further
order of this Court or decision of the said inquiry and to return this warrant with an endorsement
certifying the manner of its execution.Given under my hand the seal of the Court ........... this .........
day of ....... 19 .......(Seal)MagistrateForm No. 6Warrant of commitment on a sentence of
imprisonment or fine or both[Sections 255, Criminal Procedure Code]In The Court Of The
................ OfSession Case No. ................. of 19 ...............-------------------------CalenderToThe
Superintendent---------------------------- ........................ of the jail at
...................Officer-in-chargeWhereas on the .............. day of .......... 19 ........ the ........ Prisoner in
Case No. ........... of the calendar ..................... of 19 ........ Crime No....... of the Police Station) was
convicted
before me| Session JudgeMagistrate| of .......................... of the Offence of ............... punishable
under| Section of the Indian Penal CodeAct of| and was sentenced to ..............................
This is to authorise and require you, the said| SuperintendentOfficer-in-charge| to receive the said
into your custody in the said Jail together with this warrant, and there carry the aforesaid
sentence into execution according to law. The prisoner named above is classed as* .................... The
Prisoner is a fit subject for the special jail for habituals** ................... is not ..................Diet**(a)the
diet to which the prisoner was accustomed according to his own statement(b)the diet recommended
by the Sessions Judge/Magistrate ;(c)brief reasons if rice or wheat is recommended.
II. The distance from the Prisoner's residence to the nearest| Railway StationJail| is ............... miles.
The distance (a) by bus from the nearest| Railway StationJail| to the bus stand nearest to the
Prisoner's residence is .......... miles, (b) from the bus stand nearest to the Prisoner's
residence to his residence is ........... miles.The amount of bus fare under (a) above isIII. Details of
property on the person of the prisoner.IV. I hereby certify that of the fine has been recovered.V.
Descriptive Roll.* "Habitual" or "Casual" as the case may be, should be entered herein the
Magistrate's own Judge's own handwriting.** To be filled in only in the case of "Habitual" by a
convicting Court (not below the rank of Ist Class Magistrate in an area for which a special jail for
habitual has been appointed.*** Particulars to be entered in the Session Judge's/Magistrate's own
handwriting.Particulars of previous convictions
Court Calendar number and year Section and Code Sentence
Given under my hand the seal of the Court, this day of(Seal)Sessions Judge---------------------
MagistrateThe prisoner was transferred to ........... jail on ......... under Inspector General's Order No.
.......... dated .......... 19 ..... Remission earned up to the end of the preceding quarter is ........
days.SuperintendentThe prisoner was transferred to ................... Jail on ............... under Rule, 473,
Prisoners and Reformatory Manual, Volume II. Remission earned up to the end of the preceding
quarter is .............. days.SuperintendentSolitary confinement
From ToNumber of days Total undergone Superintendent's initials
I hereby certify that the ............ within named prisoner has this day been served with an order
directing him to notify his residence to the police for year from this date.The following address was
furnished by the prisoner on release.Street : Village :Taluk : District :Superintendent.The order has
been duly served on me(Signature or left-thumb-impression of the Prisoner)Dated .........19.........Criminal Rules of Practice and Circular Orders, 1990

Jail Magistrate
Date of admission to Jail :Number
:Name :Sentence :Dateof sentence
:Date of release :I, hereby certify that the sentence passed on theprisoner
named in this warrant has been executed according to
lawand that he has, this day, been released from custody
on*** orhaving earned ......., day's remission.
Jail
Dated ............. 19Jailor.
Release on bail or escape and readmission may be noted belowSuperintendent.Note: - In filling up
the particulars under the head "5 previous occupation" in respect of females, Court shall use the
same classes of previous occupation as are adopted for males.*** Appeal/Expiry of
sentence/Bail.Form No. 7Warrant of imprisonment on failure to recover amends by
Distress[Section 250, Criminal Procedure Code]In The Court Of The ................... Magistrate
OfCalendar Case No. ................ of 19 ...........ToThe Superintendent of the
Jail----------------------------Officer-in-chargeat
Whereas ......................... has brought against ................... the complaint that ....................... and the
same has been ................... dismissed as| frivolousvexatious| and the order of dismissal
awards payment by the said ............. of the sum of Rs. ............ as amends, and whereas the sum of
Rupees has not been paid and cannot be recovered by distress of the movable property of the said
................ and an order has been made for his simple imprisonment in Jail for the period of days,
unless the aforesaid sum be sooner paid.
This is to authorise and require you, the said| SuperintendentOfficer-in-charge| to receive he said
......... into your custody, together with this warrant and safely to keep him in the said Jail for the
said period of .......... days subject to the provisions of Section 69 of the Indian Penal Code, unless
the said sum be sooner paid and on the receipt thereof, forthwith to set him at liberty, returning this
warrant with an endorsement certifying the manner of its execution.Given under my hand the seal
of Court, ................. this .............. day of .......... 19 ......(Seal)MagistrateDESCRIPTIVE ROLL
1. Name :
2. Father's Name :
3. Sex, Married or Single :
4. Race and Religion :
5. Previous Occupation :
6. Age :Criminal Rules of Practice and Circular Orders, 1990

7. Descriptive marks :
*Diet -(a)the diet to which the prisoner was accustomed according to his own statement(b)the diet
recommended by the Magistrate(c)brief reason if rice or wheat is recommended
This distance from the prisoner's residence to the nearest| Railway StationJail| is ............. miles.
The distance (a) by bus from the nearest| JailRailway station| to the prisoner's residence is
............... miles.
* Particulars to be entered in Magistrate's own handwriting.(b)From the bus stand nearest to the
prisoner's residence to his residence is ............ miles.The amount of bus fare under (a) above
isDetails of the property on the person of the prisoner..................
Jail Magistrate
Date of admission to Jail :Number
:Name :Sentence :Dateof sentence
:Date of release :Release on bail or
escape andreadmission may be noted
belowI, hereby certify that the sentence passed on the
prisonernamed in this warrant has been executed according
to law and thathe has, this day, been released from custody
on* or having earnedday's remission .....................
Jail..............Dated ................... 19 .......Jail Superintendent.
Note :- In filling up the particulars under the head "5 previous occupation" in respect of females,
Courts shall use the same classes of previous occupation as are adopted for males.* Appeal/Expiry of
Sentence/Bail.Form No. 8Warrant to levy a fine by Attachment and Sale[Section 421, Criminal
Procedure Code]In The Court Of The .................. Class Magistrate OfCase No. ..................... of 19
..................ToWhereas .................. was on the .............. day of .... 19 .... convicted before me on the
offence of ......... and sentenced to pay a fine of Rupees ............. ; and whereas the said .........
............., although required to pay the said fine, has not paid| the sum ofa part thereof| Rs.
...............
This is to authorise and require you to attach any movable property belonging to said ................
which may be found within the district of and, if within next after such attachment the said sum of
Rs. .............. shall not be paid, to sell the property attached, or so much thereof as shall be sufficient
to satisfy the said fine/balance of fine,returning this warrant with an endorsement certifying what
you have done under it, immediately upon its execution.Given under my hand and the seal of the
Court, this day of ...... 19 ......(Seal)Sessions JudgeClass MagistrateForm No. 9Warrant to levy a fine
by Attachment and Sale of Movable or Immovable property or both[Section 421, Criminal Procedure
Code]ToThe Collector ofWhereas ........... was on ........ day of ......... 19 ......, convicted before me of
the offence of ........... and sentenced to pay a fine of rupees and whereas the said ........... although
required to pay the said fine has not paid the same/any part thereof viz., ............... and whereas,
although the said .............. has undergone the whole of the imprisonment awarded in default of
payment of fine, it is considered necessary for special reasons to levy the said fine.This is to
authorise and require you to realise the said amount by execution according to civil process against
the movable or immovable property or both belonging to the said defaulter. You are further required
to intimate the action taken by you under this warrant immediately upon its execution.Given under
my hand and the seal of the Court, this day of ........... 19 .......(Seal)Sessions JudgeClass
Magistrate.Form No. 10Warrant of commitment in certain cases of contempt when a fine is
imposed[Section 345, Criminal Procedure Code]In The Court Of ...........................................Case No.Criminal Rules of Practice and Circular Orders, 1990

........................... of 19 .......................ToThe Superintendent ..................... of the civil Jail at
......................---------------------------Officer-in-charge
Where at a Court held before me on this day .......... of ............ in the| presenceview| of the Court
committed wilful contempt ;
And whereas for such contempt the said .......... has been adjudged by the Court to pay a fine of
Rupees .............., or in default to suffer simple imprisonment for the of ..................... days ; and
whereas
the said sum of Rs. .....................part of the said sum to wit Rs. ......
has not been paid or recovered
This is to authorise and require you, the said| SuperintendentOfficer-in-charge| of the said Jail to
receive the said ............ into your custody, together with this warrant, and safely to keep him in the
said Jail for the said period of ........... days unless the said| finebalance of fine| be sooner paid, and
on the receipt thereof forthwith to set him at liberty, returning this warrant with an
endorsement certifying the manner of its execution.Given under my hand and seal of the Court, this
day of ........ 19 .....(Seal)Judge/Magistrate.DESCRIPTIVE ROLLName :Father's name :Sex, Married
or Single :Race and Religion :Previous Occupation :Age :Descriptive marks :*Diet -(a)the diet to
which the prisoner was accustomed according to his own statement.(b)the diet recommended by the
Sessions Judge/Magistrate.(c)brief reasons if rice or wheat is recommended.
The distance from the prisoner's residence to the nearest| Railway StationJail| is ............. miles.
The distance (a) by bus from the nearest| Railway StationJail| to his residence is .............. miles.
The amount of bus fare under (a) above is .......................Details of the property on the person of the
prisoner
Jail Magistrate
Date of admission to Jail :Number :Name
:Sentence :Dateof sentence :Date of release
:Release on bail orescape andreadmission
may be noted below :JailorI, hereby certify that the sentence passed on
theprisoner named in this warrant has been executed
according to lawand that he has, this day, been
released from custody on** or*"having earned ........
day's remission.
Jail
Dated …......... 19 …..........
Note :- In filling up the particulars under the head "5 previous occupation" in respect of females,
Courts shall use the same classes of previous occupation as are adopted for males.* Particulars to be
entered in the Sessions Judges/Magistrates, own hand-writing.** Appeal/Expiry of
Sentence/Bail.Form No. 11Magistrate's or Judge's Warrant of commitment of witness refusing to
answer or produce a document or thing[Section 349, Criminal Procedure Code]Case No.
......................... of 19 ................To
Whereas ....................... being| summonedbrought before this Court| as a witness and this day
required to| | give evidenceproduce| on an alleged offence, refused without alleging any just excuse
for
such refusal and for his contempt has been adjudged| detention in custodysimple imprisonment|
for ............. days ;Criminal Rules of Practice and Circular Orders, 1990

This is to authorise and require you to take the said ................ into your custody, and safely to keep
him in your custody, for the ............. of ............ days unless in the meantime he shall
consent to be examined and| to answer the question asked of himto produce| , and on the last of the
said days or forthwith on such consent being known to bring him before this Court to be
dealt with according to law, returning this warrant with an endorsement certifying the manner of its
execution.Given under my hand and the seal of the Court, this ........... day of ........... 19
...........(Seal)Judge /MagistrateDESCRIPTIVE ROLLName :Father's Name :Sex, married or single
:Race and religion :Previous occupation :Age :Descriptive marks :*Diet: -(a)The diet to which the
prisoner was accustomed according to his own statement.(b)the diet recommended by the Sessions
Judge/Magistrate.(c)brief reasons if rice or wheat is recommended.
The distance from the prisoner's residence to the nearest| Railway StationJail| is ................. miles.
The distance (a) by bus from the nearest| Railway StationJail| to the bus stand/nearest to the
prisoner's residence is ................ miles.
The amount of bus fare under (a) above is ...............................Details of the property on the person
of the prisoner
Jail Magistrate
Date of admission to Jail :Number
:Sentence :Dateof sentence :Date of
release :Release on bail or escape
andreadmission may be noted below :I, hereby certify that the sentence passed on the
prisonernamed in this warrant has been executed according
to law and thathe has, this day, been released from custody
on** or having earnedday's remission .............Jail..............
Jailor.Dated ........... 19 .........
Note: - In filling up the particulars under the head "5 previous occupation" in respect of females,
Courts shall use the same classes of previous occupation as are adopted for males.* Particulars to be
entered in the Sentence Judge's/Magistrate's own handwriting.** Appeal/Expiry of Sentence
Bail.Form No. 12Warrant of imprisonment on failure to pay maintenance[Section 125, Criminal
Procedure Code]In The Court Of The ............... Magistrate OfMiscellaneous Case No. ............ of 19
..........ToThe Superintendent---------------------------- ................... of the Jail atOfficer-in-charge
Where .................. has been proved before me to be possessed of sufficient means to maintain his
wife| andor| child that is by reason of ............... unable to maintain itself and to have
itself and to have| neglectedrefused| to do so, and as an order has been duly made requiring the
said ... to allow his said| wifechild| for maintenance the monthly sum of Rupees ............ whereas
it has been further proved that the said ...... in wilful disregard of the said ....... order, has failed to
pay Rupees ....... being the amount of the allowance for the| monthmonths| of and
thereupon an order was made adjudging him to undergo| simplerigorous| imprisonment in the said
jail for the period of ..................
This is to authorise and require you, the said| SuperintendentOfficer-in-charge| to receive the said
........ into your custody in the said Jail together with this warrant and thereto carry the said order
execution according to law, returning this warrant with an an endorsement certifying the manner of
its execution.Given under my hand and the seal of the Court, this ....... day of ............ 19
.......(Seal)MagistrateDESCRIPTIVE ROLLName :Father's name :Sex, married or single :Race and
Religion :Previous Occupation :Age :Descriptive Marks :*Diet(a)the diet to which the prisoner was
accustomed according to his own statement.(b)the diet recommended by the Magistrate.(c)briefCriminal Rules of Practice and Circular Orders, 1990

reasons if rice or wheat is recommended.
This distance from the prisoner's residence to the nearest| Railway StationJail| is more miles.
This distance (a) by bus from the nearest| Railway StationJail| to the bus stand nearest to the
Prisoner's residence is .......... miles, (b) from the bus stand nearest to the prisoner's
residence to his residence is .......... miles.The amount of bus fare under (a) above is*
....................Details of the property on the person of the prisoner .......................
Jail Magistrate
Date of admission to
JailNumberNameSentenceDateof sentenceDate of
releaseRelease on bail orescape andreadmission
may be noted belowI, hereby certify that the sentence passed on
theprisoner named in this warrant has been
executed according to lawand that he has, this
day, been released from custody on** orhaving
earned ......., day's remission.
Jail
Dated …......... 19 …..........
Superintendent.Note : - In filling up the particulars under the head " 5. previous occupation" in
respect of females, Court shall use the same classes of previous occupation as are adopted for
males.* Particulars to be entered in the Session's Judge's/Magistrate's own handwriting.**
Appeal/Expiry of Sentence/Bail.Form No. 13Bond and Bail Bond on a Preliminary Inquiry or Trial
before a Magistrate[Sections 436, 437, 438(3), 441, Criminal Procedure Code]Case No. ....................
of 19 ..........I, ....................................... of ............ being brought before the Magistrate of ............,
charged with the offence of ................ and required to give security for my attendance in his Court
and at the Court of Session if required to bind myself to attend at the Court of the said Magistrate at
........... O'clock on the ............ day of 19 ...... and on every subsequent day of the preliminary inquiry
or trial into the said charge and *should the case be transferred to any other Court or sent for trial by
the Court of Session, or sent to a Superior Court under Section 325 of the Code of Criminal
Procedure, 1973 to be and appear before the said Court when called upon to answer the charge
against me, and in case of my making default herein, I, bind myself to forfeit to the State the sum of
Rupees.Dated this ................... day of .......... 19 ............SignatureExecute before me,Magistrate
I herebyWe jointly and severally| declare| Myselfourselves and| each of us| SuretySureties| for the
said ............................................ that he shall attend at the Court of .............. at ................. O' Clock
on the
.............. day of 19 .................. and on every subsequent day of the preliminary inquiry or trial into
the offence charged against him, and should the case be transferred to any other Court or sent for
trial by the Court of Session or sent to a Superior Court under Section 325 of the Code of Criminal
Procedure, 1973 that he shall be, and appear, before the said Court to answer the charge against him
and in case of his making default therein
I bind myselfwe bind ourselves| to forfeit to the State the sum of Rupees ..................
Dated this ................. day of ............ 19Signature Executed before me Signature(Seal)Magistrate.*
When the case is transferred to another Court, the Court from which the case is transferred shall
inform the accused and sureties of such transfer.Form No. 14Warrant of commitment of the surety
of an accused person admitted to bail[Section 446, Criminal Procedure Code]In The Court Of
........................Case No. ..................... of 19 ............ToThe Superintendent--------------------------- of
the Civil Jail atOfficer-in-chargeWhereas ............................ of .................. has bound himself as aCriminal Rules of Practice and Circular Orders, 1990

surety for the appearance of and the said ............... has herein made default whereby the penalty
mentioned in the bond has been forfeited to the State, and whereas the said .............. has, on due
notice to him, failed to pay the said sum or show any sufficient cause why payment should not be
enforced against him, and the same cannot be recovered by attachment and sale of movable
property of his, and an order has been made for his imprisonment in the Civil Jail for
This is to authorise and require you the said| SuperintendentOfficer-in-charge| to receive the said
..................... into your custody with this warrant and safely to keep him in the said Jail, for the said
and to return this warrant with an endorsement certifying the manner of its execution.Given under
my hand and the seal of the Court, this .............. day of ............19..........(Seal)Judge/
Magistrate.DESCRIPTIVE ROLL
1. Name
2. Father's name
3. Sex, married or single
4. Race and religion
5. Previous occupation
6. Age
7. Descriptive marks
Diet*(a)The diet to which the prisoner was accustomed according to his own statement.(b)The diet
recommended by the Sessions Judge/Magistrate.(c)Brief reasons if rice or wheat is recommended.
This distance from the prisoner's residence to the nearest| Railway StationJail| is .............. miles.
The distance (a) by bus from the nearest Jail to the bus stand nearest to the prisoner's residence is
............ miles, (b) from the bus stand nearest to the prisoner's residence to his residence is ..............
miles.The amount of bus fare under (a) above is .........................Details of the property on the person
of the prisoner ................Judge/ MagistrateNote : - In filling up the particulars under the head "5
previous Occupation" in respect of females, Courts shall use the same classes of previous occupation
as are adopted for males.* Particulars to be entered in Magistrate's own handwriting.Form No.
15Warrant of Imprisonment on breach of a Bond to keep the peace or to be good of behaviour or to
appear before a Court[Section 446, Criminal Procedure Code]In The Court Of The ..............
Magistrate OfCase No. ............... of 19 ...........ToThe Superintendent--------------------------- of the
Civil Jail at ..............................Officer-in-charge
Whereas proof has been given before me and duly recorded that ........ has committed a breach of
the bond entered into by him to be of| good behaviourto keep the peace| (or to appear before the
Court of ....... on ...........) whereby he has forfeited to the State the sum of Rupees ............ andCriminal Rules of Practice and Circular Orders, 1990

whereas the said .......... has failed to pay the said sum or to show cause why the said sum should not
be paid, although duly called upon to do so, and payment thereof cannot be enforced by attachment
of his movable property and an order has been made for the imprisonment of the said in the Civil
........... Jail for the period of ..................... ;
This is to authorise and require you, the said| SuperintendentOffice-in-charge| of the said Civil Jail
to receive the said ............... into your custody, together with this warrant, and safely to keep him
the said Jail for the said period of and to return this warrant with an endorsement, certifying the
manner of its execution.Given under my hand and the seal of the Court, this day of ............ 19
........(Seal)MagistrateDESCRIPTIVE ROLL
1. Name
2. Father's Name
3. Sex, married or single
4. Race and Religion
5. Previous occupation
6. Age
7. Descriptive marks
*Diet -(a)The diet to which the prisoner was accustomed according to his own statement(b)The diet
recommended by the Magistrate.(c)Brief reasons if rice or wheat is recommended. The distance
from the prisoner's residence to the nearest.
The distance from the prisoner's residence to the nearest| JailRailway Station| is more miles
The distance (a) by bus from the nearest| JailRailway Station| to the bus stand nearest to the
prisoner's residence is ........... miles.
(b)from the bus stand nearest to the prisoner's residence to his residence is ........... miles.The
amount of bus fare under (a) above is .....................Details of the property on the person of the
prisoner ....................Magistrate.Note : - In filling up the particulars under the head "5 Previous
occupation" in respect of females, Court shall use the same classes of previous occupation as are
adopted for males.* Particulars to be entered in Magistrate's own handwriting.Form No. 16Warrant
of attachment and sale on forfeiture of a Bond for good behaviour or to keep the peace[Section 446,
Criminal Procedure Code]ToThe Officer-in-charge of the Police Station at ..........................
Whereas ................... did on the ............... day of ............ 19 ................. give security by ...................
bond in the sum of rupees ............. that| should be of good behaviourshould keep the peace| and
proof hasCriminal Rules of Practice and Circular Orders, 1990

been given me and duly recorded of the commission by the said ................ of the offence of .........
whereby the said bond has been forfeited, and whereas notice has been given to the said .........
calling upon him to show cause why the said sum should not be paid and he has failed to do so or to
pay the said sum.This is to authorise and require you to attach by seizure of movable property
belonging to the said .............. to the value of Rupees which you may find within the District of and if
the said sum be not paid within to sell the property to attach or so much of it as may be sufficient to
realize the same and to make return of what you have done under this warrant immediately upon its
execution.Given under my hand and the seal of the Court, this ............. day of 19
............(Seal)MagistrateForm No. 17Warrant of imprisonment on forfeiture of bond for good
behaviour or to keep the peace[Section 446, Criminal Procedure Code]In The Court Of The
................... Magistrate OfCase No. ............. of 19 ............ToThe
Superintendent--------------------------- of the Civil Jail at .............................Officer-in-charge
Whereas .................. did, on the ............... day of ..................... 19 ................. give security by bond in
the| should be of good behaviourkeep the Peace| and proof of the breach of the said bond ..........
......... has been given before me and duly recorded whereby the said ............... has forfeited to the
State the sum of Rupees ..................... and whereas he has failed to pay the said sum, or to show
cause why the said sum should not be paid although duly called upon to do so, and payment thereof
cannot be enforced by attachment of his movable property, and an order has been made for the
imprisonment of the said .................. in the Civil Jail for the period of .................
This is to authorise and require you the said| SuperintendentOfficer-in-charge| to receive the said
into your custody together with this warrant and safely to keep him in the said period of ...................
return in this warrant with an endorsement certifying the manner of its execution.Given under my
hand and the seal of the Court .................... this ............ day of ............... 19
...............(Seal)MagistrateDESCRIPTIVE ROLL
1. Name
2. Father's name/Husband's name
3. Sex, married or single
4. Race and Religion
5. Previous occupation
6. Age
7. Descriptive marks
*Diet -(a)The diet to which the prisoner was accustomed according to his own statement.(b)The diet
recommended by the Magistrate.(c)Brief reasons if rice or wheat is recommended.Criminal Rules of Practice and Circular Orders, 1990

This distance from the prisoner's residence to the nearest| Railway StationJail| is ................ miles.
This distance (a) by bus from the nearest| JailRailway Station| to the bus stand nearest to the
prisoner's residence is ................ miles.
(b)from the bus stand nearest to the prisoner's residence to his residence is ................ miles.The
amount of bus fare under (a) above is .......................Details of the property on the person of the
prisoner.Magistrate.Note :- In filling up the particulars under the head "5 Previous occupation" in
respect of females, Court shall use the same classes of previous occupation as are adopted for
males.* Particulars to be entered in Magistrate's own handwriting.Form No. 18Warrant to bring up
a witness after service of summons[Section 87, Clause (b), Criminal Procedure Code]ToWhereas
complaint has been made before me that ............... has or is suspected to have committed the
offence of .............. and ........... whereas it is proved that the summons issued to who, it appears,
likely can give evidence concerning the said complaint, has been duly served in time to admit of his
appearing in accordance therewith but that he has failed so to appear without offering a reasonable
excuse for such failure.This is to authorise and require you to arrest the said ........... and on the day
of ............ 19 ............, to bring him before this Court to be examined touching the offence
complained of.Given under my hand and the seal of the Court this day .................. of .......... 19
...........(Seal)Magistrate
If the said ............... shall give bail himself in the sum of Rs............ with| One Surelytwo sureties
each| in the sum of Rs. ............... to attend before me on the day of .......... 19 .........., and continues
so to attend until otherwise directed by me, he may be released.Dated this ................... day of ............
19 ..............Magistrate.Form No. 19Form of order for the Detention in Custody of an accused
person[Section 167, Criminal Procedure Code]To
Whereas it appears that a charge against .............. of an offence under Section .............. of| the
Indian Penal CodeAct No. ......... of ........| is under investigation by the police under the provisions
of
Chapter of
Criminal Procedure, that such investigation cannot be
completed within the period of 24 hours fixed by Section 57 of
the Code and that there are grounds for believing
that the| accusationinformation| against the said person is well founded ;
and the accused having been duly forwarded to this Court, this is to authorise you to detain the said
........ in custody* for .............. days, and to cause him to be produced before Court sitting at ......... on
the day ......... of ........... 19 ............, at ............. O' Clock.DESCRIPTIVE ROLL
1. Name
2. Father's/Husband's NameCriminal Rules of Practice and Circular Orders, 1990

3. Sex, married or single
4. Race and religion
5. Previous occupation
6. Age
7. Descriptive marks
Note :- Atleast three identification marks must be given.Given under my hand and seal of the Court,
this day ......... of ..........(Seal)Magistrate*The custody may be such as the Magistrate thinks fit.Form
No. 20Proceedings Of The ............... Magistrate OfDated ............ 19 .............(Under Section 173,
Criminal Procedure Code)Read -Referred Charge-sheet entered as Serial No. ............... in
Magistrate's Register
1. Name of the
(a)Station(b)Village(c)Taluk
2. Complainant's name
3. Name of accused
4. Offence, with law and section under which punishable
5. Explanation of any delay evidenced by dates in docket (outside).
6. Order to the Police, regarding making or refraining from making further
investigation and with regard to the bond, if any, executed by the accused.
7. Brief statement of facts of the case and reasons for order.
Proceedings on Referred Charge Sheet Entered as Serial No. ............. in Magistrate's
RegisterFromThe .................. MagistrateToThe .................. MagistrateDate .................. Month
................... Year
Date of {OffenceReport of stationReceipt of ReferredCharge-sheet by
InspectorReceipt of Referred Charge-sheet byMagistrateOrder of
the MagistrateDespatch 
 Criminal Rules of Practice and Circular Orders, 1990

 
 
 
 
 
 
 
 
Remarks of  Magistrate. 19
Received
Despatched  
Reply of   
Received
Despatched| Magistrate
19
Form No. 21Notice to Complainant[Section 200, Criminal Procedure Code]IN THE COURT OF
THE .............. MAGISTRATE OFToYou are hereby required to appear before this Court at .......... O'
Clock ............ day of ........ 19 ........, to give a sworn deposition regarding the complaint preferred by
you against ....................Dated(Seal)MagistrateForm No. 22Warrant of commitment of e person
charged with an offence[Section 209, Criminal Procedure Code]Case No. ...................... of 19
.....................ToThe Officer-in-charge of ................... Jail at .........................Whereas ............... is
charged with having committed an offence under Section ............. of and the case has been
committed to Sessions .............. at on the ............ 19 ..........You are hereby required to receive the
said into your custody in the said Jail and safely to keep him there until he shall be thence delivered
by due course of law.DESCRIPTIVE ROLL
1. Name
2. Father's name/Husband's name
3. Sex, married or single
4. Race and Religion
5. Previous occupation
6. Age
7. Descriptive marks
Note: - At least three identification marks must be given.Given under my hand and the seal of the
Court this day of .......... 19 ......(Seal)MagistrateForm No. 23Proceedings of the Magistrate of[SectionCriminal Rules of Practice and Circular Orders, 1990

256, Criminal Procedure Code]Dated ...................... 19 ..........In Calendar Case No. ................. of 19
..........Complainant AccusedOffence :Date of offenceDate of complaintDate of hearingORDER
The case was called on for hearing today to which it had been| postedadjourned
The complainant not being present either in person or by pleader, the accused be acquitted under
Section 256 Criminal Procedure Code.(Seal)Magistrate.Form No. 24Proceedings of the ..................
Magistrate of[Section 249, Criminal Procedure Code]The ............... day of ........... 19 .............In
Calendar Case No. ................ of 19 .............. Complainant ............. Offence ............ Accused
...........The complainant not appearing this day, the date fixed for the hearing of the case, and it
appearing that the alleged offence is one which may be lawfully compounded, the Court directs
under Section 249 Criminal Procedure Code, that the accused be discharged.(Seal)Magistrate.Form
No. 25Form of Order for the detention in custody of approves[Section 306, Criminal Procedure
Code]In The Court Of ........................Case No. .............. 19 ........ToThe Officer-in-charge of the
.............. Jail at .......... .Whereas on the day of ................ 19 .............. a tender of pardon was made to
under Section 306 of the Code of Criminal Procedure, this is to authorize and require you to receive
the said into your custody together with this warrant and to produce him before the committing
Magistrate and the Court of Sessions under safe custody at such times and places as the said Courts
may require you to do, and to keep him in the said jail at such times as his production before the
Court is not required.DESCRIPTIVE ROLL
1. Name
2. Father's name/Husband's name
3. Sex, married or single
4. Race and religion
5. Previous occupation
6. Age
7. Descriptive marks
Note :- At least three identification marks must be given.Given under my hand and the seal of the
Court, this day of 19(Seal)MagistrateForm No. 26Adjournment Order[Section 309, Criminal
Procedure Code]In The Court Of ..................Case No. .................. of 19 ..........Offence:Case No.
:Name of accusedDate of first appearance of accused :Whether in custody or not :Whether
remanded to custody or not :Adjourned from toPlace fixed for further hearing :Reason for
postponing or adjourning :Form No. 27Form of Remand Warrant[Section 309, Code of Criminal
Procedure]The Officer-in-charge of the ................ jail at ................ .Criminal Rules of Practice and Circular Orders, 1990

Where| hashave| been forwarded in custody by the officer-in-charge of the ............ Police Station, to
this Court, charge by the Police with offence under Section and this Court is
empowered to take cognizance of the said offence and whereas the Court has| postponed
trialadjourned the inquiry| to the day of ...... 19 ......., this is to authorise and require you to detain
the said
....... in your custody for ............. days and to cause| himthem| to be produced before the Court
sitting ................. at .............. on the ...... day of 19 ............ at ............ O' Clock.
DESCRIPTIVE ROLL
1. Name
2. Father's Name/Husband's Name :
3. Sex, married or single :
4. Race and Religion :
5. Previous occupation :
6. Age :
7. Descriptive marks :
Note: - At least three marks of identification must be given.Given under my hand and the seal of the
Court, this ............ day of ........ 19 ........(Seal)MagistrateForm No. 28Deposition of Witness[Chapter
XXIII, Criminal Procedure Code]IN THE COURT OF ..........................
CalenderMiscellaneousPreliminaryRegisterSessions |Case No. …....... of 19...........
Deposition of ................................ witness for |ProsecutionDefenceCourt
Name :Father's name :Village :Taluk :CallingReligion :Age :Solemnly affirmed in accordance with
the provisions of Act X of 1873 on the ........... day of ............. 19 .............Form No. 29Examination of
the Accused[Section 313, Criminal Procedure Code]IN THE COURT OF
........................CalendarMiscellaneousPreliminary Register ............... Case No. .............. of 19
...........SessionsStatement of .................... accusedName :Father's Name :Village :Taluk :Calling
:Religion :Age :Question :Date ................. 19 .................Answer :Form No. 30Form of Warrant on a
Sentence of Imprisonment for Life[Section 418 (1), Criminal Procedure Code]IN THE COURT OF
SESSION .............. DIVISIONToThe Superintendent of the ............. Jail at ............ .Whereas at the
Sessions held before me on the ......... day of ....... 19 ....., Prisoner in Case No. ....... of the Calendar at
the said Sessions (Crime No. ....... of (Police Station) was duly
convicted for the offence under Section ....... of the| Indian Penal CodeAct No. ........ of .....| and was
sentenced to imprisonment for life .............. .Criminal Rules of Practice and Circular Orders, 1990

This is to authorise and require you the said Superintendent to receive the said ............ into your
custody in the said Jail together with this warrant and there safely to keep him until he shall be
delivered over by you to the proper authority and custody for the purpose of the undergoing the
punishment of imprisonment for life under the aforesaid sentence.I. *Diet(a)the diet to which the
prisoner was accustomed according to his own statement.(b)the diet recommended by the Sessions
Judge.(c)brief reasons if rice or wheat is recommended.
II. The distance from the prisoner's residence to the nearest| Railway StationJail| is ........... miles
The distance (a) by bus from the nearest| Railway StationJail| to the bus stand nearest to the
prisoner's residence is ......... miles (b) from the bus stand nearest to the prisoner's
residence to his residence is ....... miles.The amount of bus fare under (a) above isIII. Details of the
property on the person of the prisoner.IV. I hereby certify that ................. of the fine has been
recovered.V. Descriptive Roll: -Name :Father's Name :Sex, Married or single :Race and Religion
:Previous occupation :Age :Descriptive Marks :* Particulars to be entered in the Session Judge's own
handwriting.Particulars of previous convictions
Section and Code Sentence Court
Given under my hand the seal of the Court, this day of ........ 19 ..........(Seal)Sessions JudgeThe
prisoner was transferred to ......... jail on ......... under Inspector General's Order No. .......... dated ......
19 .......... Remission earned upto the end of the preceding quarter is ......... daysSuperintendentThe
prisoner was transferred to ............ jail on ........... under Rule 473, Prison and Reformatory Manual,
Volume II. Remission earned upto the end of the preceding quarter is days.SuperintendentI hereby
certify that within named prisoner has this day been served with an order directing him to notify his
residence to the Police for ............ years from this date.The following address was furnished by the
prisoner on release: -Street VillageTaluk DistrictThe order has been duly served on meSignature or
left-thumbImpression of the Prisoner
Jail JailDated 19
Date of admission to Jail
:Number :Name :Sentence
:Dateof sentence :Date of
release :I, hereby certify that the sentence passed on theprisoner named in
this warrant has been executed according to lawand that he has, this
day, been released from custody on* orhaving earned day's
remission ..........JailDated 19
Release on bail or escape and readmission may be noted belowJailorSuperintendent* Appeal/Expiry
of Sentence/Bail.Form No. 31Form of dismissal of appeal[Section 384, Criminal Procedure Code]IN
THE COURT OF ...............The ................ day of ........... 19 .........Petition of Appeal No. ....... of 19
......., against the conviction and sentence by the ............. Magistrate of ........ under Section ..........
of the Indian penal Code in Case No.Act No. .............. of ..........
AppellantThis Appeal coming on for hearing before me under Section 384 of the Code of Criminal
Procedure, upon perusing the petition of appeal and the Calendar and Judgment of the said
Magistrate and upon duly considering the same after hearing the arguments of the appellant not
appearing in support of his appeal the appellant or appellants' pleader although reasonable
opportunity of being heard has been allowed, I do adjudge and order that his appeal be
dismissed.(Seal)Sessions Judge----------------------MagistrateCopy to :The Superintendent of(for
communication to the prisoner concerned)Form No. 32Notice of appeal[Section 385, Criminal
Procedure Code]IN THE COURT OF ....................Criminal Appeal No. ............ of 19 ...........Criminal Rules of Practice and Circular Orders, 1990

1. The Appellant
The Public Prosecutor
2. (-----------------------------)
Additional Public Prosecutor
3. General Manager of ............... Railway
District Forest Officer
4. (-----------------------------)
Revenue Divisional Officer
5. Superintendent of Excise
6. Commissioner, Hyderabad Municipal Corporation
7. Municipal Commissioner
Notice is hereby given under Section 385 of the Code of Criminal Procedure that the aforesaid
appeal made to this Court by ............. against the finding and sentence of the ......... Magistrate of
.............. in Calendar Case No. ................. of 19 ......... will be heard at ...................... on the day of
............. 19 ......Sarishtadar--------------------Head Clerk.Dated .............. 19 .......... .FORM No.
33Proceedings calling for record[Sections 38,5, 397, Criminal Procedure Code]PROCEEDINGS OF
THE COURT OF ..........Read: -
Extract from the Register of Preliminary Enquiries in Case No. ............. of 19 ............... Judgement
in Calendar Case No. ....................of 19 .............. Criminal| Appeal No.Revision| ........... of
19. ................ presented against the findings and sentence in Calendar Case
No. ........ of 19 ....... on the file of the Magistrate of ............... Order.
The ................................ Magistrate is requested to submit for the consideration of this Court, the
record of proceedings in the above case with the least practicable delay.Sarishtadar- - - - - - - - -
-Head ClerkForm No. 34Form of an order dismissing an appeal and annulling a suspension of the
sentence[Section 386, Criminal Procedure Code]IN THE COURT OF .................The ............. day of
......... 19 ............Petition of Appeal No. ................ of 19 ............... against the conviction and sentence
by the ................. Magistrate of .......... under Section .......... of the Indian Penal Code/Act No. ............
of ........... in Case No. ............ of the Calendar for ............... 19 .........AppellantThis appeal coming on
........... for hearing before me, upon perusing the petition of appeal and the record of the evidenceCriminal Rules of Practice and Circular Orders, 1990

and proceedings, and upon duly considering the same and after hearing ....... I do adjudge and order
that the said appeal be dismissed and that the order of this Court suspending the sentence be
annulled.Sessions Judge.(Seal)ToThe Superintendent of ............. for communication to the prisoner
concerned.Form No. 35Form of an order confirming a sentence[Section 385, Criminal Procedure
Code]IN THE COURT OF ..........................The .................. day of ............ 19 ...............Petition of
Appeal No. ............. of 19 ................ against the conviction and sentence by the ............ Magistrate of
................ under Section ........... of the Indian Penal Code/Act No. ............ of ............ in Case No.
............ of the Calendar for 19 ...........AppellantThis appeal coming on for hearing before me, upon
perusing the petition of appeal and calendar and sentence and the record of the evidence and
proceedings, and upon duly considering the same, and after hearing I do adjudge and order that the
said appeal be dismissed.(Seal)Sessions judge.ToThe Superintendent of ..................... for
communication to the prisoner concerned.Form No. 36Form of an order reversing a
sentence[Section 386, Criminal Procedure Code]IN THE COURT OF ................The day of ................
19 ............. .Petition of Appeal No. ............... of 19 ....... against conviction and sentence by the
.............. Magistrate of .............. under Section ............. of the Indian Penal Code Act No. ...................
of ............. in case No. ............. of the Calendar for ............... 19 ......AppellantThis appeal coming on
.................. for hearing before me, upon perusing the petition of appeal and the record of the
evidence and proceedings, and upon duly considering the same
and after hearing .............. I do adjudge and order that the conviction and sentence passed on the
said| be reversedbe discharged| and the accused be acquitted and that he the said prisoner
released from the jail in which he is now imprisoned under the said sentence unless he is liable to be
detained in custody for some other cause.(Seal)Sessions Judge.Copy to :The Superintendent of
................... for communication to the prisoner concerned.Sri.......................... (Private
Complainant's name and address)Form No. 37Form of an order reducing sentence[Section 386,
Criminal Procedure Code]IN THE COURT OF ..............................The ................. day of .............. 19
............ .
Petition of Appeal No. .............. of 19 ........ against the conviction and sentence by the Magistrate of
........... under Section ......... of the| Indian Penal CodeAct No. ........... of| in Case No. ......................
of the Calendar for 19 ............AppellantThis appeal coming on for hearing before me upon perusing
the petition of appeal and the record of the evidence and proceedings, and upon duly considering
the same and after hearing .............. I do adjudge and order that the sentence passed on the said be
reduced and that instead of the punishment thereby imposed, the said .........................(Seal)Sessions
JudgeCopy to :The Superintendent of the ................... for communication to the prisoner
concerned.Form No. 38Form of an order suspending sentence[Section 389, Criminal Procedure
Code]IN THE COURT OF .............................The .................. day of ............... 19 ................
Petition of Appeal No. ............. of 19 ................ against the conviction and sentence by the ..............
Magistrate of ............. under Section .............| Indian Penal CodeAct No. ........... of .......| for 19
...........
AppellantApplication having been made to this Court by the Appellant for the suspension of the
sentence passed upon him, upon perusing the petition of appeal and the copy of the judgment of the
Lower Court, and upon hearing ............ I do order that as respects the said ............... the said
sentence be suspended until the further order of this Court in the appeal.(Seal)Sessions judge.ToThe
Superintendent of the ............. Jail at ..............Form No. 39Form of order on withdrawal byCriminal Rules of Practice and Circular Orders, 1990

complainant[Section 257, Criminal Procedure Code]PROCEEDINGS OF THE ..............
MAGISTRATE OFDated ............... 19 ............(Seal)In Calendar Case No. ................. of 19 .................
Offence .............ComplainantAccusedThe complainant having requested permission to withdraw his
complaint and having satisfied this Court that there are sufficient grounds for granting permission is
hereby permitted to withdraw the complaint The accused is acquitted under Section 257, Code of
Criminal Procedure.
1. Date of Offence.
2. Date of Complaint
3. Date of Hearing.
MagistrateForm No. 40Form of order on withdrawal by the public prosecutor[Section 321, Criminal
Procedure Code]PROCEEDINGS OF THE ...................(Seal)Dated ........... 19 ............In Calendar
Case No. ................. of 19 ............ Offence ...............ComplainantAccusedThe Public Prosecutor
having requested permission to withdraw from the prosecution of the accused in respect of offences
under Section ........................................ Indian Penal Code, and having satisfied this Court that there
are sufficient grounds for granting permission, is hereby permitted to withdraw from the
prosecution as aforesaid of the accused who
is acquittedare discharged| under the Code of Criminal Procedure.
1. Date of offence
2. Date of complaint
3. Date of hearing
Sessions Judge- - - - - - - - - - - - - -MagistrateForm No. 41
Form of Order for detention of| youthfuladolescent| offenders
Certified Schools- - - - - - - - - - - - - -Borstal
It is hereby found that (name of the offender) convicted by the law and sentenced to imprisonment
is a| youthfuladolescent| offenders under ........ years of age.
He is hereby directed to be sent to a| JuniorSenior| | certified schoolsBorstal| and to be there
detained for a period of ............... years*
DESCRIPTIVE ROLL
1. NameCriminal Rules of Practice and Circular Orders, 1990

2. Father's Name/Husband's Name :
3. Sex, married or single :
4. Race and Religion :
5. Previous occupation :
6. Age :
7. Descriptive marks :
Note : - At least three marks of identification must be given.Sessions Judge- - - - - - - - - - - - - -
-Magistrate*Vide Section 24 of the Andhra Pradesh (Andhra Area) Children Act, 1920.Form No.
42Warrant of commitment on a sentence of imprisonment or fine or both, in pursuance of an order
passed on appeal[Sections 255, 248, 386, Criminal Procedure Code]IN THE COURT OF
..........................
(Appeal No. .................. of 19 .............., ..................... against the conviction and sentence by the
Magistrate of .............. under Section ............. of the| The Indian Penal CodeAct No. .......... of ......|
in Case
No. ....................... of the Calendar for 19 ) (Crime No. ............... of the Police Station)ToThe
Superintendent---------------------------- of the Jail at ...............................Officer-in-chargeWhereas
on the .......... day of ........... 19 ........ the prisoner in the said Case No. ........... of the Calendar for 19
...... was convicted for the said the Magistrate of the offences of ...............
punishable under Section ............ of the| Indian Penal CodeAct No. .......... of ......| and was
sentenced to ............... and whereas the said sentence has been modified by the to ............... and
whereas
the said sentence has been modified by the Sessions Judge of an appeal into a sentence of
.................. .
This is to authorise and require you, the said| Superintendent to detainOfficer .......... receive| the
said ......... in your custody in the said jail together with this warrant and there carry the aforesaid
revised
sentence into execution according to law.The warrant of commitment issued by the said Magistrate
in regard to the aforesaid prisoner in the said Calendar Case should be returned to me for
cancellation.The prisoner named above is classed as*
The Prisoner name above| isis not| a fit subject for confinement in the special jail for habitual**
***diet: -(a)The diet to which the prisoner was accustomed according to his own statement.(b)The
diet recommended by the Sessions Judge/Magistrate.(c)Brief reasons if rice or wheat is
recommended.
The distance from prisoner's residence to the nearest| Railway StationJail| is ............ miles.
The distance (a) by bus from the nearest| JailRailway Station| to the busCriminal Rules of Practice and Circular Orders, 1990

stand nearest to the prisoner's residence is .............. miles, (b) from the bus stand nearest to the
prisoner's residence to his residence is .......... miles.* "Habitual" or "Casual" as the case may be
should be entered herein in the Judge's own handwriting.** To be filled in only in the case of
"habitual" by a convicting Court (not below the rank of Ist Class Magistrate) in an area for which a
special Jail for habituals has been appointed.*** Particulars to be entered in the Sessions
Judge's/Magistrate's own handwriting.The amount of bus fare under (a) above is
....................Details of property on the person of the Prisoner .....................I hereby certify
that,.................... of the fine has been recovered.DESCRIPTIVE ROLL
Particulars of the previous convictionsSection and Code Sentence Court
1. Name
2. Father's Name/Husband's Name :
3. Sex, married or single :
4. Race and Religion
5. Previous occupation :
6. Age :
7. Descriptive marks :
Given under my hand and the seal of the Court, this day of ....... 19 .........(Seal)Sessions JudgeThe
Prisoner was transferred to .......... Jail on .......... under Inspector-General's order No .......... 19
..........Superintendent.Remission earned upto the end of the preceding quarter is ......... days.The
prisoner was transferred to Jail on under Rule 453, Prison and ReFormatory Manual, Volume
II.Remission earned upto the end of the preceding quarter is ......... days.SuperintendentSolitary
confinement
From ToNumber of days Total undergone Superintendent's initials
I hereby certify that the within named prisoner has this day been served with an order directing him
to notify his residence to the police for ........ years from this date.The following address was
furnished by the prisoner on release :Street VillageTaluk DistrictSuperintendentThe order has been
duly served on me ...................................Signature or left thumb .................... impression of the
Prisoner.
Jail JailDated 19
Date of admission to
JailNumberNameSentenceDateof
sentenceDate of releaseI, hereby certify that the sentence passed on
theprisoner named in this warrant has been executed
according to lawand that he has, this day, been released
from custody on* orhaving earned day's remission.
JailCriminal Rules of Practice and Circular Orders, 1990

Dated …......... 19 …..........
Release on bail or escape and re-admission may be noted below :Jailor/SuperintendentNote :- In
filling of the particulars under the head "5 previous occupation" in respect of females, Court shall
use the same classes of previous occupation as are adopted for males.* Appeal/Expiry of
sentence/Bail.Form No. 43Warrant of commitment on a sentence of imprisonment or fine or both,
in pursuance of an order passed on appeal or revision by the High Court[Sections 388 and 405,
Criminal Procedure Code]IN THE COURT OF .........................Appeal- - - - - - - - - - - - - - - - - No.
............... of 19 ................ against the finding,Criminal Revision Case
sentenced or order passed by the| Session JudgeMagistrate| under Section .......... of
The Indian Penal Code---------------------------------Act No. .......... of ..........of the Calendar for
19---------------------------------Criminal Appeal No. .............. of 19 ............(Crime No. ............. of
............... Police Station)ToThe Superintendent- - - - - - - - - - - - - - - - - of the Jail at
.........................Officer-in-charge
Whereas on the .......... day of ........... in the said Case No ............ of the ......... 19 ......, the Prisoner
.......... Calendar of ........... was convicted before me| Session JudgeMagistrate of......| punishable
under Section ..... of offence of the| Indian Penal CodeAct ..... of .....| and was sentenced to ..... and
whereas| the sentenced was ConfirmedModified| by me Sessions Judge on appeal, and said
sentence
the --------------- said sentence as to confirmed or modified on appeal has been modified by the High
Court of Judicature of Andhra Pradesh at Hyderabadon appeal--------------------- into a sentence of
.................................on revision
This is authorise and require you, the said| SuperintendentOfficer-in-charge| to| detainreceive| the
said ........... in your custody in the said Jail together with this warrant and to carry the aforesaid
modified
sentenced of the HIgh Court into execution according to law.
The warrant of commitment issued by me in regard to the aforesaid Prisoner in the said| Calendar
CaseCriminal Appeal| should be returned to me for cancellation.
The Prisoner named above is classed as*
The Prisoner named above| isis not| a fit subject for confinement in the special jail for habituals**
*** Diet(a)The diet to which the prisoner was accustomed according to his own statement ;(b)The
diet recommended by the Sessions Judge ;(c)Brief reasons if rice or wheat is recommended.
The distance from the prisoner's residence to the nearest| Railway StationJail| is............miles.
* "Habitual" or "Casual" as the case may be, should be entered herein in the Judge's or Magistrate's
own handwriting.*** To be filled in only in the case of 'habituals" by the convicting, Court (now
below the rank of First Class Magistrate) in an area for which a special Jail for habituals has been
appointed.** Particulars to be entered in Sentence Judge's/Magistrate's own handwriting.
The distance (a) by bus from the nearest| Railway StationJail| to the bus stand nearest to the
prisoner's residence is ..... miles, (b) from the bus stand nearest to the Prisoners residence
to his residence is......miles, (b) from the bus stand nearest to the Prisoners residence to his
residence is ......... miles.The amount of bus fare under (a) above is ....................Details of the
property on the person of the prisoner ................I hereby certify that ................ of the fine has been
recovered.DESCRIPTIVE ROLLCriminal Rules of Practice and Circular Orders, 1990

Particulars of the previous convictionsSection and Code Sentence Court
Name :Father's name :Sex, married or single :Race, religion and caste :Previous occupation :Age
:Descriptive marks :Given under my hand and the seal of the Court, this ............... day of ........... 19
................ .(Seal)Sessions judgeThe prisoner was transferred to ............ Jail on ............. under
Inspector General's Order No ............. dated ............... 19 ............ .Remission earned up to the end of
the preceding quarter is ......... days.SuperintendentThe prisoner was transferred to ............... Jail
under Rule 473, Prison and Reformatory Manual, Volume II.Remission earned upto the end of the
preceding quarter is .......... days.SuperintendentSolitary Confinement
From ToNumber of Days Total undergone Superintendent's initials
I hereby certify that the within-named prisoner has this day been served with an order directing him
to notify his residence to the Police for year from this date.The following address was furnished by
the prisoner on release :Street VillageTaluk DistrictSuperintendentThe order has been duly served
on me.Signature and left thumb-impression of the prisoner.
Jail JailDated ............. 19 .......
Date of admission to Jail
:Number :Sentence:Date of
sentence :Date of release :I, hereby certify that the sentence passed on theprisoner named
in this warrant has been executed according to lawand that he
has, this day, been released from custody on* orhaving earned
day's remission.
JailDated …...........
19…..................
Release on bail or escape and readmission may be noted below :JailorSuperintendentNote : - In
filling up the particulars under the head "5 Previous occupation" in respect of females, Courts shall
use the same classes of previous occupation as are adopted for males.Note : - In the case of a
Judgment or order passed by the High Court on a revision petition against the finding, sentence or
order of an appellate Court, the appellate Court and not the trial Court should give directions to the
superintendent or the officer-in-charge of the Jail.* Appeal/Expiry of sentence/Bail.Form No.
44Warrant of release of a prisoner[Section 386, Criminal Procedure Code]IN THE COURT OF
......................
Appeal No.... of 19.......,.......against the conviction and sentence by the Magistrate of ........... under
Section ........ of| the Indian Penal CodeAct ....... of .......| in Case No...... of the Calendar for 19.......
ToThe Superintendent------------------------------ of the ....................... Jail at
........Officer-in-chargeWhereas on the ........... day of ............ 19 ........, the prisoner in the said Case
No. .......... of the Calendar of 19 ............. was convicted before the said ............ Magistrate of
............... punishable under Section .............. ofThe Indian Penal Code--------------------------------
and was sentenced to ..... and whereas the said sentenced was reversed by me Sessions Judge of
........... on appeal ...........Act ........... of ..............This is to authorise and require you to release the
said prisoner ........ from your custody unless he is liable to he detained for some other cause.Given
under my hand and the seal of the Court ......... this ............day of .......... 19 .........(Seal)Sessions
Judge.N.B.: - The Superintendent of the Jail should at once return the warrant with which the
prisoner was committed to his custody.FORM No. 45Warrant of release of prisoner on appeal or in
revision by the High Court[Sections 388 and 405, Criminal Procedure Code]IN THE COURT
OF...........................ToThe Superintendent--------------------------- of the.........................Jail
at.............Officer-in-chargeWhereas on the............... day of............. 19............. the Prisoner in CaseCriminal Rules of Practice and Circular Orders, 1990

No................ of the Calendar for 19 ......... was convicted before me theSessions
Judge---------------------------- of the offence of ......... punishable under Section .........
ofMagistratethe Indian Penal Code------------------------------- and was sentenced to .......... and
whereas theAct No.......... of .........
Sentence was| confirmedmodified| by me the Sessions Judge on appeal and whereas the
said sentence---------------------------said sentence as so confirmed or modified on appeal has been
reversed by
the High Court of Andhra Pradesh| on appealin revision
This is to authorise and require you to release the said prisoner .......... from your custody unless he
is liable to be detailed for some other cause.Given under my hand and the seal of the Court this
.......... days of.......... 19 ..........(Seal)Sessions Judge.N.B.: - The Superintendent of the Jail should at
once return the warrant with which the prisoner was committed to his custody.Note : - In the case of
a Judgment or order passed by the High Court on a revision petition against the finding, sentence or
order of an appellate Court, the appellate Court and not the trial Court should give directions to the
Superintendent or the Officer-in-charge of the Jail.Form No. 46Order for the payment of
compensation moneyI, ............................. Magistrate of ............ hereby certify that
.............complaint in Calendar Case No................... of 19, ............ on the file of my Court, is entitled
to receive payment of Rs from Treasury, being the amount of compensation awarded to him under
Section ............ of ........... from the fine imposed on the prisoner in the said case and remitted to the
above Treasury on ..............I further certify that(1)the sentence and award are not subject to appeal,
the award has been confirmed by the Appellate Court, the order as to compensation has been
modified on appeal and the payment order is in conformity with such order.(2)that no order has
been received from the Court of Revision modifying or reversing the order of compensation the
order has been modified in revision and the order is in accordance with such order on
revision.Dated .................. 19 .............Magistrate.Form No. 47Proceedings of the Chief Judicial
Magistrate[Section 14, Criminal Procedure Code]Dated................day of.............19.............Under
Section 14 of the Code of Criminal Procedure, the Chief Judicial Magistrate of.....................hereby
defines the local area .............. within which Sri ....................... appointed to be a Magistrate of the
................ Class for the district of ................ may exercise the power.Chief Judicial MagistrateCopy
to :(1)The Officer concerned(2)The Munsif Magistrate of(3)The District Superintendent of
Police,(4)The District Collector for publication in the District Gazette with translation.Form No.
48Summons to produce[Section 91, Criminal Procedure Code]IN THE COURT OF THE
..................... MAGISTRATE OFCase No. ...................ToComplainantofAccusedWhereas a complaint
has been made before this Court that the accused has (or is suspected to have) committed the
offence of and it has been made to appear to this Court that the
production of the undermentioned| documentsthings| now in your possession or power is
necessary--------------------- for the purpose of the ...... before this Court, you are here by summoned
to attend and produce (or cause to be produced) the saiddesirabledocuments---------------------
before this Court 11 a.m. on the day of 19 ..............things.Given under my hand and the seal of this
Court, this day of .........
(Seal)| Particulars of| DocumentThings| Magistrate
Form No. 49Summons to produce[Cause title]ToThe Speaker,Lok Sabha- - - - - - - - - - - - - - - - - - - -
atLegislative AssemblyThe Chairman,Rajya Sabha- - - - - - - - - - - - - - - - - - - - atLegislativeCriminal Rules of Practice and Circular Orders, 1990

CouncilWhereas a complaint has been made before this Court that the accused has (is suspected to
have) committed the offence of ............ and it has been made to appear to this Court that the
production of the undermentioned documents/things now in the custody of the Secretary of Lok
Sabha/Rajya Sabha/State Legislature is necessary or desirable for the purpose of the ............ before
this Court, you are requested to direct to the Chief Executive Officer to make arrangement for
sending an officer to attend and produce, for the transmission of/to forward to this Court a duly
authenticated copy of the said documents/things on or before the day of(Seal)MagistrateParticulars
of Documents/thingsForm No. 50NoticeIN THE COURT OF SESSION .............. DIVISION[Section
122, Criminal Procedure Code]Criminal Miscellaneous Case No. ............. of 19 ..........ToThrough the
.................. Magistrate of .............. .Take notice that Miscellaneous Case No. .... of 19 .......... on the
file of the ........... Magistrate of ............ in which you are one of the accused has been laid before this
Court for orders under Section 122, Code of Criminal Procedure, and will be heard in the Sessions
Court at on ........... at 11 a.m.Given under my hand and the seal of the Court .......... this ............ day
of ........ 19 ........(Seal)Sessions JudgeForm NO. 51ORDER OF REMAND MADE BY THE .............
MAGISTRATE OF[Section 167 or 309 Criminal Procedure Code]
1. Number of case.
2. Name of the accused.
3. Offence charged with
4. Date on which the accused was first produced before the Magistrate under
arrest
5. Period of detention orderedalready6.
Period of detention now ordered7. Reasons
for the remand.|Under Section 167, Cr.P.C.Under Section 309,
Cr.P.C.UnderSection 167, Cr.P.C.Under Section
309, Cr.P.C.
Form No. 52Notice to complainant[Section 173 or 202, Code of Criminal Procedure]In Referred
Case No. .......... of 19 .............To .............
Take Notice that the complaint preferred by you under Section ........of the| Indian Penal CodeAct
No...... of ......| is referred by the Police as ................ and that if you dispute the correctness of the
finding of the police, you should appear before this Court ........... within ............ days from this
day.Day of ........... 19 ........... .Magistrate.Form No. 53Notice[Sections 195 and 340, Criminal
Procedure Code]IN THE COURT OF THE.........................Civil .......... Miscellaneous Petition No.
...............Criminalin ............... No. ................... of 19 ............................
 Between Petitioner.
  Counter-Petitioner.
ToAnd Counter-Petitioner.
Take notice that an application has been presented by the petitioner ........ herein praying that an
inquiry be made and an inquiry will be held .......... under Section 340, Criminal Procedure Code, to
determine why a complaint should not be laid against you for an offence punishable underCriminal Rules of Practice and Circular Orders, 1990

Section(s) ........... of the Indian Penal Code, and that the said application will be heard by this Court
........... at a.m on the day of .......... 19 ........... You are at liberty to show cause why such complaint
should not be made.Given under my hand and the seal of the Court, this day of 19.Sessions Judge- -
- - - - - - - - - - -Magistrate.SealForm No. 54PROCEEDINGS OF THE CLASS MAGISTRATEDated
........... in C.C. No. ................ of
1. Date of offence.
2. Date of complaint
3. Date of sworn deposition.
4. Date of order under Section 203, Criminal Procedure Code.
5. Date of despatch to the First Class Magistrate.
6. Date of receipt.
ComplainantOffence complained of.Read-Accused.Complaint petition, complaint's sworn
deposition and Order.Sessions Judge &Chief Judicial Magistrate.
 Remarks of the Chief Judicial Magistrate.  
Date of despatch.Date of receipt. 19 …............19 …............
Date of despatchDate of receipt } 19…............  
Form No. 55Notice to complainant[Chapters XV and XVI, Criminal Procedure Code]Calendar Case
No. ................. of 19............ is informed that the complaint preferred by him/her under section
............ is posted for hearing on the ............ day of ....... 19 ....... at 11 a.m. ......... Office,The .......... day
of ......... 19 ......Magistrate.Form No. 56IN THE COURT OF SESSION ............... DIVISION[Sections
226, 229 and 230 Criminal Procedure Code]Sessions Case No ............... of 19 .......... Register Case
No ......... of 19....., on the file of the ............... Magistrate of ...............Name of accusedChargePlea of
accusedSessions JudgeForm No. 57Warrant to be used when the accused being in custody, the
Magistrate stays proceedings under Section 322 Code of Criminal ProcedureToThe Superintendent-
- - - - - - - - - - - - - - - of the ...................................... Jail atThe Officer-in-chargeWhereas
...............of............is charged before me and, the evidence appearing to warrant a presumption that
the case is one which should be tried or committed for trial by some other Magistrate in this District
or should be tried by the Chief Judicial Magistrate the proceedings have been stayed and the case
submitted to the Chief Judicial Magistrate.You are hereby required to receive the said................into
you custody and produce him when called upon before the Chief Judicial Magistrate................or
such other Magistrate at such place and time as the Chief Judicial Magistrate shall direct or in the
absence of direction from the Chief Judicial Magistrate to produce him before me at ................. on
the ............ day of .............. 19 ......... at ....... a.m./p.m.DESCRIPTIVE ROLLCriminal Rules of Practice and Circular Orders, 1990

1. Name :
Fathers's Name :
2. - - - - - - - - - - - - -
Husband's name :
3. Sex, married or single :
4. Race and religion :
5. Previous occupation :
6. Age :
7. Descriptive marks :
Note :- At least 3 marks of identification must be given. Given under my hand and seal of the Court
this day of 19 ............(Seal)Magistrate.Form No. 58Bond after conviction and a sentence of fine
only[Section 424, Criminal Procedure Code]IN THE COURT OF THE ............... MAGISTRATE
OFCase No................of 19.................Whereas I ................ of ................ have been convicted by the
............... Magistrate of ............ in C.C. No. ............. of 19 .............., and sentenced to pay a fine of Rs.
.......... and ordered to undergo imprisonment for ............. in case of default of payment of the fine
and whereas I have not paid the fine in part of ........ in full ......... the said Magistrate has suspended
the execution of the warrant of imprisonment for ............ days, I do hereby bind myself to appear
before the said Magistrate at ............ O' clock on the .... day of 19 ....... at ...... to be dealt with
according to law unless the fine shall have been sooner paid in full and in case of default therein as
above, I bind myself to forfeit to the State the sum of Rupees .......Dated this day of .............. 19
.................Signature.I declare myself surety for the above named of ......................We ..............
ourselves sureties ............ that he shall attend before the ........... Magistrate of .......... at .......... O'
clock on the ......... day of ..... 19 ........, at unless the fine specified above shall have been sooner paid
in full and in case of his making default therein, I/we hereby bind myself/ourselves to forfeit to the
State, the sum of ........... Rupees ............Dated this ........... day of .......... 19
.......SignatureSignatureExecuted before me.MagistrateForm No. 59Bailbond[Section 389 or 392
Criminal Procedure Code](a)IN THE COURT OF ........................Criminal Appeal No........- - - - - - - -
- - - - - - - - - ............................... of 19 .....................Session CaseCriminal Miscellaneous Petition No.
............... of 19 ...............Calendar Case No. ...........- - - - - - - - - - - - - - - - - - ........................... of 19
................ on the fileSessionsof the Magistrate- - - - - - - - - - - - .................................. of
....................................Sessions JudgeStateVersusTo(b)IN THE COURT OF ....................
Where I have been| convictedcommitted| by theCriminal Rules of Practice and Circular Orders, 1990

MagistrateSession Judge| of .........................................| of the offenceon a charge| of ...................
punishable under Section .......... of the Indian Penal Code and sentenced to rigorous imprisonment
for and
to Act................. of ........... pay a fine of Rs. ................ in the above case and Where I have, on
preferring the above| AppealPetition| has admitted to ball by the .......... said .......... Court of (a)
.................. in its order, dated the ............ day of .......... 19 .........I do hereby bind myself to attend
before the said Court or any other Court to which the appeal or the Sessions Case may be transferred
at 11 a.m. on ............. day the ............ day of 19 .............., or whenever required by the said Court or
the Court of ........... (b) .............
pending execution of the order of the Court of Appealtrial
and in the case of my making default herein, I bind myself to forfeit to the state the sum of Rupees
.................Dated this ............. day of .............. 19 ..........(Signature and thumb-impression of the
accused).We the marginally named persons, hereby declare ourselves sureties for the above named
accused, and we do hereby bind ourselves to produce him before the said Court or any other Court
to which the appeal or the Sessions Case may be transferred or the Court of ................ on the day
fixed or whenever called upon by the said Court or the Court (b).
pending| execution of the order of the Court of appealtrial| and in case of our making default
therein, we the said sureties hereby bind ourselves to forfeit to the State each of us the sum
of Rupees...............................Signature of the suretiesExecuted this ..................... day of ..................
19 .............Sessions Judge- - - - - - - - - - - - -MagistrateToThe SuperintendentJail(To obtain the
signature of the accused and return the bailbond for record in this Office)SURETIES
No. Name Father's Name Case Residence Age Calling Remarks
Note :- (a) The name of the Court in which the appeal of Sessions Case is filed should be
entered.(b)The name of the Court to the satisfaction of which bail is furnished should be
entered.When the appeal or the Sessions case is transferred to another Court, the Court from which
the appeal or the Sessions case is transferred shall inform the accused and the sureties of such
transfer.Form No. 60Notice[Section 403, Criminal Procedure Code]IN THE COURT
OF........................Criminal Revision Petition No. ................. of 19 ............ToThe Petitioner.The
Respondent.The Public Prosecutor.Notice is hereby given that the above petition presented for
revision of the order of the ................ under Section ............ Code of Criminal Procedure, will be
heard at 11 a.m. ........... on the day of .............. 19 ................Form No. 61Notice[Section 452, Criminal
Procedure Code]IN THE COURT OF THE ................. MAGISTRATE OFIn C.C. No. ............... of
............ 19 .............ToNotice is hereby given that the undermentioned property is ordered by the
Court of to be restored to you and that you should appear and take possession of it at an early
date.Description of the property .................Dated the ............ day of ............ 19
...............Magistrate.Form No. 62Proclamation relating to unclaimed property[To be issued under
Section 457, Code of Criminal Procedure]Proclamation is hereby made that .................... has been
seized under the provisions of Section ............ of the Code of Criminal Procedure at the house of the
............ in the street of ................ Village of .............. and is now lying at ........... in the ..............
charge of ......... town ............ in.Any person having a claim to the aforesaid property is hereby
required to appear before me and establish the same within six months of this date, failing which the
said property will be held at the disposal of Government and will be sold.Dated ............. day of
............. 19 ............Magistrate.Form No. 63Notice[Section 408, Criminal Procedure Code]IN THECriminal Rules of Practice and Circular Orders, 1990

COURT OF THE ....................PetitionerRespondent
Complainant in C.C. No.Accused| | AccusedComplainant| in C.C. No. of 19 ............. on the file of the
Magistrate of ..................................................................................
ToTake notice that an application has been made to this Court for the transfer of C.C. No. ...............
of 19 ................. on the file of the Magistrate of ............... and that the application ............... will be
heard on the .......... day of 19, ........, at .............. a.m.Station :Dated :Sessions Judge.Form No.
64[Section 356, Criminal Procedure Code]IN THE COURT OF .....................The .................... day of
.................. 19 .........Sessions-------------- Case No. ................... of ................. 19 ........CalendarPresent
:Sessions Judge- - - - - - - - - - - - -MagistrateVersus :The StateOffenceSentenceORDERUnder
Section 356 of the Code of Criminal Procedure, the accused is further ordered to notify his residence
and any change of residence after release to the police for a period of .............. from the date of
release.Sessions Judge- - - - - - - - - - - - -Magistrate(Seal)ToThe SuperintendentJail ...............Form
No. 65Memorandum
Sentenced to
.................rigorousimprisonment
and to pay a fine of Rs.
..........and in default ofpayment
to further rigorous
imprisonment dated ..............
19Year's
monthsYear's
MonthsWith reference to the warrant issued by theCourt
dated ...... the ......... day of ........... 19...........,
directing the execution of the marginally
notedsentence passed on prisoner in Calender Case
No. ............ of19, intimation is hereby given that
the sum of Rupees being thewhole part of the fine
imposed on the said has been realised.Receipt of
this intimation should be acknowledged and
theinformation endorsed on the warrant.
ToThe Superintendentof the
...............  
Sessions Judge- - - - - - - - - - - -MagistrateForm No. 66IN THE COURT OF
SESSION.................DIVISIONSessions Case No............... of 19 ..............Dated...............
19..............,Dispatched 19............,Session Judge.FromToThe Superintendent,................................
Jail.Sir,I am to request you to cause the production before this Court at 11 a.m. on the ....... day of
........ 19 ........., ............ of the undertrial prisoners in the cases noted below.Sessions Judge.
Number of the Sessions
CaseNumber of the Register
CaseName of the committing
CourtName of the
accused
Form No. 67Letter accompanying a record and memorandum of acknowledgementNo. ...............
dated the .......... 19 .........FromToSir,
I am to *forward/return herewith by the Original record of the case noted on the margin,| **called
for in yourreceived with| No............, dated the ....... 19........
Signature and Designation of the Officer.MEMORANDUM OF ACKNOWLEDGEMENTReceived the
record forward with letter No. ................ dated the .......... 19........., from the ............ of
............Signature and Designation of Receiving Officer.Dated ........... 19* Here state method of
despatch.** Note also on the margin the number of files and pages in each file.Form No. 68Notice to
take back documentsIN THE COURT OF........................Case No. .................... of 19 ...........of
Complainant- - - - - - - - - - - -AppellantVersusofAccused- - - - - - - - - -RespondentThe parties in the
above case are hereby required to take back into their custody within six months from the date
hereof, the documents now in the custody of Court filed by them as evidence in the above case, theCriminal Rules of Practice and Circular Orders, 1990

Judgment (or order) now having become final The parties are hereby informed that the documents
are kept at their own' risk that the Court from this date declines all responsibility for their safe
custody and that, if not taken back they will be destroyed when the record is destroyed.The ...............
day of ............ 19 ...........Presiding Officer.Form No. 69Court's certificate to be given to Government
or Local Fund servants who attend Court as witnessIN THE COURT OF.....................**Certified
that*........................appeared before me as a witness on behalf of in a Civil/Criminal .............. case
for .............. days ........... from ....... to .......*Name**Designation*Here state ............ in his*
.............. capacity to depose to facts whether official within his knowledge and that he has to private
.............. been ..........If nothing is paid ................ paid the undermentioned allowances: -under either
head itshould be clearly stated.
As travelling allowance Rupees
As subsistence allowance Rupees
Date ...............Presiding Officer in the Court.Note : - (1) Government Officers summoned to give
evidence in their private capacity ie., to depose to facts not coming to their knowledge in the course
of their official duties or with which they have not had to deal officially are not entitled to travelling
allowance from Government(2)In civil cases to which the State is not a party, official witnesses
appearing at the instance of a private party will be paid by the party through the Court and the fact
certified as in the case of a payment by the State.Form No. 70Sessions statement showing the details
of cases to be committed to the Court of Sessions(To be submitted by the Committing Magistrate to
the Chief Judicial Magistrate)(See Administrative Form No. 34)Form No. 71Calendar and
Judgment[for use in cases where there is only one accused person]
District
Calender of cases tried by
theMagistrate of
  Date of     
offence Report or complaintApprehension
of accusedRelease
on bailCommencement
of trialClose
of
TrialSentence
of OrderExplanation
of delay and
remarks
 
Judgment in Calender
Case No............................
of 19 ...................... on
thefile of the ...............
Magistrate of
.................Complainants.
Name of accused AgeFather's
name
   Yrs.    
Religion Calling Residence Taluk
    
Offence -        
Finding -        Criminal Rules of Practice and Circular Orders, 1990

Sentence -        
Date of Receipt Docket From     
Remarks of the Chief
Judicial MagistrateToThe Chief
Judicial
MagistrateCalenderCase
No.Date of
JudgmentDate of
despatch
o..................... 19
.......CalendarDate
of receipt.
Form No. 72Calendar and Judgment[For use in cases where there are more accused persons than
one]
District of
Calendar of cases tried by
theMagistrate
of
  Date of      
OffenceReport or
complaintApprehension of
accusedRelease
on bailCommencement
of trialClose of
trialSentence
of OrderExplanation
of delay and
remarks
        
Judgment in Calendar
Case No.
.................of19.............on
the file of the ............
Magistrate of............
Complainant.
Name of accused Age Father's name Religion Calling Residence Taluk
   Yrs.    
Offence-Finding-Sentence
-Date of Receipt     
     
Docket From    
Remarks of the Chief
Judicial magistrate ToThe Chief
Judicial
MagistrateCalender
Case
No................Date of
Judgment -Date of
despatch ofcalender
of 19 ...........Date ofCriminal Rules of Practice and Circular Orders, 1990

receipt -
Form No. 73IN THE COURT OF THE .................Judgment in Calender Case No. ...........................
on the file of the .......................... MagistrateComplainant -Accused - Offence -Sentence - Finding
-Description of the accusedDate of
1 2 3 4 5 6 7 8
Serial Number NameFather's
NameRace Occupation Residence Age Occurrence
9 10 11 12 13 14 15
ComplaintApprehension or
appearanceRelease
on bailCommencement of
trialClose of
trialSentence or
orderExplanation of
delay
Form No. 74Proceedings of the ....... dated the ...... day ofinCalendarMiscellaneousPreliminary
Register Case No................. of 19 ............
1. Name of Station and Number in first information book.
2. Section of law under which charge was laid.
 (1) Concerned(2) Arrested with warrant(3) Arrestedwithout warrant(4)
Appeared before the Court on summons orotherwise.
 
3. Number of accused4.
Value of Property -
Lost -Recovered -
5. Whether the case is -
(1)Charged by the Police(2)Referred as false by the Police(3)Referred as mistake of law or
fact.(4)Referred as undetectable.
6. Offence under which convicted and sentenced.
7. If acquitted or discharged, opinion as to -
(1)Whether the case is true, but not proved.(2)Whether the case is intentionally false and if so,
whether compensation has been ordered to be paid to the accused.(3)Whether the case is due to a
mistake of fact or law.(4)Whether the offence proved is a non-cognizable one.
8. Number of accused convicted, discharged or acquitted.Criminal Rules of Practice and Circular Orders, 1990

9. Calling of persons convicted and whether classified as habittial criminals.
10. Remarks on conduct of Police.
ToThe Superintendent of Police,....................................... Magistrate.Note : - (1) The four classes of
cases shown against Serial No. 7 should be clearly distinguished.(2)A case should never be declared
simply "false". It should always be stated under which class it falls.(3)If a case is referred by the
Police as false, the Magistrate in passing orders should state (1) whether he directs the case to be
struck off as intentionally false, mistaken or non-cognizable or (2) whether he is unable to pass any
such orders and is not prepared to send the accused and try the case. if the Magistrate sends for the
accused and tries the case the results of the trial should be intimated to the Police, all the particulars
required in this Form being given.Form No. 75IN THE COURT OF...................The .............. day of
........... 19 ............
Present : -| | Sessions JudgeMagistrate
Judgment in Criminal Appeal No................ of ............ 19 ........From what court the appeal is
preferred.Number of the case in that Court.Number of the Appeal.Name and description of the
Appellant.The sentence and law under which it was imposed in the lower Court.Whether confirmed,
modified or reversed, and if modified the modification.
Presentation FilingNotice issued by
Court to appearBail bond if appellant has
been let out on bailApplicant
ordered to appearHearing Order
       
The appeal coming on for hearing before me, upon perusing the petition of appeal and the record of
the evidence and proceedings, and upon duly considering the same after hearing the appellant and
prosecution.JudgmentForm No. 76IndexIN THE COURT OF SESSION ...............
DIVISIONSessions Case No. .............. of 19 .........
Part of – the Committing Magistrate's Record
SI.
No.Description of Paper Page
1 Extract of Diary …..........
2 Chargesheet of Complaint …..........
3 Statement of witness under Section 202 and approvers evidence …..........
4Register of Preliminary Enquiry including Summary of evidence,Magistrate's
reasons for committing…..........
5 Crime occurrence Reports, Village Officer's Reports etc. …..........
6 Other Documents, Plans etc. …..........
Dated ......... 19 .......Sessions Judge.Form No. 77IndexIN THE COURT OF
SESSION..................DIVISIONSessions Case No.................of 19 ...............English Part of Sessions
RecordCriminal Rules of Practice and Circular Orders, 1990

SI. No. Description of Paper Page
1. The Charge  
2. The plea of the accused  
(1) (2) (3)
 1. ..............  
 2. ..............  
3. Record of oral evidence for prosecution :  
 First Witness .................  
 Second Witness ................  
 Third Witness .................  
4. Examination of accused :  
 Before the Sessions Court :  
5. Record of oral evidence for defence -  
 First Witness ......................  
6. Exhibits :  
 (a) Documents used in evidence other than those included inSerial No. 4  
 A -  
 B -  
 (b) Material objections produced in evidence  
7. Judgment  
8. Other Miscellaneous Papers  
Dated ............... 19 .........Sessions Judge.Form No. 78List of Material ObjectsIN THE COURT OF
SESSION..................DIVISIONSessions Case No................of 19 ..............(P.R.C. No.............
of.........19..........on the file of the Magistrate)
1 2 3 4 5 6
Mark given
in the
Session
CourtItem of reference in the
letter to the
ChemicalExaminer(vide
Exhibit)Item of reference in
the letter to
theSerologist (vide
Exhibit)Mark given by
the SerologistDescription Remarks
Sessions Court,Sherishtadar.Note : - (a) The list should include all objects exhibited in the Sessions
Trial.(b)Every object should have fixed to it a label containing a brief description and mark assigned
to it in the Sessions Court. The label should be pasted on or securely fastened to the object. Each
object should be kept in a separate cover or other receptacle.(c)The description in column 6 should
be sufficiently full to secure easy identification.(d)Weapons should be accurately described by their
specific names.(e)Valuable should be sent separately by insured post.(f)Under column 7, it should
be explained where or from whom the object is alleged by the prosecution to have been
recovered.(g)The pasting of labels or the packing should not interfere with the marks of blood, etc.,
and detract from the probative value of the object.Form No. 79IndexIN THE COURT OF SESSIONS
............ DIVISIONSessions Case No............. of 19 ..........(Part of Sessions Records in Regional
Language)Criminal Rules of Practice and Circular Orders, 1990

SI. No. Description of Paper Page
(1) (2) (3)
1. Examination of accused before the Sessions Court  
2. Exhibits  
 A. -  
 B. -  
Dated .......... 19 ........Sessions Judge.Form No. 1[Criminal Registers No. 1]Register of Sessions Cases
Received and Disposed of
1 2 3 4 5 6
  Date of   
Number of
sessions casesName of
committing
Court and P.R.
No.Number,
name and
residence of
accusedNature of
offence
charged and
section of
code or lawCommitmentReceipt of
Record
7 8 9 10 11 12
Commencement
of trialClose of TrialDate of
JudgmentResultDate of delivery of
record into
record-room
withRecord-keeper's
initialsRemarks
Form No. 2[Criminal Register No. 2]Register of Appeal Cases Received
1 2 3 4 5
  Date of   
Number of
appealFrom what Court
with number of the
case in that CourtName and rank of
appellant in the
Lower CourtSentenced or order appealed
against and law under which
itwas passedPresentation
of appeal
6 7 8 9 10
Hearing Order ResultDate of delivery of record into
record-room
withrecord-keeper's initialsRemarks
INSTRUCTIONSThe register should be checked by the presiding officer every month and omissions
rectified.Form No. 3[Criminal Register No. 3]Register of revision cases entertained.
1 2 3 4 5 6 7
Number of
cases
entertainedWhether taken up
suo motu or on
application, Ifon
application, the
name of the
applicant and his
position inIf by petition,
date of
presentation
thereofFrom what
Court with
number of
the case on
thefile of
that CourtNature
and date
of
disposalDate of delivery of
record into record
room
withrecord-keeper's
initialsRemarksCriminal Rules of Practice and Circular Orders, 1990

theLower Court.
Form No. 4[Criminal Register No. 4]Register of calendar and Preliminary Register cases received
1 2 3 4 5 6
Number of
calendar caseName of
compliant or
station form
whichchargesheet
was received with
date and number
of chargesheetNumber
and name
of
accusedOffence
complained of and
section of lawReceipt of
report or
complaintApprehension of
the accused or
of his
appearancein
Court
7 8 9 10 11  
Commencement
of trialDecision ResultDate of delivery of
record into
record-room
withrecord-keeper's
initialsRemarks (if a
case has been
treated as a
longpending as
a long pending
one, note he
fact herein) 
INSTRUCTIONS
1. The first few pages should be set apart for Preliminary Register Cases
which should be numbered separately from Calendar Cases. In murder cases
it should be stated in the remarks column whether the accused can afford to
pay an advocate.
2. The despatch seal should be obtained in the last column of the Register in
token of transmission to the Sessions Judge of copies of Judgment and
orders.
in cases required to be included in the monthly statement prescribed in Rule 262 their inclusion
should be noted in the last column.
3. The register should be checked by the presiding Magistrate every month
and omissions rectified.
Form No. 5[Criminal Register No. 6/6-A]Register of Miscellaneous and Maintenance Cases
Received
1 2 3 4 5 6 7 8 9 10
       Date
of  Criminal Rules of Practice and Circular Orders, 1990

NumberName and
residence
of
petitioner,
if any
ordesignation
of officer
by whom
reportedName and
residence of
respondentSection and
Chapter of
the Code
under
whichproceedings
are
institutedResultReceipt
of
petition
or
reportCommencement
of inquiryOrderDate of delivery
of record into
record roomwith
Record-keeper's
initials.Remarks
INSTRUCTIONS
1. This register should be maintained in two sections in all Courts. The first
section should be called "Criminal Register No. 6". This section should be
restricted to cases under Sections 108 to 110 and 125 of the Code of Criminal
Procedure and the cases entered in this Section should be shown as
Miscellaneous cases.
The second section called "Criminal Register No. 6-A" with the same heading as in Criminal Register
No. 7, should be opened and maintained for all proceedings other than those entered in the first
section. The cases entered in this section should be marked as MIscellaneous petitions.
2. The despatch seal should be obtained in he last column of the register in
token of transmission to the District and Sessions JUdge of copies of
Judgments and orders.
In cases required to be included in the monthly statement prescribed in Rule 262 of their inclusion
should also be noted in the last column.
3. The register should be checked by the presiding Magistrate every month
and omission rectified.
Form No. 6[Criminal Register No. 6-B]Register of Applications under Section 113(4) of the Indian
Railway Act
1 2 3 4 5 6 7 8
Number
of the caseDate of
receiptName of
defaulterDesignation
of Railway
Official who
lodged the
complaintAmount of
fare
ordered to
be collectedDate of
noticeInitials of
the
MagistrateAmount
collected
9 10 11 12 13 14 15 16Criminal Rules of Practice and Circular Orders, 1990

  Irrecoverable
amount
written off
Date of
collectionInitials of
the
MagistrateDate of
remittance to
RailwayInitials of
MagistrateAlternative
sentenceAmountDate of
Sanction of
Chief
Judicial
MagistrateInitials of
the
Magistrate
Form No. 7[Criminal Register No. 7]Register of Results of Inquiries and TrialsCourt :Year
:InstructionsThis register is cast in such a Form as to supply materials for most of the columns of
Statements No. II, Part I, and No. IV, Part I. All cases disposed of, whether the accused appeared or
not, should be entered therein. Column (1) is simply intended to mark identity of the case and thus
to prevent a repetition.
2. The total of the entries in each column of the register should be
transferred without alteration to the Statements, the following are exceptions
in the case of column (1) of the register, the entry to be transferred to the
statement is the total number of the entries, and in the case of column (8)
which concerns only Statement No. IV, Part I, it will be necessary to add the
number of persons (to be ascertained from the Court's File Book) pending
inquiry or trial.
3. If the fact of receipt by transfer or commitment or on reference is noted in
the remarks column, it will save reference to the records for purposes of
columns (3) and (11) of Statement No. II, Part I, and of columns (3), (4) and (6)
of Annual Statement No. IV, Part I.
4. This register is practically a ledger of offences. The heading of each page
will be the particulars of the offence, and for this purpose the prescribed
schedule of offences must be adhered to. One or more pages must be set
apart for each offence or group of offences against which there is a head of
crime shown in columns (5) (6) or (7) in the schedule, according as the
experience of the Court may suggest as necessary for year. Separate entry
should be made in alphabetical order of each special or local law, other than
the Criminal Procedure Code, against which offences have been committed.
Every person should be entered under the "Head of Crime" under which the
Magistrate finally dealt with him. Where an accused is tried under more than
one head of charge, he should be exhibited under the principal one only,
unless he happens to be accused of entirely distinct offences supported byCriminal Rules of Practice and Circular Orders, 1990

separate evidence, in which case the trials would be separate and results
independent.
5. In the column of remarks a note shall be made against every case in which
the complainant was required to pay compensation by the accused under
Section 250, or the defendant, in addition to the punishment inflicted upon
him, was required to give recognizance or security to keep the peace under
Sections 106 and 122 and in how many cases entered against heading 15 the
orders of the Court of Session were taken under Section 122.
6. Column (2) - The duration of cases will be calculated (1) in Magistrates
Courts from the earliest date of the apprehension of any of the accused or of
his appearance in Court, whichever was the earlier and (2) in Courts of
Session from the date of the commitment of the accused.
The duration of a case disposed of on the same day on which the accused appears, will be taken as
one day only for the purpose of entries in this register. In all other cases the date of appearance shall
be excluded e.g., if the case is disposed of on the next day, the duration will be only one day.
7. Column (25) - The number of witnesses required to attend in Court on
more than three days whether consecutive or otherwise should be stated in
this column.
NUMBER OF HEAD OF CRIME
Cases disposed
ofNumbe of
personsOn regulartrialYouthful offender dealt with under A.P.Children
Act
1 2 3 4 5 6 7
Number of
the cases
disposed ofActual number of
days during which
the case inwhich
accused persons
appeared before the
Court lasted
[notapplicable to
cases shown in
column (6)]Complaints
dismissed
under Section
203 Cr.P.C.By dismissal under
Section 204(3) or
bydischarge or
acquittal of accused
under Sections 256,
257, 249,320 Cr.P.C.
before they
appeared in Court.Struck
off as
falseBy
transfer,
death or
escape of
accusedOtherwise
8 9 10 11 12 13 14
Brought for
inquiry ofDied,
transferred orDischarged
or acquittedSentence
passedReleased on
ProbationDischarged
afterDelivered to
parent orCriminal Rules of Practice and Circular Orders, 1990

trial escaped admonition guardian, etc.
Under the Probation of Offenders Act, 1958.Nomenclature of offence Act and Section
 Number of persons    
 Convicted   Number of
witnesses
On summary
trial| Adult Juvenile  
 Youthful Offenders dealt with underA.P.Children
Act   
15 16 17 18 19 20
Sentence
passedReleased on probation
under Probation of
Offenders ActDischarged after
admonitionDelivered to
parent or
guardianMale Female
21 22 23 24 25 26
Male FemaleCommitted or
referredExaminedRequired
to attend
on more
than three
daysRemarks
Of Offences
[Appended to C.R. No. 7]N.B.: - (1) Every abetment should be included with the substantive offence
abetted, but where such abetment falls under Sections 114, 115, 116 or 118 the same should be
entered separately under the offence abetted and a note made in the column Remarks against the
entry, to facilitate the compilation of figures for the first Head of Crime in the Police statement
of(2)Every attempt, not separately specified in this schedule, should be entered immediately after
the substantive offence at which it is an attempt.
     Number of
Head of
CrimeFor
High
:ForPolice
:Statement
A :
Class of
offencesChapter Section Description of offenceStatement
No. IIPart IPart
II
1 2 3 4 5 6 7
I. OFFENCES
UNDER THE
PENAL CODECriminal Rules of Practice and Circular Orders, 1990

Offences
against the
StateVI121 to 130 131 to
136Offences against the State 1 ... 2
Offences
relating to
ArmyVII & 138Offences relating to Army
and Navy2 2 ...
  137Harbouring deserters by
master of shipib. ... 3
Offences
against public
tranquillityVIII140, 143 to 145,
149 (Cognizable
cases)Wearing the dress of a
soldierib. 7 ...
  150, 151, 157 &
158Unlawful Assembly ... 6 ...
  147, 148, 152 and
153Rioting, etc. 4 ib. ...
  143
(non-cognizable
cases) and 154 to
156Rioting, unlawful assembly ib ... 10
  160 Affray 5 ... ib.
 IX 161 to 169By or relating to public
servants6 ... 5
Offences by or
relating to
public servantsX 170 to 171 Relating to public servants 7 7 ...
Contempts of
the lawful
authority of
public servants 172 to 190Offences against public
justice8 ... 4
False evidence
and offences
against public
officersXI 193 to 200False evidence or
Subordinate, etc., of public
servants andoffences
against Public Justice10 ... 4
  201 to 204, 213
to 215
(non-cognizable
cases)False evidence, false
complaints and claimsib. ... 6
  227 and 228 205
to 211 212, 213 to
216 (cognizable
cases)Harbouring and offender ib. 4 ...Criminal Rules of Practice and Circular Orders, 1990

  216 and 216-A
217 to 223offences by public servants 10 ... 5
  224 to 226Other offences against
Public Justicesib 5 ...
Offences
relating to coin
and
Government
stampsXII 231 to 254 Offences relating to coin 11 3 ...
  255 to 263 Offences relating to stamps    
Offences
relating to
weights and
measurementsXIII 264 to 267Offences relating to weights
and measurements13 ... 8
offences
affecting the
public health,
safety,
convenience,decency
and moralsXIV 269 and 277Offences affecting public
health14 57 ...
  270.. -do- ib. 34 ...
  271 to 276 and
278-do- ib. ... 27
  279, 280, 283, Offences affecting safety 5 57 ...
  285, 286 and
289-do- ib. 34 ...
  281 and 282 -do- ib. ... 27
  284, 287 and
288, 290Offences affecting
convenience16 ... ib.
  291Offences affecting
convenienceib. 57 ...
  292 to 294Offences affecting decency
and morals17 ib. ...
  294-AKeeping lottery office or
publishing proposals for
lottery.17-A ... 28
Offences
relating to
religionXV 295 to 297 Offences against religion 18 49 ...
  298 Offences against religion ib. ... 22
XVI 302 and 303 *Murder by thugs ... 8 ...  Criminal Rules of Practice and Circular Orders, 1990

Offences
affecting the
human body
   Murder by dacoits ... 9 ...
   Murder by robbers ... 10 ...
   Murder by poison 19 11 ...
   Other murders ib. 12 ...
  307 Attempt at murders 20 13 ...
  304 Culpable homicide 21 14 ...
Offences
affecting the
human body
(contd.) 304-ACausing death by rash or
negligent act21-A 15 ...
  308Attempt at culpable
homicide22 14 ...
  305 & 306 Abetment of suicide 23 18 ...
  309 Attempt of suicide 24 ib. ...
  311 Thuggee 25 39 ...
  312 to 315 Causing miscarriage 26 ... 11
  316... Injury to unborn children 27 ... ib.
  317... Exposure of infants 28 17 ...
  318 ...Concealment of birth by
secret disposal of dead
body29 ib. ...
  325 & 326 Grievous hurt 30 20 ...
  327 & 330Hurt for purpose of
extorting property or
confession etc.ib. 22 ...
  328...Administering stupifying
drugs, etc. to cause hurt.ib. 21 ...
  329, 331 & 333Grievous hurt for the
purpose of extorting
property orconfession etc.ib. 19 ...
  323... Hurt 31 ... 17
  324 Hurt by dangerous weapon ib. 23 ...
  332Hurt for deterring public
servant from his duty.ib. 22 ...
  334Hurt on grave or sudden
provocationib. ... 16
  335 ib. 20 ...Criminal Rules of Practice and Circular Orders, 1990

Grievous hurt on
provocation
  336 and 337Rash act causing hurt or
endangering lifeib 41 ...
  338Rash act causing grievous
hurt or endangering life.ib. 29 ...
  341 Wrongful restraint 32 40 ...
Offences
affecting the
human body
(Contd.) 342 to 344 Wrongful confinement 33 ib. ...
  345 Wrongful confinement ib. ... 14
  346 to 348Wrongful confinement in
secret, etc.ib. 15 ...
 XVI 352, 355 & 358 Criminal force or assault 34 ... 15
  353, 354 Criminal force to public ib. 28 ...
  356 & 357 servants or woman, etc.    
  364, 366 & 367Kidnapping or forcible
abduction with
aggravatingcircumstances35 24 ...
  363, 365, 368
and 369Other cases of kidnapping
or abduction36 ib. ...
  370 Slavery 37 ... 12
  371 Habitually dealing in slaves ib. 27 ...
  372 & 373Buying or selling a minor
for prostitution etc.38 26 ...
  374 Forced labour 39 42 ...
  375, 376 A, B, C,
DRape 40 15 ...
  377 Unnatural offence 41 16 ...
Offences
against
propertyXVII 382Theft with aggravating
circumstances of cattle
Ordinary... ... ...
  379 to 381Other cases of theft* of
cattle Ordinary42 44 ...
  401Belonging to a gang of
thievesib. 39 ...
  386 & 389Extortion with aggravating
circumstances44 ... 13
 384 & 385 Other cases of extortion 45 ... ib.Criminal Rules of Practice and Circular Orders, 1990

Offences
against
property
(Contd.)
  394 Robbery with hurt* -    
   By poison ... ... ...
   By other means 46 82 ...
  392 Other cases of Robbery* -    
   In a dwelling house on the
highway between sunset
and sunriseOther robberies47 33 ...
  393Attempts at robbery* in a
dwelling house On the
highwaybetween sunset
and sunrise Other
robberies   
  396 Dacoity with murder 49 9 ...
  397 Dacoity with hurt 50 30 ...
  397 Robbery with hurt* -    
   By Poisonous or stupefying
drugs   
   By other means ib. 32 ...
  398Attempt at dacoity armed
with deadly weapons51 30 ...
 XVII 398Attempt at robbery with
deadly weaponsib. 32 ...
  395 Dacoity 52 30 ...
  399 & 402Preparation and assembly
for dacoityib. 31 ...
  400Belonging to a gang of
dacoitsib. 39 ...
  403 and 404Criminal misappropriation
of property53 ... 19
  406 to 408 Criminal breach of trust 54 45 ...
  409Criminal breach of trust by
public servant, etc.ib. ... 20
  411 & 414Receiving etc., stolen
property55 46 ...
  412 and 413Receiving stolen property
by dacoity or habituallyib. 38 ...Criminal Rules of Practice and Circular Orders, 1990

  417 to 420 Cheating 56 ... 18
  421 to 424Fradulent deeds or
disposition of property57 ... 18
  429Mischief with aggravating
circumstances58 35 ...
  430 to 433Mischief with aggravating
circumstancesib. 34 ...
  435 to 440     
  426, 427 & 434 Other cases of mischief 59 ... 21
  428Other cases of mischief
with aggravating
circumstancesib. 35 ...
  459 & 460Criminal trespass resulting
in grievous hurt or death60 36 ...
  449 & 452Criminal trespass for the
commission of serious
offence61 37 ...
  454, 455, 457 &
458-do- ib. 36 ...
  447 & 448Other cases of criminal
trepass62 47 ...
  453 & 456Lurking house-trepass or
house-breakingib. 43 ...
  461 & 462Breaking a closed
receptacleib. 48 ...
Offences
relating to
documents and
to trade or
property marksXVIII 465 to 469,Forgery or uttering or
possessing63 ... 7
  471 & 474forged documents or
papers   
  472, 473, 475 &
476Counterfeiting or making
or possessing a counter seal
etc.,for forgery.64 ... ib.
  477Fraudulently destroying or
defacing a will or
otherdocuments65 ... ...
  482 & 486 to
488Using a false trade or
property mark etc.66 ... 9
  483 to 485 67 ... ibCriminal Rules of Practice and Circular Orders, 1990

Counterfeiting or making
or possessing a die or plate
orinstrument for
counterfeiting a trade or
property mark.
  489 Removing, destroying etc. 68 ... ib.
Criminal
breach of
contracts of
serviceXIX 491Criminal breach of
contracts of service69 ... 23
Offence relating
to marriageXX 493 to 498Offences relating to
Marriage70 ... 24
Defamation XXI 500 to 502 Defamation 71 ... 25
Crminal
intimidation
insult or
annoyanceXXII 506The threat being to cause
death or other cases
grievous hurt72 ... 26
  504 & 506 to 510Other cases of intimidation
etc.73 26 26
  505Other cases of intimidation
etc.,ib. ... 2
II. OFFENCES
UNDER
SPECIAL AND
LOCAL
LAWS(a)Code
of Criminal
Procedure
 VII.  Offences under Security to
keep the peace Chapter74 ... 29
 VIII  (B) (Sections 108, 111 to 118
and 122)   
   Offences under Security for
good behaviour75 50 ...
   Chapter VIII (B) (Sections
109, 110, 111 to 118 and
122)   
* These details should be noted in the column of Remarks in Register A for easy compilation.Form
No. 8Register of Punishments[Criminal Register No. 8]Number of Head of CrimeNomenclature of
offence
   Number
of personsCriminal Rules of Practice and Circular Orders, 1990

sentenced
to
Imprisonment
15 days and
underOver 15
days but
not
exceeding
one
monthOver one
month but not
exceeding six
monthsOver six
months
but not
exceeding
one yearOver one
year but
not
exceeding
two yearsOver two
years but
not
exceeding
seven
yearsOver
seven
years
Number of the
cases
convictedNumber
of persons
convictedImprisonment
for lifeRigorous Simple Rigorous Simple Rigorous Simple Rigorous Simple Rigorous Simple Rigorous Simple Rigorous Simple
1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17
Number
of persons
sentenced
to
(Contd.)
Fine
Rs. 10 and
underAbove Rs.
10 but not
more than
Rs. 50Above
Rs.
50
but
not
more
than
Rs.
100Above Rs.
100 but not
more than
Rs. 500Above
Rs.
500
but
not
more
than
Rs.
1,000Above Rs.
1,000      
Alone With other
punishmentAlone With other
punishmentAlone With other
punishmentAlone With other
punishmentAlone With other
punishmentAlone With other
punishmentAmount
imposedAmount
realisedAmount paid as
compensation
(Section 557,
Criminal
ProcedureCode).Number of
persons (1)
released on
probation or
with
admonitionunder
the
Probation of
Offenders
Act or the
Reformatory
SchoolsAct
or (2) whose
guardians
are boundNumber of
boys whose
sentences
were
commuted
to
detention
in
acertified
school.RemarksCriminal Rules of Practice and Circular Orders, 1990

over under
the Children
Actsor under
the Railways
Act or (3)
who are
subjected to
an
orderunder
Section 22 of
the Cattle
Trepass Act.
18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35
Form No. 9[Criminal Register No. 9]CourtRegister of Appeal Cases disposed of ..........................
Year ...............
Number of
appellants
whose
cases were
disposed
of
Number of
the appeal
disposed
ofNumber of
appellants
concernedBy
death,
transfer
or
escapeBy
rejection
of appealBy
confirmation
of sentence
or orderBy reduction
of sentence
or
modification
oforderBy
reversal
of
sentenceBy
proceedings
being
quashedBy new
trial or
further
inquiry
being
orderedActual
Number of
days during
which the
appeallastedRemarks
1 2 3 4 5 6 7 8 9 10 11
Note :- Show in the column of remarks the number of persons dealt with under Section 106(4) of the
Criminal Procedure Code or under A.P. Children Act.Form No. 10[Criminal Register No. 10]Court
:Register of Revision Cases Disposed ofYear :
Number
of
accused
persons
whose
cases
weredisposed
of
Number
of the
revision
casesNumber of
accused
persons
concernedBy
death,
transfer
orBy rejection
of
applicationBy
reduction
of
sentenceBy reduction
of sentence
or
modificationBy
reversal
of
sentenceBy
proceedings
being
quashedBy new
trial or
further
inquiryOtherwise Actual
number
of days
duringRemarksCriminal Rules of Practice and Circular Orders, 1990

disposed
ofescape or order of order being
orderedwhich
the case
lasted.
1 2 3 4 5 6 7 8 9 10 11 12
Form No. 11[Criminal Register No. 11]Court :Diary Register (Sessions and Magistrate Courts)Year :
Date Number of case, appeal or petition Purport of proceedings
1 2 3
Form No. 12[Criminal Register No. 12]Register of Court-fees and Process Fees Received
DateSerial Number
in the registerNature of document and
reference to
connectedcase*Court-fees in
stampsNon-judicial
StampsRemarks**
Process fees
Other fees
1 2 3 4 5 6 7
. Rs. Np Rs. Np.  
* Column (3) - If there are enclosures, the number and nature of those documents also to be
specified in this column.** Column (7) - Return of documents which is exceptional may be shown in
the column of remarks.Note :- This register should be reserved for papers other than those received
by post.Form No. 12-A[Criminal Register No. 12-A]Process Register[Register of processes issued to
the Police Stations by the Magistrate]Name of the Police Station -
Serial
NumberNumber
of the
caseThe crime
numberNature of
process with
Identifying
particularDate when
issue of
process was
orderedDate when
sent to
Police
StationDate when
received
backRemarks
1 2 3 4 5 6 7 8
Instructions
1. A register in this Form should be maintained in each of the Magistrate's
Courts in the districts and an extract from this register should be attached to
the monthly statement in Criminal Register No. 30.
2. Every Inspector of Police in-charge of the Circle should often as possible,
and at least once in two months, take the registers of the police Station
under him to the concerned Magistrate's Court, check up the entries with
those in the registers and if necessary, the records maintained by the Courts
and make a report to the Superintendent of Police about the cases involving
serious delay or omission.Criminal Rules of Practice and Circular Orders, 1990

3. The above register should also be maintained in ledger Form, one section
being allotted one Police Station.
4. The Register prescribed above should be maintained with care and should
be scrutinized periodically by the head Ministerial Officer and the Magistrate.
5. In column (4) of the register, the issue of processes to witnesses for the
prosecution and for the defence should be shown separately. It is not
necessary to show the name of each of the witnesses but only their total
number, e.g., 10 summons P.Ws. 8 summons D.Ws. issue of bailable
warrants and non-bailable warrants being specifically recorded in red ink.
6. In column (7) of the register, the date of hearing should also be shown
under the date of return, if the date of return of the processes to the issuing
Court is later than the date of hearing.
7. In column (8) of the register should be entered the following, namely, (a)
with reference to column (4) the number of processes served personally and
the number of processes returned unserved, and (b) particulars as to
whether bailable warrants and non-bailable warrants were executed or not.
Form No. 13[Criminal Register No. 13]Court :For the month ofYear:
Date Camp Case posted Remarks Date Camp Case posted Remarks
1 2 3 4 5 6 7 8
        
Note: - (1) When cases are adjourned, the date and place of the adjourned should be shown in
column (4)(2)Cases disposed of on the date of hearing should be marked thus.Form No.
13-A[Criminal Register No. 13-A]Fair Copy Register
Serial
NumberNumber of
the caseDate of
judgmentDate on which
judgment was
given for fair
copyDate on
which fair
copy was
readyDate on which fair
copy was signed by
thePresiding
MagistrateDate of
despatch
of calendar
statement
1 2 3 4 5 6 7
Form No. 14[Criminal Register No. 14]Register showing the Disposal of Referred charge sheets
NumberName of
the
Police
StationNumber of
referred
charge-sheet
and Section
ofLawDate of
receipt by
MagistratePurport
of order
with
dateDate of
communication of
the order
toSuperintendent
of PoliceDate of delivery of
record into Record
roomwith
record-keeper's
initialsCriminal Rules of Practice and Circular Orders, 1990

1 2 3 4 5 6 7
Form No. 14-A[Criminal Register No. 14-A]Register of First Information Reports
SI.
No.Date of
receipt of
first
inFormation
reportName
of
Police
Station
and
Crime
No.Name of
the
accusedDescription
of offence
and
provisions
of lawDate of
occurrence
of offenceDate of filing
of
Charge-sheet
or final
reportC.C.No. or
referred
Charge-sheet
No.Remarks
1 2 3 4 5 6 7 8 9
FORM No. 15[Criminal Register No. 15]Court -Register showing the disposal of property produced
in inquiries and trialsYear
Description
of property 
Number of
case or date
and number
of
chargesheet,name
of stationSerial
No.Valuable
propertyOther
propertyInitial of
the Judge
or
MagistrateParticulars
of order
for
disposal
and
Section
oflaw with
dateIf returned
to party
producing
it, or his
agentsignature
and dateInitials of
the Judge
or
MagistrateIf sold
by
auction
the date
of
auction
realisedDate of
remittance
of sale
proceeds to
TreasuryInitials of
the Judge
or
MagistrateRemarks
of
Inspecting
Officers, if
any
1 2 3 4 5 6 7 8 9 10 11 12
Instruction
1. This Register shall be inspected at least one in three months by the
presiding Judge or Magistrate who will check the valuable and record the
result of this inspection in the column for remarks.
2. A fresh Register shall be opened every year and the outstanding items
shall brought from the register of the previous year.
3. When valuables are sent to the Chief Judicial Magistrate, a triplicate form
of receipt shall be used, one part of which will be sent to the Magistrate of
which one will be checked and signed by him and passed in this register on
receipt in the Sessions Court.
4. Along with its quarterly returns each Criminal Court will send a certificate
of having checked the valuables with their register.Criminal Rules of Practice and Circular Orders, 1990

5. Deposits and such other items, being case properties should be accounted
for being brought to this register. The challan and the numbers and dates of
the deposit may also be noted in the register so that deposit adjustment
vouchers column may readily be prepared and sent to the connected
Sub-Treasuries for adjustment and the fact be noted in the last column
relating to the remarks.
Form No. 16[Criminal Register No. 17]Register of Unclaimed Property
Serial
NumberReference
to the
current
with which
property
isreceivedDescription
of propertyWhen
where
and by
whom
foundIntermediate
references
with dates*How
disposed
when and
amount
realised at
sale
(ifsold)Date of
remittance
of amount
to TreasuryDisposal
member
with
which
the file
closesRemarks
1 2 3 4 5 6 7 8 9
* Here enter particulars, such as -(1)Date of submission of the notice to the District Press.(2)Date of
publication of the notice in the District Gazette.(3)Date of reference to Session Judge and of orders
thereon, etc.Form No. 17[Criminal Register No. 17]Register of Calendars Received[Sessions
Courts]CourtYearCalendars received from the
_________________________________________________ Class Magistrate of
__________________________________________________
Serial Number of case Date of If records called for, number on Revision file Remarks
Receipts of Calendar Persual of Calendar
1 2 3 4 5
* Here enter calendar cases, summary trials, etc.Form No. 18[Criminal Register No. 18]Register
showing the Remarks on Calendars and Judgments and Replies Received Form
[Name] [Class of Magistrate] District
Name of Court and
number of caseRemarks of the Munsif Magistrate and ChiefJudicial Magistrate and
replies of they Magistrate with dates
1 2
INSTRUCTIONS
1. The register should be written separately for each Magistrate by name both
in the Chief Judicial Magistrate Court and in the Munsif Magistrate Court.
2. The register used not be kept as loose sheets. Separate registers should
be opened for the Magistrate.Criminal Rules of Practice and Circular Orders, 1990

Form No. 19[Criminal Register No. 19]Register of Refund Certificates and Deposit Vouchers
issuedCourt -Year -
Month and
date of
certificate
or voucherName of
Court
which
imposed
the fine
and
numberof
case on
its fileName of Court
which
sanctioned the
refund
orcompensation
and date of
Judgment and
number of the
caseName and
residence of the
individual to
whom
therefund or
compensation
order was
grantedAmount
ordered
to be
paidDate in
which the
refund
certificate or
depositvoucher
was
delivered to
the party or
his agent, if
before
theCourt or
of the
despatch to
him and the
lower CourtSignature
of the party
or agent in
token
orhaving
received
the
certificate
or voucherRemarks
1 2 3 4 5 6 7 8
Form No. 20[Criminal Register No. 20]Register of fines imposed, levied and refundedCourt -Year -
Demand i.e.,
Balanceuncontrolled
(in cases of
previous
months or
Fines
imposed
incase of
current
month)Collections
Fine to be
credit
eventually to
Local
Funds,Municipal
Funds, etc.
Date of
Imposition
of fineNumber of
caseName of
the
accusedAmount of
the fines to
be credited
to
GovernmentName of
the fund,
body or
association
concernedand
the
provisionCompensation
awarded
under Section
250, 246
or358 Code
Criminal
Procedure,Initials of
Judge or
MagistrateAmount
collectedDate of
collectionInitials of
Judge or
MagistrateCriminal Rules of Practice and Circular Orders, 1990

of law
under
which the
fine is
imposedand
compensation
and all other
sumsrecoverable
life fines
which cannot
be entered in
column 4 or 5
1 2 3 4 5 7 8 9 10 11
Amount
credit in
Sub-TreasuryIrrecoverable
amount and
RemissionRefunds
Credit to the
GovernmentAmount
creditedTo be
credited
eventually
to Lower
Funds,Municipal
Funds, etc.Compensation
and other
amounts
described in
column (7)Date of credit
in
Sub-TreasuryInitials of
Judge or
MagistrateAmount
written
offNumber
and date
of
sanction
written
onBalance
uncollectedAmount
refundedNumber
and
date of
refund
orderRemarks
Name of the
funds, body
or association
concernedand
the provision
of law under
which he fine
is imposed.
12 13 14 15 16 17 18 19 20 21 22 23
Rs. Np. Rs. Np.  Rs. Np.   Rs. Np.  Rs. Np. Rs. Np.   
Note:- 1. The word 'fine' includes any amount recoverable as a fine or expenses of prosecution.
2. If a fine is collected while the person on whom it has been imposed is in
jail intimation of its collection must be sent at once to the Superintendent of
the jail and the fact noted in column 23, See Rule 181 of the Criminal Rules of
Practice.
3. In the case of a remission entered in column 18 and 19 a note "Remitted on
appeal" should be made against the entry in column 23.
4. the attention of Judges and Magistrates initialling under columns 8, 11 and
17 is invited to the fact that such initials show that they satisfied themselves
that the fines imposed are taken to demand, collected and credited to theCriminal Rules of Practice and Circular Orders, 1990

Treasury. No entry shall be expunged form the register without attestation by
the Judge or Magistrate.
Form No. 21[Criminal Register No. 21]Register of Witnesses' Batta Collected from
Parties[Magistrate's Courts]
DateName
of the
caseName
of the
partyOpening
balanceAmount
of
depositTotal of
columns
4 and 5Amount
paid to
witnessesAmount
refunded
to partiesSignature
or mark
of
witness
or partyTotal of
column
7 and 8Closing
balance,
i.e,.
difference
between
columns6
and 10Initials
of the
head
of the
officeRemarks
1 2 3 4 5 6 7 8 9 10 11 12 13
Instructions
1. This register should be maintained in the ledger form with a daily abstract
being recorded in the register itself. For this purpose separate page or pages
according to the needs of the particular case should be allotted for each case
and for entering the daily abstract, some pages should be allotted at the end.
2. The amount of unspent witness batta and batta collected for witnesses
whose evidence is dispensed with, should be entered in this register. The
register must be regular intervals every months, once by the Head Ministerial
Officer and another time by the presiding Magistrate during the scrutiny of
registers.
Form No. 22[Criminal Register No. 22]Register of orders of Judge or Magistrate on witnesses' Batta
and Travelling Allowance[Rule 236, Criminal Rules of Practice]
 Judge's
order fixing
the
 Whether
the witness
waspresent
on 
Number
of caseNames
ofwitnessesSignature of
the witness on
the first day of
hisappearanceSecond
dayThird
dayFourth
dayFifth
dayClass of
the
witnessNumber
of days
for
whichDistance
for
which
mileageInitials
of the
JudgeRemarksCriminal Rules of Practice and Circular Orders, 1990

batta is
payableis
payable
with
thename
of the
railway
and the
nearest
railway
station
1 2 3 4 5 6 7 8 9 10 11 12
Note: - The signature of an official witness should be taken in this register just as in the case of any
other witness and the fact and the date of issue of the Court attendance certificate should be noted
against the entry.Form No. 23[Criminal Register No. 22-A]Batta and Travelling allowances to
witness Criminal Case No. .... on the file of the Court for 19 ......[Rule 236, Criminal Rules of
Practice]
 Travelling
allowanceBatta  
Names
of
witnessWhat caseNumber
of class
by rail
or rate
of
mileage
by roadNumber
of miles
by RoadAmount
of
Railway
fare
Mileage
by road
or actual
expenses
bysea or
canalAmount
of actual
expenses
of carriage
by road
not
exceedingfifty
paise a
mileActual cost
of carriage
hire to and
from Court
of First
Classwitness
on days of
attendanceNumber
of daysRate
per
diemTotal
batta and
travelling
allowanceCertificate of
Head Clerk
or
Magistrate
and
Comparison
withRegister
No. 22Receipts
of party
to
whom
payableRemarks
1 2 3 4 5 6 7 8 9 10 11 12 13
Form No. 24[Criminal Register No. 22-D]Cash BookMagistrate's CourtsCash Account of the Office
of the ........................ Magistrate of ................... for the .......... month of ............ 19 .........
Dr Receipts  Number of  Disbursements Cr
DateNumber of
item or folio in
LedgerParticulars CashBank or
TreasuryHead of
account
or
Heading
of itemDate Item VoucherFolio
in
ledgerParticulars CashBank or
TreasuryHead of
account
or
Heading
of item
1 2 3 4 5 6 1 2 3 4 5 6 7 8
   Rs.
P.Rs. P.       Rs.
P.Rs. P.  
Brought
forwardBrought
forwardCriminal Rules of Practice and Circular Orders, 1990

.............Carried
over............Carried
over
INSTRUCTIONS(a)All Cash transactions should be shown in this register except salaries, travelling
allowances, fines, moneys realised by forfeiting security bond of witnesses accused and
sureties.(b)Sale proceeds being an occasional item of receipts through shown in property registers
should also be shown in the book.(c)The cash book should be balanced once a month on the dates
on which the Treasury or Sub-Treasury closes its accounts of the month.Form No. 25[Criminal
Register No. 23]Register of long pending cases
Serial
NumberDate and
number of
Authorities
transfer to
this registerDate of
entry in
registerNumber
and
date of
casesDescription
of accusedDescription
of offenceDate of
offenceDate of issue
of
proclamation
under Section
82 of
CriminalProcedure
CodeDate fixed
for
appearanceDate of
attachmentDescription
of property
attachedMethod
and date
of
disposal
of
property
attachedDate of
recording
evidence
under
Section
229 of
CriminalProcedure
CodeDate of
appearance
or death of
accusedRemarks
1 2 3 4 5 6 7 8 9 10 11 12 13 14 15
Form No. 26[Criminal Register No. 24]Record destruction register
Year NumberDate of
DisposalDate of disposal or
revision petition if
anyDate up to which
to be retainedDate of
DesctructionRemarks
Part
IPart II Part I Part II
1 2 3 4 5 6 7 89
INSTRUCTIONS
1. The entries in columns 1 to 3 and 5 and 6 of the register should be made
as soon as the cases are received in the record room.
2. The entry in column 4 should be posted when the appeal or revision
petition, if any, as disposed of and the papers are received in the record
room.
3. Column 7 and 8 should be filled in only after the records actually
destroyed.
Form No. 27[Criminal Register No. 25]Register of summary trials held before .............. Magistrate of
..............[Section 263 of Criminal Procedure Code]
Offence
Serial Date of the Date of Name of Name, Complained Proved Value of The plea of Finding Sentence Date onCriminal Rules of Practice and Circular Orders, 1990

Number Commission
of the
offencethe report
or
complaintthe
complaintpercentage
and
residence
of the
accused
personsof if any property in
respect of
which
offence
committedthe accused
and his
examination
if anyand in the
case of
conviction,
brief
statement
of
thereason
thereofor other
orderwhich the
proceedings
terminated
1 2 3 4 5 6 7 8 9 10 11 12
Form No. 28[Criminal Register No. 26]Statement of Preliminary enquiries held beforeCourt -Year -
 Date  
Number
of the
caseName of
the
accusedSubstance
of the
ComplaintName of
the
ComplaintName of
witnesses
for the
prosecutionResult
of the
enquiryoffence ComplaintApprehension
of appearanceClosing
EnquiryExplanation
of delay
1 2 3 4 5 6 7 8 9 10 11
Form No. 29[Criminal Register No. 27]Register of fines in respect of which payment are payable to
(local body)
Date of Payment of
fine into the
TreasuryNumber
of caseAmount
paidRefund or
remission, if
anyExpenditure be
deducted, if anyNet amount
payableRemarks
1 2 3 4 5 6 7
INSTRUCTIONS
1. A page or a set of pages should be allotted for fines levied under each Act
and relating to each local body.
2. To enable a monthly comparison and reconciliation with the figures as per
Appendix C to Treasury Sub-Account No. 11, the extracts should work up to
the figures of "Amounts Credited" in item 3(b) of the Statement of Fines in
Form No. 30.
3. The total of the column "Net amount payable" for a year indicates the
amount payable by the District and Sessions Judge.
Note: - 1. A departmental register in this Form should be maintained in all the Criminal Courts in
the districts except Sessions Courts. An extract from this register should be attached to the monthly
statement in Criminal Register Form No. 30.Criminal Rules of Practice and Circular Orders, 1990

2. District Magistrates should also maintain a register in this Form and post
therein the figures taken from the statements received from the subordinate
Courts and effect reconciliation of the figures monthly with the Treasury
figures so that there may be no delay or difficulty in paying the grants to
local bodies at the end of the year.
Form No. 30Fine statement of the Court of........................... for the month of ..................... 19 ....... .
  Arrears Current Remarks
 1 2 3 4
  Rs.P. Rs.P.  
1Demand    
 (a) Fines to be credited to Government ...   
 (b) Fines to be credited eventually to Local or MunicipalFunds, etc. ...   
 (c) Compensation amounts etc. ...    
2Collections    
3Amount credited into the Treasury or Sub-Treasury    
 (a) To the Government ...   
 (b) To be credited eventually to Local or Municipal Funds,etc. ...   
 (c) Compensation, amounts, etc. ...   
4Amount written off ...   
5Remitted on appeal ...   
6Balance ...   
Certified that the above is a correct statement of fines and compensation amounts imposed, levied,
written off and remitted on appeal in my Court during the month of ........... 19
...............Magistrate----------------Judge
Certified that the amounts shown against item 3 were remitted into the| TreasurySub-Treasury
Sub-Treasury Officer------------------------------Treasury OfficerINSTRUCTIONS
1. If the amounts shown in columns 2 and 3 do not agree, the reason should
be explained in the columns for remarks.
2. The order sanctioning the writing off of any amount should be quoted in
columns for remarks.
FORM No. 30-AWorking Sheets for fine Recovery[To be maintained by all Criminal Courts except
Sessions Court]Criminal Rules of Practice and Circular Orders, 1990

Amount
collected
and
remitted
to
Treasury
withdate
 January February March April May June July August September October November December  
Serial
NumberDate of
imposition
of fineCase
numberArrear
DemandCollection Remittance Collection Remittance Collection Remittance Collection Remittance Collection Remittance Collection RemittanceAmount
written
offAmount
remitted
in appealremarks
1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19
Instructions
1. To be maintained in separate sections under the three heads specified in
item I of Administrative Form No. 30.
2. The sheets will be written up afresh in January and July each year.
3. Entries regarding collection and remittance should be initialled by the
Magistrate beneath each entry.
4. Dates to be entered beneath the relative amounts as denominators.
FORM No. 31Statement of Cases in which Sanction to Write off is Requested
Number and year of
caseName of
accusedAmount of
fineDate of
sentenceSteps taken to realize
the fineRemarks
 Rs. P.  
FORM No. 32Statement of refund of Fines to the Treasury Officer
District
of-------------------------------------Head
ofservice chargeableRefund of
RevenueRefunds
and DrawbacksVoucher No. .......
ofList of
payments.........for.........
19 ...........
In whose name credited On what account
receivedAmount realised Date of payment in Treasury Amount in which included
and head to which creditedTreasury
Officer's
signature in
token of
verification
ofTreasury
of TreasuryName
of
payeeAmount
to be
refundedReasons
and
authority
for
refundCertificate of
Departmental
note of refundSignature
of partyCriminal Rules of Practice and Circular Orders, 1990

credit
1 2 3 4 5 6 7 8 9 10 11
  Rs. P.  Rs. P.  Rs. P.     
   AuthoritySactionedControllingOfficers
or No.DatedThis order of refund has
been registered and
notedagainst the original
receipt entry in the
departmental
accountunder my initials
and previous order for
refund of the same sumhas
not been
issued.Signature...................Designation
...............Date....................
   
The ............. 19 ............ Passed for
payment.
Examined  Pay
RupeesAccountantMagistrate or other Officer
only.Officer-in-charge of
Treasury
FORM No. 33Statement showing the number of cases pending at the end of the month of ........ 19
.......In the Court of the .......... Magistrate of ..........
Number
of cases
pending
for
1 2 3 4 5    6 7 8
Name of
the
CourtNumber
of cases
pending at
the
beginning
of the
monthNumber
of cases
received
during
the
monthTotal
number
of cases
for
disposalNumber
of cases
disposed
off
during
the
monthLess
than
two
monthsOver
two
monthsOver six
monthsOver
one
yearTotal
number
of cases
pending
at the
end of
the
monthCause of
pendency
FORM No. 34[To be submitted by the Committing Magistrate to the Sessions Judge]Session
statement showing the details of cases committed to the Court of Session at ........... for the month of
............... 19 ............
Date of
Name of the
committing
CourtNumber of
the case on
theNumber,
name,
sex andNature of
offence
chargedOffence Report or
complaintApprehension
or
appearanceCommitment In Jail or
on bail or
otherwiseNumber
of
witnessesRemarksCriminal Rules of Practice and Circular Orders, 1990

committing
Courts fileage of
accusedand
Section of
the IPC or
otherlawsbound
over to
the Court
of Session
1 2 3 4 5 6 7 8 9 10 11
INSTRUCTION
1. To be submitted by the Committing Magistrate to the Sessions Judge
direct, on the date on which the case is committed.
2. Duplicate to be annexed to the copy of the Preliminary Register.
3. In case of murder, the Committing Magistrate should state in the remarks
column that he reported to the Sessions Court as to whether the accused is
able to employ an advocate.
4. The Preliminary Register number should be given in column (2).
5. Please write at the back, if there is not enough space on this page.
FORM No. 35[To be submitted by the court of Sessions to the High Court immediately after each
Session and in no case later than 8th of the succeeding month except for the months of April, May
and June for which a consolidated statement should be sent at the beginning of July]
Date of
Number
of the
Session
CaseNumber
of the
accused
involvedSection
of the
offence
chargedApprehension
or
appearanceCommitmentCommencement
of trialNumber
of
witnesses
examinedDate of
disposal
with
particulars
of the
offence
establishedand
the sentence
or order
passed
thereunder.Remarks
1 2 3 4 5 6 7 8 9
AbstractDuration of Sessions DaysCases PersonsPending from last SessionsNew :
...........................Total : ..........................Disposal off Referred ..........Postponed
.......................Pending from this SessionFORM No. 36[To be submitted to the High Court by
Sessions Judge on the 22nd day after the close of each quarter]Criminal Rules of Practice and Circular Orders, 1990

Quarterly Statement and Annual Statement No. 111 of Miscellaneous Proceedings under the
Criminal Procedure Code in the Court of the .......... of .......... for the| QuarterlyYearly| ...............
of ......... 19 ...... .
 Cases PersonsFine,
Compensation
or penalty
Disposed of
Nature of
ProceedingsTotal
number
for
disposalDisposal
ofPendingTotal
number
for
disposalDischarged Convicted PendingAmount
imposedAmount
realisedNumber of
persons
imprisonedRemarks
1 2 3 4 5 6 7 8 9 10 11 12
1. Proceedings against witnesses under Chapter VI-C of the Code of Criminal
Procedure.
1.
-A. Proceedings against persons under Sections 345, 346, 349, 350 and 485-A of the Code of
Criminal Procedure.
2. Proceedings under Chapter VIII, to prevent breach of peace, Section 106 to
108, 111, 118 and 122.
3. Proceedings under Chapter VIII, Security for good behaviour (Section 109,
110, 111, 118 and 122)
4. Frivolous or vexatious accusations summarily dealt with under Chapter
XX, Section 250.
5. Maintenance, Chapter IX.
6. Forfeiture of bail or recognizance, Chapter XXXIII.
7. Proceedings under Probation of Offenders Act.
Total.INSTRUCTIONSColumn I, sub-head 6-Complainants fined under Section 250, Criminal
Procedure Code, are not to be entered as convicted in Statements II (Part-I), IV (Part-I) or V (Part
I), but the fact of the fines having been imposed may be noted in the column of remarks of
Statement II (Part I), against the complaints preferred by them. The number of complaints should
be entered in columns 2, 3, 4 and the complaints in columns 5 to 8. The sub-head should also show
all accusations dealt with under Section 250, whether the complainant appeared in the Court orCriminal Rules of Practice and Circular Orders, 1990

not.Column 1, sub-heads 2 and 3-Cases under Sections 107, 108, 109, 110, 117, 119 and 122 Criminal
Procedure Code, will also appear in Statement IV (Part I), and under the appropriate head of the
schedule in Statement II (Part I), with which the figures should agree persons convicted under these
sub-heads 2 or 3 and required to give security or recognizance or both, under Sections 119 and 122,
Criminal Procedure Code will also appear in, and agree with, Statement V (Part I).Column 1,
sub-head 4, 5 and 8-Cases under these sub-heads will not appear in Statements II (Part I) IV (Part
I), or V (Part I).Columns 2 and 5-Show the numbers actually for disposal, excluding those
transferred to other Courts.Column II, sub-head 3-Show in the column of remarks the number
sentenced to rigorous imprisonment.Column II, sub-head 9-Show in columns 9 and 10 the amount
of deposits or bounds and the amount forfeited or realized as the case may be, and in column 11 the
persons ordered to be imprisoned under Section 61.FORM No. 37[To be submitted to the High
Court by the Session JUdge on the 15th day after the close of each quarter]Quarterly statement B
Part I - (Leading to Annual Statement No. IV, Part I) showing the number and General Results of
............. enquiries and ......... Trials in the Court of .......... for the ........ Quarter of 19 ............
Disposed Cases Pending
Name of
CourtNumber of
working
days in the
criminal
departmentTotal
number
for
disposal
ofBy
dismissal
of
complaint
under
Section
203 of
CriminalProcedure
CodeBy
dismissal
under
Section
204(3) or
by
discharge
oracquittal
of accused
under
Sections
256, 257,
249 or 320
ofCriminal
Procedure
Code,
before they
appeared
in Court.Struck off
as false
after the
appearance
of accusedBy
transfer
death or
escape
of
accusedOtherwiseIn which
the
accused
have
appeared
1 2 3 4 5 6 7 8 9
Duration
in days of
cases in
Cols.6
and 8Persons
brought to
trial
ConvictedNumber
of
witnesses
In which
thePendency
in days, ofAggregate Average Total
numberTransferred,
died orDischarged
orOn
regularOn
summaryCommitted
or referredTotal of
columnsPending Examined Required
to attendRemarksCriminal Rules of Practice and Circular Orders, 1990

accused
have not
appearedthe old
pending
case (Col.
9)for
disposalescaped acquitted trial trial 16 to 19 on more
than
three
years
10 11 12 13 14 15 16 17 18 19 20 21 22 23 24
Corresponding...................................... 8 ............... 9, 10,13, 11, 15, 16, 20, 25, 26, 27, 28, 29, 30,
Column of the to to
Annual Statement19,
23
INSTRUCTIONS(a)Column 2 where a day is devoted to several branches of work, the day should be
apportioned to each branch of work as accurately as circumstances admit of, six hours shall be taken
as constituting a full working day for the purpose of return.(b)Column 3 should show all cases
brought before Magistrate, whether or not the accused appeared in Court(c)The total columns 6 and
8 should agree with Column 7 of Annual Statement No. IV Part I.(d)In each sheet of this Form
entries should be made in Part I with reference only to such Courts as are shown in Part 2 of the
same sheet(e)Cases need not be distinguished into those under Sections 323 and 325, Criminal
Procedure Code and other cases nor need the work of each Court be distributed according to the
classes of powers of the presiding Magistrates. It is sufficient if the work of each Court is
shown.(f)Column 6 should show only cases in which accused have appeared.(g)Columns 14 to 23
should show only the accused who have appeared in Court.(h)For other instructions see those given
for the corresponding column in the Annual Statement. Also vide circulars under "Statistical
returns".FORM No. 38Statement B - Part-H-Showing the Details of the Detention of Persons for
Enquiry or Trial
Number of persons
pending enquiry
ortrial(Column 21 of Part
I)
Name of the CourtTwo
months
andOver two
monthsOver six
monthsTotalRemarks by way of
explanation of the entries
inColumn 3 and 4
1 2 3 4 5 6
In custody ........     
Not in custody ........     
In custody ........     
Not in custody ........     
In custody ........     
Not in custody ........     
In custody ........     
Not in custody ........     
In custody ........     
Not in custody ........     Criminal Rules of Practice and Circular Orders, 1990

In custody ........     
Not in custody ........     
In custody ........     
Not in custody ........     
In custody ........     
Not in custody ........     
In custody ........     
Not in custody ........     
|  [Docket on
the reverse]  
Periodical No.   JUDICIAL -
CRIMINAL  
From      
The      
Dated      
Despatched      
Received     Subject
Quarterly Statement B for the quarter ending.FORM No. 39[To be submitted to the High Court on
the 15th day of after the close of each quarter]Quarterly Statement C - Part I (Leading to Annual
Statement No. VI) Showing the Business of the Criminal Courts as Courts of Appeal and Revision in
the District of ........... for the Quarters of the .......... Year ........ 19 .........
Number of
appeal and
cases for
revisionDuration
in days
of cases
in
column
4Number of
appellants
and
persons
concerned
incases for
revision
Disposed of
Name of the
CourtTotal for
disposalBy
transfer,
death or
escape of
accusedOtherwiseStill
pendingPendency in
days of the
oldest
pending
appeal or
revisioncaseAggregate AverageTotal
to be
dealt
withTransferred,
died or
escapedAppeals or
applications
rejectedSentence
or order
confirmedSentence
of order
reduced
or
otherwise
modifiedSentence
reversedProceedings
quashed or
order
reversedNew
trial or
further
inquiry
orderedReferredTotal (of
columns
11 to 17)Still
pendingRemarks
1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20
Corresponding 6 7 9 10  11 12 17 18 20 21 22 23 24 25 26 27 28 29
INSTRUCTIONSColumns 2 and 9 - Include cases taken up suo motu for revision and persons
therein.Note: - For other instructions of those given for the corresponding column in the Annual
Statement.FORM No. 40Quarterly Statement C - Part II Showing the details of the pendency ofCriminal Rules of Practice and Circular Orders, 1990

appeals and cases for revision as regards the persons concerned
Number of persons
(pending trial)Remarks by way of explanation of the
entries in columns 3 and4
Name of the Court Two months and underOver two
monthsOver three
monthsTotal
1 2 3 4 5 6
Appeal      
Revision      
[Docket on the reverse]Periodical No. ......................... of .................... 19 ................ .Judicial -
CriminalFromTheDatedDespatched ........................... 19 ............. .ReceivedNo.SubjectStatement C,
Paris I and II for the ................... quarter of the year 19 .......FORM No. 41[To be submitted to the
High Court on the 15th February of each year]Annual Statement No. 1 - Part I - Showing the number
and name of territorial Jurisdiction in the district of ......... and their Area and Population for the
year 19 .......... .
Names of sub-district
Name of judicial district Name of collectorate Area Population Civil Criminal Revenue Remarks
1 2 3 4 5 6 7 8
INSTRUCTIONSColumns 2, 3 and 4: - Where the district is only a part of a Collectorate, specify it
clearly and give the area population of such part only.Column 5: - i.e., the name of each Munsiff.
Where such name is different from the name of the station where the Court is located. The name of
the station should be shown in brackets just below that of the Munsiff.Column 6: - i.e., the local
jurisdiction of the Magistrate exercising original powers other than Special Judicial Magistrate. If
there be more than one such Magistrate at a station, reckon, by the station.Column 7: - i.e., the local
jurisdiction of a Revenue Court sitting for the disposal of suits under the Madras Estates Land Act
Where there are more such Courts than one at a Station reckon, by the station and not by the
Court.FORM No. 42[To be submitted to the High Court by District Judges on 15th February of each
year]Annual Statement No. 1, Part II - Statement showing the number of working days and powers
of judicial officers exercising criminal jurisdiction in the District of ........ for the ........ year 19 .......... .
Tribunal Number of working days Powers exercised Remarks
Original Appellate
1 2 3 4 5
INSTRUCTIONSColumn 3: - When a day is devoted to several branches of work it should be
apportioned to each branch of work as accurately as circumstances admit of six hours shall be taken
a constituting a full working day for the purpose of the return.[Docket on the reverse]Periodical No.
................. of 19 ........ .Judicial - CriminalFromTheDatedDespatchedReceivedSubject,Annual
Statement No. II, Part I, for the year 19 ............ .FORM No. 43[To be submitted to the High Court by
Sessions Judges on 15th February of each year]Annual Statement No. II, Part I - Showing Number
of Offences Reported and of Persons tried Convicted and Acquitted of ......... each Offence in the
District of ........ for the year 19 ........
Number of Cases
 Cases
found to beCriminal Rules of Practice and Circular Orders, 1990

true of
offence
reported in
Nomenclature of
office with chapter
and sectionof the
Indian Penal Code
or other law
applicableNumber of
Head of
CrimeOffences
reported in
pending
from
previous
yearOffences
reported
during the
yearComplaints
dismissed
under Section
203 and204(3)
Criminal
Procedure
CodeOther
cases
found
to be
falsePrevious
yearCurrent
year
1 2 3 4 5 6 7 8
Number
of
persons
 Convicted  
Adult Juvenile
Brought
on trial
during
the yearPending
at the end
of the
yearUnder
trial
during
the year
including
receivedby
transfer
and
pending
from
previous
yearDied,
escaped or
transferredDischarged
or
acquittedMales Females Males FemalesRemaining
under trial
at the end
of the yearRemarks
9 10 11 12 13 14 15 16 17 18 19
INSTRUCTIONSNote: - (a) Persons committed or referred [Sections 122, 323, 325 should not be
included in this Statement by the Committing or Referring Magistrate who will only enter the cases
of such persons in columns (3) to (10). The Courts to which the persons are committed or referred
will, if their cases are decided show the result in Column 11 to 17 and if not decided, account for
them in column 18, against each Head of Crime to be noted in Column 1 and 2.(b)If the entry in
Column 25 of Annual Statement No. IV, Part I, be reduced from that in Column 13 of that statement,
the difference should correspond with the entry in column 11 of the statement.Columns 1 and 2: -
These should give nomenclature and Head of Crime, etc., as in the schedule of offences, which must
be strictly adhered to.Columns 3 and 14: - Information for these columns must be worked out
exclusively from the office file book of cases instituted. Include cases received by transfer and
exclude those transferred. All offences (cases) of which information was given, complaint made to or
cognizance taken by a Magistrate under Chapters IV, V, XII, XIII, XV. Criminal Procedure Code, for
the first time during a year, are to be shown although some of the charges may not have been
prosecuted, or may have turned but to be false. As to cases taken upon Police Report, only those inCriminal Rules of Practice and Circular Orders, 1990

which the Police forward the accused under custody to a Magistrate or otherwise secured his
appearance before such Magistrate under Section 170 of Criminal Procedure Code, should be
included in these columns.Column 6: - All cases other than those in column 5 in which a Magistrate
declared that the charge was false and that the offence never occurred, should be included in this
column.Column 9: - i.e., All cases whether instituted or reported within the year or in the previous
year, and whether true or false, serious or frivolous, in which an accused person has appeared
personally or by an agent before a Court.The total of columns 3 and 4 should agree with that of
columns 5, 6, 7, 8 and 10.Column 12: - Show in the column of remarks the number transferred to
other Courts within the State. Show also the number of persons who died, escaped, or were
transferred respectively out of the total number of persons shown in this column.Columns 11 to 17: -
A note should be made in column 19 of the persons dealt with under Section 360 of Criminal
Procedure Code, and show as convicted in these columns.FORM No. 44[To be submitted to the High
Court by Session Judges on 15th February of each year]Annual Statement No. IV, Part I - Showing
Number and general result of enquiries and trials in Criminal Courts (Original Jurisdiction) in the
........ District of ......... for the year ......... .
Number of
casesNumber
of personsDuration
days of
cases (in
column
7)Number or
personsFor
enquiry or
trial
Name of
CourtPending
from last
yearInstituted or
received by
commitmentReceived
by
transfer or
on
ReferenceTransferred
or in which
the accused
died or
escapedTotalOtherwise
disposed
ofPending Aggregate AveragePending
from
last
yearReceived
during
the yearTotalBy
transfer,
death or
escape
1 2 3 4 5 6 7 8 9 10 11 12 13 14
Number of
persons
Whose
cases were
disposed
of
On
Regular
Trial
Youthful
offender
dealt
withA.P.
Children
ActOn
Summary
Trial
Youthful
offenders
dealt
withunder
A.P.
Children
Act
TotalCriminal Rules of Practice and Circular Orders, 1990

Discharged
or
acquittedSentence
passedReleased
on
probation,
under the
Probation
of
Offender
ActDischarged
after
admonitionDelivered
to parent
or
guardian
etc.Sentence
passedReleased
on
Probation,
Section
562, under
Probation
ofoffenders
ActDischarged
after
admonitionDelivered
to parent
or
guardian
etc.
15 16 17 18 19 20 21 22 23 24
Number of persons
(contd.) Whose cases
weredisposed of
convictedNumber of
witnesses
Committed or
referredTotal of
columns of 15,
24 and 25Still
pendingExaminedRequired to
attend more
than three
daysRemarks showing inter
alia the number
ofpersons in custody
whose cases are pending
(column 27)
25 26 27 28 29 30
Note: - The work of the Magistrates should be shown distributed not only according to the several
Courts, but according to the classes of their powers, which should be stated therein. Where a Court
was prescribed over in a year by Magistrate of different powers the work of the Magistrate under
each class of power should be shown separately against that Court.Columns 3, 4, 7 and 12: - Cases
committed or referred will be treated by the committing or referring Courts as disposed of (column
7). The Courts receiving them will show the cases in column 8 or 4 as the case may be, and the
persons in column 12.Column 5: - In this column cases should be shown in which accused has
appeared and not all the cases accounted for in quarterly statement B.Column 6: - In this column
cases should be shown in which accused have appeared and not all the cases accounted for in
quarterly statement B.Columns 8 and 27: - The case of an insane accused who has been dealt with
under Section 466 of Criminal Procedure Code, should not be kept on the file and shown as pending.
If the case is, at any time, resumed, it should be, shown in the returns as a new case.Columns 9 and
10: - In Magistrate's Courts, the pendency of cases should be calculated from the date of
apprehension or appearance of the accused whichever was the earlier and in respect of cases
received by transfer or reference ; from the date of receipt or order of transfer or reference, from the
date of receipt or order of transfer or reference in Courts of session, the pendency Courts from the
date of commitmentColumn 14: - Show in the column of remarks the number of persons transferred
to the other Courts within the "State".Column 25: - Persons referred to High Court under Section
366(1) should be shown in this column and not in columns 15 to 24 persons whose cases were
referred to superior court for higher punishment or for orders under probation of offenders Act, will
be entered in this column and not in columns 16 to 23 against the Court making the reference.
Against the Court receiving the reference they will be shown as convicted or acquitted according to
the order passed by it or as pending if orders have not been passed.Column 29: - The detention of a
witness in a Magistrate's Court should be calculated from the date of his attendance (pursuance toCriminal Rules of Practice and Circular Orders, 1990

his summons recognizance voluntarily etc.) up to the date of his discharge, and in a Sessions Court
from the first day of the Sessions unless some other day fixed his recognizance in which case it be
reckoned from the date he attends in accordance therewith, the day on which he attends being
always reckoned as one day.Column 29: - The number of witnesses required to attend for more than
three days should include all witnesses who are required to attend the Courts in connection with any
one case on more than three days (consecutive or otherwise not only those who are required to
attend for more than three consecutive days.FORM No. 45Annual Statement No. V, Part I, Showing
the punishments inflicted by Criminal Courts Original Jurisdiction in the District of ............... of the
year 19 ......... .[To be submitted to the High Court by Sessions Judge on 15th February of each year]
Name of the
persons
sentenced to
Imprisonment
Forfeiture of
PropertyFine Number
of Person
Ordered to
fine or give
Name of the
CourtImprisonment
for lifeRigorous SimpleIn addition
to other
punishmentWithout
other
punishmentWith
imprisonmentWithout
imprisonmentTotal of
(columns
2 to 4, 6
and 8)In addition
to
punishmentWithout
punishmentSecurity
for good
behaviourNumber of
persons (1)
released on
probation
or with
admonition
under the
probation of
Offenders
Act or (2)
whose
guardians
are bound
over under
the
Children
Act or
under the
Railways
Act or (3)
who are
subjected to
an order
under
Section 22
of the Cattle
Trepass Act.Criminal Rules of Practice and Circular Orders, 1990

1 2 3 4 5 6 7 8 9 10 11 12 13
Details of
ordinary
punishment
Number of
persons
imprisonment
in default
ofsecurity for
good
behaviourNumber
of
persons
finedAmount
of fines
realised
For on year
and underFor
three
years
and
underTotal
number
of
persons
convicted
Columns
9, 11, 12
and 13Rs. 10
and
underRs. 50
and
underRs.
100
and
underRs.
500
and
underRs.
1,000
and
underAbove
Rs.
1,000Amount
of fines
imposedOut of
those
imposed
during
the yearOut of
those
imposed
in
previous
year
14 15 16 17 18 19 20 21 22 23 24 25
Details of
ordinary
punishment
Number of
person
sentenced to
imprisonment
 Rigorous        Simple   
Amount paid
by way of
compensation
under
Section357 of
Criminal
Procedure
Code15 days
and
under6
months
and
under2
years
and
under7
years
and
underAbove
7
years15
days
and
under6
months
and
under2
years
and
under7 years
and
underAbove
7
yearsNumber of
boys whose
sentences
were
committed
todetention
in a
certified
School
26 27 28 29 30 31 32 33 34 35 36 37
INSTRUCTIONSNote: - (a) The Statement is meant to exhibit every sentence passed, and where two
penalties are inflicted, on the same offender, to exhibit them both e.g., if a person is sentenced to
rigorous imprisonment and fine, he will be appeared, in column 3 and 7 if so simple imprisonment
and fine, in columns 4 and 7, if so rigorous imprisonment and to give recognizance and to keep theCriminal Rules of Practice and Circular Orders, 1990

peace, then in columns 3 and 10 and so on, but in the case of offences triable jointly under Section
219 of Criminal Procedure Code, the sentence passed should be exhibited separately if consecutive,
and only concurrent.(b)Persons whose cases were referred to other Courts under Section 322, 323
and 325 or for confirmation of sentence, should be shown against the Court receiving the cases on
reference and not against the referring Court, and the punishment to be shown, in this statement is
that, if any awarded or sanctioned receiving Court.(c)The total of columns 3, 4, 14 and 15 and should
correspond with that of columns 27 to 36, and total of columns 7 and 8 with that of columns 17 to 22
columns 24 and 25. These columns should show the total fines including compensation under
Section 357 Criminal Procedure Code.(d)Provision of law under which forfeitures or confiscation
were ordered respectively should be added in columns 5 and 6.FORM No. 46Annual Statement No.
VI, Part I, Showing the Business of the Criminal Court at Courts of Appeal ........... and Revision in
the District of ........... for the year 19 ...... .[To be submitted to the High Court by Sessions Judges on
15th February of each year]
Number
of
appeals
or cases
for
revision
for trialDuration
in days
of cases
in
Column
9
Name of
the
CourtPending
form last
yearRegistered
during the
yearTaken
up
suo
motuReceived
by
transfer
or on
referenceTotalTransferred
or in which
the accused
died
escapedRemainderDisposed
offStill
pendingAggregate AveragePending
from
last
yearWhose
appeals or
applications
were filed
during the
yearReceived
by
transfer
or on
referenceTaken up
otherwise
that of
application
Appeal Revision.
Number of
appellants
and
persons
concerned
incases of
revision
 For trial       Disposed
TotalTransferred
or escapedRemainderAppeals or
applications
rejectedSentence or
order
Confirmed.
Sentence or
order
reduced
orotherwise
modifiedSentence
reversedHow trial
proceedings
quashed or
order
reversed or
furtherinquiry
orderedReferredTotal of
Columns
20 to 26Still
pendingRemarkCriminal Rules of Practice and Circular Orders, 1990

INSTRUCTIONSColumns 11 and 12: - The pendency of an appeal or application for revision should
be calculated from the date of receipt thereof in the office of a case dealt with by the Court otherwise
than an application, from the date of the order calling for the records.Columns 13 to 28: - The words
"persons concerned in cases for revision apply only to accused on whose behalf applications for
revision are made or a Magistrate or Judge takes steps to obtain revision on his own motion when
an application for revision is made by, or a case is taken up suo moto on behalf of a complainant, the
fact should be noted in the Remarks columns with the number of complainants concerned, and the
accused persons concerned in such cases will be shown in these columns according to the results of
the cases.Column 16: - This will show the number of persons concerned in the cases entered in
Column 4.Column 18: - Note in column of Remarks the number of persons transferred to other
Courts within the State.Column 20: - Show persons whose appeals were rejected under Section 384
of Criminal Procedure Code, or whose applications for revision were refused.Column 24: - Show in
this column the persons, in whose cases proceedings were quashed under Sections 275 on appeal or
under Section 326 on revision, and these in respect of whom orders of discharge were set aside
under Section 436 of Criminal Procedure Code.Column 25: - When a sentence is reversed or
proceedings are quashed and new trial of further enquiry is at the same time ordered, entry should
be made in this column only.Column 29: - The number of persons dealt with under Section 106(4)
of the Criminal Procedure Code, or under A.P. Children Act should be noted in this column.FORM
No. 47Annual Statement of proceedings taken under Sections 195 and 340 of the Code of Criminal
Procedure[To be submitted to the High Court by Sessions Judges on 15th February of each year]
Offences
Court Mentioned in Section 195 Clause (1) of the Codeof Criminal Procedure Number of Cases
1 2 3
Cases in which prosecution was
undertaken
Number of person concernedNumber of persons
convictedNumber of persons
acquittedRemarks
4 5 6 7
Form. No. 48Quarterly Statement of Criminal Appeals and Revision CasesDisposed off by the
Sessions Judge of District to be forwarded-to the District Superintendent of Police :
1. Serial number of appeals or revision cases disposed off during the quarter.
2. Station and crime number (if shown in records received in the Sessions
Court).
3. From what Court the appeal or revision is preferred.
4. Number of case in that Court.Criminal Rules of Practice and Circular Orders, 1990

5. Number of the Appeal or revision case.
6. Name and description of the appellant or petitioner.
7. Sentence and Law under which it was imposed in the lower Court
8. Whether confirmed or modified or reversed.
9. If modified, the modification.
FORM No. 49Annual Statement of Non-cognizable cases disposed of by the ............ District during
the year 19 .......... .
Date of
Number Registry Offence Locality Nature of offence and provision of law underwhich charged
1 2 3 4 5
Number of persons Convicted
Convicted Summoned Male Female Juvenile
6 7 8 9 10
Number of
personsNature of sentence
and provision of lawCallingNumber of days
during which case
lastedNumber of
witnesses who
attendedRemarks
Convicted Committed Discharged
11 12 13 14 15 16 1718
FORM No. 50Details of Fines, Forest and Excise composition fees, etc. remitted to the Sub-Treasury
at ................
Number
of caseName of the
AccusedTo be
credited to
the Govt.To be credited to
eventually local
funds,Municipal Funds
etc.Compensation amount etc.
(cols. 7 and 15 of theRegister
of Fines)
  Rs. Ps. Rs. Ps./Rs. Ps. Rs. Ps.Rs.
Ps.
Total      
DatedCourtMagistrate-----------------JudgeHere enter the name of the fund, body or association
concerned and the provision of law under the which the fine is imposed column 6 and 14 of the
Register of Fines.
To the
officer-in-charge
ofSub-Treasury
at.................  -----------
Sub-Treasury,Criminal Rules of Practice and Circular Orders, 1990

Please receive the
amounts shown
below,
creditthem to the
appropriate
heads of account
and give a receipt
forthem on the
accompanying
form.Received on.....
the ...... day of
...... from.......
Court the sum
of Rs.
........................
on accountof
the
Government as
shown below
  AMOUNT   AMOUNT
1Fines to be
credited to
GovernmentRs. Ps. 1Fines to be
credit to the
GovernmentRs. Ps.
2*Fines to be
credited to 2*Fines to be
credited to 
3*Fines to be
credited to 3*Fines to be
credited to 
4*Fines to be
credited to 4*Fines to
credit to 
5*Fines to be
credited to 5*Fines to be
credited to 
6Compensation
amounts etc.,
Cols. 7 and 15
of the Register
ofFines) 6Compensation
amounts etc.,
Cols. 7 and 15
of the Register
offines) 
 Number of caseNumber of
AccusedAmount   
   Rs. Ps.  Rs. Ps.
   Total   Total  
      
 Court  Magistrate Dated  Acct,
Sub-Try.
Officer
 Dated     
*Here enter the
name of the fund,
body
orassociation
concerned and *Here
enter the
name of
the fund,
bodyCriminal Rules of Practice and Circular Orders, 1990

the provision of
law under which
thefine is
imposed. See
columns 6 and 14
of the Register of
Fines.orassociation
concerned
and the
provision
of law
under
which
thefine is
imposed.
See column
6 and 14 of
the
Register of
Fines.
FORM No. 51Refund OrderCase ............................ of 19 ................ on the file of
theJudge---------------MagistrateI, ....................... hereby certify that accused in the above case is
entitled to a refund of Rupees ........... being the amount of fine imposed by the sentence of the Court
of the ................. Class Magistrate.
ReversedOn appeal by this CourtOnreference to the High CourtBy the High Court of or Courtof
Sessions or Court of Revision.JudgeMagistrate
19
Form No. 52AForm of IndexSuit application or appeal or calendar No. ........... of 19 ............. on the
file of the Court of the ............ in the District of ............
Serial Number of the papersDescription of the
paper and the dateDate when the
paper was filed
or put up in
thecaseNumber of
the part of
the record to
which
thepaper
appertainsAlphabetical
numerical
marks of the
exhibitsfiled
1 2 3 4 5
1     
2     
3     
4     
5     
6     
7     
8     
9     
10     
11     Criminal Rules of Practice and Circular Orders, 1990

12     
13     
14     
15     
16     
17     
18     
19     
20     
21     
BTable showing thedivisions
of the record and the
description of the
papersfollowing under each
division.CriminalPart I
Class of caseDivisions of the record
and description of the
papers fallingunder
each division.
1. Index
2. Judgment and sentence,
if any (Original and
appellate)including spare
copies of printed Sessions
Judgments.
Trial (other than summary)3. Petition of appeal, or
application for revision,
or letterof referring
Court judgment and
order thereon.
4. Charges.
5. Documentary evidence.
Summary TrialAll papers including
register
1. Index
2. Order and grounds, if any
(Original and appellate).
Miscellaneous Cases 3. Petition of appeal, or
application for revision,
orletter or referringCriminal Rules of Practice and Circular Orders, 1990

Court Judgment and
other therein.
4. Documentary evidence.
Part II
  1. Warrant of
commitment to
jail, if any.
2. Complaints to
Magistrates, when acted
upon by theMagistrate.
3. Reports by the Police
under Section 174 and 175 of
theCriminal Procedure Code
(Act-V of 1898) when
following by actionon the
part of the Courts.
4. Oral evidence.
Trials (other than summary)5. All papers not
already specified.
Miscellaneous cases 1. Oral evidence.
2. All papers not already
specified.
Table showing the periods
prescribed for the retention
byvarious parts of the
records in the various cases
ofproceedings.
 Name of Proceedings.  Number of
years for
which
records are
to beretained
   Part I Part II
1. In trial and appeals -
a. Sessions cases.  *20  
b. Warrant cases.  20 3
c. Summons cases  5 3
d. Summary trial -    
A. Forms kept under Section
263 of the Code ofCriminal
Procedure and Judgment10 -Criminal Rules of Practice and Circular Orders, 1990

recorded under Section 264
incases where either (i)
some of the accused or
parties proceededagainst
have not been apprehended
or (ii) the accused or any
ofthem have been convicted
of an offence or repetition of
whichrenders the offender
liable to enhanced
punishment
B. All other records 3 -
e. All records in criminal
cases before village
PanchayatCourts except
documentary evidence. 3 -1 -
f. Documentary evidence in
cases before village
PanchayatCourts. 33 -
2.In Miscellaneous
Proceedings -20 3
a. Maintenance 20 3 10 3
b. Security to keep the peace
or for good behaviour 10 33 3
c. Other Miscellaneous
Proceedings 3 33 -
3.Records in cases
referred by the Police
or in which
furtherinvestigation is
stopped. 330 30
4.Records in cases
entered in the Register
of long pendingcases 30
30  
  From the date
on which the
case entered in
theregister of
long pending
casesCriminal Rules of Practice and Circular Orders, 1990

Table showing the periods
prescribed for the retention
ofthe various Court
Registers, Books and
papers.
Number and Description of
Court Registers,Books and
Papers.Number of years for
which the registers,
etc.,to be retained.
1Register other than of
summary trials in the
use of CriminalCourts,
including Panchayat
Courts 5 5
 a. Register of long
pending cases. 30
2Record destruction
register of criminal
cases. 25
3 Register of Court-fees.  3
4.Copyists registers and
process service
registers. 3
5. Challan cheque books.  10
6.a. Magistrate and
Judicial Registers of
correspondencereceived
and despatched and
administrative registers
ofdespatch. 5
7.Other Court of Office
Books and Registers. 3
8.Correspondence with
the High Court
onimportant matters
and the orders of the
High Court
thereonincluding
Administration reports
received from the High
Courtand Government
20 years from
termination20 years from
terminationCriminal Rules of Practice and Circular Orders, 1990

 a. Criminal
Administration Report
salient features.20
9. Other correspondence3 years from
termination
10.Yearly and half-yearly
statements 55
11.Monthly and.Quarterly
statements 3
 a. Criminal Statistical
returns. 3
 b. Review of pending
criminal cases in the
Courts of theMagistrate
by the Sessions Judge. 1
 c. Copies of calendars
and Judgments
submitted by
Magistratesto the
Sessions Judge.3
12.Magisterial diaries,
Police arrest Returns,
Police
Occurrencereports and
Police Reports on
unnatural and sudden
deaths.3
13.Bond volumes of
Printed Sessions
Judgments.35
* In cases in which the sentence passed is one of imprisonment for life the Judgment must be
preserved until the reports is received of the convicts death or release.FORM No. 53Calendar case
No. .......... of ......... 19 ........ on the file of the Magistrate of ...............
Date of
occurrenceDate of report
or complaintDate of
issue of
processDate of
appearance of
accusedDate of
commencement of
CaseDate of
orderExplanation
for delay
1 2 3 4 5 6 7
FORM No. 54Foil[Form of receipt to be granted by the Court]IN THE COURT OF THE
........................Received this ............................ day of ............ 19 ............ from ......... son of ........... the
sum of Rs. ........... being the whole/part of the fine/compensation directed to be paid by the
accused/complainant in C.C. No. ........... on the file of this Court.Rs.
_______________Magistrate/JudgeCounterfoil[Form of receipt to be granted by Court]ReceivedCriminal Rules of Practice and Circular Orders, 1990

this .................. day of .............. 19 ............ from ........... son of ........... the sum of Rs. ............. being
the whole/part of the fine/compensation directed to be paid by the accused/complainant in C.C. No.
.............. on the file of this Court.Rs. _______________Magistrate/JudgeFORM No. 55Form of
receipt to be granted by the CourtIN THE COURT OF THE ......................Received this .................
day of ........... 19 ........... from .......... son of .............. the sum of Rs. ............. being the amount ...........
deposited by the complainant/accused petitioner/C.P. in CC./M. .......... No. ............ on the file of
............ Court.FORM No. 56Form of receipt to be used when valuables are sent for Disposal
SESSIONS COURT SESSIONS COURT ACKNOWLEDGEMENT
Dated .......... 19 Dated .......... 19[To be returned after
verification and Signature]
FromSession Judge FromSession Judge Chief Judicial Magistrate,
ToThe District magistrate To The District magistrate ......Office,Dated....19....
Sir,Under Section....., Criminal
ProcedureCode, I am to forward
herewith for...19.... ...the
undermentionedproperties un
Sessions Case No....... Of (PRC.
No......of19......, on the file of the
Mgistrate, .......) and to
requestthat the accompanying
acknowledgement may be
returned to me afteryour
verification and Signature.Sir,Under Section....., Criminal
ProcedureCode, I am to forward
herewith for...19.... ...the
undermentionedproperties un
Sessions Case No....... Of (PRC.
No......of19......, on the file of the
Mgistrate, .......) and to
requestthat the accompanying
acknowledgement may be
returned to me afteryour
verification and Signature.Sir,I am to acknowledge the
receipt of theproperties noted
below and accompanied your
letter No......of19.... (PRC
No....... of 19....on the file of the
Chief JudicialMagistrate).
SEssions Judge. Sessions Judge Chief Judicial Magistrate.
Certain Basic Rules Of Conduct Which Have To Be Followed By The Presiding Officers While
Performing Their Duties In CourtsTo start with, it is necessary to impress upon the Presiding
Officers the need of observance of a judicial code of conduct.It is the duty of every Presiding Officer
to create and maintain confidence in the administration of justice. That is possible not only if he
decides the cases fairly, impartially and with great objectivity but also preserves outward
appearances which inspire in the minds of the parties a confidence that nothing but justice would be
done to them. He should maintain equanimity of temper and observe restraint in his utterances.
Getting excited on trivial grounds and using harsh words towards the parties or their witnesses
under examination is a practice which must always be condemned. The Presiding Officer should
develop an impartial and impersonal attitude to whatever he sets his hand. Wherever he has a
personal interest or private knowledge of any case, it is always essential that he should not try that
case. The proper course in that event would be to have the case transferred to some other Court.The
necessity of maintaining cordial relations and mutual confidence between the Bench and the Bar is
vital in the interests of the smooth and efficient administration of justice. With patience and
courtesy, a Presiding Officer is bound to rise high in the estimation of the public and the Bar. A cool
temper and politeness towards all is a great safeguard against any breeze or scenes in the Court
which undermine the dignity and render the maintenance of decorum of the Court impossible. The
Presiding Officer representing, as he does, impersonal authority of law, should not permit himself to
get personally embroiled with the persons. This is bound to lead to a scene of intermittent wrangleCriminal Rules of Practice and Circular Orders, 1990

on an unedifying level. He must necessarily have sufficient knowledge of human psychology. He
must not forget that at times a lawyer works under great stress. The nature of his work is such that
he will have many difficulties of his own. He has to keep a close eye on the proceedings of the Court
and note the points raised by his opponent. He has to follow closely the deposition of witnesses, take
objections as to relevancy and admissibility of evidence and think out questions for
cross-examination. He has to be prepared for the situation when suddenly a witness deposes to facts
contrary to his expectation and instruction. He has to make up his mind just at the spur of the
moment how to deal with such a situation. Of course, even in the midst of these and other
distractions, he has to maintain his equilibrium of mind and behave courteously. But, if out of
inexperience, or excitement or any other reason, he commits a mistake or in the heat of moment
uses expressions which he never meant to utter, too serious a view may not be taken. If reproof is
necessary it may be uttered gently and courteously. But that does not mean that the recalcitrants
should not be dealt with sternly or suitably.The treatment meted out to witnesses should be polite
and gentle. Unless a witness is given evidence which is palpably false or persistently refusing to give
evidence which is obviously within his knowledge, he should not be threatened with the penalties of
law. Certain powers are no doubt given to the Courts in relation to witnesses who refuse to answer
questions or produce any document or article in their possession and in case there be persistent
refusal, a witness can be dealt with under Sections 345, 346 or 350 of Cr.P.C., but such powers
should be exercised only in cases where the witness is intentionally recalcitrant.It is the primary
duty of every Presiding Officer to maintain the dignity of his Court He should always be in full
control of the business in the Court This is possible if he is through with his work and is equipped
with tact and natural shrewdness. It is only then that he can be relied on to hold his office with
dignity.It is further necessary that he should maintain strict discipline in the office as well. It should
be his endeavour and he must always ensure that sense of duty is instilled in the minds of the clerks
and the work is done with due promptitude allowing no scope for complaints of corruption or
laziness. Much depends on the methods followed by the Presiding Officer in controlling his staff. A
vigilant eye on their work and a little strictness will put them on their guard against practices of
corruption or lethargic attitude.Punctuality should be the watch-word of the Presiding Officer. He
can, by his example create an atmosphere of punctuality in all the rank and file. Non-adherence to
the rule of punctuality will be attended with serious inconveniences not only to the litigants, their
witnesses and lawyers but also to the Presiding Officer himself as he will not be able to cope up with
the work in the limited period which will in due course inevitably result in the huge pendency of
cases.Recording Of ConfessionsThe substantive law as to confessions is in Sections 24 to 30 Indian
Evidence Act and the adjectival law in Sections 163, 164, 281(2) to (6) of the Criminal Procedure
Code.Section 164 of the Code of Criminal Procedure, 1973 lays down that any Magistrate of the First
Class or any Magistrate of the Second Class specially empowered may record any statement or
confession made to him in the course of investigation under Chapter XIV of the Code or at any time
afterwards before the commencement of the enquiry or trial. Such confessions shall be recorded and
signed in the manner provided in Sections 164 and 281(2) to (6) of the Code of the Criminal
Procedure.Both these Sections are to be read together and the procedure which is laid down therein
with minute particularity, must be meticulously followed. It must be remembered that Section 164 is
not restricted to recording of confession. It has reference to statements as well The statements need
not amount to a confession. They may be partly confessional and partly exculpatory. They may not
be confessions at all. The distinction between statement and confession assumes importance in viewCriminal Rules of Practice and Circular Orders, 1990

of the different mode of recording thereof as would appear from sub-section (2) of Section 164. If it
is a confession, it should be recorded and signed in the manner provided in Section 281(2) to (6) and
the direction in sub-section (3) should be strictly complied with The confession need not be of a
person already accused, it may be of a person who may ultimately be an accused. Sub-section (3) has
reference to the person and has not specifically used the word 'accused'. The act of recording
confessions under Section 164 is a very solemn act and in discharging his duties under the said
section, the Magistrate must take care to see that the requirement of Section 164(3) are fully
satisfied. (AIR 1957 SC 637).Before recording the confession, the Magistrate should explain to the
person that he is not bound to make confession and that if he does so, it may be used as evidence
against him. The Magistrate should satisfy himself that it is a voluntary confession. For that
purpose, he should question the person or the accused making confession whether he has been
bullied, influenced, tortured or induced by any threat or promise to make the statement The record
should show all the questions put by the Magistrate and answers given by the accused. The
questioning must be a real endeavour to find out why the accused has offered to make a statement
The object of putting questions to an accused, who offers to confess is to obtain an assurance of the
fact that the confession is not caused by any inducement, threat or promise having reference to the
charge against the accused person as mentioned in Section 24 of the Evidence Act. No element of
casualness should be allowed to creep in and the Magistrate should be fully satisfied that the
confessional statement which the accused wants to make is in fact and in substance voluntary. (See
AIR 1957 SC 637).The extent to which the Magistrate should question the person offering to make
the confession must necessarily depend upon the facts of each case. All that can be laid down to
serve as a guideline is that the Magistrate should feel that he has a reason to believe that the
confession is voluntary.The following observations of the Supreme Court on this aspect may be
noted for guidance :"Now the law is clear that a confession cannot be used against an accused
person unless the Court is satisfied that it was voluntary and at that stage the question whether it is
true or false does not arise.""It is abhorrent to our notions of Justice and fairplay, and is also
dangerous, to allow a man to be convicted on the strength of a confession unless it is made
voluntarily and unless he realises that anything he says may be used against him, and any attempt
by a person in authority to bully a person into making a confession or any threat or coercion would
at once invalidate it if the fear was still operating on his mind at the time he make the
confession.(Vide 1956 Cr.L.J. 426 at 431)The practice of making examination of an accused
immediately after he is produced by the police before the Magistrate must necessarily be deprecated.
It is essential to give the accused, in all cases, sufficient time for reflection at a place and in the
circumstances in which he cannot be influenced by the police before his statement is recorded.
When the Magistrate has any doubt as to whether the accused will be able to make a statement
voluntarily, he must necessarily remand him to judicial custody for reflection before recording his
statement It would be difficult to lay down a hard and fast rule as to the time to be given for
reflection. Normally, it may be reasonable to remand the accused to judicial custody at least for 24
hours (vide AIR 1957 SC 637 and 1963 (2) SCJ. 209). However, there can be no inflexible rule in the
matter for the Magistrate has to satisfy himself that the mind of the accused has been freed from
fear or other complexes developed during the police custody. Having regard to the circumstances of
each case, the Magistrate has to decide how much time should be given to the accused before his
confession is recorded.It is desirable to exclude all police officers from the place, when the
Magistrate records the statement of an accused. The police officers should not be present during theCriminal Rules of Practice and Circular Orders, 1990

examination of the accused or when his confession is recorded unless, in the opinion of the
Magistrate, safe custody of the prisoner cannot otherwise be secured. In any case no Magistrate
should question the accused or record any statement of his, in the presence of the police officer who
has arrested him or produced him before the Magistrate or has investigated the case, or is in any
manner concerned with the prosecution.The warning prescribed by Section 164 of the Code and
Rule 29 of the Criminal Rules of Practice shall be administered to the accused as soon as he is
produced and before he is told he would be allowed time for reflection. If the recording of confession
is not completed in one sitting and has to be continued later, whether on the same day or on a
different date, the warnings prescribed by Section 164 Criminal Procedure Code and Rule 29 of the
Criminal Rules of Practice should be repeated before recording of the confession is resumed.It is
necessary that the Magistrate should record the confession in open Court and during Court hours,
save for exceptional reasons to be recorded in writing. Recording of confessions in the Court-hall
during Court hours is a sure safeguard for the accused person knows and feels that he is in the free
atmosphere of the Court before a Magistrate and is absolutely free from any fear or apprehension
that might have been induced by reason of the fact that he was in the custody of police.Before
recording confession of an accused, the Magistrate should question the accused in order to ascertain
the exact circumstances in which his confession is being made and to the extent to which the police
had relations with the accused before the confession is made.The Magistrate may usefully put the
following questions to the accused:(i)When were you taken into custody by the police and where
were you detained and how long till you were produced before me?(ii)Were you detained anywhere
by the police before you were taken Formally into custody and if so, in what
circumstances?(iii)When did the police first question you?(iv)How often were you questioned by the
police?(v)Were you induced, coerced, promised or advised by the police to make a confessional
statement?(vi)Did the police or anyone else suggest or promise to you that you would be taken as an
approver?(vii)Is the confessional statement you offer to make induced by any harsh treatment and if
so, by whom?(viii)How much time were you given for reflection after you were removed from the
police custody?(ix)Did anyone induce, promise or threaten you during this period to make
confessional statement?(x)Look on all sides. There is no police here. You need no longer entertain
any fear of the police.(xi)Remember you are before the Magistrate. (I am the Magistrate). You are a
free agent and no longer in custody of the police. You are not bound to make confession. It is open to
you to make confession or not. You will not be given back into the custody of the police.(xii)The
confession which you may make may be used as evidence against you at the trial. You may bear this
well in mind before you make your statement(xiii)While making confessional statements do not
proceed on the erroneous impression that you will be taken as an approver or that anyone has
promised you to take you as an approver?(xiv)What is it that prompts you to make a confessional
statement?(xv)Now say what all you want to say.These questions and any others which may suggest
themselves to the Magistrate before he records the confession of the accused should Form part of
the record made under Section 164 of the Code. The Magistrate should note that all these questions
should be put when the accused is produced from judicial custody and before recording his
confession. Even after production from judicial custody, it is advisable that the accused, if necessary,
may be given one hour time for reflection allowing him to remain in the Court before recording his
confession.When upon questioning the accused and from observation of his demeanour, the
Magistrate has reason to believe that the accused has shaken off the effects of police custody, the
Magistrate should proceed to record his confession. The Magistrate should also examine the body ofCriminal Rules of Practice and Circular Orders, 1990

the accused for marks of violence if that is suspected or the accused makes grievance of the
same.The Magistrate must avoid questions in the nature of cross-examination. He should record the
confessional statement so far as it is possible in the words of the accused or as made by him.After
recording the statement, the Magistrate should read it over to the accused and obtain his signature.
The certificate as required by Section 164(3) of the Code of Criminal Procedure should be appended
to the Statement as follows: -"I have explained to (name) that he is not bound to make a confession
and that, if he does so any confession he may make may be used as evidence against him, and I
believe that this confession was voluntarily made. It was taken in my presence and hearing and was
read over to the person making it and admitted by him to be correct and it contains a full and true
account of the statement made by him."A Magistrate who records the confession, when called as a
witness under Section 463 Criminal Procedure Code, 1973 should be able to give details as to how
long he kept the accused under observation, how he satisfied himself whether the confession was
voluntary or whether there was any reason to think that violence, threat or other influence had been
used to obtain the confession. The Magistrate should make a full note of all those details in the
record of the confession itself instead of relying upon his memory to supplement the information in
the event of his giving evidence under Section 463 of the Code of Criminal Procedure.Recording Of
Dying DeclarationSometimes Magistrates are required to record the statement of a person who is in
imminent danger of death. On receiving a requisition to record a dying declaration, the Magistrate
should at once proceed to the hospital where the said person is being treated.The principle on which
the dying declaration is admitted is indicated by the Maxim of the Law - nemo moriturus
proesumitur mentiri - a man will not meet his Maker with a lie in his mouth. The statements made
by a person as to the cause of his death or as to any of the circumstances of the transaction which
resulted in his death are relevant whatever may be the nature of the proceeding in which the cause
of the death of the person who made the statement comes into question.On reaching the hospital,
the Magistrate should verify the particulars of the person who is expected to give the declaration.
Then he should inform the intended declarant that he is a Magistrate and that he would record the
declaration. The name and other particulars should be noted as given by the declarant.While
recording a dying declaration, the Magistrate shall keep in view the fact that the object of such
declaration is to get from the declarant the cause of probable death or the circumstances of the
transaction which may result in death. Before taking down a declaration, the Magistrate may put
some simple questions to elicit answers from the declarant with a view to know his state of mind,
and record every question put to the declarant and every answer given in reply. The recording
should be in the Form of questions and answers. As far as practicable, the declaration should be
recorded in the exact words of the declarant It should be ipsissima verbs of the person making it.It
should be a complete record conveying the whole of what the declarant wished or intended to say. It
has to be recorded carefully. When the declarant is not able to speak, his dying declaration made by
signs or gestures in response to questions, should be meticulously recorded. In such cases, the
record should show the question put and the nature of the signs made in reply. The record should be
so complete as to avoid all scope of misapprehension.The Magistrate should also note the patient's
condition, the manner of making the statement, and also, the persons, if any, near the patient. After
completing the recording, the statement must be read over and explained to the deponent and his
signature or mark obtained thereon, if possible. Then the Magistrate should append a certificate
stating that he has recorded the whole statement truly and correctly and that it has been read over
and explained to the deponent who admitted it to be correct It shall also be signed, whereverCriminal Rules of Practice and Circular Orders, 1990

possible, by the Medical Officer concerned, who will clarify with regard to the state of mind of the
declarant In cases where the accused has been already arrested and committed to judicial custody
and is readily available, it will be proper that the dying declaration be recorded, so far as the
circumstances may permit, in his presence and he may be allowed to put questions, if
necessary.Value of Dying Declaration: - It is not possible to lay down any hard and fast rule when a
dying declaration should be accepted, (i.e., acted upon) or not, beyond saying that each case must be
decided in the light of the other facts and the surrounding circumstances. The Supreme Court on a
review of the relevant provisions of the Evidence Act and the decided cases in different High Courts
has ruled -*AIR 1958, SC 22 and AIR 1970, SC 1566
1. that it cannot be laid down as an absolute rule of law that a dying
declaration cannot Form the sole basis of conviction unless it is
corroborated;
2. that each case must be determined on its own facts keeping in view the
circumstances in which the dying declaration was made ;
3. that it cannot be laid down as a general proposition that a dying
declaration is a weaker kind of evidence than other pieces of evidence ;
4. that a dying declaration stands on the same footing as any other piece of
evidence and has to be judged in the light of surrounding circumstances and
with reference to the principles governing the weighing of evidence ;
5. that a dying declaration which has been recorded by a competent
Magistrate in the proper manner, that is to say, in the form of questions and
answers, and as far as practicable, in the words of the maker of the
declaration, stands on a much higher footing than a dying declaration which
depends upon oral testimony which may suffer from all the infirmities of
human memory and human character ; and
6. that in order to test the reliability of a dying declaration, the Court has to
keep in view the circumstances like the opportunity of the dying man for
observation, for example, whether there was sufficient light if the crime was
committed at night; whether the capacity of the man to remember the fads
stated has not been impaired at the time he was making the statement by
circumstances beyond his control ; that the statement has been consistent
throughout if he had several opportunities of making a dying declaration
apart from the official record of it ; and that the statement had been made atCriminal Rules of Practice and Circular Orders, 1990

the earliest opportunity and was not the result of tutoring by interested
parties.
* AIR 1958, SC 22 and AIR 1970, SC 1566.Identification ParadeIdentification parades are generally
held during the course of investigation with the primary object of enabling the witnesses to identify
persons who are suspected to have committed the offence and who were not previously known to
them or to identify property which is the subject-matter of the offence. Requisition for holding such
parades to identify persons who took part in the occurrence under investigation is made to the
Magistrate, having territorial jurisdiction, by the Police as per the Police Standing Orders. The
conduct of such proceedings is called for only when there is a reasonable belief that certain arrested
persons are concerned with commission of the crime. Once a requisition is made to the Magistrate,
control over the proceedings is and should necessarily be with the Magistrate. Having regard to the
purpose of identification parades and their evidentiary value in the case full precautions are taken, it
is of paramount importance that identification proceedings should be absolutely above suspicion.
Bereft of these essential precautions the identification parade will be devoid of all evidentiary value.
It is of vital importance that care should be taken that even a semblance of unfairness is eschewed in
the conduct of proceedings and chances of testimonial errors are reduced to nil. It is necessary that
no undue delay is caused in either summoning the witnesses or in holding the identification parade
and the persons required to identify an accused should have had no opportunity of seeing him at any
time after the commission of the crime and before the identification parade and further no mistakes
are made by them at the time of identification parade or the mistakes made are negligible. It is also
proper that the ability of the witness to identify should be tested first without showing him first the
suspect or his photograph or furnishing him the data of identification. It should be ascertained from
him what are the characteristic features of the person he seeks to identify.On a requisition to
conduct identification parade, the Magistrate should hold it as expeditiously as possible. It should
be held during day time, in conducting the parades, the Magistrate should observe the following
principles:
1. Selection for the parade of non-suspects of the same religion status,
height, age, etc., unknown to the witness to be mixed with the suspects.
Their number should be sufficiently large (ie.) not less than 5 times. They
should have similar wear as the suspects, so far as it is possible. At any rate
the bearing and general appearance should not be glaringly dissimilar.
2. There should be a separate parade for each accused securing privacy from
the public view preferably by enclosing, if possible, the place of parade.
3. He should be allowed to select his own position and should be asked if he
has any objection to the persons present or the arrangements made.Criminal Rules of Practice and Circular Orders, 1990

4. Enumeration of the number of non-suspects and total number on parade.
5. Exclusion of everyone, specially the Police, from the proceedings ;
prevention of all jail authorities from coming and going.
6. jail authorities, if present, shall not be allowed access either to the
witnesses who have to be summoned for identification or to the persons
assembled at the parade till the completion of the parade.
7. Changing the place or places in the line of persons to be identified at
discretion before the arrival of each witness.
8. Seclusion till the completion of the proceeding of each witness as finished
with, from others whose evidence has still to be taken. This precaution would
exclude the possibility of signals.
9. Exclusion of the man deputed to call each witness from a view of the
proceedings.
10. Definite information as to whether the witness has any prior acquaintance
with any suspect he identifies.
11. Recording any well founded objection by any suspect to any point in the
proceedings.
12. Every circumstance connected with the identification shall be carefully
recorded by the officer conducting it, whether the suspect or any other
person is identified or not. Any particular blemish of the suspect facilitating
recognition such as 'one-eyed' etc., shall also be noted. If the Magistrate is
eventually cited as a witness, he should be in a position to speak to
everything relevant with reference to the record instead of relying upon his
memory.
As a measure of precaution, the Magistrate may take the thumb-impression of the suspects put up
for identification on the record of the proceedings after the parade is over. This would ensure that
the correct persons were put up for the parade. Similarly the thumb-impressions of each witness
may be taken to show that the witnesses actually participated in the parade are in fact the same
persons who come to the Court later to give evidence at the time of the trial. The personal marks of
identification of the witnesses should also be noted. If the Magistrates carefully follow the aboveCriminal Rules of Practice and Circular Orders, 1990

procedure at the time of conducting identification parades, there may not be any occasion to commit
any error or omission.Examination Of The Accused Under Section 313 Of The Code Of Criminal
ProcedureSection 313 of Criminal Procedure Code empowers the Court to put to the accused at any
stage of inquiry or trial such questions as it considers necessary without previous warning. The
power thus conferred, exercisable at its discretion at any stage of the inquiry or trial, has to be
necessarily exercised under the terms of the section after the witnesses for the prosecution have
been examined and before the accused is called upon to enter on his defence. The questions to be
put, have a limited purpose. The object mainly and solely is to be enable the accused to explain any
circumstances appearing in the evidence against him. Whereas there is a statutory obligation on the
Court to put such questions, no such obligation is cast on the accused to answer them. The accused
is at liberty to answer them or refuse to do so. No punishment can flow from his refusal to answer or
giving false answers. All that is permissible in such cases for the Court or to the Jury is to draw such
inference from refusal to answer as it thinks just. The answers he gives may be taken into
consideration in the inquiry or trial or put in evidence in any other inquiry or trial for any other
offence which such answers may tend to show that he had committed. No oath shall be administered
to him at the time of examination. This is short in the limited province of examination under Section
313 of Criminal Procedure Code.It may be seen that the language in which Section 313 of Criminal
Procedure Code is couched is plain and simple and leaves no room for any misapprehension as to
the scope and purpose of the section. The scope and purpose is obvious. The questions may be put at
any stage at the discretion of the Court; but they have to be necessarily put at the crucial stage
referred to in the section. The need or occasion for such questions arises only if there are any
incriminating or adverse circumstances against the accused appearing in the prosecution evidence;
but not otherwise. The only purpose of putting questions besides, is to give him a fair and full
opportunity to explain before the said circumstances may be used against him. So then naturally the
appropriate stage where such questions should necessarily be put is the stage when the prosecution
evidence has been closed and the accused has not yet entered on his defence, for it is at that point of
time that the Court will be in a position to know all the circumstances which have been brought in
evidence against the accused, and the questions put by it can cover the whole gamut of
circumstances against him. The Statute, therefore, has cast a duty upon the Court to put questions at
that stage. Examination at that stage will besides put the accused on notice as to the adverse
circumstances he has to meet and he will be able to adduce evidence effectively with full knowledge
of the facts he has to rebut All the questions which are necessary for the purpose of explaining each
hostile circumstance have to be necessarily put That can be satisfactorily done if the Presiding
Officer and he alone analyses the entire evidence brought on record by that time and arrange all the
adverse circumstances requiring explanation in logical order and frames questions in an
understandable Form leaving no room for doubt or confusion. Having regard to the object to be
achieved, the questions which may be put must in reason be simple in Form and in no manner
complex. They should be in a Form that even an illiterate person may be able to appreciate and
understand. In no circumstances, they should be of an inquisitorial or cross-examination character.
They should be free from all tendencies to entrap the accused or pin him down to incriminating
statements. Nor can the questions be designed or have tendency to fill up the gap of the prosecution
evidence. Scrupulous care, therefore, should be taken with regard to the Form and nature of the
questions. It is not proper to read out a long string of questions and ask what the accused has to say
about them. The proper way is to put to him one by one all the vital and salient points in theCriminal Rules of Practice and Circular Orders, 1990

evidence against him, each in a short sentence of simple Form. Each question should be put
separately in logical sequence leaving no room for misapprehension, and he should be asked if he
has to say anything about it. Each answer should be recorded separately. The examination should be
thorough and only with a view to enable the accused to explain the circumstances against him to the
best of his ability. No vital or salient or incriminating point should be left out which might result in
prejudice. If any vital point is left out it cannot be used against the accused. Any such lapse on the
part of the Court may prove fatal. The Supreme Court has time and again stressed on the
importance of proper examination and regretted that the importance of the rule of proper
examination so vital has so often been ignored.A careful reading of the various decisions of the
Supreme Court will enable the Presiding Officers to understand fully the significance of drawing
attention of the accused to each of such matter separately by putting him separate questions on each
of such points in a Form easy to understand and appreciate and giving him a fair and full
opportunity to explain the circumstances against him.(See Tarasingh vs. The State) (1951
S.C.441).All the questions must necessarily be put eventhough the accused may refuse to answer.
The examination must be thorough and not perfunctory or erroneous. It is not possible to
exhaustively lay down the various points which the Court has put to the accused. All that can be said
is that all the vital, salient and incriminating points must need be put to the accused. It all depends
upon the circumstances of each case. The points on which the questions are ordinarily put are as
follows:(1)The presence of the accused at the scene of occurrence.(2)The part alleged to be played by
him at the scene of occurrence in the commission of the offence.(3)The motive for
crime.(4)Anything revealed by the medical evidence as against him.(5)Any objects recovered from
him tending to incriminate him.(6)Confession.(7)Extra-judicial confession.(8)Disinterested
character of the witnesses or motive of the witnesses to depose against him.(9)Dying
declaration.These are merely illustrative. They are mentioned here to suggest the nature of the
points to be dealt with at the time of the examination. It should after all depend upon the facts of
each case. The rule is but salutary that it is necessary that all the incriminating points should be put
to him in the manner stated above. In order to ensure thoroughness of the examination as a rule he
must be necessarily asked at the end, the following questions.(1)Can you mention any reason why
you have been falsely implicated?(2)What else have you to say?These questions in addition to the
other questions are warranted by the facts of the case will enable the accused to explain fully the
circumstances against him.It must be borne in mind that the statement of the accused even though
not on oath has the same value as evidence. It is just like any other piece of evidence which may be
taken into consideration in the case. As the presumption of innocence is in his favour, even when he
is not in a position to prove the truth of the story, his version should be accepted if it is reasonable
and accords with probabilities unless the prosecution can prove beyond reasonable doubt that it is
false. This fundamental approach cannot be ignored in any case. When the accused has put forth a
reasonable explanation which might have been true and if the Court finds that there is no reason to
reject it as false, the Court must accept the explanation and give the accused the benefit of doubt and
acquit him.(See: Hate Singh Bhagat Singh vs. State of Madhya Bharat. A.I.R. 1953 S.C.468).It is
unnecessary here to cover the other aspects of Section 313 of Criminal Procedure Code, 1973. It is
hoped the above instructions, though not quite exhaustive, will furnish sufficient guidelines for
correct examination of the accused under Section 313 of Criminal Procedure Code.Judgment, Its
Contents, Composition And QualityOf the several functions which the Court is called upon to
discharge, the most onerous and important one is the writing of judgment. Its significance  cannotCriminal Rules of Practice and Circular Orders, 1990

be overemphasised when it is manifest the whole edifice of public confidence in Courts is built on
the quality of judgment that the Courts produce. The Judgment should, therefore, be a product of
clear sustained thinking, sound analysis of facts, application of correct legal principles and
condensed commonsense and ripe experience of men and matters. It should represent the best that
can be drawn from human thought and mind on the subject.The judgment in criminal cases
concerned, as it is, with life, liberty, honour and property of a citizen, must necessarily be clear and
systematic. Sections 353 & 354 of Criminal Procedure Code, 1973, provides inter alia for the
contents of judgments. A judgment should contain:(1)A concise statement of facts.(2)The point or
points for determination,(3)The decision thereon.(4)The reasoning for such decision.(5)If there is
conviction, it should specify the offence of which and the section of law under which the accused is
convicted and the punishment is inflicted.(6)If the conviction is under the Indian Penal Code and it
is doubtful under which of two sections or two parts of the same section the offence falls, it should
be distinctly specified and the judgment should be passed in the alternative.These are the essentials
which the judgments should contain. It is so not only in relation to the judgments of the trial Court
but also of the appellate Court. Indeed, the judgments of the appellate Court must be independent.
It should stand by itself without being supplementary to the judgments of the trial Court. It must
contain a careful appraisal of the whole evidence on record and it must show that the appellate
Court has applied its independent mind to all the circumstances from all aspects. It must be clear
that every item of evidence, on which the findings of the trial Court are based has been carefully
scrutinised and weighed. See Arjunlal Misra vs. The State (A.I.R. 1953 S.C.411); Aftab Ahmed Khan
vs. State of Hyderabad (A.I.R. 1954 S.C.436).It is not sufficient if one is conversant with what the
requisite contents of a judgment are. It is also necessary that he should be able to write good
judgment, for after all, it is the quality of the judgment that is of paramount importance. Its
composition is of no less significance.Writing of judgments is an art which has to be cultivated and
developed by regular study of judgments' of eminent English and Indian Judges. Study helps a good
deal. But ultimately the judgment depends upon individual talent, grasp of facts, command of legal
principles, clarity of thought, power of expression and natural proclivities of elaboration or
compensation. It is not possible to give precise or exact instructions of universal application as to
the manner in which the judgment should be composed because the facts of each case coming up for
discussion are never as a rule stereotyped. They may differ widely from each other. All that need be
stressed upon is that the judgment should not be prolix or a mere mechanical reproduction of facts
and evidence.It should contain a concise and precise statement of facts chronologically arranged
bringing to the fore points for determination. The narrative must be precise and clear. The
marshalling of facts should be thorough. Repetition must be avoided so far as it is possible. All that
happened at the time of the occurrence and the incidents which took place in so far as they are
material, should be narrated in their natural sequence. While brevity is a great virtue, clarity of
thought and expression should be the watchword. If the sequence is duly observed and facts are
logically arranged, the narrative will be precise, clear and impressive.It will be profitable if the
following sequence in writing judgments so far as it is possible, is followed :
1. The Statement of facts.Criminal Rules of Practice and Circular Orders, 1990

2. The occurrence and the gist of the offence with some details.
3. Motive Forming the background of the offence.
4. First Information Report time of its despatch and receipt.
5. Post mortem or wound certificate, if any.
6. Anything worthy to mention with regard to investigation.
7. The plea of the accused and the defence that is set up.
8. The points for determination.
9. Discussion of the merits of the prosecution evidence.
10. Discussion of the defence evidence, if necessary.
11. Conclusion and Sentence to be passed.
After narrating the facts as gathered from the prosecution case and stating the plea of the accused,
the points which require judicial determination should be clearly stated. The weight and value of
evidence in support of the prosecution should then be considered and if it makes out a case, the
defence evidence should be discussed. It should be judged whether the defence evidence does or
does not rebut the prosecution evidence. All this involves appreciation of evidence both oral and
documentary.The function of appreciation of evidence is not an easy task. Its technique requires a
separate chapter for due consideration. Therefore, it is dealt with in another chapter. So also the
question of conviction, punishment and sentence.It is sufficient here if it be stated that reproduction
of the evidence of each witness in the case in the judgment is of no use. The evidence should be
discussed and evaluated. Corroboration and contradiction of material facts must necessarily be
commented and reasons for believing or disbelieving the evidence must be stated and the findings
on the points requiring decision must be recorded. It is of vital importance that the judgment must
be temperate and sober. Commenting on the conduct of the parties should not go beyond what is
really necessary. Damaging remarks against a witness should not be made without trustworthy
proof of the record. Remarks prejudicial to the character of a person who is neither a party nor
witness in the case should be wholly avoided. While coming to a decision various aspects of the
matter as may present themselves should be fully discussed.Just as it is the duty of a Criminal Court
to get to the bottom of a case and see that every scrap of relevant evidence is brought before it so
that justice be done, so also it is its duty to test the entire material and the various theories set up
and points raised fully and satisfactorily and reach its conclusion. Each point should be dealt with
fully before the other is taken up. Findings on the points must be precise and clear. The question of
sentence should then be considered and appropriate sentence should be awarded.Thus, theCriminal Rules of Practice and Circular Orders, 1990

judgment must be comprehensive enough to cover all the aspects in the manner described above.
Sometimes the Magistrates, before considering whether the prosecution has made out its case,
proceed indiscreetly to comment on the witnesses for the defence and discuss the incredibility of the
defence witnesses to declare the case of the accused as untrue. On that basis they accept the case set
up by the prosecution as true. This approach is wholly wrong and is fraught with grave
consequences. The legal presumption about the accused is that he is innocent till the guilt is brought
home to him by positive and credible evidence. The onus of proving all that is necessary for the
establishment of guilt is wholly on the prosecution.If the prosecution evidence is doubtful or
unsatisfactory, it cannot gain any strength from the weakness in the defence case as it should stand
or fall on its own strength. If the guilt is not proved beyond reasonable doubt on the basis of the
prosecution evidence, the accused is entitled to benefit of doubt and consequent acquittal. The
defence evidence has to be discussed only if the prosecution has discharged the onus of proving the
guilt and not otherwise. Of course, if the accused pleads the right of private defence or any other
general or special exceptions under the Penal Law and the facts alleged by the prosecution are not
disputed, it may not be necessary to discuss at length the prosecution evidence first. It will be
sufficient to set out the main features of the prosecution case and take up the evidence for the
defence. It should be noted that the standard of proof as required of the accused is not the same as
that of the prosecution. He need not prove his defence beyond reasonable doubt. It is sufficient if
there is preponderance of probability in his favour. Further, even through he might not have
established his case quite satisfactorily, should the Court on a reading of the evidence on record as a
whole i.e., of the prosecution together with the defence evidence, has reason to believe that there
may be truth in what the accused says, the accused is entitled to acquittal.The judgment, therefore
in cases like these must contain full discussion from this point of view.In connection with the
judgment it must always be remembered that what is of essence is not the mere Form or
composition of judgment but its quality. A judgment of quality postulates indeed sound knowledge
of law and of rules of evidence. But that alone may not be sufficient. What is of vital importance and
an essential requirement in judgments in criminal proceedings is the natural and acquired
shrewdness and experience by which a Judge has to Form his opinion as to whether a witness is or is
not lying. The rules of evidence may provide tests as to the quality of materials on which the
judgment may proceed without any obvious objection. But they do not profess to enable the Judge
to know whether a witness is telling the truth and what inference should be drawn from particular
facts. That must depend on the natural sagacity, logical power and practical experience of the
Presiding Officer and this, however, has to be developed to its full measure within one's capacity to
ensure satisfactory results. As this aspect is closely allied with the question of appreciation of
evidence, it is appropriate that it may be dealt with in the relevant chapter.Something, however,
must need be said also as to the necessity of having a good command of law and of legal principles
and requisite ability of correct application thereof to the facts of the case as that contributes a good
deal to the quality of judgment. A thorough knowledge of substantive and procedural law is
imperative for a good judgment Its right application to the facts is no less important. Obviously
enough, unless the Presiding Officer is sure of law before he proceeds to apply it to the facts, he
cannot hope to reach correct results. An element of slight approximation in facts will not do so much
harm as uncertainty in law. The knowledge of law has to be exactly right The exactitude demanded
is one of mathematical precision. Any flaw in the understanding of law will upset the whole
judgment It may be remembered that a Magistrate combines in himself the dual capacity of a JudgeCriminal Rules of Practice and Circular Orders, 1990

of facts and of law. He has, therefore, to be careful in relation to both the aspects.As regards the
facts, he has to be alert from the outset when he starts recording evidence and has to Form his own
impressions as the case progresses and finalise his opinion at the end. At every stage he has to apply
his commonsense and knowledge of men and matters to judge the questions of facts involved.He has
also to bear well in mind the substantive and procedural laws and rules of evidence while dealing
with cases before him. He has, of course, to be fully conversant with statute law. So also he has to be
familiar with the case law on the subject But the basic legal principles have to be necessarily
assimilated by him. Or else it will not be possible for him to proceed further and discharge his
functions efficiently. Besides, time and again, he has to refer to Sections of the law and study them
very carefully. Commentaries will be helpful but he should know how to use them. Whether at the
time of framing charge or awarding punishment he should keep the relevant Sections always in view
to avoid possible mistake and should in no circumstances exclusively rely on memory. While
referring to the relevant rulings he must not be merely guided by headlines or headnotes. He should
go through the entire rulings carefully and have an analysis of the same so that he may be sure of the
true scope and correct application thereof.There may be a few other precautions which the
Magistrate should take to impart fullness and soundness to his judgment. It is not necessary to
dilate on this aspect any further as any amount of instruction given cannot be exhaustive and much
depends on the natural capabilities of the Presiding Officer.I may, however, invite attention to the
following general principles which will be of immense help to the Courts while dealing with the guilt
or innocence of the accused:(1)The onus of proving everything essential for the establishment of the
charge against the accused lies on the prosecution.(2)The decision of the case must rest on legal
grounds based on legal testimony or evidence, both oral and documentary; but never on speculative
theory or upon suppositions or mere suspicions created by the circumstances in the evidence.(3)The
evidence to justify conviction should be such as to exclude to moral certainty every reasonable doubt
as to the guilt of the accused. In case of doubt it is always safer to acquit than to condemn. Indeed
the accused, in law, is always entitled to benefit of doubt.(4)While coming to the conclusion as to the
guilt or innocence of the accused, the Court should take the following circumstances into
consideration;(a)The circumstances in which the offence is said to have been committed.(b)The
motive for the offence or false accusation.(c)The consistency of the story told by the prosecution, its
probability or plausibility.(d)The nature of evidence on behalf of the prosecution.(e)Its
credibility.(f)The character, position and independence of the witnesses.(g)How far their testimony
is consistent with itself and conforms to experience and accords with collateral
circumstances.(h)Exaggeration and discrepancies in their statement; their cause and effect together
with the explanation as offered by the witnesses or the counsel of the parties.(i)The reasons for
accepting or rejecting any portion of the statements ; its effect on the testimony.(j)The value of
confession, if any.(k)The examination of the accused explaining the facts in the evidence against
him.(l)The evidence adduced in support of the defence theory.As regards the recording of findings it
is necessary that in the judgments findings on all charges must be clearly given. They should be
recorded in distinct and definite terms so as to afford no room for doubt as to what they are and no
scope for dispute that on the findings, no offence has been committed. Where there are several
accused, the case of each accused should be dealt with in sufficient detail and the decision with
regard to each with reasons therefor should be given. The names of the accused should be set out in
the judgment In cases of conviction, as already stated, the judgment must specify the offence of
which and the sections of the law under which the accused is convicted and also the punishmentCriminal Rules of Practice and Circular Orders, 1990

inflicted under each. In case the previous convictions are relevant and have been proved, they
should be duly stated with the details of dates, and extent of punishment The reasons for the
particular punishment also must be stated. If the conviction is under the Indian Penal Code and it is
doubtful under which of the two sections or under which of two parts of the same section of the
Code the offence falls, the Court must distinctly express the same, and pass judgment in the
alternative. If the judgment is one of acquittal, the judgment shall state the offence of which the
accused is acquitted.These in short are the various features which require mention in connection
with the judgments in criminal cases. It must be remembered that the purpose of instructions is
merely to provide some guidelines. It must all depend upon the originality and accomplishments of
the Presiding Officer to make his judgments not only thorough and interesting but also highly
satisfactory and convincing.Appreciation Of EvidenceIn order to arrive at a just conclusion with
regard to the guilt or innocence of the accused, the evidence on record has to be properly and
carefully weighed and valued. The evidence adduced may be direct or circumstantial It may present
a true picture or a false or distorted one. If it is circumstantial, the chain of circumstances may not
be quite complete to connect the accused. The oral evidence may be biased, interested, exaggerated,
purchased, perjured, tutored etc. In order to give any weight or value to the evidence, its true nature
has first to be appreciated. But, dependent as the oral evidence is, on the variable and inconsistent
factors such as human nature, the appreciation thereof can be reduced to a set of Formulae. There
can be no can on either for weighing evidence or drawing inference therefrom. Much must depend
upon the Presiding Officer's commonsense, knowledge and experience of men and matters as each
case presents its own peculiarities. Conflicting versions with seeming realities make the task of
appreciation of evidence all the more difficult The power of judgment is put to hard test The
Presiding Officer has to bring to bear on facts elicited a fair amount of common sense, shrewdness,
his knowledge and experience, taking into consideration at the same time the ordinary course of
events and human conduct The correct position would be, while considering the evidence he should
put to himself whether he, as a reasonable person is convinced that the evidence he has heard
satisfies beyond reasonable doubt that what is said to have taken place has really occurred in that
manner. This matter is not of a simple nature and mistakes committed in this direction entail
serious consequences. It is noticed that sometimes accused are acquitted on what we may call flimsy
or inconsequential grounds while on other occasions conviction are based on material which does
not justify convictions at all. Acquittal in most of the cases is based on an erroneous impression and
application of the rule of benefit of doubt It is not every contradiction or discrepancy however
inconsequential, in the testimony, that should raise a doubt warranting acquittal One has to bear in
mind that men's powers of observation and expression vary and an account given by two or more
witnesses equally truthful may be discrepant yet sufficiently accurate. Care must, therefore, be taken
in sifting the evidence. The story, if found truthful otherwise, should not be brushed aside by reason
of a slight discrepancy or defect which is explicable. Fiat Justitia should be the motto of the Court
and discovery of truth should be attempted with the help of the evidence adduced. It will be wrong
to decline to make such an attempt on the plea of discrepancies which may be the product of natural
imperfections of human nature. It should be remembered that letting off the guilty without
punishment is as much shocking to the public conscience as punishing the accused despite the
absence of legal grounds based on legal testimony. Most of such evils follow in the wake of
misappreciation of or inability to appreciate evidence by reason of inexperience or ill-equipment of
law. Of course, mathematical precision cannot be claimed in matters like these. But reasonablenessCriminal Rules of Practice and Circular Orders, 1990

of view must at all events be ensured by correct approach to the subject In this behalf the following
guiding principles may be of great help to the Presiding Officers in achieving that object: -(i)The
Standard of Proof in Criminal Cases is not the same as in the Civil.In criminal cases as life and
liberty of the accused are involved, a strict standard of proof is required as to the guilt of the
accused. It is not the preponderance of probabilities that establishes the guilt of the accused. It is
necessary that the evidence on record must prove it beyond reasonable doubt A conviction cannot be
based on the consideration that the prosecution story may be true. The accused can only be
convicted if the Court reaches the conclusion that the prosecution story must be true. Considered as
a whole the prosecution story may appear to be true but between "may be true" and "must be true"
there is a long distance and the whole of this distance has to be covered by legal, reliable and
unimpeachable evidence. (See Sarwan Singh Rattan Singh vs. State of Punjab: A.I.R. 1957 S.C.637;
In re Shivabasappa Rayyappa Channali A.I.R. 1959 Mysore 47.) If the evidence on record establishes
the truth of the charge and satisfies the reason and judgment of the Court such evidence must be
taken to have proved the charge beyond reasonable doubt justifying conviction.The law always
requires that the conviction should be certain and not doubtfuL Otherwise, no man can be safe. The
burden of proving the guilt of the accused is upon the prosecution. Upon such proof as is adduced, if
there is a real and reasonable doubt as to his guilt, the accused is entitled to the benefit of the same.
The defence evidence does not come up for consideration at all as the prosecution has not
discharged its onus. If the prosecution story is weak it cannot gain strength from the weakness of the
defence evidence. It should stand by itself.Then again, where the circumstances of a case point to the
conclusion that the accused committed the offence but at the same time there is also a reasonable
probability raised by the state of evidence which is compatible with his innocence, there is no
justification for the conviction of the accused. The accused must be acquitted.But where the burden
of proof relating to an issue in a case is on the accused, the standard of proof required of him is not
the same as is required from the prosecution. The accused need not establish his case beyond
reasonable doubt. It is enough if he shows that the preponderance of probability is in favour of his
case. What is thus required of him is the standard of proof required in civil cases. (See V.C. Jhingon
vs. State of U.P. 1966 S.C. 1762). Thus where the accused person claims exemption under a general
exception or a special exception under the Penal Law it will be sufficient if he succeeds in proving
preponderance of probabilities. (See: Harbhajan Singh vs. State of Punjab) (1966 S.C. 97). In fact, in
case he pleads right of private defence, even if the evidence read as a whole, both of the prosecution
and the defence, leaves the Court in doubt that the circumstances are such that the accused may
have a right of private defence, the accused is entitled to that benefit of doubt.(ii)Extraneous factors
and elements must always be kept out of mind while judging or determining the guilt.The
determination of guilt must be based on legal evidence brought on record and not on outside
material. The position of the accused in public life, his status or rank, the interest which the general
public takes in the case, the publicity which the case is receiving in the local press or the sensation or
stir if may have caused all these are definitely elements which are extraneous to the case and should
never be allowed to affect the judgment of the Court in any manner. (See: Palvinder Kaur vs. State of
Punjab A.I.R. 1952 S.C. 354).Likewise the Magistrate should never import his own knowledge of
facts or of the character of the witnesses into the case nor refer to matters which come to his
knowledge from other sources. Personal impressions should not find place in judicial orders. He
should not be moved by hearsay evidence either and should not allow it to be brought on
record.(iii)Evidence should be weighed but not counted.Section 134 of the Evidence Act enacts thatCriminal Rules of Practice and Circular Orders, 1990

no particular number of witnesses is required for proof of any fact. The evidence of witnesses indeed
has to be weighed and tested whatever their numerical strength be. The conscience of the Court
should be satisfied as to the guilt of the person before he can be convicted. It is the probative force
and the value of the evidence and not the sheer numerical strength of the witnesses which
determines the guilt of any accused. If the case against the accused rests on the evidence only of a
single witness to the crime and his testimony is entitled to full credit, that evidence would be
sufficient to sustain a conviction. The question of corroborative evidence would not then arise at all.
Thus, the evidence of a single witness would in law warrant conviction if it is true and above
reproach or suspicion and does not suffer from any infirmity or taint (See Vadivelu Thevar vs. State
of Madras: A.I.R. 1957 S.C. 614).The same principles which apply to proof apply equally to disproof,
and even as guilt of an accused may be proved by a single witness; his innocence also may be
accepted on the testimony of a single reliable witness even though a number of other witnesses not
so reliable may have testified to his guilt.(iv)Evidence must conform to ordinary human conduct,
natural course of events and probabilities of the transaction.The object of hearing evidence is to
enable the Court to Form its belief in the truth or otherwise of the alleged occurrence and of the guilt
of the accused. This, it has to do by evaluating or correlating the various facts in the evidence on
which the proof of guilt is made to rest The occurrence and the commission thereof by the accused
are the two essential facts the truth whereof is to be discovered. The discovery of any fact can be had
either by direct perception or by inference. The Courts have, of necessity, to infer the truth or
otherwise from the testimony of the persons who are said to have knowledge thereof by direct
perception. But whether their testimony is worthy of acceptance has to be judged, regard being had
to the circumstances under which they observed, the state of their observation, whether casual,
disturbed or distracted, their power of observance, the elasticity of their impressions, facility of
description and possible lapse of memory. Allowance also must be made for possible distortion of
the story and even lying. In order to ensure that the testimony accords with facts or contains the
whole truth it has to be necessarily subjected to scrutiny. It is capable of being tested as there is
cosmos and not chaos in the universe of facts. All the facts of the Universe are consistent with one
another. There is order, regularity and system in the interrelation of facts. There is, indeed, a logical
sequence in them as of cause and effect Their interrelationship is so close that one fact can be traced
out with the help of the other. It is, therefore, possible to reach the truth by process of reasoning on
the strength of the facts known which have logical connection therewith. Inference or reasoning to
lead us to truth must of course proceed on facts which can be believed to be true. Belief can be
engendered only if the said facts accord with reason and commonsense. The Court, therefore, while
judging the testimony or evidence before it, has to necessarily examine whether it is consistent with
itself, conforms to the ordinary course of human conduct, the natural course of events and
probabilities of the transaction. Of course, in this task effective cross-examination by the party may
help the Court a good deal. But absence of such cross-examination does not relieve the Court from
its duty to test the evidence. The Court has to undertake its task even though the witnesses are not
effectively cross-examined by the party or his counsel, It cannot, in this behalf, afford to act
mechanically. It has to subject the evidence to strict scrutiny. In weighing and evaluating the
evidence, the Presiding Officers are bound to call in aid their knowledge and experience of life in
discovering the truth. (See: Chaturbanj Pande vs. Collector, Raigarh A.I.R. 1969 S.C. 255 at page
257).The evidence of a witness shall be regarded with suspicion if it does not accord with the
probabilities of the transaction to which he deposes. It should certainly be rejected when it is notCriminal Rules of Practice and Circular Orders, 1990

consistent with itself nor conforms to the natural course of events, or ordinary human conduct. This
principle in the appreciation of evidence is of paramount importance.(v)In judging the credibility of
the witnesses, the demeanour of witnesses, their position, character and antecedents also are to be
taken into consideration.In judging the truth or falsehood of the testimony of witnesses; regard
must also be had to the factors, such as, the demeanour of witnesses, their position, character and
antecedents and their possible and probable motive for giving evidence. The demeanour of a witness
under examination, if minutely and skilfully observed, would give an important clue to the nature of
his evidence.Indeed Section 280 of the Criminal Procedure Code, 1973, casts a duty on a Sessions
Judge or Magistrate to record such remarks (if any) as he thinks material respecting the demeanour
of any witness whilst under examination. The Code thus attaches significance to anything discovered
worthy of note in the demeanour and takes care that such impressions are protected from fading
away so that the Courts may be in a position to eventually act upon them. By making a notice of the
demeanour, the trial Court keeps the impression fresh in its memory. The appellate Court also will
not miss this important feature in estimating the value of the evidence by reason of the record. Of
course, the remarks contemplated are remarks in relation to unfrank, suppressive and evasive
replies of the witness or as to other demeanour in the manner of his speech or otherwise, which has
a bearing on the question how far his evidence can inspire confidence. The Presiding Officer,
however, has to be cautious in making remarks or judging the credibility of the witness on the basis
thereof. Before he can make use of them he has to certainly make considerable allowance for the
unaccustomed situation in which the witness is placed and the impressions which such a situation
are calculated to make upon his mind. Certain particular features noticed may as well spring from
the state of agitation and embarrassment under a searching cross-examination or novelty of the
position in which the witness is placed or his constitutional nervousness. Nevertheless if the
demeanour is minutely and skilfully observed, the eye, the tone, the voice and the mouth may reflect
the state of his mind and will give a valuable clue to a skillful observer to come to the conclusion
whether he can be said to be a witness of truth or not If while making a statement he takes him to
think about the materiality of his evidence and the effect that his answer will produce on the case or
gives an evasive reply or answers a question put to him with great hesitation, the evidence that he
gives may ordinarily be open to much suspicion. The Magistrate however has to be very cautious in
noting his demeanour in drawing an adverse inference against his bona fides.It is not unusual that
uneducated witnesses or those who are not accustomed to the ways of the Court do in their
confusion of thought create discrepancies under a severe test of cross-examination. But on that
account their story, if honest and substantially true, should not be rejected. The demeanour, though
of great importance, has to be closely, carefully and critically watched and the conclusion on the
basis thereof must be reached with due caution. Further, it is not only the demeanour of a witness
but also his position, character and antecedents and his probable motive for giving evidence which
are also to be taken into consideration. After all, the question of credibility of the witness comes for
consideration only at the end when the Presiding Officer takes the overall picture and judges the
evidence in that light.(vi)The testimony of partisan or interested witnesses or relatives cannot be
discredited merely by reason of that character. What principles should be kept in view in judging the
testimony of such witnesses.Evidence given by witnesses should not be discarded merely on the
ground that it is evidence of relations or partisan or interested witnesses. Where offences are
committed in residential houses, the witnesses to the offences generally are relations and servants.
When factions prevail in villages where offences are committed, evidence available may be largely ofCriminal Rules of Practice and Circular Orders, 1990

partisan or interested witnesses. The testimony of these witnesses cannot be mechanically rejected
on the mere basis of interestedness. Such a rejection is calculated to result in failure of justice. Their
interestedness may render their testimony open to strict scrutiny; but interestedness by itself is not
a good cause for rejecting or brushing aside their testimony. It may be rejected when the witnesses
are discredited as regards their good faith and honesty or their evidence otherwise does not bear
scrutiny. The Court has, therefore, to be careful in weighing such evidence and see whether or not
their evidence is discrepant, whether the story disclosed by this evidence is probable, whether their
testimony appeals to reason and commonsense and appears to be true. In short, the evidence is to
be judged taking into account all matters which the Court has to keep in view for testing the
evidence and the testimony should be accepted, or rejected consequently. Vide Masalti vs. State of
U.P.(A.I.R. 1965 S.C.202).Again the witnesses coming under the description of interested witnesses
may have further traits.A person may be interested in a victim as being either his relative or his
friend; but he may not share with the victim hostility against he assailants.If the relationship of the
witness with the victim is close enough and friendship is very intimate, all that the Court should do
is, be careful to note is whether his testimony bears strict scrutiny. The witness cannot, at any rate,
be discredited on the ground of mere interestedness. The Court must consider whether the witness
is a chance witness or can be accepted as being present at the scene of offence. Further, if there is no
reason to disbelieve the truth of the account given by him, there is no reason why his statement
should not be acted upon.Even where the witness, besides being a relative or friend of the victim,
shares the hostility of the victim against the assailant, on principle it is difficult to accept the plea
that his evidence can never be accepted unless it is corroborated in material particulars. See Dayra
Singh vs. The State of Punjab A.I.R. 1965 S.C. 328.The testimony of the mother or a near relative of
a girl against whom an offence of rape is committed, cannot be discounted dubbing it as interested
evidence. In the absence of sufficient circumstances or motive for giving false evidence, such as
enmity, ill will or grudge against the accused the testimony of such a witness should be judged on
the same footing as that of an independent witness. Even where, in the circumstances of the case,
some corroboration is required, if the girl against whom the offence is committed has complained to
such a witness, her evidence is sufficient corroboration. See: Rameswar Kalyan Singh vs. State of
Rajasthan A.I.R. 1952 S.C. 54.A witness is normally to be considered as independent unless he is
traceable to a source which is likely to be tainted and a witness is to be considered to be tainted only
if he has been shown to have a reason or motive for implicating the accused falsely, such as, enmity
or grudge. Ordinarily, a close relative of the victim would be the last person to screen the real culprit
and falsely incriminate an innocent person, and the mere fact of relationship, far from being a
ground for suspicion, is often a guarantee of truth. There is no rule of prudence that a relative's
evidence requires corroboration, and the fallacy often noticed that there is any such should be
clearly dispelled. However, Courts must carefully see that out of feelings of relationship, innocent
persons are not roped in. Each case must be judged on its own facts. (See Dalip Singh vs. State of
Punjab (A.I.R. 1953 S.C.364).Partisan witnesses: - In factious cases the names of the innocents are
not unoften tacked on to the really guilty ones. It is therefore, necessary that in such cases the Judge
should scrutinise the evidence of partisan witnesses with particular care to exclude the danger that
out of spite or enmity all the important members of the opposite faction are implicated so as to
destroy them root and branch. It is important that evidence of such partisan witnesses be
scrutinised with more than ordinary care and in particular sweeping statements and wholesale
implications should be received with utmost caution.The above principles are well settled. TheCriminal Rules of Practice and Circular Orders, 1990

Courts would do well to keep in view the following points relating to appreciation of evidence, while
considering the evidence of interested witnesses or relatives :-
1. The testimony of a close relative cannot be discarded merely because of
relationship. In fact, his evidence in a large number of cases would be very
material, for a close relative would be the last person to screen the real
culprit and falsely implicate an innocent person. The mere fact of
relationship, far from being a ground of suspicion or the foundation of
criticism of evidence, is thus often a sure guarantee of truth. It is not a
general rule of prudence to require corroboration before such evidence is
believed. Of course, if the culprits are more than one, rule of prudence may in
certain circumstances require corroboration. It must all depend upon the
particular circumstances of each case and the degree of confidence inspired
by the statement of the witness.
(2)A person may be interested in the victim being his relation or otherwise and may not necessarily
be hostile to the accused. In that case, the fact that the witness was related to the victim or was his
friend may not necessarily be a ground to subject the statement of the witness to more than ordinary
scrutiny.(3)(a)Where the witness is a close relation of the victim and is shown to share the victim's
hostility against his assailant, that naturally would impel the Court to put the evidence to strict
scrutiny before deciding to act upon it. In dealing with such evidence, the Courts will have to
ascertain whether such witnesses are chance witnesses and whether their testimony, having regard
to its nature, consistency with itself and conformity with the other circumstances of the case,
appeals to reason or commonsense and should be accepted as correct, or is fairly corroborated by
other evidence.(b)It must always be remembered that interested witnesses are not necessarily liars.
Their testimony cannot be rejected and must be acted upon if it bears scrutiny. Their statement may,
however, having regard to the circumstances of the case, be judged with care taking into account the
possible bias.(c)The testimony of partisan witnesses in factious cases must be scrutinised with more
than ordinary care and accepted with due caution.(4)It is not the rule that if a witness is shown to be
a relative of the victim and it is also shown that he shares the hostility of the victim towards the
assailant, his evidence can never be accepted unless it is corroborated on material particulars. All
that can be said is that his testimony should be accepted if it bears scrutiny and the conscience of the
Court is satisfied that it is true.(vii)The Rule of Best Evidence should never escape one's attention in
evaluating evidence.In attaching weight and value to the evidence the Court should also see why the
best evidence which could be produced by the Prosecution was not so produced. Where, for instance
'A' a respectable man of the village who was present when the occurrence took place, is not produced
but instead two labourers living at a distance from the place of occurrence are produced, the Court
should view their evidence with suspicion unless good reasons are given for not producing 'A' and
there are other circumstances to believe the testimony of the labourers. It goes much to the discredit
of a party if good evidence which is worthy of credit is kept back and not produced. But if the best
evidence has not been produced it does not mean that the other evidence admissible in law should
be rejected forthwith. As observed above, the Court has still to consider the weight and the legalCriminal Rules of Practice and Circular Orders, 1990

effect of the witnesses produced in the case.(viii)The evidence of child witnesses should be accepted
with due care.The competence of a witness is determined by Section 118 of the Evidence Act
According to the said section, every person is competent to give evidence, except when the Court
considers that he or she is unable to understand the questions put to him or her, or give rational
answers. Such incompetency may arise from causes like tender years, old age, disease, etc.The
proviso to Section 5 of the Oaths Act prescribes that when a witness is a child under 12 years of age
and the Court considers that though he understands the duty of speaking the truth, he does not
understand what oath means, the Court may dispense with the administration of oath. But the
Judge should always, when dispensing with an oath, make a clear record that he was satisfied that
the child understands the duty to speak the truth and should also state his reason for thinking so.
(See Rameshwar Kalyan Singh vs. State of Rajasthan 1952 S.C.54.)Although the unworn testimony
of a child is admissible, it must be received with great caution. Children of tender age, generally
speaking, are pliable and their evidence can easily be shaped and moulded. They can be made to
repeat glibly a story put into their mind. They do not possess the discretion to distinguish between
what they have witnessed and what they have heard. It is therefore desirable that absolute reliance
should not be placed on the evidence of a solitary child witness. One should look for corroboration
of the same from other circumstances in the case. The tender years of the child, coupled with other
circumstances appearing in the case, for example its demeanour, unlikelihood of tutoring and so
forth, may render corroboration unnecessary. But that is a question of fact in every case. If, after
carefully scrutinising the evidence, the Court comes to the conclusion that there is a great impress of
truth in it, there is no bar in law in the way of accepting the evidence of a child witness. The Court
should look for corroboration as a matter of caution and not as a rule of law. That is the guiding
principle in appreciation of evidence of a child witness. There is no law which says that the evidence
of a child witness should not be accepted unless it is corroborated. But the rule of prudence requires
corroboration. (See Mohammed Sugal Esa vs. The King. 1946 P.C.3).(ix)Evidence of Accomplice
requires corroboration for conviction.Section 133 of the Evidence Act provides that "An accomplice
shall be a competent witness against an accused person; and a conviction is not illegal merely
because it proceeds upon the uncorroborated testimony of an accomplice."The provision thus places
no limitation on the acceptance of the testimony of an accomplice against the accused on the ground
that he is an accomplice. It does not impose any condition or correlation for purposes of
conviction.But illustration (b) under Section114 of the Act says that the Court may presume that an
accomplice is unworthy of credit, unless he is corroborated in material particulars. It follows that
notwithstanding that an accomplice is a competent witness against the accused, his testimony is
inherently of a tainted nature and by itself it is not sufficient to sustain a conviction. Of course, it is
legal evidence. It can be relied upon in proof of the guilt of the accused if it is worthy of credit but
conviction can follow if it finds corroboration from other evidence. To sustain conviction it should
thus satisfy two tests:(1)The version must be a reliable account which means that there is nothing
inherently improbable in the story.(2)There must be sufficient corroboration of his evidence before
it is accepted or acted upon.(See Piara Singh vs. The State of Punjab, 1969 SC 961Sarvan Singh vs.
The State of Punjab, 1957 SC 637Lachhiram vs. The State of Punjab, 1967 SC 792, andSeshanna vs.
State of Maharashtra, 1970 SC 1330 at 1333).The nature and extent of corroboration that the Court
should look to depends upon the facts and circumstances of each case. It is not possible to
Formulate any rules. However, the following principles are well established:(a)Corroboration must
be from an independent source.(b)Corroboration need not be by direct evidence. It is sufficientCriminal Rules of Practice and Circular Orders, 1990

eventhough it is circumstantial in nature.(c)Corroboration is required on material particulars and
not confirmation of every detail deposed to by the approver.(See, Bhiva Doulu Patel vs. State of
Maharashtra, 1963 SC 599 and Sarvan Singh vs. State of Punjab. 1957 SC 637).(d)Corroboration
required to the extent stated in both as to the commission of offence and identity of the accused or
each one of the accused (as the case may be) as actual participants in the Crime.(x)Nature and
extent of corroboration wherever it is required by law should always be kept in mind.In all cases
where corroboration is required, the nature and extent of corroboration that the Court should look
to must necessarily vary with the circumstances of each case and also according to the particular
circumstances of the offence charged. There can, therefore, be no set Formula which may be of
universal application. However, there are certain guiding principles which will be of great help to
the Presiding Officer in this behalf. These principles have been succinctly laid down in King vs.
Baskerville, 1916(2) KB. 658 which is the locus classicus on the subject.One of the important
principles according to it is that wherever corroboration is required, what should be looked into is
not independent corroboration of every circumstances in the sense that there should be independent
evidence which by itself de hors the testimony of the complainant or the accomplice be sufficient to
sustain conviction. As Lord Reading says: -"Indeed, if it were required that the accomplice should be
confirmed in every detail of the crime, his evidence would not be essential to the case, it would be
merely confirmatory of other and independent testimony".All that is required is that there must be
"some additional evidence rendering it probable that the story of the accomplice (or complainant) is
true and that it is reasonably safe to act upon it".The second principle is that the corroborative
evidence must not only make it safe to believe that the crime was committed but also must in some
way reasonably connect or tend to connect the accused with it by confirming in some material
particular the testimony of the accomplice or complainant that the accused had committed the
crime. This does not, however, mean that the corroboration as to identity must extend to all the
circumstances necessary to identify the accused with the offence. It is nevertheless essential that
there should be independent evidence which will make it reasonably safe in believe the witness's
story that the accused was the one among those who committed the offence. The reason for this part
of the rule is that "a man who has been guilty of a crime himself will always be able to relate the facts
of the case, and if the confirmation be only on the truth of that history, without indentifying the
persons, that is really no corroboration at all. It would not at all tend to show that the party accused
participated in it."The third principle is that the corroboration must come from independent sources
or sources other than tainted. Ordinarily, therefore, the testimony of one accomplice would not be
sufficient to corroborate that of another. But of course, the circumstances may be such as to make it
safe to dispense with the necessity of corroboration and in those special circumstances a conviction
would not be illegal.The fourth principle is that the corroboration need not be by direct evidence
that the accused committed the crime. It is sufficient even if it is circumstantial evidence as to his
connection with the crime. Were it otherwise "many crimes which are usually committed in secret,
such as incest, offences with females (or unnatural offences) could never be brought to justice".The
above rules were approved or followed in Rameshwar Kalyan Singh as. State of Rajasthan (1952 SC
54). Sidheshwar Ganguly vs. State of West Bengal (AIR 7958 SC 143) and Major E.G. Barsay vs.
State of Bombay (1961 SC 1762).(xi)Former statement of a witness may be used as corroboration of
his testimony.The previous statement of a witness may be corroboration of the evidence of the
witness. Illustration (j) under Section 8 of the Indian Evidence Act reads as follows: -"The question
is whether A was ravished. The fact that shortly after the alleged rape, she made a complaint relatingCriminal Rules of Practice and Circular Orders, 1990

to the crime, the circumstances under which, and the terms in which the complaint was made are
relevant".Thus the previous statement of a female who is ravished is admissible under Section 8 of
the Indian Evidence Act by way of the conduct of the party. The question is whether such a
statement may be proved to corroborate the subsequent testimony as to the same fact. In this regard
Section 157 of the Indian Evidence Act reads thus:"In order to corroborate the testimony of a
witness, any Former statement made by such witness relating to the same fact, at or about the time
when the fact took place or before any authority legally competent to investigate the fact, may be
proved".Thus according to this section any Former statement made by a witness may be proved to
corroborate his testimony provided the conditions laid down therein are satisfied. One of the
conditions is that the Former statement must have been made 'at or about the time' when the fact
took place. At or about the time' would mean as early as can reasonably be expected in the
circumstances of each case. See: Rameshwar Kalyan Singh vs. State of Rajasthan 1952 SC 54. In that
case, a girl who was raped told her mother about the incident about 4 hours after it occurred. The
reason for the delay was that the mother was not at home when the girl went there. When the girl
went home, she lay down and went to sleep and when her mother returned from the field at about 4
p.m. she told her mother what had happened. It was held in that case that the Former statement of
the girl was made at or about the time when the fact took place.(xii)The Probative Value of evidence
of the complainant or the prosecutrix in sexual offences.A women who has been raped is not an
accomplice. She is the victim of an outrage. If the woman gave her consent, there is no offence
unless she 1 happens to be a married woman in which case consequences of adultery may follow. In
the case of a girl below the age of consent, her consent will not matter so far as the offence of rape is
concerned. In all sexual offences, including unnatural offences, the evidence of the complainant or
the prosecutrix has to be treated with caution. Though the complainant or the prosecutrix is not an
accomplice, and though corroboration is not essential before there can be a conviction, the necessity
of corroboration must be present to the mind of the Judge and in the case of trial by Jury there must
be an indication in this charge to the Jury about the necessity of corroboration of such evidence
though such corroboration may be dispensed with in the particular circumstances of a case when it
is safe to do so. When the child on whom the sexual offence is committed is of tender years and has
no opportunity of being tutored having regard to her demeanour, corroboration may be dispensed
with. See: Rameshwar vs. The State of Rajasthan (1952 SC 54) and Sidheswar Ganguly vs. State of
West Bengal (1958 SC 143).(xiii)The value of evidence of trap witnesses in cases relating to
bribery.In cases relating to bribery, sometimes in order to entrap the persons receiving the bribe,
the persons offering the bribe produce currency notes before the police authorities or Executive
Magistrates. After some marks are made on the currency notes, the same are handed over to the
person receiving bribe and he is entrapped and caught. In some cases, the Police Officers and
Executive Magistrates themselves provide such money. The point for consideration is whether the
evidence of the witnesses of the raiding party and the Officer is to be treated as that of
accomplices.The persons who under compulsion offer money to the person receiving bribe cannot
be said to be accomplices. They are in the nature of only partisan or interested witnesses. Their
evidence cannot be rejected on the ground of absence of independent corroboration. Their evidence
has to be judged by the same standard as the evidence of other partisan or interested witnesses.Vide
State of Bihar vs. Basawan Singh (1958 SC 500) Ramanlal vs. State of Bombay (1960 SC 961).The
inexpediency of employing Magistrates as trap witness has been stressed upon in various cases. In
Brannan vs Peek 1947 (2) All E.R. 572 Goddard, C.J. made the following observations: -"I hope theCriminal Rules of Practice and Circular Orders, 1990

day is far distant when it will become a common practice in this country for police officers to be cold
to commit an offence themselves for the purpose of getting evidence against someone".This point
was again stressed upon in Ramjanam Singh vs. The State of Bihar (1956 SC 643 at 651). It was
observed therein thus:"The very best of men have moments of weakness and temptation, and even
the worst, times when they repent of an evil thought and are given an inner strength to set Satan
behind them; and if they do, whether it is because of caution, or because of their better instincts or
because some other has shown them either the futility or the wickedness of wrong doing it behoves
society and the state to protect them and help them in their good resolve, not to place further
temptation in their way and start afresh a train of criminal thought which had been finally set
aside."The inexpediency of employing Magistrates as trap witnesses cannot be resolved into an
inflexible rule that their evidence should be totally rejected in the absence of independent
corroboration. Vide The State of Bihar vs. Basawan Singh (1958 SC 500).(xiv)The value of evidence
of a person seeing the commission of a crime and not giving information of it to anyone else.A man
who sees the perpetration of a crime and does not give information of it to anyone else cannot be
regarded in law as an accomplice. But there can be no doubt that evidence of such a man should be
scanned with much caution and the Court must be fully satisfied that he is a witness of truth
especially when no other person was present at the time to see the crime or murder. Though he is
not an accomplice, the Court would still require corroboration on material particulars as he is the
only witness to the crime and as it would be unsafe to hang the accused on his sole testimony unless
the Court feels convinced that he is speaking the truth. Vide Vemireddy Satyanarayana Reddy vs.
State of Hyderabad (1956 SC 379).(xv)Contradictions and Discrepancies have to be carefully judged.
How far they are material.The duty of the Court is to discover the truth and to find out whether the
accused is guilty or not It has to reach its conclusion in this behalf on the basis of legal testimony or
the evidence brought before it. This evidence may be direct or indirect It may be based on perceived
facts or inferred facts. Facts based on direct observation are perceived facts. What may be inferred
from the facts known by a process of thinking or reasoning are inferred facts.Even the perceived
facts come before or to the knowledge of the Court by way of testimony of persons who say they have
seen them. This testimony cannot be free from certain natural defects. To start with, human
observation itself has its own imperfections. It cannot possibly cover all the particulars of the
incident at one time. It is not therefore free from possibility of mistake. Mistakes again may be of
observation or they may be of description. The version coming before the Court besides cannot be
free from mistakes of memory and what is more of the possibility of careless reporting or deliberate
lying. The amount of confidence which has to be placed on legal testimony based on observation
must, therefore, be judged by references to various factors such as (1) the subject matter, i.e., the
nature of the occurrence, (2) the time of the observation (3) whether the observation was casual or
deliberate (4) the type of mind of the observer, (5) the state of mind at the time, (6) the possibility of
elaboration and distortion of the facts perceived, (7) the length of time that elapsed between the
observation and the recording of testimony (8) the amount of corroboration from other observers,
and (9) whether the testimony is consistent with the probabilities of the transaction.So then, while
considering the testimony, we are obliged to take into account not only the possibilities of mistakes
of observation and mistakes of memory but also the possibilities of careless statement or deliberate
lying. Of course, a thorough and skillful cross-examination should enable the Court to judge the
state of observation and the witness's memory. It may expose any attempt at deliberate falsehood as
well But an inference as to the truth or otherwise of the story told has to be drawn even from out ofCriminal Rules of Practice and Circular Orders, 1990

seeming conflicts, contradictions or discrepancies, found in the testimony occasioned by
cross-examination or otherwise. These contradictions and discrepancies may flow from natural
defects of observation and vagaries of human nature or they may betray that the versions of the
deponents are false or unworthy of credit It all depends upon the nature of the defects and the type
of the witnesses examined. It must be remembered that contradictions and discrepancies are
natural and inevitable in the testimony of even truthful witnesses. There can be discrepancies of
truth as of falsehood. It all depends upon the natural causes thereof. While minor discrepancies
cannot be of any consequence, contradictions in the statement of witnesses cannot be lightly passed
over as they seriously affect the creditability of witnesses. Discrepancies of minor character are
generally those which are attributable to inattention to all the details or the elasticity of human
impressions, men's varied powers of observation and expression. A version given by two persons in
relation to some incident though sufficiently accurate may not be free from discrepancies. It not
possible for any two persons to observe all the minutest details of the occurrence with equal care.
Their power of appreciation or expression also differs. The discrepancies, therefore, both as a result
of inattention to details and due to natural tendency to exaggerate or belittle are but natural and
inevitable. Indeed, the absence of such discrepancies may, in a large number of cases, be
attributable to tutoring. So then "when the evidence is discrepant or exaggerated allowance has to be
made for the idiosyncrasies of the class from which the witnesses are drawn, their powers of
observation, strength of memory and facility of description with a discount for possible bias or
prejudice". (See Taylor on Trial or Cases, Page 86).The discrepancies may sometimes be due to
confusion of thoughts when the witness is subjected to severe test of cross-examination. Such defect
will be more prominent in cases of persons who are not accustomed to the ways of Courts or are
nervous. Certainly these factors have to be borne in mind while evaluating the evidence of the
witnesses. While contradictions on material points cannot be easily ignored as they affect the truth
of the story, not much importance should be attached to the minor discrepancies. These
discrepancies may not be merely in relation to the details of the occurrence but also to the time and
date or day of the occurrence as well.As a matter of fact the time and date as given by most of the
witnesses are approximate and there ought to be great margin for honest error. It is not possible for
the witnesses to give the exact time in relation to each instance of the incident. They may not have
watches with them and even if they have, they may not closely note the same, being wholly absorbed
in the observation of the incident Eventhough they may at times remember the date, when they have
to give their evidence after a long interval, failure of memory in this behalf may be inevitable. They
will not be able to recall the exact date. Indeed it is impossible to expect any witness much less an
illiterate witness to describe the particulars as to time and distance and the movements of persons in
such a scientific detail as to stand the test of calculation. See Nitta Singh vs. State of Punjab (1965
SC. 26 at 30).Where a large number of offenders or victims are involved in an offence, it is often not
possible for the witnesses to describe accurately the part played by each one of the assailants. In
such cases, it is usual to adopt the test that the conviction should be sustained only if it is supported
by two or three or more witnesses who give a consistent account of the incident (See Masalti vs.
State of U.P. 1965 SC. 202).Sometimes illiterate witnesses from villages who are dull witted are
unable to separate in their minds what they saw from what they heard, from the inferences they
themselves draw and from the inferences other persons draw for them. It is due to this inability
certain discrepancies creep in their statements. These discrepancies are to be judged carefully. The
Court has to subject each material contradiction or discrepancy to strict scrutiny and see whether itsCriminal Rules of Practice and Circular Orders, 1990

conscience is satisfied that the witnesses are speaking the truth. The Court has, always, to bear in
mind that the benefit of reasonable doubt has to go to the accused. Where the evidence is conflicting
or where there is an indication that false evidence has been introduced the probability or
improbability of the transaction should be taken into account to arrive at the truth. Of course, the
rejection of certain specific statements of a witness is not necessarily a ground for disbelieving the
whole of his evidence. Where the untruth spoken to, by a witness is merely in embroidery to the
story and is attributable to lack of memory, the whole statement should not be disregarded and an
attempt should be made to disengage the truth from the falsehood. But if it is established that he has
prejudiced himself either with regard to a particular accused or on a major part of the case, that
should be enough to discredit the testimony altogether. (See Sukha vs. State of Rajasthan 1956 SC.
513).Hardly we come across a case where there is not a grain of untruth in the evidence of a witness.
Often the statements of witnesses contain exaggerations, embellishments, and embroideries; but on
that ground alone their evidence cannot be discarded. Truth must be separated from falsehood in
the same manner as chaff should be separated from grain. But where the material portion of the
evidence is not believed, it is wholly unsafe to convict any person on a small piece of evidence that
may possibly be true. Ugar Ahir and others vs. The State of Bihar 1965 SC 277, Nisar Ali vs. The
State of U.P. 1957 SCJ 392: AIR 1957 S.C. 366).If the statement of a few witnesses is not believed
with respect to some of the accused persons, it does not necessarily follow that their evidence should
not be relied on with reference to other accused as well (See Gullusah vs. The State of Bihar, 1968 SC
813). (in the case cited the evidence of witnesses was not accepted in respect of some of the accused
but was relied on against the appellant).Witnesses who retract their statements in the trial Court
should be looked upon as witnesses not above suspicion and their evidence should be regarded with
great caution. Where a witness for the prosecution makes a statement in the trial Court
contradictory to the one before the Inquiry Magistrate or the Police casting a serious doubt about
the case for the Prosecution, there is no guarantee of truth in either of his statements and his
evidence entirely unreliable. (See Madan Mohan Singh vs. State of U.P., AIR 1954 SC
637).Witnesses who kept silent for a long time about the incidents to which they have deposed and
who, moreover, when first questioned by the Police had denied all knowledge of the affair, are not
entitled to have their testimony believed.(xvi)Circumstantial Evidence is of considerable help in
determining the guilt.Circumstantial evidence is sometimes of very great importance. Indeed in
some heinous crimes it is the only evidence available. It provides links in a chain oaf facts which go
to establish the guilt of the accused. Where there is no direct evidence and the proof is made to rest
on circumstantial evidence, the principles which should be kept in view in judging the guilt are as
follows:(1)Each fact and circumstance on which the prosecution relies in support of its cause must
be such as to lead to a reasonable inference about some aspect of the guilt of the accused.(2)Every
such fact or circumstance on which the prosecution relies must be clearly proved beyond
doubt.(3)The chain of proved facts and circumstances must be of such nature as to point, in their
total effect, irresistibly and unmistakably to the only conclusion that the accused is guilty of the
offence. The Chain of evidence must be so far complete as not to leave any reasonable doubt for the
conclusion consistent with the innocence of the accused person. The circumstances should be of a
conclusive nature and tendency and they should be such as to exclude every hypothesis but the one
proposed to be proved. In short, the incriminating facts established must be incapable of
explanation upon any other hypothesis then that of the guilt of the accused. Otherwise the accused
must be given the benefit of doubt. See Anant Chintaman Lagu vs. State of Bombay, AIR 1960 SCCriminal Rules of Practice and Circular Orders, 1990

500 ; Govinda Reddy vs. State of Mysore, AIR 1960 SC 29, Eradu vs. State of Hyderabad, AIR 1965
SC 316; See Charan Singh vs. State of U.P. 1967 SC 520 and See Hanumant Govind Nargundkar vs.
State of M.P., 1952 SC 343.(xvii)The Significance of Evidence of Motive.Motive is the reason which
induces and actuates a man to do a certain act. It is a sense of injury or a long cherished feeling of
resentment which induces a person to commit an offence. Motive is thus no doubt an important
factor and is therefore relevant under Section 8 of the Evidence Act. Existence of adequate motive
for the perpetration of crime is an important factor which strengthens the general body of evidence.
But failure to prove motive cannot outweigh the positive evidence as to the crime. Thus motive,
though an important factor, adequacy or absence of motive may not affect the merits of the case if
there is positive evidence as to the crime which brings home the guilt of the accused.(xviii)The
evidence regarding conduct is relevant. The degree of probative value depends on the particular
circumstances of each case.In some cases the prosecution seeks to establish that the accused when
arrested manifested a great agitation and alarm or that when the accused came to know that the
police machinery is set in motion in relation to the occurrence, he immediately took to flight or that
every since the incident the accused has been absconding.Wills in his Book on Circumstantial
Evidence at page 126 says: -"Men are differently constituted as respects both animals and moral
courage and fear may spring from causes very different from that of conscious guilt ; and every man
is therefore entitled to a candid construction of his words and actions, particularly if placed in
circumstances of great and unexpected difficulty".Mr. Justice Abbot in a trial for murder where
evidence was given of flight, observed in his charge to the Jury, that"a person, however, conscious of
innocence, might not have courage to stand a trial ; but might, although innocent, think it necessary
to consult his safety by flight."It may be a conscious anticipation of punishment for guilt, as the
guilty will always anticipate the consequences ; but at the same time it may possibly be, according to
the frame of mind, merely an inclination to consult his safety by fight rather than stand his trial on
charge so heinous and scandalous as this is".These passages show that the evidence of such a
conduct unless it is traceable to the conscious guilt of the accused is not of much consequence. (See
Khushal Rao vs. State of Bombay, 1958 SC 22). Of course, when there is no sufficient explanation
and the other evidence pointing to the guilt is overwhelming, this conduct adds to the proof of guilt
(See Pritam Singh vs. State of Punjab, 1956 SC 415).(xix)Confession and their valueDeliberate and
voluntary confessions of guilt, if clearly proved, are amongst the most effectual proofs in the law.
That is because it cannot be ordinarily presumed that a rational being will wantonly make
admissions prejudicial to his interests and safety. But in a large variety of cases it is seen that the
confession is retracted at the trial. So then, it falls to the duty of the Court to determine if a
confession is voluntary. The burden will be on the prosecution. If the circumstances in which a
confession was made throw a doubt upon its voluntary character, it must be rejected. If the accused
claims that the confession was induced or coerced, unless the voluntary nature is fully proved, the
confession has no value. The accused is not required to prove his assertion affirmatively. All that
may have to be considered is whether what he says is possible. If there is nothing on record to show
that his assertion is false and, judged from other circumstances, such things can happen and may
have happened in the instant case, that is enough to give the benefit to the accused. (See Nathu vs.
State of U.P. 1956 SC 56 ; Aher Raja Khima vs. State of Saurashtra, 1956 SC 217). If the reasons
given by the accused for withdrawing the confessional statement are palpably false and the
statement is held to be true and voluntary, the question arises, what is the importance and weight to
be attached to the confession, retracted as it stands. If the truth of the confession is established byCriminal Rules of Practice and Circular Orders, 1990

corroboration in material particulars by independent evidence, it can be acted upon. What is
sufficient corroboration for this purpose has to be decided in each case on its own facts and
circumstances. It may, however, be generally stated that where the prosecution by the production of
reliable evidence which is independent of the confession, establishes the truth of certain parts of the
account given in the confession and those parts are so integrally connected with other parts of the
confession, that a prudent Judge would think it reasonable to believe, in view of the established
truth of these parts that what the accused has stated in the confession as regards his own
participation in the crime, is also true, that is sufficient corroboration. (See Nand Kumar vs. State of
Rajasthan, 1962(2) S.C.R. 890.(xx)Extra Judicial Confession.Extra-judicial confession can he
accepted as evidence only if the Court is satisfied that it is both voluntary and true. It must be
received with great caution. The exact words used by the accused should always be ascertained; and
before it is accepted as a piece of evidence justifying a conviction, the Court should satisfy itself on
the following points: -
1. What were the circumstances under which it was made or in what manner
was it obtained?
2. Was the confession made by the accused voluntarily?
3. What was the reason for the accused to have confided in the witness who
proves it and to have made a clean breast of his actions?
4. Did the witness truly understand the sense of what was stated to him, or is
there any room for a mistake or misapprehension?
5. Have the words uttered by the accused been correctly reproduced or is the
witness improving on the statement which was made to him?
6. Has the witness any personal motive to depose falsely against the
accused, or have the police, in their eagerness to prove the commission of a
crime, put up that witness to prove a confession.
(See Ratan Gond vs. State of Bihar, 1959 SC 18; Mulk Raj vs. State of M.P. 1956 SC 902)(xxi)Value to
be attached to confessional statements of co-accused.The confession of a co-accused is not evidence
under Section 3 of the Evidence Act. It is not required to be recorded on oath and it cannot be tested
by cross-examination. First the Court should altogether exclude such confession from consideration.
It must see if there is evidence in the case sufficient to sustain a conviction. If the finding is that
there is not sufficient evidence the matter ends there and a conviction cannot be upheld eventhough
there is in addition a confession by a co-accused. If on the other hand, the Court finds that the other
evidence is of such a nature as to be sufficient to sustain a conviction provided it is believed, the
confession of a co-accused comes into use and can be called in aid for lending assurance to the belief
in that evidence. See Nathu vs. State of U.P. (1956 SC 56).The confession must implicate the makerCriminal Rules of Practice and Circular Orders, 1990

himself substantially to the same extent as his companions in the crime before it can be used against
the accused. See Balbeer Singh vs. State of Punjab (1957 Section 216). Section 30 of the Evidence Act
alone permits the Court to take into considerations the confession of a co-accused against others if it
is made by him affecting himself and some other.The various principles referred to above though by
no means exhaustive will afford sufficient guidance to the Magistrates in particular and all the
Presiding Officers of the Criminal Courts in general in appreciating the oral evidence that may be
adduced in criminal cases. The Courts called upon to decide criminal cases while appreciating
evidence have to take into account the documentary evidence as well. They have to call in aid
sometimes certain presumptions of law. If need be, they have to take judicial notice of certain facts
as well It may be seen that whereas it is manifest that the evidence that may be given in any inquiry
or trial under the mandate of Section 5 of the Evidence Act, is of the existence or non-existence of
every fact is issued and of such other facts as are relevant under the Indian Evidence Act and of no
others, and what are relevant facts have been referred to in Sections 6 to 55 of the said Act, the
method of proof is not merely by way of oral testimony of witnesses. There are other methods as
well One such method which is most common is the documentary proof. The documents may be
public or private. Private documents are other than the Public Documents. (Sections 74 and 75 of
the Indian Evidence Act). Method of proof of Public Documents has been stated in Sections 77 to 79
and the presumptions which have to be raised in relation to certain documents have been
mentioned in some of the subsequent sections. It is necessary that these presumptions should be
kept in mind while judging the evidence. The proof of private documents has to be adduced by
producing the originals, if available. They have to be duly proved by a person who wrote and signed
them (Section 67) and if any such person is dead or cannot be found or denies his handwriting or
signature, they may be proved by ;(a)the evidence of the person who are familiar with this
handwriting or signature.(b)by a comparison of the signature or writing of that person with his
signature or writing which is admitted, or proved to the satisfaction of the Court (Section 77).Thus
even in relation to the documents, oral testimony becomes necessary and the principles of
appreciation of evidence already referred to will apply. It should be further remembered that the
documentary evidence being not prone to lapses of memory may have its special value as against the
oral evidence but that has to be judged in the circumstances the document was executed or brought
into being. This has to be borne in mind while attaching weight and value to the evidence. Under the
Evidence Act, the Court has to take judicial notice of certain facts without calling upon the party to
prove as provided in Sections 56 and 57. Thus the Court would do well to take all these factors into
consideration while appreciating the evidence and coming to its conclusions in criminal
cases.Punishment And Sentence And Considerations In Awarding PunishmentsSections 35 and 39
of Criminal Procedure Code deal with the limits of sentences which various Courts may legally pass.
The Indian Penal Code save, in certain offences where the minimum also is fixed, fixes only the
maximum limits of sentences which may be passed for any offence. The same is the case even with
regard to fines. The legislature thus has, in reason, left the matter of award of adequate sentence,
within the limits prescribed, entirely to the discretion of the Court This discretion has, of course, to
be exercised judicially in accordance with the established principles of reason and justice regard
being had to the nature of the offence, the circumstances in which it is committed, the
circumstances of the accused and the policy and object of law. The question of determination of
proper sentence is not free from difficulty. Indeed its importance cannot be overemphasised when it
is manifest that a disproportionate sentence is likely to excite sympathy of the public for the accusedCriminal Rules of Practice and Circular Orders, 1990

and thus defeat the very object for which it is passed. It removes all chances of reFormation also.
Likewise a light or a ridiculously low sentence is fraught with tendencies to prove a danger to the
public peace. The question of sentence is thus both a difficult and delicate matter. No hard and fast
rule can be laid down being a matter of discretion, guided by a large number of considerations.
Precedents also cannot be a sure guide unless they are based upon any principle of universal
application. Sentence passed by one Judge in relation to the same kind of crime or offence cannot
therefore be a dependable guide. No two cases can be exactly similar in all their aspects. Indeed in a
large variety of cases, there can be wide divergence both in relation to the circumstances in which
the offences were committed and also those of the accused. The Presiding Officer has to fall back on
his good sense and judgement taking into account various considerations while determining the
sentence. The nature and gravity of the offence, the circumstances in which it was committed the
degree of deliberation shown by the accused or provocation received, the age and character of the
accused, his antecedents, the motive for the crime and the manner in which it was committed, etc.,
are all matters which have to be necessarily taken into consideration. Further, all these must be
matters of a record established by evidence and not mere impressions created by the accused on the
Presiding Officer. The aggravating and extenuating circumstances have an important role to play.
The theory and object of punishment and the policy of law are no less significant They have to be
always kept in mind. The avowed objects of punishment are varied and manifold. But mainly and
essentially the object is to ensure the protection of the public against offences to person and
property. As Bentham in his works, Vol. I, page 386, has said:"If we could consider an offence which
has been committed as an insolated fact, the like of which would never recur, punishment would be
useless. It would be adding an evil to another. But when we consider that an unpunishable crime
leaves the path of crime open not only to the same delinquent but also to all those who may have the
same motives and opportunities for entering upon it, we perceive that the punishment inflicted on
the individual becomes a source of security to all".Protection of the public is ensured if prevention of
crime is secured. This object can be achieved in two ways:(1)by imposing punishments sufficient to
deter the accused from repeating the crime and serve as a lesson or warning for others with similar
bent of criminal mind; and (2) by ensuring that the punishment given serves as a reformation for
the offender so that he may become a good citizen and cease to be a threat to the public, Thus the
theory of punishment is based upon (1) the protection of the public; (2) the prevention of crime; (3)
the reFormation of the offender; and (4) corporal suffering for the crime to committed. The
punishment may have a deterrent element also. The concept of deterrent punishment does not take
in the idea of vindictiveness; but intact eschews the same. While deterrent punishment has a
reFormative value, vindictiveness defeats the very object The sentence in each case at any rate
should necessarily bear reasonable proportion to the nature and gravity of the offence and
circumstances of each case. If it is unduly severe or vindictive, it is apt to frustrate the very
purpose.So then, what is to be considered while awarding punishment within permissible limits is
firstly, the gravity of the offence; secondly, the circumstances under which it is committed; thirdly
the circumstances of the accused, and fourthly, the object and policy of law.Nature and gravity of the
offence is the first consideration. The measure of punishment should be determined largely having
regard to the same. Offences against person are certainly of greater magnitude than those against
property, for personal violence spreads a feeling of greater insecurity and terror in the community,
involves the person in more bodily suffering and sometimes the injury caused is irreparable.
Therefore, the Former type of offence warrants a heavier sentence than the latter. At the same time,Criminal Rules of Practice and Circular Orders, 1990

the circumstances under which they were committed are of no less significance in determining the
quantum. The offence may be attended by aggravating circumstances or there may be some
mitigating circumstances. The punishment in both the cases cannot be the same or else the purpose
of punishment will be frustrated.Aggravating circumstances may generally be, as Bentham has put
it:"(1) Deliberate violence especially when it is super added to another crime, viz., robbery and
dacoity in which case the offender justly forfeits all human sympathy.(2)Use of lethal
weapon.(3)Wanton cruelty and malignity.(4)Treachery as when he is inveigled into an ambush and
then murdered.(5)Nature of injury-as where a man is clubbed to death or where he is stabbed with a
knife.(6)Motive which will of course play a most important part "Mitigating circumstances as
mentioned by the same author are:-"(1) Absence of bad
intention.(2)Provocation.(3)Sell-preservation.(4)Preservation of some near friend.(5)Transgression
of the limits of self-defence.(6)Submission to menace.(7)Submission to
authority.(8)Drunkenness.(9)Childhood."The above list cannot be said to be exhaustive.
Aggravating circumstances certainly warrant heavier sentence and the mitigating circumstances
tend towards leniency. Thus the nature and enormity of the offence is a major consideration that
must be primarily kept in view in awarding punishment The measure thereof, of course, may to an
extent be influenced by the other considerations which call for strict or lenient view of the matter.
This depends on the circumstances under which and the manner in which the offence was
committed, the personal circumstances of the offender himself and the object and policy of law.The
offence might have been committed with deliberation and cruelty or it might have been committed
in the supposed exercise of right of private defence or without pre-meditation or under grave and
sudden provocation. It may be the product of momentary impulse or a feeling of supposed wrong.
Further, the offender may be a man of tender age or immature understanding or he may be an old
man of senile intellect He may be a man given away to fits of temper or he may have acted on the
authority of some person who has in a domineering position. His state of health, sex, position in
life-all these must necessarily influence the determination of the appropriate measure and extent of
punishment The cases of first offenders have to be viewed with commiseration as in such cases
repentance and reFormation are always possible. In such cases punishment should ordinarily be of
warning rather than of penalty. That is not to say that Criminal tendencies in juvenile offenders
should not be taken into consideration at all in passing sentence against them. Indeed while passing,
sentence on such offenders also, it is necessary to guard against any danger to the public and danger
to the accused himself. Where the crime committed by a young man is by no means a simple crime,
such as is committed by children out of mere thoughtlessness rather than criminality, and it shows a
singular combination of design and ingratitude and a general character of craft and deceit, he may
not be leniently dealt with. The cases of hardened criminals may warrant a long term of
imprisonment if there is no likelihood of moral improvement of the person. Considerations of public
safety and protection and the risk and danger to which the public will be exposed while he is at large
may justify his being awarded a long term of imprisonment Where deliberate murders have been
committed, dangerous weapons are used or a defenceless man or woman is attacked in a cowardly
manner or with treacherous deceit or where the deceased is mercilessly killed or where a child is
killed for its ornaments by a servant to whose care the child was committed-such cases ordinarily
warrant severe sentence and may sometimes even extreme penalty of law that can be given. So also
the cases dacoity or robbery with acts of great cruelty and violence; likewise rape committed upon
an innocent and undefended girl or other atrocious crimes committed with deliberation all theseCriminal Rules of Practice and Circular Orders, 1990

cases demand severe sentence.There are certain types of cases where deterrent sentences may have
to be passed. These sentences will be of utility where there is a deliberate defiance of law by a large
body of person. "when waves of imitative crime sweep over the State or where in times of public
tumult there is danger of wide breach of public peace or security or where a highly organised or
some professional association of persons "engineer series of offences or in similar circumstances"
See. 63 I.C.615 (Per Bucknil-J). Exemplary punishments may be needed in cases where it is
necessary to maintain as high a standard as possible of honesty and decency among public servants
and persons who occupy positions of trust and confidence. They may also sometimes be needed in
the case of prejury. In the case of thefts in places of public resort, such as fairs, railway trains, having
regard to the circumstances, deterrent sentences may have to be passed. In offences which may be
said to be terrible or in certain class of crimes which can figuratively be called 'white collar crimes' or
in offences for bribery, corruption, tax evasions, malpractices in share markets and offences
punishable under special enactments like the Prevention of Food Adulteration Act, the Drugs Act,
Anti-smuggling Laws, Violation of Foreign Exchange Regulations and the like, they may, having
regard to the circumstances in which they were committed have to be dealt with by awarding
deterrent punishments. These offences are, as a rule, more dangerous than ordinary crimes not only
because the financial stakes are high but also because of irreparable damage done to public morals
and injustice to the society at large. The unnatural offences such as those punishable under Section
377 I.P.C. or similar offences which corrupt the society call for deterrent sentence. So also all
anti-social offences where the person wants to become rich at the time of scarcity, like the offences
of black-marketing, also may warrant deterrent sentence. So also certain cases under the Excise Act
which are not easy to detect and are difficult to prove.Leniency in punishments may be of grate
utility in cases where the mitigating circumstances warrant the same.Where the offence is purely a
technical one it may call for only a nominal punishment The fact that the accused was not cognizant
of the offence committed by him also may be taken into consideration in determining the measure of
punishment.In cases of political offences, arising out of beliefs of the accused but not involving
heinous crimes or offences endangering the public safety severe sentence might sometimes defeat
the object and create other offenders. Where the offence involves no moral turpitude though it is
deliberate, having regard to the nature and gravity of the offence, sometimes it may be sufficiently
punished by fine if the offender is capable of paying the same.It is not possible to cover the entire
sphere of cases in connection with the question of punishment It is sufficient to state that award of
adequate punishment being a matter left to the discretion of the Court, the Court has to judiciously
exercise its discretion regard being had to the Principles stated above.The instances given already
must furnish sufficient guidance for exercising the discretion. They should not, however, be taken as
rule of thumb but only as principles regulating discretion.The question of awarding punishment
arises only when the guilt of the accused is proved beyond reasonable doubt In doubtful cases or
where the evidence is weak or insufficient, it is highly improper to convict the accused and pass a
nominal or inadequate sentence which is not open to appeal.Unappealable sentences are permitted
by law on the basis of absolute trust in the bona fides and integrity of the Magistrates. A sacred
responsibility, therefore, rests on them when they pass unappealable sentences.As already stated the
sentences which the Courts may pass must be clear and complete in themselves so as to allow no
scope for doubt or misapprehension about the scope and effect thereof. If the accused is convicted of
two or more offences, the sentence should be passed separately for each of the offences. It should
also be stated whether the punishments should run concurrently or not.Where the offence isCriminal Rules of Practice and Circular Orders, 1990

punishable both under the Penal Code and another law, the offender can be punished under one or
the other but not under both. If an offence is punishable with death alone as in the case of Section
303 of I.P.C. that punishment alone should be inflicted on conviction. If the sentence is death or
imprisonment for life, no sentence other than any of these two can be given.Fine: - In some cases
fine is the only punishment which can be imposed while in other cases fine may be imposed along
with the imprisonment In awarding the sentence of fine, in addition to substantial term of
imprisonment, it shall be carefully considered whether or not the circumstances of the crime desire
both the fine and imprisonment.SupplementLatest AmendmentsAmendment to the Criminal Rules
of Practice and Circular Orders, 1990 - Orders - IssuedG.O.Rt. No. 2200, Law (L.A. & J - Home -
Courts-B) Department, Dated: 07-11-2013NotificationIn exercise of the powers conferred by Article
227 of the Constitution of India and Section 477 of the Code of Criminal Procedure, 1973 (Act 2 of
1974) and of all other powers hereunto enabling the Governor of Andhra Pradesh in consultation
with the High Court of Andhra Pradesh hereby makes the following amendment to the Criminal
Rules of Practice and Circular Orders, 1990 as published in the Andhra Pradesh Gazette, RS to
part-II, issue No. 6, dated the 7th March, 1991.AmendmentsIn the Criminal Rules of Practice and
Circular Orders, 1990, after Rule 116, the following rules shall be added, namely,"116A. To avoid
abscondence of accused due to furnishing of bogus surety or surety bond by a stock surety, in
addition to the proof as mentioned in sub-clause (2) of the Format of Surety Bond, the surety, in all
cases under the NDPS Act, the cases in which offence is serious and sentence provided is of more
than 10 years imprisonment or the cases under the special enactments shall furnish at least one of
the documents, amongst the following :-
1. Ration Card (Household supply card) issued by the Civil Supplies
Department.
2. Passport
3. Identity Card issued by the Election Commission of India.
4. Permanent Account Number Card, i.e., PAN Card issued by the Income-Tax
Department.
5. ATM/Debit card, or Credit Card issued by any Nationalized or Private Bank
of Standing at the National Level, having photograph of the holder thereon.
6. Identity Card issued by the Government Authorities or he Public Statutory
Corporations.
7. Any such document, which is ordinarily issued by an Authority after due
verification of the identity of the person and his address, which the Judge or
the Magistrate may think just and proper, in the interest of justice, byCriminal Rules of Practice and Circular Orders, 1990

recording specific reasons.
116B. The surety shall submit two copies of his latest passport size
photographs, which are not older than six months before the date of
submission, of which one copy shall be retained in the Court record and one
copy be retained by the police station concerned."
Amendment to the Criminal Rules of Practice and Circular Orders, 1990 - Orders - IssuedG.O.Rt.
No. 2201, Law (L.A. & J - Home - Courts-B) Department, Dated: 07-11-2013.NotificationIn exercise
of the powers conferred by the Article 227 of the Constitution of India and Section 477 of the Code of
Criminal Procedure, 1973 (Act 2 of 1974) and of all other powers hereunto enabling the Governor of
Andhra Pradesh in consultation with the High Court of Andhra Pradesh hereby makes the following
amendment to the Criminal Rules of Practice and Circular Orders, 1990, as published in the Andhra
Pradesh Gazette, RS to Part - II, issue No.6, dated the 7th March, 1991.AmendmentThe existing
sub-rule (2) of Rule 58 shall be read as sub-rule (2)(i) and the following rules (ii) and (iii) shall be
added, namely,"(ii) each document shall be assigned separate exhibit number;(iii)where a marked
document contains more pages than one, the total number of pages shall be mentioned in the
endorsement".Criminal Rules of Practice and Circular Orders, 1990

