Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental
Action Group & Ors on 7 March, 2006
Equivalent citations: AIR 2006 SUPREME COURT 1489, 2006 AIR SCW 1392,
2006 (3) AIR BOM R 164, (2006) 4 COMLJ 14, (2006) 2 SCJ 705, 2006 (3) SCC
434, (2006) 3 SUPREME 49, (2006) 1 LACC 456, (2006) 3 SCALE 1, 2006 BOM
LR 1 738, (2006) 1 GCD 686 (SC), MANU/SC/1197/2006, (2006) 3 BOM CR 260
Author: S.B. Sinha
Bench: S.B. Sinha, P.P. Naolekar
           CASE NO.:
Appeal (civil)  1519 of 2006
PETITIONER:
Bombay Dyeing & Mfg. Co. Ltd
RESPONDENT:
Bombay Environmental Action Group & Ors
DATE OF JUDGMENT: 07/03/2006
BENCH:
S.B. Sinha  & P.P. Naolekar
JUDGMENT:
J U D G M E N T [Special Leave Petition (Civil) No.23040 of 2005] With CIVIL APPEAL NO. 1528
of 2006 [Arising out of SLP (C) No. 24415 of 2005] CIVIL APPEAL NO. 1546 of 2006 [Arising out of
SLP (C) No. 23317 of 2005] CIVIL APPEAL NO. 1541 of 2006 [Arising out of SLP (C) No. 23500 of
2005] CIVIL APPEAL NO. 1532 of 2006 [Arising out of SLP (C) No. 24418 of 2005] CIVIL APPEAL
NO. 1540 of 2006 [Arising out of SLP (C) No. 23607 of 2005] CIVIL APPEAL NO. 1550 of 2006
[Arising out of SLP (C) No. 23609 of 2005] CIVIL APPEAL NO. 1520 of 2006 [Arising out of SLP
(C) No. 23616 of 2005] CIVIL APPEAL NO. 1536 of 2006 [Arising out of SLP (C) No. 23632 of
2005] CIVIL APPEAL NO. 1521 of 2006 [Arising out of SLP (C) No. 23700 of 2005] CIVIL APPEAL
NO. 1515 of 2006 [Arising out of SLP (C) No. 23718 of 2005] CIVIL APPEAL NO. 1538 of 2006
[Arising out of SLP (C) No. 23765 of 2005] CIVIL APPEAL NO. 1518 of 2006 [Arising out of SLP (C)
No. 24419 of 2005] CIVIL APPEAL NO. 1523 of 2006 [Arising out of SLP (C) No. 23794 of 2005]
CIVIL APPEAL NO. 1543 of 2006 [Arising out of SLP (C) No. 23810 of 2005] CIVIL APPEAL NO.
1517 of 2006 [Arising out of SLP (C) No. 23815 of 2005] CIVIL APPEAL NO. 1522 of 2006 [Arising
out of SLP (C) No. 26193 of 2005] CIVIL APPEAL NO. 1530 of 2006 [Arising out of SLP (C) No.
26088 of 2005] CIVIL APPEAL NO. 1534 of 2006 [Arising out of SLP (C) No. 26089 of 2005] CIVIL
APPEAL NO. 1526 of 2006 and [Arising out of SLP (C) No. 25048 of 2005] CIVIL APPEAL NO. 1516
of 2006 [Arising out of SLP (C) No. 26090 of 2005] S.B. SINHA, J :Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

Leave granted in all SLPs.
INTRODUCTION Whether any synthesis between environmental aspects and
building regulation vis-`-vis the scheme floated by the Board of Industrial and
Financial Reconstruction (for short 'BIFR') in terms of the provisions of the Sick
Industrial Companies (Special Provisions) Act, 1985 (for short, 'SICA') herein is
possible is the core question involved in these appeals.
BACKGROUND FACTS The First Respondent herein is a public charitable trust. Its
aims and objects, inter alia, are to look after the environment in all respects. It had
allegedly initiated and/or participated in matters of environmental importance as
regard preservation and improvement wherefor it had moved the court in public
interest on several occasions. The Second Respondent herein is said to be the
honorary Secretary of the First Respondent and served in various committees
appointed by the Central and State Governments as also by the Bombay High Court.
The said respondents filed a writ petition questioning the validity of Development
Control Regulation No. 58 (DCR 58) framed by the State of Maharashtra in terms of
the Maharashtra Regional and Town Planning Act, 1966 [for short "the MRTP Act"].
The Respondents in the writ application, some of whom are Appellants herein, were/
are owners of various cotton textile mills.
DCR 58 admittedly was made by the State of Maharashtra with a view to deal with
the situation arising out of closure and/or unviability of various cotton textile mills
occasioned inter alia by reason of a strike resorted to by the workers thereof.
WRIT PROCEEDINGS The writ petition questioning the validity of DCR 58 by the
First and Second Respondents was filed allegedly to protect the interests of the
residents of Mumbai and to improve the quality of life in the town of Mumbai which
is said to have drastically been deteriorated during the last fifteen years as also for
preventing further serious damage to the town planning and ecology so as to avoid an
irretrievable breakdown of the city. The main thrust of the writ petitioners was to
ensure "open spaces" for the city and to provide the crying need of space for public
housing. In the said writ petition, apart from the State of Maharashtra, the Municipal
Corporation of Greater Mumbai (MCGM), the Maharashtra Housing and Area
Development Authority (MHADA), the National Textile Corporation (NTC) North
Maharashtra and South Maharashtra were impleaded as respondents. Before the
High Court, a large number of mill owners and others who allegedly have invested a
huge sum on the lands of the mill owners or otherwise interested in implementation
of DCR 58 of 2001 filed applications for their impleadment as parties therein which
were opposed by the writ petitioner- respondents. The said applicants were, however,
allowed to intervene in the matter. It is, however, not in dispute that the purchasers
from National Textile Corporation were not impleaded as parties therein who are
now before us. On or about 2.6.2005, the writ petitions-Respondents took out a
Chamber Summons seeking to amend the writ petition. The proposed amendmentsBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

inter alia related to:
"i) a challenge to the clarification dated 28th March, 2003 issued by Respondent No.
3 on the ground that the same seeks to permit residential user and is therefore an
amendment of DCR 58 of 2001; and
ii) the alleged requirement of Environmental Impact Assessment (EIA) in pursuance
of notification dated 27th January, 1994 as amended by notification dated 7th July,
2004 issued under the provisions of the Environment Protection Act."
The said Chamber Summons was allowed by an order dated 7.7.2005 directing:
"We are fully satisfied that the amendments sought are necessary and essential in the
above Petition especially when the above petition is a PIL petition, which is yet to be
admitted. The Respondents will have full opportunity to deal with these amendments
by filing an additional affidavit  in reply. Under these circumstances, Chamber
Summons is made absolute in terms of prayer clause (a). Amendment to be carried
out on or before 16.7.2005"
HIGH COURT JUDGMENT The aforementioned writ petition was allowed by the Bombay High
Court on 18.02.2005. By its judgment, the Division Bench of the High Court, inter alia, held :
(i) DCR 58 should be construed having regard to the importance of open space and
public space;
(ii) By reason of the 2001 amendment, no substantial change had been made and the
amendments carried out therein must be construed having regard to the expression
'development' which included 'demolition of structures'.
(iii) DCR 58 as amended must be harmoniously construed so as to uphold the
constitutionality thereof. The expression 'open space' would take within its ambit the
same space as was obtaining after demolition.
(iv) DCR 58, if not construed in the manner as contended by the writ petitioners
would render it ultra vires Articles 14, 21 and 48-A of the Constitution of India.
(v) Sales carried out by the National Textile Corporation were contrary to the scheme
framed by BIFR as also the orders of this Court dated 05.05.2005
(vi) NTC as a State should have taken steps to modernize its mills or start other
textile mills. It could not act like a private mill owner. Its high profits should not be
expended towards anything which would be contrary to the objectives for which the
Acts of 1974 and 1994 were enacted, as also the scheme of the BIFR and the orders of
this Court.Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

(vii) Doctrine of prospective overruling has no application in the instant case.
(viii) The High Court refused to dismiss the public interest litigation on the ground of delay in view
of the enormity of the issues involved. In support of the said contention, it principally relied on the
decision of this Court in M/s. Lohia Machines v. Union of India [AIR 1985 SC 421].
(ix) It concluded:
"(a) In amended DCR 58(1)(b), "open lands"
would include lands after demolition of structures.
(b) Clarification dated 28th March, 2003 is clearly violative of Section 37 of MRTP Act and Article
21 of the Constitution of India.
(c) The issue whether the amended DCR 58 is contrary to Section 37 of MRTP Act or Article 21 of
the Constitution of India, is kept open.
(d) All the constructions carried out by various Developers are clearly in violation of EIA
Notification as amended on 7th July, 2004, as admittedly none of them have obtained clearance
from Ministry of Environment and Forests.
(e) All sales of Mill lands carried out by NTC are clearly contrary to the Supreme Court orders dated
11th May, 2005 and 27th September, 2002 and contrary to the sanctioned BIFR schemes."
Upon taking into consideration the provisions of the 1994 Amendment Act and SICA, it was held:
(i) State also has a stake in the mills because they meet the requirements of cheap
and quality cloth and furthermore provide work and livelihood to many.
(ii) An ecological imbalance would be created by proliferation of high-
rise structures in Girangaon area, which was essentially planned for commercial and industrial
activities.
(iii) DCR 58 facilitates the implementation of measures for revival, rehabilitation and modernisation
of closed, sick and potentially viable sick mills and must, thus, be construed as such.
(iv) NTC should take all such measures as are necessary to protect and encourage the industry and
not contrary thereto or inconsistent therewith.
(v) It was necessary to amend DC Regulations to confer additional rights and incentives to enable
NTC and the mill owners revive the mills.Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

(vi) The Commissioner has discretion to permit utilisation of existing built up area and open lands
as well as the balance FSI.
(vii) NTC has a statutory obligation to revive, rehabilitate, or modernise the mills.
(viii) Commissioner has the power to allow re-construction and demolition of existing structures,
but re-construction is limited to the extent of built up area of the demolished structures.
(ix) Combination of properties whether under common ownership or otherwise and joint
development is permitted provided FSI is in balance.
(x) If the textile mill has shifted or the owner establishes a diversified industry then further
obligation is cast to offer on priority in the re- located mill or diversified industry, as the case may
be, employment to the workers.
(xi) Fruits and benefits of development and re-development cannot be retained by owners but they
have to be passed on to those who are legitimately entitled thereto.
(xii) Monies are required to be put in Escrow Account.
(xiii) It is a complete and comprehensive code so far as development and re-development of lands of
cotton textile mills is concerned. Mill owners must not be allowed to trade in the properties owned
by it.
(xiv) The scheme is very much workable as the regulation allows enough free play to meet the
obligations towards workers and financial institutions.
(xv) The intent is to control the development and re-development by making comprehensive
regulatory measures, the portions becoming vacant after demolition of existing built-up areas have
to be included in the concept "open lands."
As regards, the clarification made by the State dated 28.3.2003, it was opined that the same
amounts to amendment of DCR 58 and, thus, not being a clarification simpliciter in terms of DCR
62(3), the same was unsustainable. The said clarification was also ultra vires Article 21 of the
Constitution of India.
As regards non-compliance of the notification dated 07.07.2004, it was observed that none of the
mills obtained clearance as per the EIA Notification in spite of High Court's directions to do so and
had been carrying on construction activities. MCGM as also the State of Maharashtra did not take
any effective step to ensure compliance of the EIA notification. Even the public hearings conducted
by the Maharashtra Pollution Control Board were not done satisfactorily. It directed that the public
hearings be conducted by the Ministry of Environment and Forests itself, keeping in view the
enormity of ecological imbalance and environmental degradation and also keeping in mind
'Precautionary Principle' and the principle of 'sustainable development.' In its judgment, the HighBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

Court furthermore opined:
(i) MCGM has not ensured at all, while sanctioning the building plans, compliance of
the provisions relating to public amenities.
(ii) No step for compliance with EIA Notification had been taken ever by MCGM..
(iii) MCGM did not ensure furthermore that all the Mill owners provide free housing
of 225 Square feet to the occupants. Despite mandatory nature of DCR 58 (7) none of
the sanctioned plans provide for any housing for the mill workers/occupants.
(iv) MCGM has not ensured surrendering of lands for "open spaces" and "public
housing" as per amended DCR 58, although any construction could commence only
after physical surrender of lands as "open spaces" and "public housings."
(v) Since, MCGM had completely abdicated all its basic functions, State of
Maharashtra was ordered to take immediate remedial measures.
SUBMISSIONS We have heard a large number of counsel appearing for the parties. Submissions of
the learned counsel appearing for the Appellants and supporting respondents are as under:
Re: DCR 58 (A) DCR 58, as amended in 2001, shall apply not only to a sick mill but
also to a closed mill being unviable which had opted for revival/
modernization/shifting. The original DCR 58 being not invalid, the mere grant of
additional benefits would not make it ultra vires. (B) The State cannot be said to have
ignored various conflicting objectives while carrying out the amendment in DCR 58.
(C) The High Court, in exercise of its jurisdiction of judicial review, could not have
interfered with a policy decision of the State. (D) The High Court committed a
manifest error in holding that the amended version of DCR 58 vis a vis the term 'open
space' would have the same meaning as was contemplated under DCR 58 of 1991. (E)
The High Court failed to appreciate that reading down of DCR 58 was impermissible
in law.
(F) The High Court ought to have taken into consideration the past experience of the
State necessitating amendment of DCR. (G) The High Court furthermore failed to
take note of the fact that the committees appointed by the State also made
recommendations that the mill owners would be allowed to develop their lands. (H)
Two different interpretations of DCR 58 having been found by the High Court to be
possible, it could not have arrived at a conclusion that clarificatory notification dated
28.03.2003 amounted to an amendment of the Regulation and, thus, void. (I) The
impugned judgment is wholly unsustainable as several irrelevant factors, e.g. deluge
in the city of Bombay in 2005, were taken into consideration for the purpose of
interpretation of DCR 58. (J) The findings of the High Court would lead to a radical
discrimination between cotton textile mills and other industries which being notBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

based on any rational criteria renders it unconstitutional being violative of Article 14
of the Constitution of India. (K) The High Court failed to take into consideration the
fact that the equity was in favour of the appellants herein as they having already
demolished the building as having created third party interests, should not have been
asked to go back to the same position as was obtaining in the year 1991.
(L) If the impugned judgment is upheld, several provisions of DCR 58, as for
example, clause (6) thereof would become otiose and redundant and, thus,
interpretation of the High Court in respect of DCR 58 is unsustainable.
(M) No foundational fact having been laid in the writ petition to show as to how the
clarification amounts to amendment of DCR 58, the High Court committed a
manifest error in arriving at a finding that the said Regulations are ultra vires Section
37 of the Act and/or Article 21 of the Constitution of India.
(N) The Respondent-writ petitioners were guilty of serious delay and laches in filling
of the writ petition and thus it was liable to be not dismissed in limine.
Re: Validity of sales of 5 mills by NTC
(a) The High Court in granting relief in favour of the writ petitioners failed to take
into consideration relevant factors and based its decision on irrelevant factors and,
thus, misdirected itself in law.
(b) The judgment of this Court in Bombay Dyeing & Manufacturing Co.
Ltd. v. Bombay Environmental Action Group and Ors. [(2005) 5 SCC 61] being final and binding on
the parties, the High Court committed a serious illegality in interfering therewith.
(c) BIFR scheme had wrongly been taken recourse to for the purpose of construction of the
Regulation.
Submissions of Writ Petitioners  Respondents No. 1-2 (1) DCR broadly lays down a scheme of land
uses and zoning, Clause 58 thereof as amended in 2001 should be read in conformity with the
provisions of the MRTP Act.
(2) The expression 'open land' as contained in DCR 58 must be interpreted in such a manner so as to
enable the concerned authorities to sanction a building plan in terms of the extant regulations. (3)
On a plain construction of DCR 58 of 2001, it has rightly been held by the High Court that the
intention of the State evidently was to give only double FSI and not to diminish the stake of MCGM
and MHADA in the mill land.
(4) Interpretation of DCR 58 by the State has defeated the purport and object of the Act.Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

(5) For the purpose of upholding the constitutionality of DCR 58, the same was required to be read
down, failing which it is rendered unconstitutional.
(6) The effect and purpose of DCR 58 as clarified by the state only having come to the notice of the
writ petitioners in 2005 and as the writ petition was filed by them immediately thereafter, the same
was not liable to be dismissed on the ground of delay and laches on their part.
(7) In view of the subsequent events, this Court may lay down the principles for the purpose of
moulding the reliefs and remit the matter to the High Court for consideration of the matter afresh.
(8) MHADA and the MCGM having taken different stands before the High Court, that they should
not be permitted to support the State before this Court.
(9) All applications for grant of permission for development/ redevelopment was required to be
considered having regard to the nature of the land as would be existing after demolition of the
existing structures.
STATUTORY SCHEME Bombay Town Planning Act, 1954 replaced the Bombay Town Planning Act
1915 which became applicable to the entire State of Maharashtra including the town of Mumbai.
In the year, 1966, the legislature of the State of Maharashtra with a view to make provisions for
planning and development and use of land in regions established for that purpose and for
constitution of Regional Planning Boards therefor and for other purposes mentioned in the
preamble thereto enacted the MRTP Act repealing and replacing the Bombay Town Planning Act,
1954. It came into force with effect from 11th January, 1967. MRTP Act provides for formulation of
regional plans and development plans. Definitions of some of the expressions which are relevant for
our purpose are as under:
2(7) "Development" with its grammatical variations means the carrying out of
buildings, engineering, mining or other operations in, or over, or under, land or the
making of any material change, in any building or land or in the use of any building
or land or any material or structural change in any heritage; building or its precincts
and includes demolition of any existing building structure or erection or part of such
building, structure of erection; and reclamation, redevelopment and lay-out and
sub-division of any land; and "to develop" shall be construed accordingly;
2(9) "Development plan" means a plan for the development or re-development of the
area within the jurisdiction of a planning Authority and includes revision of a
development plan and proposals of a special planning Authority for development of
land within its jurisdiction;
2(9A) "development right" means right to carry out development or to develop the
land or building or both and shall include the transferable development right in the
form of right to utilise the Floor Space Index of land utilisable either on the
remainder of the land or partially reserved for a public purpose or elsewhere, as theBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

final Development Control Regulations in this behalf provide;
2(13A) "Floor Space Index" means the quotient or the ratio of the combined gross
floor area to the total area of the plot, viz.: -
Floor Space Index = "
Section 2(27) defines regulations made under Section 159 of the MRTP Act and
includes zoning and other regulations made as part of a regional plan, development
plan or town planning scheme. The land-use maps and the development control
rules/ regulations together comprise the development plan under Section 22. The
land-use map indicates the zone in which a piece of land falls, in regard whereto the
permissible uses are specified in the rules/ regulations. In each of such zonal plan,
although the industrial areas have been delineated separately but existence of each of
the cotton textile mills therein has specifically been shown which evidently shows
that cotton textile mills had been given a special status.
The regional plan is drawn up by the State Government in terms of Section 14 read
with Section 17 of the MRTP Act. Section 14 inter alia mandates specification of land
uses, i.e., residential, industrial, agricultural, etc., reservation for open spaces,
gardens, etc., reservation and conservation of areas of natural scenery as also
infrastructure such as transport, water supply, drainage, sewerage, etc. Section 21
mandates drafting of a Development Plan by every Planning Authority for the area
within its jurisdiction. Section 22 lays out the contents of such development plan
indicating the manner of use and development of land. As far as possible, the same is
to provide for:-
a) Allocation of land for residential, industrial, commercial, agricultural uses, etc;
b) Designation of land for public purposes;
c) Designation of areas for open spaces, playgrounds, stadia, zoological gardens,
green belts, nature reserves, sanctuaries and dairies;
d) Transport and communication;
e) Public utilities and amenities;
f) Reservation of land for community facilities and services.
Section 37 permits modification of a Development Plan by the Planning Authority or in cases of
urgency by the State Government in exercise of its power under Sub-section 1AA of Section 37 which
reads as under:Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

"(1AA) (a) Notwithstanding anything contained in sub-sections (1), (1A) and (2),
where the State Government is satisfied that in the public interest it is necessary to
carry out urgently a modification of any part of, or any proposal made in, a final
Development Plan of such a nature that it will not change the character of such
Development Plan, the State Government may, on its own, publish a notice in the
Official Gazette, and in such other manner as may be determined by it, inviting
objections and suggestions from any person with respect to the proposed
modification not later than one month from the date of such notice, and shall also
serve notice on all persons affected by the proposed modifications and the Planning
Authority.
[Emphasis supplied] Section 38 provides for periodic revisions of the development plan making it
mandatory to revise the same at least once in every 20 years. Section 43 restricts change in use or
development of land without the written permission of the Planning Authority. Such application is
required to be made in terms of Section 44 of the Act.
Section 45 confers power to grant such permission whereas Section 46 makes it mandatory for the
planning authority to have due regard to the provisions of the draft of final plan or a sanctioned
plan.
Section 159 of the MRTP Act empowers any Regional Board or Development Authority to make
regulations consistent with the provisions thereof or the rules made thereunder inter alia to carry
out the purposes thereof. Sub-section (2) of Section 159 empowers the State Government to make
special development control regulations consistent therewith and the rules made thereunder to
carry out the purpose of executing a Special Township Project and such regulations may be a part of
Development Control Regulations or Development Plan or Regional Plan, as the case may be.
In terms of the MRTP Act, Development Control Rules (DCR), 1967 were framed. The State
Government took a policy decision to frame new DCR in 1990 wherefor suggestions / opinions from
the public were invited.
The State of Maharashtra in exercise of its power conferred on it under Section 159(2) of the MRTP
Act framed the Development Control Regulations, 1991 (for short "the 1991 Regulations"). The
Development Plan had been notified in the year 1981 and the Development Control Regulations
formed a part thereof. The said regulations, indisputably, were framed upon carrying out the
requisite formalities. The expression "existing building" is defined in Regulation 2(28) to mean "a
building or structure existing authorisedly before the commencement of these regulations. The
expression Floor Space Index (FSI) is defined under Regulation 2(42) to mean "the quotient of the
ratio of the combined gross floor area of all floors, excepting areas specifically exempted under these
Regulations to the total area of the plot. Regulation 3(1) makes the regulations applicable to "all
development, redevelopment, erection and/ or re-erection of a building, change of user, etc., as well
as to the design, construction, reconstruction, and additions and alterations to a building".
Regulation 3(2) reads as under:Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

"Part construction  where the whole or part of a building is demolished or altered or
reconstructed/ removed, except where otherwise specifically stipulated, these
regulations apply only to the extent of the work involved."
In terms of Regulation 21 whenever more than one building is proposed on any land or where the
land development measures more than 1000 sq. m. in a residential, commercial or industrial zone,
it is mandatory to prepare a lay-out plan. A lay-out plan would also be necessary where
sub-divisions are required to be made. Such plan inter alia has to include "a table indicating the size,
area and use of all the plots in the sub-division/ lay- out plan". It should also contain "a statement
indicating the total area of the site area utilized under roads, open spaces for parks, playgrounds,
recreation spaces and development plan designations, reservations and allocations, schools,
shopping and other public places along with their percentage with reference to the total area of the
site"
Land uses have been provided for in Regulation 9 stating that uses of all lands should
be regulated in regard to type and manner of development/ redevelopment as
specified in Table  4. In Table  4 inter alia the following uses have been mentioned:
(a) Residential
(b) Commercial
(c) Industrial
(d) Transportation
(e) Public and semi-public Regulation 32 read with Table -14 prescribes the floor
space indices in relation to the town of Bombay stating that for residential zone, it
would be 1.33 whereas for the service zone it would be 1.00.
Item  3 of Table  14 specifies different zones stating:
"Service Industrial Zone (I-1) General Industrial Zone (I-2) Special Industrial Zone
(I-3)
(a) For users permissible in the zone in the Island City and in Suburbs and Extended
Suburbs 1.00
(b)Textile Mills -
1.00 Island City and Suburbs and Extended Suburbs.
In the case of reconstruction, modernization or renovation, where a textile activity is to be
continued, the FSI shall not exceed 1.33 in the Island City and 1.00 in the Suburbs and ExtendedBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

Suburbs."
Regulation 34 provides for available Transferable Development Rights (TDR) if the development
potential of a plot is separated from the land. TDR so granted can be alienated in the manner
prescribed by the regulation. Regulation 35, in the matter of calculating the floor space index  built
up area in respect of a plot, requires exclusion of certain areas for large plots in residential and
commercial zones, i.e., plots exceeding 2500 sq. m. approx., i.e., 15% of the area has to be excluded
for recreational amenity, open space, etc. Regulation 51(1) speaks of ancillary uses. Regulation 52
provides that what could be done in terms of Regulation 51 can be done also in terms of Regulation
52; whereas Regulation 53 provides that what could be done in terms of Regulations 51 and 52 could
be done also in terms of Regulation
53. Regulation 54(1)(i) provides for industries in C-2 zone wherein also commercial uses as specified
therein are permissible. Regulations 56 to 58 provide for user of land for industrial zones.
Regulation 56 of the 1991 Regulations provides for the General Industries Zone (I-2 Zone) which
includes any building or part of a building or structure in which products or materials of all kinds
and properties are fabricated, assembled or processed. Sub-regulation (2) of Regulation 56, inter
alia, enumerates textile' manufacture except manufacture of rope, bandage, net and embroidery
using electric power upto 37.5 KW. It is not disputed that all the mill lands fall in either residential
or I-2 Zones. The I-2 zones permits buildings and premises to be used for industrial and accessory
uses except one category under sub-regulation (2) of Regulation 56 new textile mills cannot be
constructed in the said areas. Sub-regulation (3) of Regulation 56 contains a non-obstante clause
providing that service industries and service industrial estates shall be permitted in the General
Industries Zone. Sub-regulations 3(b), 3(c) and 3(d) of Regulation 56 read as under:
"(b) With the previous approval of Commissioner and on such conditions as deemed
appropriate by him, the existing or newly built-up area of unit, in the General
Industrial Zone (Zone I-2), (including industrial estates) excluding that of cotton
textile mills, may be permitted to be utilized for an office or commercial purposes as a
part of a package of measures recommended by the Board of Industrial and Financial
Reconstruction (BIFR), Financial Institutions and Commissionerate of Industries for
the revival/ rehabilitation of potentially viable sick industrial units.
(c) With the previous approval of the Commissioner, any open land or lands or
industrial lands, in the General Industrial Zone (I-2 Zone) be permitted to be utilized
for any of the permissible users in the Residential Zone (R-1 Zone) or the Residential
Zone with shop line (R-2 Zone) or for those in the Local Commercial Zone (C-1 Zone)
subject to the following.
(d) With the previous approval of the Commissioner, and subject to such terms as
may be stipulated by him, open land in existing industrially zoned land or space,
excluding land or space of cotton textile mills, which is unoccupied or is surplus to
requirement of the industry's use may be permitted to be utilized for office or
commercial purposes but excluding warehousing."Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

Sub-regulation (4) of Regulation 56 deals with other uses in the General Industrial Zone.
Regulation 57 of the 1991 Regulations provides for Special Industrial Zone known as I-3 Zone.
Manufacture of textile goods do not come within the purview thereof. In terms of the said
Regulation, similar restrictions on land user have been provided except service industries and
service industrial estates. Change of user is allowed for lands other than lands of cotton textile mills.
Regulation 57(4)(c) is in pari materia with Regulation 56(3)(c).
LEGAL HISTORY OF DCR 58 DCR 58 of 1991 provided for development or redevelopment of lands
of cotton textile mills; in terms whereof, modernization of mills and development of surplus lands in
the manner specified therein was to be promoted. It, furthermore, provided for development of mill
lands as a part of package of BIFR  approved rehabilitation schemes and also for modernization
and shifting thereof. Pursuant to the said Regulation, the cotton textile mill owners could give one of
the options out of the following:
(i) The mill owners could continue to operate their mills even though it was running
into losses. This was the status quo option which entailed no land being surrendered
to MHADA as well as for public greens.
(ii) The second option entailed retaining the outer shell of the mill structures and
building commercial structures within the mill structure.
(iii) The third option entailed two steps. The first step was raising of construction
within the old structure and the second step was to construct on the part of open
spaces.
(iv) The fourth option ensured demolition of the entire old structures and sharing the
entire mill lands in approximately three equal proportions.
The first part would remain with the mill owner which he would be entitled to redevelop. The second
part would go to MHADA and the third part would go to public greens.
In terms of the said offer, only two mills exercised the second option and three opted for the third.
Nobody had opted for the fourth option presumably because pursuant thereto about 2/3rd of the
land possessed by the owner of the mill was required to be surrendered.
DCR 58 provides for a complete code. A distinction, therein has been made between cotton textile
mills on the one hand and non-cotton textile mills, on the other.
In 2001, DCR 58 was amended/ modified. DCR 58 as amended in the year 2001 reads as under:
"58. Development or redevelopment of lands of cotton textile mills;Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

(1) Lands of sick and/or closed cotton textile mills. -- With the previous approval of
the Commissioner to a layout prepared for development or redevelopment of the
entire open land built-up area of the premises of a sick and/or closed cotton textile
mill, and on such conditions deemed appropriate and specified by him, and as a part
of a package of measures recommended by the Financial Institutions and
Commissionerate of Industries for the revival/rehabilitation of a potentially viable
sick and/or closed mill, the Commissioner may allow;
(a) The existing built-up areas to be utilised-
(i) for the same cotton textile or related user subject to observance of all other
Regulations;
(ii) for diversified industrial users in accordance with the industrial location policy,
with office space only ancillary to and required for such users, subject to and
observance of all other Regulations;
(iii) for commercial purposes, as permitted under these Regulations;
(b) Open lands and balance FSI shall be used as in the Table below:
-----------------------------------------------------------
Sr.  Extent  Percentage     Percentage to    Percentage to
No.          to be earmar-  be earmarked     be earmarked &
             ked for recr-  and handed       marked & to be
             ation Ground   over for dev-    developed for
             /Garden, Play  opment by        residential or
             ground or any  MHADA for        commercial
             other open     public housing   user to be
             user as spec-  /(for mill       developed
             ified by the   worker's hous-   (including
             Commissioner   ing as per       users permis-
                            guidelines       ssible in res-
                            approved by      idential or
                            Government to    commercial
                            be shared        zone as per
                            equally)         these Regulat-
                                             ions) or
                                             diversified
                                             industrial
                                             users as per
                                             Industrial
                                             Location
                                             Policy) to be
                                             developed by
                                             the ownerBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

-----------------------------------------------------------
(1) (2) (3) (4) (5)
-----------------------------------------------------------
inclusive of 5 Ha.
2. Between 5 upto 10 Ha.
----------------------------------------------------------- Note
(i) In addition to the land to be earmarked for recreation ground/garden/play ground or any other
open user as in column (3) of the above Table, open spaces, public amenities and utilities for the
lands shown in columns (4) and (5) of the above Table as otherwise required under these
Regulations shall also be provided.
(ii) Segregating distance as required under these Regulations shall be provided within the lands
intended to be used for residential/commercial users.
(iii) The owner of the land will be entitled to Development Rights in accordance with the
Regulations for grant of Transferable Development Rights as in Appendix VII in respect of the lands
earmarked and handed over as per column (4) of the above Table. Notwithstanding anything
contained in these Regulations, Development Rights in respect of the land earmarked and handed
over as per column (3) shall be available to the owner of land for utilisation in the land as per
column (5) or as Transferable Development Rights as aforesaid.
(iv) Where FSI is in balance but open land is not available, for the purposes of column (3) and (4) of
the above Table, land will be made open by demolishing the existing structures to the extent
necessary and made available accordingly.
(v) Where the lands accruing as per columns (3) and (4) are, in the opinion of the Commissioner of
such small sizes that they do not admit of separate specific uses provided for in the said columns, he
may, with the prior approval of Government, earmark the said lands for the use as provided in
column (3).
(vi) It shall be permissible for the owners of the land to submit a composite scheme for the
development or redevelopment of lands of different cotton textile mills, whether under common
ownership or otherwise upon which the lands comprised in the scheme shall be considered by the
Commissioner in an integrated manner.
(2) Lands of cotton textile mills for purpose of modernisation:-Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

With the previous approval of the Commissioner to a layout prepared for
development or redevelopment of the entire open land and/or built-up area of the
premises of a cotton textile mill which is not sick or closed, but requiring
modernisation on the same land as approved by the competent authorities, such
development or redevelopment shall be permitted by the Commissioner, subject to
the condition that it shall also be in accordance with scheme approved by
Government provided that with regard to the utilisation of built-up area, the
provisions of Clause (a) of Sub-Regulation (1) of this Regulation shall apply and, if
the development of open lands and balance FSI exceeds 30 per cent of the open land
and balance FSI, the provisions of Clause (b) of sub-regulation (1) of this Regulation
shall apply.
Notes:
(i) The exemption of 30 per cent as specified above may be availed of in phases,
provided that, taking into account all phases, it is not exceeded in aggregate.
(ii) In the case of more than one cotton textile mill owned by the same company, the
exemption of 30 per cent as specified above may be permitted to be consolidated and
implemented on any of the said cotton textile mill lands within Mumbai provided,
and to the extent, FSI is in balance in the receiving mill land.
(3) Lands of cotton textile mills after shifting:
If a cotton textile mill is to be shifted out side Greater Bombay but within the State,
with due permission of the competent authorities, and in accordance with a scheme
approved by Government, the provisions of Sub-clauses (a) and (b) of sub- regulation
(1) of its Regulation shall also apply in regard to the development or redevelopment
of its land after shifting. (4) The condition of recommendation by the Board of
Industrial and Financial Reconstruction (BIFR) shall not be mandatory in the case of
the type referred to in sub-regulations (2) and (3) above.
(5) Notwithstanding anything contained above, the Commissioner may allow
additional development to the extent of the balance FSI on open lands or otherwise
by the cotton textile mill itself for the same cotton textile or related user. (6) With the
previous approval of the Commissioner to a layout prepared for development or
redevelopment of the entire open land and/or built up area of the premises of a
cotton textile mill which is either sick and/or closed or requiring modernisation on
the same land, the Commissioner may allow,:
(a) Reconstruction after demolition of existing structures limited to the extent of the
built up area of the demolished structures, including by aggregating in one or more
structures the built up areas of the demolished structures;Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

(b) Multi-mills aggregation of the built up areas of existing structures where an
integrated scheme for demolition and reconstruction of the existing structures of
more than one mill, whether under common ownership or otherwise, is duly
submitted, provided that FSI is in balance in the receiving mill land.
(7) Notwithstanding anything contained above-(a) if and when the built up areas of a
cotton textile mill occupied for residential purposes as on the 1st of January 2000
developed or Page 359 redeveloped, it shall be obligatory on the part of the land
owner to provide to the occupants in lieu of each tenement covered by the
development or redevelopment scheme, free of cost, an alternative tenement of the
size of 225 sq. ft. carpet area;
(b) if and when a cotton textile mill is shifted or the mill owner establishes a
diversified industry, he shall offer on priority in the relocated mill or the diversified
industry, as the case may be, employment to the worker or at least one member of the
family of the worker in the employ of the mill on the 1st January 2000 who possesses
the requisite qualification or skills for the job;
(c) for the purpose of Clause (b) above, the cotton textile mill owner shall undertake
and complete training of candidates for employment before the recruitment of
personnel and starting of the relocated mill or diversified industry takes place.
8(a) Funds accruing to a sick and/or closed cotton textile mill or a cotton textile mill requiring
modernisation or a cotton textile mill to be shifted, from the utilisation of built up areas as per
Clause (a) of sub-regulation (1) and as per Clauses (a) and (b) of sub-regulation (6) or from the sale
of Transferable Development Rights in respect of the land as per columns (3) and (4) of the Table
contained in Clause (b) of sub-regulation (1) or from the development by the owner of the land as
per column (5), together with FSI on account of the land as per column (3), shall be credited to an
escrow account to be operated as hereinafter provided.
(b) The funds credited to the escrow account shall be utilised only for the revival/rehabilitation or
modernisation or shifting of the cotton textile mill, as the case may be, provided that the said funds
may also be utilised for payment of worker's dues, payments under Voluntary Retirement Schemes
(VRS), repayment of loans of banks and financial institution taken for the revival/rehabilitation or
modernisation of the cotton textile mill or for its shifting outside Greater Mumbai but within the
State.
9(a) In order to oversee the due implementation of the package of measure recommended by the
Board of Industrial and Financial Reconstruction (BIFR) for the revival/rehabilitation of a
potentially sick and/or closed textile mill, or schemes approved by Government for the
modernisation or shifting of cotton textile mills, and the permissions for development or
redevelopment of lands of cotton textile mills granted by the Commissioner under this Regulation,
the Government shall appoint a Monitoring Committee under the chairmanship of a retired High
Court Judge with one representative each of the cotton textile mill owners, recognised trade unionBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

of cotton textile mill workers, the Commissioner and the Government as members.
(b) The Commissioner shall provide to the Monitoring Committee the services of a Secretary and
other required staff and also the necessary facilities for its functioning.
(c) Without prejudiced to the generaility of the functions provided for in Clause (a) of this
sub-regulation, the Monitoring Committee shall, --
(i) lay down guidelines for the transparent disposal by sale otherwise of built up space, open lands
and balance FSI by the cotton textile mills;
(ii) lay down guidelines for the opening operation and closure of escrow accounts;
(iii) approve proposals for the withdrawal and application of funds from the escrow accounts;
(iv) monitor the implementation of the provisions of this Regulation as regards housing, alternative
employment and related training of cotton textile mill workers.
(d) The Monitoring Committee shall have the powers issuing and enforcing notices and attendance
in the manner of a Civil Court.
(e) Every direction or decision of the Monitoring Committee shall be final and conclusive and
binding on all concerned.
(f) The Monitoring Committee shall determine for itself the procedures and modalities of its
functioning."
REASONS FOR AMENDMENT We may, at this juncture, take notice of the stand taken by the State
before the High Court. The State of Maharashtra filed several affidavits before the Bombay High
Court stating the backdrop of events leading to amendment in 2001. It is accepted that the State
appointed several committees to make an in depth study of the matter. In an affidavit affirmed by
one Shri Ramanand Tiwari, Principal Secretary, Urban Development Department, Government of
Maharashtra, on 22nd March, 2005, it was stated:
"I say that the deteriorating condition of the textile units and need to have sites for
public purpose and public housing, prompted Government to have a policy which
threw open these lands for development or redevelopment to facilitate revival and
modernization of mills. Thus, in the year 1991, when the Revised Development
Control Regulations were sanctioned, Regulation 58 for development of mill land and
premises for cotton textile mills was introduced for the first time."
In the said affidavit, it was categorically stated that a committee under the Chairmanship of the then
Minister for Textiles, Shri Ranjit Deshmukh was constituted on or about 27th March, 2000. The
report by the said Committee was submitted on 6.7.2000. It was stated that the Government dulyBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

considered the report of the said Committee and the Cabinet approved its recommendations on
11.10.2000.
DCR 58 was modified upon following the procedure under Section 37(1AA) of the MRTP Act and in
terms of the decision of the Cabinet. However, in a second affidavit affirmed by Shri Ramanand
Tiwari on 10th August, 2005, some clarification as regard the stand of the State was given. While
meeting the contentions raised by the Writ Petitioners, it was stated:
"I say that a reference to the Ranjit Deshmukh Committee has been made in my
earlier affidavit dated 22nd March, 2005. I say that in the said affidavit, the genesis
of the amended Regualtion 58 have been elaborately stated. I say that the Petitioner's
contention that the said report has not been disclosed by the State, is totally
unjustified and unwarranted. I say that when a mention of the said report has been
made in my earlier affidavit, the Petitioners could have sought a copy of the said
report from the State. Since the Petitioners have never done so as it can be presumed
that the Petitioners already have a copy of the said report in their possession but are
only putting a pretence that they do not have a copy. It is also unbelievable that the
Petitioners who otherwise have all the relevant information including various reports
on which they rely in the petition as filed as well as the amended petition do not have
a copy of the said Ranjit Deshmukh Committee Report. In any event, the State has no
objection to furnishing a copy of the report of the Ranjit Deshmukh Committee if the
Petitioners so desire."
The deponent of the said affidavit further denied and disputed the contention raised on behalf of the
petitioner that the Government intended to side with the private developers at the cost of the city as
a whole and had not made any amendment in furtherance of the Charles Correa Committee Report.
It was stated:
"I say that as stated in my earlier affidavit dated 22.3.2005, the State Government
has culled out certain recommendations of the Correa Committee as also certain
recommendations of the Ranjit Deshmukh Committee whilst coming to a conclusion
the need for, and thereafter incorporating suitable amendments to the said DCR 58."
The said stand of the State, however, underwent some change when the same deponent in his third
affidavit dated 17th August, 2005 in purported clarification of the earlier stand of the State stated:
"I am making this further affidavit in order to explain the position with regard to the
change made with regard to Regulation 58(1)(b) and the clarification issued on
March 28, 2003. The Ranjit Deshmukh Committee gave its report on July 06, 2000.
Thereafter, the report was circulated to all the concerned departments, the Urban
Development Department, the Labour Department, the Textile Department and the
Industries Department. A detailed Cabinet note was prepared for consideration by
the Cabinet which not only included the recommendations of the Ranjit Deshmukh
Committee report but also specifically the views of the various departments. On thisBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

aspect, the views of the Urban Development Department were that in view of the
prevailing regulation 58 which required sharing of lands after demolition under
Regulation 58(1)(b) the Mill Owners were not willing to come forward with proposals
since the same would not be viable for them. It was the view of the Department that
in order to make revival feasible and possible the area available after demolition of
existing structure should be excluded from computation of the land to be shared.
After the Cabinet decision, the then Secretary whilst formulating the amendments
and the proposed modification to regulation 58 specifically included the deletion of
the words beginning with "lands after demolition" upto "scheme to" and substitution
thereof by the words "balance FSI shall". This was the subject matter of Item (A-6) of
schedule I to the Public Notice which was issued on November 29, 2000."
Evidently, the Charles Correa Committee Report had not been given effect to, but the same as would
appear hereinafter had been taken note of by the Deshmukh Committee.
A fourth affidavit again came to be filed by the same deponent on 29th August, 2005.
REPORTS OF THE TWO COMMITTEES RELEVANCE It may also be of some interest to refer to
the report of the two Committees.
The State of Maharashtra appointed a committee headed by Shri Charles Correa, Architect/ Planner
in 1996. The development under 1991 Regulation was put on hold from 1996 to 2001. In Part I of the
Report, the Committee lamented that out of the 53 mills, they could gain access only to 26 mills.
They advocated for aggregation of mills. They identified those which were viable or considered
viable and suggested that the lands of unviable mills should be disposed of. It proposed a holistic
development of the mill lands. It also noticed the need for leaving open spaces. It took into
consideration other factors, namely, transport, urban form, open spaces and employment
generation. As regard open spaces, it stated:
"The Public Open Spaces proposed (see fig 23) vary in size from large Maidans to
small Neighbourhood Parks, so that a variety of different open-air activities can take
place. In front of the Railway Stations, large Pedestrian plazas have been proposed,
surrounded by shopping arcades (so that the people can pick up their vegetables and
other purchases on their way home  a classic pattern found all over Mumbai). Then
again, the principal roads can be widened and lined with trees, so that they are
converted into leafy boulevards."
A second committee was constituted but it did not submit any report. Another Committee was
constituted under the Chairmanship of Shri Ranjit Deshmukh, the then Minister for Textiles and
included a representative of all the Ministries and Departments concerned including the Urban
Development Department. The Committee appointed a sub- committee. The sub-committee inter
alia took into consideration the recommendations of the Charles Correa Study Group, prevailing
provisions belonging to textile mills, prevailing state of affairs with respect thereto, demands of the
National Textile Industries Board. It also held discussions with various bodies including the millBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

workers and mill owners as also MPs and MLAs of the town of Mumbai. It, however, carried out
actual site inspection of some textile mills only. The Committee recommended:
"Since rule 58(1)(a) contains the term "newly built-up", it is presumed that it permits
new construction. But, carrying out such new construction means using the balance
Floor Space Index and consequently using the adjoining open space. Thus, using
open space in this manner under the provisions of rule 58(1)(a) means indirectly to
override the provisions of rule 58(1)(b). Hence, in order to more clearly distinguish
the boundary line between rule 58(1)(a) and 58(1)(b) following amendments are
required to be carried out in this rule under section 37.
(a) The words "or newly" in rule 58(1)(a) should be excluded.
(b) The words "permissible FSI and" in rule 58(1)(a)(i) should be excluded.
(c) The words "FSC of 1.00 and" in rule 58(1)(a)(ii) should be excluded.
Upon making aforesaid changes the rule 58(1)(a) shall be limited to the extent of new use of the
existing buildings of the mills only and exercise of rule 58(1)(b) shall be regarding development of
the available open lands and land becoming vacant upon demolition of the existing buildings.
However, such development shall be subject to permissible FSI."
In Paragraph 19.1, it made some suggestions for giving encouragement to revival of mills stating:
"Hence the provisions of rule 58(1)(b) should be made more attractive and in order
to promote revival, the mills owners should be permitted to use the development
rights of the open lands, to be handed over to municipal corporation, in the lands of
their share as per column (5) of the aforesaid Table (even if such lands are situate in
Mumbai island) and for this purpose the prevailing provision of rule 58(1)(b) should
be amended as per section 37. Such recommendation is also made by the Korea (sic
Correa) Study Group."
It furthermore encouraged modernization of mills. It suggested certain incidental amendments also.
From what has been noticed hereinbefore, it is evident that as per the suggestion of Ranjit
Deshmukh Committee the words "or newly" were omitted as according to it, it may give rise to a lot
of confusion. From paragraph 18.8 of the report also, it appears that the said Committee suggested
use of different language, namely, "lands after demolition of structure". We find from the said report
that the Committee suggested a draft in respect of DCR 58(1)(b) of the Regulations. It is in that
context, we may have to consider the second affidavit affirmed by Shri Ramanand Tiwari when he
stated that the Cabinet had approved the report albeit not in its entirety.Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

The draft regulations thereafter were notified for considering the objections thereto, if any. Several
objections were filed, they were considered by the appropriate authority including the planning
authority. Evidently, the said two reports were considered by the Cabinet but it intended to give
more to the mill owners than what was recommended inter alia by introducing sub-regulation (6) of
DCR 58. The intent and purport of the State is apparent from DCR 58. It accepted a major part of
the recommendations of the Deshmukh Committee but thought that the mill owners should be given
something more.
PUBLIC INTEREST LITIGATION : SCOPE OF While entertaining a public interest litigation of this
nature several aspects of public interest being involved, the Court should find out as to how greater
public interest should be subserved and for the said purpose a balance should be struck and
harmony should be maintained between several interests such as (a) consideration of ecology; (b)
interest of workers
(c) interest of public sector institution, other financial institutions, priority claimed due to workers;
(d) advancement of public interest in general and not only a particular aspect of public interest; (e)
interest and rights of owners; (f) the interest of a sick and closed industry; and (g) schemes framed
by BIFR for revival of the company.
The courts in doing so would have to take into consideration a large number of factors, some of
which may be found to be competing with each other. It may not be proper to give undue
importance to one at the cost of the other which may ultimately be found to be vital and give effect
to the intent and purport for which the legislation was made. Scope of Public Interest Litigations in
view of several decisions of this Court has its own limitations. We would hereinafter notice a few of
them.
In Raunaq International Ltd. v. I.V.R. Constructions Ltd. & Ors. [(1999) 1 SCC 492], this Court
highlighted that the public interest litigation should not be a mere cloak. The court must be satisfied
that there is some element of public interest involved in entertaining such a petition. The court also
cautioned that before entertaining a writ petition and passing an interim order overwhelming public
interest should be taken into consideration therefor. It was further observed :
" It is important to bear in mind that by court intervention, the proposed project
may be considerably delayed thus escalating the cost far more than any saving which
the court would ultimately effect in public money by deciding the dispute in favour of
one tenderer or the other tenderer. Therefore, unless the court is satisfied that there
is a substantial amount of public interest, or the transaction is entered into mala fide,
the court should not intervene under Article 226 in disputes between two rival
tenderers."
In Ashok Lanka v. Rishi Dixit [(2005) 5 SCC 598], this Court opined:
" it is well settled that even in a case where a petitioner might have moved the Court
in his private interest and for redressal of personal grievances, the Court inBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

furtherance of the public interest may treat it necessary to enquire into the state of
affairs of the subject of litigation in the interest of justice."
This was also the view taken in Guruvayoor Devaswom Managing Committee v. C.K. Rajan [(2003)
7 SCC 546 at para 50], Shivajirao Nilangekar Patil v. Dr. Mahesh Madhav Gosavi [(1987) 1 SCC 227]
and Chairman & MD, BPL Ltd. v. S.P. Gururaja and Others, (2003) 8 SCC 567. In K.K. Bhalla v.
State of M.P. & Ors. [2006 (1) SCALE 238], it was stated:
"The Appellant has brought to the notice of the High Court that a malady has been
prevailing in the department of the State of Madhya Pradesh and the JDA. It may be
true that the Appellant did not file any application questioning similar allotments but
it is well-settled if an illegality is brought to the notice of the court, it can in certain
situations exercise its power of judicial review suo motu"
This Court times without number, however, has laid down the law as regard limited scope of public
interest litigation. It sounded note of caution for entertaining public interest litigation in service
matters [See Dr. B. Singh v. Union of India and Others, (2004) 3 SCC 363], in questioning the
validity or otherwise of a statute or when a statute is enacted in violation of the direction of a
superior court [See Ashok Kumar Thakur v. State of Bihar & Ors. [(1995) 5 SCC 403]. But, we cannot
also shut our eyes to the fact that this Court has entertained a large number of public interest
litigations for protection of environmental and/ or ecology. [See .M.C. Mehta group of cases and
T.N. Godavarman Thirumulpad v. Union of India and Others, (2006) 1 SCC 1] Public interest
litigations, thus, have been entertained more frequently where a question of violation of the
provisions of the statutes governing the environmental or ecology of the country has been brought to
its notice in the matter of depletion of forest areas and/ or when the executive while exercising its
administrative functions or making subordinate legislations has interfered with the ecological
balance with impunity. The High Court of Bombay, therefore, cannot be faulted with for
entertaining the writ petition as a public interest litigation.
PRINCIPLES OF INTERPRETATION Before us, the learned counsel appearing for the parties have
relied on several principles of interpretation of statute. The golden rule of interpretation is that
unless literal meaning given to a document leads to anomaly or absurdity, the principles of literal
interpretation should be adhered to. [See Compack (P) Ltd. v. CCE, (2005) 8 SCC 300,
Gurudevdatta VKSSS Maryadit v. State of Maharashtra, (2001) 4 SCC 534, Dayal Singh v. Union of
India, (2003) 2 SCC 593 and Swedish Match AB v. Securities and Exchange Board, India, (2004) 11
SCC 641]. The learned Judges of the High Court as also this Court have been taken through the
provisions of the MRTP Act, those of the DCR and in particular DCR 58 as framed in 1991 as well as
in 2001 times without number. With the assistance of different counsel appearing for different
purpose, we have read, re-read and re-read several provisions. Before us, several principles, canons
and rules of interpretation have been emphasized. We have not only been taken through various
decisions of this Court but also various authorities and treatises dealing with the subject of
interpretation of statutes.Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

We have also been asked by the learned counsel for the parties to interpret the impugned legislation
in the light of constitutional scheme and in particular Articles 14 and 21 of the Constitution of India,
the provisions of the MRTP Act, the doctrine of sustainable development and various other
principles. In the aforementioned situation, it is not possible for us to take recourse to the golden
rule.
As would appear from the discussions made hereinafter, we are, however, of the opinion that for
correct interpretation of DCR 58, the principles of purposive interpretation should be applied.
In Francis Bennion's Statutory Interpretation, purposive construction has been described in the
following manner:
'A purposive construction of an enactment is one which gives effect to the legislative
purpose by
(a) following the literal meaning of the enactment where that meaning is in
accordance with the legislative purpose (in this Code called a purposive-and-literal
construction), or
(b) applying a strained meaning where the literal meaning is not in accordance with
the legislative purpose (in the Code called a purposive-and-
strained construction).' In K.L. Gupta & Ors. v. The Bombay Municipal Corporation and Ors. [1968
(1) SCR 274], it was stated:
"Before examining the contentions on the points of law raised in this case, it is
necessary to appreciate what the Act sought to achieve and why it was brought on the
statute book. In order to do this, it is necessary to take stock of the position at the
time of its enactment so that attention may be focussed on the situation calling for a
remedy and how the legislature sought to tackle it..."
However, the pith of this statement has now found form in the doctrine of purposive construction,
as accepted by this Court in several cases.
In Maruti Udyog Ltd. v. Ram Lal and Others [(2005) 2 SCC 638], while interpreting the provisions
of Industrial Disputes Act, 1947, the rule of purposive construction was followed.
In Reserve Bank of India v. Peerless General Finance and Investment Co. Ltd. [(1987) 1 SCC 424]
this Court stated:
"If a statute is looked at, in the context of its enactment, with the glasses of the
statute-maker, provided by such context, its scheme, the sections, clauses, phrases
and words may take colour and appear different than when the statute is looked at
without the glasses provided by the context. With these glasses we must look at theBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

Act as a whole and discover what each section, each clause, each phrase and each
word is meant and designed to say as to fit into the scheme of the entire Act"
In 'The Interpretation and Application of Statutes', Reed Dickerson, at p.135 discussed the subject
while dealing with the importance of context of the statute in the following terms:
'... The essence of the language is to reflect, express, and perhaps even affect the
conceptual matrix of established ideas and values that identifies the culture to which
it belongs. For this reason, language has been called "conceptual map of human
experience".' In Punjab Land Development and Reclamation Corpn. Ltd. v. Presiding
Officer, Labour Court, Chandigarh [(1990) 3 SCC 682], this Court referred to the
following passage from Hans Kelsen's Pure Theory Law of Law:
"The legal act applying a legal norm may be performed in such a way that it
conforms (a) with the one or the other of the different meanings of the legal norm, (b)
with the will of the norm- creating authority that is to be determined somehow, (c)
with the expression which the norm- creating authority has chosen, (d) with the one
or the other of the contradictory norms, or (e) the concrete case to which the two
contradictory norms refer may be decided under the assumption that the two
contradictory norms annul each other. In all these cases, the law to be applied
constitutes only a frame within which several applications are possible, whereby
every act is legal that stays within the frame."
[See also High Court of Gujarat v. Gujarat Kishan Mazdoor Panchayat, (2003) 4 SCC 712, Indian
Handicrafts Emporium and Others v. Union of India and Others, (2003) 7 SCC 589 and Deepal
Girishbhai Soni and Others v. United India Insurance Co. Ltd., Baroda, (2004) 5 SCC 385, para 56]
In Balram Kumawat v. Union of India and Others, [(2003) 7 SCC 628], this Court held that if special
purpose is to be served even by a special statute, the same may not always be given any narrow and
pedantic, literal and lexical construction nor doctrine of strict construction should always be
adhered to.
In Pratap Singh v. State of Jharkhand and Another [(2005) 3 SCC 551], this Court emphasized
assignment of contextual meaning to a statute having regard to the constitutional as well as
international law operating in the field. Strict adherence to the procedure, subject to just exceptions,
was highlighted therein.
However, in P.S. Sathappan (Dead) By LRS. v. Andhra Bank Ltd. and Others [(2004) 11 SCC 672], it
was observed that in the guise of purposive construction one cannot interpret a section in a manner
which would lead to a conflict between two sub-sections of the same section. Having noticed the
principles of purposive construction, we may take note of certain other principles which are
necessary to be considered for proper interpretation of DCR 58.
It is well-settled principle of law that in the absence of any context indicating a contrary intention,
the same meaning would be attached to the word used in the latter as is given to them in the earlierBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

statute. It is trite that the words or expression used in a statute before and after amendment should
be given the same meaning. When the legislature uses the same words in a similar connection, it is
to be presumed that in the absence of any context indicating a contrary intention, the same meaning
should attach to the words. In Venkata Subamma and another v. Ramayya and others [AIR 1932 PC
92], it is stated that an Act should be interpreted having regard to its history and the meaning given
to a word cannot be read in a different way than what was interpreted in the earlier repealed section.
It is also a fundamental proposition of construction that the effect of deletion of words must receive
serious consideration while interpreting a statute as this has been repeatedly affirmed by this Court
in a series of judgments. [See Commr. Of Income-tax/Excess Profits Tax, Bombay City v. Messrs.
Bhogilal Laherchand including Batliboi and Co., Bombay, AIR 1954 SC 155, The Mangalore Electric
Supply Co. Ltd. v. The Commissioner of Income Tax, West Bengal, (1978) 3 SCC 248, His Holiness
Kesavananda Bharati Sripadagalvaru v. State of Kerala and Another, (1973) 4 SCC 225 and M/s.
Onkarlal Nandlal v. State of Rajasthan and Another (1985) 4 SCC 404].
It is furthermore well-known that when the statute makes a distinction between the two phrases and
one of the two is expressly deleted, it is contrary to the cardinal principle of statutory construction to
hold that what is deleted is brought back into the statute and finds place in words which were
already there in the first place.
In Charles Bradlaugh v. Henry Lewis Clarke [(1883) 8 AC 354], Lord Watson as regards conscious
omission from the statute stated the law, thus:
"I see no reason to suppose that all these omissions were accidental, and as little
reason to suppose that the enactments with regard to personal disabilities were
intentionally left out, whilst the express mention made of common informers was
omitted through accident or inadvertence."
It is also a well-settled principle of law that common sense construction rule should be taken
recourse to in certain cases as has been adumbrated in Halsbury's Laws of England (Fourth Edition)
Volume 44(1) (Reissue). We would refer to the said principle in some details later.
INTERPRETATION OF ACT AND REGULATIONS DCR 58 has been attempted to be interpreted in
more than one manner by the learned counsel appearing for the parties. DCR 58 was made to revive
and resurrect neighbourhoods, foster development, regenerate lands which had become sterile,
encourage the shifting of textile mills (thereby reducing the attendant strain and industrial activity
places on civil amenities) and pay off chronic arrears and dues of workers, banks institutions,
statutory dues, etc. In its operation and implementation new DCR 58 would also unlock large real
estate and make it available to residents.
A statute, it is well known, is to be read as a whole. Subordinate legislation indisputably has to be
read in the light of the provisions of the Act whereunder it has been made. It, however, must be read
having regard to the purpose and object for which the statute is made. The MRTP Act provides for
formulation of regional plans and development plan. The planning authority, before a plan is
finalized, is required to see that the provisions thereof have been fully complied with. The MRTP ActBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

provides for appointment of a town planning officer who possesses requisite qualification. The
MRTP Act lays down the matters which are mandatorily required to be considered by the planning
authority in all the stages, namely, survey, preparation, submission and sanction of development
plan. While doing so, it is bound to take into consideration a large number of factors as specified
therein. The State has been conferred with a special power to frame development control regulations
in terms of Section 159(2) of the MRTP Act. Development Control Regulations have been framed in
terms of the said provisions. The State has furthermore been given a power to supervise and
maintain control over the planning authorities. Such control may be exercised in more than one
manner. The planning authority is not only required to obtain statutory sanction and approval
wherever applicable, but the State, has also been conferred with a special power to make a
development plan subject, of course, to the condition that the same shall not change the character of
such development plan.
Section 22 of the MRTP Act provides for the contents of the development plan, i.e., to be divided
into several areas for allocating the use of land for the purposes as, for example, residential or
commercial, proposals for designation of land for public purposes, proposal for designation of areas
for open spaces, playgrounds, stadia, zoological gardens, green belts, nature reserves, sanctuaries,
dairies, transports and communications, such as roads, highways, parkways, railways, waterways,
canals and airports, including their extension and development, water supply, drainage, sewerage,
etc. and reservation of land for community facilities and services. Whereas designation and/ or
reservation of areas for certain public purposes would vary from place to place, ut must take care of
not only the public purposes but also several others including open spaces. Water supply, drainage,
sewerage, and other public utilities including electricity and gas or highways or waterways, schools,
etc., however, would be considered to be equally important.
A planning authority, therefore, must take into consideration all the relevant factors, although in a
given case, one gets priority over the other. Ordinarily, it would not be for the court to substitute its
decision to that of the planning authority unless an appropriate case is made out therefor. When,
however, question of public interest comes up, the court indisputably would try to delicately balance
the different factors, if possible. Both open space as also the other factors relevant for making the
regulation would be in public interest. The question would, however, be as to which is of greater
public interest. Public interest, thus, would be a relevant factor also for interpretation of the statute.
Public interest so far as maintenance of ecology is concerned pertains to a constitutional scheme
comprising of Articles 14, 21, 48A and 51A(g) of the Constitution of India, the other factors are no
less significant. [See also T.N. Godavarman Thirumalpad vs. Union of India and Others, (2002) 10
SCC 606, N.D. Jayal and Another vs. Union of India and Others, (2004) 9 SCC 362 and Vellore
Citizens' Welfare Forum vs. Union of India and Others, (1996) 5 SCC 647]. All concerned, namely,
operating agencies, the State Government, the National Textile Mills as also BIFR interpreting the
said regulation opined that sharing of land is imperative, but the question remains, to what extent?
Whether radical changes were made in the year 2003, when the State made the aforementioned
clarification would again be a question which is required to be posed and answered. Was such a
clarification in consonance with the reports of Charles Correa Committee and the Ranjit Deshmukh
Committee? Did 2000 acres of vacant land which would have been otherwise available come down
to 50 acres? Had any balance been struck between the original concept of sharing of lands byBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

Bombay Municipal Corporation, MHADA and the mill owners? It is in the aforementioned
backdrop, the nature of change must be considered. The amendment in 2001, therefore, must be
interpreted having regard to the provisions of the MRTP Act which professed increase in the
ecological interest by providing more open space and not decreasing the same, but again the
question would be "was there any reduction"? The amendments in the regulation must be construed
in furtherance of the legislative policy and not in derogation thereof. But, while doing so, the past
experience of the State which paved the necessities for modifying the earlier regulation should not
be forgotten. A statutory scheme herein also by way of Section 22 clearly speaks about open spaces.
The Legislative Act confers guidelines which advocates the necessity of environmental impact
assessment. The State, when it exercises its power under Section 37 of the MRTP Act is required to
act within the four-corners of the Act. Any modification or amendment must address the
environmental consequences together with other relevant factors. As a logical corollary, it must also
be determined as to whether the amendments amounted to a minor modification or substantive one.
Literal interpretation of the Act and the Rules would give rise to many anomalies. It would not
advance the object and purport of the Act. It would also create difficulties in implementing the
statutory scheme. Having said so, we have no other option but, as indicated hereinbefore, to take
recourse to the principles of purposive construction and interpret DCR 58 in accordance with the
scope and object of the Act. For the said purpose, we may also have to consider various aspects of
the matter. We would make an attempt in this behalf.
SCOPE OF JUDICIAL REVIEW VIS-@-VIS LEGISLATIVE POLICY A policy decision, as is well
known, should not be lightly interfered with but it is difficult to accept the submissions made on
behalf of the learned counsel appearing on behalf of the Appellants that the courts cannot exercise
their power of judicial review at all. By reason of any legislation whether enacted by the legislature
or by way of subordinate legislation, the State gives effect to its legislative policy. Such legislation,
however, must not be ultra vires the Constitution. A subordinate legislation apart from being intra
vires the Constitution, should not also be ultra vires the parent Act under which it has been made. A
subordinate legislation, it is trite, must be reasonable and in consonance with the legislative policy
as also give effect to the purport and object of the Act and in good faith. In P.J. Irani v. The State of
Madras [(1962) 2 SCR 169], this Court has clearly held that a subordinate legislation can be
challenged not only on the ground that it is contrary to the provisions of the Act or other statutes;
but also if it is violative of the legislative object. The provisions of the subordinate legislation can
also be challenged if the reasons assigned therefor are not germane or otherwise mala fide. The said
decision has been followed in a large number of cases by this Court. [see also M/s. Punjab Tin
Supply Co., Chandigarh and Others vs. Central Government and Others, (1984) 1 SCC 206].
It is interesting to note that in Secretary, Ministry of Chemicals & Fertilizers, Government of India v.
Cipla Ltd. & Ors. [(2003) 7 SCC 1], this Court opined :
"It is axiomatic that the contents of a policy document cannot be read and interpreted
as statutory provisions. Too much of legalism cannot be imported in understanding
the scope and meaning of the clauses contained in policy formulations. At the same
time, the Central Government which combines the dual role of policy-maker and the
delegate of legislative power, cannot at its sweet will and pleasure give a go-by to theBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

policy guidelines evolved by itself in the matter of selection of drugs for price control.
The Government itself stressed on the need to evolve and adopt transparent criteria
to be applied across the board so as to minimize the scope for subjective approach
and therefore came forward with specific criteria. It is nobody's case that for any good
reasons, the policy or norms have been changed or have become impracticable of
compliance."
[Emphasis supplied] The parameters of judicial review in relation to a policy decision would depend
upon the nature as also the scope and object of the legislation. No hard and fast rule can be laid
down therefor. The court normally would not, however, interfere with a policy decision which has
been made by experts in view of the fact that it does not possess such expertise. Divergent opinions,
however, have been expressed by the authorities in this behalf. The scope and extent of judicial
review of legislation, it is trite, would vary from case to case.
Reliance has been placed by the Appellants on Maharashtra State Board of Secondary and Higher
Secondary Education and Another v. Paritosh Bhupesh Kuamr Sheth and Ors. [(1984) 4 SCC 27]
wherein this Court was concerned with a regulation laying down the terms and conditions for
revaluating the answer papers. Indisputably, there exists a distinction between regulations, rules
and bye-laws. The sources of framing regulations and bye-laws are different and distinct but the
same, in our opinion, would not mean that the court will have no jurisdiction to interfere with any
policy decision, legislative or otherwise.
In R.K. Garg v. Union of India & Ors. [(1981) 4 SCC 675], this Court noticed that the legislature is
presumed to understand and correctly appreciate the needs of its own people, but the same again
would not mean that judicial review of legislation is impermissible. In Balco Employees Union v.
Union of India [(2002) 2 SCC 333], this Court while dealing with new economic policies of the
elected government held:
"Any such change may result in adversely affecting some vested interests. Unless
any illegality is committed in the execution of the policy or the same is contrary to
law or mala fide, a decision bringing about change cannot per se be interfered with by
the court.
Wisdom and advisability of economic policies are ordinarily not amenable to judicial
review unless it can be demonstrated that the policy is contrary to any statutory
provision or the Constitution. In other words, it is not for the courts to consider
relative merits of different economic policies and consider whether a wiser or better
one can be evolved. For testing the correctness of a policy, the appropriate forum is
Parliament and not the courts"
The embargo as regard exercise of power of judicial review may not be beyond the aforementioned
dicta.Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

Here, however, we are not at all dealing with an economic policy of the State, but a special planning
statute of which economic factor is only one of the components. Even then, it has no bearing with
the economic policy affecting the State or general public. DCR 58 deals with only a class of people 
who owned and possessed cotton textile mills and want revival/ rehabilitation of their sick or closed
textile mills or intend to modernize or shift their mills.
We may notice that in State of Rajasthan & Ors. v. Basant Nahata [AIR 2005 SC 3401], it was
pointed out :
"The contention raised to the effect that this Court would not interfere with the policy
decision is again devoid of any merit. A legislative policy must conform to the
provisions of the constitutional mandates. Even otherwise a policy decision can be
subjected to judicial review"
Furthermore, interpretation of a town planning statute which has an environmental aspect leading
to application of Articles 14 and 21 of the Constitution of India cannot be held to be within the
exclusive domain of the executive.
There cannot be any doubt whatsoever, that the validity and/or interpretation of a legislation must
be resorted to within the parameters of judicial review, but it is difficult to accept the contention that
it is totally excluded.
Unreasonableness is certainly a ground of striking down a subordinate legislation. A presumption as
to the constitutionality of a statute is also to be raised but it does not mean that the environmental
factors can altogether be omitted from consideration only because the executive has construed the
statute otherwise.
It is interesting to note that the scope of judicial review is now being expanded in different
jurisdictions. Even judicial review on facts has been held to be permissible in law. [See Manager,
Reserve Bank of India, Bangalore v. S. Mani and Others, (2005) 5 SCC 100, Sonepat Cooperative
Sugar Mills Ltd. v. Ajit Singh, (2005) 3 SCC 232 and Cholan Roadways Ltd. v. G.
Thirugnanasambandam, (2005) 3 SCC 241]. In Anil Kumar Jha v. Union of India, (2005) 3 SCC 150,
it was held that in an appropriate case, the Supreme Court may even interfere with a political
decision including an action of the Speaker or Governor of the State although it may amount to
entering into a political thicket. [See also Rameswar Prasad & Ors. v. Union of India & Anr. 2006 (1)
SCALE 385]. Furthermore, there are innumerable cases where this Court has even issued directions
despite the fact that the field is covered by some statute or subordinate legislation. Such directions
issued are clear pointers to show that when a question involving greater public interest or public
good including enforcement of fundamental right arises, this Court bestowed enormous
consideration to public interest. [See Vineet Narain and Others v. Union of India and Another,
(1996) 2 SCC 199, Union of India and Another v. C. Dinakar, IPS and Others, (2004) 6 SCC 118 and
Kapila Hingorani v. State of Bihar, (2003) 6 SCC 1].Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

Such directions have more often than not been issued even where the question involved relates to
enforcement of a human right or environmental aspects. Interpretation and application of
constitutional and human rights had never been limited by this Court only to the black letter of law.
Expansive meaning of such rights had all along been given by the Courts by taking recourse to
creative interpretation which lead to creation of new rights. By way of example, we may point out
that by interpreting Article 21, this Court has created new rights including right to environmental
protection.
The Wednesbury principles to which reference has been made in The Trustees of the Port of Madras
v. M/s Aminchand Pyarelal and Ors. [(1976) 3 SCC 167] in some jurisdiction are being held to be not
applicable in view of the development in constitutional law in this behalf. [See e.g. Huang and
Others v. Secretary of State for the Home Department [(2005) 3 All. ER 435], wherein referring to
R. v. Secretary of State of the Home Department, ex. P Daly [(2001) 3 All ER 433], it was held that in
certain cases, the adjudicator may require to conduct a judicial exercise which is not merely more
intrusive than Wednesbury, but involves a full-blown merits judgment, which is yet more than Ex p.
Daly requires on a judicial review where the court has to decide a proportionality issue. Law is never
static; it changes with the change of time. [See Motor General Traders and Anr. v. State of Andhra
Pradesh and Ors.,(1984) 1 SCC 222 and John Vallamattom v. Union of India, (2003) 6 SCC 611].
For the foregoing reasons, we are of the opinion that in cases where constitutionality and/ or
interpretation of any legislation, be it made by the Parliament or an executive authority by way of
delegated legislation, is in question, it would be idle to contend that a court of superior jurisdiction
cannot exercise the power of judicial review. A distinction must be made between an executive
decision laying down a policy and executive decision in exercise of its legislative making power. A
legislation be it made by the Parliament/ Legislature or by the executive must be interpreted within
the parameters of the well-known principles enunciated by this Court. Whether a legislation would
be declared ultra vires or what would be the effect and purport of a legislation upon interpretation
thereof will depend upon the legislation in question vis-`-vis the constitutional provisions and other
relevant factors. We would have to bear some of the aforementioned principles in mind while
adverting to the rival contentions raised at the bar in regard to interpretation of DCR 58 as well as
constitutionality thereof.
DCR 58 : INTERPRETATION For the purpose of interpretation of DCR 58, it may be beneficial to
notice the changes effected by 2001 Regulations vis-`-vis 1991 Regulations:
Old DCR 58 New DCR 58
58. Development or redevelopment of lands of cotton textile mills;
(1) Lands of sick and/or closed cotton textile mills. - With the previous approval of the
Commissioner to a layout prepared for development or redevelopment of the entire open land
built-up area of the premises of a sick and/or closed cotton textile mill, and on such conditions
deemed appropriate and specified by him, and as a part of a package of measures recommended by
the Board of Industrial and Financial Reconstruction (BIFR), Financial Institutions andBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

Commissionerate of Industries for the revival/rehabilitation of a potentially viable sick mill, the
Commissioner may allow;
(a) The existing or newly built-up areas to be utilised-
(i) for the same cotton textile or related user subject to permissible FSI and observance of all other
Regulations;
(ii) for diversified industrial users in accordance with the industrial location policy, with office space
only ancillary to and required for such users, subject to FSI of 1.00 and observance of all other
Regulations;
(iii) for commercial purposes, as permitted under these Regulations:
Provided that in the Island City, the area used for office purposes shall not exceed
that used earlier for the same purpose.
(b) Open lands and lands after demolition of existing structures in case of a
redevelopment scheme to be used as in the Table below
58. Development or redevelopment of lands of cotton textile mills;
(1) Lands of sick and/or closed cotton textile mills. -- With the previous approval of the
Commissioner to a layout prepared for development or redevelopment of the entire open land
built-up area of the premises of a sick and/or closed cotton textile mill, and on such conditions
deemed appropriate and specified by him, and as a part of a package of measures recommended by
the Financial Institutions and Commissionerate of Industries for the revival/rehabilitation of a
potentially viable sick and/or closed mill, the Commissioner may allow;
(a) The existing built-up areas to be utilised-
(i) for the same cotton textile or related user subject to observance of all other Regulations;
(ii) for diversified industrial users in accordance with the industrial location policy, with office space
only ancillary to and required for such users, subject to and observance of all other Regulations;
(iii) for commercial purposes, as permitted under these Regulations;
Provided that in the Island City, the area used for office purposes shall not exceed that used earlier
for the same purpose.
(b) Open lands and balance FSI shall be used as in the Table below A bare comparison of the said
provisions would show that in sub- regulation (1) of DCR 58, the language remains the same.
However, in clause (a) thereof the words "or newly" have been omitted in the 2001 Regulations.Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

Clause (a) of sub-regulation (1) provides for change of user in relation to the existing built-up area,
subject to the recommendations of BIFR as a package. The question as to whether the mills which
are closed but were not referred to BIFR come within the purview of the said clause would be dealt
with a little later.
Sub-regulation (1) of DCR 58 provides for an approval of the Commissioner to a layout prepared for
the development or redevelopment of the entire open land as well as built-up area of the premises of
a sick and/or closed textile mill. For the purpose of grant of sanction as regards change of user, the
Commissioner may specify certain conditions as it may deem appropriate. Such an approval was
sought to be a part of the measure of the package recommended by BIFR for the
revival/rehabilitation of a potentially viable sick mill. Only if such conditions are specified, clause
(a) shall apply which provides for change of user relating to existing built-up area. We have noticed
hereinbefore that Regulation 56(3)(b) and Regulation 57(4)(c) also makes specific provisions for
grant of change of user in respect of sick mills as a part of a package of measures recommended by
BIFR.
The drastic changes have, however, been made in clause (b) of Sub- regulation (1) of DCR 58. It
refers to a case of redevelopment. In clause (b) the words "after demolition of existing structures in
case of a redevelopment scheme" have been deleted.
DCR 58 as made in 1991 consisted of four different concepts:
(1) Existing built up areas;
(2) Newly built up areas in DCR 58(1)(a); (3) Open land and (4) Lands after
demolition of existing structures in the case of a redevelopment scheme in DCR
58(1)(b).
It is not in dispute that the scheme framed thereunder did not work or in any event did not work to
the satisfaction of all the mill owners and other players including the State.
In view of the limited options contained therein and the consequences flowing therefrom in terms of
the Old Regulations a mill owner could
(i) continue to use the existing cotton textile mill;
(ii) redevelop the existing structure without changing its shell and without touching the open land in
which event, no sharing of land or structure was necessary;
(iii) retain existing structure and develop the open land in which event the mill owners were
required to share 2/3rd of the open land used;
(iv) demolish the existing structures and develop the entire land, meaning thereby, the open land as
also the land available after demolition of the existing structure in which event sharing of entire landBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

was contemplated.
We have noticed that only five mills opted in terms of the old Regulation. Hardly any development
took place. Thus, most textile mills continued with status quo. Closed mills remained closed,
workers had not been paid their wages, banks and financial institutions did not receive back their
dues. Even the statutory dues and taxes continued to mount. The structures might have become
more dilapidated and ten years went down the line in the aforementioned scenario. Even otherwise,
mills like Phoenix Mills retained more than 100 years old shell and glassed it up and even in the said
shell, malls, supermarkets, night clubs and restaurants were constructed. Thus, it resulted in
unplanned and unregulated development. It is in that situation, the State might have thought that
workable changes are necessary wherefor, after taking into consideration some reports, they had
come out with a draft. When the draft was published in terms of Section 37(1AA) of the MRTP Act,
24 objections were received. The writ petitioners admittedly were not amongst them. The said
objections were placed before the planning authorities. The Bombay Municipal Corporation had also
put inputs as a planning authority. Only thereafter the matter went back to the State.
The effect of amendment in clause (b) must be seen from the Table appended thereto. In terms of
the Old Regulation in respect of land covering more than 10 hectares, for green area 33% land was to
be set apart, and for MHADA 37% thereof, whereas the owner retained 30%. Under the new DCR
58, admittedly the owner of the mill at least obtains construction rights over 63% of the land as the
land in terms of Column 3 gets loaded in Column 5. The mill owner furthermore even according to
the writ petitioners gets TDR of 37%. Open land in clause (b) is what is not covered by the built-up
area. The balance FSI, indisputably, is not open area. The meaning of 'open land' must be construed
as land other than land required to sustain the built up area. We may now attempt to understand the
effect of FSI having regard to a concrete example. If the area of a plot is 1000 sq. m., applying the
FSI of 1.33, a person will be entitled to construct a built up area of 1330 sq. m. If he intends to build
a two-storeyed building, he will utilize 665 sq. m. of land whereas in a case of ground plus four
storeyed building, he will be using 266 sq. m. of land and in case of nine storeyed structure, he will
be using only 133 sq. m. The greater the height of the building, more lands will be available either by
way of public green or private green as also for MHADA. However, in such a case, the plinth area
will vary significantly. Whereas in the first case, it would be 665 sq. m., in the third case, it would
only be 133 sq.m. although the built up area remains the same. Taking the illustration as mentioned
hereinbefore, the open land in each case shall vary. Thus, open land would not mean land occupied
by the plinth but would mean land other than that is necessary to sustain the built up area.
We do not accept the contention of Mr. Salve that clause (b) applies to open land as also lands after
demolition of existing structure in case of a redevelopment scheme and only because the words "and
lands after demolition of existing structures" had been deleted, the same may not be of much
significance inasmuch as clause (b) of the new regulations will have to be construed in the light of
clause (a). It will bear repetition to state that whereas clause (a) refers to change of user in relation
to the existing built-up area, clause (b) provides for open lands. The manner in which the
development and/ or redevelopment should take place has been clubbed in sub-regulation (1) of
DCR 58 read with sub-regulation (6) thereof. For proper interpretation, all the relevant provisions
are required to be read harmoniously.Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

DCR 58(1)(a) deals with a case of non-sharing of a land as is evident from the fact that no sharing
percentage is provided therein. It, therefore, envisages change of user for the three purposes
mentioned therein, in the event the existing built-up area is utilized. In terms of the said provision,
the internal area of such structure remains the same although they can be redesignated or
reconstructed. The only benefit conferred by reason thereof is grant of change of user indicated
therein. The State while making this regulation contemplated that the change of user would enable
earning of additional sums of money from the assets which were unproductive. Clause
(b), however, expressly provides for sharing of land as specified in the Table therein. The question,
however, is as to what would be the extent of open land available on the spot.
Existing built-up area, in our view, would not be open land. We have also to take note of the fact that
the newly built-up area, as existing in the old clause (a) of sub-Regulation (1) of DCR 58 has been
omitted, the effect whereof would be noticed a little later.
We are not oblivious of the fact that the word "and" has been used twice in sub-regulation (1) of
DCR 58. It ordinarily shall be read conjunctively and not disjunctively. However, for the purpose of
giving effect to the said provisions, the rule of purposive construction is required to be taken
recourse to. Sub-regulation (1) speaks of entire open land as well as built-up area. It speaks of the
necessity of having the recommendation of BIFR as a package of measures. Such recommendations
must be for the revival/rehabilitation of a potentially viable sick mill. The provisions, therefore, may
not apply to a mill which is neither sick nor otherwise not potentially viable, subject, of course, to
the explanation contained in Note
(vi) appended thereto as also sub-regulation (6) thereof. For the aforementioned purpose, let us at
this juncture also notice the tables appended to clause (b) of sub-Regulation (1) of DCR 58. Column
(2) of the Table refers to the extent of land. Column (3) provides for percentage to be earmarked for
recreation ground/ garden, playground or any other open user as specified by the Commissioner.
Column (4) refers to percentage to be earmarked and handed over for development by MHADA for
public housing/ for mill worker's housing as per guidelines approved by the Government to be
shared equally. Column (5) provides for percentage to be earmarked and to be developed for
residential or commercial user (including users permissible in residential or commercial zone as per
these regulations or diversified industrial users as per Industrial Location Policy) to be developed by
the owner. There is no change in Note (i) or Note (ii). Changes have been made in Note (iii) and
Notes (iv), (v) and (vi) have been added. Interestingly, from Note (iii), after the words "Transferable
Development Rights as in Appendix VII" and before the words "in respect of the lands earmarked
for open spaces in column (3)", the expression "only" has been omitted. Thus, whereas earlier
transferable development rights could be granted only for the purpose of the open lands which were
to be handed over to MCGM, i.e., about 33%, now apart from that, development rights in respect of
lands earmarked and handed over as per Column (3) have been made available to the mill owners
for utilization thereof as per Column (5) as TDR as aforesaid. The mill owner, therefore, gets FSI of
1.33. He, furthermore, gets corresponding TDR to be utilized in the sub-urbs area or to sell the
same. The idea appears to be to give more FSI and TDR to the person who surrenders the lands.Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

Things, however, may be different in a case where the mill owner demolishes a portion of the
existing structure and construct new areas so as to be called 'newly built-up' area on that part of the
land remaining the other part of the structure that it will come within the purview of clause (a)
inasmuch as approval for development would be necessary for the newly built-up area for change of
user. In such a case, requirements of clause (b) were not required to be complied with as it would
squarely fall within the purview of clause (a).
The omission of the words "or newly" from clause (a) provides for a guideline. If the entire structure
is to be demolished, the newly built-up area will have to be in terms of clause (b) read with
sub-regulation (6). Such newly built-up structure, having regard to omission from clause (a) would
have no role to play if no built-up area existed. Thus, all new constructions including constructions
on lands after demolition of the existing structure and new constructions whether under a
development or redevelopment scheme would be covered by clause (b) read with sub-regulation (6)
thereof. If new constructions are raised, FSI, in a case of such development or redevelopment, being
covered by clause (b) would be for the entire plot, except the built-up area which was existing, FSI
having regard to its statutory definition would, thus, have to be calculated having regard to the ratio
of the total construction to the area of the plot except the land component of the existing built up
area.
There is no dispute as regard grant of better facility to the mill owners through TDR. The only
dispute is what meaning should be attributed to the expression `balance FSI'.
In order to determine whether vital changes have been effected by way of the amendment of 2001,
both the sub-clauses of sub-regulation (1) would be necessary to be taken into consideration for
construing the words "balance FSI".
The expression "balance" would mean "apart from" which in turn would mean apart from the area
for which protection has already been given. Balance FSI would, thus, mean FSI which is available
for construction after excluding the FSI relatable to an already consumed by the existing built-up
structure.
Both the phrases "open lands" as also "balance FSI" contained in DCR 58(1)(b) play significant role.
The word "balance" is crucial which would naturally mean FSI which is available to be utilized upon
open land. Such balance FSI must be apart from the existing FSI. Indisputably, the built-up area had
consumed some FSI and, thus, when the expression "balance FSI" is used, the same would mean
additional built-up area. It contemplates that where the entire plot has been used by existing
built-up areas and some open land has been left out on the remaining non-built up area of the plot
additionally unconsumed FSI could be used. It is in that sense separate. It is true that DCR 58(1)
uses the word entire land but the said expression is followed by the expression "built-up area".
"Balance FSI" in the aforementioned situation would not mean the FSI which is involved for the
purpose of construction of structures not only on the open land which had been existing but also the
land which had become open by reason of the demolition of the existing structures. It is only in that
sense, as would be amplified from the discussions made hereinafter that the State intended to give
additional protection to the mill owners. If open land is given its natural or dictionary meaning, noBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

distinction could be made in between DCR 58(1)(a) and DCR 58(1)(b), which ex facie would lead to
an anomaly.
In view of the fact that the built up area was to be protected in terms of sub-regulation (1) of DCR
58, a'fortiori the land component thereof could be protected under clause (b) thereof. Thus, the
same land which was protected under clause (a) could not become shareable under clause (b) which
would render the distinction between the said provisions otiose. Balance FSI on open lands or
otherwise had also been used in sub-regulation (5) of DCR 58. It also, thus, gives a significant clue to
find out the meaning of balance FSI. Additional reason for the aforementioned conclusion is that
development or redevelopment of entire open land and built up area of the premises referred to in
DCR 58(1), in the event, the findings of the High Court are accepted, there would not be any
necessity for the State to use two different words "open land" and "built-up area" separately and
distinctly. The words "built-up area" find its source from the definition of existing building, as
noticed hereinbefore. The existing built-up area was not to be shared and the same if read with the
word "existing", it may be contrasted with a built-up area additionally but separate and distinct from
the old existing built-up area. The existing built-up area, thus, was sought to be protected which
would mean that they were sought to be protected from non-shareable land component thereof. It is
thus possible to come to the conclusion that the obligation to share was intended to be absent only
so long as no additional built-up area was created. In a case where the existing structure is
demolished in part, the balance FSI would be available but in relation to the entire open lands, FSI
has to be calculated taking into account the area of open land appurtenant to the existing structures.
Thus, no basic change had been effected in drafting the regulation to segregate newly built-up areas
from existing built-up areas. It cannot be denied that the State intended to give more benefits to the
mill owners by reason of 2001 Regulations and, thus, if after demolition of the entire structure the
whole plot is treated to be open land and FSI is calculated on the basis thereof the purport and
object of the amendment will be defeated. The fact that the State intended to consider the matter
relating to amendment having regard to the fact that there had hardly been any takers for the 1991
Scheme as it failed to provide sufficient incentives, cannot be ignored.
Indisputably, though, the Regulations made by the State which is a piece of subordinate legislation
should be read in the light of the statutory scheme made under the legislative act as also having
regard to the constitutional scheme as contained in Articles 14, 24, 48-A and 51-A(g) of the
Constitution of India, but while doing so the effect and purport for which such amendment were
brought about cannot be lost sight of. The amendments carried out in the MRTP Act from time to
time and clearly the provisions of Sub-section (2) of Section 26 of the MRTP Act point out that the
State had been leaning towards environmental aspects but that was not the sole objective.
The title of the regulation reads as a modification to DCR 58. It was, therefore, not in substitution of
the resolution of 1991 nor was it framed by way of recasting thereof.
In the marginal note, the expression "development or redevelopment"
of land of cotton textile mills has been mentioned. What, therefore, in focus was the
land of cotton textile mills. The expression "land", thus, plays an important role.Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

Although a marginal note may not be determinative of the content of the provision, it
may act as an intrinsic aid to construction. [See Smt. Nandini Satpathy v. P.L. Dani
and another , AIR 1978 SC 1025, para 33].
The expression "development or redevelopment" in the marginal note does not
advance the contention of the writ petitioners that DCR 58 does not frame change of
user to non-textile mill users. Indisputably, having regard to the provisions of the
entire Regulation, DCR 58 is a special provision. It is a self-contained code. It
provides for a large number of things. The State while making the said legislation was
required to provide for almost all the eventualities in respect of the different
categories of cotton textile mills. They could be, apart from the sick mills referred to
BIFR; (a) closed, (b) non-closed mills intending to modernization, (c) non-closed
mills intending to shifting, (d) sick mills which have not been referred to BIFR under
SICA and, thus, no scheme wherefor was made. There were multiple options and one
mill or the other may fall in more than one category. A closed mill may come within
the purview of DCR 58(1)(a) or 58(1)(b) or 58(6). Some of the NTC mills also may
come within one or more categories. It is possible and in fact some of the mill owners
had opted for one or more of the multiple options of development/ redevelopment
activity in terms of the said regulation. By way of example, Ruby Mill opted for both
modernization and shifting and permission had been granted therefor. The fact that
DCR 58 is a self-contained code is evident from sub-regulation (8) which provides
that funds accruing to a sick, closed or mill requiring modernization or shifting shall
be credited to an escrow account, which shall be utilized only for revival/
rehabilitation, modernization or shifting of the industry. Sub- regulation (9) provides
a mechanism for putting this into place. The State, not only endeavoured to take care
of needs of various categories of cotton textile mills but also made attempts to find
out a solution having regard to the fact that the 1991 Regulations did not work. By
framing DCR 58, therefore, a mechanism was sought to be provided for achieving the
purpose of providing some relief to all players in the field. The said Regulations were
framed under Section 22(m) of the MRTP Act for controlling and regulating the use
and development of land. They are not, and cannot be, treated to be provisions for
compulsory acquisition of land. It also does not provide for reservation and/ or
designation in a development plan.
In sub-regulation (1) of DCR 58, the phrase "lands of sick and/ or closed cotton
textile mills" has been used. The same phrase has been used in Regulations 58(6),
58(8)(a) and 58(9)(a). DCR 58(1) read with DCR 58 (4) although postulates
recommendations by BIFR, the words "closed mills"
also find place both in Regulations 58(1) and 58(6). We have heretobefore noticed the statutory
meaning attributed to the expression "exiting building". DCR 58(1)(a) deals with existing structure
which could have been subjected to modification internally. DCR 58(1)(b) deals with the rest of it,
namely, open land. Under old regulation, the expression "open land" would mean such lands which
were required to sustain built-up area. The concept finds place in DCR 58(6). In terms of DCRBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

58(1)(a), thus, no demolition is contemplated which in turn would mean that no sharing of land also
is contemplated, i.e., the land owners are not required to surrender any land. However, it
contemplates change of user. It contemplates:
(i) the old cotton textile mills may continue to operate;
(ii) Alternatively, it may take recourse to "related user", i.e., user related to such
mills.
(iii) It could also take recourse to "diversified industrial user", meaning thereby, user
other than cotton textile mill and would include uses for other industries in terms of
the industrial location.
It is not in dispute that a long list of industries is contained in the said policy. It could further be
used for commercial purpose and the same having regard to the regulations would also include
residential purposes. In terms of DCR 58(1)(a), there could be no demolition and only the existing
structures, namely, those which were existing prior to coming into force of the said Regulation
should be developed by utilizing the existing structure which could not either be demolished or
reconstructed or relocated.
The contention of Mr. Salve that the word "demolition" brought about by reason of 1994
amendment in Section 2(7) of the MRTP Act plays a significant role also cannot be accepted for
more than one reason. The amendment of 1994 appears to be clarificatory in nature, having regard
to the fact that prior thereto the land owners could carry on demolition without prior intimation
and/ or obtaining permission from the corporation. The High Court, therefore, in its judgment
wrongly laid undue emphasis thereupon.
Furthermore, in DCR 58 the word redevelopment had all along been used. By reason of the said
amendment, no different meaning which would not be in consonance with the object should be
attributed. Whatever that may mean, redevelopment contemplates in its ordinary parlance a
renewal or substitution of development and involves pulling down of the structures. Development
by way of demolition cannot mean that DCR 58(1) would permit not just the retention of the
structure (shell) but also demolition of structure (shell). The purpose for introducing the said
amendment, therefore, was for a different purpose and could not have been used for the purpose of
construction of DCR 58.
It has not been disputed that keeping in view of the fact that the structures of the mills had been
built long long time back, they had sprawling existing structures. Ranjit Deshmukh Committee
Report does not categorically state that the balance FSI has to be calculated only from the open land
which was available before demolition and not from the land which became open by reason of
demolition of structures existing thereon. It is true that the lands of different mills had different
built-up areas. Balance FSI was required to be calculated on the basis thereof. The extent of vacant
land available for the purpose of distribution would indisputably depend upon the extent of
structures which had been standing on the lands but the same is a fortuitous circumstance. OnlyBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

because in a given case, the extent of the area to be given to MHADA or MCGM would be
comparatively less than the case of land belonging to other mills, the same by itself cannot be a
ground for construing DCR 58 differently. Furthermore, in Note (iv) of DCR 58(1)(b) itself, it is
categorically stated that land would become open by demolishing the existing structure which also
points to the fact that the contentions of the Respondents  Writ Petitioners are not correct in view
of the fact that if the land after demolition was already subsumed under open land, it was not
necessary to deal with the same subject specifically with land which had become open on
demolition. It is also interesting to note that in DCR 58(6)(a) the words "reconstruction after
demolition of existing structures limited to the extent of the built up area of the demolished
structure" have been used with reference to "development/ redevelopment of the entire open land
and/ or built up area of premises" which would also go to show that in the event, the interpretation
as advocated by Mr. Salve is accepted, such detailed and specific references to the specific
contingency of openness of land arising after and upon demolition or reconstruction done after
demolition would become wholly meaningless.
It is, thus, clear that the expression "open lands" is meant to connote lands other than lands
available after demolition of existing structures. [See Lennon v. Gibson, (1919) AC 709 at 711, Craies
on Statute Law, Seventh Edition, page 141 and G.P. Singh's Principles of Statutory Interpretation,
Ninth edition, page 258].
Having said so, let us take a re-look at sub-regulation (6) of DCR 58. Sub clauses (a) and (b) of
sub-regulation (6) refer to built-up areas which would mean that such area which the owner of the
mill had built whether existing or after demolition. The statute contemplates retention of the built-
up area that means the same area which the owner could retain had the building been not
demolished. The area which the structure had occupied is intended to be left with the mill owner.
However, how much area would be allowed to be retained, would inevitably differ from mill to mill.
Sub- regulation (6) merely provides for a guiding principle that the owners of the mill would be
permitted to retain the existing structure and built-up area; precisely that is the concept of
sub-regulation (6). In other words, rebuilding to the same effect or aggregation between different
plots is permitted so long the existing built up area is demolished and the same would not require
sharing of any land thereunder, provided of course that existing built up area is not enhanced. DCR
58(6) is carved out of DCR 58(1)(b). In terms of it only the construction is permitted for the same
area for the purpose of reconstruction. It is also worth noticing that both old and new regulation
speak of retention of same structure. DCR 58(6), thus, confers an additional benefit in respect of
cases falling within DCR 58(1)(a) allowing inter alia:
(a) demolition which it could not do under DCR 58(1)(a);
(b) it does not require any sharing for which benefit was also available under DCR
58(1)(a);
(c) built up area remaining the same, the shape, size and nature of the existing
structure could be changed which could not be done under DCR 58(1)(a);Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

(d) The second part of sub-regulation (6) permits aggregation on the same single mill
plot, which was not available under DCR 58(1)(a), subject of course to the existing
built up area remaining the same.
The contention of BEAG is that the implementation of DCR 58 would lead to a disastrous result and
in this behalf our attention was drawn to a sanctioned plan in respect of Mill No. 4 to show that the
consequences thereof would be that the share of MCGM and MHADA would come to 662.61 sq. m.
and 542.13 sq. m. respectively, although the plot area of Mill No. 4 is 58,458.36 sq. m. We do not
find any merit in the said contention as keeping in view of our finding aforementioned, the built up
area was required to be deducted therefrom. With a view to examine the said contention, we may
hereinbelow notice some charts in respect of Mill No. 1 and Mill No. 4:
Existing Development PLOT AREA (EXCL. SET BACK AREA) 47,730.28 SQ.M.
EXIST. PLINTH AREA 22,950.58 SQ.M. RATIO OF GROUND COVER 48.08%
EXISTING R.G. AREA ALMOST NIL Proposed Development PLOT AREA (EXCL.
SET BACK AREA) 47,730.28 SQ.M. PROP. PLINTH AREA 3,980.00 SQ.M. RATIO
OF GROUND COVER 8.34% LAYOUT R.G. DCR 21 11,910.00 SQ.M. M.C.G.M.
4,058.65 SQ.M. R.G. + M.C.G.M. 15,968.65 (33.5%) Computation of Open Land
1.
PLOT AREA (EXCL. SET BACK AREA) 47,730.28 SQ.M.
2. LAND COMPONENT OF EXISTING B.U. AREA UNDER DCR 58(6) i.e. EXISTING BU AREA
PERMISSIBLE FSI 47,123.67 SQ.M. 1.33 35,437.29 SQ.M.
3.
(i)
(ii)
(iii) BALANCE OPEN LAND TO BE SHARED UNDER DCR 58(1)(b) SHARE OF MCGM (33%)
SHARE OF MHADA (27%) SHARE OF OWNER (40%) 12,298.99 SQ.M. 4,058.67 SQ.M. 3,320.73
SQ.M. 4,919.60 SQ.M. OWNER'S HOLDING [2+3(iii)] 40,356.89 SQ.M. Existing Development
PLOT AREA (EXCLU. SET BACK AREA) 58,458.36 SQ. M. EXIST. PLINTH AREA 39,304.83
RATIO OF GROUND COVER 67.20% EXISTING R.G. AREA ALMOST NIL Proposed Development
PLOT AREA (EXCL. SET BACK AREA) 58,458.36 SQ.M. PROP. PLINTH AREA 10,789.40 SQ.M.
RATIO OF GROUND COVER 18.45% LAYOUT R.G. DCR 21 17,423.51 M.C.G.M. 662.61 SQ.M. R.G.
+ M.C.G.M. 18086.12 SQ.M. Computation of Open Land
1. PLOT AREA (EXCL. SET BACK AREA) 58,458.36 SQ.M.Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

2. LAND COMPONENT OF EXISTING B.U. AREA UNDER DCR 58(6) i.e. EXISTING BU AREA
PERMISSIBLE FSI 75,079.11 SQ.M. 1.33 56,450.46 SQ.M.
3.
(i)
(ii)
(iii) BALANCE OPEN LAND TO BE SHARED UNDER DCR 58(1)(b) SHARE OF MCGM (33%)
SHARE OF MHDA (27%) SHARE OF ONER (40%) 2,007.90 SQ.M. 662.61 SQ.M. 542.13 SQ.M.
803.16 SQ.M. OWNER'S HOLDING [2+3(iii)] 57253.62 SQ.M. For computing the extent of the land
required to be shared, the plinth area will have no relevance. So far as Mill No. 4 is concerned,
having regard to the existing built up area, the share of MCGM and MHADA would be on a low side,
but it is evident that so far as Mill No. 1 is concerned, whereas the plot area was only 47,730.28 sq.
m., having regard to the built up area, the share of MCGM and MHADA would come to 4,058.67 sq.
m. and 3,320.73 sq. m. respectively. These are indicative of the fact that the extent of open land to
be shared by the owners with MCGM and MHADA would depend upon the built up area of the
structure which existed on site. The share of MCGM and MHADA, therefore, would vary from case
to case and, thus, we cannot determine the question keeping in view only the case of one mill and
not the others.
We do not furthermore agree with the approach of the High Court in interpreting the
aforementioned provisions having regard to certain other factors, namely, deluge in Bombay in the
year 2005 as also the requirements of the entire population of Bombay from environmental aspect.
Such factors cannot be taken into consideration for interpretation of a statute. We cannot look to a
statute with a coloured glass, we have to consider the provisions as the legislature thought. The
same should be subject, of course, to the constitutional and other limitations.
At this juncture, we may consider the cases of the closed mills.
CLOSED INDUSTRIES No specific provision has been made for industries which are closed but for
one reason or the other had not been referred to BIFR. A mill may be closed although the company
which owns it and having other businesses or other properties is not sick company in terms of SICA.
From its other resources, it can modernize or shift the industry. But, there may be a case where the
mill is the only property, if it lies closed and no action is taken for its revival, the same may defeat
the purpose for which DCR 58 was made, or the company although as such is not sick but finds it
difficult to arrange funds for revival of the closed mill. The doctrine of purposive interpretation in
such a case has to be applied. The expression "sick and/ or closed" used in sub-regulation (1) of DCR
58 must be read as disjunctive and not conjunctive.
Furthermore, in this behalf the principles of common sense construction, as noticed hereinbefore,
should be taken recourse to. In Halsbury's Laws of England (Fourth Edition) Volume 44(1)
(Reissue), the law is stated in the following terms:Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

"1392. Commonsense Construction Rule. It is a rule of the common law, which may
be referred to as the commonsense construction rule, that when considering, in
relation to the facts of the instant case, which of the opposing constructions of the
enactment would give effect to the legislative intention, the court should presume
that the legislator intended common sense to be used in construing the enactment.
1477. Nature of presumption against absurdity. It is presumed that Parliament intend
that the court, when considering, in relation to the facts of the instant case, which of
the opposing constructions of an enactment corresponds to its legal meaning, should
find against a construction which produces an absurd result, since this is unlikely to
have been intended by Parliament. Here 'absurd' means contrary to sense and
reason, so in this context the term 'absurd' is used to include a result which is
unworkable or impracticable, inconvenient, anomalous or illogical, futile or pointless,
artificial or productive of a disproportionate counter- mischief.
1480. Presumption against anomalous or illogical result. It is presumed that
Parliament intends that the Court, when considering, in relation to the facts of the
instant case, which of the opposing constructions of an enactment corresponds to its
legal meaning, should find against a construction that creates an anomaly or
otherwise produces an irrational or illogical result. The presumption may be
applicable where on one construction a benefit is not available in like cases, or a
detriment is not imposed in like cases, or the decision would turn on an immaterial
distinction or an anomaly would be created in legal doctrine. Where each of the
constructions contended for involves some anomaly then, in so far as the court uses
anomaly as a test, it has to balance the effect of each construction and determine
which anomaly is greater. It may be possible to avoid the anomaly by the exercise of a
discretion. It may be, however, that the anomaly is clearly intended, when effect must
be given to the intention. The court will pay little attention to a proclaimed anomaly if
it is purely hypothetical, and unlikely to arise in practice."
If such an interpretation is not given, a very valuable asset would be rendered sterile. If it is to be
construed that a scheme made by BIFR is the condition precedent for applicability of DCR 58 by
reason whereof the benefit conferred thereunder would not be available in like cases for no apparent
reasons whatsoever particularly when it was the intention of the State that all categories of the mills
which require rehabilitation, revival or modernization should be brought within the purview of DCR
58.
It is, thus, not possible to accept Mr. Salve's submission that even a closed mill although not covered
under DCR 58 may be utilized for purposed mentioned in Regulation 56.
Indisputably, there may be closed mills which have not been referred to BIFR or otherwise not
capable of being referred to. The spirit of making DCR 58 was to revival and/ or rehabilitation of the
cotton textile mills. Revival of closed mill was also, thus, a component part of the scheme behind
framing of DCR 58. It may be true that in terms of sub-regulation (1) of DCR 58 recommendation ofBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

the BIFR is contemplated but recommendation of BIFR would be necessary where it is otherwise
available. If it is insisted that the recommendation by BIFR was mandatory even for closed mill,
much of the significance for using the words `and/or closed' after the word `sick' is lost. A closed
mill would mean a mill in respect whereof closure has been effected in accordance with law. Such
closure can be effected in accordance with law in terms of the provisions of the Industrial Disputes
Act. Before effecting a closure under the Industrial Disputes Act, notice has to be given to the State
and in certain cases its prior permission is also required to be obtained. Thus, all cases, which entail
closure of an industry, would be within the knowledge of the State. The State through its machinery
can furthermore verify the genuineness or otherwise of such closure. In such a case, even in terms of
the provisions of the Industrial Disputes Act having regard to the purport and object for which the
same had been enacted, the authorities thereunder as also for the State a duty is cast to restore back
the industrial peace. [See State of Rajasthan & Anr. v. Mohammed Ayub Naz, (2006) 1 SCALE 79].
SICK MILLS SICA is a special statute. It is an Act made by the Parliament. It was enacted in the
public interest so as to make special provisions with a view to securing the timely detection of sick
and potentially sick companies owning industrial undertakings, the speedy determination by a
Board of experts of the preventive, ameliorative, remedial and other measures which need to be
taken with respect to such companies, the expeditious enforcement of the measures so determined
and for matters connected therewith or incidental thereto. SICA was enacted for giving effect to the
policy of the State towards securing the principles specified in clauses (b) and (c) of Article 39 of the
Constitution of India. It would prevail over other statutes including MRTP and the Regulations
framed thereunder.
Section 3(e) of SICA defines "industrial company" to mean "a company which owns one or more
industrial undertakings." "Industrial undertakings" has been defined in Section 3(f) of SICA. "Sick
industrial company" has been defined in Section 3(o) of SICA to mean "an industrial company
(being a company registered for not less than five years) which has at the end of any financial year
accumulated losses equal to or exceeding its entire net worth". Section 15 of SICA provides for
reference to a Board where an industrial company has become a sick industrial company for
determination of the measures which should be adopted with respect thereto. Section 17 provides
for the power of Board to make suitable orders on the completion of inquiry. Various provisions
have been laid down in Chapter III of SICA enabling the Board to issue several directions. Section 32
of SICA provides for a non-obstante clause stating that the provisions thereof shall prevail
notwithstanding anything contained in any other law for the time being in force or in the
Memorandum or Articles of Association of an industrial company or in any other instrument having
effect by virtue of any law except enactments specified therein.
The question as regards the interpretation of the sick industries contained in sub-regulation (6) of
DCR 58 must be considered from that perspective.
DCR 58(6) is adjunct to the other provisions. Although on some occasions, DCR 58(2) may apply
without DCR 58(6). However, there is no such machinery so far as sick mills are concerned, it is,
therefore, difficult to comprehend that those mills which are sick but not referred to BIFR also can
take advantage of sub-regulation (6). How an industrial undertaking belonging to a company whichBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

is sick should be determined to be so as laid down under the provisions of SICA. Only in a case
where a company is sick in terms of the 1985 Act, an industrial undertaking belonging to it may be
subject matter of the provisions thereof. The State for that matter neither has any statutory power or
competence to deal with sick undertakings. Furthermore, the extent to which such sick company
requires protection to the extent of the sickness of the industrial undertaking cannot also be gone
into by the State or for that matter by any other authority apart from BIFR.
MODERNIZATION/ SHIFTING Sub-regulation (2) of DCR 58 deals with cases requiring
modernization. For invoking the said provision, certain steps are required to be taken which are as
under:
(i) Application for Scheme of Modernization to Government (Competent Authority
i.e. Corporation and Textile Department, Government of Maharashtra) as per DCR
58(2) read with 58(6)(a)(b) as the case may be.
(ii) Scrutiny by the Department of Textiles.
(iii) Approval to Scheme by Government (with direction to approach MCGM for
further approval as per Regulation 58(2) read with 58(6)(a)(b).
(iv) Application by Owner to Municipal Commissioner for a layout prepared for
development or redevelopment of the entire open land and/ or built up areas of the
premises of mill. With regard to the utilization of built up area (if reconstruction,
aggregation is proposed then it has to be read with 58(6)(a)(b) as the case may be),
the provisions of clause (a) of sub-regulation 1 of these regulations shall apply and if
the development of open lands and balance FSI exceeds 30% of the open land and
balance FSI, the provision of clause (b) sub-
regulation 1 of this regulation shall apply.
As per Notes (ii)  in case of more than one cotton textile mills owned by the same company, the
exemption of 30%, as specified above, may be permitted to be consolidated.
Permission for development or redevelopment granted as per 58(2) read with 58(6)(a)(b).
(v) Ready for Implementation for Scheme of Modernization.
(vi) As per 58(8)(a)(b)  Funds accruing in ESCROW Account, monitored by Monitoring Committee
as per DCR 58(9)(a).
If it fulfills the said requirements, it becomes entitled to utilization of open land and FSI to the
extent of 30% of the balance FSI available. Under 1991 Regulation, the mill owners in terms of the
similar provision was entitled to the exemption of 15% which by reason of 2001 Regulations had
been raised to 30%. Furthermore, for providing the incentive for modernization where there existsBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

more than one textile mill, the exemption may also be consolidated on any of the mill land subject to
the extent of balance FSI in the receiving land without having to share land as would be evident
from Note (ii) appended thereto.
However, sub-regulation (6) of DCR 58 may not be available to an applicant intending to modernize
its mill where aggregation is not resorted to and no demolition of the existing built up area is
involved as also open lands/ balance FSI are utilized for additional constructions as per DCR
58(1)(b) but in appropriate cases, evidently it has to share. For the purpose of change of user of the
lands, previous approval of the Commissioner to a layout plan in accordance with the Scheme
approved by the Government is necessary. In terms of the said provision, Clause (a) of
Sub-regulation (1) thereto shall apply as regard utilization of the built-up area and clause (b) shall
apply in relation to development of open lands and balance FSI exceeds 30% of the open land and
for balance FSI clause (b) of sub-regulation (1) shall apply. Sub-regulation (3) applies in respect of
the cotton textile mills which intend to shift with the permission of the competent authorities and in
accordance with the scheme approved by the Government. In terms of the said provision also,
Clauses (a) and (b) of sub- regulation (1) of DCR 58 would apply in regard to the development or
redevelopment of its land after shifting. Sub-Regulation (4) provides that in case of modernization
and shifting, recommendation by BIFR would not be mandatory which implies that such
recommendation shall be mandatory. DCR 58(3) provides for shifting. Shifting of industries outside
the town is encouraged.
Ruby Mills Limited, which is one of the Appellants in civil appeal arising out of SLP (C) No. 23634 of
2005, is one of the companies which had opted for shifting. It had, however, made a scheme for
shifting-cum- modernization under the said provisions as also commercial development of a portion
of its textile mill land.
OTHER REGULATIONS Sub-regulation (5) provides for additional development to the extent of
balance FSI on open lands or otherwise by the cotton textile mill itself not only for the same cotton
textile but also for related user. The calculation of FSI indisputably would be in terms of the
Appendix VII. Sub-regulation (6) provides for multi-mill aggregation. This provision in certain
respects is to be considered with Note (vi) of sub- regulation (1) of DCR 58. The aforementioned
clause cannot be read in isolation. It has to be read in conjunction with the other regulations. It
would apply to a case which might have otherwise been covered by sub- regulations (1), (2), (3) and
(5). But the same would not mean that a part of sub-regulation (1) and a part of sub-regulation (2)
cannot be applied in a given case. Although sub-regulation (6) does not specifically refer to the
recommendations of BIFR as imperative where the other sub-regulations are applicable,
sub-regulation (6) cannot be read as a 'stand alone' clause. The writ petitioners contended that
sub-regulation (6) should be read independently so that its benefit may not become obtainable while
obtaining benefit under one or the other sub-regulation. Such a construction would defeat the other
provisions of the regulation. We have noticed hereinbefore that Regulations 56 and 57 deal with
industries located in I-2 and I-3 zones. Both in Regulations 56 and 57 cotton textile mills had
expressly been excluded from a general power to convert the user into a residential or commercial
purpose. If such a provision was required to be made in making an exception in relation to the
cotton textile mill, it was not necessary for the State to frame the regulation in its present form. IfBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

sub-regulation (6) of DCR 58 is read in the manner suggested by the learned counsel for the
Respondents, other parts of DCR 58 would have been unnecessary. Sub- regulation (6) specifically
refers to sick and/ or closed or requiring modernization on the same land. Such cases would, thus,
bring within its purview only closed mills which had not been referred to BIFR but the change of
user, must be confined to DCR 58 itself and not under DCR 56. The construction that we have put
on DCR 58(6), furthermore, does not cause any injustice to any party. If an industrial undertaking is
really sick within the provisions of the 1985 Act, for the purpose of availing the benefits under DCR
58, it can refer the question to BIFR and once a scheme is framed as regard revival and/ or
rehabilitation, the owner of the mill can take recourse thereto. The lands of the cotton textile mills,
thus, although become open lands available but therefor they cannot be used for purposes specified
in I-2 Zone. Sub-regulation (6) of DCR 58 must be read in sharp contrast to Sub-regulation (3)(c) of
Regulation 56 and Sub-regulation 4(c) of Regulation 57 which permits a change of user to industrial
lands other than lands of cotton textile mills. Sub-regulation (6) of DCR 58 although contains no
power to change of user but the same had been provided in other clauses. If it is not held that
sub-regulation (6) contains the power to change user in respect of existing structures, a'fortiori it
may not be possible to give effect thereto as there would be no power to user of change of land under
existing structures.
So far as NTC mills are concerned, development had taken place as a package of measure
recommended by BIFR. Indisputably, the same would come within the purview of sub-regulation (1)
of DCR 58 but in certain cases sub-regulation (6) also may be attracted. Each of the relevant sub-
regulations of DCR 58 confers regulatory power upon the Commissioner of the State. Development
or redevelopment in terms of sub-regulations (1), (2), (3) and (5) are required to be made in terms of
a layout plan as approved by the Commissioner and in case of modernization as per the scheme
approved by the State. As the said provisions, contain a safeguard, namely, prior approval of the
Commissioner, all the mill owners irrespective of the fact that they fall in different categories in
terms of the regulations would, thus, be entitled to take benefit of clause (6) subject to strict
compliance of other provisions.
CONSTITUTIONALITY OF DCR 58 The constitutionality of DCR 58 had been questioned
principally on three grounds, namely, it is violative of: (i) Article 21; (ii) Article 14; and
(iii) it is not in consonance with Article 48-A of the Constitution of India. The High Court, however,
read DCR 58 on the touchstone of Article 21 as also Article 48-A of the Constitution of India. The
High Court did not go into the question of its constitutionality. It proceeded on the basis that if the
said provision is read down, the same would render the provision constitutional. It is no doubt true
that a planning regulation which requires to meet environmental challenges may not be interpreted
in the same fashion as economic legislation. But whether it is necessary to apply the strict scrutiny
test or not, would depend upon the statute. The State, while exercising its power to make a
subordinate legislation, may or may not obtain expert opinion. But invariably the Court would
satisfy itself as to whether relevant factors as laid down in the legislative act had been taken into
consideration.Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

The question, however, raised in these appeals is as to whether requirements to obtain such expert
opinion so as to enable the court to look at the quality of the input both with reference to its source
as also the scope thereof is mandatory in nature. In this case, in our opinion, the said question need
not be gone into in great detail. We would, however, broadly consider the same. The court ordinarily
is required to consider the constitutionality of the subordinate legislation within the accepted
norms. We have hereto before, noticed the parameters of judicial review. The question raised,
therefore, will have to be considered having regard thereto. A matter involving environmental
challenges may have to be considered by a superior court depending upon the fact as to whether the
impugned action is a legislative action or an executive action. In case of an executive action, the
court can look into and consider several factors, namely,
(i) Whether the discretion conferred upon the statutory authority had been property exercised;
(ii) Whether exercise of such discretion is in consonance with the provisions of the Act;
(iii) Whether while taking such action, the executive government had taken into consideration the
purport and object of the Act;
(iv) Whether the same subserved other relevant factors which would affect the public in large;
(v) Whether the principles of sustainable development which have become part of our constitutional
law have been taken into consideration; and
(vi) Whether in arriving at such a decision, both substantive due process and procedural due process
had been complied with.
It would, however, unless an appropriate case is made out, be difficult to apply the aforementioned
principles in the case of a legislative act. It is no doubt true that Articles 14, 21, 48-A of the
Constitution of India must be applied both in relation to an executive action as also in relation to a
legislation, however, although the facet of reasonableness is a constitutional principle and
adherence thereto being a constitutional duty may apply, the degree and the extent to which such
application would be made indisputably would be different. Judicial review of administrative action
and judicial review of legislation stand on a different footing. What is permissible for the court in
case of judicial review of administrative action may not be permissible while exercising the power of
judicial review of legislation. It may, however, be a different thing to contend that the legislation had
been enacted without constitutional principles in mind. The real question is whether the
constitutional mandates had been complied with in making such legislation.
We do not agree with the contention of Mr. Jethmalani, that Article 21 of the Constitution of India
should be literally construed as was done in A.K. Gopalan v. State of Madras [1950 SCR 88]. In view
of the fact that the factors governing the quality of life have been included in the expression "life"
contained in Article 21 by reason of creative interpretation of the said provision by this Court, is it
possible to argue that Article 21 does not provide for an absolute immunity? Article 21 does not only
refer to the necessity to comply with procedural requirements, but also substantive rights of aBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

citizen. It aims at preventive measures as well as payment of compensation in cases human rights of
a citizen are violated. So far as the question of compliance of the procedural due process is
concerned, it was conceded before the High Court by the writ petitioners  Respondents that the
procedural requirements laid down in provisions of Section 37 of the MRTP Act had been complied
with.
We, however, are unable to uphold the contention of Mr. Salve, as at present advised, that before
making DCR 58 in the year 2001, it was obligatory on the part of the State to accept in toto the
recommendations made by the Expert Committees who had undertaken certain exercises; the
equities should have been adjusted and the provisions of the pollution laws including the provisions
of sub-section (2) of Section 28 of the MRTP Act should have been considered. A presumption arises
as regards the constitutionality of a statute. Such a presumption would also arise in a case of
subordinate legislation. As indicated hereinbefore, a subordinate legislation, however, shall be
susceptible or vulnerable to challenge not only on the ground that the same offends Articles 14, 21
read with Article 48-A of the Constitution of India but also that the provisions of the MRTP Act are
unreasonable.
In the instant case, the State appointed two committees. They have been taken into consideration by
the State, may albeit be only in part. The State might not have agreed with the entirety of the report.
The State might have taken into consideration other factors which would subserve the purport and
object of the regulation. But, it will be difficult for us to arrive at a finding that the environmental
aspects had totally been ignored. To what extent, DCR 58 would be commensurate with the ideal
ecological condition as is suggested by the experts is one thing but it is another thing to say that no
consideration at all in this behalf had been made by it. The State in its affidavit categorically stated
that the said reports had fallen for consideration and had been accepted by it but in the third
affidavit it has merely been stated that the State intended to give more than what was suggested in
the said report. It has been accepted by the parties that certain suggestions have been accepted in
toto and the provisions have been amended pursuant thereto or in furtherance thereof. The Ranjit
Deshmukh Committee, not only visited some mills but also took recourse to the consultative
process. Even the Charles Correa Committee visited all the public sector textile mills. While taking
the said reports into consideration, the State acquainted itself with the existing ground realities as
they then existed.
For the purpose of striking down a legislation on the ground of infraction of the Constitutional
provisions, the court would not exercise its jurisdiction only because the recommendations of the
committees had not been accepted in toto but would do so inter alia on the ground as to whether
they otherwise violate the constitutional principles. Arbitrariness on the part of the legislature so as
to make the legislation violative of Article 14 of the Constitution should ordinarily be manifest
arbitrariness. What would be arbitrary exercise of legislative power would depend upon the
provisions of the statute vis-`-vis the purpose and object thereof. [See Sharma Transport v.
Government of Andhra Pradesh, (2002) 2 SCC 188, para 25, Khoday Distillery v. State of Karnataka,
(1996) 10 SCC 304 and Otis Elevator Employees' Union S. Reg. and Others v. Union of India and
Others, (2003) 12 SCC 68, para 17].Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

In Om Prakash and Others v. State of U.P. and Others, [(2004) 3 SCC 402], this Court has held that
the test of reasonableness is nothing substantially different from social engineering, balancing of
interests or any other formulae which modern sociological theories suggest as an answer to the
problem of judicial interference.
In Cipla Ltd. (supra), this Court in relation to a legislation while interpreting the statutory
provisions on the touchstone of Article 14 of the Constitution of India, was of the opinion:
". the Government exercising its delegated legislative power should make a real
and earnest attempt to apply the criteria laid down by itself. The delegated legislation
that follows the policy formulation should be broadly and substantially in conformity
with that policy, otherwise it would be vulnerable to attack on the ground of
arbitrariness resulting in violation of Article 14."
It was further opined:
"Broadly, the subordinate law-making authority is guided by the policy and
objectives of the primary legislation disclosed by the preamble and other provisions.
The delegated legislation need not be modelled on a set pattern or prefixed
guidelines. However, where the delegate goes a step further, draws up and announces
a rational policy in keeping with the purposes of the enabling legislation and even
lays down specific criteria to promote the policy, the criteria so evolved become the
guideposts for its legislative action. In that sense, its freedom of classification will be
regulated by the self-evolved criteria and there should be demonstrable justification
for deviating therefrom. "
The amendment to DCR 58 was carried out 10 years after the original DCR 58 was introduced.
Before doing so, due consultative process as laid down in Section 37 of the MRTP which involves
suggestions and objections from public and the concerned statutory authorities was taken recourse
to. Consideration of the same by Dy. Director of Town Planning and thereafter promulgation of the
same in the form of direct regulation establishes that the same is not ex facie arbitrary in nature,
particularly when most of the suggestions of the said Committees were accepted. So far as the
argument based on violation of Article 48-A of the Constitution is concerned, the provisions thereof
are required to be construed as a part of the principle contained in Article 14 of the Constitution of
India. A statute may not be ultra vires Article 48-A itself if it is not otherwise offensive of Articles 14
and 21 of the Constitution of India. What, however, cannot be done for striking down legislation can
certainly be done for striking down executive action. [See K.K. Bhalla v. State of M.P. & Ors., 2006
(1) SCALE 238 and S.N. Chandrashekar and Anr. v. State of Karnataka and Ors., [JT 2006 (2) SC
202].
Ecological factors indisputably are very relevant considerations in construing a town planning
statute. The court normally would lead in favour of environmental protection in view of the creative
interpretation made by this Court in finding a right of environmental including right to clear water,
air, etc. under Article 21 of the Constitution of India. But, in this case, we are not dealing with aBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

similar problem. It must be borne in mind while interpreting DCR 58 that there exists a stark
distinction between the interpretation of planning and zoning statutes enforcing ecology vis-`-vis
industrial effluents and hazardous industries and those relating to concerted efforts at rehabilitating
the industry. It is around this pivot that interpretation must revolve. It is also interesting to note
that in American Jurisprudence 2d, wherein at page 496 of vol. 82, it is stated that zoning laws
should be construed strictly in favour of the property owners and that they should not be extended
by implication to include restrictions not clearly prescribed. Ecology in terms of DCR 58 has not
been marginalized. The statute does not prescribe any fixed norm. It provides for guidelines. It has
not been shown that the said guidelines have been violated. The environmental aspect considered in
DCR 58 may not be to everybody's satisfaction but the regulation in question has to be interpreted
having regard to the purport and object for which the same was enacted, meaning thereby, a holistic
approach to a large number of problems.
DCR 58 was made in a special situation. In any other situation, probably this Court might have
interpreted a similar provision differently. But, DCR 58 seeks to strike a balance between different
public interest. The State has its own limitations. DCR 58 cannot be struck down solely on the
ground that the interest of the common citizen (from the ecological point of view) has been affected,
unless its actions are considered to be unfair. The State indeed in making the regulation intended to
solve a longstanding problem wherewith it was beset. The State while framing the aforementioned
regulation had to deal with various objectives in mind. It might have taken recourse to trial and
error method. It started with an experiment in the year 1991 but having failed therein it introduced a
new policy. The State considered the same to be fair on its part. We must take notice of the fact that
the 1991 Regulation failed to achieve the desired objective forcing the State to take a conscious
policy decision, which according to it, would satisfy everybody's need. All players may not feel happy
as evidently a group of workers and the writ petitioners are not. Even the Bombay Municipal
Corporation and MHADA had shown its reservation but the same by itself would not resist us in any
manner in arriving at a correct interpretation. In Forward Construction Co. and Others vs. Prabhat
Mandal (Regd), Andheri and Others [(1986) 1 SCC 100], it was clearly recognized that in a given
case there can be more than one public interest and these interests can be in conflict with each
other. The law maker has to make his choice and preferring one to the other is inevitable. A
substantive law as also delegated legislation raises a presumption of constitutionality. Attempt is,
thus, required to be made for upholding the same.
Sale of lands belonging to mills which are absolutely unviable and/ or those which are lying closed
for one reason or the other as also those who intend to modernize their mills and/ or shifting the
same and/ or part of it must be kept for consideration in the matter of interpretation of DCR 58.
Applying the principles which can be culled down from the aforementioned decisions, we are unable
to hold that DCR 58 is unconstitutional.
CLARIFICATION The State of Maharashtra admittedly issued a clarification on 28.03.2003. It did
so in purported exercise of its power under sub-regulation (2) of Regulation 63 of Regulations. The
High Court held the said clarification to be ultra vires Section 37 of the Act on the premise that by
reason thereof, amendment to the regulation had been carried out. As of fact we may, however,
notice that the State of Maharashtra started granting approvals in terms of DCR 58 of 2001 muchBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

prior to 28.03.2003. It is, therefore, not correct to contend that the permission had been granted
after issuance of the said clarification. In terms of such approvals, combined permission had been
granted invoking one or more sub-regulations of DCR 58.
However, the submission of the learned counsel appearing on behalf of the Appellants to the effect
that the said clarification is binding and conclusive upon all concerned cannot be accepted. No
interpretation of a State can be said to be binding on courts. It may have a persuasive value. The
court in certain situations, in the event two interpretations are possible including the one as
interpreted by the State, may accept the latter but the same would not mean that once a statutory
power of interpretation or clarification had been exercised by the State, the court's hands are tied. In
fact, the learned Advocate General appearing on behalf of the State of Maharashtra accepted the said
legal position.
We may, however, place on record that similar interpretation must be held to have been made by
MCGM as it granted sanction in respect of several plans in the line of interpretation made by the
State. The clarification was issued having regard to a letter of MCGM dated 28.08.2001 to the Urban
Development Department stating as to how it understood DCR 58 of 2001 which was confirmed by
the Urban Development Department. Thus, although at one point of time they interpreted DCR in
the same manner as that of the State; only much later they raised a doubt which was bona fide. Only
with a view to clear the air of doubt, the clarification was issued by the State.
It is interesting to note that in paragraph 23 of the writ petition, the writ petitioners treated the
purported reduction in area attributable to DCR 58 as amended in 2001 and not because of any
purported change brought about by clarification made in 2003.
Furthermore, it is one thing to say that the clarification is beyond the statutory power of the State or
plainly contrary to the regulations, the effect whereof is required to be determined, but it is another
thing to say that while doing so the State gives out its mind as to what it meant thereby as an author
of the regulations. The grievance of the writ petitioner respondents primarily in that behalf is that in
terms of the said clarification, reconstruction on land made available after demolition of the existing
structure is to be in terms of sub-regulation (6) of DCR 58 and the user thereof is proposed to be
changed from industrial to commercial or residential under sub-regulation (1)(a)(iii). We have
interpreted the aforementioned provision independently and we agree that such construction of
DCR 58 was possible. But, we also do not agree therewith in its entirety as has been indicated
hereinbefore. The writ petitioners intend to construe sub-regulation (6) of DCR 58, as a stand alone
clause, with which for the reasons stated hereinbefore, we do not agree. If some mill owners claim
the right to change of user under sub-regulation (6) alone, the same would be in the teeth of the
interpretation of DCR 58. It cannot be said that by taking recourse to the said power of clarification
the State has improperly exercised its power. Reference to resolution dated 27.08.2003 passed by
MCGM, does not have the effect of clarification being set at naught for DCR 58. Similarly, the letter
dated 24.07.2003 issued by the Chief Executive Officer of MHADA to the Housing Board or the
State Government also does not talk about the incorrectness or otherwise of the clarification issued
by the State but as regards the effect of DCR of 2001. MAHDA before us categorically stated that it
would abide by the decision of the State of Maharashtra despite the letter dated 24.07.2003, whichBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

was made the only basis for filing the affidavit before the High Court. Mr. Singhvi appearing for
MCGH did not raise any contention contrary to that of the State. According to Mr. Chagla, the
clarification made by the State will have the following legal effects:
(i) Excluding lands after demolition of existing structures;
(ii) Excluding the land required to support the FSI of existing built up areas;
(iii) Introducing change of user in DCR 58(6)
(iv) Altering the meaning of "existing built up areas" in DCR 58(1)(a).
(v) Permitting residential user under DCR 58(1)(a)(iii);
(vi) Obviating surrender of land under DCR 58(6) in respect of newly built up areas
despite change of user.
(vii) Dispensing with prerequisite of BIFR in DCR 58(1).
Most of the contentions raised by Mr. Chagla stand answered by our findings recorded hereinbefore.
They may, however, be briefly dealt with in seriatim.
(i) The exclusion of land after demolition of existing structure was not brought about by 2003
clarification for the first time but it is apparent from 2001 Regulations themselves. We have
heretobefore held that DCR 58 as interpreted by the State was valid to a large extent.
(ii) As permissions as regard the layout plans had been given, sanctioning building plans by the
statutory authorities and/or approval of scheme by the State Government in 2001 and 2002, i.e.,
after DCR 58 came into force and much prior to the 2003 clarification, no change as such was
brought about thereby.
(iii) If sub-regulation (6) of DCR 58 is to be read along with other regulations, the stand of the State
must be held to be correct. Reading of sub-regulation (6) with other parts of DCR 58 is not only for
the purpose of change of user but also as regard the restrictions and limitations imposed thereby. It
is, therefore, not correct to contend that the approach of the State was to somehow find an
interpretation that furthered the purpose of not requiring sharing of land by the land owners and by
reason of the clarification that end was attained substantially.
(iv) & (v) These submissions are not dependent upon 2003 clarification. The meaning of the words
"entire land" and "built up area" vis-`-vis permissibility of residential user arose from 2001
Regulations which had merely been reiterated in 2003 clarification.
(vi) DCR 58(6) itself contemplates absence of sharing obligation so long as there was no increase in
the built up area of the existing structure. The 2003 clarification of the State is in tune therewith.Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

(vii) The expression 'sick' used in sub-regulation (6) must necessarily be those industries which were
are referred to BIFR and not any other sick mill, as the State or any other statutory authority under
regulations are not authorized to determine as to whether a mill is sick or not or the extent thereof
and/ or remedial measures therefor within the meaning of the provisions of the said regulations.
CONTEMPORANEOUS EXPOSITO/ EXECUTIVE CONSTRUCTION It was contended by the
petitioners before us that the High Court ought to have applied the doctrine of contemporanea
exposito while interpreting DCR 58 of 2001 and the Clarification of 2003. We have indicated
hereinbefore that we do not agree with the said contention but as the learned counsel appearing for
the appellants have relied upon some decisions of this Court, the same may be noticed at this
juncture. In Union of India and Another v. Azadi Bachao Andolan and Another [(2004) 10 SCC 1],
this court was concerned with a statutory power exercised by the Board of Direct Taxes in issuing
directions to the Income Tax Officers as to how they should deal with the cases falling within the
purview of Indo-Mauritius Double Taxation Avoidance Convention, 1983. The Court itself held that
the principles adopted in interpretation of treaties are not the same as those in interpretation of a
statutory legislation on the ground that the principle which needs to be kept in mind in the
interpretation of the provisions of an international treaty, including one for double taxation relief, is
that treaties are negotiated and entered into at a political level and have several considerations as
their basis; whereas a statute has to be interpreted keeping in mind the well known principles or
canons of interpretation of statutes.
It is in the aforementioned context the court therein took recourse to the doctrine of contemporanea
expositio. The court itself referred to a decision of the Calcutta High Court in Baleshwar Bagarti v.
Bhagirathi Dass [ILR 1908 (35) Cal. 701] wherein it was held that the court interpreting the statute
would give much weight to the interpretation. The said decision, therefore, is not an authority for
the proposition that the court has no jurisdiction to take a contrary view.
It is interesting to note that the Bench referred to a judgment of the Constitution Bench of this Court
in Collector of Central Excise, Vadodara v. Dhiren Chemical Industries [(2002) 2 SCC 127], wherein
S.N. Variava, J. was a party. Therein, it was laid down :
"11. We need to make it clear that, regardless of the interpretation that we have
placed on the said phrase, if there are circulars which have been issued by the Central
Board of Excise and Customs which place a different interpretation upon the said
phrase, that interpretation will be binding upon the Revenue."
However, in Kalyani Packaging Industry v. Union of India and Another, (2004) 6 SCC 719], Variava,
J. explained the said decision and clarified that in a case of conflict between circulars of the Board
and the judgment of the court, the latter will prevail.
It is also of some interest to note that House of Lords in Gullick v. West Norfolk Area Health
Authority, [1986 AC 112] opined that an incorrect statement of the law appearing in a circular can be
struck down. In Municipal Corpn. for City of Pune v. Bharat Forge Co. Ltd. [(1995) 3 SCC 434], it
was stated:Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

"What has been stated relating to "executive construction" or "practical construction"
which has been relied on by the learned Advocate General, would not persuade us to
agree with him in this submission, though it may be permissible to take note of
post-enactment history to find out as to how an enactment was understood on the
principle of "contemporanea expositio"
[See also Ajay Gandhi v. B. Singh, (2004) 2 SCC 120] In Jamshed N. Guzdar v. State of Maharashtra
[(2005) 2 SCC 591], it is stated:
"We are afraid, when it comes to interpretation of the Constitution, it is not
permissible to place reliance on contemporanea expositio to the extent urged.
Interpretation of the Constitution is the sole prerogative of the constitutional courts
and the stand taken by the executive in a particular case cannot determine the true
interpretation of the Constitution..."
From what we have noticed hereinbefore, it is abundantly clear that the principle of
contemporaneous expositio cannot be said to have universal application. Each case must be
considered on its own facts. An executive construction is entitled to respect but is not beyond the
pale of judicial review.
ARE REGULATIONS AND CLARFICIATION ULTRA VIRES SECTION 37 OF THE MRTP ACT ?
We may, with a view to examine the said question more closely, take note of the following facts
which more or less are undisputed. Certain plots were reserved and uses were designated for
specified purposes in the development plan. The mill lands are constituted in wards of the Bombay
Municipal Corporation, namely, A, E, F (South), F (North), G(South), G(North) and L. The lands of
the mills were designated as I-2, I-3 or Residential (Retention Activity) Zones. The contention of the
writ petitioners is that DCR 58 changes the character of development plan which would include all
regulations framed under the MRTP Act. Section 37 (1AA) of the MRTP Act itself suggests that the
changes would be of such nature that would not change the character of such development plan
which would be otherwise permissible in terms of Section 37. Fundamental changes or even very
significant changes would not normally apply to such a situation. It has not been suggested that
while effecting the change of user, designation of uses for specified purposes would change. The
identified reservation for open spaces in the development plan did not include mill lands. In spite of
modification, the mill lands are not to be included in any such reservation. To the said extent, there
would not be any change at all. Another question which has been raised is as to whether major
modification has been effected although Section 37 contemplates only minor changes. It is axiomatic
that for the said purpose Section 37 of the MRTP Act must be read in the context of Section 22-A
thereof which provides for substantial changes.
It is also to be borne in mind that whereas the heading of Section 37, prior to amendment, provided
for minor modification, the word "minor" has been deleted and in that view of the matter emphasis
should be laid on the fact or as to whether such modification alters the basic character of the
development of Greater Bombay or not. It would give rise to a further question, namely, as toBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

whether by reason thereof a radical transformation has taken place as regards its basic features,
including its identity, which a'fortiori would mean as to whether the modified development plan
stands unrecognized from the original one. Such a conclusion could have been arrived at if a green
area has been eliminated or a green area has been allotted to be used for commercial purposes as
was the case in Bangalore Medical Trust v. B.S. Muddappa & Ors. [(1991) 4 SCC 54]. In that case,
this Court, while construing the Town Planning Act, opined that reservation of open spaces for parks
and playgrounds is universally recognized as a legitimate exercise of statutory power rationally
related to the protection of the residents of the locality from the ill-effects of urbanization stating:
"The statutes in force in India and abroad reserving open spaces for parks and
playgrounds are the legislative attempt to eliminate the misery of disreputable
housing condition caused by urbanisation. Crowded urban areas tend to spread
disease, crime and immorality.."
Here, the court was considering the question as to whether discretion vested in the executive head
had correctly been exercised or not. We are not concerned with such a question in the instant case.
If certain number of sites were reserved in the development plan for public purposes and change of
user had been effected as for example, whether some of the green areas had been converted to
commercial uses, the matter might have been different. The terms 'modification' or 'change' have
often been the subjects of judicial interpretation.
The meaning of the expression "change" came up for consideration in Forward Construction
Company v. Prabhat Mandal [(1986) 1 SCC 100], wherein after noticing its dictionary meaning, it
was observed:
"So, the general meaning of the word "change"
in the two dictionaries is "to make or become different, to transform or convert". If the user was to
be completely or substantially changed only then the prior modification of the development plan
was necessary."
The question as regard the process of modification of a plan came up for consideration in Legg v.
Ilea [1972 (3) All ER 177] wherein it was stated:
"the process involved in modification is thus one of alteration and it must be
considered how radical the alteration is. The alteration may consist of additions or
subtractions or other changes in what is already there or, no doubt, any combination
of these. But, throughout, there must, I think, be the continued existence of what in
substance is the original entity. Once one reaches a stage of wholesale rejection and
replacement, the process must cease to be one of modification"
Yet again in Puran Lal v. President of India [(1962) 1 SCR 688], it was stated:Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

"The word modification means the action of making changes in an object without
altering its essential nature or character"
Mr. Chagla strongly relied upon a decision of a Division Bench decision [Coram Justice B.P. Singh,
CJ (as His Lordship then was) and Justice Ranjana Desai] of the Bombay High Court in M.A.
Panshikar v. State of Maharashtra through its Urban Development Department & another, [2002
(5) BCR 318] wherein the Bench observed that Section 37(1AA) empowers the State to effect changes
both minor and even major so long it does not change the character of the plan. In that case itself
the Bench held that the modification in question did not bring about a change in the character of
development plan on account of the increased FSI specified therein.
Reliance has also been placed by Mr. Chagla on Pune Municipal Corporation and Another v.
Promoters and Builders Association and Another [(2004) 10 SCC 796] wherein while interpreting
Section 37 of the Act a passing reference was made that such changes should be minor in nature.
This Court therein did not consider the amendment carried out in the marginal note thereof. In that
case, the State Government while allowing a proposal for modification submitted by Pune Municipal
Corporation added some words which were challenged on the ground that the same was beyond the
powers of the State Government under Section 37. Such a contention was upheld by the High Court.
This Court, however, reversed the said decision. In the said decision, the meaning and scope of the
phrase "character of plan" did not directly or indirectly fall for consideration. The expression "minor
changes" were used by this Court only for holding that the State Government exercises wide
discretion. The said words were not used for determination of the scope and ambit of the phrase
"character of the plan".
Reliance has also been placed by Mr. Chagla upon a decision of this Court in Balakrishna H. Sawant
and Others v. Sangli, Miraj & Kupwad City Municipal Corpn. and Others [(2005) 3 SCC 61] wherein
also a case of this nature did not fall for consideration.
We may place on record that the total area affected by the change on an average would be
approximately 3.07% of the total area of the wards and the mill lands occupy only 0.6% of the entire
land area of Bombay. When the question as regard validity or otherwise of the 1991 Regulations
came up for consideration before the Bombay High Court, Sujata Manohar, J. (as the learned Judge
then was) speaking for the Division Bench in Nivara Hakk Samiti [WP No. 963 of 1991] wherein the
writ petitioners also were parties observed that the word "modification" being somewhat indefinite
in its ambit must be distinguished from a radical illustration.
A development plan is an organic document in the sense that periodic changes are contemplated
thereby. A development plan is required to be changed every 20 years. Such changes are to be
brought about keeping in view the past experience of the planning authority and the intended future
development of the town. While, therefore, interpreting the words "change in the character of plan"
the question would be as to whether the change in the character is referable to alteration of the
entire plan. The change in the character would, therefore, necessarily mean the change in the basic
feature thereof and the entire plan as a whole wherefor the same must be read in totality. In this
case, the changes made do not brought about any significant changes so as to come to a conclusionBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

that its basic features are altered. For the reasons aforementioned, we are of the considered view
that the clarification issued by the State is not violative of Section 37 of the MRTP Act.
SUSTAINABLE DEVELOPMENT AND PLANNED DEVELOPMENT VIS-@-VIS ARTICLE 21 OF
THE CONSTITUTION OF INDIA It is often felt that in the process of encouraging development the
environment gets sidelined. However, with major threats to the environment, such as climate
change, depletion of natural resources, the entrophication of water systems and biodiversity and
global warming, the need to protect the environment has become a priority. At the same time, it is
also necessary to promote development. The harmonization of the two needs has led to the concept
of sustainable development, so much so that it has become the most significant and focal point of
environmental legislation and judicial decisions relating to the same. Sustainable development,
simply put, is a process in which development can be sustained over generations. Brundtland Report
defines 'sustainable development' as development that meets the needs of the present generations
without compromising the ability of the future generations to meet their own needs. Making the
concept of sustainable development operational for public policies raises important challenges that
involve complex synergies and trade offs. The Indian judiciary has time and again recognised this
principle as being a fundamental concept of Indian law.
In Vellore Citizens' Welfare Forum v. Union of India and Others [(1996) 5 SCC 647], this Court laid
down the salient principles of sustainable development consisting of the Precautionary Principle
and the Polluter Pays Principle being its essential features stating:
"The "Precautionary Principle"  in the context of the municipal law  means:
(i) Environmental measures  by the State Government and the statutory authorities
 must anticipate, prevent and attack the causes of environmental degradation.
(ii) Where there are threats of serious and irreversible damage, lack of scientific
certainty should not be used as a reason for postponing measures to prevent
environmental degradation.
(iii) The "onus of proof" is on the actor or the developer/industrialist to show that his
action is environmentally benign.
12. "The Polluter Pays Principle" has been held to be a sound principle by this Court in Indian
Council for Enviro-Legal Action v. Union of India. The Court observed: (SCC p. 246, para 65) "... we
are of the opinion that any principle evolved in this behalf should be simple, practical and suited to
the conditions obtaining in this country".
The Court ruled that: (SCC p. 246, para 65) "... once the activity carried on is hazardous or
inherently dangerous, the person carrying on such activity is liable to make good the loss caused to
any other person by his activity irrespective of the fact whether he took reasonable care while
carrying on his activity. The rule is premised upon the very nature of the activity carried on".Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

Consequently the polluting industries are "absolutely liable to compensate for the harm caused by
them to villagers in the affected area, to the soil and to the underground water and hence, they are
bound to take all necessary measures to remove sludge and other pollutants lying in the affected
areas". The "Polluter Pays Principle" as interpreted by this Court means that the absolute liability for
harm to the environment extends not only to compensate the victims of pollution but also the cost of
restoring the environmental degradation. Remediation of the damaged environment is part of the
process of "Sustainable Development" and as such the polluter is liable to pay the cost to the
individual sufferers as well as the cost of reversing the damaged ecology."
This Court, referring to Articles 48-A and 51-A(g) of the Constitution of India, observed that the
aforementioned principles are part of the constitutional law.
In Intellectual Forum, Tirupathi v. State of A.P. & Ors. [JT 2006 (2) SC 568], it was stated:
"In light of the above discussions, it seems fit to hold that merely asserting an
intention for development will not be enough to sanction the destruction of local
ecological resources. What this Court should follow is a principle of sustainable
development and find a balance between the developmental needs which the
respondents assert, and the environmental degradation, that the appellants allege."
The MRTP Act does not exclude these principles. Unless they are so excluded, they are to be read in
the statute both in the substantive legislation as also delegated legislation.
In A.P. Pollution Control Board v. Prof. M.V. Nayudu (Retd.) and Others [(1999) 2 SCC 718], this
Court reiterated the necessity of institutionalizing scientific knowledge in policy-making or using it
as a basis for decision-making by agencies and courts.
In Narmada Bachao Andolan v. Union of India and Others, [(2000) 10 SCC 664], this Court
emphasized the exercise which is required to be undertaken by the committees before policy
decisions are taken. In M.C. Mehta v. Union of India and Others [(1996) 4 SCC 351], this Court
directed shifting of industries which are not in conformity with the provisions of the Master Plan.
Yet again in M.C. Mehta v. Union of India and Others [(2004) 6 SCC 588], this Court negatived the
attempt on the part of the State for in situ regularization by way of change of policy. The court
emphasized that in terms of Article 243-W of the Constitution of India, the Municipalities have
constitutional responsibilities of town planning stating:
"The Municipal Corporation has the responsibility in respect of matters enumerated
in the Twelfth Schedule of the Constitution of India, regulation of land use, public
health, sanitation, conservancy, solid-waste management being some of them"
In M.C. Mehta v. Union of India and Others [(2005) 2 SCC 186], this Court issued further directions
stating that the Government must have due regard in letter and spirit to aspects that have been
mentioned in the earlier place including rights of individuals who are residents of the localitiesBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

under consideration for in situ regularization by amendment of the Master Plan. In M.C. Mehta v.
Kamal Nath and Others [(1997) 1 SCC 388], it was stated:
"The resolution of this conflict in any given case is for the legislature and not the
courts. If there is a law made by Parliament or the State Legislatures the courts can
serve as an instrument of determining legislative intent in the exercise of its powers
of judicial review under the Constitution. But in the absence of any legislation, the
executive acting under the doctrine of public trust cannot abdicate the natural
resources and convert them into private ownership, or for commercial use. The
aesthetic use and the pristine glory of the natural resources, the environment and the
ecosystems of our country cannot be permitted to be eroded for private, commercial
or any other use unless the courts find it necessary, in good faith, for the public good
and in public interest to encroach upon the said resources."
[Emphasis supplied] In Consumer Education & Research Society v. Union of India and Others
[(2000) 2 SCC 599], this Court issued certain directions directing the State to constitute a
committee consisting of experts for study of the relevant environmental aspects as also for study of
the effects of the present limited mining operation permitted by this Court. The State Government
was further directed to take steps to monitor air and water pollution in that area. Such a Committee
having been constituted and the report having been submitted, this Court in [(2005) 10 SCC 185]
issued some directions to the State:
"Considering all these aspects, we are of the view that the recommendation of the
expert body to the effect that the mining operations should not be allowed within 2.5
km beyond the boundaries of Narayan Sarovar Wildlife Sanctuary which obviously
means the notified boundary in force, is prima facie acceptable and could serve as a
guideline in the matter of grant or renewal of mining leases by the State Government.
Final orders in this regard will be passed after the details mentioned in the next
paragraph are furnished."
This Court, therefore, in appropriate cases may monitor implementation of the constitutional policy
of sustainable development upon directing the State to appoint expert committees. In Sushanta
Tagore and Others v. Union of India and Others [(2005) 3 SCC 16], this Court was concerned with
interpretation of the provisions of Visva-Bharati Act, 1951 which was enacted to preserve and
protect the uniqueness, tradition and special features of Visva-Bharati University. Therein, this
Court opined:
"It may be true that the development of a town is the job of the Town Planning
Authority but the same should conform to the requirements of law. Development
must be sustainable in nature. A land use plan should be prepared not only having
regard to the provisions contained in the 1979 Act and the Rules and Regulations
framed thereunder but also the provisions of other statutes enacted therefor and in
particular those for protection and preservation of ecology and environment.Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

As Visva-Bharati has the unique distinction of being not only a university of national
importance but also a unitary one, SSDA should be well advised to keep in mind the
provisions of the Act, the object and purpose for which it has been enacted as also the
report of the West Bengal Pollution Control Board. It is sui generis."
In that case, this Court interfered as the planning authorities were found to have violated the
provisions of a Parliament Act which had a direct ecological impact of a special nature on the area
over which the Visva Bharati University had jurisdiction.
Mr. Chagla relied upon some decisions of this Court in this behalf which we may notice now.
In Indian Handicrafts Emporium and Others v. Union of India and Others [(2003) 7 SCC 589],
wherein one of us was a party, this Court opined:
"The provisions of the said Act must be construed having regard to the purport and
object it seeks to achieve. Not only, inter alia, wild animal is to be protected but all
other steps which are necessary therefor so as to ensure ecological and environmental
security of the country must be enforced. "
In Virender Gaur and Others v. State of Haryana and Others [(1995) 2 SCC 577], it was stated:
"It is seen that the open lands, vested in the Municipality, were meant for the public
amenity to the residents of the locality to maintain ecology, sanitation, recreation,
playground and ventilation purposes. The buildings directed to be constructed
necessarily affect the health and the environment adversely, sanitation and other
effects on the residents in the locality. Therefore, the order passed by the
Government and the action taken pursuant thereto by the Municipality would clearly
defeat the purpose of the scheme"
Lahoti, J. (as the learned Chief Justice then was) speaking for a Division Bench of this Court in
Friends Colony Development Committee v. State of Orissa and Others [(2004) 8 SCC 733] stated the
law in the following terms:
"In all developed and developing countries there is emphasis on planned
development of cities which is sought to be achieved by zoning, planning and
regulating building construction activity. Such planning, though highly complex, is a
matter based on scientific research, study and experience leading to rationalisation of
laws by way of legislative enactments and rules and regulations framed thereunder.
Zoning and planning do result in hardship to individual property owners as their
freedom to use their property in the way they like, is subjected to regulation and
control. The private owners are to some extent prevented from making the most
profitable use of their property. But for this reason alone the controlling regulations
cannot be termed as arbitrary or unreasonable. The private interest stands
subordinated to the public good. It can be stated in a way that power to planBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

development of city and to regulate the building activity therein flows from the police
power of the State. The exercise of such governmental power is justified on account of
it being reasonably necessary for the public health, safety, morals or general welfare
and ecological considerations; though an unnecessary or unreasonable intermeddling
with the private ownership of the property may not be justified."
These decisions do not lay down any law which is different from what we have said herein. The
development of the doctrine of sustainable development indeed is a welcome feature but while
emphasizing the need of ecological impact, a delicate balance between it and the necessity for
development must be struck. Whereas it is not possible to ignore inter- generational interest, it is
also not possible to ignore the dire need which the society urgently requires.
In a case of this nature, an endeavour should be made in giving effect to the intention of the
legislature. For the said purpose, it is necessary to ascertain the object the legislature seeks to
achieve. It may also be necessary to address questions as regards the nature of the statute. Does the
statute ex facie point out degradation of the environment? Would by change of user envisaged by the
legislature, the existing open space be decreased? Would it be necessary in view of the legislative
scheme to invoke the precautionary principles?
Answers to the said questions in this case are to be rendered in the negative. The main purpose of
the legislation is revival of industry inter alia by modernisation and shifting of industry. Article 21
guarantees a right to a decent environment and, thus, what should be the parameters therefor would
essentially be a legislative policy. Undoubtedly, different criteria may be laid down to achieve
different purposes. When the discretionary power under a statute is arbitrarily exercised, evidently
the court will not tolerate the same and strike it down. DCR 58, however, ex facie does not impair
sustainable development of the town of Bombay.
Mr. Salve has placed before us several decisions of American Courts to suggest that environmental
considerations into town planning laws have got the upper hand in the matter of interpretation of
the town planning provisions in a broad manner. The said discussions are not relevant for our
purpose. He further relied upon a decision of House of Lords in South Bucks District Council v.
Porter Chichester District Council v. Searle and others [(2003) 3 All ER 1] wherein it was held:
"Over the past 60 years there has been ever- increasing recognition of the need to
control the use and development of land so as to prevent inappropriate development
and protect the environment. This is, inevitably, a sensitive process, since it
constrains the freedom of private owners to use their own land as they wish. But, it is
a very important process, since control, appropriately and firmly exercised, enures to
the benefit of the whole community."
The statement of law propounded by us do not lay anything contrary to the said dicta. Herein, an
attempt has been made to interpret DCR 58 in such a manner so that it not only enures to the
benefit of the whole community but also give effect to the purport and object thereof.Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

REDUCTION IN GREEN AREAS IS-@-VIS ENVIRONMENTAL IMPACT ASSESSMENT While
considering the environmental aspect, we must not forget that before constructions are allowed to
be commenced and completed, the exercise for environmental impact assessment is mandatorily
required to be done by the competent authority. An expert body albeit within the fourcorners of the
regulatory provisions would be entitled to consider the entire question from the environmental
aspect of the matter which would undoubtedly take into consideration all relevant factors including
the question as to whether the same is likely to have adverse effects on ecology or not. Consideration
of ecological aspects from the court's point of view cannot be one sided. It depends on the fact
situation in each case. Whereas the court would take a very strict view as regard setting up of an
industry which is of a harazardous nature but such a strict construction may not be resorted to in
the case of town planning. The counsel before us referred to the decision in Padma v. Hiralal Motilal
Desarda and Others [(2002) 7 SCC 564], wherein it was stated:
"The significance of a development planning cannot therefore be denied. Planned
development is the crucial zone that strikes a balance between the needs of
large-scale urbanization and individual building. It is the science and aesthetics of
urbanization as it saves the development from chaos and uglification. A departure
from planning may result in disfiguration of the beauty of an upcoming city and may
pose a threat for the ecological balance and environmental safeguards."
This, however, has no relevance in the present case. Whereas even in a case of town planning, the
court may consider the action on the part of the State while exercising its discretionary jurisdiction
in changing the user with all seriousness; it deserves particularly when it is contrary to the
development plan, it may not do so where it is within the contours thereof. The question has to be
considered having regard to the fact that in stead and place of industries which would have
otherwise a far larger environmental impact vis-`-vis the buildings which would be constructed
would be used for residential or commercial purposes. The problem will have to be addressed from
the point of view that as a part of the scheme framed by the State in making DCR 58, the money
would be invested not only for the purpose of revivial and / or rehabilitation of the sick or closed
mills, the same would also give a boost to modernization and/ or shifting of mills and/ or parts
thereof from residential area to outside the town of Bombay. It is not disputed that modernization
and shifting of the mills from Bombay to the suburbs would go a long way in solving ecological
problems of the town. If some mills opt for modernization, the ecological impact would be lesser
than the mills which are existing for a very long time. While setting up modern mills in place of old
ones, evidently approval of the Commissioner and sanction of the State in relation to the scheme
would be imperative and while doing the exercise of scrutiny as regard environmental impact
assessment would be required to be gone into. Furthermore, such a step would also be in
consonance with the present economic policy of the State viz. the policy of disinvestment and
privatization. Such a policy is not alien to the scheme of MRTP Act. We, however, fail to understand
that if raising of construction by the mill owners had been questioned on ecological considerations
why the Appellants failed and/ or neglected to raise such a contention as regard the constructions to
be raised by MHADA. Construction of buildings, if results in an impact on ecology; it was expected
that the writ petitioners  Respondents would question the validity thereof. They might have not
done so having regard to the fact that the same would invite adverse comments from the workers.Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

Even the mill owners did not question the constitutionality of such a provision presumably because
they considered the provisions of DCR 58 as part of a package deal. Presumably, they also thought
that if change of user is granted, even sale of a portion of land would compensate them for the
portion they are required to surrender to MCGM by way of public greens and/ or housing schemes
to be undertaken by MHADA.
The notification of 7th July, 1994 under the Environment Protection Act, 1986 sought to amend the
notification dated 27th January, 1994. The primary purpose for issuing such notification was to state
in detail the nature of the project, the extent of work carried on in respect thereof which would
require environmental impact assessment clearance from the committee. Before us, the findings of
the High Court as regard requirement to comply with the statutory directions issued by the Central
Government for the purpose of getting the environmental impact assessment in respect of each and
every project is not in question. Parties before us have raised rival contentions. It was contended by
some of the Appellants that the said notification will have no application in the matters they
represent; contentions have also been raised that despite the said notification having come into
force, the building plans are being sanctioned and constructions to a large extent are being carried
out without obtaining clearance from the E.I.A. Committee. We do not intend to determine the
factual dispute keeping in view the fact that in cases in which the said notification would apply, the
committee required to assess the environmental impact as regard each project shall go into the
individual cases and pass appropriate orders. The apprehension that by reason of the 2001
Regulations, the existing green area would be reduced, does not appear to be based on any factual
data. According to the Respondent Nos. 1 and 2, in terms of 1991 Regulations, the residents would
have got 165 acres for greens whereas under the new Regulations, they would get approximately 32
acres of greens.
'Reduction in green areas' envisages reduction of an area which was existing.
The said submission does not have any factual foundation. No actual greens existed by way of
designation under Section 22(c) of the MRTP Act or otherwise under any other legislation. In any
event, DCR 58 of 1991 did not work. Increase in FSI by reason of 2001 Regulations even according
to Mr. Salve would have added many more floors which thus became otherwise permissible in law. It
ensures giving of some areas voluntarily by the mill owners. It is, however, one thing to say as to
what actual area would be available for public greens but it is another thing to say that by reason
thereof a change in the character of plan itself has taken place as a result whereof the green areas
would be reduced. The Appellants have contended that in terms of the 2001 Scheme, the extent of
actual surrender has substantially gone up in comparison to the offer of surrender made during the
period 1991-2001. They have contended that the lands available to MCGM and MHADA would also
be higher. It is also the contention of the Appellants that larger volumes of private greens which
would be available although the same may not be a substitute for public greens, but would certainly
enhance the ecological balance. It is also contended that the land area available towards the owner's
component would be higher and the private green areas emerging therefrom would also be
correspondingly higher. Dr. Singhvi has further submitted that by reason of implementation of the
Zonal Regulations, three more Shivaji Parks would be added. The contentions raised by the
Appellants may or may not be correct. However, only because the ideal situation could not beBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

brought about by the State while inserting 2001 Regulations, the same, in our opinion, would not
lead to a conclusion that the same would be ultra vires Section 37(1AA) of the MRTP Act.
If the government intends to create more green areas in mill lands it has to avail of one of three
alternatives, namely:
(a) designation/reservation in terms of Section 22(c);
(b) acquisition of land; or
(c) voluntary surrender of land.
It was contended by the NTC that DCR 58 of 2001 is an attempt to induce higher voluntary
surrender of land by the mill owners. The first two alternatives would only put additional time and
costs for the government in terms of procedures for acquisition and payment of compensation. It
was also contended that through the Integrated Development Scheme, NTC have made themselves
liable to surrender 26 acres of land to MHADA and 23 acres to MCGM. It is estimated that for all the
mills more than 70.00 acres of land would be available for public greens and value thereof would
approximately be 750 crores (calculated on the basis of auction price).
It is not at all in dispute that all the 58 cotton textile mills are spread over seven wards of MCGM,
namely, A, E, F (South), F (North), G(South), G(North) and L. They are not spread over the entire
town of Bombay. The mill lands occupy only 3.07% of the wards and 0.65% of the entire town of
Bombay as is evident from the following chart:
S.No. Name of Ward No. of mills % of area occupied by mills
1.
A 0.31%
2. E 6.61%
3. F(South) 5%
4. F(North) 0.67%
5. G(South) 9.95%
6. G(North) 1.43%
7. L 0.88% From the affidavit affirmed by Shri Raoul S. Thackersey, it appears that the mill lands
available for development, both open and built-up area, aggregate 400 acres approx. and not 600
acres of land as contended by the writ petitioners. Approximately, 200 acres of mill landsBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

comprising running textile mills are not available for development. Out of the total lands, 87% of the
lands occupied by the mill owners are freehold lands and 13% of the lands are lease-hold either from
the State or private parties. All the textile mills are not within I-2 Zones. 13 cotton textile mills are
situated within the residential zone. As per the provisions of DCR 58 of 1991, it was in the discretion
of the owner whether to come forward for total redevelopment of the mill and/ or to utilize the
existing built up area for commercial purposes, etc. However, out of the area which would have been
available for sharing lands with M.C.G.M./ MHADA under DCR 58 of 1991 in the cases of the
proposals which were approved for total/ partial redevelopment would have been as under:
S.No. Name of the Mill Land for MCGM in sq. m.
Land for MHADA in sq. m.
Others (for public housing) in sq. m.
1.
Matulya Mill 5641.40 4616.46 Nil
2. Swadeshi Mill 24482.00 12612.13 12612.13
3. Moder Mill 8626.56 7058.12 Nil However, the area available for M.C.G.M. & MHADA for the
proposals approved under modified DCR 58 of 2001 for total/ partial redevelopment are as under:
S.No. Name of the Mill Proposed as per the provisions of modified DCR 58(1)(b)
MCGM in sq. m.
MHADA in sq. m
1.
Standard Mill (China Mill) 1525.14 1247.84
2. Standard Mill Prabhadevi 1247.80 1020.93
3. Morarjee Goculdas Unit No. 4479.37 1276.96 Located at Kandivli Unit
4. Morarjee Goculdas Unit No.
5. Piramal Mill 1533.46 1254.65
6. 588.41 481.43
7. Matulya Mill 474.68 388.37Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

8. Modern Mill 1163.31 Nil
9. Shreeram Mill 1848.25 1572.20
10. Victoria Mill 545.34 4537.10
11. Hindustan Spg. & Wvg.
662.61 542.12
12. Hindustan Spg. & Wvg.
Mill (Crown Mill Division) 1134.81 928.67
13. Simplex Mill 1363.54 1115.63
14. New Great Eastern Spg. & Wvg. Mills 1533.30 1254.52
15. Swan Mill (Kurla) 4663.70 3815.76
16. 2628.00** 2946.54***
17. 7873.63** 8828.01***
18. Elhpinstone Mills 2796.40** 3135.35**
19. Jupiter Mills 1484.75** 1664.72***
20. New Hind Textile Mills 2034.88** 2281.54***
21. Mumbai Mills (Sakseria Mills) 10631.02** 11919.63***
22. Apollo Mills & its property i.e. Morarka Bungalow 4714.81** 5286.33***
23. Swan Mill (Seweree) 4059.00 3321.00
24. Western India Spg. & Wvg.
Mill 1436.00 1175.00
25. Bombay Dyeing (Spring Mill Wadala) 25775.24 26556.30
26. Bombay Dyeing Textile Mill (Lower Parel) 7052.86 5770.52 ** Proposed to be earmarked and
handed over at India United Mill No. 2 & 3.Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

*** Proposed to be earmarked at New Hind Textile Mill and India United Mill No. 2 & 3"
The difference can, thus, at once be felt.
The main features of the new DCR 58 will have to be construed having regard to the
changes brought about thereby. For the aforementioned purpose, we may notice the
following chart showing the purported reduction of space:
Ward A E F(South) F(North) G(South) G(North) L % of total Open Space in each
ward as per old DCR 58 5.79% 9.29% 4.47% 6.12% 12.43% 4.40% 19.30% % of total
Open Space in each ward as per new DCR 58 5.73% 7.84% 3.37% 5.97% 10.29%
4.08% 19.11% Ward wise reduction in open space 0.06% 1.45% 1.1% 0.15% 2.14%
0.32% 0.19% If Regulation prior to 1991 was implemented, the average of the Green
Areas would have come to 8.33% whereas after 1991, it comes to 8.16%. From what
has, thus, been noticed hereinbefore, it is difficult to agree with the contentions of the
writ petitioners that there had been substantial reduction in green area. It must also
be placed on record that civic load in respect of residential construction so far as land
occupied by the mills owners was more than the present ratio of FSI at 1.33%. FSI
given for construction of buildings to MHADA itself would be 1.596 i.e. almost 1.6%.
It is contended on behalf of the Appellants that out of the total area of 2,430,000 sq. m., the lands
which would be available to MCGM as public green is 11.53% and the private greens works out to be
20.87%, thus, totalling 32.43%. It is also contended that the purported reduction ward- wise will
vary from 0.06% to 2.14% and in most cases it would be 1.1% or less. From what has been noticed
hereinbefore, it is evident that the purported reduction in green area compared to pre-1991
situation, would not create much difference so far as maintenance of the ecological balance is
concerned by giving effect to 2001 Regulations vis-`-vis the 1991 Regulations.
SALE OF LANDS OF NTC MILLS A large number of cotton and other textile mills were situate in
the town of Bombay. The workmen of the said cotton textile mills resorted to a strike as a result
whereof a large number of textile mills were closed. The mills occupied lands measuring about 600
acres. The Parliament of India enacted the Sick Textile Undertakings (Nationalisation) Act, 1974 (for
short "the 1974 Act") for acquisition and transfer of the sick textile undertakings, and the right, title
and interest of the owners thereof specified in the First Schedule appended thereto. The said Act
received the assent of the President of India on 21st December, 1974. It came into force from 1st day
of April, 1974. In terms of Section 3 of the said Act, every sick textile undertaking and the right, title
and interest of the owners thereto stood transferred to and vested absolutely in the Central
Government with effect from the appointed day. The sick textile undertakings which stood vested in
the Central Government by virtue of sub-section (1) of Section 3 of the said Act had been transferred
to and vested in the National Textile Corporation.
The Parliament of India again enacted the Textile Undertakings (Nationalisation) Act, 1995 (for
short "the 1995 Act") for acquisition and transfer of textile undertakings specified in the First
Schedule appended thereto with a view to augmenting the production and distribution of differentBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

varieties of cloth and yarn so as to subserve the interests of the general public for matters connected
therewith or incidental thereto. In terms of the provisions of the said Act, 25 mills notified
thereunder vested in NTC. It, inter alia, has two subsidiaries, viz., National Textile Corporation
(South Maharashtra) and National Textile Corporation (North Maharashtra). By reason of the 1974
Act and the 1995 Act, about 119 textile mills situate throughout the country were nationalized. Out of
the 25 mills of National Textile Corporation which are in the town of Bombay, 18 mills were lying
closed. 14,800 employees were retrenched. National Textile Corporation together with its six other
subsidiary corporations were referred to BIFR under SICA sometime between 1992-1993. The said
proceedings remained pending for nearly ten years. BIFR formulated eight schemes. The schemes
were approved by all concerned as well as the operating agencies. The matter came up before this
Court and by an order dated 27.9.2002 the scheme as sanctioned by BIFR was directed to be
implemented. The said order was passed in a special leave petition filed by NTC (IDA) Employees
Association v. Union of India & Ors. [SLP No. 16732 of 1997 dated 7.5.1999] which is in the
following terms :
"We have been informed that BIFR has already formulated right schemes which
stand approved by all concerned and agencies. Let the schemes as sanctioned by
BIFR be implemented. The Special Leave Petition and the Transfer Petition stand
disposed of accordingly."
The salient features of the said schemes are as under:
(a) One time settlement qua banking institutions;
(b) Identification of closed unviable mills;
(c) Sale of surplus assets including land;
(d) Rehabilitation/revival of unviable mills;
(e) An Asset Sale Committee (ASC) under Section 32(1) of the SICA Act for the sale of
the assets was to be constituted. A nominee of BIFR was one of the members thereof.
It was constituted to ensure transparency in the sale of assets of the mills.
Guidelines for the said ASC had also been set out. Pursuant to or in furtherance of the said schemes,
National Textile Corporation closed down unviable mills and mobilized a large sum towards
implementation thereof. Some of the steps taken in this behalf are as under:
(a) An amount of Rs. 643.94 crores were spent by the National Textile Corporation
for payment of Modified Voluntary Retirement Scheme to workers. The said amount
was disbursed before April, 2003.
(b) National Textile Corporation issued bonds (series No. IX) whereby a sum of Rs.
2028 crores was raised. The said bonds carried interest ranging from 6.10% to 10%Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

per annum.
(c) Expenses have been incurred towards wage bills amounting to Rs.
1839 crores. The accumulated total loss of National Textile Corporation was about Rs. 4055.35
crores including the amounts payable to the banks/ financial institutions.
(d) An amount of Rs. 84 crores had been paid to the workers on account of Provident Fund and ESI
dues.
(e) Having regard to the one time settlement arrived at with banks and financial institutions, a sum
of Rs. 72 crores had been paid.
Pursuant to the said Scheme dated 25.7.2002, National Textile Corporation submitted an Integrated
Development Plan on 3.5.2005 for all the 25 mills situate in the town of Bombay. The said scheme
was prepared keeping in view DCR 58 as modified in 2001.
On or about 27.10.2004, Municipal Corporation of Greater Mumbai (MCGM), however, approved
the scheme only for seven mills, permitting sale of five mills and surrender of India United Mills 2
and 3 as well as New Hind Textile Mill as share of Maharashtra Housing and Area Development
Authority (MHADA) and MCGM.
An integrated plan was set out for sale of lands in terms whereof lands situate in other mills were
kept aside to provide open lands which may be required in the event the writ petition filed by the
Writ Petitioners - Respondents was allowed. Negotiations were held between the purchasers and
NTC as regards sale of the said land. Several queries were made by the intending purchasers which
were duly answered. Specific assurances were given to the bidders by NTC that deficiencies in open
space shall be made good by making available equivalent open space from its other mills in the
vicinity, in the event the writ petition was allowed. Clarifications were also issued to the effect that
NTC was committed to sell lands specified in respect of each mill as well as specified in FSI as
approved by the Bombay Municipal Corporation and, thus, any extra surrendering of land, if any
occasion arises therefore, would be borne by it. It was furthermore clarified that "assuming that the
court decides otherwise, then NTC has other mills to offer as far as the share of MHADA and MCGM
is concerned and NTC will take care of the interest of the purchasers". An undertaking had also been
given by it in the High Court which was duly recorded in its interim order dated 1.4.2005 which
reads as under :
"On behalf of NTC the learned counsel submits that they should be allowed to
proceed with the sale of Jupiter Mills. The matter is pending before this Court.
However, considering the urgency which counsel make out any further as NTC has 25
mills the request for confirming the sale can be agreed to, subject to the following
conditions:Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

(i) NTC will file an undertaking in this Court, that on the Court passing an order on
interim relief they will comply with the order of the Court including if a situation
arises of reserving the land in the other mills for which development is sought in
terms of the order that may be passed by the Court.
On such undertaking being filed, it is open to NTC to confirm the sale of Jupiter Mills."
It was further directed:
"(ii) Considering that the matter has now been adjourned to 20-4-2005 Respondent
2 Municipal Corporation directed not to approve any further layouts, issue IOD, or
CC without the permission of this Court or till further orders."
As regard, sale of lands from NTC Mills, the High Court in its judgment opined that the sale of its
mills by NTC was contrary to this Court's orders dated 11.05.2005 and 27.09.2002 as also contrary
to the BIFR scheme in the following terms :
"273. It is very clear from the order of the Supreme Court dated 11th May, 2005, that
every sale after the said order by either NTC-MN or NTC-SM will be only in terms of
the scheme framed by the BIFR. Only sale of land from Jupiter Mills had taken place
earlier.
274. But even the sale of land from Jupiter Mills will have to be in accordance with
the BIFR scheme, as per earlier order of the Supreme Court dated 27th September,
2002.
275. The sanctioned scheme of BIFR, clearly provides that the surrender of land to
MCGM and MHADA in respect of each mill shall be out of the land of such mill itself
and not out of the land of some other mill. Hence, the integrated scheme in respect of
7 mills approved by MCGM on 27th October, 2004 (which provides for aggregation of
land to be surrendered to MCGM and MHADA in respect of the five mills sold, on
two other mills) is contrary to the sanctioned scheme, which clearly does not
contemplate any such integration, (emphasis supplied).
276. In paragraph 5 of the affidavit dated 12th September, 2005 filed by NTC, it is
expressly admitted that the integrated development scheme submitted to MCGM is a
modification of the sanctioned scheme of BIFR. It is stated that a proposal for
modification of the sanctioned scheme has been made to BIFR about a year ago. It is
submitted by the Petitioners that this application for sanction of the BIFR to such
modifications was made in view of the direction of the Supreme Court dated 27th
September 2002 "Let the scheme as sanctioned by BIFR be implemented". It is stated
in the said affidavit of NTC that "The sanction of BIFR is awaited and Respondent
Nos. 3 and 4 will implement the same after approval of BIFR". However, contrary to
the aforesaid statement and in breach of the orders of the Hon'ble Supreme Court,Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

NTC has sold five mills under the integrated development scheme approved by
MCGM without the approval of the BIFR to the modifications in the sanctioned
scheme.
277. Hence we are clearly of the view that the sale of lands by NTC from 5 mills viz.
(a) Apollo Textile Mills (SM), (b) Mumbai Textile Mills (SM), (c) Elphinstone Mills
(SM), (d) Kohinoor Mill No. 3 (MN) and (e) Jupiter Mills are clearly contrary to the
sanctioned BIFR Scheme and both the orders of Supreme Court dated 11th May,
2005 and 27th September, 2002."
We for the reasons stated hereinafter are not in agreement with the conclusion of the High Court in
this behalf.
It is not in dispute that in the special leave petition wherein the said order dated 27.09.2002 was
passed, the parties therein were not concerned with the sale of any mill lands or for enforcement
and/or interpretation of any regulation framed under the MRTP Act. The said observations were
made while entertaining an application filed on behalf of the workmen and not for any other
purpose. The observations were not made for the purpose of determination of any of the issues
involved in the matter. It could not, thus, be treated to be a direction on the part of this Court. The
question of the sale of mill lands by NTC could be held to be invalid if the same had been effected
contrary to the direction of this Court and not otherwise.
ORDER OF THIS COURT DATED 11.5.2005 The order of this Court dated 11th May, 2005 reads as
under:
"So far as transactions relating to seven mills belonging to the National Textile
Corporation are concerned, including sale of Jupiter Mills, it is not in dispute that
transactions have reached a final stage. The purchasers of Jupiter Mills have already
paid Rs 16 crores and a sum of Rs 376 crores would pass hands if the transaction is
completed. If the transactions in respect of the mills are not allowed to be completed,
the scheme framed by BIFR would come to a standstill resulting in accrual of interest
payable by the National Textile Corporation to the financial institutions besides other
hardships which may be caused to various other persons including the workers.
We, therefore, having regard to the facts and circumstances of this case as also the
law operating in the field, are of the opinion that interest of justice would be
subserved if the National Textile Corporation is permitted to complete the
transactions in terms of the scheme framed by BIFR but the same shall be subject to
the condition that in the event, the writ petition ultimately succeeds, the vacant land
available from other mills, if necessary, shall be offered by way of adjustment."
In the said order, it was recorded:Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

"Mr Parasaran and Mr Rohatgi, learned Senior Counsel appearing on behalf of the
National Textile Corporation would contend that keeping in view the fact that in
respect of seven mills, negotiations have been entered into, they should be allowed to
be sold off and in the event, the writ petition succeeds, the order of the Court can be
complied with by adjusting vacant land belonging to the other mills.
Mr Iqbal Chagla, learned Senior Counsel appearing on behalf of the writ petitioner
respondents, on the other hand, would urge that the undertaking directed to be given
by the National Textile Corporation is commensurate with the suggestion given by Mr
Parasaran before this Court."
So far as order of this Court dated 11.05.2005 is concerned, again the validity or otherwise of the
BIFR scheme and/or implementation thereof was not in question. An order of this Court, it is
well-known, must be construed having regard to the text and context in which the same was passed.
For the said purpose, the orders of this Court were required to be read in their entirety. A judgment,
it is well settled, cannot be read as a statute. [See Sarat Chandra Mishra and Others v. State of Orissa
and Others, 2006 (1) SCC 638 and State of Karnataka and Others v. C. Lalitha, 2006 (1) SCALE 73].
Construction of a judgment, it is well settled, should be made in the light of the factual matrix
involved therein. What is more important is to see the issues involved therein and the context
wherein the observations were made. Any observation made in a judgment, it is trite, should not be
read in isolation and out of context.
While passing the order dated 11.05.2005, this Court merely noted the terms of the BIFR scheme. It
did not issue any direction to the effect that the sale of the mill land should be effected strictly in
terms thereof or in a particular manner. The BIFR scheme evidently was referred to as this Court
noticed that even statutory authorities constituted under a Parliamentary Act found it necessary to
direct sale of the mill lands in public interest. While considering a writ petition on an environmental
issue, the focus of the court should have been confined thereto. It was in our considered opinion
impermissible for the High Court to examine the BIFR scheme as if the environmental issues were
considered therein. The BIFR exercises its jurisdiction under a statute; the objects whereof are
distinct and different from a town planning scheme. The BIFR is not a town planner. It is not a
development authority. It has nothing to do with the town planning or development scheme or
maintenance of ecological balance. The BIFR was concerned only with the manner in which sick
industrial undertaking should be made to revive. Before passing the said order, it was required to
hear all concerned, namely, the management, the workmen, the financial institutions, banks etc. as
also the operating agencies. It did so.
BIFR appointed IDBI as an operating agency. The authorities were concerned with obtaining
maximum amount by way of sale of mill lands. It was in any event not concerned with the
interpretation and/or applicability of the provisions of the MRTP Act or the Regulation framed
thereunder. BIFR was not concerned with the interpretation of DCR 58 and, thus, only because this
Court in its aforementioned orders dated 27.09.2002 and 11.05.2005 had referred thereto, the same
would not mean that thereby any direction was issued either directly or indirectly that the sale of the
lands pertaining to cotton textile mills must strictly be conducted in accordance with the saidBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

scheme. This Court merely asked the authorities to effect sale of mill land upon following the
scheme framed by BIFR and in accordance with the procedure laid down therefor. This Court in its
order dated 11.5.2005 categorically observed that if the transactions in respect of mills are not
allowed to be completed, the scheme framed by the BIFR would come to a standstill resulting in
accrual of liability of a huge amount by way of interest payable by NTC to the financial institutions
besides other hardships which may be caused to various other persons including the workers. The
scheme framed by the BIFR, therefore, was taken to be a relevant factor only for the purpose of
determining the issues involved in the appeal which arose out of an interim order. It was only in that
situation mention was made to the scheme framed by the BIFR and not for any other purpose. This
Court, as would appear from the submissions made by the counsel for the parties therein merely
intended to give effect to the consensus arrived at the bar that an undertaking by the NTC to the
effect that the order of this High Court would be complied with by way of adjustment of lands from
other mills would subserve the interest of justice. The validity or otherwise of the transaction of
sales of seven mills of NTC were, thus, not open to a further determination by the High Court.
The High Court furthermore appeared to have committed a manifest error in reading down para 5 of
the affidavit of Shri Deodutt B. Pandit. It has been contended before us that the proposed
modification by IDBI as has been referred to therein was not in respect of the five NTC mills,
including Jupter Textile Mill proposed to be sold but was as regards shifting of the activities of
Finlay Mills to Digvijay Textile Mills and that of Gold Mohur Mills to Sitaram Mills. The proposed
modification by the IDBI had nothing to do with sale of five mill lands and, thus, no attempt was
made by NTC to get the order of the BIFR modified in regard thereto as opined by the High Court.
In any view of the matter, the BIFR scheme did not postulate that the surrender of lands to MCGM
and MHADA should be out of the lands of each individual mill itself and not out of the lands of some
other mills. The BIFR had no occasion to say so nor could it do so having regard to the provisions
contained in DCR 58. The writ petitioner-respondents have nowhere denied or disputed that the
seven mills which were put up for sale were unviable ones. The lands pertaining to the mills were
found to be surplus. For the purpose of giving effect to the scheme framed by the BIFR, indisputably
an Asset Sale Committee was constituted to discharge the functions of overseeing the sale of surplus
assets of the said mills. It is furthermore not in dispute that an Integrated Development Scheme was
framed by NTC with the assistance of the architects which was submitted to MCGM and the same
was duly approved. Sanction of sale of two mills out of seven mills was not granted evidently in view
of the pendency of the writ petition. The BIFR scheme or the said Integrated Development Scheme
framed by NTC was not in question in the writ petition. Even when the interlocutory application was
being heard, no submission was made as regard violation of the BIFR scheme or the aforementioned
order dated 27.09.2002. Before this Court as also the High Court the question which arose was as to
whether sufficient lands were available in the event the writ petition was to be allowed.
BIFR SCHEME The order of the BIFR dated 25.07.2002 passed in Case No.536 of 1992 clearly
shows that after hearing the concerned parties it has been noticed that the Government of
Maharashtra although had not given clearance to sell the surplus lands of all the 13 mills in Mumbai
and 5 mills outside Mumbai, as has been done in other states, agreed that with a view to compensate
therefor MCGM would give additional Floor Space Index (FSI) and MHADA would give Transfer
Development Rights which would not enable the NTCMNL to earn full consideration for the land. ItBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

further appears that the Government of Maharashtra had not been asked to make assessment
regarding sacrifice, if any, made by them in this behalf or any benefit which would accrue to them
with the sale so that the Board could consider such a sacrifice/benefit in line with the sacrifices
made with others and if the final stand is not conveyed by the Government, the Board would decide
to confirm winding up of the company which would be detrimental to all who made sacrifices,
wherefor some power was granted. It had further been noticed therein that the Government of
Maharashtra by a letter dated 30.03.2002 i.e. after the 2001 Regulation came into force, although
expressed its inability to give exemption from payment of stamp duty, categorically stated that
necessary permission would be given by the competent authority strictly as per DCR 58 which also
shows that DCR 58 of 1991 was not directed to be taken recourse to. The Board had further noticed
the submissions of the GOI-MOT (promoters) as contained in their letter dated 08.05.2002, inter
alia, to the following effect :
"iii) Appointment of Monitoring Committee to oversee implementation of the
package would not only run contrary to the provisions of SICA but would also result
in duplication of authority and control. BIFR may direct State Government to exclude
NTC package from the purview of such a committee."
It directed constitution of another committee, namely, Assets Sale Committee (ASC) for bringing in
transparency in the sale of assets. Para 21 of the said order runs thus :
"21. Since the GOM had indicated in regard to sale of land that the necessary
permission in this regard would be given by competent authority strictly as per the
provisions of Regulation 58 of the Development Control Regulation (DCR) the
promoters (GOI-MOT) should ensure that in the event of any shortfall of funds,
which would be utilized for rehabilitation of other NTC units, would be brought in by
them for rehabilitation of NTCMNL."
It is, therefore, evident that the Board had all along in its mind the modified regulations only. Yet
again it is evident that for the purpose of valuation only they had referred to DCR 58 which also goes
to show that they had only in mind the 2001 Regulations and not the 1991 Regulations. From what
we have noticed hereinbefore, it is evident that the High Court was not correct in holding that the
sale of mill lands was contrary to the scheme framed by the BIFR. Even otherwise it is preposterous
to suggest that having regard to its statutory function. BIFR would issue any direction which would
be to a great extent defeasive of the purpose for which the schemes were made. We have noticed
hereinbefore the anxiety expressed by the BIFR to have/ save more funds for NTC. Our attention
has also been drawn to the fact that there is nothing to show that the BIFR scheme provided that the
lands were to be surrendered to MCGM and MHADA from each of the mills and not out of the land
of some other mill. The High Court, therefore, committed an error of records. Even otherwise, the
scheme should have been read in the light of the factual matrix obtaining therein as also the extant
regulation. It is furthermore not in dispute that sale of the lands was approved by ASC. One of the
directors of the BIFR, again indisputably, was a member of the said Committee. Once approval of
ASC was obtained, the sales were to be treated as confirmed. The order of this Court dated
11.05.2005 had, thus, been given effect to.Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

It is furthermore not in dispute that conveyance deeds had duly been executed and registered
between the parties. It is also not in dispute that additional lands for open space were available from
the two mills which had not been the subject-matter of sale. The purchasers yet again indisputably
had created third party interest. They had also created financial liabilities by taking loans from
banks/financial institutions. The writ petitioners in the writ proceedings, we have noticed
hereinbefore, at no point of time questioned the sale of surplus land by NTC. In fact, challenge to
such sale even could not be permitted by the High Court. Even assuming that the NTC failed and/ or
neglected to comply with the directions contained in the scheme framed by the BIFR and,
consequently, the orders of this Court, the persons aggrieved thereby could have gone back to BIFR.
It is not in dispute that NTC was a sick company. As a sick company, it might not have in a position
to reopen any close mill at all. Reference to BIFR in terms of Section 16 of the Act evidently was
made for the aforementioned purpose. If the schemes sanctioned by BIFR are given effect to, at least
some of the NTC mills indisputably would be revived. SICA, we have noticed hereinbefore, is a
special statute. It was enacted by the Parliament only with a view to meet the contingencies
contemplated therein. The validity or otherwise of the reference made by NTC to BIFR is not in
question. The writ petitioners did not question the validity of the statutory schemes. No material has
been brought before us to show even the workmen were in any way aggrieved thereby. Had they
been so, they could have preferred an appeal before the BIFR. Even there does not exist any material
to show that at any point of time they had approached the High Court in judicial review. The
workmen were parties in the proceedings before BIFR. Presumably BIFR made the said schemes
after hearing of parties concerned including the workmen.
It is not in dispute that the writ petitioners merely filed an affidavit on 12th July, 2005 before the
High Court alleging that the sale of surplus land by NTC was in violation of this Court's order and/
or the scheme framed by the BIFR. If the prayer in the writ petition had not been amended, we fail
to understand as to on what premise the High Court proceeded to consider the question as regards
the alleged violation of the order of this Court, as also the BIFR Scheme by NTC for the purpose of
setting aside the sale. In a collateral proceeding, the High Court, in our opinion, could not issue any
direction which would not only be contrary to a statutory scheme but defeasive of the purport and
object for which SICA was enacted. Furthermore, it was none of the concern of the writ petitioners 
Respondents as to how BIFR calculated the financial viability by way of sale of surplus land by NTC.
It was equally impermissible for the High Court to consider as to whether despite their being a
provision for multi-mill aggregation in terms of DCR 2001, the same had been taken into
consideration under BIFR Scheme or not. We have noticed hereinbefore that for the purpose of
considering the validity or otherwise of the sale in terms of BIFR Scheme itself, ASC was appointed
wherein a member of the BIFR was also represented. We are, therefore, of the firm opinion that the
judgment of the High Court in this behalf is not correct.
EFFECT OF SUCH SALES ON AUCTION PURCHASERS NTC issued advertisements in several
newspapers for sale of five mills, viz., Jupiter Textile Mill, Mumbai Textile Mill, Apollo Textile Mill,
Kohinoor Mill No. 3 and Elphinstone Spinning and Weaving Mills. Some of the Appellants herein
pursuant to or in furtherance of the said advertisements submitted their tenders.Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

It is, furthermore, not in dispute that out of the five mills sold full payments have been received by
National Textile Corporation from the purchasers of four mills, viz., Jupiter Textile Mill, Mumbai
Textile Mill, Apollo Textile Mill and Kohinoor Mill No. 3. As regards the fifth mill, viz., Elphinstone
Spinning and Weaving Mills, full payment is yet to be received. It is, however, not in dispute that the
processes of auction sales are complete and the applicants are bonafide purchasers in duly
concluded sales. Bona fide purchasers in an auction sale for certain purposes are treated differently.
A distinction has all along been made between a decree holder who came in to purchase under his
own decree and a bona fide purchaser who came in and got at the sale in execution of a decree to
which he was not a party. In a case where the third party is a bona fide auction purchaser, even if
decree is set aside, his interest in an auction sale is saved [See Zain- ul-Abdin Khan v. Muhammad
Asghar Ali Khan - 15 IA 12]. The said decision has been affirmed by this Court in Gurjoginder Singh
v. Jaswant Kaur (Smt.) and Another [(1994) 2 SCC 368].
In Janak Raj v. Gurdial Singh and Anr. [1967 (2) SCR 77], this Court confirmed a sale in favour of
the Appellant therein who was a stranger to the suit being the auction purchaser of the
judgment-debtor's immovable property in execution of an ex parte money decree in terms of Order
XXI Rule 92 of the Code of Civil Procedure. Despite the fact that ordinarily a sale can be set aside
only in terms of Rules 89, 90 and 91 of Order XXI of Code of Civil Procedure, it was opined that the
court is bound to confirm the sale and direct grant of a certificate vesting the title in the purchaser as
from the date of sale when no application in term of Rule 92 was made or when such application was
made and disallowed.
In Padanathil Ruqmini Amma v. P.K. Abdulla [(1996) 7 SCC 668], this Court upon making a
distinction between the decree-holder auction purchaser himself and a third party bona fide
purchaser in an auction sale, observed :
"The ratio behind this distinction between a sale to a decree-holder and a sale to a
stranger is that the court, as a matter of policy, will protect honest outsider
purchasers at sales held in the execution of its decrees, although the sales may be
subsequently set aside, when such purchasers are not parties to the suit. But for such
protection, the properties which are sold in court auctions would not fetch a proper
price and the decree- holder himself would suffer. The same consideration does not
apply when the decree-holder is himself the purchaser and the decree in his favour is
set aside. He is a party to the litigation and is very much aware of the vicissitudes of
litigation and needs no protection.
We are not oblivious of the fact that the decisions referred to hereinbefore have no
direct application in the instant case as the sale of NTC mill lands were not effected in
execution of decrees passed by a competent court of law, but, we have referred
thereto only to highlight that having regard to the principles analogous to the ratio
laid down in the aforementioned decisions the court should make an endeaour to
safeguard the interest of the bona fide purchasers unless and until there exists any
statutory interdict.Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

It is, thus, absolutely clear that the purchasers of the cotton textile mills of the NTC
cannot be made to suffer for no fault on their part and, thus, the High Court
committed a manifest error in that behalf.
DELAY AND LACHES Each one of the learned counsel appearing on behalf of the
Appellants had advanced lengthy submissions in regard to the irretrievable injuries
caused to their respective clients by reason of delay and laches on the part of the writ
petitioners in filing the writ petition. We may notice that the writ petitioners
although raised objections when DCR 58 was proposed to be made in the year 1990
but no such objection was raised when the State proposed to amend the same in
2000. The writ petitioners filed a writ petition before the Bombay High Court
questioning the validity of DCR 58 which was dismissed. They did not prefer any
appeal thereagainst. Some of the mill owners, as noticed hereinbefore, submitted
their scheme as also applications for grant of sanction of their layout plans much
before the clarificatory order dated 28.3.2003 was issued by the State. Requisite
statutory sanctions had been obtained in most of the cases.
Plans were also sanctioned pursuant whereto and in furtherance whereof some of the
Appellants had not only entered into development agreements with third parties; in
some cases they demolished the structures, carried on excavations, raised
constructions; in some cases construction activities are complete and flats had been
sold, the purchasers whereof in turn incurred huge financial liabilities. In almost all
the cases, the workers had been paid a large sum of money which may not be possible
to be recovered. Loans and other financial assistances had been obtained from banks
and other financial institutions by the auction purchasers - appellants for the said
purpose. In some cases, the development agreements have been fully acted upon.
Some of the mills, as noticed hereinbefore, were closed but not referred to BIFR. One
mill, viz., Bombay Dyeing and Manufacturing Company Limited wanted to
modernize its plants and machines. Ruby Mills Limited had a scheme of
shifting-cum-modernization. Schemes were submitted by them in terms of the extant
regulations. The same had been approved by the State.
Although the State issued the clarificatory notification as far back on 28.3.2003, no
step had been taken by the writ petitioners to question the validity thereof within the
reasonable time. The writ petition was filed on 18.2.2005. Even on 21.3.2005, the
writ petitioners filed an affidavit and in paragraph 27 thereof it was categorically
averred that the BIFR Scheme had no bearing on the validity of the rule. Although,
permission for multi-mill aggregation was granted on 27.10.2004, the validity or
legality thereof had not been questioned in the writ petition. Yet again on 19.4.2005,
another affidavit was affirmed on behalf of the writ petitioners wherein it was averred
that the scheme framed by the BIFR was irrelevant for the purpose of its decision. An
application for amending the writ petition was filed only on 7.7.2005 wherein a
contention as regard the interpretative effect of the clarification was raised. Only inBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

the third affidavit dated 12.7.2005, the writ petitioners raised the question in regard
to the correctness or otherwise of BIFR Scheme for the first time only whereupon an
interim order was passed on 1.4.2005 by the High Court.
On 11th May, 2005, this Court set aside the interim order passed by the High Court
whereafter an advertisement was issued by NTC. Tender documents were published
in newspapers and put on website on 21.6.2005 The last date for submission of the
bid was 27.7.2005. On 12.7.2005, the writ petitioners had put an affidavit that such
sale was permissible. The bid was accepted on 13.8.2005 whereafter ASC approved
the sale. After the writ petition was heard and the judgment was reserved on
14.9.2005, the writ petitioners only in their written submissions filed on 15.9.2005,
raised a contention that the sales were contrary to BIFR Scheme as also orders of this
Court. The purchasers on different dates in October/ November purchased lands of
the textile mills and took possession after the deeds of conveyances were executed in
their favour. The purchasers indisputably borrowed a huge amount from banks/
financial institutions and they are required to pay interest on the said borrowed
sums.
Delay and laches on the part of the writ petitioners indisputably has a role to play in
the matter of grant of reliefs in a writ petition. This Court in a large number of
decisions has categorically laid down that where by reason of delay and/ or laches on
the part of the writ petitioners the parties altered their positions and/ or third parties
interests have been created, public interest litigations may be summarily dismissed.
Delay although may not be the sole ground for dismissing a public interest litigation
in some cases and, thus, each case must be considered having regard to the facts and
circumstances obtaining therein, the underlying equitable principles cannot be
ignored. As regards applicability of the said principles, public interest litigations are
no exceptions. We have heretobefore noticed the scope and object of public interest
litigation. Delay of such a nature in some cases is considered to be of vital
importance. [See Chairman & MD, BPL Ltd. v. S.P. Gururaja and Others, (2003) 8
SCC 567]. In Narmada Bachao Andolan v. Union of India [(2000) 10 SCC 664], this
Court held:
"Any delay in the execution of the project means overrun in costs and the decision
to undertake a project, if challenged after its execution has commenced should be
thrown out at the very threshold on the ground of laches if the petitioner had the
knowledge of such a decision and could have approached the court at that time. Just
because a petition is termed as a PIL does not mean that ordinary principles
applicable to litigation will not apply. Laches is one of them."
In R. & M. Trust v. Koramangala Residents Vigilance Group [(2005) 3 SCC 91], this Court laid down
the law in the following terms:Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

"sacrosanct jurisdiction of public interest litigation should be invoked very sparingly
and in favour of the vigilant litigant and not for the persons who invoke this
jurisdiction for the sake of publicity or for the purposes of serving their private ends."
It was further stated:
"There is no doubt that delay is a very important factor while exercising
extraordinary jurisdiction under Article 226 of the Constitution. We cannot disturb a
third party interest created on account of delay. Even otherwise also why should the
Court come to the rescue of a person who is not vigilant in his rights."
In State of Maharashtra v. Digambar [(1995) 4 SCC 683], this Court held:
"where the High Court grants relief to a citizen or to any person under Article 226 of
the Constitution against any person including the State without considering his
blameworthy conduct, such as laches, or undue delay, acquiescence or waiver, the
relief so granted becomes unsustainable even if the relief was granted in respect of
alleged deprivation of his legal right by the state."
However, we do not intend to lay down a law that delay or laches alone should be the sole ground for
throwing out a public interest litigation irrespective of the merit of the matter or the stage thereof.
Keeping in view the magnitude of public interest, the court may consider the desirability to relax the
rigours of the accepted norms. We do not accept the explanation in this regard sought to be offered
by the writ petitioners. We have no doubt in our mind that the writ petitioners are guilty of serious
delay and laches on their part.
M/s. Lohia Machines (supra), whereupon the High Court placed strong reliance, was not a case
where a third party interest was created. Therein, the validity of Rule 19-A of the Income Tax Rules,
1962 was in question. It may be true that therein the validity of the rule was challenged after 19
years but the plea of dismissing the writ petition on the ground of delay was negatived holding that
the challenge in regard to the constitutionality of the said rule was otherwise well-founded. It was
not a case where during the interregnum, the parties altered their position and third party interest
was created. It is in that situation this Court observed that if a rule made by a rule making authority
is found to be outside the scope of its power, it is void and it is not at all relevant that its validity has
not been questioned for a long period of time; if a rule is void it remains void whether it has been
acquiesced in or not.
The High Court in this case did not declare DCR 58 to be ultra vires the Constitution or the
provisions of the MRTP Act. In Proprietary Articles Trade Association v. AG of Canada [(1931) AC
310], the validity of the rule was in question. The decision of the Privy Council in Attorney General
of the Commonwealth of Australia v. Queen [95 CLR 529] is to the same effect. In this case, the
delay is enormous. Most of the Appellants and, particularly, those who are purchasers have been
suffered considerable financial loss and embarrassment. It had calamitous consequence to the
entrepreneurs who are required to pay lakhs and lakhs of rupees by way of interest to the banks andBombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

other financial institutions per day. The bona fide of the purchasers of NTC Mill lands had never
been in question in the sense that as the writ petitioners at no point of time questioned the validity
or otherwise of the sale of the lands by filing any application for amendment of the writ petition, and
as noticed hereinbefore, only during arguments such a contention was raised. The High Court, in
our considered opinion, thus, committed a manifest error in acting thereupon. Before us, we may
notice, a statement has been made across the bar that keeping in view the orders passed by this
Court dated 11th May, 2005, the sale of NTC mills is seriously not in question.
As we have considered the matter on merits, evidently, we are not dismissing the writ petition on the
ground of delay and laches alone but we have taken the same as one of the factors in determining
the questions raised before us.
CONFLICTING STAND OF WORKMEN The workers are vertically divided. Whereas Rashtriya Mill
Mazdoor Sangh (RMMS) sides with the mill owners, Girni Kamgar Sangharsh Committee (GKSS)
sides with the writ petitioners. They contradict each other not only from their own stand point
vis-`-vis the point of view of the workers, but also as regards the interpretation and constitutionality
of DCR
58. RMMS complains that the High Court did not consider its principal submissions at all which
were placed before it by way of written submissions, but merely considered only those which were
raised by way of further written submissions. According to them, RMMS is the only representative
and approved trade union under the Bombay Industrial Relations Act for Greater Bombay.
According to them, closure of the cotton mills affected 2,00,000 workers and because of the strike
the mills defaulted in making payment of wages, provident funds dues, gratuity, etc. to the workers
causing great hardship to them. It played an active role in the revival / rehabilitation of the NTC
mills and other sick mills by representing the workers' cause before BIFR. It also agrees with the
reasons put forward by the appellants as regards the validity of DCR 58 of 2001. It highlights the
policy/ objectives thereof in great details. It also states:
(i) RMMS has entered into VRS Agreement with the management of several mills.
(ii) Nearly 10,000 workers of the NTC mills and more than 25,000 workers of private
mills, aggregating in all more than 35,000 workers stand to benefit by the VRS
Schemes.
(iii) As on date, the NTC mills have discharged their entire liabilities under the VRS
Schemes by making payment to the extent of 398.76 crores payable to these workers.
(iv) The Maharashtra State Textile Corporation has also cleared the outstanding dues of its workers
to the extent of Rs. 22 crores. As regards the private mills, out of the total amount due to the
workers under VRS Schemes amounting to 808.75 crores, approximately a sum of 631.05 crores has
been paid.Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

(v) However, approximately Rs. 373 crores remain outstanding to be paid to approximately 20,000
workers  which payments are directly linked to the development of the lands by the mill owners.
It further argues that if the judgment of the High Court is implemented, it would cause irretrievable
injury and extreme prejudice to the workers.
Mr. Colin Gonsalves, learned counsel appearing on behalf of GKSS, on the other hand, not only laid
emphasis on the so-called defaults of the mill owners but had gone to the extent of urging that the
workers' dues have not been paid substantively. He further contended that revival scheme has not
been given effect to and the amount required to be spent therefor had in fact not been spent. It has
further been contended that no guidelines had at all been framed for the Monitoring Committee by
the State for overseeing the disbursement of funds. According to it, in the case of Mafatlal Centre
although the scheme was sanctioned in 2001, no payment has been made despite the fact that the
company received a sum of Rs. 16 crores from the sale of the built up areas of Mafatlal Centre at
Parel. The workers' dues being to the extent of 93 crores, the same are in excess of the legal dues of
the workers and only a paltry sum had been paid to them whereas the dues of the banks had been
cleared.
In these appeals, we are not concerned with the said issues. We may, however, place on record that
according to Mr. Sorabjee the statement of Mr. Colin Gonsalves that nothing had been paid to the
workers is baseless and irresponsible. It was contended that the Union represented by Mr.
Gonsalves impleaded itself in the writ petition filed by it before the High Court against the MCGM as
regard non-disposal of layout plan, etc. wherein they categorically stated that it would have no
objection to the development of their property subject to realization of the cheques given in favour
of the workers. It is stated that the cheques had been fully realized and the workers have enjoyed the
benefit of payment.
We have pointed out these factors only for the purpose of showing that this litigation was treated to
be a platform for even championing the cause of the workers although neither the High Court nor
this Court is concerned therewith.
In terms of the Regulations, the entire amount is to be deposited in the funds specially created
therfor. It is the Committee appointed by the State alone which can spend the amount. The priority
as regard disbursal of such amount has categorically been laid down in the regulation itself. If the
fund created is not being expended for the purposes mentioned therein, a separate cause of action
will arise therefor. It is, thus, not necessary for us to delve deep into the said contentions. Guidelines
for the Committee are also not necessary to be laid down. In any event, we are not called upon nor is
it necessary to make any attempt in that regard. However, if any occasion arises for any of the
parties in this behalf, the aggrieved party indisputably would be at liberty to agitate the same before
appropriate forums CONCLUSION The upshot of our aforementioned discussions is:
(i) The Public Interest Litigation was maintainable.Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

(ii) DCR 58 is valid in law. DCR 58(1) applies also to closed mills but sub-regulation
(6) of DCR 58 does not apply to sick industries which have not been referred to BIFR.
(iii) The clarification made by the State is neither ultra vires Section 37 of the MRTP
Act nor is violative of the constitutional provisions.
(iv) DCR 58, as inserted in 2001 and as clarified in 2003, is not contrary to the
principles governing environmental aspects including the principles of sustainable
and planned development vis-`-vis Article 21 of the Constitution of India.
(v) Judicial review of DCR 58 was permissible in law.
(vi) Sale of NTC mills was not contrary to the BIFR Scheme as also the orders passed
by this Court.
(vii) Although, delay and laches play an important role, as we have considered the
merit of the matter, the writ petition filed by the Respondent Nos. 1 and 2 is not being
dismissed on that ground alone.
(viii) It is not necessary for us to go into the question as to whether worker's dues
have been paid and also as to whether the committee had been applying the fund in
terms of DCR 58 or not. However, all such contentions shall remain open.
For the reasons aforementioned, these appeals are allowed, the impugned judgment of the High
Court is set aside. However, in the facts and circumstances of the cases, there shall be no order as to
costs.Bombay Dyeing & Mfg. Co. Ltd vs Bombay Environmental Action Group & Ors on 7 March, 2006

