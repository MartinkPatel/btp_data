Chhattisgarh Minor Mineral Rules, 1996
CHHATTISGARH
India
Chhattisgarh Minor Mineral Rules, 1996
Rule CHHATTISGARH-MINOR-MINERAL-RULES-1996 of 1996
Published on 31 October 2002• 
Commenced on 31 October 2002• 
[This is the version of this document from 31 October 2002.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
Chhattisgarh Minor Mineral Rules, 1996Published Chhattisgarh State on 1-11-2000 vide
Notification No. F-7-2-2002-12., dated 31-10-2002, C.G. Rajpatra Part 1 dated 27-12-2002 at Page
No. 1920-21In exercise of powers conferred by Section 15 of the Mines and Minerals (Regulation
and Development) Act, 1957 (No. 67 of 1957), the State Government hereby makes the following
rules, namely
Chapter I
Preliminary
1. Short title and commencement.
- (i) These rules may be called the Chhattisgarh Minor Mineral Rules, 1996.(ii)They shall come into
force on first day of April, 1996.
2. Definitions.
- In these rules, unless the context otherwise requires,-(i)"Act" means the Mines and Minerals
(Regulations and Development) Act, 1957 (No. 67 of 1957);(ii)"Agreement" means an agreement to
quarry and carry away any one or more minor minerals specified therein;(iii)"Assessment" means
the assessment lev led under these rules with reference to the extent of minor minerals
extracted;(iv)"Assessee" means a person holding a quarry lease or quarry permit and includes any
other person who holds a quarry of minor minerals granted under these rules save as exempted
under rules;(v)"Assessment Year" means the yearly period beginning from the date of
commencement of the lease and ending on 31st December for the first year of the lease and
thereafter from 1st January to 31st December or part thereof;[(v-a) "Assessing Authority" means
Mining Officer, Assistant Mining Officer and Mining Inspectors posted in the district;] [Inserted by
Notification No. 19-53-87-XII-2, dated 19-06-1997.](vi)"Appellate Authority" means theChhattisgarh Minor Mineral Rules, 1996

Government or any other authority vested with such powers under these rules;(vii)"Below Poverty
Line" means the family of below poverty line as declared by the State Government from time to
time;(viii)"Competent Authority" means a competent authority appointed by the State Government
to carry out the provisions of these rules;(ix)(a)"Collector" and "Additional Collector" of Senior IAS
Scale have the same meaning respectively assigned to them in the Chhattisgarh Land Revenue Code,
1959 (No. 20 of 1959);(b)"Commissioner" of a revenue division of Chhattisgarh have the same
meaning assigned to it in the Chhattisgarh Land Revenue Code, 1959 (No. 20 of 1959);[(ix-a)
"Corporation" shall have the same meaning as assigned to it in the Chhattisgarh Municipal
Corporation Act, 1956 (No. 23 of 1956).] [Inserted by Notification No. 19-53-87-XII-2, dated
19-06-1997.](x)"Dead Rent" and "Royalty" have the meanings respectively assigned to them in the
Act;(xi)"Director" Means the Director of Geology and Mining, Chhattisgarh;(xii)"Joint Director",
"Deputy Director", "Geologist", "Assistant Geologist", "Mining Officer", "Assistant Mining Officer",
"Mining Inspector" means the respective officers of Directorate of Geology and Mining,
Chhattisgarh or any officer nominated as such by the Director or Collector for the
purpose;(xiii)"Educated Unemployed" means a person-(a)who is holding at least High School
Examination Certificate i.e., 10th pass in 10+2 system of the Chhattisgarh Board of Secondary
Education;(b)who is a resident of Chhattisgarh;(c)who is above 18 years but below 35 years of
age;(d)who belongs to a family of below poverty line;(e)Who has not availed of any facility under
any other scheme, for Educated Unemployed at any time.(xiv)"Form" means a form appended to
these rules;(xv)"Gram Panchayat", "Janpad Panchayat", "Zila Panchayat" and "Gram Sahha" have
the same meanings respectively assigned to them in the Chhattisgarh Panchayat Raj Adhiniyam.
1993 (No. 1 of 1994);(xvi)"Lessee" means a person who has been granted a quarry' lease or quarry
permit under these rules and include any contractor, sub-lessee and agent whether appointed as
such or not who acting or purporting to act on behalf of the lessee takes part in the management,
supervision, extraction and dispatch of mineral;(xvii)"Co-operative Society" has the same meaning
assigned to it under the Chhattisgarh Co-operative Societies Act, 1960 (No. 17 of 1961), and
"Association" means a body of persons associated for its objects the promotion of the economic
interest of its members and is registered under the Chhattisgarh Cooperative Societies Act,
1960;(xviii)"Member of Scheduled Castes" means a member of any caste, race or tribe, or part of or
group within a caste race or tribe specified as such with respect to the State of Chhattisgarh under
Article 341 of the Constitution of India;(xix)"Member of Scheduled Tribes" means a member of any
tribe, tribal community or part of or group within a tribe or tribal community specified as such with
respect to the State of Chhattisgarh under Article 342 of the Constitution of India;(xx)"Member of
Other Backward Classes" means a person belonging to other backward classes as notified by the
State Government from time to time;(xxi)"Minor Minerals" means the minerals as specified in
Schedule I and appended to these rules and any other mineral which the Government of India may,
by notification in the official gazette, declare to be a minor mineral under Section 3 (e) of the
Act;(xxii)"Mining Operation" and "Quarrying operation" means any operation undertaken for the
purpose of mining any minor mineral and shall include erection of Machinery, construction of roads
and other preliminary' operations for the purpose of quarrying and concomitant operation of
handling and transport of minerals up to the point of dispatch;[(xxii-a) "Municipality" shall have the
same meaning as assigned to it in the Chhattisgarh Municipalities Act, 1961 (No. 37 of 1961);]
[Inserted by Notification No. 19-53-87 XII-2, dated 19-06-1997.](xxiii)"Quarry permit" means a
permission granted under these rules to extract and remove any minor mineral in any specifiedChhattisgarh Minor Mineral Rules, 1996

period;(xxiv)"Public Place" means roads, public buildings, reservoirs, irrigation canals, Tanks,
Water Courses, village paths, religious places, Burial ground etc.;(xxv)"Quarry Lease" means a
mining lease for minor minerals as mentioned in section 15 of the Act;(xxvi)"Railway" and "Railway
Administration" have the meanings respectively assigned to them in the Indian Railways Act, 1989
(No. 24 of 1989);[(xxvi-a) "Special area" shall have the same meaning as assigned to it in the
Chhattisgarh Nagar Tatha Gram Nivesh Adhiniyam, 1973 (No. 23 of 1973).] [Inserted by
Notification No. 19-53-87-XII-2, dated 19-06-1997.](xxvii)"Schedule" means a Schedule appended
to these rules;(xxviii)"State Government" means the Government of Chhattisgarh;(xxix)the
expressions "Mine" and "Owner" have the meanings respectively assigned to them in the Mines Act,
1952 (35 of 1952);
3. Exemptions.
- Nothing in these rules shall apply to,-(i)the extraction of clay or sand, by a hereditary kumhar, a
member of a Scheduled Caste or a member of a Scheduled Tribe or a Cooperative Society of such
kumhars or members of Scheduled Castes or members of Scheduled Tribes for preparing tiles, pots
or bricks by traditional means, but not by the process of manufacture in kilns or by any mechanical
means, from the area that the Gram Panchayats may decide and earmark within their respective
Panchayat area for extraction of clay and sand :Provided that no extraction shall be made from any
public place or 50 meter from such public place.(ii)the removal of minor minerals from mines,
whether situated in private or Government land, when such mines have not been appropriated to
the use of a department of the State Government and the minor minerals are not quarried for sale
but are required for the Construction or repairs of wells, or other agricultural works or for the
construction or improvement of the dwelling houses of agricultirsts, Village artisans and labourers
resideing in revenue or forest villages;(iii)the minor minerals removed from Government lands for
public works by Gram Panchayats, Janpad Panchatats and Zila Panchatats for work undertaken by
respective Panchyats, However, the Government Departments shall be required to pay the royalty at
the prescribed rate on consumption of minor minerals by them to the concerned Panchayats.(iv)the
search for minor minerals at the surface not involving any substantial disturbance of the soil by
digging up pits, trenches or otherwise.The chipping of outcrops with a geological hammer for the
purposes of taking samples shall not be deemed to be a substantial distrubance of the soil :Provided
that the aforsaid exemptions do not afford immunity from any action which might be taken under
any existing rules or any Act of the State or Central Government for unauthorised removal of minor
minerals from any land by private person, without the permission of the State Government or any
officer or Authority authorised by it in this behalf.
Chapter II
General Restrictions On Undertaking Mining Operations
4. Prohibition of mining operation without a quarry permit or quarry lease.
(1)No person shall undertake any mining operation in any area except under and in accordance with
the terms and conditions of a quarry permit or quarry lease granted under these rules :Provided thatChhattisgarh Minor Mineral Rules, 1996

nothing in this sub-rule shall affect any mining or quarrying operation undertaken in any area in
accordance with the terms and conditions of permit, a quarry lease, trade quarry or royalty quarry
granted before the commencement of these rules which is in force at the time of such
commencement.(2)No quarry permit or quarry lease shall be granted other than in accordance with
the provisions of these rules.
5. Restrictions on the grant of quarry permit or quarry lease.
(1)No quarry lease, or quarry permit shall be granted to any person unless such person is an Indian
National or a company as defined in sub-section (1) of Section 3 of the Companies Act, 1956 (No. 1 of
1956) and satisfies such conditions prescribed in these rules.Explanation. - In case of a firm or any
other association of individuals, for the purpose of this sub-rule, a person shall be deemed to be an
Indian National only, if all the members of the firm or association are citizens of India.(2)No quarry
lease, or quarry permit shall be granted in respect of an area:-(a)notified by the Government as
reserved for the use of the Government, Local Authorities or for any other public or for special
purposes except with the previous approval of the State Government;(b)in forest land without the
permission of appropriate authority as prescribed in the Forest (Conservation) Act, 1980 (No. 69 of
1980);(c)[ within a distance of 100 metres from any bridge, national/state/highway, railway line, 50
metres from the road constructed under Pradhan Mantri Gram Sadak Yojana, other District Roads
of Public Works Department; and 10 metres from grameen kachcha rasta; or 50 metres from any
public place : [Substituted by Notification No. F-7-7-2004-XII, dated 6-5-2006.]Provided that the
amended provisions shall be made applicable from the date of renewal of the existing quarry
leases.(d)except for mineral sand or bajri, within a distance of 100 metres from river banks, dam; 50
metres from nalas (small water course) canal or any natural water course or any water impounding
structure:Provided that the amended provisions shall be made applicable from the date of renewal
of the existing quarry leases.](e)which is not compact and contiguous.
Chapter III
Powers To Grant Quarry Leases And Quarry Permits
6. Power to grant quarry lease.
- Quarry' lease in respect of minerals specified in Schedule 1 and Schedule II shall be granted and
renewed by the authority mentioned in column (1) for the minerals specified in column (2) subject
to the extent as specified in the corresponding entry in column (3) thereof of the Table below: -Table
[No.] [Substituted by
Notification No.
19-53-87-XII-2, dated
19-6-1997.]Authority Minerals Extent Powers
(1) (2) (3) (4)
1. State Government i. Minerals specified in S.No. 1 i. Full powers.Chhattisgarh Minor Mineral Rules, 1996

to 3 of Schedule-I.
  ii. Minerals specified in S.No.
5 of Schedule-I.ii. Where the area
applied for exceeds
4.00 hectares.
2. Directori. Minerals specified in S.No. 4
of Schedule-I.i. Where the area
applied for exceeds
4.00 hectares.
  ii. Minerals specified in S. No.
6 &. 7 of Schedule-Iii. Where the area
applied for exceeds
4.00 hectares.
3.Collector/Additional
Collector (Senior IAS
Scale)i. Minerals specified in S. No.
4 of Schedule-1.i. Where the area
applied for is less
than 4.00 hectares.
  ii. Minerals specified in S. No.
5 of Schedule-I.ii. Where the area
applied for is less
than 4.00 hectares.
  iii. Minerals specified in S. No.
6 & 7 of Schedule-I.iii. Where the area
applied for is less
than 4.00 hectares.
  iv. Minerals specified powers.
Schedule-II serial No 2
formaking bricks tiles etc.
chimney bhatta.in iv. Full
  v. All Minerals specified in
Schedule-II within the areas
ofthe Corporation,
Municipalities, Special Areas
& NagarPanchayats.v. Full powers,
  vi. Minerals specified in
Schedule-II S.No. 1 and S.No.
3 to12 within the area of
Panchayats.vi. Where the
average annual value
of the quarry
exceedsRs.
10,00,000/- (Ten
Lakh)
7. Power to grant quarry permit.
- Quarries of annual value upto Rs. 2,50,000/- (Rs. Two Lakh fifty thousand); above Rs. 2,50,000/-
(Rs. Two Lakh fifty thousand) but upto Rs. 5,00,000/- (Rs. Five Lakh) and above Rs.
5,00,000/-(Rs. Five Lakh) and upto Rs. 10,00,000/- (Ten Lakh) in respect of minerals specified in
Schedule II except stone quarries for crusher and clay quarries for tiles and bricks in chimney
bhatta, shall for regulating the grant and renewal or quarry permit and all pruposes connected
therewith including collection of royalty, stand transferred to the respective GramChhattisgarh Minor Mineral Rules, 1996

Panchayats/Janpad Panchayats and Zila Panchayats respectively. Quarry permits shall be granted
and renewed by the respective Panchayat, after obtaining prior approval of the Gram Sabha of the
Panchayat in which the quarry area is situated.Explanation. - For purpose of assessing the annual
value of any quarry of mineral specified in Schedule II, if the quarry is a trade or royalty quarry, the
average annual bid amount of the years 1992-93, 1993-94 and 1994-95 shall be taken into
consideration and in cases of quarries granted as quarry leases average annual royalty for the years
1992, 1993 and 1994 shall be taken into consideration. This assessment of value is for the purpose of
transfer/sanctioning power of quarries to respective Zila, Janpad and Gram Panchayats at the
commencement of these Rules.
8. [ Procedure for demarcation of new quarries. [Substituted by Notification
No. 19-53-87-XII-2, dated 19-6-1997.]
- Panchayat demarcate and declare new quarry' in respect of Mineral specified in schedule II in
consultation with the Collector of the district.]
Chapter IV
Grant Of Quarry Lease In Respect Of Minerals Specified In
Schedule I And Schedule II
9. Application for quarry lease.
- An application for the grant or renewal of a quarry lease shall be made in Form I in triplicate for
the minerals specified in Schedule I and II. The application shall be affixed with a court fee stamp of
the value of five rupees and shall contain the following particulars together with documents in
support of the statements made therein(a)If the applicant is an individual, his name, nationality,
profession, caste, educational qualification, age, residence, present address and financial status;(b)If
the applicant is a company, its name, nature and place of business and place of registration or
incorporation, list of directors and their nationality, financial status, registration/incorporation
certificate;(c)If the applicant is a firm, its name, nature and place of business, list of partners and
their nationality, partnership deed, registration certificate, financial status;(d)If the applicant is a
society/association, its name, nature and place of working, list of members and their caste,
educational qualification, nationality, registration certificate, bye-laws and financial status of
individual member;(e)A description illustrated by a map or plan showing as accurately as possible
the situation and boundaries of the land in respect of which the quarry lease is required where the
area is unsurveyed the location of the area should be shown by some permanent physical feature,
roads, tank, etc.;(f)Copy of latest Khasra Panchsala;(g)The minerals or mineral which the applicant
intends to quarry or mine;(h)The period for which the quarry lease is required;(i)The purpose for
which the extracted mineral is to be used;(j)Every application for the grant or renewal of a quarry
lease shall be accompanied by an affidavit showing particulars of the areas mineral-wise in each
district of the State, which the applicant or persons jointly with him(i)already holds under quarry
lease;(ii)has already applied for, but not granted; and(iii)being applied for simultaneously;(k)AnChhattisgarh Minor Mineral Rules, 1996

affidavit to the effect that the applicant has, where the land is not owned by him, obtained surface
rights over the area or has obtained the consent of the owner/owners for conducting mining/
quarrying operations :Provided that no such affidavit shall be necessary where the Land-rights vest
with the State Government;(l)Every application for the grant or renewal of a quarry lease shall be
accompanied by a no dues certificate in Form II granted by the Mining Officer or Assistant Mining
Officer, [or incharge of the mining section of the district] [Substituted by Notification No.
19-53-87-XII-2, dated 19-6-1997.] in respect of payment of mining dues payable under the Act or
rules made thereunder from all the districts where the applicant holds or held mineral concessions
:Provided that it shall not be necessary' for the applicant to produce the no dues certificate if he has
furnished an affidavit and such other evidence as may be required to the satisfaction of the
concerned authority that he does not hold and has never held any mineral concession in any district
of the State ;Provided further that the grant of no dues certificate shall not discharge a holder of
such certificate from the liability to pay the mining dues which may be subsequently found to be
payable by him under the Act or Rules made thereunder.
10. Application Fee.
(1)There shall be paid in respect of every application for grant or renewal of a quarry lease in respect
of a mineral specified in Schedule I, an application fee of Rs. 5000/- (Rs. Five thousand) and Rs.
250/-(Rs. Two Hundred Fifty) in respect of a mineral specified in Schedule II.(2)Where an
application for the grant or renewal of a quarry lease is refused or the applicant refuses to accept the
lease on account of any special conditions imposed therein under Rule 30 the fee paid by the
applicant under sub-rule (1) [shall be refunded to him by the Collector/Additional Collector]
[Substituted by Notification No. 19-53-87-XII-2, dated 19-6-1997.] and if the applicant refuses to
accept the lease or withdraws the application or fails to furnish the requisite information the
application fee shall be forfeited to the State Government.(3)The amount of fee shall be deposited in
the Government treasury under the revenue receipt head -
'0853 Mines and Minerals
102-c Mineral concession fees, rent and royalties.
800 other receipts
002 receipt from minor minerals including fines and forfeitures,
and the original treasury receipted Challan shall be attached to the application.
11. [ Officer authorised to receive applications. [Substituted by Notification
No. 19-53-87-XII-2, dated 19-6-1997.]
- The Mining Officer or Assistant Mining Officer or in their absence any officer authorised by the
Collector of the district shall receive the applications and shall enter on it the date on which the
application was received by him.]Chhattisgarh Minor Mineral Rules, 1996

12. [ Availability of certain areas. [Substituted by Notification No.
19-53-87-XII-2, dated 19-6-1997.]
- No application for quarry lease of minerals at S .No. 1 to 4 of Schedule I shall lie for area previously
held or which are being held under a quarry' lease or in respect of which the order had been made
for the grant thereof but due to any reason lease deed is not executed and in respect of which the
order granting lease has been revoked or in respect of which an application for quarry lease has been
rejected on the ground that the area should be reserved for any purpose, unless the date from which
the area shall be available for grant is notified in the official Gazette at least thirty days in advance
:Provided that the State Government may for reasons to be recorded in writing relax the provisions
of this rule in any special case.]
13. Reservation of areas for exploitation in the public sector, etc.
- The State Government may, by notification in the Official Gazette, reserve any area for
conservation, Protection of environment, assessment of reserve by the State Government or for
Exploitation by the Government, a Corporation established by Central or State Government or a
Government Company within the meaning of Section 617 of the Companies Act, 1956 (Act 1 of 1956).
14. Acknowledgement of application.
(1)Where an application for the grant or renewal of a Quarry lease is delivered personally its receipt
shall be acknowledged forthwith; and where such application is received by registered post, its
receipt shall be acknowledged on the same day; and in other cases, the receipt shall be
acknowledged within three days of the receipt.(2)The receipt of every such application shall be
acknowledged in Form III.
15. Register of applications for quarry lease.
(1)A register of applications for quarry lease shall be maintained by the mining officer or Assistant
Mining Officer of the district in Form IV.(2)The Register of application for quarry leases and the
register of quarry leases shall be open to inspection by any person on payment of the following
fee:-Rs. 10.00 (Rupees Ten) for first hour or part thereof;Rs. 5.00 (Rupees Five) for next subsequent
hour or part thereof.(3)[ The fee under sub-rule (2) shall be deposited in the same manner as
prescribed in sub-rule (3) of rule 10] [Inserted by Notification No. 19-53-87-XII-2, dated 19-6-1997.]
16. Premature applications.
- Applications for the grant of a quarry lease in respect of areas whose availability for grant is
required to be notified under rule 12 shall if :-(a)no notification has been issued under that rule;
or(b)where any such notification has been issued, the period specified in notification has not
expired;shall be deemed to be premature and shall be entertained and the application fee thereon, if
any paid, shall be refunded.Chhattisgarh Minor Mineral Rules, 1996

17. Renewal of quarry lease.
- Every application for the renewal of a quarry lease shall be made at least one year before the date
of which the lease is due to expire.
18. Disposal of applications for the grant or renewal of quarry lease.
(1)On receipt of an application for the grant or renewal of a quarry' lease, its details shall be first
circulated for display on the notice board of the Zila Panchayat, Janpad Panchayat and Gram
Panchayat concerned of the district and collectorate of the district concerned.(2)[ The Sanctioning
Authority after making such enquires as he deems fit, may sanction the grant or renewal of a quarry
lease or refuse to sanction it within one year from the date of receipt of the application for the grant
of quarry lease or for the renewal application before the expiry of quarry lease already sanctioned.
Otherwise the application shall be deemed to have been refused :Provided that no quarry lease for
new area shall be sanctioned without obtaining opinion of the respective Gram Panchayat.]
[Substituted by Notification No. 19-53-87-XII-2, dated 19-6-1997.](3)Notwithstanding anything
contained in sub-rule (2), all pending applications for the grant inclusive of such applications on
which agreements have not been executed on the date of commencement of these rules shall be
deemed to have been refused by the Sanctioning Authority. Fresh applications in this behalf may be
made according to the procedure laid down under these rules.(4)[ Where an applicant for grant or
renewal of a quarry lease, dies before the sanction order is passed it will be deemed to have been
filed by his heir and if the applicant dies after the sanction order of grant or renewal but before
execution of lease deed it will be deemed to have been granted or renewed to the legal heir of the
applicant.] [Inserted by Notification No. 19-53-87-XII-2, dated 19-6-1997.]
19. Reasons for refusal to be recorded.
(1)Where the Sanctioning Authority passes any order refusing to grant or renew a quarry lease, it
shall communicate in writing the reasons for such order to the person against whom such order is
passed.(2)Where it appears that the application is not complete in all material particular is not
accompanied by the required documents, the Collector or any other Officer authorised by him in his
behalf shall by a notice served by registered post in writing, requiring the applicant to make good the
omission or as the case may be, to furnish the documents, not later than 30 (Thirty) days from the
date of communication of the said notice. An application for the grant or renewal of a quarry lease
made under Rule 9 shall not be refused by the Sanctioning Authority only on the ground that
application is not complete in all material particulars or is not accompanied by the documents.
20. Register of quarry leases.
- A register of quarry leases shall be maintained by the Mining Officer/Assistant Mining Officer in
Form V.Chhattisgarh Minor Mineral Rules, 1996

21. Preferential Rights.
- [(1) * * * *] [Omitted by Notification No. 7-22/2003/M, dated 09-09-2003.](2)Minerals specified
at S.No. 2 to 7 of Schedule 1 and Minerals specified in Schedule II -(i)Co-operative
Society/Association of Scheduled Tribe/Scheduled Caste/Backward Classes, Co-operative
Society/Association of educated unemployed youths or individuals where more than fifty per cent,
of the members belong to the concerned category and also where the Chairman of the Society is of
the concerned category and also where the executive committee have the representation in the ratio
of the members of the concerned category and hail from below Poverty Line families listed in the
District Rural Development Agency or educated unemployed youth belonging to Scheduled
Tribe/Scheduled Caste/Backward Classes in that order;(ii)An educated unemployed youth
belonging to below Poverty Line families listed in the District Rural Development Agency;(iii)Any
other person belonging to below Poverty Line families listed in the district Rural Development
Agency;(iv)Any other applicant:[Provided that exclusive Co-operative Society/Association of
Women or an individual woman shall have the preferential right over other applicants in the same
order as provided in clause (i), (ii), (iii) and (iv).] [Inserted by Notification No. 19-53-87-XII-2,
dated 21-01-1998.][Provided further that] [Substituted by Notification No. 19-53-87-XII-2, dated
21-01-1998.] the above priorities shall hold good only if the applications are received within one
month from the date of first application.(3)Whenever more than one application in any particular
category are received for minerals of Schedule I for an area, the Sanctioning Authority shall while
sanctioning a quarry lease take into consideration the following matters in respect of the
applicants-(i)Any special knowledge or experience of mining and export;(ii)Technical and special
management experience of establishing, running and maintaining cutting polishing industry';
and(iii)The nature and quality of the technical staff and the plant and machinery deployed or to be
deployed by the applicant;(iv)The financial resources of the applicant;(v)The proposed phased
programme of establishing the industry;[Notwithstanding anything contained in sub-rule (2), it
shall be competent for the Sanctioning Authority for reasons to be recorded in writing and with the
prior approval of the State Government to grant a lease in variance with the order of priority
specified in sub-rule (2)] [Substituted by Notification No. 7-22/2003/M, dated 09-09-2003.]
:Provided that in cases falling under category (i) to (iv) in sub-rule (2), the grant of lease shall be
subject to the condition that lessee shall work the quarry directly and shall not hand it over to any
other party for working :Provided further that the Sanctioning Authority may refuse to accord
preference to the application of a Co-operative Society/Association if he finds that the particular
society does not work properly in the interest of the workers concerned.The lessee shall give priority
in employment to the resident of the village in which the quarry' lease is granted.
22. Period of quarry lease/quarry permit.
- The period for which a quarry lease/quarry permit may be granted or renewed shall be as shown in
the table below :-
S.No.Name of the
MineralsPeriod___________________________________________Chhattisgarh Minor Mineral Rules, 1996

In case of
individualIn case of
co-operative
Society
(1) (2) (3) (4)
1.Dimensional
Stone-Granite,
dolerite, and other
igneous
andmetamorphic
rocks used for
cutting and
polishing purpose
formaking blocks,
slabs, tiles of
specific dimension.Twenty years with renewal clause.Twenty'
years with
renewal
clause.
2.Marble used for
cutting and
polishing purpose
for makingblocks,
slabs, tiles of
specific dimension.Ten years with renewal clause.Ten years
with renewal
clause.
3.Marble stone for
other purpose.Five years with renewal clause.Five years
with renewal
clause.
4.Limestone when
used in kilns for
manufacture of
lime used
asbuilding
material.Ten years with renewal clause.Ten years
with renewal
clause.
5.Flagstone-Natural
sedimentary rock
which is used
forflooring, roof
top etc. and used in
cutting and
polishingindustry'.Ten years with renewal clause.Ten years
withrenewal
clause.
6.Stone for making
gitti by mechanical
crushing (i.e. use
forcrusher).Ten years with renewal clause.Ten years
with renewal
clause.
7. Bentonite/Fuller’s
earthFive years with renewal clause. Five years
with renewalChhattisgarh Minor Mineral Rules, 1996

clause.
8.Clay for chimney
Bhatta and tiles
industry.Ten years with renewal clause.Ten years
with renewal
clause.
9.Ordinary Sand,
Bajri.Two years without renewal clause.Two years
without
renewal
clause.
10.Ordinary' clay for
making bricks, pots
tiles etc.
exceptchimney
Bhatta.two years without renewal clauseTwo years
without
renewal
clause.
11.Stone, Boulder,
Road metal, Gitti,
Dhoka, Khanda,
Dressedstones,
Rubble, Chips.Three years without renewal clause.Three years
without
renewal
clause.
12. Murrum. Two years without renewal clause.Two years
without
renewal
clause.
13. Lime Kankar. Two years without renewal clause.Two years
without
renewal
clause.
14. Gravel. Two years without renewal clause.Two years
without
renewal
clause.
15. Lime shell. Two years without renewal clause.Two years
without
renewal
clause.
16. Reh mitti. Two years without renewal clause.Two years
without
renewal
clause.
17.Slate when used for
building material.Two years without renewal clause.Two years
without
renewal
clause.Chhattisgarh Minor Mineral Rules, 1996

18.Slate when used for
building material.Two years without renewal clause.Two years
without
renewal
clause.
19.Any other minor
mineral not
specified above.Two years without renewal clause.Two years
without
renewal
clause.
23. Restrictions on area of quarry lease.
- [(i) No lessee shall ordinarily hold in aggregate more than the area of Limestone (Minor Mineral),
Marble and Flag stone in the State as specified below :-
(A) Cooperative Society/Association/Companies -10 Hectares
(B) Individuals -4 Hectares
Explanation. - The above limit shall ordinarily be applicable in Renewal cases also.] [Substituted by
Notification No. 19-53-87-XII-2, dated 19-6-1997.](ii)At the time of renewal of the lease, the lessee
shall be entitled to surrender any compact part of the leased area.
24. Boundaries below the Surface.
- The boundaries of the area covered by a quarry lease shall run vertically downwards below the
surface towards the centre of the earth.
25. Security deposit and surety.
(1)An applicant for quarry lease shall before the deed referred to in Rule 26, is executed, deposit as
security, a sum of rupees Ten thousand in respect of quarry' lease for dimensional stones-Granite,
dolerite, rhyolite, marble and other igneous and metamorphic rocks which are used for cutting and
polishing for making blocks, slabs and tiles of specific dimensions [and Rs. One thousand in respect
of quarry leases of limestone and other minerals specified in schedule-I and minerals specified in
Schedule-II, in the same manner as specified in sub-rule (3) of Rule 10] [Substituted by Notification
No. 19-53-87-XII-2, dated 19-6-1997.];(2)The applicant shall also submit the surety bound duly
filled in Form VI or a bank guarantee for an amount equal to two years of dead rent:Provided in case
of a Co-operative Society/Association the provision of sub-rule (2) may be waived by the Competent
Authority ;(3)[ Deposit made under sub-rule (i) if not forfeited under these rules and no other dues
arc outstanding against the lessee it shall be refunded by the Collector/ Additional Collector on tire
expiry lease or its determination whichever is earlier.] [Substituted by Notification No.
19-53-87-XII-2, dated 19-6-1997.]Chhattisgarh Minor Mineral Rules, 1996

26. Lease to be executed within three months.
- Where a quarry lease is granted or renewed, the lease deed in Form VII shall be executed and
registered under the Indian Registration Act, 1908 (No. 16 of 1908) within three months of the order
of sanction of the lease and if no such lease is executed within the aforesaid period, the order
sanctioning the lease shall be deemed to have been revoked :Provided that where the Sanctioning
Authority is satisfied that the applicant is not responsible for the delay in the execution of the lease
deed, the Sanctioning Authority may permit the execution of the lease deed after the expiry of the
aforesaid period of three months.
27. Survey of the area leased.
(1)When a quarry' lease is granted over any area, arrangement shall be made by the Mining Officer
or Assistant Mining Officer at the expense of the lessee for the preparation of a plan and the
demarcation of the area granted under the lease, after collecting a fee calculated according to the
rates specified in the table below :-
(a)Area not exceeding 20
hectaresRs. 25/- per hectare or part thereof subject to a minimum ofRs.
100/-
(b)Area exceeding 20 hectares Rs. 50/-per hectare or part thereof.
(2)The lessee shall, erect and maintain at his own expense, boundary' pillars of substantial material,
standing not less than one metre above the surface of the ground at each comer or angle in the line
of the boundary, delineated in the plan attached to the lease deed :(3)The fee under sub-rule (1)
shall be deposited in the same manner as prescribed in sub-rule (3) of Rule 10.
28. Information of agreements etc. to Panchayats.
- The Collector shall send copy of every' lease deed with plan to the respective Janpad Panchayat
and shall intimate the full details of area to the respective Panchayat.
29. Rent and Royalty.
(1)When a quarry' lease is granted or renewed-(a)dead rent shall be charged at the rates specified in
Schedule IV;(b)royalty except for limestone shall be charged at the rates specified in Schedule
III;(c)rate of royalty on limestone shall be the same as fixed by the Government of India from time
to time for limestone in Schedule II of the Act;(d)surface rent shall be charged at the rates specified
by the Collector of the district from time to time for the area occupied or used by the lessee.(2)On
and from the date of commencement of these rales, the provisions of sub-rule (1) shall also apply to
the leases granted or renewed prior to the date of such commencement and subsisting on such
date;(3)If the lease permits the working of more than one mineral in the same area separate dead
rent in respect of each mineral may be charged :Provided that the lessee shall be liable to pay the
dead rent or royalty in respect of each mineral, whichever is higher in amount;(4)Notwithstanding
anything contained in any instrument of the lease, the lessee shall pay rent/royalty in respect of anyChhattisgarh Minor Mineral Rules, 1996

mineral removed and/or consumed at the rate specified from time to time in Schedules III and
IV;(5)The State Government may, by notification in the Official Gazette amend the Schedules III
and IV so as to enhance or reduce the rate at which rents/royalties shall be payable in respect of any
mineral with effect from the date of publication of the notification in the Official Gazette :Provided
that the rate of royalty/dead rent in respect of any mineral shall not be revised more than once
during any period of three years;(6)No granite block either processed or in the raw form or any
other mineral shall be dispatched from any of leased areas without a valid transit pass issued by
Mining Officer. The transit pass shall be issued on an application in Form VIII after depositing
royalty for the quantity intended to be transported out of the minerals extracted. Contravention of
this rule may result in forfeiture of the security deposit by the Collector without prejudice to any
other action that might lie against the lessee;(7)The Transit Pass shall be in Form IX.
Chapter V
Quarry Lease-General Conditions
30. Conditions of quarry lease.
(1)Every quarry lease shall be subject to the following conditions(a)The lessee shall pay, for every
year except for the first year of the lease, yearly dead rent at the rates specified in the Schedule IV in
the advance for the whole year, on or before the 20th day of the first month of the year;(b)[ The
lessee shall pay the dead rent or royalty in respect of each mineral whichever is higher in amount
but not both. The lessee shall pay royalty in respect of quantities of mineral intended to be
consumed or transported from the leased area, no sooner the amount of dead rent already paid
equals the royalty on mineral consumed or transported by him. The dead rent or royalty shall be
deposited in the Personal Deposit account opened by the Collector for this purpose in any
Nationalised Bank of the district.] [Substituted by Notification No. 19-53-87-XII-2, dated
19-6-1997.](c)The lessee shall also pay for the surface area occupied or used by him for the purposes
of mining operations, surface rent in advance for the whole year on or before the 20th day of the
first month every year;(d)Notwithstanding any other action that may be taken for default in the
payment of dues as specified in clause (a), (b), (c) within time under these rules or under any other
condition of the lease, the lessee shall pay interest at the rate of 24% per annum for all defaulted
payments of dead rent, royalty and surface rent.(2)If any mineral not specified in the lease is
discovered in the leased area, the lessee shall report discovery' without delay to the Collector and
shall not win or dispose of such mineral without obtaining a lease therefor. If he fails to apply for
such a lease within three months of the discovery of the mineral, the Competent Authority may
sanction lease of such mineral, to any other person, who applied for it.(3)The lessee shall not pay
wages less than the minimum wages as prescribed by the State or the Central Government from
time to time under the Minimum Wages Act. 1948 (No 1 of 1948).(4)The lessee shall take all
measures for planting trees in quarried area or any other area selected by the Collector not less than
twice the number of trees destroyed by reasons of mining or quarrying operation in addition to
restoring and levelling the land.(5)The lessee shall commence mining operation within one year
from the date of execution of the lease deed and shall thereafter conduct such operations in a
proper, skillful and workman-like manner.(6)Subject to the other conditions of these rules, whereChhattisgarh Minor Mineral Rules, 1996

mining operations have not commenced within a period of one year from the date of execution of
the lease or discontinued for a cumulative period of six months during any calendar year after
commencement of such operation, the Sanctioning Authority may, by an order, declare the quarry
lease as lapsed and communicate the declaration to the lessee.(7)Where the lessee is unable to
commence mining operation for a period exceeding one year or unable to continue mining after
commencement for the reasons beyond his control, he may submit an application to Sanctioning
Authority explaining the reasons at least ninety days before the expiry' of such period.(8)There shall
be paid, in respect of every application under sub-rule (7), a fee of Rs. 200/- (Rupees Two Hundred)
The amount of fee shall be deposited in the Government treasury under the receipt head prescribed
in sub-rule (3) of Rule 10.(9)The Sanctioning Authority of the lease may, on receipt of an application
made under sub-rule (7) and on being satisfied about the adequacy and genuineness of the reason
for the non-commencement of mining operations or discontinuance thereof, pass an order before
the date on which the lease would have otherwise lapsed; extending or refusing to extend the period
of the lease :Provided that where the Sanctioning Authority on receipt of application under sub-rule
(7) does not pass any order before the expiry of the date on which the lease would have otherwise
lapsed, the lease shall be deemed to have been extended until the order is passed by the concerned
authority or for a period of one year whichever is earlier.(10)Where non-commencement of the
mining operation within a period of one year from the date of execution of the lease deed is on
account of delay in-(i)acquisition of surface rights, or(ii)getting the possession of the leased area,
or(iii)supply or installation of machinery, or(iv)getting financial assistance from banks or any
financial institution.and if the lessee is able to furnish documentary evidence supported by a duly
sworn-in-affidavit that there are sufficient reasons and/or reasons beyond their control for
non-commencement of mining operations, the Sanctioning Authority may revoke the
declaration/order through which the lease has lapsed.(11)The lessee shall, at his own expense erect
and at all times maintain and keep in good repairs boundary' marks and pillars necessary' to
indicate the demarcation shown in the plan annexed to the lease(12)The lessee shall not carry' on, or
allowed to be carried on any mining operations -(a)at any point within a distance of 75 metre from
any railway line, bridge or highway except under and in accordance with the written permission of
the railway administration or the administration concerned;(b)50 metres from tank, river banks,
reservoir, canal (10 metre from grameen kachcha road);(c)100 metre from abadi, school, hospital
and other public places, buildings and habited sites;(d)300 metre from sensitive area like radio
station, doordarshan kendra, defence establishment etc. of the Central and State Government except
under and in accordance with the previous written permission of the State/Central Government;The
Central or the State Government may in granting such permission impose such conditions as it may
deem fit.(13)The lessee shall keep correct accounts showing the quantity and other particulars of all
minerals obtained from the mine, date wise quantities of despatches/consumptions from the lease
hold, the price obtained for such minerals, the name of the purchaser, the receipts for money
received, the number of persons employed therein and shall, allow all officers of the Directorate of
Geology and Mining and any officer authorised by the Zila/Janpad/Gram Panchayat in this behalf to
examine at any time any accounts and record maintained by him and shall furnish to the Collector
and respective Zila/Janpad/Gram Panchayat such information and returns as he or it may
require.(14)The lessee shall issue a transit pass in Form IX to accompany every carrier for every trip
carrying mineral, or product or products from leased area. The transit pass shall be prepared in
duplicate in book form. Original shall be given to the driver of the carrier after making the necessaryChhattisgarh Minor Mineral Rules, 1996

entries. The Mining Officer shall issue the transit pass book duly stamped and signed by him on an
application in Form VIII made by the lessee. The lessee shall surrender all previous duplicates of
used transit pass books together with unused transit pass books issued to him before the royalty is
paid by him under clause (b) of sub-rule (1) and fresh transit passes are issued. The Mining Officer
will keep proper accounts of issued and used duplicate transit pass books and unused transit pass
books deposited back by the lessee.(15)Whosoever transports minerals or their products like bricks,
tiles, lime, dressed stone, blocks. Slabs, tiles, chips, stone dust and ballast etc. without a valid pass in
Form IX or if the transit pass is found to be incomplete distorted or tampered with, the Collector,
Additional Collector, Chief Executive Officer of Zila/ Janpad Panchayat and Gram
Panchayat/Deputy Director, Mining Officer, Assistant Mining Officer or Mining Inspector may seize
the mineral or its products together with all tools and equipment and the vehicle used for transport
:[Provided that the provisions of this sub-rule shall not apply for the purposes of clause (i) of Rule
3.] [Inserted by Notification No. 19-53-87-XII-2. dated 19-6-1997.](16)The Collector. Additional
Collector, Chief Executive Officer of Zila/Janpad Panchayat and Gram Panchayat/Deputy Director,
Mining Officer by an order in writing may impose a penalty up to Rs. Ten Thousand which in no
case shall be less than rupees one thousand.(17)The seized mineral or its products, tools, equipment
and vehicle may be released when the penalty so imposed is deposited by the offender.(18)If the
penalty so imposed is not paid within 15 days from the date of the order, of imposing the penalty, all
the minerals or its product, tools equipment and vehicles etc. so seized shall stand forfeited and
shall become the property of the State Government.(19)The lessee shall submit the records and
books of accounts for the purpose of assessment of royalty to the Assessing Authority concerned
within thirty days from the 30th June/31st December or whenever demanded by the Assessing
Authority concerned though a notice in writing. In case if he fails to do so, a penalty of rupees one
thousand may be imposed for every month till he produces the said record.(20)The lessee
shall-(a)Submit by the 10th day of every' month to the Collector and Gram Panchayat a return in
Form X giving the total quantity of mineral/ minerals raised, removed/consumed in previous
calendar month;(b)Submit on or before 15th day of July and January to the Collector half yearly
return for half year ending June and December in Form XI;(c)Submit by the 31st January' every
year to the Collector a Statement giving information in Form XII regarding quantity and value of
mineral/minerals raised/removed/consumed during last calendar year, average number of
labourers employed (men and women separately), number of days worked.(21)The lessee shall
strengthen and support to the satisfaction of the Railway Administration or the Sanctioning
Authority, as the case may be, any part of mine which its opinion requires such strengthening or
support for the safety' of any railway, bridge, national highway', reservoir, tank, canal, or any other
public works or buildings.(22)If the lessee or his transferee or assignee does not allow entry or
inspection under sub-rule (23) the Sanctioning Authority may cancel the lease and forfeit in whole
or in part the security deposit paid by the lessee under Rule 25.(23)(i)The lessee shall allow officers
authorised by the State or the Central Government and any officer authorised by the
Ziki/Janpad/Gram Panchayat to enter upon any building excavation or land comprised in the lease
for the purpose of inspecting the same.(ii)Every owner, agent or manager of a quarry shall provide
all necessary facilities to the persons deputed by the State Government for the purpose of
undertaking research or training in matters relating to mining operations.(24)The lessee shall
immediately give to the Director General of Mines Safety, Government of India, Dhanbad, the
Controller General, Indian Bureau of Mines of Government of India, Nagpur and the DistrictChhattisgarh Minor Mineral Rules, 1996

Magistrate of the District in which the mine is situated, a notice in writing in Form XIII appended to
these rules, as soon as-(a)the working in the mine extends below superjacent ground;(b)the depth of
any open cast excavation measured from its highest to the lowest point exceeds six metres; or(c)the
number of persons employed on any day exceed 50; or(d)any explosive are used.(25)The State
Government shall at all times have the right of pre-emption of the minerals won from the land in
respect of which the lease has been granted:Provided that a fair market price prevailing at the time
of pre-emption shall be paid to the lessee for all such minerals.(26)In case of breach by the lessee or
his transferee or assignee of any of the conditions specified in sub-rule (1), (3), (4), (11), (12) or (13)
of this rule, the Collector/Additional Collector shall give notice in writing to the lessee, or his
transferee or his assignee asking him to show cause why he should not be penalised for the breach
committed and directing him to remedy the breach within sixty days from the date of the notice and
if the lessee or his transferee or assignee fails to show proper cause or if the breach is not remedied
within such period the Sanctioning Authority, without prejudice to any other action, may determine
the lease and forefeit the whole or part of the security deposit or in the alternative may receive from
the lessee such penalty for the breach not exceeding four times the amount of the said half yearly
dead rent as the lessor may fix.(27)In case of breach by the lessee or his transferee or assignee of any
other conditions of the lease, the Sanctioning Authority may require the lessee to pay a penalty not
exceeding an amount equivalent to twice the amount of annual dead rent.(28)A quarrying lease may
contain such other conditions as the Sanctioning Authority may deem necessary in regard to the
following, namely:-(a)the time limit, mode and place of payment of rents and royalties;(b)the
compensation for damage to the land covered by lease;(c)the felling of trees;(d)the restriction of
surface operations in any area prohibited by any authority;(e)the notice by lessee for surface
occupation;(f)the facilities to be given by the lessee for working other minerals in the leased area or
adjacent area;(g)the entering and working in a reserved or protected forest;(h)the security pits and
shafts;(i)the reporting of accidents;(j)the indemnity to State Government against claims of third
parties;(k)the maintenance of sanitary conditions in the mining area;(l)the delivery of possession
over lands and mines on the surrender, expiration or determination of the lease.(m)the forfeiture of
property left after determination of the lease;(n)the power to take possession of plant, machinery,
premises, and mines in the event of war or emergence(o)the manner in which rights of third parties
may be protected (whether by way of payment of compensation or otherwise) in cases where any
such party is prejudicially affected by reason of any mining operation;(p)the manner in which
rehabilitation of flora and other vegetation such as trees, shrubs and the like destroyed by reason of
any quarrying or mining operation shall be made in the same area or in any other areas selected by
the State Government, (whether by way of reimbursement of the cost of rehabilitation or otherwise)
by the person holding the quarry' lease;(q)the construction, maintenance and use of roads, power
transmission lines, tramways, railways, aerial rope ways, pipelines and making of passage for water
for mining purposes on any land comprised in a quarry' or to other mineral concessions.
31. Special Conditions.
- A quarry lease may contain any other special conditions as may be specified by the State
GovernmentChhattisgarh Minor Mineral Rules, 1996

32. Establishment of cutting and polishing units.
(1)Notwithstanding anything contained in sub-rule (5) of Rule 30 in respect of quarry leases of
granite granted for the establishment of cutting and polishing unit, if the unit is not established
within a period of one year from the date of Execution of lease/leases within the State the said
lease/leases shall be deemed to be terminated.(2)The lessee can transport including inter state
movement or export the rough blocks within the first year of the quarry lease, the quantity as may be
permitted by the State Government.
33. Rights of Lessee.
- Subject to the conditions specified in rule 30 the lessee for the purposes of mining operations with
respect to the land leased to him shall have the right :-(i)to work the mines;(ii)to sink pits and
construct buildings and roads;(iii)to erect plant and machinery;(iv)to quarry' and obtain building
and road materials and make bricks, but not for sale;(v)to use water;(vi)to use land for stacking
purpose;(vii)to do any other thing specified in the lease.
34. Right to determine lease.
- The lessee may determine the lease at any time by giving not less than six months notice in writing
to the Sanctioning Authority after paying all outstanding dues of the Government.
35. Transfer of Quarry lease.
(1)No lessee shall transfer or sub-let his lease to any other person nor make any arrangement with
any body, whereby even indirectly any' right over the leased areas is passed on to any other persons
:Provided that the permission for transfer may be granted to the lessee by the Sanctioning Authority
on payment of [Rs. 1000/- (Rupees One thousand) to be deposited in the same manner as
prescribed in sub-rule (3) of Rule 10] [Substituted by Notification No. 19-53-87-XII-2, dated
19-6-1997.] and transferee has accepted all the conditions and liabilities which the transferor was
having in respect of any such quarry lease.(2)The Sanctioning Authority' may by an order in Writing
determine the lease at any time if in the opinion of the sanctioning authority the lessee has
committed a breach of sub-rule (1).(3)Where on an application for transfer of quarry lease under
sub-rule (1). the Sanctioning Authority has given consent for transfer of such lease, a transfer lease
deed in Form XIV shall be executed within three months from the date of permission or within such
further period as the Sanctioning Authority may allow in this behalf.
Chapter VI
Grant Of Quarry PermitChhattisgarh Minor Mineral Rules, 1996

36. Quarry Permit.
- Quarry permit shall be issued by Zila/Janpad and Gram Panchayats as specified in Rule 7 and Rule
8.
37. Application for quarry permit.
- An application for grant or renewal of quarry' permit shall be made to the [concerned Zila
Panchayat, Janpad Panchayat and Gram Panchayat as the case may be] [Substituted by Notification
No. 19-53-87-XII-2, dated 19-6-1997.] in Form XV and shall contain the following
particulars:-(i)Name, profession, caste, educational qualification, age, residence, financial status
and address. In case of Co-operative Socieities/ Association, by law's, list of members and their
caste, financial status of individual member and their educational qualification;(ii)Name of the
mineral for which permit is required;(iii)Description of the land marked on a village map with
khasra panchsala from which the mineral is to be removed;(iv)Purpose for which the mineral is to
be used;(v)Consent of the owner of land, if the land is a private land;(vi)Period for which the permit
is required;(vii)An application fee of rupees Twenty Five (Rs. 25.00) to be deposited in the manner
as may be prescribed by the respective authority and the cash receipt thereof shall be enclosed with
the application.
38. Disposal of application for quarry permit.
(1)On receipt of an application for the grant [* * *] [Omitted by Notification No. 19-53-87-XII-2,
dated 19-6-1997.] of quarry permit its details shall be first circulated for display on the notice board
of the Zila Panchayat, Janpad Panchayat and Gram Panchayat concerned of the district and
collectorate of the district concerned. It shall be disposed of by the Sanctioning Authority within
[sixty days] [Substituted by Notification No. 19-53-87-XII-2, dated 19-6-1997.] from the date of its
receipt. However a Gram Panchayat shall obtain prior approval of its Gram Sabha before final
disposal of the application.(2)The Sanctioning Authority shall grant quarry permit in Form XVI for
extraction and removal from any specified quarry, and mineral under any one permit. The
agreement shall be executed and registered in Form XVII within 30 days of sanction and if no such
agreement is executed within the aforesaid period, the order of sanction shall be deemed to be
revoked. The transit pass in Form IX shall be issued after deposition of royalty for the quantity of
mineral intended to be transported every time. The royalty shall be calculated at the rates specified
in Schedule III. The applicant shall deposit the amount of security which he may be directed to
deposit by the Authority before such execution of agreement.(3)If any application is rejected, the
Sanctioning Authority shall inform the applicant, stating the reasons of such
rejection.(4)Preferential Rights.- A Quarry permit shall be granted only to the residents of the
Panchayat where the quarry is located in the following order of preference :-(a)Co-operative
society/association of Scheduled Tribe/Scheduled Caste/Backward Classes Educated unemployed
youths or individuals where more than 50 per cent of the members belong to the concerned category
and the chairman of the society belongs to the concerned category and also where the executive
committee have representation in the ratio of the members of the concerned category and hail from
below poverty line unemployed youth belonging to Scheduled Tribe/Scheduled Caste/BackwardChhattisgarh Minor Mineral Rules, 1996

Classes in that order;(b)An educated unemployed youth belonging to below poverty line families
listed in the District Rural Development Agency;(c)Any other person belonging to below poverty line
families listed in the District Development Agency;(d)Any other applicant:[Provided that exclusive
Co-operative Society/Association of Women or an individual woman shall have the preferential
right over other applicants in the same order as provided in clauses (i), (ii), (iii) and (iv).] [Inserted
by Notification No. 19-53-87-XII-2, dated 21-01-1998.]
39. Period of Quarry permit.
- The period of a quarry permit shall be as specified in Rule 22.
40. Conditions of quarry permit.
- The conditions of quarry permit shall be as follows, namely;-(i)The depth of quarry below the
surface shall not exceed six metre;(ii)The permit is non-transferable;(iii)Mineral, other than for
which quarry' permit is granted, shall not be excavated, removed or transported without approval of
the Sanctioning Authority;(iv)If any major mineral is found during quarrying operations, the permit
holder shall report the matter to the Sanctioning Authority and the Collector of the district,
forthwith;(v)The quarry permit holder shall maintain complete and correct accounts of the mineral
excavated and quantity removed from the area;(vi)The quarry' permit holder shall immediately
report all accidents to the Sanctioning Authority and the Collector of the district;(vii)The quarry
permit holder shall have no right over the quarried material and other property lying in the permit
area after the expiry of the permit:(viii)The quarry permit holder shall not carry on the quarrying
operation within the prohibited distances from any public roads, public building, temples reservoirs,
dams, burial ground and railway track, etc. and cause any damage to any public and private
properties;(ix)The quarry permit holder shall allow the sanctioning Authority or any Officer
authorised by any of them to inspect the quarrying operations and to check the accounts and verify
the details of dispatches from the registers maintained by him, and(x)The quarry permit holder shall
surrender on expiry' of the permit all duplicates of transit passes issued to him to the Sanctioning
Authority and furnish to him a complete statement indicating the quantities of minerals removed
and other particulars as may be required by the Sanctioning Authority'.
41. Register of quarry permit.
- The Sanctioning Authority shall maintain a register of quarry' permits in Form XVIII.
Chapter VII
Quarrying Operations
42. Opencast working.
(1)In opencast workings, the benches formed shall be so arranged that the benches in mineral andChhattisgarh Minor Mineral Rules, 1996

overburden are separated so as to avoid mixing of waste with mineral.(2)(i)In alluvial soil, murrum,
gravel, clay or other similar ground, the sides shall be slopped at an angle of safety not exceeding 45
degrees from horizontal or such other angle as the Deputy Director may permit by an order in
writing.(ii)The sides shall be kept benched, and the height of any bench shall not exceed 1.5 metre
and the breadth thereof shall not be less than the height.(iii)The benches in overburden shall be kept
sufficiently in advance so that their workings do not interfere with the working of mineral.(iv)The
overburden and waste material obtained during mining operations shall not be allowed to be mixed
with non-salable or sub-grade minerals. They shall be dumped and stacked separately'.(v)The
mining operations shall be carried out in workmen-like manner and in accordance with the
provisions of the State and Central Acts and rules wherever applicable.(vi)The Collector of the
district concerned or am officer authorised by the State Government if in his opinion the compliance
with the provisions thereof not reasonably practicable, may, by any order in writing and subject to
such conditions as he may specify therein, exempt from the operation of these rules for any working
in those cases in which special difficulties exist :Provided that all sand quarries, operated by
co-operative socieities/ associations of scheduled tribe/caste/backward classes and educated
unemployed and an individual member of scheduled tribe/caste and backward classes shall be
exempted from compliance of these rules subject to the conditions that loose stones and debris shall
not be allowed to remain within a distance of three metre from the edge of excavation and no
undercutting of any face or side is caused to permit any overhanging.
43. Exemptions to be subject to Mines Act, 1952 and rules made thereunder.
- Subject to such exemptions granted under the Mines Act, 1952 and rules made thereunder, the
lessees shall comply with all provisions of the said Act and rules.
Chapter VIII
Protection Of Environment
44. Protection of Environment.
(1)Every holder of quarry lease shall take all possible precautions for the protection of environment
and control of pollution while conducting quarrying operation in the following manner(a)Wherever
top soil exists and is to be excavated for quarrying operation, it shall be removed separately;(b)The
top soil so removed shall be stored for future use;(c)The dumps shall be properly secured to prevent
escape of material therefrom and cause land degradation or damage to agricultural fields, pollution
of surface water bodies or cause floods;(d)The site of dumps shall be selected as far as possible on
impervious and barren ground within the leased area;(e)The top soil dumps shall be suitably
terraced and stabliscd through vegetation or otherwise.(2)The top soil so removed shall be utilised
for restoration or rehabilitation of the land which is no longer required for quarrying
operations.(3)Removal, Storage and utilisation of overburden, etc.(a)Every' holder of a quarry
lease/quarry permit shall take steps so that the overburden, waste rock, rejects and fines generated
during quarrying or during sizing shall be stored in separate dumps;(b)The dumps shall be properly
secured and shall be suitably terraced and stabilised through vegetation or otherwise;(c)WhereverChhattisgarh Minor Mineral Rules, 1996

possible, the waste rock, over burden etc. shall be back filled into the quarry' excavations with a view
to restoring the land to its original use as far as possible;(d)The fines shall be so deposited and
disposed that they are not allowed to flow away and cause land degradation or damage to
agricultural fields, pollution of surface water bodies or cause floods.
45. Reclamation and rehabilitation of lands.
- Every holder of quarry lease shall-(i)Undertake the phased restoration, reclamation and
rehabilitation of lands affected by quarrying operations and shall complete this work before the
conclusion of such operations and the abandonment of quarry.(ii)Carry' out quarrying operations in
such a manner so as to cause least damage to the flora of the area held under quarry lease and the
nearby area;(iii)Every holder of a quarry lease/quarry permit shall.-(a)take immediate measures for
planting in the same area or any other area selected by the Collector not less than twice the number
of trees destroyed by reason of any quarrying operations;(b)look after them during the subsistence
of the lease after which the trees shall be handed over to the Gram Panchayat of the area in which
the quarry' is situated; and(c)restore, to the extent possible other flora destroyed by quarrying
operations.(iv)The State Government may prescribe rates at which the cost of rehabilitation and
reclamation shall be recoverable from the holder of a quarry' lease/quarry permit upon his failure to
observe these rules.
46. Precautions against damage to public places, air pollution and noise
pollution etc.
- Every holder of a quarry lease shall,-(i)take adequate precautions against damage to public
buildings or monuments, roads, religious places cither within the lease area or in proximity to the
lease area;(ii)air pollution due to fines, dust, etc; shall be controlled, and kept within permissible
limits specified in the Air (Prevention and Control of Pollution) Act, 1981 (No. 14 of 1981) and the
Environment (Protection) Act, 1986 (No. 29 of 1986) and rules made there under;(iii)noise arising
out of quarrying operations shall be abated or controlled at the sources so as to keep it within
permissible limits.
47. Penalty.
- Whosoever contravenes any of the provisions of [Rules 44 to 50] [Substituted by Notification No.
19-53-87-XII-2, dated 19-06-1997.] shall be punishable with imprisonment for a term which may
extend up to three months or with fine which may extend to five thousand rupees or with both and
in the case of continuing contravention, with an additional fine which may extend upto five hundred
rupees for every' day during which such contravention continues after conviction for the first such
contravention.Chhattisgarh Minor Mineral Rules, 1996

48. Returns.
(1)Every holder of a quarry lease shall submit to the Collector of the district concerned or any officer
authorised by him within a period of 60 days of the execution of the quarry' agreement, a scheme of
an environment management incorporating proposals for the progressive reclamation and
rehabilitation of the land disturbed by the quarrying operations, a scheme for the plantation of trees
and a scheme for prevention and control of air and water pollution in Form XIX.(2)The scheme
under sub-rule (1) shall be prepared in consultation with the Deputy Director.(3)The collector or the
authorised officer may direct such other measures to be taken for minimising the adverse effect of
quarrying operations on the environment.(4)The environmental scheme prepared under sub-rule
(1) may be modified at any time on geological considerations by the holder of a quarry' lease subject
to the approval of Director.(5)Every holder of a quarry lease shall submit to the Collector a quarterly
report in Form XX so as to reach him by 15th April, 15th July, 15th October and 15th January for the
quarters ending March, June, September and December respectively. The Collector together with
his comments shall send the reports to Panchayats so that they can exercise due control on
protection of environment.
49. Relaxation from protection of Environment..
(1)Notwithstanding anything contained in these rules the provisions of Rules 44,45,46,47 and 48
shall not apply to sand and bajri quarrying.(2)Relaxations may be granted by the Director, to a
quarry lease holder from all or some of the provisions of environmental protection on special
considerations.
50. Scheme to be submitted by the existing lessees.
- Where quarrying operations have been undertaken before the commencement of these rules
without an approved scheme of an environment management, the holder of all such quarry leases
including auction quarries shall submit a scheme within a period of 90 days from the
commencement of these rules to the Collector of the district concerned.
51. Approval of Scheme.
(1)The Collector shall within a period of 90 days from the date of receipt of the scheme, under rule
48 and 50 convey his approval or disapproval together with reasons to the lessee or permit
holder.(2)If no decision is conveyed within the stipulated period under sub-rule (1), it shall be
deemed to have been provisionally approved subject to the final decision whenever communicated.
Chapter IX
Assessment Of RoyaltyChhattisgarh Minor Mineral Rules, 1996

52. Assessment and determination of royalty.
(1)Assessment and determination of royalty due from an assessee during an assessment year or as
required shall be made by the assessing authority after the returns in respect of that year have been
filed by the assessee as required under the terms and conditions of the lease deed or the statement
of production, despatches or consumption has been submitted by the lease/permit holder :Provided
that the assessing authority may make a provisional assessment for a particular period during the
assessment year after the receipt of returns in respect of that period.(2)For the purpose of
assessment of royalty as mentioned in sub-rule (1) the assessee shall submit monthly returns in
Form X by the 10th of the following month and annual return in the Form XII within one month
from the expiry of the assessment year.(3)If the assessee fails to submit returns as required under
sub-rule (2) or the returns filed appear to be incorrect, the assessing authority may hold such
inquiry as it may deem fit and assess royalty of the assessment year :Provided that the assessing
authority shall give reasonable opportunity of being heard to an assessee before taking any action
under this sub-rule.(4)For the purpose of sub-rule (3) the assessing authority may serve a 15 days'
notice upon the assessee requiring in writing on a date and at place specified in the notice and to
produce any evidence on which the assessee relies in support of the correctness of the returns,
statement and records furnished by him and produce or cause to be produced such accounts
pertaining to the assessment year as the assessment authority may require.(5)On the day specified
in the notice given in sub-rule (4) or on any other day thereafter which the assessing authority may
fix, the assessing authority after hearing and considering the evidence as may be produced by the
assessee in this behalf, shall make an order in writing of assessment of royalty payable by the
assessee.(6)Notwithstanding anything contained in these rules or in the agreement of quarry
lease/permit if the assessee contravencc any of the provisions of subrules (2), (4) and (5) or if he has
not adopted any method of regular accounting on the basis of which assessment can be made
properly', the assessing authority shall assess the royalty to the best of its judgement and may
impose for each of the contravention, penalty up to 20% of annual dead rent.(7)If an assessee fails to
submit monthly returns in Form X under sub-rule (2) for any month within the prescribed time
limit and if the assessing authority has reason to believe that the assessee has evaded or avoided
payment of royalty, the assessing authority may after giving to assessee a reasonable opportunity of
being heard and after making such inquiry as it may consider necessary, assess the royalty for the
period to the best of its judgement. The amount so assessed shall be payable forthwith by the
assessee.
Chapter X
Penalty For Un-Authorised Extraction And Transportation
53. Penalty for un-authorised extraction and transportation.
(1)Whenever any person is found extracting or transporting minerals or on whose behalf such
extraction or transportation is being made otherwise than in accordance with these rules, shall be
presumed to be a party to the illegal extraction of minerals and every such person shall be
punishable with simple imprisonment for a term which may extend to one year or with fine whichChhattisgarh Minor Mineral Rules, 1996

may extend to five thousand rupees or with both.(2)Whenever any person is found extracting or
transporting mineral in contravention of the provisions of these rales the Collector/Additional
Collector/ Joint Director/Deputy Director/Mining Officer/Assistant Mining Officer, or any Officer
authorised by him or Zila/Janpad/Gram Panchayat may seize the minor minerals and its products
together with all tools, equipments and vehicles used in committing such offence.(3)The officer
seizing illegally extracted or transported mineral or its product, tools, equipments and vehicles shall
give a receipt of the same to the person from whose possession such things were so seized and shall
make report to the Magistrate having Jurisdiction to try such offence.(4)The property so seized
under sub-rule (2) may be released by the officer who seized such property on execution of a bond to
the satisfaction of the officer by the persons from whose possession such property was seized. It
shall be produced at the time and at the place w hen such production is asked for by such
officer:Provided that where a report has been made to the Magistrate under sub-rule (3) then the
seized property shall be released only under tire orders of such Magistrate.(5)The
Collector/Additional Collector/Joint Director/Deputy Director/ Mining Officer or Officer authorised
by Zila/Janpad/Gram Panchayat may either before or after the institution of the prosecution,
compound the offence so committed under sub-rale (1) on payment of such fine which may extend
to double the market value of mineral no extracted but in no case it will be less than rupees one
thousand or ten times of royalty of minerals so extracted whichever is higher:Provided that in case
of continuing contravention Collector/Additional Collector/Deputy Director/Mining Officer in
addition to the fine imposed may also recover an amount of Rs. 500/- for each day' till such
contravention continues.(6)Any person who trespasses on any land in contravention of these rules,
such trespasser may be served with an order of eviction by the Collector/Additional Collector.(7)All
property seized under sub-rule (2) shall be liable to be confiscated by an order of the Magistrate
trying the offence if the amount of the fine and other sums imposed are not paid within a period of
one month from the date of the order:Provided that on payment of such sum within one month of
the order all property' so seized except the mineral or its products shall be released and the mineral
or its products so seized under sub-rule (2) shall be confiscated and shall be the property of the State
Government.(8)The authorities empowered to take action under this rule may if deem necessary,
request to the police authority in writing for the help of police and the police authorities shall render
such assistance as may be necessary' to enable the officer to exercise the powers conferred on them
by this rule to stop illegal extraction and transportation of minerals.(9)(i)Subject to such conditions
as may be specified, the Collector/ Additional Collector may authorise either generally or in respect
of particular case or class of cases any officer not below the rank of Assistant Mining Officer to
investigate all or any offence punishable under this rule.(ii)Every officer so authorised shall in
conduct of such investigation exercise the powers conferred upon the officer-in-charge of a police
station by the Code of Criminal Procedure for the investigation of a cognizable offence.(iii)The
investigation officer for the purposes of this rule shall exercise the powers of the Code of Civil
Procedure in respect of the following matters :-(a)Enforcing the attendance of any person and
examining him on oath or affirmation.(b)Completing production of documents.
Chapter XI
Minor Mineral Offences Prevention AwardChhattisgarh Minor Mineral Rules, 1996

54. Awards.
(1)Any officer of Directorate, Geology and Mining, Chhattisgarh furnishing information leading to or
otherwise contributing to the prosecution of offence in respect of illegal mining and quarrying and
transport, or of offences otherwise committed against the Act and the rules may be granted
awards.(2)Awards may be granted only in case when the information furnished is useful to impose
penalty under the rules.(3)Conditions and extent of award. - The awards made under these rules
shall be in cash subject to the following conditions :-(i)Where minerals are seized. - The maximum
amount of an award shall be 5% of the sale value of the seized mineral after realisation or five
hundred rupees, whichever is less;(ii)Where no mineral is seized. - A maximum amount of an award
shall be 5% of the penalty amount realised, may be awarded.(4)Award not to be claimed as of
right-(i)Awards under these rules can not be claimed as matter of right.(ii)No appeal lies to any
authority on any award made by the Competent Authority under these rules.
55. Authority and mode of awards.
(1)The power to grant awards shall vest with the Director.(2)The case or proposal to make an award
shall be examined and decision taken to grant the award by a committee consisting of the Director
with two other officers of his department nominated by him.(3)The award shall be drawn on the
Form 34 of the Chhattisgarh Treasury Code Volume II by the Drawing and Disbursing Officer who
disburses the pay and allowances of the Government servant concerned.
Chapter XII
Disbursement Of Revenue From Minor Minerals Between
Janpad Panchayats And Gram Panchayats
56. [ Deposition of revenue. [Substituted by Notification No. 19-53-87-XII-2,
dated 19-6-1997.]
(1)All revenue from the minor mineral quarries granted by the Panchayats including Dead Rent,
Royalty, Surface Rent, interest and any other penalty shall be deposited in the fund of respective
Panchayats.(2)Except area granted by the Gram Panchayat, Revenue such as Dead Rent, Royalty,
Surface Rent interest and any other Penalty from other quarries of Minor Minerals situated within
the area of Panchayats shall first be deposited in the Zila Panchayat Nidhi of the area concerned. It
shall then be distriubuted according to rules governing the District Panchayat Nidhi and as per the
procedure prescribed by the State Government.(3)All Revenue from Minor Minerals such as Dead
Rent, Royalty, Surface rent, interest and any other penalties recoverabale within the area of
Corporation, Municipalities, Special Area or Nagar Panchayats shall be deposited in the respective
Local Bodies.]Chhattisgarh Minor Mineral Rules, 1996

Chapter XIII
Appeal, Review And Revision
57. [ Appeal and appellate authorities. [Substituted by Notification No.
F-7-7-2004-XII, dated 24-8-2006.]
(1)Where any power is exercisable by Gram Panchayat, Janpad Panchayat or Zila Panchayat under
these rales in relation to any matter, an appeal shall lie from every order passed under these rules to
the authority mentioned in Chhattisgarh Panchayat (Appeal and Revision) Rules, 1995 and in the
same manner as prescribed therein.(2)Where any power is exercisable by the Collector/Additional
Collector under these rales, in relation to any matter, an appeal shall lie, from every order passed
under these rules to the Director, Geology & Mining, Chhattisgarh.(3)Where any power is
exercisable by the Director under these rules, in relation to any matter, an appeal shall lie from
[every original order] passed under these rales to the State Government.(4)An order passed in
review varying or reversing any order shall be appealable in like manner as the original order.(5)No
such appeal shall be entertained unless presented within sixty days from the date of (he order and in
computing the period aforesaid, time requisite for obtaining a copy of the said order shall be
excluded :Provided that any such appeal may be entertained by an appellate authority after the said
period, if the appellant satisfies him that he has sufficient cause for not making the application
within time.
58. Revision.
(1)The State Government and Director may at any time, on its own motion for the purpose of
satisfying itself as to the legality or propriety of any order passed by or as to the regularity of the
proceedings of any officer subordinate to it call for and examine the record of any case pending
before or disposed of by such officer and may pass such order in reference thereto as it thinks
fit:Provided that no order shall be varied or reversed in revision unless notice has been served on the
parties interested and opportunity given to them of being heard.
59. Review of orders.
(1)The Director or Collector on his own motion review any order passed by himself or by any of his
predecessors in office and pass such order in reference/thereto as he thinks fit :Provided that-(i)if
the Director thinks it necessary to review any order, he shall first obtain the sanction of the
Government, and if Collector proposes to review any order, whether passed by himself or by any
predecessors, he shall first obtain the sanction in writing of the Director;(ii)no order shall be varied
or reversed unless notice has been given to the parties interested to appear and be heard in support
of such order;(iii)no order from which an appeal has been made, or which is the subject matter of
any revision proceedings are pending, be reviewed;(2)No order shall be reviewed except on the
grounds provided for in the Code of Civil Procedure, 1908 (V of 1908).Chhattisgarh Minor Mineral Rules, 1996

60. Application for Appeal.
(1)An application shall be made in triplicate in Form XXI (Anncxure-I). The application for appeal
shall be accompanied by a treasury receipt showing that a fee of one hundred rupees has been paid
into Government Treasury under the head of account-
'0853 -Mines and Minerals
800 -Other receipts
0278 -Receipts from minor minerals including fines and forfeitures'
(2)The application for appeal shall be affixed with a court fee stamp of the value of Rs. 10.00
(Rupees Ten).(3)In every application under sub-rale (1) against the order refusing to grant a quarry
lease, any person to whom a quarry' lease was granted in respect of the same area or part thereof,
shall be impleaded as party.(4)Along with the application under sub-rule (1), the applicant shall
submit as many copies thereof as there are parties impleaded under sub-rule (3).
61. Copies of application of appeal to be sent to impleaded parties.
- On receipt of the application and the copies thereof the Appellate Authority shall send a copy of the
application to each of the parties impleaded under sub-rule (3) of Rule 60 specifying the date on or
before which he may make his representation, if any, against the appeal application.
62. Order on appeal application.
- Where an application for appeal is made under these rules, the authority may confirm, modify or
set aside the order or pass such other order in relation thereto as it may deem just and proper.
63. Grant of stay.
- The appellate authority may at any time direct that the execution of the order against which appeal
is pending be stayed for such time as it may deem fit:Provided that no stay for the recovery of
mining dues shall be granted unless the party seeking stay has paid the undisputed amounts of
rents, royalties and interest due thereon and has furnished bank guarantee for the disputed amounts
of such rent, royalty and interest,]
Chapter XIV
Miscellaneous
65. Power to rectify apparent mistakes.
- The Competent Authority may at any time within six months from the date of the order passed by
it under these rules on its own motion rectify' any mistake or error apparent on the face of the
record and shall within the like period rectify any such mistake or error which has been brought toChhattisgarh Minor Mineral Rules, 1996

its notice by an applicant for the grant of quarry:Provided that no such rectification having or
purported to have a prejudicial effect on another application for the grant of the quarry lease/quarry
permit shall be made unless the Competent Authority have given to such applicant notice of its
intention to do so and have allowed him reasonable opportunity of being heard.
66. Relaxation of rules in special cases.
- In any case or class of cases in which the State Government is of the opinion that the public
interest so requires it may grant a quarry' lease/quarry permit on the terms and conditions other
than those prescribed in these rules.
67. Handling over possession of quarry.
(1)Where quarry lease/ quarry permit is cancelled or determined or right of pre-emption is exercised
or the period for which the lease is granted has expired, the lessee shall hand over possession of
quarry to the Collector/Additional Collector or any officer authorised by him or Zila/Janpad/Gram
Panchayat within a period of 15 (Fifteen) days of the cancellation of the lease or determination of the
lease or exercise of the right of pre-emption or the day immediately following date of expiry of the
lease as the case may be.(2)Where a lessee fails to hand over possession of the quarry in accordance
with sub-rule (1), the Collector/Additional Collector or the Officer authorised by him or
Zila/Janpad/Gram Panchayat shall serve or cause to be served a notice on the lessee either by post
or by tendering or delivering a copy of it personally to the lessee or one of his family members or
servants or by affixing it to a conspicuous part of the place of his residence or publishing it in at least
one newspaper having circulation in the locality where the lessee resides.(3)The notice under
sub-rule (2) shall contain a statement that the lessee shall hand over possession of the quarry' within
a period of 15 (Fifteen) days of the date of service of the notice to an officer authorised by him under
sub-rule (1) of rule 67. Where a lessee fails to hand over possession of a quarry' within the period
specified in the notice under sub-rule (2) to the officer authorised under sub-rule (1) of Rule 67. he
may take possession of the quarry' from the lessee and for that purposes may use such force as he
considers necessary'.
68. [ Permission for removal of minor minerals for Central and State
Governments and their undertakings. [Substituted by Notification No.
19-53-87-XI1-2, dated 19-6-1997]
(1)(i)The concerning Panchayat shall grant permission for extraction, removal and transportation of
any minor mineral from any specified quarry or land which may be required for the works of any
department and undertaking of the Central Government or State Government. Such permission
shall only be granted to either the concerned departmental authority or its authorised contractor on
furnishing proof of award of contract.(ii)The Collector/Additional Collector shall grant permission
for extraction, removal and transportation of any minor mineral from any specified quarry or land
only from the areas of Corporation, Municipalities, Nagar Panchayat and Special Area which may be
required for the works of any department or undertaking of the Central Government or StateChhattisgarh Minor Mineral Rules, 1996

Government. Such permission shall only be granted to either the concerned departmental authority
or its authorised contractor on furnishing proof of award of contract.(2)Such permission shall not
exceed a duration of 30 days and a quantity of 500 cubic meter at any one time.(3)Such permission
shall only be granted on payment in advance of royalty calculated at the rates specified in schedule
III. The transit pass in Form IX then shall be issued.(4)The permit shall be governed by the
following conditions :-(a)The permit holder shall maintain complete and correct account of the
mineral removed and transported from the area.(b)The permit holder shall allow any officer
authorised by the Zila/ Janpad/Gram Panchayat in respect of the permission given by the
Collector/Additional Collector to the Collector/Additional Collector/Deputy Director/Mining
Officer/Assistant Mining Officer/Mining Inspector, to inspect quarrying operations and verify the
accounts.(c)No sooner the permitted quantity is transported within the time period of 30 days or
earlier, duplicates of all transit pass, such unused transit passes together with a complete statement
of the quantities duly certified by the Officer of the concerned department shall be furnished to the
Sanctioning Authority.]
69. Delegation of powers and functions.
- The State Government may by notification in the official Gazette, direct that any power or function
which may, be exercised or performed by it under these rules, may in relation to such matters
subject to such conditions, if any, as it may specify in the notification, be exercised or performed
also by such officer or authority subordinate to the State Government as may be specified in the
notification.
70. Repeal.
- All rules or executive instructions corresponding to these rules in force immediately before the
commencement of these rules are hereby repealed :Provided that anything done or any action taken
under the rules or instructions so repealed shall, so far as they are not inconsistent with the
provisions of these rules, be deemed to have been done or taken under the corresponding provisions
of these rules.
I
(See Rule 6)Specified Minerals
1. Dimensional stone-granite, dolerite, and other igneous and metamorphic
rocks which are used for cutting & polishing purpose for making blocks,
slabs, tiles of specific dimension.
2. Marble which is used for cutting and polishing purpose for making blocks,
slabs, tiles of specific dimension.Chhattisgarh Minor Mineral Rules, 1996

3. Marble stone for other purposes.
4. Limestone when used in kilns for manufacture of lime used as building
material.
5. Flagstone-Natural sedimentary rock which is used for flooring, roof top
etc. and used in cutting and polishing industry.
6. Stone for making gitti by mechanical crushing (i.e. use of crusher).
7. Bentonite/Fuller's earth.
II
(See Rules 6 & 7)Other Minerals
1. Ordinary Sand, Bajri.
2. Ordinary clay for making bricks, pots, tiles etc.
3. Stone, Boulder, Road Metal Gitti, Dhoka, Khanda, Dressed Stones, Rubble,
Chips.
4. Murrum.
5. Lime Kankar when used in kilns for manufacture of lime used as building
material.
6. Gravel.
7. Lime shell when used in kilns for manufacture of lime used as building
material.
8. Reh Mitti.
9. State when used for building material.Chhattisgarh Minor Mineral Rules, 1996

10. Shale when used for building material.
11. Quartzite and quartzitic sand when used for purposes of building or for
making road metal or house-hold utensils.
12. Salt petre.
[Schedule III] [Substituted by C.G. Notification No. F. 7/7/2004/12, dated 27-07-2005 (in force
from 1-9-2001)](See Rule 29)Rates of Royalty
S.No. Mineral Rates
(1) (2) (3)
1.Dimensional Stone-Granite, dolerite, and other
igneous andmetamorphic rocks which are used for
cutting and polishingpurpose for making blocks, slabs,
tiles of specific dimension :- 
 (a) Black colourRs.
750/-
per
cu.mt.
 (b) Other colourRs.
400/-
per
cu.mt.
2Marble which is used for cutting and polishing
purpose formaking blocks, slabs, tiles of specific
dimension.Rs.
200/-
per
cu.mt.
3 Marble stone for other purposeRs. 75/-
per
cu.mt.
4Flagstone Natural sedimentary rock which is used
forflooring, roof top etc.Rs. 75/-
per
cu.mt.
[5 [Substituted by C.G.
Notification No. F. 7/7/2004/12,
dated 2-3-2006 (in force from
1-4-2006).]Ordinary' sand, bajriRs. 15/-
per
cu.mt.
6 MurrumRs. 15/-
per
cu.mt.Chhattisgarh Minor Mineral Rules, 1996

7 Stone :-  
 (a) BoulderRs. 30/-
per
cu.mt.
 (b) Gitti, roadmetalRs. 40/-
per
cu.mt.
 (c) Dressed stone, Khanda, DhokaRs. 40/-
per
cu.mt.
  (except
lime
stone)
8 Soil-For making bricks and tilesRs. 15/-
per
cu.mt.
9 A Other minor mineralsRs. 30/-
per
cu.mt.]
IV
(See Rule 29)Rates Of Dead Rent In Rupees Per Hectare Per Annum
S.No. Category of Mineral1st year of
the quarry
lease2nd year to 3rd
year of the
quarry lease4th year
of the
quarry
lease and
onward
(1) (2) (3) (4) (5)
1.Dimensional Stone-Granite, dolerite, and other
igneous andmetamorphic rocks which are used for
cutting & polishingpurpose for making blocks, slabs,
titles of specific dimension.Nil 10000 15000
2.Marble which is used for cutting & polishing
purpose formaking blocks, slabs, titles of Specific
dimension and marblestone for other purpose.Nil 5000 7500
3.Limestone when used in kilns for manufacture of
lime used asbuilding material.Nil 3000 5000
4.Flagstone-Natural sedimentary rock which is used
forflooring, roof top etc.Nil 5000 7500
5. Stone for crusher Nil 5000 7500Chhattisgarh Minor Mineral Rules, 1996

6. Ordinary Sand, bajri Nil 5000 7500
7. Murrain Nil 2000 3000
8.Stone for building purposes and other minor
minerals.Nil 2000 3000
Form I(See Rule 9)Application For Grant/renewal Of Quarry LeaseReceived at.................(place) on
the................day of.............19.................Here affix court fee stampFromToTheThrough :- TheDated
the..........19.....
1. I/We beg to apply for grant of quarry' lease/renewal of quarry' lease for a
term of years over hectares of land in the area specified in the schedule.
2. A sum of Rs. 5000./- or Rs. 250/- as application fee payable under rules has
been deposited vide challan No................dated......... at place..........
3. The required particulars arc given below :-
(i)Name of applicant(ii)Nationality of the applicant (Partners, Directors, Members)(iii)Place of
registration or incorporation (firm, Company or Society/ Association)(iv)Profession of individual,
nature of business of firm or Company or Society/Association and place of business.(v)Address of
the individual firm, Company or Society/Association.(vi)Caste (individual or members of
society/Association)(vii)Educational qualification (individual or members of society/
Association)(viii)Age (individual or members of society/Association)(ix)Residence (individual or
members of society/Association)(x)List of
Director/Partners/Members(xi)Registration/m-corporation certificate(xii)Financial
status(xiii)Articles of memorandum/partnership deed/by-laws(xiv)Whether the application is for a
fresh lease or for a renewal of a lease previously granted. Give details of previous lease
held.(xv)Mineral/Minerals which the applicant intends to mine.(xvi)Period for which the quarry'
lease/renewal of quarry lease is required.(xvii)Approximate quantity of mineral expected to be
raised year wise during the first three years.(xviii)Manner in which the mineral raised is to be
utilised.(a)for manufacture(b)for sale(c)any other purposeIn case of manufacture the industries in
connection with which it is required, should be specified. Details of plant (s) owned, proposed to be
set up be given.
4. (a) A plan (six copies) showing the situation and boundaries of the area/
areas applied for and concession if any, adjoining is/are enclosed. (If this
plan/ these plans be considered insufficient. I/we request that the necessary'
plan/plans of the area/areas may be prepared in duplicate in your office at
my/our cost.)
(b)Khasra Panchsala.Chhattisgarh Minor Mineral Rules, 1996

5. A statement supported by an affidavit showing all the areas mineralwise in
each district of the state.
(i)already held by me/us in my/our name/names (and jointly with others) under quarrying leases
specifying the names of minor minerals.(ii)already applied for but not yet granted and(iii)being
applied for simultaneously.
6. An affidavit of obtaining surface rights.
7. No dues certificate in Form II.
8. The plan should indicate important features, viz-
(i)if a railway, its full details i.e. whether Eastern Railway or Central Railway, whether a branch line
or a main line or colliery tramway,(ii)if a road, whether village or public works department or carp
track,(iii)walls,(iv)temples or mosques,(v)burning ghat or burial ground, etc.
9. In case the renewal applied for is only for part of the lease hold.
(a)the area applied for renewal(b)description of the area applied for renewal.(c)particulars of the
lease hold with area applied for renewal clearly marked on it (attached).
10. Means by which mineral is to be raised i.e. by hand labourers, mechanical
or electric power.
11. Any other particulars which the applicant wishes to furnish.
Schedule 4
Description of the area applied for(i)Name of village and Panchayat.(ii)Khasra number and area of
each field or part thereof
Khasra Number Area in Hectares
(iii)Full description of the area applied for with regard to natural feature-(iv)Tehsil and patwari
circle numbcr-(v)District....................Place...................Date....................Yours Faithfully,Name and
DesignationN.B. - If the application is signed by an authorised agent of the applicant, power of
attorney should by attached.If all the number cannot be entered on this form they should be
continued on a separate sheet attached to it and signed. Where a portion of a khasra number only is
required the approximate area of such portion will suffice.Form II[See Rule 9(1)]No Dues Certificate
Office of issue....................  Date....................
No........................................ District.......................  Chhattisgarh Minor Mineral Rules, 1996

This is to certify that the following quarry leases/mining leases are held by
Shri/M/s................................in district........................
Village Tehsil Minerals Areas inTotal Dues Assessed (in
Rupees)Period_________________________
   hectares Surface Dead Royalty Others  
    rent rent    
(1) (2) (3) (4) (5) (6) (7) (8) (9)
Amount paid during the period in rupees
Surface Rent Dead Rent Royalty Other Total
(1) (2) (3) (4) (5)
Balance Dues :-1.2.3.
1. In case there has been no assessment in any year, it must be stated clearly
with reasons therefor.
2. It must be stated whether any attachment or R.R.C. are pending in respect
of this lease.
3. This is valid only for six months from the date of issue.
Signature and Designation of authorised officer with seal of OfficeForm III[See Rule 14 (2)]Receipt
of Application for Quarry Lease or RenewalS.
No.................................................Date....................................Received the application with the
following enclosures for grant/renewal of quarry lease from Shri/Sarvashri..........on 19 for
about.....................hectares of land located in
village..........Panchayat...........Tehsil..........District............for mining...............minerals.
Enclosures :- ...................................
 Signature
Place .......................................... of the receiving officer with
Date............................................ seal of Office.
Form IV[See Rule 15(1)]Register of Application for Quarry Leases
1. Serial No.
2. Name of applicant.
3. Residence of applicants.Chhattisgarh Minor Mineral Rules, 1996

4. Date on which application was received by receiving officer.
5. Particulars of minerals which the applicant desires to win.
6. Name of village.
7. Name of panchayat.
8. Tehsil.
9. Khasra No.
10. Area in hectares (khasrawise)
11. Period for which applied.
12. Remarks (preferential right sought for)
13. Final disposal of applications together with number and date of the order.
14. Signature of the officer
Form V[See Rule 20]Register of Quarry Leases
1. Serial No.
2. Name of the lessee with complete address.
3. Date of application & S. No. of application register.
4. Mineral for which lease has been granted.
5. (a) Number and date of grant of lease with authority.
(b)Date of execution of quarry lease.
6. Period for which granted/renewed.Chhattisgarh Minor Mineral Rules, 1996

7. Village, Panchayat & Tehsil where situated.
8. Khasra No. and area.
9. Area in hectares for which lease has been granted.
10. Khasra No. with area of each No. taken up for working with date when so
taken up.
11. Amount of compensation paid for Area in col. No. 9 with date of payment
and whether through Government or by private negotiations together with
No. and order of land acquisition or transfer of lease.
12. Amount of surface rent fixed and date of fixation.
13. Date of expiry' or relinquishment or cancellation of the lease.
14. Remarks with particulars as to date of renewal, actual expiry or
relinquishment.
15. Date from which the area is available for grant (Notification No. & Date of
availability).
16. Date of assignment or transfer of lease, if any, and the name and address
of the assignee or transferee.
17. Date of change together with the details of change that take place, in
name nationality or other particulars of the holder of quarrying lease.
18. Signature of the Officer.
19. Remarks.
Form VI[See rule 25 (2)]Surety BondStamp duty as specified against item 57 ofSchedule 1 A. of
Indian Stamp Act, 1899.Know all Men By These Presents, that I, ..............S/o Shri..............Resident
of...........in the Tehsil.........of the District (hereinafter called the surety) am held and firmly bound to
the Governor of Chhattisgarh (hereinafter called the Governor) for the sum of Rs.............only, to be
paid to the Governor, his successors, or assignees or their attorney or the Officer authorised by the
Governor in this behalf, for which payment will and truly to be made, I hereby bind myself, my
heirs, executors, administrators and representatives, firmly by these withnesses;As witness I haveChhattisgarh Minor Mineral Rules, 1996

set out my hand, this day of...............one thousand nine hundred and...............Whereas Shri
................son of Shri........resident of............in the tehsil............or the district (hereinafter called the
lessee) has at his own request been granted quarry hease for (mineral) over an area
of.................................hectares in village.............Tehsil ....... district..............................................for a
period of............vide order No..................dated .............And whereas the lessee has agreed to execute
the prescribed agreement with the Government.And whereas by virtue of the agreement to be
executed between the Governor (lessor) and lessee, the said lessee is required to pay regularly and
timely the dead rent, royalty, surface rent and any other dues arising out of the lease.And whereas
the Governor has asked Shri................son of............to furnish surety of
Rs...........(Rupees..........only), I,............stand as surety for him to the above amount and execute this
bond and I declare that I own the following immovable property of which I am the absolute owner
and that the property is not mortgaged or gifted and it is free from all encumbrances.Details of the
property............Value...............And the conditions of the Bond is such that if the lessee shall die or
become insolvent or at any time ceases to pay the dead rent, royalty, surface rent or any other dues
arising out of the said lease, any such due on this account under this lease shall immediately become
due and payable to the Governor and the same will be recovered from my property detailed above as
an arrear of land revenue in one instalment by virtue of this Bond.And I further declare that I will
not sell, mortage, gift or transfer in any other manner and will not act in any way to dispose off the
above property till this bond is in force.In witness whereof the said........................has signed
hereinto on...........day of............. One thousand nine hundred and..............
Signature with full name address Signature of the surety
and occupation of the witness.  
1............................ Verified and found correct has signed
2............................ this Bond today in my presence
Date...................... Magistrate, Executive.
Form VII[See Rule 26]Quarry Lease DeedThis Indenture made this day of................................
between the Governor of Chhattisgarh acting through the................. (hereinafter referred to as the
"lessor" which expression shall where the context so admits be deemed to include the successors in
office of the one part and Shri...........S/o............(name of person with address and occupation)
(hereinafter referred as "the lessee" which expression shall where the context so admits be deemed
to include his heirs, executors, administrator, representatives and permitted
assignees)Or............(Name of society/Association with address and occupation) and...............
(Name of person with designation) (hereinafter referred to as "the lessee" which expression shall
where the context so admits be deemed to include their respective heirs, executors, administrators,
representatives and their permitted assignees).Or.................(Names and addresses of partners), son
of. of............son of of......................all carrying on business in partnership under the firm name and
style of (Name of the firm) registered under Indian Partnership Act, 1932 (9 of 1932) and having
their registered office at In the town of (hereinafter referred to as "the lessee which expression
where the context so admits be deemed to include all the said partners their respective heirs,
exeutors, legal representatives and permitted assignees).Or......................(Name of company) a
company registered under the Companies Act, 1956 and having its registered office
at................................. (address) (hereinafter referred to as "the lessee" which expression shall whereChhattisgarh Minor Mineral Rules, 1996

the context so admits be deemed to include its successors and permitted assignees) of the other
part.WHEREAS the lessee/lessees has/have applied to the Competent Authority in accordance with
the Chhattisgarh Minor Minerals Rules, 1996 (hereinafter referred to as the said Rules) for a quarry
lease for ............ in respect of the lands described in Part I of the Schedule hereunder written and
has/have deposited with the State Government the sum of Rs...............as security
deposit.WITNESSETH that in consideration of the rents and royalties, convenants and agreements
by and in these presents and the Schedule hereunder written reserved and contained and on the part
of the lessee/lessees to be paid observed and performed the Competent Authority hereby grants and
demises unto lessees.All those Quarries.....................(here state the mineral or minerals) lessee
(hereinafter and in the Schedule referred to as the said minerals) situated lyaing and being in or
under the lands which are referred to in Part I of the said Schedule together with the liberties,
powers and privileges to be exercised or enjoyed in connection herewith which are mentioned in
Part II of the said Schedule subject to the restrictions and conditions as to the exercise and
enjoyment of such liberties, powers and privileges which are mentioned in Part III of the said
Schedule EXCEPT and reserving out of this demise unto the State Government the liberties, powers
and privileges mentioned in Part IV of the said Schedule TO HOLD the premises hereby granted and
demised unto the lessee/lessees from the day..............19....for the terms of..............years thence next
ensuing YIELDING AND PAYING therefor unto the State Government the several rents and
royalties mentioned in Part V the said Schedule at the respective times therein specified subject to
the provisions contained in Part VI of the said Schedule and the lessee/lessees hereby
convenants/convenant with the State Government as in Part VII of the said Schedule is expressed
and the State Government hereby convenants with lessee/lessees as in Part VIII of the said Schedule
as expressed and it is hereby mutually agreed between the parties hereto as in Part IX of the said
Schedule is expressed.In Witness Whereof these presents have been executed in manner hereunder
appearing the day and year first above writtenThe Schedule above referred to
Part I – The Area of this Lease
Location and area of the lease. - All that tract of lands situated at village ................... (Description of
area or areas) in Tehsil in............ Gram Panchayat bearing Khasra survey Nos..... containing an area
of............. or thereabouts delineated on the plan hereto annexed and thereon coloured and bounded
as follows :-On the North byOn the South byOn the East byandOn the West byhereinafter referred to
as "the said lands"
Part II – Liberties, powers and privileges to be exercised and
enjoyed by the lessee/lessees subject to the restrictions and
conditions in Part III.
1. To enter upon land and win, work etc. - Liberty and power at all times
during the term hereby demised to enter upon the said lands and to win,
work, dress, process, convert, carry' away and dispose of the said
mineral/minerals.Chhattisgarh Minor Mineral Rules, 1996

2. To bring and use machinery equipment etc. - Liberty and power for or in
connection with any of the purposes mentioned in this part to erect,
construct, maintain and use on or under the said lands any engines,
machinery, plant, dressing floors, brick-kilns, workshops, store house,
godowns, sheds and other buildings and other works and conveniences of
the like nature on or under the said lands.
3. To make roads and ways etc. and use existing roads and ways.. - Liberty
and power for or in connection with any of the purposes mentioned in this
part to make any tramways, roads, and other ways in or over the said lands
and to use maintain and go, and repass with or without horses cattle,
wagons, or other vehicles over the same (or any existing tramway's, roads
and other way's in or over the said lands) on such conditions as may be
agreed to.
4. To get building and road materials etc. - Liberty and power for or in
connection with any of the purposes mentioned in this part to quarry' and get
stone, gravel and other building and road materials and clay and to use and
employ the same and to manufacture such clay into bricks or tiles and to use
such bricks or tiles but not to sell any such material bricks or tiles.
5. To use water from streams etc. - Liberty and power for or in connection
with any of the purpose mentioned in this part but subject to the right of any
existing or future lessees and with the written permission of Collector to
appropriate and use water from any streams, water-courses, springs or other
sources in or upon the said lands and to divert, step up or dam any such
stream or water course and collect or impound any such water and to make,
costruct and maintain any water-course culverts, drains or reservoirs but not
as so to deprive and cultivated lands, villages, buildings or watering places
for livestock or a reasonable supply of water as before accustomed nor in
any way to foul or pollute any stream or springs. Provided that the
lessee/lessees shall not interfere with the navigation in any navigable stream
or shall divert such stream without the previous written permission of the
State Government.Chhattisgarh Minor Mineral Rules, 1996

6. To use land for stacking, heaping, depositing purposes. - Liberty and
power to enter upon and use a sufficient part of the surface of the said lands
for the purpose of stacking, heaping, storing or depositing therein any
produce of the quarries or works carried on and any tools, equipment, earth
and materials and substances dug or raised under the liberties and powers
mentioned in this part.
Part III – Restrictions and Conditions as to the Exercise of the
Liberties, Powers and Privileges in Part II
1. No building etc. upon certain places. - No building or thing shall be erected
set up or placed and no surface operations shall be carried on in or upon any
public pleasure ground, burning or burial ground or place held sacred by any
class of persons or any house or village site, public road or other place
which the State Government may determine as public ground nor in such a
manner as to injure or pre-judicially effect any buildings, works, property or
rights of other persons and no land shall be used for surface operations
which is already occupied by persons other than the State Government for
works or purposes not included in this lease. The lessee/lessees shall not
also interfere with any right of way, well or tank.
2. Permission for surface operations in a land not already in use.. - Before
using for surface operations any land which has not already been used for
such operations, the lessee/lessees shall give to the Collector of the District
two calendar months previous notice in writing specifying the name or other
description of the situation and the extent of the land proposed to be so used
and the purpose for which the same is required and the said land shall not be
so used if objection is issued by the Collector within two months after the
receipt by him of such notice unless the objection so stated shall on
reference to the State Government be annulled or waived.
3. No mining operations within prohibited distances. - The lessee/lessees
shall not work or carry on or allow to be worked or carried on any mining
operations at or to any point within the prohibited distances specified in Rule
30 (12).Chhattisgarh Minor Mineral Rules, 1996

4. Facilities for adjoining Government licences and leases. - The
lessee/lessees shall allow existing and future holders of Government
licenses or leases over any land which is comprised in or adjoins or is
reached by the land held by the lessee/lessees reasonable facilities or
access thereto :
Provided that no substantial hindrance or interference shall be caused by such holders of licences or
leases to the operations of the lessee/lessees under these presents and fair Compensation as may be
mutually agreed upon or in the event of disagreement as may be decided by the State Government
shall be made to the lessee/lessees for loss or damage sustained by the lessee/lessees by reason of
the exercise of this liberty.
Part IV – Liberties, Powers and Privileges Reserved to the State
Government
1. To work other minerals. - Liberty and power for the State Government or to
any lessee or persons authorised by it in that behalf to enter into and upon
the said lands and to search for, win, work, dig, get, raise, dress, process,
convert and carry away minerals other than the said minerals and any other
substances and for those purposes to sink, drive, make, erect, construct,
maintain and use such pits, shafts, inclines, drifts, levels and other lines,
waterways, airways, water courses, drains, reservoirs, engines, machinery,
plant, buildings, canals tramways, railways, roadways and other works and
conveniences as may be deemed necessary or convenient :
Provided that in the exercise of such liberty and power no substantial hindrance or interference shall
be caused to or with the liberties, power and privileges of the lessee/lessees under these presents
and that fair compensation as may be mutually agreed upon or in the event of disagreement as may
be decided by the State Government shall be made to the lessee/lessees for all loss or damage
sustained by the lessee/lessees by reasons for all loss or damages sustained by the lessee/lessees by
reasons or in consequence of the exercise of such liberty and power.
2. To make railway's and roads. - Liberty and power for the State Government
or any lessee or person authorised by in that behalf to enter into and upon
the said lands and to make upon over or through the same any railways,
tramways, roadways or pipelines for any purpose other than those
mentioned in Part II of these presents and to get from the said lands stones,
gravel, earth and other materials for making, maintaining and repairing such
railways, tramways and roads or any existing railways and roads and toChhattisgarh Minor Mineral Rules, 1996

repass at all times with or without horse, cattle or other animals carts,
wagons carriages, locomotives or other vehicles over or along any such
railways, tramways road lines and other ways for all purposes and as
occasion may require, provided that in the exercise of such liberty and power
by such other lessee or person no substantial hindrance or interference shall
be caused to or with the liberties, powers and privileges of the lessee/lessees
under these presents and that fair compensation as may be mutually agreed
upon or in the event of disagreement as may be decided by the State
Government shall be made to the lessee/lessees for all loss or damage
sustained by the lessee/lessees by reason or in consequence of the exercise
of such liberty and power.
Part V – Rents and Royalties Reserved by this Lease
1. To pay dead rent or royalty whichever is higher. - The lessee shall pay for
every year except the first year of the lease, dead rent as specified in clause
2 of this Part:
Provided that, where the holder of such quarry lease becomes liable under Rule 30 of the Rules to
pay royalty for any mineral removed or consumed by him or by his agent, manager, employee,
contractor or sub-lessee from the leased area he shall be liable to pay either such royalty or the dead
rent in respect of that area, whichever is higher.
2. Rate and mode of payment of dead rent. - Subject to the provisions of
clause 1 of this part during the subsistence of the lease, the lessee/lessees
shall pay to the State Government annual dead rent for the lands demised
and described in Part I of this Schedule at the rate for the time being
specified in the Schedule IV of the Rules in such manner as specified in Rule
30 (1) (a).
3. Rate and mode of payment of royalty. - Subject to the provision of clause 1
of this part, the lessee/lessees shall during the subsistance of this lease pay
to the State Government as specified in Rule 30 (1) (b) royalty in respect of
any mineral/minerals removed by him/them from the leased area at the rate
for the time being specified in the Schedule III to the Rules.Chhattisgarh Minor Mineral Rules, 1996

4. Payment of surface rent. - The lessee/lessees shall pay rent to the State
Government in respect of all parts of the surface of the said lands which
shall from time to time be occupied or used by the lessee/lessees under the
authority of these persents at the rate of Rs respectively per annum per
hectare or part thereof for area so occupied during the period from the
commencement of such occupation or use unit the area shall cease to be so
occupied or used and shall as far as possible restore the surface land so
used to its original condition. Surface rent shall be paid as detailed in Rule 30
(1) (c).
Part VI – Provisions Relating to the Rents and Royalties
1. Rent and royalties to be free from deduction etc. - The rent and royalties
mentioned in Part V of this Schedule shall be paid free from any deductions
to the State Government as specified in Rule 30 (1).
2. Mode of computation of royalty. - For the purposes of computing the said
royalties the lessee/lessees shall keep a correct account of the
mineral/minerals produced, consumed and despatched. The accounts as well
as the volume of the mineral/minerals in stock or in the process of export
may be checked by an officer authorised under Rules.
3. Course of action if rents and royalties are not paid in time. - Should any
rent, royalty or other sums due to the State Government under the terms and
conditions of these presents be not paid by the lessee/lessees within the
prescribed time, the same, together with simple interest due thereon at the
rate of twenty four per cent per annum may be recovered on a certificate of
Mining Officer/Assistant Mining Officer in the same manner as an arrear of
land revenue.
Part VII – The Convenants of the Lessee/Lessees
1. Lessee to pay rents and royalties, taxes etc. - The lessee/lessees shall pay
the rent and royalties reserved by this lease at such time and in the manner
provided in Parts V and VI of these presents and shall also pay and
discharge all taxes, rates, assessments and impositions whatsoever being in
the nature of public demands which shall from time to time be chargedChhattisgarh Minor Mineral Rules, 1996

assessed or imposed by the authority of the State Government upon or in
respect of the premises and works of the lessee/lessees in common with
other premises and works of a like nature except demands for land revenues.
2. To maintain and keep boundary marks in good order. - The lessee/ lessees
shall at his/their own expense erect and at all times maintain and keep in
repair boundary marks and pillars according to the demarcation to be shown
in the plan annexed to this lease. Such marks and pillars shall be sufficiently
clear of the shrubs and other obstructions as to allow easy identification.
3. To commence operations within a year and work in a workman like
manner. - The lessee/lessees shall commence operation within one year from
the date of execution of the lease and shall thereafter at all times during the
continuance of this lease, win. work and develop, the said minerals without
voluntary intermission in a skilful and workman like manner and as
prescribed under clause 12 hereinafter without doing or permitting to be
done any unnecessary or avoidable damage to the surface of the said lands
or the crops, buildings, structures of other property thereon. For the
purposes of this clause operations shall include the erection of machinery',
laying of a tramway or construction of a road in connection with the mine.
4. To idemnify Government against all claims. - The lessee/lessees shall
make and pay such reasonable satisfaction and compensation as may be
assessed by lawful authority in accordance with the law in force on the
subject for all damage, injury' or disturbance which may be done by
him/them in exercise of the powers granted by this lease and shall indemnify
and keep indemnified fully and completely the State Government against all
clams which may be made by any person or persons in respect of any such
damage, injury or disturbance and all costs and expenses in connection
therewith.
5. To secure and keep in good condition pits, shafts, etc. - The lessee/lessees
shall during the subsistence of this lease well and sufficiently secure and
deep open with timber or other durable means all pits and workings that may
be made or used in the said lands and make and maintain sufficient fences to
the satisfaction of the Collector round every such pit or working whether the
same is abandoned or not and shall during the same period keep allChhattisgarh Minor Mineral Rules, 1996

workings in the said lands except such as may be abandoned accessible free
from water and foul air as far as possible.
6. To strengthen and support the mine to necessary extent. - The
lessee/lessees shall strengthen and support to the satisfaction of the Railway
Administration concerned or the State Government, as the case may be any
part of the mine which in its opinion requires such strengthening or support
for the safety' of any railway, reservoir, canal, road and any other public
works or structures.
7. To allow inspection of workings. - The lessee/lessees shall allow any
officer authorised under these Rules to enter upon the premises including
any building excavation or land comprised in the lease for the purpose of
inspecting, examining, surveying, prospecting and making plans thereof
sampling and collecting any data and the lessee/lessees shall with proper
person employed by the lessee/ lessees and acquainted with the mines and
works effectually assist such officer, agents, servants and workman in
conducting every' such inspection and shall afford them all facilities,
information connected with the working of the mines which they may
reasonably require and also shall and will conform to and observe all orders
and regulations which the Central and State Government as the result of
such inspection or otherwise may from time to time, see tit to impose.
8. To report accident. - The lessee/lessees shall without delay send to the
Collector a report of any accident causing death or serious bodily injury' or
serious injury' to property or seriously affecting or endangering life or
property which may occur in the course of the operation under this lease.
9. To report discovery of other minerals. - The lessee/lessees shall report to
the Collector the discovery in the leased area of any mineral not specified in
the lease without delay along with full particulars of the nature and positions
of each such find. If any mineral not specified in the lease is discovered in
the leased area, the lessee/lessees shall not win and dispose of such mineral
unless such mineral is included in the lease or a separate lease is obtained
therefor.Chhattisgarh Minor Mineral Rules, 1996

10. To keep records and accounts regarding production and employees etc. -
The lessee/lessees shall at all time during the said term keep or cause to be
kept at an office to be situated upon or near the said lands correct and
intelligible books of accounts which shall contain accurate entries showing
from time to time:-
(1)Quantity and quality of the said mineral/minerals realised from the said lands.(2)Quantities of
the various qualifies of the said mineral/minerals sold and exported separately.(3)Quantities of the
various qualities of the said mineral/minerals otherwise disposed of and the manner and purpose of
such disposal.(4)The prices and all other particulars of all sales of said mineral/ minerals.(5)The
number of persons employed in the mines or works or upon the said lands specifying nationality,
qualifications and pay of the technical personnel.(6)Such other facts, particulars and circumstances
as the Central or the State Government may from time to time require and shall also furnish free of
charge to such officers and at such times as the Central and State Government may appoint true and
correct abstract of all or any such books of accounts and such information and returns to all or any
of the matters aforesaid as the State Government may prescribe and shall at all reasonable times
allow such officers as the Central Government or State Government shall in that behalf appoint to
enter into and have free access to the said offices for the purpose of examining and inspecting the
said books of accounts plans and records and to make copies thereof and make extracts therefrom.
11. To maintain plans, etc. - The lessee/lessees shall at all times during the
said term maintain at the mine office correct intelligible up-to-date and
complete plans of the mines in the said lands. They shall show all the
operations, and workings and all the trenches, pits made by him/them in the
course of operations carried on by him/them under the lease and geological
data and all such plans shall be amended and filled up by and from actual
surveys to be made for that purpose at the end of twelve months or any
period specified from time to time and the lessee/lessees shall furnish free of
charge to the State Government true and correct copies of such plans
whenever required. Accurate records of all trenches, pits shall show -
(a)The subsoil and strata through which they pass.(b)Any mineral encountered.(c)Any other matter
of interest and all data required by the State Government from time to time.The lessee/lessees shall
allow officer of the State Government authorised in this behalf to inspect the same at all reasonable
time. He/they shall also supply when asked for by the State Government a composite plan of the
area showing thickness, dip, inclination, etc. as also the quantity of reserves quality wise.
12. To pay compensation for injury of third parties. - The lessee/ lessees shall
make and pay reasonable and satisfactory compensation for all damage,
injury or disturbance to person or property which may be done by or on theChhattisgarh Minor Mineral Rules, 1996

part of lessee/lessees in exercise of the liberties and power granted by these
presents and shall at all times save harmless and keep indemnified the State
Government from and against all suits, claims and demands which may be
brought or made by any person or persons in respect of any such damage,
injury or disturbance. In case of Government land the lessee/lessees shall
pay compensation equal to 30 and 60 times of land revenue in case of leases
up to 10 and 20 years respectively.
13. Not to obstruct working of other minerals. - The lessee/lessees will
exercise the liberties and powers hereby granted in such a manner as to offer
no unnecessary or reasonably avoidable obstruction or interruption to the
development and working within the said lands of any minerals not included
in this lease and shall at all times afford to the Central and State Government
and to the holders of prospecting licences or quarry leases in respect of any
such minerals or any minerals within any land adjacent to the said lands as
the case may be reasonable means of access and safe and convenant
passage upon and across the said lands to such minerals for the purpose of
getting working, developing and carrying away the same provided that the
lessee/lessees shall receive reasonable compensation for any damage or
injury which he/they may sustain by reason or in consequence of the use of
such passage by such lessees or holders of prospecting licenses.
14. Transfer of lease. - The lessee/lessees shall not, without the previous
consent in writing of the Sanctioning Authority-
(a)Assign, sublet, mortgage, or in any other manner transfer the quarry' lease, or any right, title or
interest therein; or(b)Enter into or make any arrangement, contract or understanding whereby the
lessee/lessees will or may be directly or indirectly financed to a substantial extent by, or under
which the lessee's operations or undertakings will or may be substantially controlled by, any person
or body of persons other than the lessee/lessees;(c)The Sanctioning Authority may by an order in
writing determine the lease at any time if the lessee/lessees has/have in his opinion committed a
breach of any of the above provisions or has/have transferred lease or any right, title or interest
therein otherwise than in accordance with Rule 35, provided that no such order shall be made
without giving the lessee/lessees a reasonable opportunity of stating his/their case.
15. Lessees shall deposit any additional amount necessary. - Whenever the
security deposit of Rs or any part thereof or any further sum hereinafter
deposited with the State Government in replenishment thereof shall be
forefeited or applied by the State Government pursuant to the power inChhattisgarh Minor Mineral Rules, 1996

hereinafter declared in that behalf the lessee/lessees shall deposit with the
State Government such further sum as may be sufficient with the
unappropriated part thereof to bring the amount in deposit with the State
Government up to the sum of Rs........
16. Delivery of working in good order to State Government after
determination of lease. - The lessee/lessees shall at the expiration or sooner
determination of the said term or any renewal thereof deliver up to the State
Government all mines, pits, water ways, and other works now existing or
hereinafter to be sunk or made on or under the said lands except such as
have been abandoned with the sanction of the State Government and in any
ordinary' and fair course of working all engines, machinery, plant, buildings,
structures, other works and conveniences which at the commencement of
the said term were upon or under the said lands and all such machinery' set
up by the lessee/lessees which cannot be removed without causing injury to
the mines, works under the said lands and all such machinery set up by the
lessee/lessees which cannot be removed without causing injury' to the
mines, works under the said lands (except such of the same as may with the
sanction of the State Government have become dis-used) and all buildings
and structures of bricks or stone erected by the lessee/lessees above ground
level in good repair order and condition and fit in all respects for further
working of the said mines and the said minerals.
17. Right of pre-emption. - (A) The State Government shall from time to time
and all times during the said terms have the right (to be exercised by notice
in writing to the lessee/lessees) of pre-emption of the said minerals (and all
products thereof) lying in or upon the said lands hereby demised or
elsewhere under the control of the lessee/lessees and the lessee/lessees
shall with all possible expedition deliver all minerals or products or minerals
purchased by the State Government under the power conferred by this
provision in the quantities at the times in manner and at the place specified
in the notice exercising the said rights.
(B)The price to be paid for all minerals or products of minerals taken in pre-emption by the State
Government in exercise of the right hereby conferred shall be the fair market price prevailing at the
time of pre-emption. Provided that in order to assist in arriving at the said fair market price the
lessee/lessees shall if so required furnish to the State Government for the confidential information
of the Government, particulars of the quantities, description and prices of the said minerals orChhattisgarh Minor Mineral Rules, 1996

products thereof sold to other customers and of charters entered into for freight, for carriage of the
same and shall produce to such officer or officers as may be direct by the State Government original
or authenticated copies of contracts and charter parties entered into for the sale or freightage of
such minerals or products.(C)In the event of the existance of a state of war or emergency (of which
existence and President of India shall be the sole judge and a notification to this effect in the Gazette
of India shall be conclusive proof), the State Government with the consent of the Central
Government shall from time to time and all times during the said term have the right (to be
exercised by a notice in writing to the lessee/lessees) forthwith take possession and control of the
works, plant, machinery and premises of the lessee/lessees on or in connection with the said lands
or operations under this lease and during such possession or control the lessee/lessees shall
conform to and obey all directions given by or on behalf of the Central Government or State
Government regarding the use or employment of such works, plants, premises and minerals :
Provided that fair compensation which shall be determined in default of agreement by the
Government shall be paid to the lessee/ lessees for all loss or damage sustained by him/they by
reason or in consequence of the exercise of the powers conferred by this clause and provided also
that the exercise of such powers shall not determine the said terms hereby granted or affect the
terms and provisions of these presents further than may be necessary to give effect to the provisions
of this clause.
18. Recovery of expenses incurred by the State Government. - If any of the
works or matters which in accordance with the convenants in that behalf
hereinbefore contained are to be carried or performed by the lessee/lessees
be not so carried out or performed within the time specified in that behalf, the
State Government may cause the same to be carried out or performed and
the lessee/ lessees shall pay the State Government on demand all expenses
which shall be incurred in such carrying out or performance of the same and
the decision of the State Government as to such expenses shall be final.
19. Other obligation. - (A) The lessee/lessees shall pay a wage not less than
the minimum wage prescribed by the Central Government or State
Government from time to time under Minimum Wages Act, 1948;
(B)The lessee/lessees shall comply with provisions of the Mines Act, 1952 and the rules made
thereunder;(C)The lessee/lessees shall take measures for the protection of environment like
planting of trees, reclamation of land, use of pollution control devices and such other measures as
may be prescribed by the Collector from time to time, at his own expense;(D)The lessee/lessees shall
pay compensation to the occupier of the land on the date and in the manner laid down in the
Rules;(E)The lessee/lessees shall in the matter of employment give preference to the tribals and to
the local persons;(F)The lessee/lessees shall not transport any mineral or its product from the
leased area without a valid transit pass as provided in the Rules.Chhattisgarh Minor Mineral Rules, 1996

Part VIII – The Convenants of the State Government
1. Lessee/lessees may hold and enjoy rights quietly. - The lessee/lessees
paying the rents and royalties hereby reserved and observing and
performing all the convenants and agreements herein contained and on the
part of the lessee/ lessees to be observed and performed shall and may
quietly hold and enjoy the rights and premises hereby demised for and
during the term hereby granted without any in lawful interruption from or by
the State Government or any person rightfully claiming under it.
2. Acquisition of land of third parties and compensation thereof. - If in
accordance with the provision of clause 4 of Part VII of this Schedule the
lessee/lessees shall offer to pay to an occupier of the surface of any part of
the said lands compensation for any damage or injury which may arise from
the proposed operations of the lessee/lessees and the said occupier shall
refuse his consent to the exercise of the right and powers reserved to the
State Government and demised to the lessee/lessees by these presents and
the lessee/lessees shall report the matter to the State Government and shall
deposit with it the amount offered as compensation and if the State
Government are satisfied that the amount of compensation offered is fair and
reasonable or if it is not so satisfied and the lessee/lessees shall have
deposited with it such further amount as the State Government shall
consider fair and reasonable the State Government shall order the occupier
to allow the lessee/ lessees to enter the land and to cam' out such operations
as may be necessary for the purpose of this lease. In assessing the amount
of such compensation the State Government shall be guided by the
principles of the Land Acquisition Act.
3. To renew. - The quarry lease is renewable in terms of the provisions of the
Rules.
4. Liberty to determine the lease. - (1) The lessee/lessees may at any time
determine this lease by giving not less than six calendar months notice in
writing to the Sanctioning Authority and upon the expiration of such notice
provided that the lessee/lessees shall upon such expiration render and pay
all rents, royalties, compensation for damages and other moneys which may
then be due and payable under these presents to the lessor or any otherChhattisgarh Minor Mineral Rules, 1996

person or persons and shall deliver these presents to the State Government
then this lease and the said term and the liberties, powers and privileges
hereby granted shall absolutely cease and determine but without prejudice to
any right or remedy of the lessor in respect of any breach of any of the
convenants or agreements contained in these presents.
(2)The Sanctioning Authority may on an application made by the lessee permit him to surrender
one or more minerals from his lease which is for a group of minerals on the ground that deposits of
that minerals have since exhausted or depleted to such an extent that it is no longer possible to work
the mineral economically subject to the condition that the lessee.(a)Makes an application for such
surrender of mineral atleast six months before the intended date of surrender; and,(b)Gives an
undertaking that he will not cause any hindrance in the working of the mineral so surrendered by
any other person who is subsequently granted a quarry lease for that mineral.
5. Refund of security deposits. - On such date as the Collector may elect after
the determination of this lease or of any renewal thereof, the amount of the
security deposit paid in respect of this lease and then remaining in deposit
with the State Government and not required to be applied to any of the
purposes mentioned in this lease shall be refunded to the lessee/lessees. No
interest shall run on the security deposit.
Part IX – General Provisions
1. Obstructions to inspection. - In case the lessee/lessees or his/their
transferee/assignee does/do not allow entry or inspection by the officers
authorised by the Central or State Government under the said Rules, the
Collector shall give notice in writing to the lessee/lessees requiring him/them
to show cause within such time as may be specified in the notice why the
lease should not be determined and his/their security deposit forfeited; and if
the lessee/lessees fails/fail to show cause within the aforesaid time to the
satisfaction of the Sanctioning Authority may determine the lease and forfeit
the whole or part of the security deposit.
2. Penalty in case of default in payment of royalty and breach of convenants.
- If the lessee/lessees of his/their transferee or assignee makes/ make any
default in payment of rent or royalty as required by the Rules, Act or commits
a breach of any of the conditions and convenants: other than those referred
to in convenant 1 above, the Collector shall give notice to the lessee/lessees
requiring him/them to pay the rent royalty or remedy the breach, as the caseChhattisgarh Minor Mineral Rules, 1996

may be within sixty days from the date of receipt of the notice and if the rent,
and royalty are not paid or the breach is not remedied within such period, the
Sanctioning Authority without prejudice to any proceedings that may be
taken against him/them, determine the lease and forfeit the whole or part of
the security deposit or may impose penalty as provided in Rules.
3. Failure to fulfil the terms of leases due to "Force Majeure". - Failure on the
part of the lessee/lessees to fulfil any of the terms and conditions of this
lease shall not give the State Government any claim against the
Lessee/lessees or be deemed a breach of this lease, in so far as such failure
is considered by the said Government to arise from force majeure, and if
through force majeure the fulfilment by the lessee/lessees of any of the terms
and conditions of this lease be delayed, the period of such delay shall be
added to the period fixed by this lease. In this clause the expression "Force
Majeure" means act of God, War, insurrection, riot, civil commotion, strike,
earth quake, tide, storm, tidal wave, flood, lightning, explosion, fire and any
other happening which the lessee/lessees could not reasonably prevent or
control.
4. Lessee/lessees to remove his/their properties on the expiry or lease. - The
lessee/lessees having first paid discharged rents, and royalties payable by
virtue of these presents may at the expiration or sooner determination of the
said term or within three calendar months thereafter (unless the lease shall
be determined under clauses 1 and 2 of this Part and in that case at any time
not less than 15 days nor more than three calendar months after such
determination) take down and remove for his/their own benefit all or any
engines, machinery, plant, building, structures, tramways and other works,
erections and conveniences which may have been erected, set up or placed
by the lessee/lessees in or upon the said lands and which the lessee/lessees
is/are not bound to deliver to the State Government under these rules.
5. Forfeiture of property left more than three months after determination of
lease. - If at the end of three calendar months after the expiration or sooner
determination of the said term under the provision contained in clause 4 of
Part VIII of this Schedule become, effective there shall remain in or upon the
said land any engines, machinery', plant, building structures, tramways and
other work, erections and conveniences or other property which are notChhattisgarh Minor Mineral Rules, 1996

required by the lessee/lessees in connection with operations in any other
lands held by him/them under quarry' lease the same shall if not removed by
the lessee/lessees within one calendar month after notice in writing requiring
their removal has been given to lessee/lessees by the Collector be deemed to
become to property of the State Government and may be sold or disposed of
in such manner as the State Government shall deem fit without liability to
pay any compensation or to account to the lessee/ lessees in respect thereof.
6. The lease is executed at................ and subject to the provision of Article
226 of the Constitution of India, it is hereby agreed upon by the lessee and
the lessor that in the event of any dispute in relation to the area under lease,
condition of lease, the dues realisable under the lease and in respect of all
matters touching the relationship of the lessee and the lessor, the suits (or
appeals) shall be filed in the civil courts at............(name of the city') and it is
hereby expressly agreed that neither party shall be competent to file a suit or
bring any action or file any petition at any place other than the courts named
above.
7. For the purpose of stamp duty the anticipated royalty from the demised
land is Rs............. per year.
In witness whereof these presents have been executed in the manner hereunder appearing the day
and year first above written.Signed byfor and on behalf of the
Governor(lessor)DatedWitness(1)..........................(2)..........................Witness(1)..........................(2)..........................Lessee
Dated......................(Signature and Designation)Form VIII[See Rule 29(6)]Application for Issue of
Transit Pass/transit Pass Book for Despatch of Minerals
1. Name of lessee
2. Address
3. Source of the Mineral
(i)Quarry at(ii)Tahsil(iii)Panchayat(iv)District
4. Name of mineralChhattisgarh Minor Mineral Rules, 1996

5. Quantity of mineral in stock and the quantity-proposed to be
despatched/transported
6. Route and mode of transport of the quantity
7. Purpose of despatch (Own consumption/sale). In case of sale, the name
and address of the purchaser should be furnished).
8. In case of Rail Transport
(i)Station of loading(ii)Destination of the consignment with the name and the address of the
consignee.
9. Sale value of the mineral
10. Period within which the applicant desires to despatch/transport the
quantity
11. Other particulars which the applicant wishes to state.
I/we hereby certify that the particulars given above are correct to the best of my/our knowledge and
belief.Signature of the ApplicantPlace :Date :Form IX[See Rule 29(7)]Transit Pass
  District.......................................
 Pass book No ............................................
 Transit Pass No ............................................
 Name of lessee/permit holder ............................................
 Name of Mineral ............................................
 Name of Quarry and village ............................................
 Area of Quarry ............................................
 Period of quarry lease/quarry permit ............................................
1Date of dispatch from quarry ............................................
2Time of dispatch from the Quarry ............................................
3Quantity of mineral being carried in cubic meters ............................................
4Name of purchaser and destination ............................................
5Value of the mineral being carried ............................................
6Truck/Tractor No. or name of the bullock cart owner ............................................
..................................... Signature of Lessee
Signature of Driver of the carrier. Contractor/Munshi/Authorised Agent.Chhattisgarh Minor Mineral Rules, 1996

Note. - (1) No over writing should be done and should be filled up in legible hand writing.(2)Original
copy should be given to driver of the carrier and carbon copy should be retained in this book for
depositing the book back with the authority for issue of next pass book.(3)Omission to write date
and time or over writing attracts penalty.(4)Only one Transit Pass should be issued to one carrier for
each trip.Form X[See Rule 30 (20) (a)]Monthly Return(To be submitted by 10th of ensuring month)
To,  For the month of.................  
(1) The Collector (1) Name of the lessee..............
  (2) Address........................
  (3) Location of quarry-
   (a) Village;
   (b) Tahsil;
   (c) Panchayat.
(2) Gram Panchayat (4) Details of lease
   (a) Khasra No............
area............
   (b) Period of lease
Note. - All figures be given in cubic metres.
1. Opening stock
2. Production of Mineral
3. Total (1+2)
4. Consumption of Mineral
5. Despatch of Mineral
6. Total consumption and Despatch (4+5)
7. Closing stock (3-6)
8. Transit passes used Book Nos. and Serial Nos
9. Products from mineral consumed-
(a)Opening stock(b)Production(c)Total (a+b)(d)Despatch(e)Closing stock (c-d)Chhattisgarh Minor Mineral Rules, 1996

10. Balance payable royalty
11. Royalty for this month
12. Total royalty (10+11)
13. Royalty paid vide challan No and
Date ..................Place .................
14. Balance due (12-13)
15. Remarks
Place......................... Signature of the lessee
Date............................ or his authorised person
Form XI[See Rule 30 (20)(b)]Half Yearly Return for the Period
1.
-1-19 to 30-06-19
1.
-7-19 to 31-12-19(To be submitted by 15th July/15th January)
To,  (1) Name of the lessee.........................
 (a) The Collector (2) Address....................................
 ............................... (3) Location of quarry-
 ...............................  (a) Village ;
   (b) Tahsil;
   (c) Panchayat.
  (4) Details of lease
   (a) Khasra No............
area...............
   (b) Period of lease
Note - All figures be given in cubic metres and rupeesChhattisgarh Minor Mineral Rules, 1996

1. Total production in the Half year
2. Consumption
3. Despatches
4. Total (2+3)
5. Royalty
6. Dead Rent Paid
7. Royalty payable (5-6)
8. Royalty paid Ch. No............Date........and place.........
Please give details of :-(1)Pits mouth value(2)Sale price(3)Average number of persons employed per
day(4)Depth of quarry(5)Use of explosives if any
Place......................... Signature of the lessee
Date............................ or his authorised person
Form XII[See Rule 30(20) (c)]Annual Return(To be submitted by 31st January every- year)To,The
Collector,
Part I – General
(1)Name and address of lessee(2)Name of Mine/quarry(3)Mineral/Minerals(4)Details of lease
area-(i)Total area with Khasra Nos(ii)Date of Execution(iii)Date of possession(iv)Period of
lease(v)Village, Panchayat(vi)Thana(vii)Post Office(viii)District
5. Transferor or previous lessee if any and date of transfer
6. Ownership (Please Mark)-
(i)Scheduled Tribe Society(ii)Scheduled Caste Society(iii)Educated unemployed
Society(iv)Individual (Indicate S.C./S.T./O.B.C.etc.)(v)Any other
Part II – Utilisation of AreaChhattisgarh Minor Mineral Rules, 1996

7. Lease area utilisation as at the end of year-
(i)Area already exploited and abandoned.(ii)Area covered under current operations.(iii)Area used
for waste disposal(iv)Area used for any other purpose (Give details)
Part III – Rents and Royalties
8. Royalty paid during the year-
(a)Royalty during the year(b)Amount of past arrears if any paid during the year
9. Amount of dead rent paid during the year.
10. Surface rent-
(i)Area for which surface rent is payable(ii)Amount paid for the year.(iii)Amount paid for past
arrears in any
Part IV – Production and Despatches
11. Production and Despatches
(i)Opening stock(ii)Production(iii)Despatches(iv)Closing stock
Part V – Cost of Production
12. (i) Direct Cost Cost per tonne
(ii)Over-head cost(iii)Interest(iv)Depreciation(v)Taxes, royalty etc.
13. Explosives and machinery used (Give specific details)
Place : Signature of lessee or his
Date : authorised person
Form XIII[See Rule 30 (24)]Notice
1. (a) Name of mine
(b)Name of mineral worked(c)Situation of mine (Village, Thana. Sub Division, District,
State)(d)Date when work was first startedChhattisgarh Minor Mineral Rules, 1996

2. (a) Name and postal address of present owner(s)
(b)Name and postal address of agent, if any
3. (a) Name and postal address of Manager, if any
(b)His age(c)His qualifications(d)His experience in mining
4. Whether working are likely to be extended below ground
5. (a) Maximum depth of open cast excavation measured from its highest to
its lowest point.
(b)Date when depth first exceeded 6 metres.
6. (a) Nature, amount and kind of explosive used, If any
(b)Date when explosives were first used...................................Signature of
Owner/Agent/ManagerDate........................................To be sent to :-
1. The Director General, Mines Safety, Government of India, Dhanbad.
2. The Controller General, India Bureau of Mines, Government, of India
Nagpur.
3. The District Magistrate of the District where the mine situated.
4. The Mining Officer/Assistant Mining Officer.
Form XIVModel Form For transfer Of Quarry Lease[See Rule 35 (3)]When the transferor is an
individual.............The indenture made this ........... day of..........19......... between......... (Name of the
person with address and occupation) hereinafter referred to as the "transferor" (which expression
shall where the context so admits be deemed to include his heirs executors, administrators,
representatives and permitted assignees);OrWhen the transferor is a
Society/Association................(Name of the society/Association with address and occupation)
and..................... (Name of person with address and occupation) hereinafter referred to as the
"transferor" (which expression shall where the context so admits be deemed to include their
respective heirs, executors administrators, representatives and their permitted assignees);OrWhen
the transferor is a registered firm...................(Name of the person with address of all the partners)
all carrying on business in partnership under the firm name and style of..............(Name of the firm)
registered under the Indian Partnership Act, 1932 (9 of 1932) and having their registered office at
...............hereinafter referred to as the "transferor" (which expression where the context so admitsChhattisgarh Minor Mineral Rules, 1996

be deemed to include all the said partners, their respective heirs, executors, legal representatives
and permitted assignees);OrWhen the transferor is a registered company.......................... (Name of
Company) a company registered under...................(Act under which incorporated) and having its
registered office at....................(Address) hereinafter referred to as the "transferor" (which
expression shall where the context so admits be deemed to include its successors and permitted
assignees) of the first part.AndWhen the transferee is an individual.........................................(Name
of person with address and occupation) hereinafter referred to as the "transferee" (which expression
shall where the context so admits be deemed to include his heirs, executors, administrators
representatives and permitted assignees).OrWhen the transferee is a
Society/Association...............(Name of the society/association with address and occupation)
and...................(Name of person with address and occupation) hereinafter referred to as the
"transferee" (which expression shall where the context so admits be deemed to include their
respective heirs, executors, administrators, representatives and their permitted assignees);OrWhen
the transferee is a registered firm................(Name and address of all the partners) all carrying on
business in partnership under the firm name and style of...............(Name of the firm) registered
under the Indian Partnership Act, 1932 (9 of 1932) and having their registered office
at...........................................hereinafter referred to as the " transferee" (which expression where the
context so admits be deemed to include all the said partners, their respective heirs, executors, legal
representatives and permitted assignees.)OrWhen the transferee is registered company ..................
(Name of the Company) a company registered under (Act under which incorporated) and having its
registered office at...........(Address) hereinafter referred to as the "transferee" (which expression
shall where the context so admits be deemed to include its successors and permitted assignees) of
the second part.AndThe Governor of Chhattisgarh hereinafter referred to as the "State Government"
(which expression shall where the context so admits be deemed to include the successors and
assignees) of the third part.Whereas by virtue of an indenture of lease dated the ..................... and
registered as No.............on.............(date) in the office of the Sub-Registrar of................ (place)
hereinafter referred to as lease the original whereof is attached hereto and marked 'A' entered into
between the State Government (herein called the lessor) and the transferor (therein called the
lessee), the transferor is entitled to search for, win and work the mines and minerals in respect
of..............(name of mineral/s) in the lands described in Schedule thereto and also in Schedule
annexed hereto for the term and subject to the payment of the rents and royalties and observance
and performance of the lessee's convenant and condition in the said deed of lease reserved and
contained including a convenant not to assign the lease or any interest thereunder without the
previous sanction of the Competent Authority.And Whereas the transferor is now desirous of
transferring and assigning the lease to the transferee and the Competent Authority has at the
request of the transferor, granted permission to the transferor vide order
No.........................dated...........to such a transfer and assignment of the lease upon the condition of
the transferee entering into an agreement in and containing the terms and conditions hereinafter set
forth.Now this Deed witnesseth as follows :
1. The transferee hereby convenants with the State Government that from
and after the transfer and assignment of the lease the transferee shall be
bound by, and be liable to perform, observe and conform and be subject toChhattisgarh Minor Mineral Rules, 1996

all the provisions of all the convenants, stipulations and conditions
contained in said herein before recited lease in the same manner in all
respects as if the lease had been granted to the transferee as the lessee
thereunder and he had originally executed it as such.
2. It is further hereby agreed and declared by the transferor of the one part
and the transferee of the other part that-
(i)the transferor and the transferee declare that they have ensured that the mineral rights over the
area for which the quarry lease is being transferred vest in the State Government.(ii)The transferor
hereby declares that he/she has not assigned, subject; mortgaged or in any other manner
transferred the quarry lease now being transferred and that no other person or persons has any
right, title or interest where under in the present quarry lease being transferred.(iii)The transferor
further declares that he/she has not entered into or made any agreements, contract or
understanding whereby he had been or is being directly or indirectly financed to a substantial extent
by or under which the transferor's operation or understandings were or are being substantially
controlled by any person or body of persons other than the transferor.(iv)The transferee hereby
declares that he/she has accepted all the conditions and liabilities which the transferor was having
in respect of such "quarry lease."(v)The transferee further declares that he/she is financially capable
of and will directly undertake mining operations.(vi)The transferor has supplied to the transferee
the Original or certified copies of all plans of abandoned workings in the area and in a belt 65 metre
wide surrounding it.(vii)The transferee hereby further declares that as a consequence of this
transfer, the total area which is held by him under quarry- leases are not in contravention of the
Chhattisgarh Minor Minerals Rules, 1996.(viii)The transferor has paid all the rent, royalties and
other dues towards Government till the date, in respect of this lease.In witness whereof the parties
hereto have signed on the date and year first above written.
Schedule 5
Location and area of the leaseAll that tract of lands situated at village..............(Description of area of
areas) Tahsil .................................. District.......................... bearing khasra Nos...............containing
an area of................ or thereabout delineated on the plan hereto annexed and thereon
coloured..............and bounded as followsOn the North by .....................On the South by
.....................One the East by .....................AndOn the West by .......................Signed by for and on
behalf of the State Government in the presence of-
1.
2.
Signature of Transferor in the presence of witnesses-Chhattisgarh Minor Mineral Rules, 1996

1.
2.
Signature of transferee in the presence of-
1.
..............................................
2.
..............................................Form XV[See Rule 37]Form of Application for Quarry PermitReceived
at ............. (Place)On ....................... (Date)Date : ..............Initial of Receiving Officer........To,The
...................................................Sir,I/We request that a quarry permit under the Chhattisgarh Minor
Mineral Rules, 1996 be granted to me/us.A sum of Rs. 25/- being the fee in respect of this
application is deposited and cash receipt in original is enclosed.The following particulars are
enclosed :-
1. Name of applicant.
2. Address of applicant.
3. Registration certificate and by-laws of the Society/Association.
4. Profession/Nature of business and place of working.
5. Cast (Individual or members of Society/Association.)
6. Educational qualification (Individual or members of Society/ Association.)
7. Age (Individual or members of Society/Association.)
8. Financial status (Individual or members of Society/Association.)
9. Name of minor minerals applied for.
10. Quantity in cu. mts. required.Chhattisgarh Minor Mineral Rules, 1996

11. Time within which the entire quantity will be removed and transported.
12. Purpose for which the minor mineral is to be used.
13. Consent of owner/owners in case of private land.
14. Certified copy of village plan with khasra panchsala indicating the land
from which the minor mineral is to be removed and transported.
I/We do hereby declare that the particulars funished are correct and am/are ready to furnish any
other details as may be required by you. I/We do hereby further declare that I/We shall adhre to the
terms and conditions as indicated in permit and rules in Chhattisgarh Minor Minerals Rules. 1996
and any other condition imposed by the competent authority.
Place : Your's faithfully
Date : Signature of the applicant.
Form XVI[See Rule 38 (2)]Form of Grant of Quarry PermitQuarry Permit No............................Date
.......................................Whereas. Shri ............................... applied for grant of quarry permit for
removal and transport of .............................. (Minor Minerals) from Khasra No.....................of
Village, Panchayat.....................Tahsil..............District...............under Rule.................of the
Chhattisgarh Minor Mineral Rules, 1996 and has paid an application fee of Rs. 25/-.Permission is
hereby granted to quarry, collect, remove and transport.......(mineral) from the aforesaid area/areas
indicated on the plan annexed hereto on the following conditions.
1. The quarry permit shall be valid for ................... from the date of issue.
2. The quarry permit holders shall abide by the conditions provided in the
Chhattisgarh Minor Mineral Rules, 1996.
Signature of the Competent Authority with seal of office.To,Shri ....................................Copy to :-
1. Mining Officer/Assistant Mining Officer of the District.
2. Janpad Panchayat/Gram Panchayat.
Signature of the Competent Authority with seal of office.Form XVII[See Rule 38 (2)]Quarry Permit
AgreementThis indenture made this day of. 19......between the Zila/Janpad/Gram Panchayat
(hereinafter called the 'Lessor' which expression shall where the context so admits, include his
successors in office and assignees) of the one part, and ........... (hereinafter called the 'lessee' which
expression shall, where the context so admits, includes his heirs executors, administrators,
representatives and assignees) of the other part.Whereas the lessee has been granted a quarry
permit by the lessor on his application in the Gram Panchayat Village ........... Tahsil .............Chhattisgarh Minor Mineral Rules, 1996

District.........for the purpose of quarrying for............(Name of the Mineral) in the land comprising of
Khasra No...............area of................hectares and the lessee has deposited the application fees of Rs.
25/- (Rs. Twenty Five) and as security Rs.................... (Rs.....................) for the due and faithful
performance by the lessee of the convenants and conditions on the part of the lessee hereinafter
contained.And whereas the Zila/Janpad/Gram Panchayat in respect of the lands so described and
demised for a term of..............and subject to the convenants and conditions hereinafter contained
now this indenture witness as follows :-The lessor hereby demises to the lessee all those lands being
specifically described in the Schedule hereunder and delineated in the plan annexed hereunto and
therein coloured..................
2. There are included in the said demise and for the purposes thereof
following liberties:-
(i)Minerals hereinafter authorised to be got from the said lands by the lessee.(ii)Generally to do all
things which shall be convenient or necessary for getting the mineral and for removing and
disposing thereto.(iii)The lessee hereby agrees to pay during the said terms royalty' as specified in
Schedule III.(iv)To bear, pay and discharge all existing and future rates, assessment whatsoever
imposed or charged upon the demised land or the produce thereof.(v)Not to assign, subject or part
with the possession of the demised land.(vi)That the lessee shall keep correct accounts, in such form
as the Authority shall, from time to time, require and direct showing the quantities and other
particulars of the said mineral obtained by the lessee from the said lands.(vii)If in the course of
quarrying any mineral not specified in this agreement is discovered the lessee shall at once report
such discovery to the Authority concerned and shall obtain orders of such competent Authority for
working of the same.(viii)The lessor or their authorised officers shall be at liberty at all reasonable
times to inspect and examine the works carried on by the lessee and may issue such orders and
regulations as may be necessary as the result of such inspection to keep the lands in good order and
condition or in the interest of public health and safety.(ix)The lessee shall not cut or injure any
timber or trees.(x)The lessee shall pay where ever necessary compensation for any loss or damage
which may be caused by the lessee to surface of the demised land or any vegetation growing or
situated therein. The lessee shall further always keep the lessor indemnified against any claim by
any person for any loss or injury caused to him or to his property by the lessee. The Authority shall
be competent to assess and fix any compensation payable by the lessee on this account.(xi)The
lessee shall erect and maintain at his own expense boundary pillars of substantial material along the
boundary as delineated in the plan annexed hereto.(xii)That this lease may be terminated in respect
of the whole or any part of the lands by a one month notice in writing on either side provided that
the lessee has paid all outstanding dues before such notice is given by him.(xiii)That on such
determination the lessee shall have no rights to compensation of any kind.(xiv)The lessee shall
immediately report all accidents to the competent authority and the collector of the district.(xv)The
lessee shall not transport any mineral without valid transit pass issued by the competent authority
in form IX. He/she shall surrender all duplicate of used transit pass and unused transit passes on
expiry of permit period.Chhattisgarh Minor Mineral Rules, 1996

3. The lessor hereby convenants with the lessee that on observing and
performing the several convenants and stipulations herein and provided in
the Chhattisgarh Minor Mineral Rules, 1996, the lessee shall peacefully hold
and enjoy the demised land and the liberties hereby demised and granted
during the said term without any interruption by the lessor or any person
rightfully claiming under him
4. The said demised land shall be held by the lessee for the term
of...............years from the..............day of.......... 19..........to the..............day
of.......... 19 ............
In witness whereof...........acting for and on behalf of and by an order and direction of the said
Zila/Janpad/Gram Panchayats and the said lessee have hereto set their hands the day and year
mentioned above.
Schedule 6
Name of Village Khasra No. Area in hectares Boundaries
Witness : 1.............................................. Signed & Delivered by
 2.............................................. the above named.
Witness : 1.............................................. Lessor.............................
 2.............................................. Lessee.............................
Form XVIII(See Rule 41)Register of Quarry PermitsS.No.
1. Name of the permit holder and address.
2. Date of application.
3. Mineral for which permit has been granted
4. No. & date of order.
5. Period.
6. Village.
7. Tahsil.Chhattisgarh Minor Mineral Rules, 1996

8. Khasra Number & area.
9. Signature of the Officer.
10. Remarks.
Form XIX[See Rule 48 (I)]Scheme of Environmental Management
1. Name and Address of quarry lease holder.
2. Particulars of the area-
(i)Date of execution of agreement.(ii)Period.(iii)Extent of area.(iv)Mineral.(v)Khasra
Nos(vi)Panchayat and tehsil.(vii)District.
3. Particulars of the machines to be used.
4. The plan of the area showing number of pits already made showing all
areas within 500 metres of the lease boundary' with details thereof.
5. Details of quarrying operations to be undertaken.
6. Scheme for plantation of trees.
7. Scheme for progressive reclamation and rehabilitation of the land
disturbed.
8. Scheme for prevention and control of air and water pollution.
9. Any other matter which the lessee desires to state.
Place : Signature
Date : Name in full
Form XX[See Rule 48 (5)]Quarterly Report of EnvironmentTo,The
Collector,................................Pin............................
1. Name and Address of lease holder.Chhattisgarh Minor Mineral Rules, 1996

2. Particulars of lease.
3. Plantation-
(i)No. of trees planted during the period(ii)Area of plantation
4. Area worked out
5. Area reclaimed
6. Dumps of top soil, overburden etc.
SizeType
7. Precautions for stablization
8. Any other matter which the lessee desires to state
Place : Signature
Date : Name in full
 Designation
[Form XXI [Substituted by Notification No. F-7-7/2004/12, dated 24-8-2006.][See Rule 60 (1)](To
be submitted in triplicate)Model form of Application for Appeal
1. Name and address of individual(s) society, firm or company, applying
2. Profession.
3. Name of authority, No. and date of order against which the appeal
application is filed (copy attached).
4. Minor Mineral or Minor Minerals for which the appeal application is filed.
5. Details of the area in respect of which the application is filed.
District Tehsil Village PanchayatKhasra
No. &
total
area
(A map or plan of
the area(s) to beChhattisgarh Minor Mineral Rules, 1996

attached)
6.Whether application fee has been deposited inthe
mannerprescribed. Original receipt to beattached.
7.Whether the appeal application has been
filedwithin timespecified if not, the reasons for
notpresenting it withinthe prescribed limits
asprovided for in rules.
8. Name and complete address of the party/ parties impleaded.
9. No. of copies attached.
10. Grounds of appeal.
11. If the appeal application has been filed by the holder of Power of
Attorney, the Power of Attorney, to be attached.
Signature of the Applicant.]Place :Date :Chhattisgarh Minor Mineral Rules, 1996

