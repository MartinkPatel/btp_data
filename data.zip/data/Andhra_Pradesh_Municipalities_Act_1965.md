Andhra Pradesh Municipalities Act, 1965
ANDHRA PRADESH
India
Andhra Pradesh Municipalities Act, 1965
Act 6 of 1965
Published on 17 February 1965• 
Commenced on 17 February 1965• 
[This is the version of this document from 17 February 1965.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
Andhra Pradesh Municipalities Act, 1965(Andhra Pradesh Act No. 6 of 1965)Last Updated 26th
October, 2019Statement of Objects and Reasons. - According to Section 5(2) (ii) of Andhra Pradesh
Municipalities Act, 1965, a Member of the Legislative Assemble representing a constituency which
comprises more than one Municipality including a part of any Municipality shall be ex-officio
member of one such Municipality which he chooses with voting right and shall have the right to
speak in or take part in the proceedings of the other Councils within the Constituency but not
entitled to vote at any such meeting. The same holds good in respect of a Member of the House of
the people under Section 5(2) (iii)As no time limit was fixed in the said provisions to choose a
Municipality, the Member of Legislative Assemble or Member of the House of the People are taking
their own time resulting in the Municipal Councils transacting business in the absence of Ex-officio
Members.After careful examination, the Government have felt it desirable to fix a time limit of thirty
days from date of conduct of ordinary elections to the Municipality or the date of election to the
Assembly or the House of the People, as the case may be, to choose a Municipality, if there are more
than one Municipality in the Constituency represented by the Member of the Legislative Assembly
or as the case may be member of the House of the People concerned by giving a notice in writing to
the Commissioner. It is also decided to make the intimation once made as irrevocable and in default
of such intimation, the Election Authority shall be empowered to decide the Municipality to which
the Member of Legislative Assembly or as the case may be the Member of the House of the People
shall be ex-officio member and to inform the same to such member. The Government have
accordingly decided to amend section 5(2)(ii) and (iii) of the Andhra Pradesh Municipality Act, 1965
suitably by substituting new provisos.2. This Bill seeks to give effect to the above
decisions.Statement of Object and Reasons. - Section 142 of the Andhra Pradesh Municipality Act,
1965 empowers the Government to direct the Municipal Council to levy and collect the pipe-line
service charges from the owner or occupies of a building of any category specified in clause (a) of
sub-section (2) of section 141 to defray towards the capital cost of pipe-line system from time to
time. But there is no similar provision in the Act to enable the Municipal Council to levy and collect
such pipe-line charge from the owners or occupiers of the building for having connection with
underground drainage system.To achieve the above object in view, the Government have therefore,
decided to amend the Andhra Pradesh Municipality Act, 1965 in Council Resolution No. 159/98,Andhra Pradesh Municipalities Act, 1965

suitably:-As the Legislative Assembly of the State was not the in session having been prorogued and
as it has been decided to give effect to the above decision immediately, the Andhra Pradesh
Municipality (Amendment) Ordinance, 1998 (A.P. Ordinance No. 4 of 1998) has been promulgated
by the Governor on the 12th June, 1998 and in order to have continuity of law the Andhra Pradesh
Municipality (Second Amendment) Ordinance, 1998 (A.P. Ordinance No. 6 of 1998) has been
promulgated by the Governor on the 3rd September, 1998.2. This Bill seeks to replace the said
Ordinances.Statement of Objects and Reasons. - According to G.O.Ms.No. 220, M.A. & U.D.
Department, dated 30.4.1998, the District Selection Committee constituted under rule 3 of the Rules
issued in G.O.Ms.No. 221, Education (Ser. III) Department 16.7.1994 shall conduct recruitment to
the teacher posts in the schools maintained by the Municipalities as per the procedure mentioned
therein and names of the selected candidates shall be sent to the concerned Municipalities for
issuance of appointment orders. The said rules were framed by invoking the provisions of the
Andhra Pradesh Education Act, 1982 and the Andhra Pradesh Panchayat Raj Act, 1994 but not
invoking the provisions of the Andhra Pradesh Municipalities Act, 1965.The Andhra Pradesh High
Court in its order dated 24.6.1998 in W.P.M.P.No. 18969/98 in W.P.No. 16902/96 filed by the
President, the Andhra Pradesh Chamber of Municipal Chairman has suspended rule 3 of the rules
issued by the Government in G.O.Ms.No. 221, Education (Ser. III) Department, dated 16.7.1994 in
so far as the posts relating to the Municipalities are concerned, as it is in violation of section 74 of
the Andhra Pradesh Municipalities Act, 1965 and article 243-w and Schedule 12, item-13 of the
Constitutior.In view of the interim orders of the High Court, the rules issued in G.O.Ms.No. 220,
M.A. & U.D. Department, dated 30.4.1998, and the Selection Committee constituted under rule 3 of
G.O.Ms.No. 221, Eduction (Sar. III) Department, dated 16.7.1994 are not in tune with the provision
of section 74 of the Andhra Pradesh Municipalities Act, 1965 and therefore Government have
decided to amend the section 74 of the said Act, suitably and frame fresh rules.As the Legislative
Assembly of the state was not then in Session having been prorogued and as it has been decided to
give effect to the above decision immediately, the Andhra Pradesh Municipalities (Amendment)
Ordinance, 1999, (A.P. Ordinance 2 of 1999) has been promulgated by the Governor on the 6th
February, 1999 and published it on the same date.2. This Bill seeks to replace the said
Ordinance.Statement of Objects and Reasons. - Under sub-section (2) of Section 46 of Andhra
Pradesh Municipalities Act, 1965, the motion of no-confidence in Vice-Chairperson can be moved by
members including ex-officio members of the Council and by such members not less than one half of
the sanctioned strength of the Council. Since the Chairperson is directly elected, he is not included
in the sanctioned strength of the Council. However, by virtue of sub-section (7) of Section 23 of
Andhra Pradesh Municipalities Act, 1965, Chairperson by virtue of his office, be a member of
Municipal Council and shall have all the rights and privileges of an elected member and shall be
entitled to vote at all the meetings of the Council including the meetings convened to pass motion of
no confidence in the Vice-Chairperson. But the wording of Section 46 (2) gives rise to an ambiguity
whether Chair-person can be a signatory in such no confidence motion. In order to avoid any
ambiguity in the matter and to include the Chairperson in the sanctioned strength of the Council
Government have decided to amend the section 46 of the Andhra Pradesh Municipalities Act, 1965
suitably.2. This Bill seeks to give effect to the above decision.Statement of Objects and Reasons. -
According to proviso under sub-section (2) of section 7 of the Andhra Pradesh Municipalities Act,
1965, the appointment of Special Officer to the newly constituted Municipalities in the absence of an
elected body to perform the duties and functions of the council is for a period of one year only. DueAndhra Pradesh Municipalities Act, 1965

to various reasons such as wars division, fixation of reservation of seats for Palasa-Kasibugga
Municipality elections could not be held. Necessary steps have already been taken to complete the
ward division and fixation of reservations of seats etc. and it has been proposed to conduct elections
within the stipulated time.As the term of the Special Officer of Palasa-Kasibugga Municipality
expires by 29-1-2002, it was decided to amend sub-section (2) of section 7 of the said Act enabling
the Government to extend the term for a further period of six months and accordingly the Andhra
Pradesh Municipalities (Amendment) Ordinance, 2002 (A.P. Ordinance 1 of 2002) was
promulgated by the Governor on 28-1-2002.As the Legislative Assembly was not then in session
having been prorogued and in order to have continuity of the Office of the Special Officer in the
above said Municipality it has been decided to extend the term of the Special Officer for a further
period of six months, the Andhra Pradesh Municipalities (Amendment) Ordinance, 2002 (A.P.
Ordinance 1 of 2002) has been promulgated by the Governor on the 28th January, 2002.2. This Bill
seeks to replace the above said Ordinance.Statement of Objects and Reasons. - According to proviso
under sub-section (2) of section 7 of the Andhra pradesh Municipalities Act, 1965 empowers the
Government to appoint a Special officer for a period of one year for the newly constituted Municipal
Councils to exercise the powers, discharge the duties and perform the functions of the Council. The
Special Officer so appointed shall cause arrangements for election to be made so that the
Chairperson and the elected members may come into Office. The said term of the one year was
raised to one year was raised to one and half year through the Andhra Pradesh Municipalities
(Amendment) Act, 2002 (Act 9 of 2002) with retrospective effect from 23rd November, 2001. The
election to the Palasa-Kasubugga Municipal Council which is a newly constituted Municipality could
not be held due to revision forward division and the revision was sub-sequently completed. An
election Notification for Palasa-Kasibugga Municipal Council was issued by the State Election
Commission on 16.3.2002. After issue of the said Notification, Sri T. Krishna Rao and another
residents of Palasa have approached the Hon'ble High Court in W.P.M.P. No. 6010 of 2002 and
their prayer is to stay all further proceedings including the proposed conduct of elections of the
Palasa-Kasibugga Municipal Council, Srikakulam District pending disposal of W.P.No. 4814 of
2002. On which the Hon'ble High Court directed the concerned not to conduct elections. As per the
High Court directions election to the Palasa-Lasibugga Municipal Council could not be held.
Necessary steps have already been taken to vacate the stay orders in cousultiation with the
Government Pleader for General Administration Department in order to conduct the elections.
According to proviso to the sub-section (2) of Section 7 of the A.P. Municipalities Act, 1965, the term
of special officer will continue up to 23.5.2002. Within the said date the election process could not
be completed in view of the interim orders of the High Court. Therefore, it is necessary to extend the
term of Special Officer of the Palasa-Lasibugga Municipality for a further period of six months from
24.5.2002 to 23.11.2002. Subsequently stay has been vacated and action is being taken to conduct
the elections by the Director of Municipal Administration/State Election Commission.As the
Legislative Assembly was not then in session having been prorogued and in order to have continuity
of the office of Special Officer in the above said Municipality it has been decided to extend the term
of the Special Officer for a further period of six months, the A.P. Municipalities (Second
Amendment) Ordinance, 2002 (A.P. Ordinance 2 of 2002) has been promulgated by the Governor
on the 21st May, 2002 which has been published in Part IV-B, Extraordinary of the Andhra Pradesh
Gazette dated the 22nd May, 2002.2. This Bill seeks to replace the above said Ordinance.Statement
of Objects and Reasons - (Act No. 6 of 2012). - Para 10.161 of the report of XHIth FinanceAndhra Pradesh Municipalities Act, 1965

Commission stipulates that a State Government will be eligible to draw its share of the performance
grant for the years 2011-12 to 2014-15 in respect of Local Bodies if it complies with nine conditions
by the end of financial year (315' March) for the succeeding financial year. Andhra Pradesh State is
eligible for performance grant of ? 664.23 crores approximately in respect of Urban Local Bodies
(ULBs) for the next four years starting from 2011-12. Condition VII of the XIII Finance Commission
states that "State Governments must put in place a State Level Property Tax Board, which will assist
all Municipalities and Municipal Corporations in the State to put in place an independent and
transparent procedure for assessing Property tax".2. The XIIIth Finance Commission stipulated that
the Board would be responsible to: Enumerate or cause to enumerate all properties within the
jurisdiction of the Municipalities and Corporations;Review the present property tax system and
make suggestions for proper assessment and valuation of properties; and Recommend modalities
for periodic revisions.3. The XIIIth Finance Commission has further stipulated that:The findings,
suggestions and recommendations of the Board will be communicated to the respective Urban Local
Bodies for necessary action.The exact model to be adopted is left to the respective States. The Board
should be staffed and equipped in such a manner as to be able to make recommendations relating to
atleast 25% of the aggregate number of estimated properties across all Urban Local Bodies (ULBs)
in the State by 31st March, 2015. The Board should prepare a work plan indicating how it proposes
to achieve this coverage target and the human and financial resources it proposes to deploy. Passage
of the relevant legislation or issue of the necessary executive instructions by the State Government
for creation of the Property Tax Board as well as publication of the work plan by the Board in the
State Government gazette will demonstrate compliance with this condition.4. To comply with the
conditions stipulated by XIIIth Finance Commission, Government have issued orders in G.O.Ms.No.
107, MA & UD (TC.l) Department dated 26-3-2011 constituting Andhra Pradesh State Property Tax
Board to provide assistance and technical guidance to all Municipalities and Municipal Corporations
in the State for proper assessment and revision of-Property Tax. It is proposed to amend Municipal
Laws suitably to provide a statutory backing for A.P.State Property Tax Board already constituted.
The Board also will review the present property tax assessment system in Municipalities and
Municipal Corporations and make suggestions to the Government in this regard.5. In view of the
above, all the Municipal Commissioners are required to consult the Board before issue of draft
notification fixing monthly rent proposed per square meter of plinth area for assessment or revision
of property tax. The Andhra Pradesh State Property Tax Board shall study the draft notification and
make a comparative study of the monthly rental values proposed by other Municipalise is in the
District in this regard and offer its views in this matter. The Municipal Commissioners shall give due
consideration to the views offered by the Andhra Pradesh State Property Tax Board before adopting
the final notification showing monthly rent per square meter of plinth area as prescribed. It is
proposed to amend Municipal Laws suitably to provide a statutory backing for Andhra Pradesh
State Property Tax Board already constituted.Accordingly, it has been decided to amend the
Municipal Laws.The salient features of the Bill are:-(i) To provide a statutory backing to the Andhra
Pradesh State Level Property Tax Board;(ii) The Chairperson of the Board shall be a person who has
held the office of the Judge of High Court; and(iii) The Board may be entrusted with the function of
suggesting criteria for exempting buildings and lands from payment of property tax.6. The bill seeks
to give effect to the above decisions.Received the assent of 'he Governor or the 17th April, 2012 and
the said assent is hereby first published on the 20th April, 2012 in the Andhra Pradesh Gazette for
general information.Statement of Objects and Reasons - (Act No. 16 of 2009). - Section 23(1)(c) ofAndhra Pradesh Municipalities Act, 1965

Andhra Pradesh Municipalities Act, 1965 which was in force prior to its amendment by the Andhra
Pradesh Municipal Laws (Third Amendment) Act, 2005 (Act No. 29 of 2005) provided that out of
the total number of offices of Chairperson in the State, the Government shall, subject to such Rules,
as may be prescribed, by notification, reserve such number of offices to the Scheduled Castes,
Scheduled Tribes, Backward Classes and Women, Section 23(1) of the said Act which was amended
by the Andhra Pradesh Municipal Laws (Third Amendment) Act, 2005 (Act No. 29 of 2005),
provides that the Chairperson and Vice-Chairperson shall be elected by the elected members and
ex-officio members. However there is no provision in the amended Act regarding reservation of
offices of the Chairperson to the Scheduled Casts, Scheduled Tribes, Backward Classes and
Women.However, the offices of the Chairperson in Municipalities were reserved in favour of
Scheduled Castes, Scheduled Tribes, Backward Classes and Women in G.O.Ms.No. 759, M.A&U.D.
(Elec. II) Department, dated 18-8-2005. It is therefore, decided to amend the Act suitably providing
for reservation to the offices of the Chairperson to the Scheduled Castes, Scheduled Tribes,
Backward Classes and Women, with effect from 6-8-2005, to validate the reservation of offices of
Chairpersons already made in the said Government Order by making suitable provisions in the
Bill.This Bill seeks to give effect to the above decision.Statement of Objects and Reasons - (Act No.
13 of 2000). - Article 334 of the Constitution of India provided for reservation of seats to the
Scheduled Castes, Scheduled Tribes and Anglo Indian Community in the House of People and in the
Legislative Assemblies of the States upto 25th January, 2000 and under Article 243T of the
Constitution, the reservation of seats for the Scheduled Castes and Scheduled Tribes in Municipal
Institutions shall cease to have effect on the expiration of the period specified in Article 334. Section
9 of the Andhra Pradesh Municipalities Act, 1965 and Section 56-A of the Hyderabad Municipal
Corporation Act, 1955 accordingly provided for such reservations to cease after 25th January,
2000.2. The Constitution of India has been amended by the Constitution (79th Amendment) Act,
1999 for extending the reservations for a further period of ten years. To bring the reservations for
Scheduled Castes and Scheduled Tribes In the Municipal Institutions in the State, in conformity
with the provisions of the Constitutions, as amended from time to time, it has been decided to
amend Section 9 of the Andhra Pradesh Municipalities Act, 1965 and Section 56A of the Hyderabad
Municipal Corporation Act, 1955 to continue the reservations so long as they are provided by Article
334 of the Constitution.3. As the Legislative Assembly of the State was not then in session having
been prorogued and it was considered necessary to give effect to the above decision immediately, the
Andhra Pradesh Municipal Laws (Amendment) Ordinance, 2000 was promulgated by the Governor
on the 23rd January, 2000.4. This Bill seeks to replace the said Ordinance.Appended to L.A.Bill No.
14 of 2000.[Dated 17.2.1965]An Act to consolidate and amend the law relating to municipalities in
the State of Andhra Pradesh. Be it enacted by the Legislature of the State of Andhra Pradesh in the
Sixteenth Year of the Republic of India as follows: -
Part 1 – Preliminary
1. Short title, extent and commencement.
(1)This Act may be called the Andhra Pradesh Municipalities Act, 1965.(2)It extends to the whole of
the State of Andhra Pradesh.(3)It shall come into force on such date as the State Government may,
by notification in the Andhra Pradesh Gazette, appoint.Andhra Pradesh Municipalities Act, 1965

2. Definitions.
- In this Act, unless the context otherwise requires, -(1)"Andhra Area" means the area in the State of
Andhra Pradesh other than Telangana area;(2)"appointment" , "appoint" , includes temporary
appointment and officiating appointment or to appoint temporarily or in an officiating
capacity;(2-a) "Backward Classes" means any socially and educationally backward classes of citizens
recognised by the Government for purposes of Clause (4) of Article 15 of the Constitution of
India.(3)"building" means any structure constructed of any materials for any purpose, and includes
a house, out-house, shop, stable, latrine, shed, hut, wall (other than a boundary wall not exceeding
two metres in height), or any part of such building;(4)"building line" means a line which is in rear of
the street alignment and to which the main wall of a building abutting on a street may lawfully
extend;(5)"carriage" means any wheeled vehicle with springs or other appliances acting as springs
and includes any kind of bicycle, tricycle, rickshaw and palanquin but does not include any motor
vehicle within the meaning of the Motor Vehicles Act, 1939; (Central Act 4 of 1939).(6)"cart"
includes any wheeled vehicle which is not a carriage but does not include any motor vehicle within
the meaning of the Motor Vehicles Act, 1939; (Central Act 4 of 1939).(7)"casual vacancy" means a
vacancy occurring otherwise than by efflux of time and casual election' means an election held to fill
a casual vacancy:(7-a) "ceiling limit" means the ceiling limit as specified in Section 4 of the Urban
Land (Ceiling and Regulation) Act, 1976.(8)'Chairperson' means the Chairperson of the
Council;(8-a) "Commissioner" means the person appointed as Commissioner under Sub-section (1)
of Section 29(9)"Company" means a company as defined in the Companies Act, 1956; (Central Act 1
of 1956), and includes any foreign company within the meaning of Section 591 of that
Act:(10)"conservancy worker" means a person employed in collecting or removing filth, in cleaning
drains or slaughter houses or in driving cars used for the removal of filth;(11)"Council" means a
municipal council constituted under this Act;(12)"election authority" means such officer or authority
as may be appointed by the State Election Commission to exercise such powers and to perform such
functions in connection with the conduct of elections to the Municipalities;(13)............(14)"factory"
means any premises including the precincts thereof,--(i)Where in any industrial or manufacturing
process is carried on with the aid of steam, water, oil, gas, electrical or any other form of power
which is mechanically transmitted and is not generated by human or animal agency; or(ii)Whereon
twenty or more workers are working or were working and in any part of which a manufacturing
process is being carried on without the aid of power or is ordinarily so carried on; but does not
include a mine subject to the operation of the Mines Act, 1952 (Central Act 35 of 1952) or a railway
running shed;(15)"filth" means--(a)night soil and other contents of latrines, cess-pools and
drains;(b)dung and the refuses or useless or offensive material thrown out in consequence of any
process of manufacture, industry or trade; and(c)putrid and putrefying substances;(15-a) "Finance
Commission" means the Finance Commission constituted by the Governor under Article 243-I of
the Constitution of India;(16)"government" means the State Government.(17)"house" means a
building or hut fit for human occupation, whether as a residence or otherwise, having a separate
principal entrance from the common way, and includes any shop, workshop or warehouse or any
building used for garaging or parking buses or as a bus-stand;(18)"hut" means any building which is
constructed principally of wood, mud, leaves, grass or thatch and includes any temporary structure
of whatever size or any small building of whatever material made, which the council may declare to
be a hut for the purposes of this Act;(19)"latrine" includes privy, water-closet and urinal;(20)"localAndhra Pradesh Municipalities Act, 1965

area" includes any town, village, hamlet, bazar, station or other area or any group of the same in the
immediate neighbourhood of one another but does not include a cantonment governed by the
Cantonments Act, 1924; (Central Act 2 of 1924).(21)"municipal officer" means the principal office of
any council;(22)"municipality" means a municipality of such grade as may be declared by the
Government, from time to time, by notification in the Andhra Pradesh Gazette on the basis of its
income and such other criteria as may be prescribed;(22-a) "Nagar Panchayat" means a body
deemed to have been constituted under Section 2-A, for a transitional area specified by the
Governor under clause (42-a);(23)"nuisance" includes any act, omission, place or thing which
causes or is likely to cause injury, danger, annoyance or offence to the sense of sight, smell or
hearing or disturbance to rest or sleep or which is or may be dangerous to life or injurious to health
or property of the public or the people in general who dwell or occupy in the vicinity or persons who
may have occasion to use any public right;(24)"occupier" includes--(a)any person for the time being
paying or liable to pay to the owner the rent or any portion of the rent of the land or building or part
of the same in respect of which the word is used;(b)a rent-free occupant;(25)"ordinary vacancy"
means a vacancy occurring by efflux of time and "ordinary election" means an election held to fill an
ordinary vacancy;(26)"owner" includes--(a)the person for the time being receiving or entitled to
receive, whether on his own account or as agent, trustee, guardian, manager or receiver for another
person or estate for any religious or charitable purposes, the rent or profits of the property in
connection with which the word is used;(b)the person for the time being in charge of the animal or
vehicle in connection with which the word is used;(27)"palanquin" includes tonjons, manchils and
chairs carried by men by means of posts, but not slings or cots used for the conveyance of children
or aged or sick people;(27-a) "population" or population at the last census' with all its grammatical
variations and cognate expressions, means the population as ascertained at the last census of which
all the relevant and necessary figures have been published;(28)"prescribed" means prescribed by the
Government by rules made under this Act;(29)"private street" means any street, road, square, court,
alley, passage or riding path, which is not a public street but does not include a pathway made by the
owner of premises on his own land to secure access to, or the convenient use of, such
premises;(30)"public place" includes any path, garden or ground or any other place to which public
have or are permitted to have access;(31)"public street" means any street, road, square, court, alley,
passage or riding path over which the public have a right of way whether a thoroughfare or not, and
includes-(a)the roadway over any public bridge or causeway;(b)the footway attached to any street
public bridge or causeway; and(c)the drains attached to any such street, public bridge or cause way
and the land, whether covered or not by any pavement, verandah, or other structure which lies on
either side of the roadway upto the boundaries of the adjacent property whether that property is
private property or property belonging to the Government;(32)"public water-course, springs, wells
and tanks" include those used by the public to such an extent as to give a prescriptive right to such
use,(32-a) "qualifying date" in relation to the preparation and publication of every electoral roll
under this Act means the first day of January of the year in which it is so prepared and
published;[(32-b) "Recognised Political Party" and "Registered Political Party" shall have the
meanings respectively assigned to them in the Election Symbols (Reservation and Allotment) Order,
1968, issued by the Election Commission of India under Article 324 of the Constitution of India and
in the registration of Political Parties and Allotment of Symbols Order, 2001, issued by the State
Election Commission under Article 243-K read with Article 243-ZA of the Constitution of India.]
[Inserted by Act No. 28 of 2005, dated 25.10.2005.](33)"reconstruction" of a buildingAndhra Pradesh Municipalities Act, 1965

includes--(a)the re-erection, wholly or partially, of a building after more than one-half of its cubical
contents have been taken down or burnt down or has fallen down whether at one time or not;(b)the
re-erection, wholly or partially, of any building of which an outer wall has been taken down or burnt
down or has fallen down to or within ten feet of the ground, adjoining the lowest storey of the
building, and of any frame building which has so far been taken down or burnt down or has fallen
down, so as to leave only the frame work of the lowest storey;(c)the conversion into a dwelling house
or a place of public worship of any building not originally constructed for human habitation or for
public worship as the case may be, or the conversion into more than one dwelling house of a
building originally constructed as one dwelling house only or the conversion of a dwelling house into
a factory, shop, office or warehouse;(d)the re-conversion into a dwelling house or a place of public
worship or a factory of any building which has been discontinued as, or appropriated for any
purpose other than, a dwelling house or a place of public worship or a factory, as the case may
be.(34)"Regional Director" means the Regional Director of Municipal Administration having
jurisdiction over the Municipality concerned;(35)"residence'-- "reside'-- a person is deemed to have
his residence" or to reside" in any house, if he sometimes uses any portion thereof as a sleeping
apartment; and a person is not deemed to cease to reside in any such house merely because he is
absent from it or has elsewhere another dwelling house in which he resides, if he is at liberty to
return to such house at any time and has not abandoned his intention of returning;(36)"rubbish"
means dust, ashes, broken bricks, mortar, broken glass, and refuse of any kind which is not
filth';(37)"salary" means pay and acting pay or payment by way of commission and includes
exchange, compensation allowances but not allowances for house-rent, conveyance or travelling
expenses;(38)"scheduled castes" means such castes, races or tribes or parts of or, groups within,
such castes, races or tribes as are notified to be Scheduled Castes under Article 341 of the
Constitution of India in relation to the State of Andhra Pradesh;(39)"scheduled tribes" means such
tribes, or tribal communities or parts of, or groups within, such tribes or tribal communities as are
notified to be Scheduled Tribes under Article 342 of the Constitution of India in relation to the State
of Andhra Pradesh;(40)"State Election Commission" means the State Election Commission
constituted in pursuance of Article 243- K of the Constitution of India;(41)"street alignment" means
a line dividing the lands comprised in and forming part of a street from the adjoining
land;(42)"Telangana area" means the territories specified in Sub-section (1) of Section 3 of the
States Reorganisation Act, 1956; (Central Act 37 of 1956);(42-a) "transitional area" or a smaller
urban area' means such area as the Governor may, having regard to the population of the area, the
density of the population therein, the revenue generated for local administration, the percentage of
employment in non-agricultural activities, the economic importance or such other factors as he may
deem fit, specify by public notification for the purposes of this Act, subject to such rules as may be
made in this behalf;(42-b)'Wards Committee' means a Wards Committee constituted under Section
5-B;(43)"watercourse" includes any river, stream or channel whether natural or artificial,(44)"year"
means the financial year.
2A. Constitution of Nagar Panchayats.
(1)Where an area is specified as a transitional area under clause (42-a) of Section 2, a Nagar
Panchayat shall be deemed to have been constituted for such transitional area.(2)The provisions of
this Act shall apply to a Nagar Panchayat deemed to have been constituted under this section as theyAndhra Pradesh Municipalities Act, 1965

apply to a Municipality and to facilitate such application a Nagar Panchayat shall be deemed to be a
Municipality;
Part 2 – Constitution of Municipalities and constitution or
appointment of Municipal Authorities
Chapter 1
Constitution of Municipalities
3. Constitution of Municipalities.
(1)Where a notification is issued specifying an area as a smaller urban area under clause (42a) of
Section 2, a Municipality shall be deemed to have been constituted for such area; Provided that a
Municipality under this clause may not be constituted in such urban area or part thereof as the
Governor may, having regard to the size of the area of the Municipal Services being provided or
proposed to be provided by an industrial establishment in that area and such other factors as he may
deem fit, by public notification, specify to be an Industrial Township.(1A)[ The Government may, by
notification and in accordance with such principles and procedure as may be prescribed in this
behalf,-(a)include within a Municipality any local area or part thereof, in the vicinity of such
Municipality;(b)exclude from a Municipality, any area comprised therein.](2)[ Any resident of a
local area or tax payer of a Municipality, as the case may be, in respect of which any such
notification has been published may, if he desires to object to anything therein contained, submit his
objection in writing to the Government within six weeks from the publication of the notification and
the Government shall take all such objections into consideration.(3)When six weeks from the
publication of the notification have expired, and the Government have considered the objections, if
any, which have been submitted, they may, as the case may be, by notification in the Andhra
Pradesh Gazette, declare to be a Municipality or include in or exclude from a Municipality, the local
area or any portion thereof.] [Substituted by Act No. 31 of 1988, dated 14.9.1988.][***] [Omitted '(4)
Every local area which at the commencement of the Andhra Pradesh Municipal Laws (Amendment)
Act, 1995 has been constituted into a Municipality shall, until the criteria for specifying a
transitional area' and smaller urban area' are prescribed be deemed to have been specified as a
smaller urban area under clause (42-a) of Section 2 and a Municipality of the same grade existing as
at such commencement shall be deemed to have been constituted under this Act: Provided that after
the criteria for specifying a 'transitional area' and 'smaller urban area' are prescribed, if a local area
which is deemed to have been specified as a smaller urban area does not satisfy the criteria therefor,
but satisfies the criteria, for specifying as a 'transitional area', then it shall be competent for the
Governor to specify such local area as a transitional area and thereupon a Nagar Panchayat shall be
deemed to have been constituted for such transitional area.' by Act No. 8 of 2006, dated 2.1.2006.]Andhra Pradesh Municipalities Act, 1965

3A. Abolition of Municipalities.
(1)The Government may, by notification, abolish any municipality to which this Act applies, wherein
the opinion of the Government it is not financially sound or for such other reasons as may be
recorded in writing:-Provided that-(a)the Government shall, before they issue such notification,
communicate to the municipal council the grounds on which they propose to do so, fix a reasonable
period for the municipal council to show cause against proposal and consider its explanations and
objections, if any(b)the notification shall contain a statement of the reasons of the Government and
shall be laid before the Andhra Pradesh Legislative Assembly.(2)From such date as may be specified
in such notification, the provisions of this Act and all notifications, rules, bye-laws, regulations,
orders, directions and powers issued, made or conferred under this Act, shall cease to apply to the
area previously comprised in the municipality; the balance of the municipal fund and all other
property vested in the municipal council and all its liabilities shall stand transferred to the
Government or to such local or other authority or to such officer or other person as they may, by
order, direct.
Chapter 2
Constitution or Appointment of Municipal Authorities
4. The Municipal authorities.
- The municipal authorities charged with carrying out the provisions of this Act are-(a)a council;(b)a
Chairperson;(c)a commissioner.(d)the Wards Committee.
5. Constitution of Municipal Council.
(1)There shall be constituted for each Municipality a body of members to be called the Municipal
Council having authority over the Municipality.(2)The Council shall consist of the following
members, namely:-(i)Such number of elected members as may be notified from time to time by the
Government in the Andhra Pradesh Gazette, in accordance with such principles as may be
prescribed: Provided that the number of members to be elected in respect of each Council existing at
the commencement of the Andhra Pradesh Municipal Laws (Second Amendment) Act, 1994 shall be
as it stood at such commencement until such number is revised by the Government in accordance
with the principles prescribed;(ii)every member of the Legislative Assembly of the State
representing a constituency of which a Municipality or a portion thereof forms part:[Provided that a
Member of the Legislative Assembly representing a Constituency which comprises more than one
Municipality including a part of any Municipality, shall be ex-officio member of one such
Municipality, which he chooses within a period of thirty days from the date of conduct of ordinary
elections to the Municipalities or the date of election as Member of the Legislative Assembly by
notice in writing duly signed by him and delivered to the Commissioner of that Municipality or
Nagar Panchayat and he shall also have the right to speak in and otherwise take part in the
proceedings of any meeting of the other Councils comprised within the Constituency, but shall not
be entitled to vote at any such meeting. The intimation so given shall be final and irrevocable. InAndhra Pradesh Municipalities Act, 1965

default of such intimation within the aforesaid period, the Election Authority shall decide the
Municipality and inform the Member of the Legislative Assembly.] [Substituted by Act No. 5 of
1999, dated 25.3.1999](iii)every member of the House of the People representing a constituency of
which a Municipality or a portion thereof forms part:[Provided that a Member of the House of the
People representing a Constituency which comprises more than one Municipality including a part of
any Municipality, shall be ex-officio member of one such Municipality, which he chooses within a
period of thirty days from the date of conduct of ordinary elections to the Municipalities or the date
of election as Member of the House of the People by notice in writing duly signed by him and
delivered to the Commissioner of that Municipality or Nagar Panchayat and he shall also have the
right to speak in and otherwise take part in the proceedings of any meeting of the other Councils
comprised within the Constituency, but shall not be entitled to vote at any such meeting. The
intimation so given shall be final and irrevocable. In default of such intimation within the aforesaid
period, the Election Authority shall decide the Municipality and inform the Member of the House of
the People.] [Substituted by Act No. 5 of 1999, dated 25.3.1999](iv)every member of the Council of
States registered as an elector within the Municipality ex-officio;(v)persons having special
knowledge or experience in Municipal Administration co-opted by the Municipal Council whose
number shall be one in the case of a Nagar Panchayat two in the case of a Municipality having
population of less than three lakhs and three in the case of a Municipality having a population of
three lakhs or more :Provided that in the case of a Municipality which has more than one co-opted
member, one member shall be a woman; Provided further that the member co-opted under this
clause shall have the right to speak in and otherwise to take part in the meetings of Nagar Panchayat
or the Municipality, as the case may be, but shall not have the right to vote.(vi)one person belonging
to minorities to be co-opted in the prescribed manner by the members specified in clauses (i) to (iv)
from among the persons who are registered voters in the Municipality and who are not less than
twenty-one years of age:Provided that the member co-opted under this clause shall have the right to
speak in and otherwise to take part in the meetings of the Nagar Panchayat or the Municipality, as
the case may be, without the right to vote.;
5A. [ Symbols for direct elections. [Substituted by Act No. 28 of 2005, dated
25.10.2005.]
- The State Election Commission shall, as soon as may be, after the issue of election notification, for
any direct election by the voters in the Municipality, to any office specify by notification published in
the Andhra Pradesh Gazette, the symbols, (including the symbols reserved for recognised political
parties and the symbols, if any, reserved for registered political parties, for exclusive allotment to
contesting candidates set up by such parties), that may be chosen by the candidates contesting at
such an election and the resuictions to which their choice shall be subject.] [Inserted by Act No. 8 of
2006, dated 2.1.2006.]Explanation. - In this section the term "recognised political party" shall have
the meaning assigned to it in the Election Symbols (Reservation and Allotment) Order, 1968, issued
under Article 324 of the Constitution of India.Andhra Pradesh Municipalities Act, 1965

5B. Constitution, powers and functions of the Wards Committees.
(1)In respect of a Municipality having population of three lakhs or more there shall be constituted by
the Commissioner and Director of Municipal Administration, by order, such number of Wards
Committees as may be determined by him, so however, that each Wards Committee shall consist of
not less than five Wards:Provided that in constituing Wards Committees, the Commissioner shall
maintain geographical contiguity as far as possible:Provided further that the Commissioner and
Director of Municipal Administration may in respect of Municipalities having population of less
than three lakhs constitute Wards Committees subject to such conditions and in accordance with
such rules as may be made in this behalf.(2)Each Wards Committee shall consist of the members
elected from the Wards for which the Wards Committee is constituted:Provided that such officers of
the Municipality as the Commissioner may specify shall attend the meetings of the Wards
Committee, and shall have the right to speak in and otherwise to participate in the meetings of the
Wards Committee, but shall not have the right to vote.(3)The Chairperson of the Wards Committee
shall be elected by the members thereof from among themselves in the prescribed manner. He shall
hold office for a period of one year from the date of election and shall be eligible for
re-election.(4)The Chairperson shall cease to hold office if he ceases to be a member of the Wards
Committee. Any casual vacancy in the office of the Chairperson shall be filled by election of another
Chairperson from among the elected members of the Wards Committee as soon as may be after the
occurrence of the vacancy.(5)The powers and functions of the Wards Committee and the manner of
conduct of business at its meetings shall be such as may be prescribed.
6. Incorporation of Council.
- The council constituted under Section 5 shall, by the name of the municipality, be a body
corporate, shall have perpetual succession and a common seal and subject to any restriction or
qualification imposed by this Act or any other law shall be vested with the capacity of suing or being
sued in its corporate name, acquiring, holding and transferring property, entering into contracts and
doing all things necessary for the purposes of this Act.
7. Special provision in the case of newly constituted and reconstituted
councils.
(1)Notwithstanding any other provision in this Act, where a municipality is constituted for the first
time, the Government may appoint a Special Officer to exercise the powers, discharge the duties and
perform the functions of the council, its Chairperson, its Wards Committees, its committees referred
to in Sections 43 and 74, and the Commissioner.(2)The Special Officer shall cause arrangements for
election to be made so that the Chairperson and the elected members may come into officer on such
date as may be specified by the Government by an order made in this behalf;Provided that the
Government may, from time to time, postpone the date [within a period of two years] [Substituted
'within a period of one and half years' by Act No. 19 of 2002, dated 9.8.2002] so specified it, for any
reason, the elections cannot be completed before such date.(2A)Notwithstanding anything
contained in this Act, every Special Officer appointed under Sub-section (1) read with Sub- sectionAndhra Pradesh Municipalities Act, 1965

(6) to any municipality in the State, shall cause arrangements for election to be made to that
municipality so that the elected members and the Chairperson thereof may come into office on such
date as may be specified by the Government by an order made in this behalf;(3)The Special Officer
shall exercise the powers, discharge the duties and perform the functions, of the council until the
elected members come into office, of the Chairperson until a Chairperson is elected, of the wards
committees until the wards committees are constituted of the committees referred to in Sections 43
and 74 until committees thereof have been constituted and of the Commissioner until a
Commissioner has been appointed, as the case may be.(4)x x x[***] [Omitted '(5)' by Act No. 28 of
2005, dated 27.10.2005.](6)The provisions of sub-sections (1) to (5) shall so far as may be, apply to
all cases of reconstitution of councils, unless otherwise provided in this Act.(7)Where the number of
seats on a council is increased by or in consequence of a notification under sub-section (1) of Section
5, the members elected for the additional seats or the members elected in their places at casual
vacancies shall hold office until the date on which the members elected to the original seats at the
ordinary elections immediately preceding will vacate office.
8. Reservation of seats.
(1)In every municipality, out of the total strength of elected members determined under Section 5,
the Government shall, subject to such rules as may be prescribed, by notification, reserve -(a)such
number of seats to the Scheduled Castes and Scheduled Tribes as may be determined by them,
subject to the condition that the number of seats so reserved shall bear, as nearly as may be, the
same proportion to the total number of seats to be filled by direct election to the Municipal Council,
as the population of the Scheduled Castes, or as the case may be, of the Scheduled Tribes in that
Municipality bears to the total population of that Municipality; and such seats may be allotted by
rotation to different Wards in a Municipality;(b)one third of the total number of seats to the
Backward Classes and such seats may be allotted by rotation to different Wards in the
Municipality;(c)not less than one-third of the total number of seats reserved under clauses (a) and
(b) for women belonging to the Scheduled Castes, Scheduled Tribes or as the case may be, the
Backward Classes;(d)not less than one-third (including the number of seats reserved for women
belonging to the Scheduled Castes, Scheduled Tribes and Backward Classes) of the total number of
seats to be filled by direct election to every Municipal Council, for women and such seats may be
allotted by rotation to different Wards in a Municipality.Explanation-I. - In this section the
expression "Scheduled Castes, Scheduled Tribes" shall have the meanings respectively assigned to
them in clause (24) and clause (25) of Article 366 of the Constitution of India.[Explanation-II.
[Added by Act No. 7 of 2012, dated 17.4.2012.] - In this section, the expression "Backward classes"
means any socially and educationally Backward classes of citizens recognized by the Government for
the purpose of clause (4) of Article 15 of the Constitution of India without reference to the
classification but including the creamy layer amongst such Backward classes of citizens.](2)Nothing
in sub-section (1) shall be deemed to prevent women and members of the Scheduled Castes,
Scheduled Tribes or Backward Classes from standing for election to the non-reserved seats in the
Municipality.Andhra Pradesh Municipalities Act, 1965

9. Reservation of Office of members and Chairperson to cease after certain
date.
- The provisions of Sections 8 and 23 relating to the reservation of office of member or the
Chairperson for the Scheduled Castes and Scheduled Tribes shall cease to have effect on the
expiration of the period specified in Article 334 of the Constitution of India.
10. Division of municipalities into wards, etc., for the purpose of election of
members.
(1)For the purpose of election of members to a council, the Government may, after consulting the
council, by notification in the Andhra Pradesh Gazette,--(a)divide the municipality into as many as
single member wards as the number of members notified under Section 5.x x x(b)determine the
wards in which the seats, if any, reserved under sub-section (1) of Section 8 shall be set apart;
and(c)declare for whom such seats are reserved.(2)x x x(3)All the electors of a ward shall be entitled
to vote at an election to any seat in the ward whether reserved or not.(3-A) Where a notification
issued under sub-section (1) results in the material alteration of the existing division of a
municipality into wards, the Government may direct that the alteration shall take effect from the
date of next ordinary elections.(3-B) Where any local area within the jurisdiction of any other local
authority is included in a Municipality under Section 3, the local area shall be added to such
adjoining ward or wards of the municipality, as the Government may direct.(4)When a new ward is
formed, or when an existing ward is abolished, the election authority shall, with the approval of the
Government, determine--(a)the ward which each elected member then on the council shall be
deemed to represent; and(b)the ward or wards in which elections shall be held to fill the vacancies,
if any, in the council.
10A. State Election Commission.
- The preparation of electoral rolls for, and the conduct of elections to, all municipalities in the State
shall be under the super intendancy, direction and control of the State Election Commission.
10B. [ Powers and functions of the State Election Commission. [Inserted by
Act No. 28 of 2005, dated 25.10.2005.]
(1)All elections to the Municipalities shall be held under the supervision and control of the State
Election Commission and for this purpose it shall have power to give such directions as it may deem
necessary to the Commissioner and Director of Municipal Administration, District Collector or any
officer or servant of the Government and the Municipalities so as to ensure efficient conduct of the
elections under this Act.(2)The preparation of electoral rolls for the conduct of all elections under
the Act shall be done under the supervision and control of the State Election Commission.(3)For the
purposes of this section the Government shall provide the State Election Commission with such staff
as may be necessary.(4)On the request of the State Election Commission, the State Government
shall place at the disposal of the Commission such staff of the State Government, Municipalities forAndhra Pradesh Municipalities Act, 1965

the purpose of conduct of elections under this Act.(5)The State Election Commissioner may, subject
to control and revision, delegate his powers to such officers as he may deem necessary.]
11. Preparation and publication of electoral roll for a municipality.
(1)The electoral roll for a municipality shall be prepared and published by the person authroised by
[the State Election Commissioner] [Substituted by Act No. 25. of 1996, dated 5.10.1996] in such
manner by reference to such qualifying date as may be prescribed and the electoral roll for a
municipality shall come into force immediately upon its publication in accordance with the rules
made by the Government in this behalf. The electoral roll for a municipality shall consist of such
part of the electoral roll for the Assembly constituency published under the Representation of the
People Act, 1950 as revised or amended under the said Act, up to qualifying date as relates to
municipality or any portion thereof:Provided that any amendment, transposition or deletion of any
entries in the electoral roll, any inclusion of names in the electoral roll of the Assembly
Constituencies concerned, made by the Electoral Registration Officer under Section 22 or Section
23, as the case may be, of the Representation of the People Act, 1950, upto the date of election
notification, for any election held under this Act, shall be carried out in the electoral roll of the
municipality and any such names included shall be added to the part relating to the concerned
ward.Explanation. - When in the case of any Assembly Constituency there is no district part of the
electoral roll relating to the municipality, all persons whose names are entered in such roll under the
registration area comprising the municipality and whose addresses as entered are situated in the
municipality shall be entitled to be included in the electoral roll for the municipality prepared for
the purposes of this Act.(2)The electoral roll for a municipality,-(a)shall be prepared and published
in the prescribed manner by reference to the qualifying date,-(i)before each ordinary election;
and(ii)before each casual election to fill a casual vacancy in the office of the Chairperson or Member
of Municipality; and(b)shall be prepared and published, in any year, in the prescribed manner, by
reference to the qualifying date, if so, directed by the State Election Commission:Provided that if the
electoral roll is not prepared and published as aforesaid, the validity, or continued operation of the
said electoral roll, shall not thereby be affected.(3)When a municipality has been divided into
Wards, the Electoral Roll for the Municipality shall be divided into separate lists for each
ward.(4)Where after the electoral roll for a municipality or any alteration thereto have been
published under subsection (2), the Municipality is divided into Wards for the first time or the
division of the Municipality into wards is altered or the limits of the Municipality are varied, the
person authorised by the State Election Commission in this behalf shall, as soon as may be after
such division or alteration or variation, as the case may be, in order to give effect to the division of
the Municipality into wards or to the alteration of the variation of the limits, as the case may be,
authorise a re-arrangement and republication of the electoral roll for the Municipality or any part of
such roll, in such manner as the State Election Commission may direct.(5)The electoral roll
published under sub-section (1) or as the case may be under sub-section (4) shall be the electoral
roll for the municipality and it shall remain in force till a fresh electoral roll for the municipality is
published under this Section.(6)Every person whose name appears in that part of the electoral roll
relating to a ward shall subject to the other provisions of this Act, be entitled to vote at any election
which takes place in that ward while the electoral roll remains in force and no person whose name
does not appear in such part of the electoral roll shall vote at any such election.(7)No person shallAndhra Pradesh Municipalities Act, 1965

vote at an election under this Act in more than one ward or more than once in the same ward and if
he does so, all his votes shall be invalid.Explanation. - In this section, the expression "Assembly
Constituency" shall mean a constituency provided by law for the purpose of elections to the Andhra
Pradesh Legislative Assembly.
12. [ Voter identity Cards. [Inserted by Act No. 28 of 2005, dated 25.10.2005.]
- With a view to preventing impersonation of electors, provision may be made by rules made under
this Act, for the production before the Presiding Officer or Poling Officer of a Polling Station by very
such elector, of his identity card before the delivery of a ballot paper or ballot papers to him, if under
the rules made in that behalf under the Registration of Electors Rules, 1960 made under the
Representation of the People Act, 1950, electors of the Legislative Assembly Constituency or
Constituencies in which the Municipality is situated, have been supplied with identity cards with or
without their respective photographs attached thereto.]
13. Qualification of candidates.
- A person shall be qualified for election as a member only if his name appears on the electoral roll
for the municipality and if he is not less than twenty one years of age.
13A. General Disqualification.
- A person shall be disqualified for being chosen as, or for being a member of a Municipality if he is
disqualified by or under any law for the time being in force for the purpose of elections to the
legislature of the State concerned:Provided that no person shall be disqualified on the ground that
he is less than twenty five years of age, if he has attained the age of twenty one years.
13B. Persons having more than two children to be disqualified.
- A person having more than two children shall be disqualified for election or for continuing as
member:Provided that the birth within one year from the date of commencement of the Andhra
Pradesh Municipal Laws (Second Amendment) Act, 1994 (hereinafter in this Section referred to as
the date of such commencement) of an additional child shall not be taken into consideration for the
purposes of this section:Provided further that a person having more than two children (excluding
the child if any born within one year from the date of such commencement) shall not be disqualified
under this section for so long as the number of children he had on the date of such commencement
does not increase:Provided also that the Government may direct that the disqualification in this
section shall not apply in respect of person for reasons to be recorded in writing.
14. Disqualification for election or for holding office as a member.
- A person holding an office of profit under a municipality, the Central Government or the State
Government shall be disqualified for election or for holding office as member.Provided that a personAndhra Pradesh Municipalities Act, 1965

shall not be deemed to hold an office of profit under municipality by reason only that he is a
Chairperson or member of a municipality in the State.Provided further that a village officer who is
not actually performing the functions or discharging the duties as such officer shall not be so
disqualified.
15. Other disqualifications of candidates.
(1)A person who has been sentenced by a criminal court(a)to imprisonment for an offence under the
[Protection of Civil Rights Act, 1955] [Substituted 'Untouchability (Offences) Act, 1955' by Act No.
28 of 2005, dated 25.10.2005.]; (Central Act 22 of 1955).(b)x x x x for any offence other than an
offence of political character or any offence not involving moral delinquency, such sentence not
having been suspended, reversed or the offence pardoned. shall be disqualified for election as a
member while undergoing the sentence and for five years from the date of the expiration
thereof.(2)A person shall be disqualified for election as a member if such person is, on the date fixed
for scrutiny of nomination for election(a)of unsound mind and stands so declared by a competent
court, a deaf-mute or suffering from leprosy;(b)an applicant to be adjudicated an insolvent or
undischarged insolvent;(c)interested in a subsisting lease or contract entered into with or any work
being done for, the council except as a share-holder, other than a director, in a company:Provided
that a person shall not be deemed to have any interest in such contract or work by reason only of his
having a share or interest in(i)any sale or purchase of immovable property or any agreement for the
same; or(ii)any public loan raised by municipality or any security for the payment of money only;
or(iii)any newspaper in which any advertisement relating to the affairs of the council is inserted;
or(iv)the sale to the council of any articles in which he regularly trades, or the purchase from the
council of any articles to a value in either case not exceeding five hundred rupees in the aggregate in
any year during the period of the contract or work;(v)the occasional letting out on hire to the
municipality or hiring from the municipality of any article for an amount not exceeding in the
aggregate in any one year five hundred rupees;(d)employed as a paid legal practitioner on behalf of
the council or as a legal practitioner against the council;(e)an honorary magistrate for the municipal
town;(f)already a member whose term of office as such will not expire before his fresh election can
take effect, or has already been elected a member whose term of office has not yet
commenced;Explanation. - Nothing in this clause shall be construed as disqualifying a sitting
member of a municipality for re-election as member to that municipality;(g)the employee or
employer or the official subordinate or official superior of a member holding office on the said
date;(h)in arrears of any kind due by him otherwise than in a fiduciary capacity to the municipality
upto and inclusive of the previous year, in respect of which a bill or notice has been duly served
upon him and the time if any specified therein for payment, has expired; or(i)dismissed form service
of the Central Government, the State Government, any municipality or any local authority for
misconduct.
15A. [ Disqualification of ground of corrupt practice or election offences.
[Inserted by Act No. 28 of 2005, dated 25.10.2005.]
- Any person who is convicted of any offence punishable under Chapter IX-A of the Indian Penal
Code, 1860, or any person against whom a finding of having indulged in any corrupt practice isAndhra Pradesh Municipalities Act, 1965

recorded in the verdict in an election petition filed under this Act or any person convicted of an
offence punishable under Chapter III of Part VI of this Act, shall be disqualified for contesting in any
election held under this Act, for a period of six years from the date of such conviction or verdict, as
the case may be.]
15B. [ Disqualification for failure to lodge account of election expenses.
[Inserted by Act No. 28 of 2005, dated 25.10.2005.]
- If the State Election Commission is satisfied that a person, -(a)has failed to lodge an account of
election expenses within the time limit prescribed and in the manner required by or under this Act,
and(b)has no good reason or justification for the failure, the State Election Commission shall, after
following the procedure prescribed, by order published in the Andhra Pradesh Gazette, declare
him,-(i)to be ineligible for a period of three years from the date of the said order to contest any
election held for any office under this Act; and(ii)to have ceased to hold office, in case he is elected.]
16. Disqualification of members.
(1)Subject to the provisions of Section 17, a member shall cease to hold his office, if he--(a)is
sentenced by a criminal court to such punishment and for such offence as is described in sub-section
(1) of Section 15;(aa)[ is elected to aWard/Office reserved for Scheduled Castes or Scheduled Tribes
or Backward Classes, and subsequently the community certificate, on the basis of which he is elected
is cancelled, underSection 5oftheAndhra Pradesh (Scheduled Castes, Scheduled Tribes and
Backward Classes) Regulation of issue of Community Certificates Act, 1993;] [Inserted by Act No. 28
of 2005, dated 25.10.2005.](b)becomes of unsound mind and stands so declared by a competent
court;(c)is a deaf-mute or is suffering from leprosy;(d)applies to be adjudicated or is adjudicated an
insolvent;(e)subject to the proviso to clause (c) of Sub-section (2) of Section 15, acquires any interest
in any subsisting contract made with, or work being done for, the council except as a share-holder,
other than a director, in a company;(f)is employed as a paid legal practitioner on behalf of the
council or legal practitioner against the council;(g)is appointed as an officer or servant under this
Act or as an honorary magistrate for the municipal town;(h)accepts employment under or becomes
the official subordinate of any other member;(i)ceases to reside for a period of more than six months
in the municipality or within two kilometers from the outer limits therefrom;(j)fails to pay arrears of
any kind due by him, otherwise than in a fiduciary capacity, to the municipality within three months
after a bill or notice has been served upon him under this Act, or where, in the case of any arrears,
this Act does not require the service of any bill or notice, within three months after a notice
requiring payment of the arrears, which notice it shall be the duty of the Commissioner to serve at
the earliest possible date, has been duly served upon him by the Commissioner;(k)absents himself
from the meetings of the council for a period of three consecutive months reckoned from the date of
the commencement of his term of office, or of the last meeting which he attended, or of his
restoration to office as member under Sub-section (3), as the case may be, or within the said period
less than three ordinary meetings have been held absents himself from three consecutive ordinary
meetings held after the said date:Provided that in the case of a woman member a period of not more
than two months at a time shall be excluded in reckoning the period of absence aforesaid if, for
reasons of physical disability due to advanced stage of pregnancy and of delivery, such memberAndhra Pradesh Municipalities Act, 1965

absents herself from meetings of the council after giving a written intimation to the Commissioner
of the date from which she would be absent:Provided further that no meeting from which a member
absented himself shall be counted against him under this clause if notice of that meeting was not
duly served on him.Provided also that nothing in this clause shall apply to an ex-officio
member.Explanation. - For the purpose of this clause, (i) ordinary meeting' shall mean a meeting
referred to in sub-rule (1) of Rule (2) in Schedule I. (ii) where a meeting other than an ordinary
meeting intervenes between one ordinary meeting and another ordinary meeting, those two
ordinary meetings shall be regarded as being consecutive to each other.(2)Where a person ceases to
be a member under Clause (a) of sub-section (1) or under Section 19, he shall be restored to office
for such portion of the period for which he was elected as may remain unexpired at the date of such
restoration, if and when the sentence or order is annulled on appeal or revision and any person
elected to fill the vacancy in the interim shall on such restoration, vacate office.(3)Where a person
ceases to be a member under clause (k) of sub-section (1), the Commissioner shall at once intimate
the fact in writing to such person and report the same to the council at its next meeting. If such
person applies for restoration to the council on or before the date of its next meeting or within
fifteen days of the receipt by him of such intimation; the council may, at the meeting next after the
receipt of such application, or suo motu restore him to the office of member;Provided that a member
shall not be so restored more than thrice during his term of office.
17. District Judge to decide questions of disqualifications of members.
(1)Where an allegation is made by any voter or authority to the Commissioner in writing that any
person who is elected a a member has not qualified or has become disqualified under Section 13,
Section 13-A and Section 13- B Section 14, Section 15, Section 16 or Section 19 and the
Commissioner has given intimation of such allegation to the member and such member disputes the
correctness of the allegation so made or where any member himself entertains any doubt whether or
not he has become disqualified under any of those sections.(a)such member or any other member
may, within a period of two months from the date on which such intimation is given or doubt is
entertained, as the case may be, and(b)the Commissioner shall, either on the direction of the council
or with the approval of the Government if no such direction is given within a period of two months
from the date of placing of the matter by the Commissioner before the council, apply for a decision
to the District Judge of the district in which the municipality is situated.(1A)x x x(2)The said Judge,
after making such inquiry as he deems necessary, shall determine whether or not such person is
disqualified and his decision shall be final.(3)Pending such decision, the member shall be entitled to
act as if he was not disqualified.
18. Infringement of secrecy of [***] [Omitted 'election' by Act No. 28 of 2005,
dated 25.10.2005.].
- Every polling officer, clerk or other person in attendance at the polling room who, except for some
purpose authorised by law, communicates to any person any information showing directly or
indirectly for which candidate any voter, has voted, and every person who by any improper means
procures any such information, shall be punished with imprisonment of either description which
may extend to six months or with fine or with both.Andhra Pradesh Municipalities Act, 1965

19. Disqualification of persons convicted of [***] [Omitted 'election offences'
by Act No. 28 of 2005, dated 25.10.2005.].
- Every person convicted of an offence punishable under Section 18 or under Chapter IX-A of the
Indian Penal Code shall be disqualified from voting or from being elected in any election to which
this Act applies from holding the office of member for a period of five years from the date of his
conviction or for such shorter period as the court may, by order, determine.
20. Term of office of members and filling of seats.
(1)(a)The term of office of elected members shall, save as otherwise expressly provided in this Act,
be five years from the date appointed by the election authority for the first meeting of the Council;x
x x(b)An ex-officio member shall hold office so long as he continues to be the member of the
Legislative Assembly of the State or as the case may be, of the House of the People.(2)Ordinary
vacancies in the office of the members shall be filled at ordinary elections which shall be completed
before the expiry of the term of office of the members.(3)A member elected at an ordinary election
held after the occurrence of a vacancy shall enter upon office forthwith but shall hold office only as
long as he would have been entitled to hold office if he had been elected before the occurrence of the
vacancy;(4)[ ***] [Omitted by Act No. 28 of 2005, dated 25.10.2005.]
21. [ Casual vacancies of members. [Substituted by Act No. 28 of 2005, dated
25.10.2005.]
(1)Every casual vacancy in the office of an elected member of a municipality shall be reported by the
Commissioner to the State Election Commission within fifteen days from the date of occurrence of
such vacancy and shall be filled within four months from that date.(2)A member elected in a casual
vacancy shall enter upon office forthwith but shall hold office only so long as the member in whose
place he is elected would have been entitled to hold office if the vacancy had not occurred.(3)No
casual election shall be held to a municipality within six months before the date on which the term
of office of its members expires by efflux of time.]
21A. Postponement of casual elections to the office of members and
Chairperson.
- Notwithstanding anything in this Act, or the rules made thereunder, [it shall be lawful for the State
Election Commission] [Substituted 'it shall be lawful for the Government' by Act No. 28 of 2005,
dated 25.10.2005.], to postpone, from time to time by general or special order, and for reasons
specified therein, any election to fill a casual vacancy in the office of a Chairperson or a member of a
municipality:Provided that the total period of such postponement shall in no case exceed one year.Andhra Pradesh Municipalities Act, 1965

22. Procedure when no member is elected.
(1)If at an ordinary or casual election held under Section 20 or Section 21, no member is elected, a
fresh election shall be held on such day as the election authority may fix.(2)The term of office of a
member elected under this section shall expire at the time at which it would have expired if he had
been elected at the ordinary or casual election, as the case may be.
23. Election of Chairperson.
(1)(a)In the case of every municipality, the Chairperson shall be elected by the persons whose names
appear in the electoral roll for the municipality, from among themselves, in the manner prescribed.
A person shall not be qualified to stand for election as Chairperson unless he is not less than
twenty-one years of age.(b)If at any election held under this sub-section no Chairperson is elected, a
fresh election shall be held:Provided that if a member of the Legislative Assembly of the State of of
either House of Parliament is elected as Chairperson, he shall cease to hold the said office of
Chairperson unless within fifteen days from the date of election to the said office, he ceases to be a
member of the Legislative Assembly of the State or as the case may be, of either House of Parliament
and if a Chairperson subsequently becomes a member of the Legislative Assembly of the State or as
the case may be, of either House of Parliament, he shall cease to hold the said office of the
Chairperson unless, within fifteen days from the date on which he so becomes such member he
ceases to be member of Legislative Assembly of the State or as the case may be, of either House of
Parliament:x x xx x x(c)Out of the total number of offices of chairperson in the State, the
Government shall, subject to such rules as may be prescribed, by notification reserve--(i)such
number of offices to the Scheduled Castes and Scheduled Tribes as may be determined subject to the
condition that the number of offices so reserved shall bear, as nearly as may be, the same proportion
to the total number of offices to be filled in the State as the population of the Scheduled Castes or
Scheduled Tribes, as the case may be, in the Municipalities of the State bears to the total population
in the Municipalities of the State and such offices may be allotted by rotation to different
Municipalities in the State;(ii)one-third of the offices to the Backward Classes and such offices may
be allotted by rotation to different municipalities in the State;(iii)not less than one-third of the total
number of offices reserved under clauses (i) and (ii) for women belonging to the Scheduled Castes,
Scheduled Tribes, or as the case may be Backward Classes; and(iv)not less than one-third (including
the number of offices reserved for women belonging to the Scheduled Castes, Scheduled Tribes and
the Backward Classes) of the total number of offices to be filled in the State, for women; and such
offices may be allotted by rotation to different Municipalities in the State.(2)The election of the
Chairperson may be held ordinarily at the same time and in the same place, as the ordinary election
of the members of the municipality.(3)Save as otherwise expressly provided in this Act, the term of
office of the Chairperson who is elected at an ordinary election shall be five years from the date,
appointed by the election authority for the first meeting of the council.x x x(4)Subject to the
provisions of sub-section (5), any casual vacancy in the office of the Chairperson shall be filled at a
casual election and a person elected as Chairperson in any such vacancy shall enter upon office
forthwith and hold office only so long as the person in whose place he is elected would have been
entitled to hold office, if the vacancy had not occurred.(5)No casual vacancy in the office of the
Chairperson shall be filled within six months before the date on which the ordinary election of theAndhra Pradesh Municipalities Act, 1965

Chairperson under sub-section (1) is due.(6)The provisions of Sections 13-A to 19 (both inclusive)
shall, as far as may be, apply in relation to the office of the Chairperson, as they apply in relation to
the office of an elected member.(7)The Chairperson shall, by virtue of his office be a member of the
municipality and shall have all the rights and privileges of an elected member of municipality and he
shall be entitled to vote at all the meetings of the Council.
23A. [ Disqualification on the ground of defection. [Inserted by A.P. Act No. 9
of 1987, dated 6.2.1987]
(1)Subject to the provisions of section 23B and 23C the Mayor or Councillor of a Municipal
Corporation belonging to any political party shall cease to be such Mayor or Councillor -(a)if he has
voluntarily given up his membership of such political party; or(b)if he votes or abstains from voting
in such municipal Corporation contrary to any direction issued by political party to which he
belongs or by any person or authority authorised by it in this behalf, without obtaining, in either
case, the prior permission of such political party, person or authority and such voting or abstention
has not been condoned by such political party, person or authority within fifteen days from the date
of such voting or abstention.(c)if he has been expelled from such political party in accordance with
the procedure established by the constitution, rules or regulations of such political
party.Explanation: - For the purposes of this sub-section the Mayor or elected councillor shall be
deemed to belong to the political party, if any by which he was set up as a candidate for election as
such Mayor or councillor and ex-officio councillor shall be deemed to belong to the political party, if
any, by which he was set up as a candidate for election as a Member of the Legislative Assembly,
House of the people or the Council of States, as the case may be.(2)A Mayor or Councillor who has
been elected as such otherwise than as a candidate set up by a political party may join any political
party within a period of six months and on such joining he shall be deemed to belong to such
political party as if he was set up as a candidate for election as Mayor or Councillor by that political
party for purposes of this section.(3)An intimation that a Mayor or Councillor has ex-facie ceased to
hold office under this section shall be given by the Government.]
23B. [ Disqualification on ground of defection not to apply in case of split.
[Inserted by A.P. Act No. 9 of 1987, dated 6.2.1987]
- Where the Mayor or a councillor makes a claim that he and any other members of his party
constitute the group representing a faction which has arisen as a result of a split in his original
political party and such group consists of not less than one-third of the members of such
party,-(a)he shall not be disqualified under such section (1) of section 23A on the ground-(i)that he
has voluntarily given up his membership of his original political party; or(ii)that he has voted or
abstained from voting in such Municipal Corporation contrary to any direction issued by such party
or by any person or authority authorised by it in that behalf without obtaining the prior permission
of such party, person or authority and such voting or abstention has not been condoned by such
party, person or authority within fifteen days from the date of such voting or abstention; and(b)from
the time of such spilt, such faction shall be deemed to be the political party to which he belongs for
the purpose of sub-section (1) of section 23A and to be his original political party for the purpose ofAndhra Pradesh Municipalities Act, 1965

this section.]
23C. [ Disqualification on ground of defection not to apply in case of merger.
[Inserted by A.P. Act No. 9 of 1987, dated 6.2.1987]
(1)A Mayor or Councillor of a Municipal Corporation shall not section 23A where his political party
merges with another political party and he claims that he and any other members of his original
political party.-(a)have become members of such other political party or, as the case may be, of a
new political party formed by such merger;or(b)have not accepted the merger and opted to function
as a separate group and from the time of such merger, such other political party or group, as the
case may be, shall be deemed to be the political party to which he belongs for the purpose of
sub-section (1) of section 23A and to be his original political party for the purposes of this
sub-section.(2)For the purposes of subsection (1) of section 23A, the merger of the original political
party of a Mayor or Councillor shall be deemed to have taken place if, and only if, not less than
two-thirds of the members of the party concerned have agreed to such merger.Explanation. - For the
Purposes of section 23B, and 23C, 'Original political party' in relation to a Mayor or Councillor
means the Political party to which he belongs for the purposes of section 23A.]
23D. [ Authority to decide Questions of disqualification of Councillors and
Mayor. [Inserted by A.P. Act No. 9 of 1987, dated 6.2.1987]
(1)Where an allegation is made by any voter or authority to the Commissioner in writing that any
person who is elected as a councillor has not qualified or has become disqualified under section 21,
section 22 or section 23 and the Commissioner has given intimation of such allegation to the
councillor and such councillor disputes the correctness of the allegation so made or where any
councillor himself entertains any doubt whether or not he has become disqualified under any of
those sections,-(a)such councillor or any other councillor may, within a period of two months form
the date on which such intimation is given or doubt is entertained, as the case may be, and(b)the
Commissioner shall, either on the direction of the councillor with the approval of the Government if
no such direction is given within a period of two months from the date of placing of the matter by
the Commissioner before the council, apply for a decision to the Chief Judge, City Civil Court,
Hyderabad.(2)Where an intimation is given by the Government under sub-section (3) of section 23A
Councillor, such a person may, within a period of two months from the date on which such
intimation is given, apply to the Chief Judge, City Civil Court, Hyderabad for a decision on the
correctness of the fact so intimated.(3)The said judge, after making such inquiry as he deems
necessary, shall determine whether or not such person is disqualified and his decision shall be
final.(4)Pending such decision, the councillor shall be entitled to act as if he was not disqualified.]
24. [ Reservation of Offices of Chairpersons. [Inserted by Act No. 16 of 2009,
dated 19.9.2009.]
- Out of the total number of offices of Chairpersons in the State, the Government shall, subject to
such rules as may be prescribed, reserve-(i)such number of offices to the Scheduled Castes andAndhra Pradesh Municipalities Act, 1965

Scheduled Tribes as may be determined subject to the condition that the number of offices so
reserved shall bear, as nearly as may be, the same proportion to the total number of offices to be
filled in the State as the population of the Scheduled Castes or Scheduled Tribes, as the case may be,
in the Municipalities of the State bears to the total population of the Municipalities in the State and
such offices may be allotted by rotation to different Municipalities in the State;(ii)one-third of the
Offices to the Backward Classes and such offices may be allotted by rotation to the different
Municipalities in the State;(iii)not less than one-third of the total number of offices reserved under
clauses (i) and (ii) above for women belonging to the Scheduled Castes and Scheduled Tribes, or as
the case may be, Backward Classes; and(iv)not less than one-third (including the number of offices
reserved for women belonging to Scheduled Castes and Scheduled Tribes and the Backward Classes)
of the total number of offices to be filled in the State, for women and such offices may be allotted by
rotation to different Municipalities in the State.]
25. Election of Vice-Chairperson.
(1)Every council shall elect one of its elected members to be its Vice-Chairperson within fifteen days
from the date of election of the Chairperson, in the manner prescribed.x x x(2)The ex-officio
members other than the ex-officio members specified in Clause (v) of sub-section (2) of Section 5
shall be entitled to participate in the meeting convened for the election of the Vice-Chairperson.(3)If
at any election held under sub-section (1) no Vice-Chairperson is elected, a fresh election shall be
held for electing a Vice-Chairperson.(4)The Vice-Chairperson shall be deemed to have assumed
office on his being declared as such.
26. Cessation of office of Chairperson and Vice-Chairperson.
- The Chairperson shall cease to hold office as such, on his becoming disqualified for holding the
office or on his removal from office or on the expiry of his term or on his otherwise ceasing to be
Chairperson: and the Vice- Chairperson shall cease to hold office as such, on the expiry of the term
of office as a member or his otherwise ceasing to be a member.
26A. Procedure when office of Chairperson is vacant.
(1)Where the officer of the Chairperson falls vacant, the Vice-Chairperson shall perform the
functions of the Chairperson until a new Chairperson is elected. Immediately on the occurrence of
such vacancy, the Commissioner shall intimate the fact to the election authority and the election
authority shall arrange the election of the Chairperson.(2)Where the office of the Chairperson is
vacant and there is either a vacancy in the office of the Vice- Chairperson, or the Vice- Chairperson
has been continuously absent from jurisdiction for more than fifteen days or is incapacitated for
more than fifteen days, the District Collector in the case of a special selection grade municipality or
the Revenue Divisional Officer, in the case of any other municipality, shall, notwithstanding
anything in this Act or in the rules and notifications issued thereunder, exercise the powers and
perform the functions of the Chairperson until a new Chairperson or Vice-Chairperson is elected, or
the Vice-Chairperson returns to jurisdiction or recovers from incapacity.Andhra Pradesh Municipalities Act, 1965

27. Notification of elections.
- All elections of members Chairperson and Vie-Chairperson shall, as soon as may be, be notified in
the prescribed manner.
28. Requisitioning of premises and vehicles for election purposes.
(1)If it appears to the Government that in connection with any election held under this Act:-(a)any
premises are needed or are likely to be needed for the purpose of being used as a polling station or
for the storage of ballor boxes after a poll has been taken, or(b)any vehicle is needed or is likely to be
needed for the purpose of transport of personnel or ballot boxes to or from any polling station, or
transport of members of the police force for maintaining order during the conduct of such election,
or transport of any officer or other person for performance of any duties in connection with such
election, the Government may, by order in writing, requisition such premises or such vehicle, as the
case may be, and may make such further orders as may appear to them to be necessary or expedient,
in connection with the requisitioning;Provided that no vehicle which is being lawfully used by a
candidate or his agent for any purpose connected with the election of such candidate shall be
requisitioned under this sub-section until the completion of the poll at such election.(2)The
requisition shall be effected by an order in writing addressed to the person deemed by the
Government to be the owner or person in possession of the property, and such order shall be served
in the prescribed manner on the person to whom it is addressed.(3)Whenever any property is
requisitioned under sub-section (1), the period of such requisition shall not extend beyond the
period for which such property is required for any of the purposes mentioned in that
sub-section.Explanation. - For the purpose of this section, premises' means any land, building, part
of a building and include a hut, shed or other structure or any part thereof; and vehicle' means any
vehicle used or capable of being used, for the purpose of road transport, whether propelled by
mechanical power or otherwise.
28A. Payment of Compensation.
(1)Whenever in pursuance of Section 28, the Government requisition any premises, there shall be
paid to the person interested compensation the amount of which shall be determined by taking into
consideration the following namely:(i)the rent payable in respect of the premises or if no rent is so
payable, the rent payable for similar premises in the locality:(ii)if in consequence of the requisition
of the premises, the person interested is compelled to change his residence or place of business, the
reasonable expenses, if any, incidental to such change:Provided that where any person interested,
being aggrieved by the amount of compensation so determined, make an application within the
prescribed time to the Government for referring the matter to an arbitrator, the amount of
compensation to be paid shall be such as the arbitrator appointed in this behalf by the Government
may determine;Provided further that where there is any dispute as to the title to receive the
compensation or as to the appointment of the amount of compensation, it shall be referred by the
Government to an arbitrator appointed in this behalf by the Government for determination and
shall be determined in accordance with the decision of such arbitrator.Explanation. - In this
sub-section, the expression person interested' means the person who was in actual possession of theAndhra Pradesh Municipalities Act, 1965

premises requisitioned under Section 28 immediately before the requisition, or where no person
was in such actual possession, the owner of such premises.(2)Whenever in pursuance of Section 28,
the Government requisition any vehicle, there shall be paid to the owner thereof compensation, the
amount of which shall be determined by the Government on the basis of the fares or rates prevailing
in the locality for the hire of such vehicle;Provided that where the owner of such vehicle, being
aggrieved by the amount of compensation so determined, makes an application within the
prescribed time to the Government for referring the matter to an arbitrator the amount of
compensation to be paid shall be such as the arbitrator appointed in this behalf by the Government
may determine:Provided further that where immediately before the requisitioning, the vehicle was
by virtue of hire purchase agreement, in the possession of a person, other than the owner, the
amount determined under this sub-section as the total compensation payable in respect of the
requisition shall be apportioned between that person and the owner in such manner as they may
agree upon and in default of agreement, in such manner as an arbitrator appointed by the
Government in this behalf may decide.
28B. Power to obtain information.
- The Government may, with a view to requisitioning any property under Section 28 or determining
the compensation payable under Section 28-A, by order, require any person to furnish to such
authority as may be specified in the order, such information in his possession relating to such
property as may be so specified.
28C. Eviction from requisitioned premises.
(1)Any person remaining in possession of any requisitioned premises in contravention of any order
made under 28 may be summarily evicted from the premises by any officer empowered by the
Government in this behalf.(2)Any officer so empowered may, after giving to any woman not
appearing in public, reasonable warning and facility to withdraw, remove or open any lock or bolt or
break open any door of any building or do any other act necessary for effecting such eviction.
28D. Penalty for contravention of any order regarding requisitioning.
- If any person contravenes any order made under Section 28 or Section 28-B, he shall be
punishable with imprisonment for a term which may extend to one year or with fine or with both,
28E. Voting machines at elections.
- Notwithstanding anything contained in this Act or the rules made thereunder, the giving and
recording of votes by voting machines in such manner as may be prescribed, may be adopted in such
ward or wards as the State Election Commission may, having regard to the circumstances of each
case, specify.Explanation. - For the purpose of this section, 'voting machine' means any machine or
apparatus whether operated electronically or otherwise used for giving or recording of votes and any
reference to a ballot box or ballot paper in this Act or the rules made thereunder shall, save asAndhra Pradesh Municipalities Act, 1965

otherwise provided, be construed as including a reference to such voting machine wherever such
voting machine is used at any election.
29. Appointment of Commissioner.
(1)The Government shall appoint a Commissioner for a municipality who shall be the executive
authority of that municipality.Provided that person holding office as Commissioner or Executive
Officer, as the case may be, of a municipality immediately before the commencement of this Act,
shall be, deemed to have been appointed by the Government as Commissioner under this
sub-section.(2)In the case of any municipality where it is considered necessary to do so, the
Government may also appoint a Deputy Commissioner to assist the Commissioner.(3)The
classification and methods, recruitment, conditions of service including pay, allowances and
disciplinary conduct of the officers appointed under sub-sections (1) and (2) shall be subject to the
rules made under Section 72:Provided that the conditions of service, including pay and allowances
of a person holding office as Commissioner or Executive Officer, as the case may be, of a
municipality immediately before the commencement of this Act shall not be varied to his
disadvantage.(4)The Government shall pay, out of the Consolidated Fund of the State, the salaries,
allowances, leave allowances, pension and contributions, if any, towards the provident fund, or
provident-cum-pension fund of the officers appointed under Sub-section (1) or sub-section (2), as
the case may be.(5)The withdrawal of any officer appointed under Sub-section (1) or Sub-section (2)
from any municipality shall be governed by the provisions of Sub-section (2) of Section 72.
Chapter 3
Powers and Functions of the Municipal Authorities
30. Vesting of municipal administration in the council.
- Subject to the provisions of this Act, the municipal administration shall vest in the Council, and for
this purpose the council shall exercise such powers and perform such functions as may be conferred
upon it by or under this Act:Provided that the council shall not be entitled to exercise the powers or
to perform the functions which are expressly assigned by or under this Act or any other law to the
Chairperson or the Commissioner.
31. Council's power to call for records.
- The council may, at any time, require the Chairperson to produce any document which is in his
custody. The Chairperson shall comply with every such requisition unless in his opinion compliance
therewith would be prejudicial to the interests of the council or of the public, in which case he shall
make a declaration in writing to that effect.Andhra Pradesh Municipalities Act, 1965

31A. Appointment of Committees.
(1)A Council may constitute committees or may appoint individual members to enquire into and
report or advise on any matters which it may refer to them and such committees or individuals shall
have power to call for such records as are deemed necessary for examining the matters referred to
them. In particular the council may constitute committees consisting of the Chairperson, the
Commissioner and not less than three but not more than seven members, chosen in this behalf by
the council from among its elected members in respect of matters pertaining to formulation review
and general superintendence of development programmes relating to education, health, sanitation,
water supply, drainage and welfare of the Scheduled Castes, Scheduled Tribes, Backward Classes,
Women and children.(2)It shall be lawful for the council, from time to time, by a resolution
supported by not less than one-half of the sanctioned strength of the council to appoint as members
of any committee any persons who are not members but who may in the opinion of such council
possess special qualifications for serving on such committee. But the number of persons so
appointed on any committee shall not exceed one-third of the total number of members of such
committee. All the provisions of this Act relating to the powers, duties, liabilities and
disqualifications and disabilities of members shall, save as regards the disqualification on the
ground of residence, be applicable, so far as may be, to such persons.(3)The term of the members of
the committees constituted under sub-section (1) and of those constituted under Sections 43 and 74
shall be one year, and the retiring members shall be eligible for re-appointment or reelection as the
case may be to such committees.
32. Rules and Regulations for proceedings of Council.
- The council shall observe the rules in Schedule I and may make regulations not inconsistent
therewith or with other provisions of this Act or any rules made by the Government in regard to the
following matters, namely:-(a)the time and place of its meetings;(b)the manner in which notice
thereof shall be given;(c)the preservation of order and the conduct of proceedings at meetings, and
the powers which the Chairperson may exercise for the purpose of enforcing his decisions on points
of order;(d)the transaction of business by any committee constituted under Section 31-A;(e)the
persons by whom receipts may be granted for money paid to the council; and(f)all other similar
matters.
33. Acts of council etc., not to be invalidated by defect in constitution,
vacancy etc.
- No act of a council or of any person acting as the Chairperson, Vice-Chairperson, or member shall
be deemed to be invalid by reason only of a defect in the constitution of the municipality on the
ground that the Chairperson, Vice-Chairperson or the member was not entitled to hold or continue
in such office by reason of any disqualification or by reason of any irregularity or illegality in his
election or by reason of such act having been done during the period of any vacancy in the office of
the Chairperson, Vice-Chairperson or member.Andhra Pradesh Municipalities Act, 1965

34. Council to submit annual administration report to Government and to
furnish information relating to its plan schemes to Zilla Parishad.
(1)As soon as may be after the first day of April, in every year, and not later than such date as may be
fixed by the Government through the District Collector a report on the administration of the
municipality during the preceding year in such form and with such details as the Government may
direct. If the District Collector makes any remarks on the report, such remarks shall be forwarded to
the council and the council shall be entitled, within such time as the Government may fix, to offer or
make such explanations or observations as the council thinks fit.(2)The Commissioner shall prepare
the report and submit it to the council. The council shall consider the report and forward it to the
Government with its resolution thereon, if any.(3)The report and the resolutions thereon, if any,
shall be published in the manner as the council, subject to the approval of the Government, may
direct.(4)The council shall furnish to the Zilla Parishad concerned such information relating to the
plan schemes of the municipality as may, from time to time, be required by the Zilla Parishad.
35. Vesting of public streets and appurtenances in the council.
(1)All public streets in any municipality with the pavements, stones and other materials thereof and
all works, materials and other things provided for such streets, all sewers, drains, drainage works,
tunnels and culverts, whether made at the cost of the municipal fund or otherwise, in, along-side or
under any street, whether public or private, and all works, materials and things appertaining thereto
shall vest in the council.(2)The Government may, after consultation with the council, by notification
in the Andhra Pradesh Gazette, withdraw any such street, sewer, drain, drainage work, tunnel or
culvert from the control of the council.
36. Duty of council in respect of public streets withdrawn from its control.
- Where any public street has ben withdrawn from the control of a council under sub-section (2) of
Section 35 and placed under the control of the Highways Department of the Government, it shall be
the duty of the Council to provide, at the cost of the municipal funds, to such extent as the
Government may by general or special order direct:-(a)for the lighting, watering, scavenging, and
drainage of such street;(b)for the provision, maintenance and repair of the water-supply mains,
drains and sewers in, along-side or under such street;(c)for the provision, maintenance and repair of
foot ways attached to such street:Provided that where, in the discharge of such duties, it is necessary
for the council to open and break up the soil or pavement of any such street, the council shall obtain
the previous consent of such officer of the Highways Department as the Government may, by
general or special order, specify;Provided further that in cases of emergency the council may,
without such consent, open and break up the soil or pavement of any such street, but shall, as far as
practicable, restore such soil or pavement to the condition in which it was immediately before it was
opened and broken up and a report of the action so taken and the reasons therefor shall be sent
forthwith to the officer specified under the foregoing proviso.Andhra Pradesh Municipalities Act, 1965

37. Vacant lands belonging to Government situtated in the municipality to be
in the possession or under the control of the council.
(1)On and from the date of the commencement of this Act, all vacant lands belonging to or under the
control of the Government situated within the local limits of a municipality shall, subject to the
provisions of Sub-section (2) and (3) and to such conditions as may be prescribed, be deemed to be
in the possession or under the control of the council concerned for purposes of this Act.Explanation.
- For the purpose of this section "vacant land" includes a poramboke, donka or kunta.(2)The council
shall keep all such vacant lands free from encumbrances and shall restore the possession or control
of any such land to the Government free of cost whenever it is required by the Government for their
use for any public purpose or for purpose of alienation to any person or local authority.(3)The
council shall not(a)construct or permit the construction of any building or other structure on any
such vacant land:(b)use or permit the use of such vacant land for any permanent
purpose;(c)alienate such vacant land to any third party, unless the prior permission of the
Government is obtained by the council therefor, after furnishing such information as the
Government may require, including the usefulness of the land or any housing scheme;
38. Collected sewage, etc., to belong to council.
- All rubbish and filth and other matter collected by or on behalf of a council under this Act shall
belong to the Council.
39. Power of Board of Revenue to transfer control of endowments to council.
(1)Subject to the control of the Government, the Board of Revenue may, by notification in the
A.P.Gazette, with the consent of a council, make over to the council the management and
superintendence of any Charitable Endowment in respect of which powers and duties attached to
the Board of Revenue under the provisions of the Andhra Pradesh (Andhra Area) Endowments and
Escheats Regulation, 1817 or any other law similar thereto for the time being in force, and thereupon
all powers and duties which attach to the Board of Revenue in respect thereof shall attach to the
council as if it had been specially named in the said Regulation or law, and the council shall manage
and superintend such endowment.(2)The Board of Revenue may, of its own motion and shall on a
direction from the Government, and after consultation with the council, by notification in the
Andhra Pradesh Gazette, resume the management and superintendence of any endowment made
over to a council under sub-section (1), and upon such resumption, all the powers and duties
attaching to the council in respect of the endowment shall cease and determine.
40. Acceptance of donations, endowment or trust by the council.
- The council may accept any donations, endowment or trust for the furtherance of any purpose for
which the municipal fund may be applied.Andhra Pradesh Municipalities Act, 1965

41. Subjects not provided for by this Act.
- The Government may, subject to such conditions as they may deem fit to impose and with the
consent of council, transfer to the council the management of any institution or the execution of any
work not provided for by this Act, and it shall thereupon be lawful for the council to undertake such
management or execution:Provided that in every such case, the funds required for such
management or execution, shall be placed at the disposal of the council by the Government.
42. Procedure for acquisition of immovable property under the Land
Acquisition Act, 1894.
(1)Any immovable property which any municipal authority authorised by this Act to acquire may be
acquired under the provisions of the Land Acquisition Act 1894, (Central Act 1 of 1894), and, on
payment of the compensation awarded under the said Act in respect of such property and of any
other charges incurred in acquiring it, the said property shall vest in council.(2)where a municipal
authority proposes to acquire any immovable property otherwise than under the provisions of Land
Acquisition Act, 1894, it shall obtain the previous approval of the District Collector therefor. While
according his approval, the District Collector shall determine the value at which the property is to be
acquired and every such acquisition shall be subject to the previous sanction of the Government.
43. Authority to contract and contractual power of persons appointed by
Government.
(1)The power of making, on behalf of the council, any contract where of the value or amount does
not exceed the monetary limits specified in column (2) of the Table below, shall be exercised by the
authority specified in column (3) thereof.(2)The power of making every contract whereof the value
or amount exceeds the monetary limits mentioned in Sub-section (1) shall be exercised by the
council concerned).(3)Notwithstanding anything in the foregoing sub-sections, any person
appointed by the Government to carry any work into execution on behalf of a council may, subject to
such control as the Government may prescribe, make such contracts as are necessary for the
purpose of carrying such work into execution to the extent of the sum provided for such work; and
the council shall pay to the person so appointed such sums as may be required for the said purpose
to the extent aforesaid.x x x x
44. Rules regarding the conditions on which contracts may be made.
- The power conferred by Section 43 to make or sanction contracts shall be subject to such rules as
may be prescribed in regard to the conditions on which, and the mode in which contracts may be
made or sanctioned by or on behalf of the council.Andhra Pradesh Municipalities Act, 1965

45. Mode of executing contracts.
(1)Every contract made by or on behalf of, a council whereof the value or amount exceeds one
thousand rupees shall be in writing and, except in the case of contracts made under the provisions of
Sub-section (3) of Section 43, shall be signed by the Commissioner.(2)A contract executed or made
otherwise than in conformity with the provisions of this section or of Section 43 and of the rules
referred to in Section 44 shall not be binding on the council.
46. Power of Council to pass motion of no confidence in ....................
Vice-Chairperson.
(1)A motion expressing want of confidence in the Vice-Chairperson may be made in accordance with
the procedure laid down in the following sub-sections.(2)A written notice of intention to make the
motion, in such form as may be specified by the Government, signed by such number of members,
chairperson and the Ex-officio members as shall constitute not less than one half of the sanctioned
strength of the councils, together with a copy of the proposed motion, shall be delivered in person by
any two of the elected members signing the notice to the District Collector in the case of special or
selection grade municipality, or to the Revenue Divisional Officer in the case of any other
municipality.Explanation. - For the removal of doubts, it is hereby declared that for the purpose of
this section the expression sanctioned strength of the council' shall mean the total number of
[members, chairperson and the ex-officio members] [Substituted 'members including the ex-officio
members' by Act No. 10 of 2001, dated 10.4.2001].(3)The District Collector or the Revenue
Divisional Officer as the case may be, shall then convene a meeting for the consideration of the
motion at municipal office on the date appointed by him which shall not be later than thirty days
from the date on which the notice under Sub-section (2) was delivered to him. He shall give to the
members, chairperson and the Ex-officio members notice of less than fifteen clear days of such
meeting.Explanation. - In computing the period of thirty days specified in this sub-section, the
period during which a stay order, if any, issued by a competent court on a petition filed against a
notice under sub-section (2) is in force shall be excluded.(4)The District Collector or the Revenue
Divisional Officer as the case may be, shall preside at such meeting. If within half an hour after the
time appointed for the meeting, the District Collector or Revenue Divisional Officer as the case may
be, is not present to preside at the meeting, the meeting shall stand adjourned to a date to be
appointed by him under sub-section (5).(5)If the District Collector or the Revenue Divisional
Officer, as the case may be, is unable to preside at the meeting due to the circumstances beyond his
control he may, after recording his reasons in writing, adjourn the meeting to such other date as he
may appoint. The date so appointed by him shall not be later than fifteen days from the date fixed
for the meeting under sub-section (3). Notice of not less than three clear days shall be given by him
to the members members, chairperson and the Ex-officio members of the adjourned
meeting.(6)Save as provided in sub-sections (4) and (5), a meeting convened for the purpose of
considering a motion under this section shall not, for any reason, be adjourned.(7)As soon as the
meeting convened under this section commences, the District Collector or the Revenue Divisional
Officer as the case may be, shall read to the council the motion for the consideration of which the
meeting has been convened, and declare it to be open for debate.(8)No debate of any motion under
this section shall be adjourned.(9)Such debate shall automatically terminate on the expiration ofAndhra Pradesh Municipalities Act, 1965

two hours from the time appointed for the commencement of the meeting if it is not concluded
earlier. On the conclusion of the debate or on the expiration of the said period of two hours,
whichever is earlier, the motion shall be put to vote.(10)The District Collector or the Revenue
Divisional Officer as the case may be, shall not speak on the merits of the motion and he shall not be
entitled to vote thereon.(11)A copy of the minutes of the meeting together with a copy of the motion
and the result of the voting thereon shall be forwarded immediately on the termination of the
meeting by the District Collector or the Revenue Divisional Officer as the case may be, to the
Government.(12)If the motion is carried with the support of majority of the strength of the members
including the ex-officio members as on the date of the meeting, the District Collector or the Revenue
Divisional Officer as the case may be, shall forthwith publish the result in the notice board at the
municipal office and on such publication the Vice-Chairperson, shall be deemed to have been
removed with immediate effect. Any such result be final and shall not be questioned in any court of
law.(13)If the motion is not carried by such a majority as aforesaid, or if the meeting could not be
held for want of a quorum, no notice of any subsequent motion expressing want of confidence in the
same Vice-Chairperson shall be made until after the expiration of one year from the date of the
meeting.(14)No notice of a motion under this section shall be made within one year of the
assumption of office by a Vice-Chairperson.
47. Powers and functions of the Chairperson.
(1)The Chairperson shall(a)make arrangements for the election of the Vice-Chairperson;(b)convene
the meeting of the council;(c)refer any resolution of the council for its re-consideration which, in his
opinion is in excess of the powers of the council or inconsistent with any law; and(d)exercise all the
powers and perform all the functions specifically conferred or imposed on the Chairperson by this
Act.(2)All official correspondence between the council and the Government or the Heads of the
Departments shall be conducted in the name of the Chairperson.
48. Power of Chairperson to incur contingent expenditure.
(1)The Chairperson may incur in each case contingent expenditure incidental to the municipal
administration--(i)in the case of third grade or second grade municipality, not exceeding one
thousand and five hundred rupees.(ii)in the case of first grade or special grade or selection grade
municipality, not exceeding three thousand rupees.(2)He shall report the expenditure so incurred
and the reasons therefor to the council at its next meeting;Provided that no such expenditure shall
be incurred if there is no provision available to meet the expenditure under the relevant head of
account in the budget framed by the council with the modifications, if any, made by the Government
or where such expenditure was expressly prohibited by the council.
49. Emergency powers of the Chairperson.
- The Chairperson may, in cases of emergency, direct the execution of any work or the doing of any
act which would ordinarily require the sanction of the council and the immediate execution or doing
of which is, in his opinion, necessary for the service or safety of the public and may direct that the
expense of executing such work or doing such act shall be paid from the municipal fund;ProvidedAndhra Pradesh Municipalities Act, 1965

that-(a)he shall not act under this Section in contravention of any resolution of the council
prohibiting the execution of any particular act; and(b)he shall report the action taken under this
Section and the reasons therefor to the council at its next meeting;
50. Delegation and devolution of functions of Chairperson.
(1)The Chairperson may, by an order in writing, delegate any of his functions to the
Vice-Chairperson and any of his administrative functions to the Commissioner;Provided that he
shall not delegate any functions which the council expressly forbids him to delegate.(2)If the
Chairperson has been continuously absent from jurisdiction for more than ten days or incapacitated
for more than ten days, his functions shall, during such absence or incapacity, devolve on the
Vice-Chairperson.Provided that where the absence from jurisdiction of the Chairperson is within the
State of Andhra Pradesh, and is on business connected with the municipality, the Chair person's
functions shall not, except to the extent, if any, to which functions have been delegated by him under
sub-section (1), devolve on the Vice-Chairperson.(3)If the Vice-Chairperson has been continuously
absent from jurisdiction for more than ten days or is incapacitated for more than ten days or if the
office of Vice-Chairperson is vacant the Chairperson may by an order in writing, delegate any of his
functions to any elected member;Provided that -(i)when an order of delegation made under this
sub-section is in force, no further order of delegation of any functions shall be made in favour of any
member other than the member in whose favour the order in force was made;(ii)no delegation
under this sub-section shall, without the special sanction of the council, be made for any period
exceeding in the aggregate ninety days in any year; and(iii)every order made under this sub-section
shall be communicated forthwith to the council and the Regional Director.(4)The exercise of powers
or performance of any functions delegated under sub-sections (1) and (3) shall be subject to such
restrictions, limitations and conditions, if any, as may be laid down by the Chairperson and shall
also be subject to his control and revision. The Chairperson shall also have power to control and
revise the exercise of powers or performance of any function devolving on the Vice-Chairperson
under sub-section (2).
51. Presidency of council and Chairperson.
(1)(a)Every meeting of the council shall be presided over by the Chairperson; in his absence by the
Vice- Chairperson and in the absence of both the Chairperson and the Vice-Chairperson by a
member included in the panel of temporary chairmen prepared in the manner specified in clause
(b). Where no such temporary Chairperson is also present and if there is quorum, one of its
members may be chosen by the meeting to preside for the occasion.(b)At the first meeting in every
year, of the council, the Chairperson may nominate from amongst the elected members a panel of
not more than four temporary chairmen, any one of whom may preside at any meeting of the council
in the absence of the Chairperson and the Vice-Chairperson in the order in which they are
nominated in the panel. The panel of temporary chairmen so nominated shall remain in force until a
new panel of temporary chairmen is nominated.(2)The Chairperson shall preserve order and shall
decide all points of order arising at or in connection with meetings. There shall be no discussion on
any point of order and the decision of the Chairperson on any point of order shall, save as otherwise
expressly provided in this Act, be final.(3)(a)Where the conduct of a member is in the opinion of theAndhra Pradesh Municipalities Act, 1965

Chairperson disorderly, he may direct that such member shall withdraw from the meeting of the
council and such member shall thereupon withdraw and shall not be allowed to attend for the
remainder of the day's meeting.(b)If any member who has been ordered to withdraw, continues to
remain in the meeting, the Chairperson may take steps to cause him to be removed.(4)The
Chairperson may, in the case of grave disorder arising in any meeting, suspend the meting for a
period not exceeding three days.Explanation. - Chairperson in this section and Section 52 includes
the Vice-Chairperson, temporary Chairperson or member presiding for the occasion.(5)(a)The
Chairperson may, if he deems it necessary, name a member who disregards the authority of the
chair or abuses the rules, bye-laws or regulations of the council by persistently and wilfully
obstructing the bussines thereof.(b)If a member is so named by the Chairperson, the Chairperson
shall at a meeting of the council forthwith put the question that the member (naming him) be
suspended from functioning in the council as such for a period not exceeding three consecutive
months reckoned from the date of that meeting. Provided that the council may, at any time resolve
that such suspension be terminated.(c)A member suspended under this sub-section shall forthwith
withdraw from the precincts of the council.
52. Member when to abstain from taking part in discussion and voting.
(1)No member shall vote on, or take part in discussion of any question coming up for consideration
at a meeting of the council, if the question is one in which, apart form its general application to the
public, he has personal interest or he or his partner has any direct or indirect pecuniary
interest.(2)The Chairperson may prohibit any member from voting or taking part in the discussion
of any matter in which he, for reasons to be recorded in writing, believes such member to have such
interest, or he may require such member to absent himself during the discussion.(3)Such member
may challenge the decision of the Chairperson who shall, thereupon, put the question to the meeting
and the decision of the meeting shall be final.(4)If any member present at the meeting believes that
the Chairperson has any such personal or pecuniary interest in any matter under discussion, the
Chairperson shall, if a motion to that effect be carried, absent himself from the meeting during
discussion.(5)The member concerned shall not be entitled to vote on the question refereed to in
sub-section (3) and the Chairperson concerned shall not be entitled to vote on the motion referred
to in sub-section (4).
53. Duties and powers of individual members.
(1)Any member may call the attention of the Chairperson to any neglect in the execution of
municipal work, to any waste of municipal property or to the wants of any locality and may suggest
any improvements which may appear desirable.(2)Every member shall have the right to move
resolutions and to interpellate the Chairperson on matters connected with municipal administration
subject to such rules as may be made by the Government in this behalf.(3)Every member shall have
access during office hours to the records of the municipality after giving a reasonable notice to the
Chairperson:Provided that the member shall not have access to such records of the municipality as
are classified as confidential or secret by the rules made by the Government in this behalf.Andhra Pradesh Municipalities Act, 1965

54. Payment of honorarium and conveyance allowance to Chairperson and
conveyance allowance to members.
- For any municipality, the Government may, after consultation with the council sanction out of the
municipal fund, payment of honorarium and conveyance allowance to the Chairperson or the
Vice-Chairperson on whom the functions of the Chairperson devolve under sub- section (2) of
Section 50, as the case may be, and conveyance allowance to every member, at such rates as may be
prescribed,Provided that the conveyance allowance shall be payable to the Chairperson or
Vice-Chairperson, as the case may be, in case he maintains and uses a motor car.
55. Resignation of member, .........................., Vice-Chairperson or
Chairperson.
- Any member, ................. the Vice-Chairperson or the Chairperson may, by writing under his hand
addressed to the Commissioner resign his office. The Commissioner shall, on receipt of such
resignation, place it before the next meeting of the council. The council shall, if it is satisfied as to its
genuineness from the concerned person, accept the resignation; and the resignation so accepted
shall take effect from the date of such acceptance. If the council is not satisfied as to the genuineness
of the resignation, the notice of resignation shall lapse. Before the resignation is so accepted, it shall
be open to the person concerned to withdraw such resignation by writing under his hand addressed
to the Commissioner. (c) Commissioner
56. Powers and functions of the Commissioner.
(1)The Commissioner shall, save as otherwise provided in this Act,(a)carry into effect all the
resolutions of the council;(b)furnish to the council such periodical reports regarding the progress
made in carrying out the resolutions of the council;(c)subject to all other restrictions, limitations
and conditions hereinafter imposed, exercise the executive power for the purpose of carrying out the
provisions of this Act, and be directly responsible for the due fulfillment of the purposes of this
Act;(cc)exercise diciplinary control over the employees of the Municipal Council, who shall be
subordinate to the Commissioner;(d)exercise all powers in relation to the collection of taxes and
fees, the licences and the removal of encroachments;(e)be in charge of the office of the municipality
and have custody of the municipal records;(f)inspect the places of entertainment for the purposes of
verification of the sale of tickets; and(g)exercise all the powers and perform all the functions
specifically conferred or imposed on the Commissioner by or under this Act.(2)The Commissioner
may, for the purpose of performing his functions imposed by or under this Act, requisition the
services of any of the officers and other employees of the municipality and the vehicles of the
municipality under their control and the said officers or other employees shall comply with such
requisition.(3)Subject to any directions given, or restrictions imposed by the Government or the
council, the Commissioner may, by order in writing, delegate any of his powers or functions to any
officer or other employee of the council or to any employee of the Government. The exercise of any
power or the performance of any function so delegated shall be subject to such restrictions,
limitations and conditions as may be laid down by the Commissioner and shall be subject to hisAndhra Pradesh Municipalities Act, 1965

control and revision.(4)The Commissioner shall, save as otherwise provided in the rules relating to
discipline and conduct, be under such administrative control of the Chairperson, as may be
prescribed.(5)(a)The Commissioner may incur in each case contingent expenditure incidental to the
municipal administration,(i)in the case of a third grade or second grade municipality not exceeding
one thousand rupees;(ii)in the case of first grade municipality, not exceeding fifteen hundred
rupees.(iii)in the case of a special grade or a selection grade municipality, not exceeding two
thousand rupees.(b)He shall report the expenditure so incurred and the reasons therefor to the
council at its next meeting.Provided that no such expenditure shall be incurred if there is no
provision available to meet the expenditure under the relevant head of account in the budget framed
by the council with the modifications, if any, made by the Government or where such expenditure
was expressly prohibited by the council.
57.
[xxxxx]
58. Commissioner to attend the meetings of the council and its committees.
- The Commissioner shall attend the meetings of the council, and where he is required to do so by
the Chairperson, of any of its committees. He shall have the right to speak, and otherwise to take
part, in the meetings of the council and of any of its comittees but shall not be entitled to move any
resolution, or to vote, at any such meeting.
Chapter 4
Controlling Authorities and their powers
59. Government's power to cancel or suspend resolutions etc.
(1)The Government may, either suo motu or on representation of any member, the Chairperson or
the Commissioner by order in writing(i)cancel any resolution passed, order issued, or licence or
permission granted; or(ii)prohibit the doing of any act which is about to be done or is being done, in
pursuance or under colour of this Act, if in their opinion--(a)such resolution, order, licence,
permission or act has not been passed, issued, granted or authorised in accordance with law;
or(b)such resolution, order, licence, permission or act is in excess of the powers conferred by this
Act or any other enactment; or(c)the execution of such resolution, or order, the continuance in force
of such licence or permission or the doing of such act is likely to cause financial loss to municipality,
danger to human life, health or safety or is likely to lead to a riot or breach of peace or is against
public interest.Provided that the Government shall, before taking action under this section on any of
the grounds referred to in clauses (a) and (b), give the authority or person concerned an opportunity
for explanation;Provided further that nothing in this sub-section shall enable the Government to set
aside any election which has been held.(2)If, if the opinion of the Government, immediate action is
necessary on any of the grounds referred to in clause (c) of sub-section (1), they may suspend the
resolution, order, licence, permission or act, as the case may be, for such period as they think fitAndhra Pradesh Municipalities Act, 1965

pending the exercise of the powers under sub-section (1).
59A. Government's power to suspend Chairperson or Vice-Chairperson or
Member.
(1)The Government may, either suo motu or on a representation of a Chairperson or
Vice-Chairperson or Member or Commissioner or employee of a Municipal Council, by notification
in the Andhra Pradesh Gazette, suspend any Chairperson or Vice-Chairperson or Member who, in
their opinion, wilfully misbehaved or manhandled any other Member or Officer or employee of the
Council or destroyed the property of the Council or used unparliamentary language or abused his
position in the course of meetings of the Council or during the discharge of any duty vesting upon
any Chairperson or Vice-Chairperson or Member or Officer or employee, so as to lead to a situation
in which the Municipal Administration cannot be carried on in accordance with the provisions of
this Act or the financial stability of the Council is threatened.(2)The Government shall, before taking
action under sub-section (1) give the Chairperson or Vice-Chairperson or Member concerned an
opportunity for explanation, and the notification issued under the said sub-section shall contain a
statement of the reasons for the action taken by the Government.(3)The Government may, suo
motu, or on an application made by the Chairperson or Vice-Chairperson or Member revoke the
order of suspension issued under sub-section (1).
60. Government's power to remove Chairperson or Vice-Chairperson.
(1)The Government may, by notification in the Andhra Pradesh Gazette, remove any Chairperson or
Vice- Chairperson who, in their opinion wilfully omits or refuses to carry out or disobeys the
provisions of the Act or any rules, bye-laws, regulations or lawful orders issued thereunder or abuses
his position or the powers vested in him.(2)The Government shall, when they propose to remove a
Chairperson or Vice-Chairperson under sub-section (1), give the Chairperson or Vice-Chairperson
concerned an opportunity for explanation, and the notification issued under the said sub-section
shall contain a statement of the reasons of the Government for the action taken.(3)Any person
removed under sub-section (1) from the office of Chairperson or from the office of Vice- Chairperson
shall not be eligible for election to either of the said offices until the date on which notice of the next
ordinary elections to the council is published in the prescribed manner.
61.
[xxxxx]
62. Government's power to dissolve the council.
(1)If, in the opinion of the Government, a council is not competent to perform, or persistently makes
default in performing, the duties imposed on it by or under this Act or any other law for the time
being in force or exceeds or abuses its position or powers or a situation exists in which the municipal
administration cannot be carried on in accordance with the provisions of this Act or the financialAndhra Pradesh Municipalities Act, 1965

stability or credit of the council is threatened, the Government may, by notification in the Andhra
Pradesh Gazette, direct that the council be dissolved with effect from a specified date and
reconstituted either immediately or with effect from another specified date not later than six months
from the date of dissolution; and the notification shall be laid before both Houses of the State
Legislature.(2)x x x(3)For purposes of reconstitution of dissolved council under this section, the
vacancies in the office of all the elected members shall be deemed to be casual vacancies.(4)Before
publishing a notification under sub-section (1), the Government shall communicate to the council
concerned the grounds on which they propose to do so, fix a reasonable period for the council to
show cause against the proposal and consider its explanations or objections, if any: and the
Chairperson of the Municipality concerned shall also be given a reasonable opportunity of being
heard;(5)On the date fixed for the dissolution of the council under sub-section (1), all its members
including ex-officio members as well as its Chairperson, and Vice-Chairperson shall forthwith be
deemed to have vacated their offices as such.(6)During the interval between the dissolution and the
reconstitution of the council, all or any of the powers and functions of the council and of its
Chairperson and Wards Committees and of the Committees referred to in Section 43 and 47 may be
exercised and performed, as far as may be, and to such extent as the Government may determine, be
such person as the Government may appoint in that behalf, and any person who is not a District
Collector or Revenue Divisional Officer may, if the Government so directs, receive payment for his
services from the municipal fund; the Government may determine the relations of such person with
the District Controlling Officers and with themselves and the Government may direct the
Commissioner to exercise and perform any powers and duties under this Act in addition to his
own.(7)The members including the ex-officio members of the reconstituted Council shall enter upon
their office on the date fixed for its reconstitution and the term of office of the elected members shall
continue only for the reminder of the period for which the dissolved Municipality would have
continued had it not been dissolved.(8)The Government may reconstitute the council before expiry
of the period notified under sub-section (1) or sub-section (2).Provided that where the reminder of
the period for which the dissolved Municipality would have continued is less than six months, it
shall not be necessary to hold any elections under this clause for constituting the Municipality for
such period.(9)When a council is dissolved under this section, the Government, until the date of the
reconstitution thereof, and the reconstituted council thereafter, shall be entitled to all the assets and
be subject to all the liabilities of the council as on the date of the dissolution and on the date of the
reconstitution respectively.
62A. Appointment of Special Officer.
(1)Notwithstanding anything contained in this Act, where in the opinion of the Government it is not
possible to hold the elections to the municipalities in accordance with the provisions of this Act,
before the date of expiration of the term, and to bring the newly elected members into office on the
date of expiration of the term as aforesaid ................ the Government may, by notification appoint a
Special Officer to exercise the powers, perform the duties and discharge the functions of--(a)the
Council;(b)the Chairperson; and(c)the Commissioner;Provided that the Government may, from
time to time, by notification in the Andhra Pradesh Gazette and for reasons specified therein extend
the said period of appointment of Special Officer beyond six years for a further period or periods, so
however the period of appointment of the special officer shall not, [in the aggregate exceed threeAndhra Pradesh Municipalities Act, 1965

years] [Substituted 'in the aggregate exceed ten years' by Act No. 22 of 1994, dated 9.8.1994] or till
the newly elected councils assume office which ever is earlier.(2)The Government shall cause
elections to be held to the municipality under the Principal Act, so that the newly elected members
may came into office on such date as may be specified by the Government in this behalf by a
notification, in the Andhra Pradesh Gazette:Provided that the Government may, from time to time,
advance or postpone the date specified under this subsection and fix instead another date;Provided
further that the date fixed under this sub-section shall be the date on which the appointment of the
Special Officer, expires.(3)The Special Officer shall exercise the powers, perform the duties and
discharge the functions of the council until the elected members come into office, of the Chairperson
until a Chairperson is elected, and of the Commissioner until a Commissioner is appointed by the
Government and the committees referred to in Sections 43 and 74 until such committees are
constituted, as the case may be and any such officer may, if the Government so direct, receive
remuneration for his service from the municipal fund.
62B. [ Appointment of Special Officers to the Municipalities in Scheduled
Areas. [Inserted by Act No. 8 of 2006, dated 2.1.2006.]
- Notwithstanding anything contained in Section 62-A or any other provisions of this Act, it shall be
competent for the Government by notification, to appoint and continue a Special Officer to exercise
the powers, perform the duties and discharge the functions of the Council, the Chairperson and the
Commissioner in respect of the Municipalities located in the Scheduled areas until the Parliament
by law extend the provisions of Part IX-A of the Constitution of India to the Scheduled areas under
clause (3) of Article 243-ZC of the Constitution of India:Provided that elections shall be held to the
said Municipalities in the Scheduled areas within a period of one year after such extension of Part
IX-A of the Constitution of India to the Scheduled areas and the Special Officers shall continue until
the newly elected Councils assumes office.]
63. Government's power to appoint officers to supervise municipalities.
(1)The Government may appoint a Director of Municipal Administration and such number of
Deputy Directors, Regional Directors and other officers as may be required for the purpose of
inspecting or superintending the operations of all or any of the councils established under this
Act.(2)All schools, hospitals, dispensaries, vaccine stations, choultries and other institutions
mentioned by any council and all documents relating thereto shall, at all times, be open to the
inspection of such officers as the Government may appoint in that behalf.(3)Municipal authorities
and municipal officers and servants shall be bound to afford to inspecting or superintending officers
appointed under this section such access at all reasonable times to municipal property or premises,
and to all documents which, subject to any rules made in this behalf, the inspecting or
superintending officers may consider to be necessary to enable them to discharge their duties of
inspection or superintendence.Andhra Pradesh Municipalities Act, 1965

64. Government's power to take action in certain cases.
(1)If, at any time, it appears to the Government that a council, Chairperson, Vice-Chairperson
Commissioner has made any default in performing any duty imposed by or under this Act or any
other enactment for the time being in force, they may, by order in writing, fix a period for the
performance of such duty.(2)If such duty is not performed within the period so fixed, the
Government may appoint some person to perform it, and may direct that the expense of performing
it shall be paid, within such time as they may fix, to such person by the council.(3)If the expenses
which the Government have directed under sub-section (2) to be paid from the municipal fund are
not so paid, the District Collector, with the previous sanction of the Government, shall make an
order directing the Commissioner to pay it in priority to any other charges against such fund except
establishment charges and charges for the service of authorised loans.(4)The Commissioner shall, so
far as the funds to the credit of the council permit, be bound to comply with such order.
65. Government's powers to undertake work for municipality.
(1)The Government may, with the consent of council, undertake on its behalf the construction of
water supply, drainage or other works, appoint persons to carry out construction of such works and
direct that the expenses including the pay of such persons be paid from the municipal fund and
thereafter the provisions of Sub-sections (3) and (4) of Section 64 shall apply.(2)The Government
may, after consultation with the council, constitute planning committees for any municipality,
consisting of such members as may be appointed by them, for the purpose of preparing plans in
respect of such developmental works as may be approved by the Government for execution within
the municipality; and the council shall undertake all such works. The expenses incurred towards the
planning committees, the preparation of plans and the execution of developmental works under this
section shall be paid from the municipal fund.
66. District Collector's power to enforce execution of resolutions.
(1)If it appears to the District Collector that the Chairperson or Commissioner has made default in
carrying out any resolution of the council, the said Collector shall, after giving the Chairperson or
the Commissioner as the case may be, a reasonable opportunity of explanation, send a report on
such resolution together with the explanation if any received, to the Government and at the same
time forward a copy of the same to the council.(2)The Government shall, as soon as may be, after the
receipt of the report of the Collector under sub-section (1), consider the same and the explanation, if
any, received therewith and, if necessary, take action under subsection (2) of Section 64.
67. Power District Collector and Government for purposes of control.
(1)The District Collector may enter on and inspect, or cause to be entered on and inspected, any
immovable property or any work in progress under the control of any municipal authority in his
district.(2)The Government or the District Collector may-- (a) call for any document in the
possession, or under the control, of any council or the Chairperson or Commissioner; (b) requireAndhra Pradesh Municipalities Act, 1965

any council, the Chairperson or Commissioner to furnish any return, plan, estimate, statement,
account or statistics; (c) require any council, the Chairperson or Commissioner to furnish any
information or report on any municipal matter; (d) record in writing, for the consideration of the
council, the Chairperson or Commissioner, any observations they or he may think proper in regard
to its or his proceedings or duties.
68. Emergency powers of District Collector.
(1)The District Collector may, in cases of emergency, direct or provide for the execution of any work
or the doing of any act which the council or the Commissioner is empowered to execute or to do and
the immediate execution or the doing of which is, in his opinion, necessary for the safety of the
public and may direct that the expenses incurred for executing such work or doing such act, as the
emergency may require, shall be paid from the municipal fund.(2)If the expenses are not so paid,
such Collector may make an order directing the person having the custody of the municipal fund to
pay them in priority to any other charge against the fund.(3)Such person shall, so far as the funds to
the credit of the council admit, be bound to comply with such order.(4)Every case in which the
powers conferred by this section are exercised shall be forthwith reported to the Government by the
District Collector with the reasons in full, for the exercise of such powers; and a copy of the letter
shall at the same time be sent to the council for information.
69. Powers of officers acting for, or in default of, council and liability of
municipal fund.
- When the District Collector or a person appointed by the Government lawfully takes action on
behalf, or in default, of the council or the Commissioner under this Act, he shall have all such
powers as are necessary for the purpose, and shall be entitled to the same protection under this Act
as the Municipal Authority whose powers he is exercising, and compensation shall be recoverable
from the municipal fund by any person suffering a damage from the exercise of such power to the
same extent as if the action has been taken by such municipal authority.
70. Power of District Collector to suspend a resolution, etc.
- If in the opinion of the District Collector, immediate action is necessary on any of the grounds
referred to in clause (c) of sub-section (i) of Section 59 he may suspend the resolution, order,
licence, permission or act, as the case may be, and report to the Government who may thereupon
either rescind the Collectors order or, after giving the authority or person concerned a reasonable
opportunity of explanation, direct that it shall continue in force with or without modification
permanently or for such period as they think fit.
Part 3 – Municipal EstablishmentAndhra Pradesh Municipalities Act, 1965

71. Appointment of Municipal Health Officer, Municipal Engineer, Education
Officer and Town Planning Officer.
(1)For any municipality the Government may sanction a post of Municipal Health Officer, a post of
Municipal Engineer, a post of Education Officer and a post of Town Planning Officer;Provided that
in the case of a municipality which has an annual income of less than three lakhs of rupees from
ordinary receipts, the Government may, without sanctioning the post of a Municipal Health Officer,
a Municipal Engineer, an Education Officer, or a Town Planning Officer, appoint any officer of the
Public Health Department, the Public Works Department, the Education Department or the Town
Planning Department, on such terms as may be specified by the Government to exercise the power
and discharge the functions of a Municipal Health Officer, a Municipal Engineer, an Education
Officer, or a Town Planning Officer, as the case may be:Provided further that when the officer of the
Public Health Department or the Public Works Department Education Department or the Town
Planning Department is appointed to exercise the powers and discharge the functions under this
Act, such of the powers and functions as are exercisable by any authority under this Act in
consultation with the Municipal Health Officer, Municipal Engineer, Education Officer or Town
Planning Officer shall be exercised by such authority after consultation with the concerned officer
appointed under the foregoing proviso.Provided also that where there is no Municipal Health
Officer, Municipal Engineer, Education Officer, or Town Planning Officer, the Commissioner shall
exercise the powers and discharge the functions of such officer.(2)Before sanctioning any post under
sub-section (1) the Government shall consult the council concerned.(3)The Municipal Health
Officer, Municipal Engineer, Education Officer or Town Planning Officer shall devote his whole time
to the duties of his office and shall not undertake any work unconnected with the municipality
except with the sanction or under the direction of the Government.(4)All the appointments to posts
sanctioned under sub-section (1) shall be made by the Government.(5)All the officers appointed
under sub-section (4) shall, save as otherwise provided in the rules relating to the discipline and
conduct of those officers, be deemed, for all purposes, as officers of the council and shall, in the
exercise of the powers and discharge of the functions under this Act, be subject to such control and
direction of the Commissioner as may be prescribed.(6)The Government shall pay out of the
Consolidated Fund of the State, salaries, allowances, pension and contribution, if any, towards the
provident fund or pension-cum-provident fund of every officer appointed by the Government under
sub-section (4).
72. Government's power to regulate the methods of recruitment, conditions
of service, etc., Officers appointed under Sections 29 and 71.
(1)The Government shall have power-(a)to make rules to regulate the classification and methods of
recruitment, conditions of service, pay and allowances and disciplinary conduct of the officer
appointed under Section 29 or Section 71, as the case may be;(b)to recover form the council
concerned the whole or such proportion of the salary and allowances paid to any such officer and
such contribution towards his leave allowances, pension or provident-cum-pension fund of such
officer as the Government may, by general or special order, determine.(2)The Government may, at
any time, withdraw any officer appointed under Section 29 or Section 71 and appoint another in hisAndhra Pradesh Municipalities Act, 1965

place, and they shall withdraw such officer if such withdrawal is recommended by a resolution
passed at a special meeting called for the purpose and supported by the votes of not less than
three-fifths of the sanctioned strength of the council.Provided that no such resolution shall be
moved before the expiry of one year from the date of assumption of charge by such officer.
73. Other officers and employees of council.
(1)All proposals for fixing or altering the number, designations and grades of officers other than
those referred to in Section 72 and employees of the council and the salaries, fees and allowances
payable to them shall be placed before the council by the Commissioner for consideration and
sanction of the council.(2)The council may, after consideration of such proposals, sanction them
with or without modification;Provided that no proposal adversely affecting any municipal officer or
employee who has been in the permanent service of the municipality for more than five years and is
drawing a salary of not less than fifty rupees per mensum shall be considered except at a special
meeting convened for the purpose and no such proposal shall be given effect to unless assented to,
by atleast one-half of the members then on the council.(3)Notwithstanding any thing in sub-sections
(1) and (2), the Government shall have power to sanction and fix or alter the number, designations
and grades of, and the salaries, fees and allowances payable to, the officers, and employees of any
council or any class of such officers and employees and, it shall not be open to the council to vary the
number, designations, grades, salaries, fees or allowances as so fixed or altered except with the
previous sanction of the Government.
74. [ Appointment to posts of officers and employees of council sanctioned
under Section 73. [Substituted by Act No. 15 of 1996, dated 26.8.1996]
- Subject to any rules including the rule for the representation of Scheduled Castes, Scheduled
Tribes and the socially and educationally backward classes of citizens which the Government may
make in this behalf, and notwithstanding anything in the Andhra Pradesh (Andhra Area) Public
Health Act, 1939 or any other law similar thereto for the time being in force, appointment to posts of
officers and employees sanctioned under Section 73, shall be made by the chair-person:Provided
that an appointment to the post of a Headmaster or Headmistress of a High School maintained by
the Council shall be made from a panel prepared by a committee consisting of the Chairperson, the
Commissioner, the District Educational Officer having jurisdiction and not less than three but not
more than seven members chosen in this behalf by the council:Provided further that appointment
[to all the other posts except all categories of posts of teachers the pay or the maximum pay] of
which exceeds rupees one hundred shall be made from a panel prepared by a committee consisting
of the Chair-person, the Commissioner and not less than three but not more than seven members
chosen in this behalf by the council.][Provided also that appointment to all categories of posts of
teachers shall be made as per the procedure prescribed by the Government from time to time.]
[Added by Act No. 10 of 1999, dated 15.4.1999]Andhra Pradesh Municipalities Act, 1965

75. Power of Government to transfer officers and employees of
municipalities.
(1)Notwithstanding anything in this or any other enactment for the time being in force, the
Government shall have power to transfer any officer or employee of a municipality to the service of
any other municipality or of any other local authority.(2)The Government shall have power to issue
such general or special directions as they may think necessary for the purpose of giving due effect to
transfers made under sub-section (1).
76. Power of council to frame regulations.
(1)Subject to the provisions of this Act and the rules which the Government may make in this behalf,
the council may frame regulations in respect of officers and employees of the municipality appointed
under Section 74(a)fixing the amount and nature of security to be furnished;(b)prescribing
educational or other qualifications;(c)regulating the grant of leave, leave allowances, acting
allowances and travelling allowances;(d)regulating the grant of pensions and
gratuities;(e)establishing and maintaining provident funds and making contribution thereto
compulsory;(f)regulating conduct; and(g)generally prescribing conditions of service;Provided
-(i)that the amount of any leave, leave allowances, travelling allowances, pension or gratuity
provided for in such regulations shall, in no case without the special sanction of the Government,
exceed what would be admissible in the case of Government employees of similar standing and
status; and(ii)that the conditions under which such allowances are granted or any leave,
superannuation or retirement is sanctioned, shall not without similar sanction be more favourable
than those for the time being prescribed for such Government employees.(2)Until rules and
regulations are made under sub-section (1), the rules and regulations which were applicable to such
officers and employees immediately before the commencement of this Act in respect of the matters
specified in that sub-section shall continue to apply to them.
77. [ Power to punish municipal employees. [Substituted by Act No. 15 of
1996., dated 26.8.1996]
(1)Subject to the provisions of Sections 79 and 80 and to such control as may be prescribed, the
Commissioner may censure, fine, withhold increment in the time-scale of pay of, withhold
promotion from, suspend or reduce in rank any officer or other employees in the service of the
municipality except an officer appointed under Section 29 or Section 71, or an officer, or other
employee belonging to a municipal service for the State constituted under Section 80 for any breach
of departmental rule or discipline or for carelessness, unfitness, neglect of duty or other misconduct
after giving an opportunity of showing cause against the penalty proposed:Provided that a fine shall
not be imposed on any officer or other employee unless he is a Bill-Collector or is the holder of such
post as may be prescribed.(2)Subject to such control as may be prescribed, the Chair-person shall
have the power to impose penalty of removal or dismissal on such officer or other employee after
giving him a reasonable opportunity of showing cause against the action proposed to be taken in
regard to him.Provided that he may, in public interest, suspend any such officer or other employeeAndhra Pradesh Municipalities Act, 1965

pending action proposed to be taken in regard to him under this sub-section.]
78. Power to grant leave to officers and employees.
- Subject to the rules made under Section 72 or Section 76 the Commissioner may grant any leave to
the officer and other employees in the service of the municipality.
79. Special provisions regarding Government employees lent to council.
(1)The Government may, on the application of any council, place the services of any Government
employee employed in connection with the affairs of the State at the disposal of the council to be
employed by it for the purposes of this Act. The council shall pay any Government employee so
employed the salary he may be entitled to receive under the rules of the branch of Government
service to which he belongs, and shall also make any contribution towards the pension and leave
allowances of such employee as may be required by the conditions of his service under the
Government to be paid by him or on his behalf.(2)If such employee, while employed by the council
or if any other employee of the council does any work for the Government, the Government shall
contribute to the municipal funds so much of salary of such employee as the Government may
consider to be an equivalent for such work.(3)No Government employee employed by a council shall
be dismissed or removed from such employment,(a)if he is employed as a Medical Officer, without
the consent of the Government; and(b)in any other case, without the consent of the Government or
until three month's notice in writing to that effect shall have been given to the Chief Controlling
Authority of the branch of the Government service to which the Government employee
belongs.(4)No Government employee employed by a councils shall, except in cases of emergency, be
withdrawn from the service of the council without the consent of the council until the Government
shall have given three month's notice in writing to that effect to the council or unless some other
Government employee has been deputed to replace the one withdrawn.(5)Government employees
employed by councils shall be entitled to leave and other privileges in accordance with the
regulations applicable to the general branch of the Government service to which they belong.
80. Constitution of a municipal service for the State for any class of
municipal officers and employees.
(1)Notwithstanding anything in this Act or the rules made thereunder, the Government may, after
consulting all the councils, by notification in the Andhra Pradesh Gazette, constitute any class of
officers or employees of councils into a municipal service for the State.(2)Upon the issue of a
notification under sub-section (1), the Government shall have power to make rules to regulate the
classification, methods of recruitment, conditions of service, pay and allowances and discipline and
conduct of the municipal service thereby constituted and such rules may vest jurisdiction in relation
to such service in the Government or in such other authority or authorities as may be prescribed
therein.(3)Nothing in this section shall affect the operation of the Andhra Pradesh (Telangana Area)
Local Government service (Declaration as the State Civil Service) Act, 1956 (Act XX of 1956), in so
far as it relates to the municipal officers and municipal employees who are declared to be borne onAndhra Pradesh Municipalities Act, 1965

the State Civil Service as declared under Section 3 of that Act.
Part 4 – Chapter 1
Taxation
81. Levy of ordinary taxes and the control of Government in respect thereof.
(1)(a)Every council shall, by resolution, levy the following taxes, namely:-(i)a property tax;(ii)x x
x(iii)a tax on carriages and carts; and(iv)a tax on animals.(b)The council may, by resolution and
with the previous sanction of the Government also levy a tax on advertisements.(2)Any resolution of
a council determining to levy a tax shall specify the rate at which and the date from which any such
tax shall be levied;Provided that, before passing a resolution imposing a tax for the first time or
increasing the rate of an existing tax, the council shall publish a notice in at least one newspaper
published in the main language of the district having circulation in the municipality, on the notice
board of the municipal office and in such other places within municipal limits as may be specified,
by the council and by beat of drum, of its intention, fix a reasonable period not being less than one
month for submission of objections and consider the objections, if any, received within the period
specified.Provided further that any resolution abolishing an existing tax or reducing the rate at
which a tax is levied shall be immediately reported to the Government; and in municipalities which
have an outstanding loan either from the Government or from the public or from any banking,
insurance or financial corporation or from any other local authority, such abolition or reduction
shall not be carried into effect without the sanction of the Government.
82. Duty on transfers of property.
- In every municipality, a duty shall be levied on certain transfers of property in accordance with the
provisions hereinafter contained in this Act.
83. Notification of new taxes.
- When a council determines, subject to the provisions of Section 81, to levy any tax for the first time
or at a new rate, the Commissioner shall forthwith publish a notification in the prescribed manner
specifying the rate at which, the date from which and the period of levy, if any, for which, such tax
shall be levied.
84. Saving for certain provisions of the Constitution of India.
- Nothing in this part of this Act shall authorise a council to levy any tax which the State Legislature
has no power to impose in the State under the Constitution of India:Provided that a council which
immediately before the commencement of the Constitution was lawfully levying any such tax under
any law then in force may continue to levy that tax until provision to the contrary is made by
Parliament by law.Andhra Pradesh Municipalities Act, 1965

85. Levy of property tax.
(1)Where the Council by resolution determines that a property tax shall be levied, such tax shall be
levied on all buildings and lands within the municipal limits save those exempted by or under this
Act or any other law.The property tax may comprise(a)a tax for general purposes;(b)a water and
drainage tax to provide for expenses connected with the construction, maintenance, repair,
extension or improvement, of water or drainage works here to before provided or hereafter to be
provided;(c)a lighting tax to provide for expenses connected with the lighting of the municipality by
gas or electricity; and(d)a scavenging tax to provide for expenses connected with the removal of
rubbish, filth or the carcases of animals from private premises:Provided that where the water and
drainage tax is levied, the council shall declare what proportion of tax is levied in respect of
water-works and the remainder shall be deemed to be levied in respect of drainage works and the
proportion so declared shall also be specified in the notification published under Section
83:Provided further that the proportion so fixed shall not be altered without the previous sanction of
the Government.(2)Save as otherwise provided in this Act and subject to the provisions of Sections
81 and 87 and in accordance with the rules made by the Government in this behalf these taxes shall
be levied at such percentages of the annual rental value of lands or buildings or both as may be fixed
by the council; Provided that in the case of lands and buildings vested in the trustees of Port of
Visakhapatnam, these taxes levied in any half-year shall be at one per centum of the annual gross
earnings of the Visakhapatnam Port Trust in the year immediately preceding such levy.Provided
further that the percentage of the property tax fixed under this sub-section shall be such that the
incidence of property tax together with the education tax and library cess levied under the relevant
law, shall not exceed twenty five percentum of the annual rental value in the case of residential
buildings and thirty-three per centum of the annual rental value in the case of non-residential
buildings.(3)(a)Save as otherwise provided in clause (b), the council shall, in the case of lands which
are not used exclusively for agricultural purposes and are not occupied by, or adjacent and
appurtenant to building, levy these taxes, at such percentages of the capital value of the lands or at
such rates with reference to the extent of the lands as may be fixed by the council;Provided that such
percentages or rates shall not exceed the maximum, if any, fixed by the Government and that the
capital value of such lands shall be determined in such manner as may be prescribed.(b)In the case
of railway lands which are not used exclusively for agricultural purposes and are not occupied by or
adjacent and appurtenant to, buildings, the council shall levy these taxes at such percentages of the
capital value of such lands, and the Government shall have power to make rules regarding the
manner in which, the person or persons by whom and the intervals at which, the capital value of
such lands shall be determined, and they may also by such rules restrict or modify the application of
the provisions contained in Schedule II to such lands.(4)The council may, in the case of lands used
exclusively for agricultural purposes, levy these taxes at such proportions of land revenue payable
thereon as it may fix with the approval of the Government.(5)[ Notwithstanding anything contained
in this Act and the Rules made thereunder, where a building is constructed or re-constructed, or
some structures are raised unauthorisedly, it shall be competent to the assessing authority to levy
property tax on such building or structure with a penalty of ten percent on the amount of tax levied
till such unauthorised construction is demolished or regularised.(6)A separate receipt for the
penalty levied and collected shall be issued.] [Added by Act No. 35 of 1998, dated 22.12.1998.]Andhra Pradesh Municipalities Act, 1965

85A. [ Constitution of the Andhra Pradesh State Property Tax Board.
[Inserted by Act No. 6 of 2012, dated 20.4.2012.]
- The Government shall, by notification, within three months from the date of commencement of the
Andhra Pradesh Municipal Laws (Amendment) Act, 2012, constitute a State Property Tax Board
called as the Andhra Pradesh State Property Tax Board (hereinafter referred to as the Board) to
provide assistance and technical guidance to all Municipalities in the State for proper assessment of
property tax on buildings and lands, in their respective jurisdictions.]
85B. [ Composition of the Board. [Inserted by Act No. 6 of 2012, dated
20.4.2012.]
- The Board shall consist of a Chairperson five members as specified below:
(i)Commissioner and Director ofMunicipal-Administration, Government of
Andhra Pradesh.Ex-officioVice-Chairperson
(ii)Secretary to Government, Information Technologyand Communications
Department, Government of Andhra Pradesh or anExpert in Information
TechnologyMember
(iii) An expert in valuation of building and landsfor assessment of property tax Member
(iv) President, Chamber of Municipal Chairman, AndhraPradesh Ex-officio Member
(v)One person in the category of AdditionalDirector of Municipal
Administration appointed by the GovernmentMember-Secretary]
85C. [ Qualification for the Chairperson and Members. [Inserted by Act No. 6
of 2012, dated 20.4.2012.]
- (i) The Chairperson shall be a person who/has held the Office of Judge of a High Court;(ii)The
members shall be persons who are having knowledge and experience in the fields of valuation of
properties for assessment of property tax, Information Technology (I.T.) as may be prescribed.]
85D. [ Term and other conditions of service of Chairperson and Members.
[Inserted by Act No. 6 of 2012, dated 20.4.2012.]
- The Chairperson and the members of the Board shall hold office for a period of three years and the
terms and conditions of their service, including salaries and allowances, shall be such as may be
prescribed by the State Government.]
85E. [ Resignation. [Inserted by Act No. 6 of 2012, dated 20.4.2012.]
- The Chairperson or a member of the Property Tax Board may resign his office by a letter signed by
him and addressed to the Government and on acceptance of such resignation by the Government,Andhra Pradesh Municipalities Act, 1965

his office shall fall vacant on the date on which such resignation is accepted.]
85F. [ Removal from Office. [Inserted by Act No. 6 of 2012, dated 20.4.2012.]
- The person appointed as Chairperson of the State Property Tax Board may be removed from office
in the manner as may be prescribed.]
85G. [ Staff of the Board. [Inserted by Act No. 6 of 2012, dated 20.4.2012.]
- The Board shall be provided with such number of officers and staff as may be determined by the
State Government.]
85H. [ Functions of the Board. [Inserted by Act No. 6 of 2012, dated
20.4.2012.]
- The Board shall discharge the following functions, namely:(i)To make arrangements for
preparation of data base of property tax in all Municipalities, for proper maintenance of all record
and registers relating to assessment of property tax.(ii)to make arrangements for assessment of
property tax on all buildings and lands situated in the Municipalities as per the provisions of the Act
and the Rules issued thereunder.(iii)to monitor that the assessment books shall be completely
revised by the Commissioner once in five years as per the provisions of the Act and the Rules issued
thereunder.(iv)to make arrangements that all new constructions or additions or improvements to
the existing buildings in the Municipalities are assessed to Property Tax within thirty days from the
date of completion of the building or occupation of the building whichever is earlier.(v)to conduct
study on prevailing rental value of buildings from time to time in Municipalities.(vi)to make
arrangements for the calculation of payment of service charges in respect of Central Government
properties as per the instructions of State Government and Government of India.(vii)to review the
present Property Tax assessment system in Municipalities and make suggestions to the Government
in this regard.(viii)to make arrangements for assessment or revision of property tax relating to at
least 25% of the aggregate number of estimated properties across all Municipalities in the State by
31st March, 2015.(ix)to prepare a work plan to achieve the above coverage and publish the work
plan in the Andhra Pradesh Gazette.(x)to make arrangements for disposal of revision petitions and
appeals filed for revision of Property Tax by the concerned officers within three months from the
date of filing such revision petitions or appeals.(xi)to suggest the Government about the criteria to
be adopted for exemption of buildings and lands in Municipalities from payment of Property
Tax.(xii)to make arrangements for maintenance of register of properties exempted from the
payment of Property Tax by all the Municipalities.(xiii)to undertake training of Officers and Staff of
Municipalities in the assessment and revision of Property Tax directly or through any
institution.(xiv)to discharge such other functions in the field of assessment of Property Tax
including development of expertise in valuation of lands and buildings.]Andhra Pradesh Municipalities Act, 1965

85I. [ Powers of the Board. [Inserted by Act No. 6 of 2012, dated 20.4.2012.]
(1)The Board shall Exercise the following powers, namely:-(i)to issue instructions to the
Municipalities for assessment and revision of Property Tax as per the provisions of the Act and the
Rules issued thereunder which shall be complied with by all the Municipal Commissioners.(ii)The
Municipal Commissioner shall consult the Board before issue of draft notification fixing monthly
rent proposed per square metre of plinth area for assessment or revision of property tax. The Board
shall study the draft notification and make a comparative study of the monthly rental values
proposed by other Municipalities in the District in this regard and offer its views in the matter. The
Municipal Commissioner shall give due consideration to the views offered by the Board before
adopting the final notification showing monthly rent per square metre of plinth area as
prescribed.(iii)to make a test check of the assessments made by the Commissioner both at the time
of assessment of new buildings and revision of Property Tax.(iv)to inspect any building or land in
the Municipality or take measurements of the property for verification of the Property Tax
assessment.(v)to call for particulars relating to the building or land from any owner or occupier by
serving a notice for the purpose of verification of the assessment of Property Tax.(vi)to inspect
records and registers relating to assessment and revision of property tax in Municipalities.(vii)to call
for information from Municipal Commissioners on assessment and revision of Property Tax.(viii)to
conduct review meetings with Commissioners of Municipalities and Regional Directors of Municipal
Administration on assessment and revision of Property Tax and to issue suitable instructions in the
matter.]
85J. [ Meetings of the Board. [Inserted by Act No. 6 of 2012, dated 20.4.2012.]
(1)The Board may hold ordinary meetings at such intervals as may be prescribed and a special
meeting may be convened by Chairperson at any other time for the transaction of urgent
business.(2)The number of members necessary to constitute a quorum at a meeting and procedure
to be followed there at shall be such as may be prescribed.]
85K. [ Funds of the Board. [Inserted by Act No. 6 of 2012, dated 20.4.2012.]
(1)The Board shall have a Fund to be called the State Property Tax Board Fund, to which the
following moneys shall be credited,-(i)such moneys as may be paid to the Board by the State
Government or any other authority or agency; and(ii)such moneys as may be paid to the Board by
the Municipalities as may be prescribed.(2)All moneys received by the Board shall be deposited in
the State Bank of India or any Nationalized Bank as may be prescribed.]
85L. [ Expenditure. [Inserted by Act No. 6 of 2012, dated 20.4.2012.]
(1)The expenditure to be incurred by the Board for meeting the salaries and allowances including
contingencies of the Chairperson, Members, Secretary, Officers and employees serving under or for
the Board shall be defrayed out of the Fund to be provided by the State Government.(2)The
expenditure towards contingencies for undertaking normal activities of the Board shall be met out ofAndhra Pradesh Municipalities Act, 1965

the Fund provided by the State Government.]
85M. [ Budget. [Inserted by Act No. 6 of 2012, dated 20.4.2012.]
(1)The Bo3rd shall prepare each year in such for in and within such time, as may be prescribed, a
budget in respect of the ensuing financial year, showing the estimated receipts and expenditure and
shall forward a copy of the same, to State Government for approval.(2)The State Government may,
in according such approval, make such additions, alterations and modifications thereon as it thinks
fit;Provided that before taking such additions, alterations' or modifications" the State Government
shall give the Board an opportunity to express its views thereon within such period as may be
prescribed.]
85N. [ Accounts. [Inserted by Act No. 6 of 2012, dated 20.4.2012.]
- (l) The Board shall have the same financial powers as are exercisable by the Secretary or a Head of
the Department of the State Government. Matters beyond such financial powers shall be referred to
by the Board to the State Government for a decision.(2)The Board shall keep accounts of all receipts
and expenditure and prepare annual accounts in such manner as may be prescribed.]
85O. [ Audit. [Inserted by Act No. 6 of 2012, dated 20.4.2012.]
(1)The Board shall cause its accounts to be audited annually by an auditor to be appointed by the
State Government and the auditor so appointed shall have the right to demand the production of
books, accounts documents and other papers of the Board.(2)As soon as the accounts have been
audited, the Board shall send a copy thereof together with a copy of the report of the auditor to the
State Government.(3)The Board shall comply with such directions as the State Government may,
after perusal of the report of the auditor, think fit to issue in this behalf.(4)The Board shall pay out
of the Fund such sum as may be determined by the State Government by way of fees, if any, for such
audit.]
85P. [ Annual Report. [Inserted by Act No. 6 of 2012, dated 20.4.2012.]
- The Board shall prepare an Annual Report of its activities during the year in such form as may be
prescribed by the State Government and the Annual Report shall be placed before the Legislature of
the State.]
85Q. [ Delegation of powers and functions by the Board. [Inserted by Act No.
6 of 2012, dated 20.4.2012.]
(1)The Board may delegate its powers and functions including financial powers to the Chairperson
of the Board by a resolution adopted by it in this behalf.(2)The Board may also delegate any of its
powers or functions to the Secretary or any Officer of the Board by a resolution adopted by it in this
behalf.]Andhra Pradesh Municipalities Act, 1965

85R. [ Members, officers and employees to be public secants (Central Act 45
of 1860). [Inserted by Act No. 6 of 2012, dated 20.4.2012.]
- Chairperson, every Member of Board or every *J0fficer 6f employee of the Board shall, when ,
acting or purporting to act under the provisions r of this Act, be deemed to be a public servant
within the-meaning of Ejection <23 of>the Indian Penal Code, 1860.]
86. Levy of property tax on a direction by Government.
(1)The Government may, after consultation with the council by order published in the Andhra
Pradesh Gazette, direct any council to levy the property tax referred to in sub-section (1) of Section
81 or any class of such tax, at such rate and with effect from such date, not being earlier than the
first day of the half year immediately following that in which the order is published, as may be
specified in the order.(2)When an order under sub-section (1) has been published, the provisions of
this Act relating to property tax shall apply as if the council had, on the date of publication of such
order, by resolution, determined to levy the tax at the rate and with effect from the date specified in
the order and as if no other resolution of the council under Section 81 determining the rate at which
and the date from which property tax shall be levied, had taken effect.(3)A council shall not alter the
rate at which the property tax or any class of such tax is levied in pursuance of an order under
sub-section (1) or abolish such tax except with the previous sanction of the Government.
87. Method of assessment of property tax.
(1)Every building shall be assessed together with its site and other adjacent premises occupied as an
appurtenance thereto unless the owner of the building is a different person from the owner of such
site or premises.(2)The annual rental value of lands and buildings shall be deemed to be the gross
annual rent at which they may reasonably be expected to be let from month to month or from year
to year with reference to its location, type of construction, plinth area, age of the building, nature of
use to which it is put and such other criteria as may be prescribed.(3)Notwithstanding anything in
the Andhra Pradesh Buildings (Lease, Rent and Eviction) Control Act, 1960, the gross annual rent at
which the lands and buildings might reasonably be expected to be let from month to month or from
year to year, shall be determined by the Commissioner, with reference to its location, type of
construction, plinth area, age of the building, nature of use to which it is put and such other criteria
as may be prescribed:Provided that in the case of any Government or railway building or any
building or a class of buildings not ordinarily let, the gross annual rent of which cannot in the
opinion of the Commissioner be estimated, the annual rental value of the premises shall be deemed
to be nine percent of the estimated value of the land and the present cost of erecting the building
after deducting a reasonable amount towards depreciation which shall in no case be less than ten
percent of such cost.(4)The annual rental value of lands and buildings shall be deemed to be the
gross annual rent at which they may reasonably be expected to let from month to month or from
year to year, less a deduction at the rate of ten per cent for buildings upto the age of 25 years and
twenty per cent for buildings above the age of 25 years and thirty percent for buildings above the age
of 40 years of that portion of such gross annual rent which is attributable to the building apart fromAndhra Pradesh Municipalities Act, 1965

their sites and adjacent lands occupied as an appurtenance thereto and the said deduction shall be
in lieu of all allowances for repairs or on any other account whatsoever:Provided that a rebate of
forty per cent of the annual rental value shall be allowed in respect of the residential buildings
occupied by the owner inclusive of the deduction permissible under this sub-section.Provided
further that in respect of such municipalities on the sea-shore as may be specified by notification
from time to time, a rebate of five per cent of the annual rental value shall be allowed in addition to
the rebates allowed under the other provisions of the Act in respect of all the buildings;Explanation.
- For the purposes of this section, an area not exceeding three times the plinth area of the building
including its site or a vacant land to the extent of one thousand square meters, whichever is less
shall be deemed to be adjacent premises occupied as an appurtenant to the building, and assessed to
tax in accordance with the provisions of this section, and the area, if any, in excess of the said limit
shall be deemed to be land not occupied by or adjacent and appurtenant to such building and the tax
shall be levied thereon in accordance with the provisions of sub-section (3) of Section 85 as if it were
land to which that sub-section applied.
88. General exemptions.
(1)The following buildings and lands shall be exempt from the property tax:(a)places set apart for
public worship and either actually so used or used for no other purpose;(b)choultries for the
occupation of which no rent is charged and choultries the rent charged for the occupation of which
is used exclusively for charitable purposes.(c)recognised educational institutions including hostels,
public buildings and places used for the charitable purpose of sheltering destitute or animals and
libraries and play-grounds which are open to the public;(d)such ancient monuments protected
under the law relating to preservation of ancient monuments for the time being in force, or parts
thereof as are not used as residential quarters, or as public offices;(e)charitable hospitals and
dispensaries;(f)such hospitals and dispensaries maintained by railway administration as may, from
time to time, be notified by the Government in the Andhra Pradesh Gazette:(g)burial and burning
grounds included in the book kept at the municipal office under Section 303;(h)buildings and lands
belonging to the council;(i)any irrigation work vesting in the Government including the bed of
water-course or any building or land adjacent and appertaining to such irrigation work; all lands
belonging to or under the control of the Government including the vacant lands specified in Section
37 and all such other Government property, being neither buildings nor land, from which, in the
opinion of the Government the income could be derived as may, from time to time, be notified by
the Government in the Andhra Pradesh Gazette;Provided that nothing in clauses (a), (c) and (e)
shall be deemed to exempt from property tax any building or land for which rent is payable by the
person or persons using the same for the purposes referred to in the said clauses.Explanation. - The
exemption granted under this section shall not extend to residential quarters attached to schools
and colleges not being hostels or to residential quarters attached to hospitals, dispensaries and
libraries'.(1-A) .....................(2)The water and drainage tax shall not be levied on any land used
exclusively for agricultural purposes and not deriving any benefit from the water or drainage works
on account of which the tax is imposed.(3)The council may, with the previous sanction of the
Government, exempt any particular part of a municipality from the payment of the whole or a
portion of the water and drainage tax or of the lighting tax on the ground that such area is not
deriving full benefit from the water-supply and drainage or from the lighting system.(4)The councilAndhra Pradesh Municipalities Act, 1965

may exempt by building or land from the whole or any portion of the scavenging tax if it is satisfied
that the owner or occupier has made efficient arrangements for the daily removal there from of
rubbish, filth and carcasses of animals.(5)The council may, by resolution, exempt any class of
buildings or lands from the property tax(i)x x x x(ii)If the annual rental value of the same does not
exceed Rs. 300/- in the case of owner occupied residential buildings within the municipal
limits:Provided that in respect of houses constructed for urban poor, the municipality shall collect
one rupee for every half-year towards property tax.(iii)the person to be assessed does not own any
other building or land assessed to the property tax and is not liable to profession tax or income tax.
89. Taxation to be uniform.
- Save as otherwise provided in this Act, the rate of any class of property tax on lands, when levied
on their capital value, or the rate of any class of property tax on lands, when levied on their annual
rental value, may be lower than the rate of the same class of property tax on buildings and there
shall be uniformity in the levy of each such rate throughout the municipal area in respect of the
lands or buildings as the case may be.
90. Property tax a first charge on property.
- The property tax on buildings and lands shall, subject to the prior payment of land revenue, if any,
due to the Government thereon, be a first charge upon the said buildings or lands and upon the
movable property, if any found, within or upon the same and belonging to the person liable to such
tax. If the tax due in respect of a building or land under this section is not paid within the time
specified therefor, it may be recovered in the first instance by distraint under the warrant of the
Commissioner, and sale of movable property of the defaulter and if for any reason, the distraint or a
sufficient destraint of the defaulter's movable property is impracticable, the tax may be recovered by
attachment and sale of the said building or land in such manner as may be prescribed.
91. Property tax when payable.
- The property tax shall be levied every half-year and shall, save as otherwise expressly provided in
Schedule II, be paid by the owner of the assessed premises within thirty days after the
commencement of the half-year.Provided that a simple interest at the rate of two percent per men
sum shall be charged in case of failure to pay property tax within the due date.Provided further that
when payment of property tax is not made within the due date, the Commissioner may, after giving
notice to the owner or occupier, disconnect the essential services to the premises:Provided also that
all the taxes and dues to the Municipality including the property tax payable to the Municipality
shall be liable to be recovered as if they were areas of land revenue.
91A. Power to correct the assessment records.
(1)If at any time it appears to the council that any person or property has been inadvertently omitted
from the assessment records or inadequately or improperly assessed relating to any tax, or a clericalAndhra Pradesh Municipalities Act, 1965

or arithmetical error is committed in the records maintained in relation to such assessment, it may
direct the Commissioner to assess or reassess or correct the errors as the case may be:Provided that
no such direction shall be given where it involves an increase in the assessment unless the person
affected is afforded an opportunity to show cause against the proposed action.(2)Such assessment or
reassessment or correction of records shall not relate, to a period earlier than the five half-years
immediately preceding the current half-year.
92. Vacancy remission.
(1)When any building or land or any portion of any premises which has been treated as a separate
property for the purposes of assessing the property taxes has been vacant thirty or more consecutive
days in the half year the Commissioner shall, subject to the provisions hereinafter contained, remit
the property taxes, if any, to a maximum of one half of the amount paid in respect of taxes for the
number of days that such vacancy lasted.(2)For the purpose of sub-section (1),(a)premises shall be
deemed to be vacant only if they are unoccupied and unproductive of rent;(b)premises shall be
deemed to be productive of rent, if let to a tenant having a continuing right of occupation thereof,
whether they are actually occupied by such tenant or not;(c)premises furnished or reserved by the
owner for his own occupation whenever required shall be deemed to be occupied whether they are
actually occupied by the owner or not,(d)premises used or intended to be used for the purposes of
any industry which is seasonal in character shall not be deemed to be vacant merely on account of
their being unoccupied and unproductive of rent during such period or periods of the half-year in
which seasonal operations are normally suspended;(e)a vacancy which has continued during the
whole of the month of February shall be deemed to have continued for not less than thirty
consecutive days.(3)Every demand for remission under sub-section (1) shall be made during the
half-year in respect of which the remission is sought or in the following half-year and not after
wards.(4)(a)No demand for such remission shall be entertained unless the owner of the building,
land or premises or his agent has previously thereto delivered notice to the Commissioner. (i) that
the building, land or premises is vacant and unlet; or (ii) that the building, land or premises will be
vacant and unlet from a specified date either in the half-year in which notice is delivered or in the
succeeding half-year.(b)No demand for such remission shall be entertained in the case of a person
who is in arrears of property tax due by him otherwise than in a fiduciary capacity to the
municipality, in respect of which a bill has been duly served upon him and the time, if any, specified
therein for payment has expired.(c)The period in respect of which the remission is made shall be
calculated(i)if remission is sought in respect of the half-year in which notice is delivered, from the
date of delivery of the notice or from the date on which the building, land or premises became
vacant and unlet whichever is later; and(ii)If remission is sought in respect of the half-year
succeeding that in which the notice is delivered, from the commencement of the half-year in respect
of which remission is sought or from the date on which the building, land or premises became
vacant and unlet, whichever is later.(d)Every notice under clause (a) shall expire which the half-year
succeeding that during which it is so delivered and shall have no effect thereafter.Andhra Pradesh Municipalities Act, 1965

93. Obligation of transferor and transferee to give notice of transfer.
(1)Whenever the title of any person, primarily liable to the payment of property tax on any premises,
to or over such premises is transferred, the person whose title is transferred and the person to whom
the same shall be transferred shall, within three months after the execution of the instrument of
transfer or after its registration if it be registered, or after the transfer is effected, if no instrument be
executed, give notice of such transfer to the Commissioner.(2)In the event of the death of any person
primarily liable as aforesaid, the person to whom the title of the deceased shall be transferred as heir
or otherwise shall give written notice of such transfer to the Commissioner within one year from the
death of the deceased.(3)The notice to be given under this section shall be in such form as the
Commissioner may direct and the transferee or the person to whom the title passes, as the case may
be, shall, if so required, be bound to produce before the Commissioner any documents evidencing
the transfer or succession.(4)Every person who makes a transfer as aforesaid without giving such
notice to the Commissioner shall in addition to any other liability which he incurs through such
neglect, continue to be liable for the payment of property tax assessed on the premises transferred
until he gives notice or until the transfer shall have been recorded in the municipal registers, but
nothing in this section shall be held to affect(a)the liability of the transferee for the payment of the
said tax; or(b)the prior claim of the council under Section 90.
94. Owner's obligation to give notice of construction, reconstruction or
demolition of building.
(1)(a)If any building in a municipality is constructed or reconstructed, the owner shall give notice
thereof to the Commissioner within thirty days from the date of completion or occupation of the
building whichever is earlier.(b)If such date falls within the last two months of a half-year, the
owner shall subject to notice being given under clause (a), be entitled to a remission of the whole of
the tax or enhanced tax, as the case may be, payable in respect of the building only for that
half-year.(c)If such date falls within the first four months of a half-year, the owner shall, subject to
notice being given under Clause (a) be entitled to a remission of so much, not exceeding a half of the
tax or enhanced tax, as the case may be, payable in respect of the building only, for that half-year. as
is proportionate to the number of days in that year preceding such date.(2)(a)If any building in a
municipality is demolished or destroyed, the owner shall, until notice thereof is given to the
Commissioner, be liable for the payment of the property tax which would have been leviable had the
building not been demolished or destroyed.(b)If such notice is given within the first two months of a
half-year, the owner shall be entitled to a remission of the whole of the tax payable in respect of the
building for that half-year.(c)If such notice is given within the last four months of a half-year, the
owner shall be entitled to a remission of such sum not exceeding a half of the tax payable in respect
of the building for that half-year as is proportionate to the number of days in that half-year
succeeding the demolition or destruction, as the case may be.
95. Power of Commissioner or valuation officer to call for information and to
enter upon premises.Andhra Pradesh Municipalities Act, 1965

(1)For the purpose of assessing the property tax, the Commissioner or valuation officer appointed
under Rule 9 of Schedule II, may, by notice, call on the owner or occupier of any land or building to
furnish him, within thirty days after the service of the notice, where the notice is served upon the
Government, Railway Administration or a company and within seven days after service in other
cases, or which such further period, not exceeding seven days, as may be specified by the
Commissioner or valuation officer, with returns of the rent payable for the land or building, the cost
of erecting the building and the measurements of the land with such other information as the
Commissioner or valuation officer may require; and every owner and occupier on whom such notice
is served shall be bound to comply with it and to make a true return to the best of his knowledge or
belief.(2)For the purpose aforesaid the Commissioner or Valuation Officer or any other person
authorised by them in this behalf may enter, inspect, survey and measure such building or land after
giving reasonable notice to the owner or occupier.
96. Tax on Carriages and Carts.
- x x x x
97. Tax on Carriages and Carts.
- x x x x
98. Tax on Carriages and Carts.
- x x x x
99. Tax on Carriages and Carts.
- x x x x
100. Tax on Carriages and Carts.
- x x x x
101. Tax on Carriages and Carts.
- x x x x
102. Tax on Carriages and Carts.
- x x x xAndhra Pradesh Municipalities Act, 1965

103. General provisions regarding tax on carriages and carts.
(1)If the council by a resolution determines that a tax on carriages and a tax on carts shall be levied,
the Commissioner shall take steps to levy the said tax yearly on carriages and carts kept or used
within the municipality.(2)The rates of tax shall be determined by the council, provided that in no
case they shall exceed the maximum laid down in Schedule II in respect of carriages, and in respect
of carts, such rates shall not exceed eight rupees per cart per year.
104. Liability to tax according to period for which carriage has been kept.
(1)Every person having possession, custody or control of any taxable carriage shall be liable for the
yearly tax, if the carriage has been kept or used within the municipality for an aggregate period of
not less than one hundred and twenty days in the year.(2)If such aggregate period exceeds thirty
days but is less than one hundred and twenty days, a moiety of the yearly tax shall be leviable.(3)If
such aggregate period does not exceed thirty days, no tax shall be leviable for the year.(4)Every
person having possession, custody or control of any taxable carriage within the municipality shall,
until the contrary is shown, be presumed to have kept or used the same within the municipality for
one hundred and twenty days in the year.
105. Cart liable to tax to be registered.
(1)Every owner of any such cart shall register it once in every year in the municipal office.(2)The
council may direct that a municipal number shall be affixed to every registered cart.(3)The
Commissioner shall notify certain days in every year for the registration and numbering of carts and
the payment of the tax.(4)All registrations made and numbers affixed under this Section shall be
entered in a book to be kept for the purpose at the municipal office.(5)Such book shall be open at all
reasonable times to the inspection, free of charge, by any person who pays any tax to the
municipality.(6)No tax shall be levied on any cart which is shown to the satisfaction of the
Commissioner to have been kept or used within the municipality for an aggregate period not
exceeding thirty days in an year.
106. Non-liability to tax in certain cases.
- Notwithstanding anything in Section 104, no person shall be liable(a)to pay tax to the municipality
during any year on any carriage or cart in respect of which the tax for the same year has already
been paid to the municipality by some other person; or(b)to pay to the municipality on any carriage
or cart in respect of which tax has already been paid to any other municipality or any other local
authority or cantonment board, whether under this Act relating to such other local authority or the
Cantonments Act, 1924 (Central Act 2 of 1924) more than the excess, if any of the tax payable in the
municipality in respect of such carriage or cart over the tax already paid to the other municipality,
the other local authority or the cantonment board, as the case may be.Andhra Pradesh Municipalities Act, 1965

107. Exemptions.
- A carriage or cart tax shall not be levied on-(a)carriages or carts belonging to the Government and
used for defence purposes;(b)carriages or carts belonging to the council;(c)carriages or carts kept
solely for sale by carriage or cart makers and dealers;(d)carriages or carts which have been under
repair or kept by a carriage or cart maker during the whole of the year;(e)children's parambulators
and tricycles;(f)carriages or carts kept solely to be used for the conveyance of the sick, the injured or
the dead, free of charge.(g)private bicycles and owner driven rickshaws.
108. Compounding of tax.
- With the sanction of the council or in accordance with regulations framed by that body, the
Commissioner may compound, for at any period with any livery stable keeper or other person
keeping carriages for sale or hire, for a certain sum to be paid in lieu of the carriage tax.
109. Forms to be sent to and returned by tax payers.
(1)The Commissioner shall send to every person liable to the tax on carriages a printed table to be
filled up with such information respecting the carriages kept or used by him as the Commissioner
considers necessary for the assessment of the tax.(2)Such table shall be filed up with such
information in writing and signed and dated and returned within thirty days of its receipt to the
municipal office by the person to whom it has been sent.(3)On the expiry of the period of thirty days
referred to in sub-section (2), the Commissioner shall cause a notice to be served on such person
requiring him to pay within thirty days of the date of such service the sum for which, in the opinion
of the Commissioner such person is liable on account of the tax on carriages.
110. Grant of licence to carriages on payment of tax and prepayment of tax --
conditions precedent to registration of carriages.
(1)When any person pays the amount of tax due in respect of any carriage the Commissioner shall
grant him a licence to keep or use such carriage for the period to which the payment
relates.(2)Where the Andhra Pradesh (Andhra Area) Hackney Carriages Act, 1911 (Act V of 1911), or
any other law similar thereto for the time being in force, is in force in any area of a municipality, the
person appointed to perform the functions of the Commissioner under the said Act or law in respect
of such area shall, before registering any carriage thereunder, satisfy himself that the council has
received payment of the tax, if any, due under Section 103 on account of the last preceding year and
the current year.
111. Power to require numbers to be affixed to bicycles etc.
(1)The Commissioner may direct that a municipal number shall be affixed(a)to every carriage let out
for hire within the municipality; and(b)to every bicycle and tricycle kept or used within the
municipality.(2)The numbers affixed under sub-section (1) shall be registered in the municipalAndhra Pradesh Municipalities Act, 1965

office.(3)The owner of every carriage, bicycle or tricycle shall pay such fee as the Commissioner may
fix towards the cost of the plate or disc containing the number.
112. Seizure of vehicles not bearing numbers.
(1)If a municipal number is not affixed to a cart or carriage (hereinafter referred to as vehicle) in
pursuance of a direction issued under Section 105 or Section 111, as the case may be, the
Commissioner may, at any time, seize and detain the vehicle and the animal, if any, by which it is
drawn:Provided that no vehicle other than bicycle, or tricycle shall be seized or detained when
actually employed in the conveyance of any passenger or goods.(2)If the vehicle or animal seized be
not claimed and the tax due thereon be not paid within ten days from the date of seizure, the
Commissioner may direct that the vehicle or animal shall be sold in public auction and the proceeds
of the sale applied to the payment of--(i)the tax, if any, due on the vehicle or animal sold;(ii)such
penalty not exceeding the amount of the tax as the Commissioner may direct and(iii)the charges
incurred in connection with the seizure, detention and sale.(3)If the owner of the vehicle or animal
or other person entitled thereto claims the same within ten days from the date of seizure or at any
time before the sale, it shall be returned to him on payment of--(i)the tax due thereon;(ii)such
penalty not exceeding the amount of the tax as the Commissioner may direct; and(iii)the charges
incurred in connection with the seizure and detention Tax on Animals
113. Tax on Animals.
(1)If the council by a resolution determines that a tax on animals shall be levied, the Commissioner
shall take steps to levy the said tax yearly on the animals which are kept or used within the
municipality and which are of the kinds specified in Schedule II.(2)The rates of tax shall be
determined by the council provided that in no case they shall exceed the maximum laid down in
Schedule II.(3)The provisions of Sections 104 and 106 to 110 in so far as they relate to the levy of tax
on carriages shall, with the necessary modifications, apply to the levy of tax on animals.
114. Tax on advertisements.
- Every person who erects, exhibits, fixes, or retains upon or over, any land, building, wall, hoarding
or structure, any advertisement or who displays any advertisement to public view in any manner
whatsoever, in any place whether public or private, shall pay on every advertisement which is so
erected, exhibited, fixed, retained or displayed to public view, a tax calculated at such rates and in
such manner and subject to such exemptions as the council may, with the approval of the
Government, by resolution determine:Provided that the rates shall be subject to the maximum and
minimum laid down by the Government in this behalf:Provided further that no tax shall be levied
under this section on any advertisement or a notice--(a)of a public meeting; or(b)of an election to
any legislative body or to the council; or(c)of a candidature in respect of such an election:Provided
also that no such tax shall be levied on any advertisement which is not a sky-sign and which--(a)is
exhibited within the window of any building; or(b)relates to the trade or business carried on within
the land or building upon or over which such advertisement is exhibited or to any sale, or letting of
such land or building or any effects therein or to any sale, entertainment or meeting to be held uponAndhra Pradesh Municipalities Act, 1965

or in the same; or(c)relates to the name of the land or building upon or over which the
advertisement is exhibited or to the name of the owner or occupier of such land or building;
or(d)relates to the business of any railway administration; or(e)is exhibited within any railway
station or upon any wall or other property of a railway administration except any portion of the
surface of such wall or property fronting any street.Explanation I. - The word "structure" in this
section shall include any movable board on wheels used as an advertisement or an advertisement
medium.Explanation II. - The expression "sky-sign" shall, in this section, mean any advertisement,
supported on or attached to any post, pole, standard, frame-work or other support wholly or in part
upon or over any land, building, wall or structure, which, or any part of which, shall be visible
against the sky from some point in any public place and includes all and every part of any such post,
pole, standard, frame-work or other support. The expression "sky-sign" shall also include any
balloon, parachute or other similar device employed wholly or in part for the purposes of any
advertisement upon or over any land, building or structure or upon or over any public place but
shall not include--(a)any flagstaff, pole, vane or weathercock, unless adapted or used wholly or in
part for the purpose of any advertisement: or(b)any sign or any board, frame or other contrivance
securely fixed to or on the top of the wall or parapet of any building or on the cornice or blocking
course of any wall or to the ridge of a roof:Provided that such board, frame or other contrivance be
of one continuous face and not open work, and does not extend in height more than one metre
above any part of the wall, or parapet or ridge, to against or on which it is fixed or supported;
or(c)any advertisement relating to the name of the land or building upon or over which the
advertisement is exhibited or to the name of the owner or occupier of such land or building;
or(d)any advertisement relating exclusively to the business of a railway administration and placed
wholly upon or over any railway, railway station, yard, platform or station approach belonging to a
railway administration and so placed that it cannot fall into any street or public place; or(e)any
notice of land or building to be sold or let, placed upon such land or building.Explanation III. -
"Public place" shall, for the purpose of this section, means any place which is open to the use and
enjoyment of the public, whether it is actually used or enjoyed by the public or not.
115. Prohibition of advertisements without written permission of
Commissioner.
(1)No advertisement shall be erected, exhibited, fixed or retained upon or over any land, building,
wall, hoarding or structure within the municipality or shall be displayed in any manner whatsoever
in any place without the written permission of the Commissioner.(2)The Commissioner shall not
grant such permission if--(i)the advertisement contravenes any bye-laws made by the council under
clause (3) of Section 330; or(ii)the tax, if any, due in respect of the advertisement has not been
paid.(3)Subject to the provisions of sub-section (2) in the case of an advertisement liable to the
advertisement tax, the Commissioner shall grant permission for the period to which the payment of
the tax relates and no fees shall be charged in respect of such permission;Provided that the
provisions of this Section shall not apply to any advertisement relating to the business of a railway
administration erected, exhibited, fixed or retained on the premises of such administration.Andhra Pradesh Municipalities Act, 1965

116. Permission of the commissioner to become void in certain cases.
- The permission granted under Section 115 shall become void in the following cases, namely:-(a)if
the advertisement contravenes any bye-law made by the council under clause (30) of Section
330;(b)if any addition to the advertisement be made except for the purpose of making it secure
under the direction of Municipal Engineer, or the Commissioner;(c)if any material change be made
in the advertisement or any part thereof;(d)if the advertisement or any part thereof falls otherwise
than through accident;(e)if any addition or alteration be made to or in the building, wall or structure
upon or over which the advertisement is erected, exhibited, fixed or retained, if such addition or
alteration involves the disturbance of the advertisement or any part thereof; and(f)if the building,
wall or structure upon or over which the advertisement is erected, exhibited, fixed or retained, be
demolished or destroyed.
117. Owner or person in occupation to be deemed responsible.
- Where any advertisement is erected, exhibited, fixed or retained upon or over any land, building,
wall, hoarding or structure in contravention of the provisions of Section 114 or Section 115 or after
the written permission for the erection, exhibition, fixation or retention therefor for any period has
expired or become void, the owner or person in occupation of such land, building, wall, hoarding or
structure shall be deemed to be the person who has erected, exhibited, fixed or retained such
advertisement in such contravention, unless, he proves that such contravention was committed by a
person not in his employment or under his control or was committed without his connivance.
118. Removal of unauthorised advertisements.
- If any advertisement is erected, exhibited, fixed or retained contrary to the provisions of Section
114 or Section 115 or after the written permission for the erection, exhibition, fixation or retention
thereof for any period has expired or become void, the Commissioner may, by notice in writing
require the owner or occupier of the land, building, wall, hoarding or structure upon or over which
the same is erected, exhibited, fixed or retained, to take down or remove such advertisement or may
enter any building, land or property and have the advertisement removed, and the costs thereof
shall be recoverable in the same manner as property tax.
119. Collection of tax on advertisements.
- The Commissioner may farm out the collection of any tax on advertisement leviable under Section
114 for any period not exceeding one year at a time on such terms and conditions as may be
determined by the council.
120. Method of assessments of duty on transfers of property.
- The duty on transfers of property shall be levied(a)in the form of a surcharge on the duty imposed
by the Indian Stamp Act, 1899, (Central Act 2 of 1899) for the time being in the State, on everyAndhra Pradesh Municipalities Act, 1965

instrument of the descriptions specified below, in respect of the whole or part of the immovable
property, as the case may be, situated within the limits of a municipality; and(b)at such rate as may
be fixed by the Government, not exceeding five per centum on the amount specified below against
such instrument; Description of instrument Amount on which duty shall be levied(i)Sale of
immovable property. The amount of value of the consideration for the sale, as set-forth in the
instrument or the market value of the property which is the subject matter of the sale whichever is
higher(ii)Exchange of immovable property The market value of the property of greater value, which
is the subject matter of exchange.(iii)Gift of immovable property The market value of the property
which is the subject matter of the gift.(iv)Mortgage with possession of immovable property The
amount secured by the mortgage, as set forth in the instrument.(v)Lease for a term exceeding one
hundred years or in perpetuity of immovable property An amount equal to one-sixth of the whole
amount or value of the rents which would be paid or delivered in respect of the first fifty years of the
lease as set forth in the instrument.
121. Provisions of the Indian Stamps Act, 1899, applicable on the
introduction of duty on transfers of property.
- On the introduction of the duty on transfers of property--(a)Section 27 of the Indian Stamp Act,
1899 (Central Act 2 of 1899) shall be read as if it specifically requires the particulars to be set forth
separately in respect of property situated within the limits of a municipality and outside such limits;
and(b)Section 64 of the same Act shall be read as if it referred to the Council concerned as well as
the Government.
122. Power to make rules regarding assessment and collection of duty on
transfer of property.
- The Government may make rules not inconsistent with this Act for regulating the collection of the
duty on transfer of property, the payment thereof to the councils concerned and the deduction of
any expenses incurred by the Government in the collection thereof.
123. [ [Omitted by Act No. 16 of 2011, dated 26.4.2011.]
***]
123. Compensation to Municipalities towards loss of income from tolls, etc.- (1) Notwithstanding
anything in any law for the time being in force, there shall be paid from the Consolidated Fund of
the State annually or at such period as may be specified by the Government, from time to time(i) to
each municipality specified in Schedule VIII which was constituted prior to the first day of April
1961;(a) in the Andhra Area, the sum shown against the municipality in Part A of that Schedule, as
compensation for the loss of income from tolls or vehicle tax on motor vehicles or both which the
said municipality was deriving under the proviso to Section 10 (1) (a) (v) of the Andhra Pradesh
(Andhra Area) Motor Vehicles Taxation Act, 1931, (Act III of 1931) before the said proviso was
omitted by the Madras Motor Vehicles Taxation (Andhra Amendment) Act 1956 (Act III ofAndhra Pradesh Municipalities Act, 1965

1956).(b) in the Telangana area, the sum shown against the municipality in Part B of that Schedule,
as compensation for the loss of income from tolls on animals and Vehicles which the municipality
was levying under Section 107 of the Andhra Pradesh (Telangana Area) District Municipalities Act,
1956, (Acts XVIII of 1956) before the said section was omitted by Section 3 of the Hyderabad
Municipal Corporation and Andhra Pradesh (Telangana Area) District Municipalities (Andhra
Pradesh Amendment) Act, 1961 (Act XXXVIII of 1961).(ii) to each municipality constituted on or
after the 1st day of April, 1961-(a) in the Andhra area, a sum equal to the average annual income
derived by the district board from tolls or vehicle tax on motor vehicles or both during the three
years ending on the 31st day of March 1961 within the area for which the municipality was
constituted, from out of the sum payable to the Zilla Parishad which is now functioning in the place
of such district board;(b) in the Telangana area, a sum equal to the average annual income derived
by the district board from the tolls on animals and vehicles, during the three years ending on the
31st day of March, 1961 within the area for which the municipality was constituted; from out of the
sum payable to the Zilla Parishad which is now functioning in the place of such district
board:Provided that if it is not possible to determine such annual income in the case of any
municipality, the sum payable to the municipality under Sub-clause (a) or sub-clause (b) of this
clause shall be determined by the Government in consultation with the Zilla Parishad concerned as
provided in Sub-section (3) of this section;(iii) to each municipality specified in Part C of that
Schedule, the sum shown thereof, as compensation for the loss in income due to the abolition of
fees or licences granted to motor vehicles which the said municipality was deriving under Section 10
(1) (a) (iv) of the Andhra Pradesh (Andhra Area) Motor Vehicles Taxation Act, 1931 (Act III of
1931).(iv) to each municipality in the State constituted prior to the 1st day of April, 1963-(a) in the
Andhra area, a sum calculated at the rate of thirty paise per head of population at the last census in
the municipality towards the loss of income on account of the abolition of fees for the use of
cart-stand levied on motor vehicles, if such municipality was deriving any income from fees during
any one of the three years immediately preceding that day;(b) in the Telangana area a sum
calculated at the rate of thirty paise per head of population at the last census, in the municipality
towards the loss of income on account of the abolition of tax on motor vehicles, if such municipality
was deriving any income from that tax during any one of the three years immediately proceeding
that day.(2) The Government shall determine the amounts payable to the municipalities under
clause (ii) of sub-section (1) and the said determination shall be final.(3) In determining the amount
payable to the municipalities under Clause (ii) of sub-section (1), the Government shall take into
account(a) the arrears of tolls or vehicles tax on motor vehicles or both left uncollected which could
have been collected; and(b) the amounts which the municpalities or the Zilla Parishads should have
paid to any other local authority constituted under any enactment for the time being in force on
account of collections made on behalf of such local authority and remaining to be adjusted.(4)
Notwithstanding anything contained in the foregoing sub-sections, the Government may vary the
amount or rate of compensation payable to the municipality;Provided that no such variation shall
be made to the disadvantage of the municipality.(5) The Government may impose a suitable cut in
the amounts of grants or as the case may be the compensation to be released in respect of
Municipalities whose tax collection is less than eighty-five per cent of the demand of of each year.Andhra Pradesh Municipalities Act, 1965

124. Power to write off irrecoverable taxes, etc.
- The council may write off any tax, fee or other amount whatsoever due to it, whether under a
contract or otherwise, or any sum payable in connection therewith, if, in its opinion, such tax, fee,
amount or sum is irrecoverable.
Chapter 2
Finance Municipal Fund
125. Definition of Municipal Fund.
- All moneys received by the council shall constitute a fund which shall be called the municipal fund
and shall be applied and disposed of subject to the provisions of this Act or other laws. Budget
126. Budget estimate.
- The council shall, in each year, frame a budget showing the probable receipts and the expenditure
which it proposes to incur during the following year and shall submit a copy of the budget to the
Government before such date as may be fixed by them in that behalf. The budget shall contain
provisions, adequate in the opinion of the Government, for the due discharge of all liabilities in
respect of loans contracted by the council, for the maintenance of a working balance, and for the
execution of such works as the Government may undertake or approve under Section 65. If the
budget as submitted to the Government fails to make those provisions, the Government may modify
any part of the budget so as to ensure that such provisions are made.
127. Revised or supplementary budget.
- If, in the course of a year, a council finds it necessary to modify the figures shown in the budget
with regard to its receipts or to the distribution of the amounts to be expended on the different
services it undertakes, it may submit a supplemental or revised budget provided that no alteration
shall be made without the consent of Government in the amount allotted for the service of debt or in
the working balance.
127A. [ Preparation of annual accounts. [Inserted by Act No. 22 of 2011, dated
27.12.2011.]
(1)The Commissioner shall prepare annual accounts in such form with such information, as may be
prescribed. In particular, the annual accounts comprises the financial statements consisting of
income and expenditure, assets and liabilities, and receipts and payments.(2)The annual accounts
shall be prepared within such time as may be prescribed and be placed before the Council for
approval.(3)On approval by the Council, the annual accounts shall be forwarded to the auditor
appointed by the Government for audit.]Andhra Pradesh Municipalities Act, 1965

128. Appointment of auditors [to audit the annual accounts] [Substituted 'of
accounts of receipts and expenditure' by Act No. 22 of 2011, dated
27.12.2011.].
- The Government shall appoint auditors of the accounts of receipts and expenditure of the
municipal fund. Such auditors shall be deemed to be 'public servants' within the meaning of Section
21 of the Indian Penal Code.
129. Contribution to expenditure by other local authorities.
(1)If the expenditure incurred by the Government or by any other municipality to which this Act
applies or by any other local authority in the State for any purpose authorised by or under Part II of
Schedule II is such as to benefit the inhabitants of a municipality, the council may, with the sanction
of the Government, make a contribution towards such expenditure.(2)The Government may direct a
council to show cause, within a month after receipt of the order containing the direction, why any
contribution described in sub-section (1) should not be made.(3)If the council fails to show cause
within the said period to the satisfaction of the Government, the Government may direct it to make
such contribution as they may specify and it shall be paid accordingly.
130. Application of Schedule II.
- The rules and tables embodied in Schedule II shall be read as part of this chapter. Loans and
Advances
131. Guarantee of Government of principal of, and interest on, the loans
floated by council for purposes of the Act.
(1)The principal of and, interest on the loans floated by a council, to such maximum amount as may
be fixed by the Government and subject to such condition as they may think fit to impose, shall carry
the guarantee of the Government.(2)The Government may increase the maximum amount of any
guarantee given by them.(3)The Government may, after consulting the council,-(a)by notification in
the Andhra Pradesh Gazette, and(b)by notice for not less than fourteen days in such of the principal
newspapers in the municipality as the Government may select in this behalf. discontinue any
guarantee given by them or restrict the maximum amount thereof or modify the conditions subject
to which it is given with effect from a specified date not being earlier than six months from the date
of publication of the notification in the Andhra Pradesh Gazette;Provided that in cases where the
maximum amount of the guarantee is to be restricted or the conditions subject to which the
guarantee is given are to be modified, the notification and notice aforesaid shall set forth with
sufficient clearness the scope and effect of the restriction or modifications.Provided further that the
withdrawal, restriction or modification of any guarantee under this sub-section shall not affect in
any way the guarantee carried by any loan taken prior to the date on which such withdrawal,
restriction or modification takes effect.Andhra Pradesh Municipalities Act, 1965

132. Recovery of loans and advances made by the Government.
- Notwithstanding anything in the Local Authorities Loans Act, 1914, (Central Act 9 of 1914), or any
other law similar thereto for the time being in force, the Government shall be entitled to recover in
the manner provided by sub-section (1) of Section 64 of this Act or by suit, any loan or advance
made to any council for any purpose to which the funds of the said council may be applied under
this Act.
132A. Finance Commission.
(1)The Finance Commission constituted by the Governor in pursuance of Article 243-I of the
Constitution shall also review the financial position of the Municipalities and make
recommendations to the Government as to,(a)the principles which should govern,(i)the distribution
between the State and the Municipalities of the net proceeds of the taxes, duties, tolls and fees
leviable by the State, which may be divided between them under this part and the allocation between
the Municipalities of their respective shares of such proceeds;(ii)the determination of the taxes, tolls
and fees which may be assigned to or appropriated by the Municipalities;(iii)the grants-in-aid to the
Municipalities from the Consolidated Fund of the State;(b)the measures needed to improve the
financial position of the Municipalities;(c)any other matter referred to the Finance Commission by
the Government in the interests of sound finances of the Municipalities.(2)The Government shall
cause every recommendation made by the Commission under this article together with an
explanatory memorandum as to the action taken thereon to be laid before the Legislative Assembly
of the State.
Part 5 – Public Health, Safety and Convenience
Chapter 1
Water-supply Lighting and Drainage
133. Vesting of works in councils.
(1)All public water courses and springs, all public reservoirs, tanks, cisterns fountains, wells,
stand-pipes and other water- works existing at the commencement of this Act or after wards made,
laid or erected, and whether made, laid or erected at the cost of the council or otherwise, and also
any adjacent land, not being private property, appertaining thereto shall vest in the council and be
subject to its control;Provided that nothing in this section shall apply to any work which is, or is
connected with, a work of irrigation or to any adjacent land appertaining to any such work(2)The
Government may, by notification in the Andhra Pradesh Gazette, limit or define such control or may
assume the administration of any public source of water-supply and public land adjacent and
appertaining thereto after consulting the council and giving due regard to its objections, if any.Andhra Pradesh Municipalities Act, 1965

134. Construction and maintenance of water-works.
(1)The council may, with the sanction of the Government direct the construction of such works as it
deems fit outside the limits of the municipality for supplying it with water and may provide
channels, tanks, reservoirs cisterns, engines, mains, wells, fountains, stand-pipes and other works as
it may deem fit within the said limits for the use of the inhabitants.(2)The council may cause
existing works, for the supply of water to be maintained and supplied with water, or it may close any
such works and may cause them to be maintained and supplied with water.(3)The council may, if it
deems fit, entrust water and drainage works to private firms, with the previous approval of the
Government.
135. Constitution of water boards for local authorities.
(1)Notwithstanding anything in Section 133, the Government may constitute a water board for one
or more municipalities or other local authorities for the construction and maintenance of water
works for the supply of water to such municipalities or local authorities.(2)The local authority or
authorities, for which water board is constituted under sub-section (1), shall, subject to such
conditions as may be prescribed, be bound to take water from such water board on and from the
date of completion of the construction or the commencement of the maintenance of a water works
by such water board.
136. Trespass on premises connected with water supply.
- It shall not be lawful for any person except with permission duly given and obtained to enter upon
land belonging to, or vested in, a council along which a conduit or pipe runs, or upon any premises
connected with the water-supply.
137. Prohibition of building over water mains.
(1)Without the permission of the council, no building, wall or other structure shall be newly erected
and no street or railway shall be constructed over any municipal water mains.(2)If any building, wall
or other structure be so erected or any street or railway be so constructed, the council may cause the
same to be removed or otherwise dealt with as shall appear to it fit, and the expenses thereby
incurred shall be paid by the persons offending.
138. Council to provide water for use.
- The council shall so far as the funds at its disposal may admit, provide a sufficient supply of water
fit for the use of the inhabitants.Andhra Pradesh Municipalities Act, 1965

139. Control over connections.
- All connections whether within or outside the premises to which they belong, with any
water-supply mains constructed by a council shall be under the control of the council, but shall be
altered, repaired and kept in proper order at the expense of the owner of the premises to which they
belong or for the use of which they were constructed and in conformity with bye-laws and
regulations framed by the council in this behalf.
140. Private water-supply for consumption and use and power of the
Chairperson to enforce provision of water supply.
(1)In municipalities in which there is a pipe supply of water the Chairperson may, on application by
the owner or occupier of any building arrange, in accordance with the bye-laws, to supply water
thereto for consumption and use.(2)Whenever it appears to the Chairperson that any building
assessed, at an annual rental value of not less than three hundred rupees is without a proper supply
of water for consumption and use and that such a supply can be furnished from a main not more
than thirty metres distant from any part of such building, the Chairperson may, by notice, require
the owner to obtain such supply and to execute all such works as may be necessary for that purpose
in accordance with the bye-laws and regulations.(3)The cost of making the connections and the cost
of hire of meters shall be borne by the owner or applicant and shall be recoverable in the same
manner as the property tax.
141. Power of council to make bye-laws for water supply.
(1)For all water supplied under Section 140, payment shall be made on such basis, at such times,
and on such conditions as may be laid down in the bye-laws made by the council, and shall be
recoverable in the same manner as the property tax.(2)In particular and without prejudice to the
generality of the foregoing power, such bye-laws may-(a)provide for the classification of supply of
water under the following categories, namely:-(i)supply to residential buildings;(ii)supply to
residential hotels;(iii)supply to shops, commercial establishments (other than industrial
undertakings), restaurants, eating houses, the aters and places of public amusement or
entertainment;(iv)supply to industrial undertakings;(v)supply to non-residential buildings not
falling within the scope of category (ii), category (iii) or category (iv).Explanation. - In this clause,
unless the context otherwise requires, the expression `commercial establishment', `eating house',
`residential hotel', `restaurant', `shop', and `theatre', shall have the meanings assigned to them in
the Andhra Pradesh (Andhra Area) Shops and Establishments Act, 1947 (Act XXXVI of
1947);(b)provide for the levy of different rates of charge in respect of water supplied to the different
categories specified in clause (a);(c)in cases of supply to residential buildings, lay down the
maximum free allowances to be made and the rates of charge to be levied in respect of water
supplied in excess of such allowance; and(d)in cases of supply to all buildings lay down that the
charge for water supplied shall be based on the number of taps allowed, irrespective of the quantity
of water consumed.Andhra Pradesh Municipalities Act, 1965

142. Levy and collection of pipe-line service charges.
- The Government may, by notification, direct the council to levy and collect pipeline service charges
from every owner or occupier of a premises to which water connection has been given at such rate as
may be prescribed to the different categories specified in Clause (a) of sub-section (2) of Section 141
to defray the capital cost of pipeline service works undertaken by the Council and the operation and
maintenance of the pipeline system from time to time:Provided that no such charges shall be levied
on the owner or occupier of any premises situated in the areas which are not served by the pipeline
system of the Council.
143. Supply beyond the limits of municipality.
- The council may, with the sanction of the Government and shall, on the direction of the
Government, supply water to local authority or other person outside the municipality on such terms,
if any, as may be approved by the Government.
144. Power to disconnect water-supply.
(1)The Commissioner or any person authorised by him in this behalf may cause to disconnect the
supply of municipal water from any premises where-(a)the premises are unoccupied;(b)any water
tax or any sum due for water for the cost of making a connection or for the cost or hire of a meter or
for the cost of carrying out any work or test connected with the water-supply, which is chargeable to
any person by or under this Act, is not paid within fifteen days after a bill for such tax or sum has
been presented;(c)after receipt of a notice from the Commissioner requiring him to refrain from so
doing, the owner or occupier continues to use the water or to permit it to be used in contravention of
any bye-laws made under this Act;(d)the owner or occupier neglects within a period specified in any
notice issued by the Commissioner under any bye-law made under this Act to put a meter or to
comply with any other lawful order or requisition:(e)the owner or occupier wilfully or negligently
damages his metre or any pipe or tap conveying municipal water;(f)the occupier refuses to admit the
Commissioner or the person authorised into premises which he proposes to enter for the purpose of
executing any work or of placing or removing any apparatus or of making any examination or
inquiry in connection with the water supply, or prevents the Commissioner or the person authorised
from doing such work, placing or removing such apparatus or making such examination or
inquiry;(g)any pipes, taps, works or fittings connected with the municipal water-supply are found on
examination by the Commissioner or the person authorised to be out of repair to such an extent as
to cause waste or contamination of water;(h)the owner or occupier causes pipes, taps, works or
fittings connected with the municipal water supply to be placed, removed, repaired or otherwise
interfered with in violation of the bye-laws;Provided that in a case falling under clauses (e), (f), (g)
or (h), the Commissioner or the person authorised shall not take action, unless notice of not less
than twenty-four hours is given to the owner or occupier of the premises.(2)The expense of
disconnecting the supply shall be paid by the owner or occupier of the premises.(3)In cases falling
under clause (b) of sub-section (1), as soon as any money for non-payment of which water is
disconnected together with the expense incurred thereof is paid by the owner or occupier, the
Commissioner shall cause water to be supplied as before on payment of the costs, if any, ofAndhra Pradesh Municipalities Act, 1965

reconnecting the premises with the municipal water-works.(4)No action taken under this section
shall relieve any person from any penalties or liabilities which he may otherwise have incurred.
145. Non-liability of council for disconnection, or stoppage of supply in
certain cases.
- Notwithstanding anything in any agreement the council shall not be liable to any penalty or
damages for disconnecting supply of water or for not supplying water, in the case of any drought, or
other unavoidable cause or accident, or the necessity for relaying or repairing pipes. Lighting
146. Provision for lighting in public streets.
- The council shall, so far as the funds at its disposal permit, cause the public streets to be lighted
and for that purpose shall provide such lamps and works as it thinks necessary.
147. Maintenance of system of drainage by council.
- The council shall, so far as the funds at its disposal may permit, provide and maintain a sufficient
system of public drains.
147A. [ Acceptance of contributions towards the capital cost of underground
drainage. [Inserted by Act No. 6 of 1999, dated 25.3.1999]
- The Government may, by notification, direct the council to levy and collect pipe-line service
charges from every owner or occupier of a premises, to which underground drainage connection has
been given at such rate as may be prescribed to the different categories specified therein to defray
the capital cost of sewerage and sewage treatment works undertaken by the council and the
operation and maintenance of the sewerage system from time to time;Provided that no such charges
shall be levied on the owner or occupier of any premises situated in the areas which are not served
by the sewerage system by the council.]
148. Owners of buildings to pay for clearance of sullage from their buildings
by connecting their house-drains with public drains.
(1)For the discharge of drainage from private premises by connecting house-drains with municipal
drains, payment shall be made under any one of the basis mentioned in sub-section (2) which the
council may, by resolution, specify, at such times, and on such conditions as may be laid down in the
bye laws made by the council and shall be recoverable in the same manner as the property
tax.(2)The basis referred to in sub-section (1) shall be the following:(a)a monthly rent at such rate
for each building as may be laid down in the bye-laws;(b)such percentage of the capital value of the
building as may be laid down in the bye-laws;(c)the number of taps allowed, irrespective of the
quantity of water consumed.Andhra Pradesh Municipalities Act, 1965

149. Control over house drains, privies and cess pools.
- All house drains whether within or outside the premises to which they belong and all private
latrines and cess polls within the municipality shall be under the control of the council but shall be
altered, repaired, cleaned and kept in proper order at the expense of the owner of the premises to
which the same belong or for the use of which they were constructed, and in conformity with
bye-laws and regulations framed by the council in this behalf.
150. Connection of house-drains of private latrines with public drains of
underground sewers.
(1)The Commissioner shall, on an application by the owner or occupier of any permises or the owner
of private street, arrange in accordance with the bye-laws, for the connection of the applicant's drain
with any public drain, and where there is underground sewer, any private latrine with any
underground sewer, at a distance not exceeding one hundred meters therefrom at the applicant's
expense.(2)(a)If there is a public drain or underground sewer or out-fall within a distance not
exceeding thirty metres of the nearest point on any permises, or if within such distance, a public
drain or underground sewer or out-fall is about to be provided or is in the process of construction,
the Commissioner may, by notice, direct the owner or occupier of the said premises to construct a
drain leading therefrom to such drain or underground sewer or place of out-fall, and to execute all
such works, as may be necessary in accordance with the bye-laws and regulations at owner's
expense. (a) Where the said owner or occupier fails to comply with the notice specified in clause (a)
within fifteen days of its service, the Commissioner may construct the said drain and may direct that
the expenses of constructing it shall be recovered in the same manner as property tax.(3)If any
premises are, in the opinion Commissioner, without sufficient means of effectual drainage, but no
part thereof is situated within thirty metres of a public drain or underground sewer or its place of
out-fall, the Commissioner may, by notice, direct the owner or occupier of the said premises to
construct a cess-poll or septic tank or filters of such material, dimensions and description in such
position and at such level as the Commissioner thinks necessary, and to construct a drain or drains
emptying into such cess-poll, tank or filters, and to execute all such works as may be necessary in
accordance with the bye-laws and regulations.Provided that--(a)no requisition shall be made under
this section on any person who has been exempted from payment of the property tax under
sub-section (5) of Section 88; and(b)no person shall be required under this section to expend a sum
exceeding ten times the property tax on any such building, with the land assessed with it as part of
the same premises or, in the case of buildings exempted under Sec. 88, ten times the property tax
which would be payable on such building with the land which would be assessed with it to the
property tax, if such building were not exempt; and if any amount exceeding the said sum is
expended, the excess shall be borne by the council.
151. Commissioner may close or limit the use of existing private drains.
(1)Where a drain connecting any premises with a public drain or other place set apart by the council
for discharge of drainage is sufficient for the effectual drainage thereof and is otherwiseAndhra Pradesh Municipalities Act, 1965

unobjectionable, but is not, in the opinion of the Commissioner, adapted to the general drainage
system of the municipality or of the part of the municipality in which such drain is situated, the
Commissioner with the approval of the council may(a)subject to the provisions of sub-section (2),
close discontinue or destroy the said drain and do any work necessary for that purpose; or(b)direct
that such, drain shall, from such date as he specifies in this behalf, be used for sullage and sewage
only, or for water unpolluted with sullage or sewage only, and by notice require the owner of the
premises to make, at his own expense an entirely distinct drain for water unpolluted with sullage or
sewage or for sullage and sewage.(2)No drain may be closed, discontinued or destroyed by the
Commissioner under clause (a) of sub-section (1), except on condition of his providing another drain
as effectual for the drainage of the premises and communicating with a public drain or other place
aforesaid, and the expense of the construction of any drain so provided by the Commissioner and of
any work done under clause (a) of Section (1) shall be paid by the council.
152. Power of Commissioner to drain premises in combination.
(1)When the Commissioner is of opinion that any group or block of premises, any part of which is
situated within thirty metres of a municipal drain already existing or about to be provided or in the
process of construction, may be drained more economically or advantageously in combination than
separately, the Commissioner may cause such group or block of premises to be drained and the
expenses incurred by the Commissioner in so doing shall be paid by the owners in such proportions
as the Commissioner may decide.(2)Not less than fifteen days before any work under this section is
commenced, the Commissioner shall give notice to the owners of(a)the nature of the intended
work,(b)the estimated expenses thereof, and(c)the proportion of such expenses payable by each
owner:(3)The owners, for the time being, of the several premises constituting a group or block,
drained under subsection (1), shall be the joint owners of every drain constructed, erected or fixed,
or continued for the special use and benefit only of such premises and shall, in the proportion in
which it is determined that they are to contribute to the expenses incurred by the Commissioner
under sub-section (1), be responsible for the expense of maintaining every such drain in good repair
and efficient condition.
153. Building etc., not to be erected without permission over drains.
(1)Without the permission of the council, no person shall place or construct any fence, building
culvert, drain covering, drain or other structure or any street, railway or cable over, under, in or
across, any public drain, or stop up, divert, obstruct or in any way interfere with, any public drain,
whether it passes through public or private ground.(2)The Commissioner may remove or otherwise
deal with anything placed or constructed in contravention of Sub-section (1) as he shall think fit and
the cost of so doing shall be recoverable from the owner thereof in the manner provided in Section
364.
154. Construction of culverts or drain coverings by owner or occupier.
(1)The Commissioner may by notice require the owner or occupier of any building or land adjoining
a public street to construct culverts or drains-coverings over the side channels or ditches at theAndhra Pradesh Municipalities Act, 1965

entrances to the said building or land.(2)All culverts or drain-coverings or pails maintained over
side channels or ditches by the owners or occupiers of adjacent buildings or lands shall be of such
form and size and consist of such materials and be provided with such means of ventilation as the
Commissioner may by notice require and shall be maintained and kept free from all obstruction at
the expense of the said owners or occupiers.
155. Power to regulate discharge of water from building or land.
(1)The owner or occupier of any building in a public street shall, within fifteen days after receipt of
notice in that behalf from the Commissioner put up and thenceforward, keep and maintain in good
condition proper troughs and pipes built and fixed in accordance with the directions, if any, issued
by the Commissioner or contained in the bye-laws of the council, for catching and carrying the water
from the roof and other parts of such building and for discharging such water in such manner as the
Commissioner may permit.(2)For the purposes of efficiently draining any building or land the
Commissioner may, by notice-(a)require any court-yard, alley or passage between two or more
buildings to be paved by the owners of such buildings with such materials and in such manner as
may be approved by him; and(b)require such pavement to be kept in proper repair.
156. Provision of public latrines and urinals.
- The council shall, as far as the funds at its disposal may permit, provide and maintain in proper
and convenient places a sufficient number of public latrines and urinals and shall cause the same to
be daily cleaned and kept in proper order.
156A. Licensing of public latrines and urinals.
(1)On receipt of an application from any person in the prescribed form and on payment of the fee
prescribed, the Commissioner may issue a licence for a period not exceeding one year for
maintaining a latrine or urinal for public use.(2)No person shall keep or maintain a public latrine or
urinal without a licence under sub-section (1).(3)Every licensee of a public latrine or urinal shall
maintain it cleanly and keep it in proper order.
157. Provision of latrines by owner or occupier.
(1)The municipal health officer may by notice require the owner or occupier of any building within
the time specified in such notice to provide a latrine or alter or remove from an unsuitable to a more
suitable place any existing latrine in accordance with the direction contained in such notice for the
use of the persons employed in or about or occupying such building and to keep it clean and in
proper order.(2)Every owner or occupier of the ground on which any group of six or more huts
stand shall provide latrines of such description and number and in such position as the municipal
health officer may by notice require within such time as may be fixed in the notice for the use of the
inhabitants of such huts.(3)Where the owner or occupier of the building or ground has made any
default in providing any such latrine within the time specified, the Chairperson may construct theAndhra Pradesh Municipalities Act, 1965

latrine and may direct that the expense of constructing it shall be recovered in the same manner as
the property tax.
158. Provision of latrines for labourers.
- Every person employing workmen, labourers or other persons exceeding ten in number, shall
provide and maintain for the separate use of persons of each sex so employed, latrines of such
description and number and in such position, as the municipal health officer may, by notice require,
within such time as may be fixed in the notice.
159. Provision of latrines for markets, cart-stands, cattle sheds, choultries,
etc.
- The Municipal health-officer may by notice require the owner or manager of a market, cart-stand,
cattle-shed, country, theatre, railway station, dock, wharf or other place of public resort within the
time specified in such notice to provide and maintain for the separate use of persons of each sex,
latrines of such description and number and in such position as may be specified in such notice.
160. Latrines to be screened from view and kept clean.
- All latrines shall be so constructed as to screen persons using the same and the filth from the view
of the persons passing by or residing in the neighbourhood and shall be kept clean and in proper
order.
161. Power to carry wire, pipes, drains, etc., through private property subject
to causing as little inconvenience as possible and paying for direct damage.
- The Commissioner may carry any cable, wire, pipe, drain or channel of any kind to establish or
maintain any system of drainage, water-supply or lighting, through, across, under, or over any road,
street or place laid out for a road or street, and after giving reasonable notice to the owner or
occupier, through, across, under, over or up the side of any land or building in the municipality and
may place and maintain posts, poles, standards, brackets or other contrivances, to support wires and
lights on any pole or post in the municipality not vested in the Government and may do all acts
necessary for repairing or maintaining any such cable, wire, pipe, drain, channel, post, pole,
standard, bracket, or other similar contrivance in an effective state for the purpose of which it is
intended to be used or for removing the same: Provided that such work shall be done so as to cause
the least practicable nuisance or inconvenience to any person;Provided further that the
Commissioner shall, with the sanction of the council, pay compensation to any person who sustains
damage by the exercise of such power.Andhra Pradesh Municipalities Act, 1965

162. Prohibition against making connection with mains without permission.
(1)No person shall, without the permission of the Commissioner make any connection with any
municipal cable, wire, pipe, drain, channel or with the connection of any other person.(2)The
Commissioner may by notice require any connection made in contravention of Sub-section (1) to be
demolished, removed, closed, altered or remade.
163. Powers in respect of works outside the municipality.
(1)The council shall not undertake new works beyond the limits of the municipality without the
sanction of the Government.(2)The Council may, in the execution and for the purpose of any works
beyond the limits of the municipality sanctioned by the Government whether before or after the
passing of this Act, exercise all the powers which it may exercise within the municipality throughout
the line of the country through which conduits, channels, pipes, line of posts and wires and the like
run, and with the sanction of the Government.(a)over any lake, tank or reservoir, from which a
supply of water for drinking for producing electric energy or for other purposes is derived and over
all lands within one kilometre water level of any such lake, tank or reservoir;(b)over any
water-course from which a supply of water for drinking for producing electric energy or for other
purposes is derived within one kilometer above and half kilometre below any point at which water is
taken for such area; and(c)over any lands used for sewage, farms, sewage disposal tanks, filters and
other works connected with the drainage of the municipality.
Chapter 2
Scavenging
164. Council to arrange for the removal of rubbish and filth and for the
preparation and sale of compost.
- The council shall make adequate arrangements for--(a)the regular sweeping and cleaning of the
streets and removal of sweeping therefrom:(b)the daily removal of filth and carcasses of animals
from private premises;(c)the daily removal of rubbish from dust-bins and private premises, and
with this object, it shall provide-(i)depots for the deposits of filth, rubbish and the carcasses of
animals;(ii)covered vehicles or vessels for the removal of filth;(iii)vehicles or other suitable means
for the removal of the carcasses of large animals and rubbish;(iv)dust-bins for the temporary deposit
of rubbish;(d)utilization of road sweepings, rubbish and filth for preparation of compost and its
sale;(e)the utilization of carcasses of animals for the supply of bones for the purpose of manures and
its sale.
165. Contribution from persons having control over places of pilgrimage.
- Where a mosque, temple, mutt, or any place of religious worship or instruction or any place which
is used for holding fairs, festivals or for other like purpose, is situated within the limits of aAndhra Pradesh Municipalities Act, 1965

municipality or in the neighbourhood thereof and attracts either throughout the year or in particular
occasions a large number of persons any special arrangements necessary for public health, safety or
convenience whether permanent or temporary shall be made by the council and the council may
require the trustee or other person having control over such place to make such recurring or
non-recurring contribution as the Government may determine to the funds of the council
166. Prohibition of improper disposal of carcasses, rubbish and filth.
- No person shall, after due provision has been made under Section 164 by the council for deposit
and removal of the same,(a)deposit the carcasses of animals, rubbish or filth in any street, or on the
varandah of any building, or on any unoccupied ground alongside any street or any public quarry,
jetty or landing place, or on the bank of a watercourse or tank; or(b)deposit filth or carcasses of
animals in any dust-bin or in any vehicle not intended for the removal of the same; or(c)deposit
rubbish in any vehicle or vessel intended for the removal of filth save for the purpose of deodorizing
or disinfecting the filth.
167. Prohibition against keeping night-soil, etc.
- No owner or occupier of any premises shall keep or allow to be kept for more than forty-eight
hours night-soil, putrid, putrefying substances or any offensive matter on such premises of any
building or on the roof thereof or in any out-building, or any place thereof, or fails to comply with
any requisition of the municipal health officer as to the construction, repair, paving or cleaning of
any latrine, on or belonging to, his premises.
168. Prohibition against allowing out flow of filth.
- No owner or occupier of any premises shall allow water from any sink, drain, latrine or stable, or
any other filth to flow out of such premises to any portion of a street except a drain or a cesspool or
to flow out of such premises in such manner as to cause an avoidable nuisance by the soakage of the
said water or filth into the walls or grounds at the side of a drain forming a portion of a street.
169. Prohibition against using any cart without cover in the removal of filth,
etc.
- No person shall, in the removal of filth, use any cart or receptacle not having a proper covering for
preventing the escape of the contents thereof, or of the stench therefrom, or intentionally or
negligently spill any filth in the removal thereof, or omit carefully to sweep and clean every place in
which any such filth has been spilled or placed or set down in any public place any filth whether in a
vessel closed or open.Andhra Pradesh Municipalities Act, 1965

170. Prohibition against throwing rubbish or filth into drains.
- No person shall put or cause to be put any rubbish or filth into any public drain not intended for
rubbish or filth or into any drain communicating with any such public drain.
170A. Disposal of waste.
- Every Municipal Council shall arrange for the disposal of the waste collected by it in such manner
as may be prescribed.
Chapter 3
Streets
171. Maintenance and repair of streets.
(1)The Council shall, at the cost of the municipal fund, cause the public streets and bridges to be
maintained and repaired and may, from the same fund, meet the cost of all improvements to the
same which are necessary or expedient for the public safety or convenience.Provided that the
powers of the council under this sub-section shall also be exercisable by the Chairperson where the
cost of maintenance, repair or improvement does not exceed(a)rupees one thousand five hundred
per annum in the case of second grade or third grade municipality;(b)rupees three thousand per
annum in the case of any other municipality.(2)The council may entrust to any other local authority
with the consent of such authority the maintenance of any public street or portion thereof, the cost
of maintenance being provided by the Council.
171A. Government's power to repair the public streets vested in the
Municipal Council.
(1)Notwithstanding anything contained in this Act, it shall be competent for the Government or any
other agency authorised by them in this behalf to exercise the powers of the Council and the
Commissioner vested in them by or under this Act for the purpose of repairing the public streets and
bridges vested in the Council and also to lay new roads at their own expense in public interest.(2)For
the purpose of enabling the Government or the agency authorised by them to undertake repairs
under sub-section (1), the public streets and bridges shall vest in the Government temporarily from
a date to be notified by them in this behalf and thereupon it shall be competent for the Government
to take over possession of the public streets and bridges from the said date. The public streets and
bridges or any new roads laid under sub-section (1) shall continue to vest in the Government until
the notification is revoked and thereafter stand transferred to the Council.(3)It shall be the duty of
the Council and the Commissioner to carry out any directions issued by the Government for the
purposes of sub-sections (1) and (2).Andhra Pradesh Municipalities Act, 1965

172. Powers of municipal authorities.
(1)The council may--(a)lay out and make new public streets;(b)construct bridges and
sub-ways;(c)turn, divert or with the special sanction of the Government permanently close any
public street or part thereof;(d)widen, open, extend or otherwise improve any public street.(2)The
owners and occupiers of any land or buildings which are acquired for, or affected by any such
purposes shall be paid such reasonable compensation as may be determined by the executive
committee.
173. Power to dispose of permanently closed streets.
(1)When a public street is permanently closed under Section 172 the council may, with the sanction
of the Government, dispose of the site or of so much thereof as is no longer required in such manner
as may be approved by the Government, provided that due compensation is made to any person
injured by such closing.(2)In determining such compensation, allowance shall be made for any
benefit acuring to the same premises or any adjacent premises belonging to the same owner from
the construction or improvement of any other public street, at or about the same time that the
public street, on account of which the compensation is paid, is closed.
174. Acquisition of land and buildings for improvement of streets.
(1)The council may acquire-(a)any land required for the purpose of turning, diverting, opening,
widening, extending, or otherwise improving any public street, or of making any new public street,
and the buildings, if any, standing upon such land; and(b)any land outside the proposed street
alignment, with the buildings, if any, standing thereupon:Provided that in any case in which it is
decided to acquire any land under clause (b) of this sub-section, the owner of such land may retain it
by paying to the council an annual sum to be fixed by the council in that behalf, or a lump-sum to be
fixed by the council, not being less than twenty-five times such annual sum and subject to such
conditions as the council thinks fit as to the removal of the existing building, if any, the description
of the new building, if any, to be erected, the period within which the new building, if any, shall be
completed and any other similar matters.(2)If any sum payable in pursuance of the proviso to
sub-section (1) in respect of any land be not duly paid, it shall be recoverable in the manner
provided by this Act for the collection of taxes, and, if not so recovered, the Commissioner may enter
upon the land, and sell it, with any erections standing thereon, by public auction subject to the
conditions, if any, imposed under sub-section (1) above and may deduct the said sum and the
expenses of the sale from the proceeds of the sale and shall pay the balance, if any, to the
defaulter.(3)Any sum paid in pursuance of the proviso to sub-section (1) or recovered under
sub-section (2) in respect of any land shall be left out of account in determining the capital value or
the annual rental value of such land for the purpose of assessing it to the property tax.(4)Any land or
building acquired under clause (b) of sub-section (1) may be sold, leased or otherwise disposed of
after public advertisements, and any conveyance made for that purpose may comprise such
conditions as the council think fit as to the removal of the existing building, if any, the description of
the new building, if any, to be erected, the period within which the new building, if any, shall be
completed and any other similar matters.(5)The council may require any person to whom any landAndhra Pradesh Municipalities Act, 1965

or building is transferred under sub-section (4) to comply with any conditions comprised in the said
conveyance before it places him in possession of the land or building.
175. Power to specify building line and street alignment.
(1)The council may -(a)specify for any public street a building line or a street alignment or
both;(b)from time to time, define a fresh line in substitution for any line so defined or for any part
thereof:Provided that in either case--(i)at least one month before the meeting of the council at which
the matter is decided, public notice of the proposal has been given and special notice thereof has
also been put up in the street or part of the street for which such line is proposed to be defined,
and(ii)the council has considered all objections to the said proposal made in writing and delivered at
the municipal office not less than three clear days before the day of such meeting.(2)A register with
plans attached shall be kept by the Commissioner showing all publicities in respect of which a
building, lane or street alignment or both have been specified and such register shall contain such
particulars as may appear to the Commissioner to be necessary and shall, at all reasonable times, be
open for public inspection.
176. Buildings not to be constructed within street alignment or building line.
(1)No person shall construct any portion of any building within a street alignment defined under
Section 175.(2)No person shall erect or add to any building between street alignment and a building
line defined under Section 175 except with the permission of the Commissioner who may, when
granting the permission, impose such conditions as the council may lay down for such cases.
177. Setting back projecting buildings or walls.
(1)When any building or part thereof abutting on a public street is within a street alignment defined
under Section 175, the Commissioner may, whenever it is proposed--(a)to rebuild such buildings or
take it down to an extent exceeding one half thereof above the ground level, such half to be
measured in cubic centimetres, or(b)to remove, reconstruct or make any addition, to any portion of
such building which is within the street alignment, by an order require such building, addition or
alteration to be set back to the street alignment;Provided that such setting back shall not be required
in respect of such building or a portion thereof which has not been demolished and rebuilt.(2)When
any building or any part thereof within the street alignment falls down or is burnt down or is,
whether by order of the Commissioner or otherwise, taken down, or when any private land without
any building thereon lies within the street alignment, the Commissioner may forthwith take
possession on behalf of the council of the portion of land within the street alignment, and if
necessary, clear it.(3)Land acquired under this section shall be deemed to be a part of the public
street and shall vest in the council.(4)When any building is set back in pursuance of any requisition
made under sub-section (1), or when the Commissioner takes possession of any land under
sub-section (2), the council shall, within ninety days from the date of such setting backing or taking
possession, make full compensation to the owner for any direct damage which he may sustain
thereby.Explanation. - The expression `direct damage', as used in sub-section (4) with reference to
land, means the market value of the land taken and the depreciation, if any, in the ordinary marketAndhra Pradesh Municipalities Act, 1965

value of the rest of the land resulting from the area being reduced in size; but does not include
damage due to the prospective loss of any particular use to which the owner may allege that he
intended to put the land, although such use may be injuriously affected by the reduction of the site.
178. Setting buildings forward to improve line of street.
- The council may, upon such terms as it thinks fit, allow any building to be set forward for the
purpose of improving the line of a public street and may, by notice, require any building to be so set
forward in the case of re-construction thereof or of a new construction.Explanation. - For the
purpose of this section, a wall separating a premises from a public street shall be deemed to be a
building; and shall be deemed a sufficient compliance with permission or requisition to set forward
a building to the street alignment, if a wall of such material and dimensions as are approved by the
Commissioner is erected along the side line.
179. Projected streets.
(1)The council may prepare schemes and plans of proposed public streets showing the direction of
such streets, the street alignment and building line on each side of them, their intended width and
such other details as may appear desirable.(2)The width of such proposed streets shall not
ordinarily be less than twelve metres, or in any area covered by huts, nine metres.(3)It shall be the
duty of the council to lay out public streets in areas covered by huts, so far as may be practicable,
both for the purpose of securing proper ventilation for huts in such areas, and in view of the
contingency of buildings being erected therein.(4)When any plan has been prepared under
sub-section (1) the street to which it refers shall be deemed to be a projected public street, and the
provisions of Section 177 shall apply to all buildings, so far as they stand across the street alignment
or building line of the projected street.
180. Watering of streets.
- The council shall, so far as it considers it requisite for the public convenience, and so far as funds
permit, cause the chief public streets to be watered, and for that purpose may provide such
water-carts, animals and apparatus as it thinks necessary.
181. Temporary closure of streets.
- The Commissioner may by an order in writing temporarily close any street to traffic for repair, or
in order to carry out any work connected with drainage, water-supply or lighting or any of the
purposes of this Act;Provided that such work shall be completed and such street re-opened to traffic
with all reasonable speed.Andhra Pradesh Municipalities Act, 1965

182. Protection of appurtenances and materials of streets.
- It shall not be lawful for any person, without the permission of the Commissioner, to displace, take
up, or make any alteration in the fences, posts, pavements, flags or other materials of any public
street.
183. Power of municipality to recover expenses caused by extraordinary
traffic.
- When by a certificate of an officer of the Government of a rank not below that of Executive
Engineer it appears to the council, that having regard to the average expense of repairing roads in
the neighbourhood, extraordinary expenses have been incurred by the council in repairing a street
by reason of the damage caused by excessive weight passing along the street, or extraordinary traffic
thereon, the council may recover, in the civil court, having jurisdiction, from any person by or in
consequence of whose order such weight or traffic has been conducted, the amount of such expenses
as may be proved to the satisfaction of such court to have been incurred by such council by reason of
the damage arising from such weight or traffic as aforesaid;Provided that any person against whom
expenses are or may be recoverable under this section, may enter into an agreement with the council
for the payment to it of a compensation in respect of such weight or traffic and thereupon the
persons so paying shall not be subject to any proceedings under this section. Private Streets.
184. Owner's obligation to make a layout and to form a street or road when
disposing of lands as building sites.
(1)The owner of any agricultural land who intends to utilise or sell such land for building purposes
shall pay to the council such conversion fee as may be fixed by the council, not being less than
twenty-five paise and not more than one rupee per square metre:Provided that no such conversion
fee shall be payable where an agricultural land belonging to charitable, religious or such other
institutions as may be prescribed is intended to be utilised or sold for building purposes.(2)The
owner of any land shall, before he utilises, sells, leases, or otherwise disposes of such land or any
portion thereof, as sites for construction of buildings-(a)make a layout and form a street or road
giving access to sites and connecting them with an existing public or private street except in the
cases where the sites abut on an existing public or private street;(b)set apart in the layout adequate
area of land on such a scale as may be prescribed for a play-ground, a park, an educational
institution or for any other public purpose.(3)Unless the conditions specified in Clauses (a) and (b)
of Sub-section (2) are satisfied, the owner shall not be entitled to utilise, sell, lease, or otherwise
dispose of his land or any portion thereof for the construction of buildings.(4)No permission for the
construction of buildings in such land or portion thereof shall be granted unless(i)the street or road
as required in clause (a) of sub-section (2) is laid out and the condition required in clause (b) thereof
is fulfilled:(ii)all layouts indicating sub-divisions of land, however small they are, are approved by
the council;(iii)any proposal for sub-division before it is registered in the records of the municipality
is certified by the town planning officer as having been approved;(iv)in all cases of
sub-division--(a)the plot is not less than the size fixed by the council from time to time;(b)the streetsAndhra Pradesh Municipalities Act, 1965

and lanes proposed conform to the minimum standards fixed by the council.(v)a copy of the title
deed of the land duly attested by a Gazetted Officer of the Government together with an urban land
ceiling clearance certificate, in case the extent of land exceeds the ceiling limit and if it does not
exceed the ceiling limit an affidavit declaring that the total extent of land held by such holder, his or
her spouse and unmarried minor children does not exceed the ceiling limits are furnished.
185. Making of a layout and forming of new private streets or road.
(1)Any person intending to make a layout and form a new private street or road shall send to the
municipal office a written application with plans and sections showing the following particulars
namely:-(a)the intended level, direction and width of the street:(b)the street alignment and the
building line:(c)the arrangements to be made for levelling, paving, metalling, flagging, channelling,
severing, draining, conserving, lighting the street, and the provision for water-supply mains;
and(d)the area set apart for public purposes under clause (b) of sub-section (2) of Section 184.(e)a
copy of the title deed of the land duly attested by a Gazetted Officer of the Government together with
an urban land ceiling clearance certificate, or as the case may be an affidavit, referred to in Section
184.(2)In addition to the particulars referred to in sub-section (1), such person shall-(i)where there
is conversion of agricultural land, enclose a certificate to the effect that conversion fees as required
under sub-section (1) of Section 184 has been paid; and(ii)for the purpose of fulfilling the
obligations imposed under Section 184, deposit as security such amount, as may be prescribed, in
the municipal treasury, or give as security in favour of the municipality and such extent of the land,
and of such value, as may be prescribed, in the area covered by his layout.(3)The Commissioner
shall, within fifteen days from the date of its receipt in the municipal office, call for further
particulars, where necessary or forward the same to the Director of Town Planning. Where further
particulars are called for, they shall be furnished by the applicant within ten days from the date of
receipt of the notice by him, and the Commissioner shall forward to the Director of Town Planning,
the layout plan with full particulars within a period of fifteen days from the date of receipt of
particulars from the applicant. The Director of Town Planning shall, within sixty days from the date
of receipt of the layout plan in his office, forward his recommendations to the municipality. The
council may, within sixty days from the date of receipt of the recommendation of the Director of
Town Planning, sanction the layout having due regard to such recommendations and subject to such
conditions as it may deem fit or refuse to sanction for reasons to be recorded in writing.(4)Such
sanction may be refused on any of the following grounds namely--(i)if, in the opinion of the council,
the proposed street or road is likely to disturb any arrangements made or to be made, for carrying
out of any general scheme for the laying out of street or road either in the master plan or a detailed
town planning scheme prepared therefor under the relevant law relating to the town planning for
the time being in force;(ii)if the proposed street or road in the layout does not conform to the
provisions of the Act or the rules made thereunder;(iii)if the proposed street or road is not so
designed as to connect atleast at one end with a street which is already open; or(iv)if adequate area
has not been set apart for public purposes under clause (b) of sub-section (2) of Section 184,(v)if a
copy of the title deed of the land duly attested by a Gazetted Officer of the Government together with
an urban land ceiling clearance certificate, or as the case may be, an affidavit referred to in Section
184 are not furnished as required under sub-section (1) thereof;(5)No person shall make a layout
and form any new private street or road without, or otherwise than in conformity with, the orders ofAndhra Pradesh Municipalities Act, 1965

the council. If further information is called for, no steps shall be taken to make a layout and form the
street or road until orders are passed in that regard. Any application not disposed of within a period
of one hundred and fifty days from the date of receipt in the municipal office of the required
particulars in respect of such application shall be deemed to have been sanctioned in accordance
with the provisions of this Act.
186. Alteration or demolition of street or road made in breach of Section 185.
(1)If any person makes a layout and forms any street or road referred to in Section 185 without, or
otherwise than in conformity with, the orders of the council, the Commissioner may, whether or not
such person be prosecuted under this Act, by notice-(a)require such person to show sufficient cause,
by a written statement signed by him and sent to the Commissioner on or before such days as may
be specified in the notice, why such street or road should not be altered to the satisfaction of the
Commissioner or if such alteration is impracticable, why such street or road should not be
demolished; or(b)require such person to appear before the Commissioner either personally or by a
duly authorised agent on such day and at such time and place as may be specified in the notice, and
show cause as required in clause (a).(2)If any person on whom such notice is served fails to show
cause to the satisfaction of the Commissioner why such street or road should not be so altered or
demolished, the Commissioner may pass an order directing the alteration or demolition of such
street or road.
187. Power of Commissioner to order work to be carried out or to execute it
in default.
(1)Where any private street or road or part thereof, is not levelled, paved, metalled, flagged
channelled, sewered, drained, conserved or lighted, or where in any street or road water supply
mains are not laid, to the satisfaction of the Commissioner, he may, by notice, require the owner of
the land which abuts on such street or road or part thereof to carry out any work specified in such
notice within such time as is fixed therein.(2)Where such work is not carried out within the time
specified in the notice, the Commissioner may, if he thinks fit, execute it and the expenses incurred
therefor as determined by him shall be paid by the owner.(3)Where the owner of such land fails to
pay the expenses due from him under sub-section (2), the Commissioner shall deduct the same from
the deposit made by him or, as the case may be, from the amount realised by auctioning the land
given as security by him, under clause (ii) of sub-section (2) of Section 185 and refund to him the
balance, if any. Where the deposit or the amount realised by auctioning the land given as security is
not sufficient to meet the expenses, the balance of the exepenses, shall be recovered from him in the
same manner as property tax.(4)The amount deposited or the land given as security, under clause
(ii) of sub-section (2) of Section 185, may be refunded or released only on the production of a
certificate from the municipal engineer that the owner has fulfilled the obligations imposed under
this section and Section 184 or where the council is satisfied that the owner has given up his
intention to make a layout and form a new private street or road.Explanation. - In this section,'the
owner' means the person referred to in Section 185.Andhra Pradesh Municipalities Act, 1965

188. Right of owner to require street to be declared public.
- If any street has been levelled, paved, metalled, flagged, channelled, drained, conserved and
lighted under the provisions of Section 187, such street shall, on the requisition of not less than
three-fourths of the owners thereof, be declared a public street by notification in the District
Gazette, or, where there is no such District Gazette, in the Andhra Pradesh Gazette. Encroachments
on streets
189. Prohibition against obstruction in, or over streets.
- No one shall build any wall or erect any fence or other obstruction or projection or make any
encroachment in or over any street except as hereinafter provided.
190. Streets open to all.
- All streets vested in, or to be vested in, or maintained by a council, shall be open to all persons.
191. Prohibition and regulation of doors, ground-floor windows and bars
opening outwards.
(1)No door, gate, bar or ground-floor window shall, without a licence from the Commissioner, be
hung or placed so as to open outwards upon any street.(2)The Commissioner may, by notice, require
the owner of such door, gate, bar or window to alter it so that no part thereof when open shall
project over the street.
192. Removal of encroachments.
(1)The Commissioner may cause to be removed or altered(a)any projection, encroachment or
obstruction (other than a door, or gate or a necessary access thereto, or bar or ground floor
windows) situated against, or in front of such premises and in, or over any street;(b)any article
whatsoever, hawked or exposed for sale in a public place or in any public street in contravention of
the provisions of this Act, together with any vehicle, package, box or any other thing in or on which
such article is placed.(2)If the owner or occupier of the premises proves that any such projection,
encroachment or obstruction under clause (a) of sub-section (1) has existed for a period sufficient
under the law of limitation to give any person a prescriptive title thereto or that it was erected or
made with the permission or licence of any municipal authority duly empowered in that behalf, and
that the period, if any, for which the permission or licence is valid has not expired, the council shall
make reasonable compensation to every person who suffers damage by the removal or alteration of
the same.(3)No decision made or order passed or proceeding taken by the Commissioner effecting
removal of encroachments shall be called in question before a civil court in any suit, application or
other proceeding and no injunction shall be granted by any court in respect of any proceeding taken
by the Commissioner.Andhra Pradesh Municipalities Act, 1965

193. Power to allow certain projections and erections.
(1)The Commissioner may grant a licence, subject to such conditions and restrictions as he may
think fit, to the owner or occupier of any premises to put up verandahs, balconies, sun-shades,
weather-frames and the like, to project over a street, or in streets in which the construction of
arcades has been sanctioned by the Commissioner to put up an arcade, or to construct any step or
drain-covering necessary for access to the premises.(2)The Commissioner may grant a licence
subject to such conditions and restrictions as he may and think fit, for the temporary erection of
pandals and other structures, in a street vested in the council or in any other public place, the
control of which is vested in the council.(3)The Commissioner shall have power to lease road sides
and street margins vested in the Council for occupation for a temporary purpose on such terms and
conditions and for such period not exceeding thirty days as the Commissioner may fix.(4)But
neither a licence under sub-section (1) nor a lease under sub-section (3) shall be granted if the
projection, construction or occupation is likely to be injurious to health or cause public
inconvenience or otherwise materially interfere with the use of the road as such.(5)The exercise by
the Commissioner of the powers under this section shall be in accordance with such rules as the
Government may make in this behalf.(6)On the expiry of any period for which a licence or lease has
been granted under this section, the Commissioner may, without notice, cause any projection or
construction put up under sub-section (1) or subsection (2) to be removed, or cause the occupier to
be evicted and the cost of so doing shall be recoverable in the manner provided in Section 364 from
the person to whom the licence or lease was granted.
194. Power to evict certain persons from municipal premises.
(1)If the Commissioner is satisfied--(a)that a person authorised to occupy any premises vesting in or
belonging to, the council has, whether before or after the commencement of this Act--(i)Not paid
rent lawfully due from him in respect of such premises for a period of more than three
months;(ii)sublet, without the permission of the council, the whole or any part of such
premises;(iii)otherwise acted in contravention of any of the terms, express or implied, under which
he is authorised to occupy such premises, or(b)that any person without the previous permission or
licence from the council is in unauthorised occupation of any premises of the council, he may
notwithstanding anything in any law for the time being in force, by notice served by post, or by
affixing a copy of it on the outer door or some other conspicuous part of such premises, or in such
other manner as may be prescribed, order that such person as well as any other person, who may be
in occupation of the whole or any part of the premises shall vacate the same within one month of the
date of the service of the notice, and where such notice relates to any land shall also remove any
building or other construction or anything deposited on it.(2)If any person refuses or fails to comply
with an order made under sub-section (1), the Commissioner may, after giving such person an
opportunity of making his representation, confirm such order and evict that person from, and take
possession of, the premises and may for that purpose use such force as may be necessary.(3)If a
person, who has been ordered to vacate any premises under sub-clause (i) or sub-clause (iii) of
clause (a) of sub-section (1) within one month of the date of service of the notice or such longer time
as the competent authority may allow pays to the council, the rent in arrears or as the case may be,
carries out or otherwise complies with the terms contravened by him to the satisfaction of theAndhra Pradesh Municipalities Act, 1965

Commissioner, the Commissioner shall, in lieu of evicting such person under sub-section (2), cancel
his order made under sub-section (1) and thereupon such person shall hold the premises on the
same terms on which he held them immediately before such notice was served on him.(4)If any
damage to the property of the council is caused by any person occupying any such premises, he shall
be liable to pay such compensation to the council for the damage as may be fixed by the council, and
the amount of such compensation shall, in case of dispute, be determined and recovered in the
manner hereinafter provided.Explanation. - For the purpose of this section, the term "premises"
shall mean any land or building or part of a building and includes(i)gardens, grounds and
out-houses, if any, appertaining to such building or part of a buildings, and(ii)any fittings affixed to
such building, or part of a building for the more beneficial enjoyment thereof.
195. Precautions during repairs of streets.
(1)The Municipal Engineer or where there is no Municipal Engineer, the Commissioner shall during
the construction or repair of any street, drain or premises vested in the council--(a)cause the same
to be fenced and guarded;(b)take proper precautions against accident by shoring up and protecting
the adjoining building; and(c)cause such bars, chains or posts to be fixed across or in any street in
which any such work is under execution as are necessary in order to prevent the passing of vehicles
or animals and avert danger.(2)The said officer shall cause such drain, street, or premises to be
sufficiently lighted or guarded during the night while under construction or repair.(3)The said
officer shall, with all reasonable speed, complete the said work, fill in the ground and repair the said
drain, street, or premises and remove the rubbish occasioned thereby.
196. Prohibition against removal of bars and lights.
- No person shall without lawful authority, remove any bar, chain, post or shoring timber or remove
or extinguish any light set up under Section 195.
197. Prohibition against making holes and causing obstruction.
(1)No person shall make a hole or cause obstruction in any street, unless he previously obtains the
written permission of the Commissioner and complies with such conditions as the Commissioner
may impose.(2)When such permission is granted, such person shall at his own expense, cause such
hole or obstruction to be sufficiently fenced and enclosed until the hole or obstruction is filled up or
removed and shall cause such hole or obstruction to be sufficiently lighted during the night.
198. Licence for work on buildings likely to cause obstruction.
- If any person intends to construct or demolish any building or to alter or repair the outward part
thereof, and if any street or foot-way is likely to be obstructed or rendered inconvenient by means of
such work, he shall first obtain a licence from the Commissioner in that behalf and shall
also--(a)cause the said building to be fenced and guarded;(b)sufficiently light it during the night;
and(c)take proper precautions against accidents during such time as the public safety orAndhra Pradesh Municipalities Act, 1965

convenience requires.
199. Clearing of debris of fallen houses etc., by occupier.
- If any obstruction is caused in any street by the fall of trees, structures or fences, the owner or
occupier of the premises concerned shall, within twelve hours of the occurrence of such fall, or
within such further period as the Commissioner may by notice allow, clear the street of such
obstruction.
199A. Punishment for destroying road direction.
- Whoever without authorisation from the Commissioner, defaces, disturbs or destroys or damages
any municipal direction post, lamp post, or lamp or extinguishes any municipal light in public place,
shall be punishable with fine which may extend to rupees five hundred.
200. Naming of public streets.
(1)The council shall give names to all public streets and may, with the approval of the Government,
alter the name of any public street.(2)The Municipal Engineer or where there is no Municipal
Engineer, the Commissioner shall cause to be put up or painted in English and in the main language
of the district on a conspicuous part of some buildings wall or place, at or near each end, corner or
entrance, the name of every public street.(3)No person shall, without lawful authority, destroy, pull
down, or deface any such name or put up any name different from that put up by order of the said
officer.
201. Numbering of buildings.
(1)The Commissioner shall cause a number to be affixed or painted to the side or outer door of any
building or to some place at the entrance of the premises.(2)No person shall, without lawful
authority, destroy, pull down or deface any such number.(3)When a number has been affixed or
painted under sub-section (1) the owner of the building shall be bound to maintain such number
and to replace it, if removed or defaced; and if he fails to do so, the Commissioner may, by notice,
require him to replace it.
Chapter 4
Building Regulations
202. Construction of buildings for public worship.
- No site shall be used for the construction of a building intended for public worship if the
construction of a building thereon will wound the religious feelings of any class of persons.Andhra Pradesh Municipalities Act, 1965

203. Permission for construction of new building not to be granted on certain
sites.
- No permission shall be granted for the construction of new building on any site which has been
filled up with faceal or offensive vegetable or animal matter or upon which any such matter has been
deposited unless the Municipal Health Officer certifies that such matter has been properly removed
by excavation or otherwise or has become or been rendered innocuous.
204. Building site and construction of buildings.
- No piece of land shall be used as a site for the construction of a building and no building shall be
constructed or reconstructed otherwise than in accordance with the provisions of this part and of
any rules or bye-laws made under this Act, relating to the use of building sites or the construction or
reconstruction of buildings;Provided that the Government may, in respect of all municipalities or
with the consent of the council, in respect of any particular municipality or portion thereof, exempt
all buildings or any class of buildings from all or any of the provisions of this chapter or the said
rules.
205. Powers of council to regulate future construction of certain classes of
buildings in particular streets or localities.
(1)The council may give public notice of its intention to declare--(a)that in any streets or portions of
streets specified in the notice--(i)continuous building will be allowed;(ii)the elevation and
construction of the frontage of all buildings thereafter constructed or reconstructed shall, in respect
of their architectural features, be such as the council may consider suitable to the locality; or(b)that
in any localities specified in the notice, the constrution of only detached buildings will be allowed;
or(c)that in any streets, portions of streets or localities specified in the notice, the construction of
shops, warehouses, factories, huts or buildings of a specified architectural character, or buildings
destined for particular uses, will not be allowed without the special permission of the council.(2)No
objections to any such declaration shall be received after a period of three months from the
publication of such notice.(3)The council shall consider all objections received within the said
period and may then confirm the declaration, and before doing so, may modify it but not so as to
extend its effect.(4)The Commissioner shall publish any declaration so confirmed and it shall take
effect from the date of publication.(5)No person shall, after the date of publication of such
declaration, construct or reconstruct any building in contravention of any such declaration.
206. Buildings at corner of streets.
(1)The Council may require any building intended to be erected at the corner of two streets to be
rounded off or splayed off to such height and to such extent otherwise as it may determine and may
acquire such portion of the site at the corner as it may consider necessary for public convenience or
amenity and for any land so acquired the council shall pay compensation.(2)In determining such
compensation, allowance shall be made for any benefit accruing to the same premises from theAndhra Pradesh Municipalities Act, 1965

improvement of the streets.
207. Prohibition against use of inflammable materials for buildings without
permission.
- No external roof, varandah, pendal or wall of a building shall be constructed or reconstructed of
grass, leaves, mats or other inflammable materials, except with the permission of the Commissioner.
208. Prohibition against constructing doors, ground-floor windows and bars
so as to open outwards.
- No door, gate, bar or ground-floor window which opens on any public street shall be constructed
or reconstructed so as to open outwards except with the licence of the Commissioner under Section
191. Building other than Huts
209. Application to construct or reconstruct buildings.
(1)If any person intends to construct or reconstruct a building other than a hut, he shall send to the
Commissioner--(a)an application in writing for the approval of the site, together with a site plan of
the land, and(b)an application in writing for permission to execute the work together with
ground-plan, elevations and sections of the building, and a specification of the work.(c)a copy of the
title deed of the land duly attested by a Gazetted Officer of the Government together with an urban
land ceiling clearance certificate or as the case may be, an affidavit referred to in Section
184.Explanation. - `Building' in this sub-section shall include a wall or fence of whatever height
bounding or abutting on any public street.(2)Every document furnished under sub-section (1) shall
contain such particulars and be prepared in such manner as may be required under rules or
bye-laws.
210. Necessity for prior approval of site.
- The Commissioner shall not grant permission to construct or reconstruct a building unless and
until it has approved of the site or an application made under Section 209.
211. Prohibition against commencement of work without permission.
- The construction or reconstruction of a building shall not be begun unless and until the
Commissioner has granted permission for the execution of the work.
212. Period within which Commissioner is to signify approval or disapproval.
- Within sixty days after the receipt of any application made under Section 209 for approval of a site
or of any information or further information required under rules or bye-laws, the Commissioner
shall, by written order, either approve the site or refuse on one or more of the grounds mentioned inAndhra Pradesh Municipalities Act, 1965

Section 215 to approve the site.
213. Period within which Commissioner is to grant or refuse to grant
permission to execute work.
- Within sixty days after the receipt of any application made under Section 209 for permission to
execute any work or of any information or of documents or further information or documents
required under rules or byelaws, the Commissioner shall by written order either grant such
permission or refuse on one or more of the grounds mentioned in Section 215 to grant it;Provided
that the said period of sixty days shall not begin to run until the site has been approved under
Section 212.
214. Effect of delay in grant or refusal of approval or permission.
- If within the period prescribed by Section 212 or Section 213, as the case may be, the
Commissioner has neither given nor refused its approval of a building site, or its permission to
execute any work, as the case may be, such approval or permission shall be deemed to have been
given; and the applicant may proceed to execute the work, but not so as to contravene any of the
provisions of this Act or any rules or bye-laws made under this Act.
215. Grounds on which approval of sites for or licence to construct or
reconstruct building may be refused.
- The only grounds on which approval of a site for the construction or reconstruction of a building or
permission to construct or reconstruct a building may be refused are the following, namely:-(1)that
the work, or use of the site for the work or any of the particulars comprised in the site plan, ground
plan elevations, sections or specifications would contravene some specified provision of any law or
some specified order, rule, declaration or bye-laws made under any law.(2)that the application for
such permission does not contain the particualrs or is not prepared in the manner required under
rules or bye-laws;(3)that any of the documents referred to in Section 209 have not been signed as
required under rules or byelaws;(4)that any information or a copy of the title deed of the land duly
attested by a Gazetted Officer of the Government together with an urban land ceiling clearance
certificate, or as the case may be, an affidavit referred to in Section 184 are not furnished or
documents required by the Commissioner under rules or bye-laws have or have not been duly
furnished.(5)that streets or roads have not been made as required by Section 184.(6)that the
proposed building would be an encroachment upon Government or municipal land.Whenever the
Commissioner refuses to approve a building site for a building or to grant permission to construct or
reconstruct a building, the reasons for such refusal shall be specifically stated in the order.
216. Lapse of permission.
- If the construction or reconstruction of any building is not completed within the period specified,
the permission shall lapse and a fresh application shall be made before the work is continued.Andhra Pradesh Municipalities Act, 1965

217. Power to require alteration of work.
(1)If the Commissioner finds that the work--(a)is otherwise than in accordance with the plans or
specifications which have been approved; or(b)contravenes any of the provisions of this Act or any
bye-law, rule, order of declaration made thereunder he may, by notice, require the owner of the
building within a period stated either--(i)to make such alterations as may be specified in the said
notice with the object of bringing the work into conformity with the said plans or provisions; or(ii)to
show cause why alteration should not be made.(2)If the owner does not show cause as aforesaid, he
shall be bound to make the alterations specified in such notice.(3)If the owner shows cause as
aforesaid, the Commissioner shall by an order cancel the notice issued under sub-section (1), or
confirm the same subject to such modifications as it may think fit.
218. Stoppage of work endangering human life.
- Notwithstanding anything in any of the preceding sections the Town Planning Officer may, at any
time, stop the construction or reconstruction of any building if in his opinion the work in progress
endangers human life and shall report the fact to the Commissioner who shall have powers to pass
such orders as he thinks fit for reasons to be recorded in writing.
219. Application of certain sections to wells.
- The provisions of Section 209, Section 210, Section 211, Section 216, Section 217 and Section 221
shall, so far as may be, apply to a well.
220. Application to construct or reconstruct huts.
(1)Every person who intends to construct or reconstruct hut shall send to the Commissioner.(a)an
application for permission to execute the work; and(b)a site plan of the land.(2)Every such
application and plan shall contain the particulars and be prepared in the manner required by rules
or bye-laws.
221. Prohibition against commencement of work without permission.
- The construction or reconstruction of a hut shall not be begun, unless and until the Commissioner
has granted permission for the execution of the work on an application sent to him under Section
220
222. Period within which Commissioner is to grant or refuse to grant
permission to execute the work.
- Within fourteen days after the receipt of any application made under Section 220 for permission to
construct or reconstruct a hut or of any information or plan or further information or fresh plan
required under rules or byelaws, the Commissioner shall, by written order, either grant suchAndhra Pradesh Municipalities Act, 1965

permission or refuse on one or more of the grounds mentioned in Section 224 to grant it.
223. Effect of delay in grant or refusal of permission.
- If within the period prescribed by Section 222, the Commissioner has neither granted nor refused
to grant permission to construct or reconstruct a hut such permission, shall be deemed to have been
granted and the applicant may proceed to execute the work but not so as to contravene any of the
provisions of this Act or any rules or bye-laws made under this Act.
224. Grounds on which permission to construct or reconstruct hut may be
refused.
- The only grounds on which permission to construct or reconstruct a hut may be refused are the
following, namely:-(1)that the work or use of the site for work would contravene some specified
provisions of any law or some specified order, rule, bye-law or declaration made under any
law.(2)that the application for permission does not contain the particulars or is not prepared in the
manner required under rules or bye-laws;(3)that any information or plan required by the
Commissioner under rules or bye-laws has not been duly furnished;(4)that streets or roads have not
been made as required by Section 184; or(5)that the proposed building would be an encroachment
upon Government or municipal land.Whenever the Commissioner refuses to grant permission to
construct or reconstruct a hut, the reasons for such refusal shall be specifically stated in the order.
225. Lapse of permission.
- If the construction or reconstruction of any hut is not completed within the period specified, the
permission shall lapse and a fresh application shall be made before the work is continued.
226. Maintenance of external walls in repair.
- The owner or occupier of any building adjoining a public street shall keep the external part thereof
in proper repair with lime plaster or other material to the satisfaction of Commissioner.
227. Application of provisions to alterations and additions.
(1)The provisions of this chapter and of any rules or bye-laws made under this Act relating to
construction and reconstruction of buildings shall also be applicable to any alteration thereof or
addition thereto.Provided that works of necessary repair which do not affect the position or
dimension of a building or any room therein shall not be deemed as an alteration or addition for the
purposes of this section.x x x xAndhra Pradesh Municipalities Act, 1965

228. Demolition or alteration of building work unlawfully commenced, carried
on or completed.
(1)If the Commissioner is satisfied--(i)that the construction or reconstruction of any building or
well--(a)has been commenced without obtaining the permission of the Commissioner or the
Chairperson as the case may be, or where an appeal has been made to the council, in contravention
of any order passed by the council; or(b)is being carried on, or has been completed, otherwise than
in accordance with the plans or particualrs on which such permission or order was based; or(c)is
being carried on, or has been completed, in breach of any of the provisions of this Act or of any rule
or bye-law made under this Act or of any direction or requisition lawfully given or made under this
Act or such rules or bye laws; or(ii)that any alterations required by any notice issued under Section
217 have not been duly made;or(iii)that any alteration of or addition to any building or any other
work made or done for any purpose into or upon, any building, has been commenced or is being
carried on or has been completed in breach of Section 227.(2)The said officer shall serve a copy of
the provisional order made under sub-section (1) on the owner of the building or well, together with
a notice requiring him to show cause within a reasonable time to be named in such notice why the
order should not be confirmed.(3)If the owner fails to show cause to the satisfaction of the said
officer, he may confirm the order with such modification as he thinks fit to make, and such order
shall then be binding on the owner.
229. Exemptions.
(1)Any building constructed and used or intended to be constructed and used, exclusively for the
purpose of a plant-house, summer-house, not being a dwelling, house, poultry house or aviary, shall
be exempted from the provisions of this chapter other than Section 208 provided the building be
wholly detached from, and situated at a distance of at least three meters from the nearest adjacent
building.(2)The Commissioner may grant permission at his discretion on such terms as he may
decide in each case to erect for a specified period temporary huts or sheds for stabling, for watching
crops, for storing tools or materials, or for other similar purposes. On expiry of the period specified,
the Commissioner may, by notice, require the owner of such hut or shed to demolish it.
230. Application of Schedule III.
- The rules embodied in Schedule III shall be read as part of this chapter.
Chapter 5
Nuisance
231. Precautions in case of dangerous structures.
(1)If any structure appears to the Commissioner to be in a ruinous state and dangerous to the
passersby or to the occupiers of neighbouring structures, he may by notice require the owner orAndhra Pradesh Municipalities Act, 1965

occupier to fence off, take down, secure or repair such structures so as to prevent any danger
therefrom.(2)If immediate action is necessary, the Commissioner shall himself before giving such
notice or before the period of such notice expires, fence off, take down, secure or repair such
structure or fence off a part of any street or take such temporary measures as he thinks fit to prevent
danger and the cost of doing so shall be recoverable from the owner or occupier in the manner
provided in Section 364.(3)If in the opinion of the Commissioner the said structure is imminently
dangerous to the inmates thereof, he shall order the immediate evacuation thereof, and any person
disobeying may be got removed with the help of any police officer.
232. Precautions in case of dangerous trees.
(1)If any tree or any branch of a tree or the fruit of any tree appears to the Commissioner to be likely
to fall and thereby endanger any person or any structure, he may by notice require the owner of the
said tree to secure, lop or cut down the said tree so as to prevent any danger therefrom.(2)If
immediate action is necessary, the Commissioner shall himself before giving such notice or before
the period of such notice expires, secure, lop or cut down the said tree or remove the fruits thereof or
fence off a part of any tree or take such other temporary measures as he thinks fit to prevent danger
and the cost of so doing shall be recoverable from the owner of the tree in the manner provided in
Section 364.
233. Precautions in case of dangerous tanks, wells, holes, etc.
(1)If any tank, pond, well, hole, stream, dam, bank or other place appears to the Commissioner to
be, for want of sufficient repair, protection or enclosure, dangerous to the passers-by or to persons
living in the neighbourhood, he may, by notice require the owner to fill in, remove, repair, protect or
enclose the same so as to prevent any danger therefrom.(2)If immediate action is necessary, he
shall, before giving such notice or before the period of notice expires, himself take such temporary
measures a she thinks fit to prevent danger and the cost of doing so, shall be recoverable from the
owner in the manner provided in Section 364.
234. Power to stop dangerous quarrying.
- If, in the opinion of the Commissioner the working of any quarry, or the removal of stone, earth or
other material, from any place is dangerous to persons residing in, or having legal access to, the
neighbourhood thereof or creates or is likely to create a nuisance, he may require the owner or
person having control of the said quarry or place to discontinue working the same or to discontinue
removing stone, earth or other material from such place or to take such order with such quarry or
place as he shall deem necessary for the purpose of preventing danger or of abating the nuisance
arising or likely to arise therefrom
235. Precaution against fire.
(1)The Commissioner may by notice, require the owner of any structure, booth or tent partly orAndhra Pradesh Municipalities Act, 1965

entirely composed of, or having any external roof, verandah, pandal or wall partly or entirely
composed of cloth, grass, leaves mats, or other inflammable materials to remove or alter such tent,
booth, structure, roof, verandah, pandal or wall or may grant him permission to retain the same on
such conditions as he may think necessary to prevent danger from fire.(2)The Commissioner may,
by notice, require any person using any place for the storage for private use, of timber, firewood,
other inflammable or combustible things to take special steps to guard against danger from
fire.(3)Where the Commissioner is of opinion that the means of egress from any building are
insufficient to allow of safe exit in the event of fire, he may, with the sanction of the council, by
notice, require the owner or occupier of the building to alter or reconstruct any staircase in such
manner or to provide such additional or emergency stair-cases as he may direct; and when any
building, booth or tent is used for purposes of public entertainment, he may require, subject to such
sanction as aforesaid, that it shall be provided with an adequate number of clearly indicated exists
so placed and maintained, as readily to afford the audience ample means of safe egress, that the
seating be so arranged as not to interfere with free access to the exits and that gangways, passages
and staircases leading to the exists shall, during the presence of the public, be kept clear of
obstructions.
236. Prohibition of construction of, wells, tanks etc., without the permission
of the Chairperson.
(1)No new well or tank shall be dug or constructed without the permission of the
Chairperson.(2)The Chairperson may grant permission, subject to such conditions as he may deem
necessary, or may, for reasons to be recorded by him refuse it.(3)If any such work is began or
completed without such permission.--(a)the Commissioner may by notice require the owner or
other person who has done such work to fill up or demolish such work in such manner as the said
officer shall direct; or(b)the Chairperson may grant permission to retain such work, but such
permission shall not exempt such owner from proceedings for contravening the provisions of
sub-section (1).
237. Filling in of pools etc., which are a nuisance.
(1)If in the opinion of the municipal health officer--(a)any pool, ditch, tank, well, pond, bog, swamp,
quarry-hole, drain, cess-pool, pit, water-course, or any collection of water; or(b)any land on which
water may at any time accumulate, is or is likely to become a breeding place of mosquitoes or in any
other respect a nuisance, the said officer may by notice require the owner or person having control
thereof to fill up, cover over, weed and stock with larvicidal fish, or petrolize in such manner and
with such materials as the said officer shall direct or to take such action for removing or abating the
nuisance as the said officer shall direct.(2)If a person on whom a requisition is made under
sub-section (1) to fill up, cover over, or drain off a well, delivers to the municipal health officer
within the time specified for compliance therewith, written objections to such requisition, the said
officer shall report such objections to the Commissioner and shall make further enquiry into the
case, and shall not institute any prosecution for failure to comply with such requisition except with
the approval of the Commissioner but the municipal health officer may nevertheless, if he deems the
execution of the work called for by such requisition to be of urgent importance, proceed inAndhra Pradesh Municipalities Act, 1965

accordance with Section 364 and, pending the Commissioner's disposal of the questions whether the
said well be permanently filled up, covered over or otherwise dealt with, may cause such well to be
securely covered over so as to prevent the ingress of mosquitoes, and in every such case the
municipal health officer shall determine with the approval of the Commissioner whether the
expenses of any work already done as aforesaid shall be paid by such owner or by the municipal
health officer out of the municipal fund or shall be shared and, if so, in what proportions.
238. Regulation or prohibition of certain kinds of cultivation.
- The Council on the report of the municipal health officer that the cultivation of any description of
crop, or the use of any kind of manure, or the irrigation of land in any place within the limits of the
municipality, is injurious to the public health may, with the previous sanction of the Government, by
public notice, regulate or prohibit the cultivation, use of manure, or irrigation so reported to be
injurious:Provided that when such cultivation or irrigation has been practised during the five years
preceding the date of such public notice, with such continuity as the ordinary course of husband any
admits of, compensation shall be paid from the Municipal Fund to all persons interested, for any
damage caused to them by absolute prohibition.
239. Cleansing of insanitary private tank or well used for drinking.
(1)The municipal health officer may, by notice require the owner or, person having control over, any
private water-course, spring, tank, well or other place, the water of which is used for drinking,
bathing or washing clothes, to keep the same in good repair and to cleanse it of silt, refuse or
vegetation and to protect it from pollution by surface drainage in such manner as the said officer
may think fit.(2)If the water of any place which is used for drinking, bathing or washing clothes, as
the case may be is proved to the satisfaction of the said officer to be unfit for the purpose, he may, by
notice, require the owner or person having control thereof to--(a)refrain from using or permitting
the use of such water, or(b)close or fill up such place or enclose it with a substantial wall or fence.
240. Duty of council in respect of public well or receptacle of stagnant water.
- The council shall maintain in a cleanly condition all wells, tanks and reservoirs which are not
private property and may fill them up or drain them when it appears necessary to do so.
241. Public wells etc, open to all.
- All such wells, tanks and reservoirs when maintained by the council shall be open to use and
enjoyment by all persons.
242. Prohibition against or regulation of washing animals or clothes or
fishing or drinking in public water courses, tanks etc.Andhra Pradesh Municipalities Act, 1965

- The council may, in the interest of the public health, regulate or prohibit the washing of animals,
clothes or other things or fishing in any public spring, tank well, public-water course or part thereof
within the municipality and may set apart any such place for drinking or for bathing or for washing
clothes or animals respectively or for any other specified purpose.
243. Provision of public wash houses.
(1)The council may construct or provide and maintain public wash-houses or places for the washing
of clothes, and may require the payment of such rents and fees for the use of any such wash-house
or place as it may determine.(2)The council may farm out the collection of such rents and fees for
any period not exceeding three years at a time on such terms and conditions as it may think fit.(3)If
a sufficient number of public wash-houses or places be not maintained under sub-section (1), the
council may, without making any charge therefor appoint suitable places for exercise by was her
men of their calling.
244. Prohibition against washing by was her men at unauthorised places.
(1)The council may, by public notice, prohibit the washing of clothes by was her men in the exercise
of their calling, either within the municipality or outside the municipality, within three kilometres of
the boundary thereof except at--(a)public wash-houses or places maintained or provided under
Section 243, or(b)such other places as it may appoint for the purpose.(2)When any such prohibition
has been made, no person who is by calling a washerman shall, in contravention of such prohibition,
wash clothes except for himself or for personal and family service or for hire on and within the
premises of the hirer, at any place within or outside municipal limits other than a public wash-house
or a place maintained or appointed under this Act:Provided that this section shall apply only to
clothes washed within or be brought within the municipality.
245. Prohibition against defiling water of tanks etc., whether public or private.
- It shall not be lawful for any person to--(a)bathe in or in any manner defile the water in any place
set apart by the council or by the owner thereof for drinking purposes;(b)deposit any offensive or
deleterious matter in the dry bed of any place set apart as aforesaid for drinking purposes; or(c)wash
clothes in any place set apart as aforesaid for drinking or bathing; or(d)wash any animal or any
cooking utensil or wool, skins, or other foul or offensive substances or deposit any offensive or
deleterious matter in any place set apart as aforesaid for bathing or washing clothes, or(e)cause or
permit to drain into or upon any place set apart as aforesaid for drinking, bathing or washing
clothes, or cause or permit any thing to be brought therein or do anything whereby the water may be
fouled or corrupted. Control over abandoned Lands. Untrimmed Hedges, etc.
246. Untenanted buildings or lands.
- If any building or land, by reason of abandonment, disputed ownership or other cause remains
untenanted, and thereby becomes a resort of idle and disorderly persons or in the opinion of theAndhra Pradesh Municipalities Act, 1965

municipal health officer becomes a nuisance, the municipal health officer may, after due enquiry, by
notice require the owner or person claiming to be the owner to secure, enclose, clear or cleanse the
same.
247. Removal of filth or noxious vegetation.
- The municipal health officer may, by notice require the owner or occupier of any building or land
which appears to the said officer to be in filthy or unwholesome state, or overgrown with any thick
or noxious vegetation, trees or undergrowth injurious to health or offensive to the neighbourhood to
clear, cleanse or otherwise put the land in proper state or to clear away and remove such vegetation,
trees or undergrowth within twenty-four hours or such longer period and in such manner as may be
specified in the notice.
248. Fencing of buildings or lands and pruning of hedges and trees.
- The Commissioner may, by notice and for the reasons specified therein, require the owner or
occupier of any building or land near a public street to --(a)fence the same to the satisfaction of the
said officer; or(b)prune any hedges bordering on the said street so that they may not exceed such
height from the level of the adjoining roadway as the said officer may determine; or(c)cut any
hedges or trees overhanging the said street and obstructing it or the view of traffic or causing it
damage; or(d)lower an enclosing wall or fence which by reason of its height and situation, obstructs
the view of traffic so as to cause danger.
249. Lime quashing, cleaning, etc., of buildings.
- The municipal health officer, if it appears to him necessary for sanitary purposes so to do, may, by
notice require the owner or occupier of any building to lime-wash or otherwise cleanse or disinfect
the building inside and outside or cleanse or disinfect any article therein which is likely to retain
infection, in the manner and within a period to be specified in the notice.
250. Further powers with reference to insanitary buildings.
(1)Whenever the municipal health officer considers--(a)that any building or portion thereof is, by
reason of its having no plinth, or having a plinth of insufficient height or by reason of the want of
proper drainage or ventilation or by reason of the impracticability of cleansing, attended with
danger of disease to the occupier thereof or to the inhabitants of the neighbourhood, or is, for any
reason, likely to endanger the public health or safety, or(b)that a block or group of buildings is, for
any of the said reasons or by reason of the manner in which the buildings are crowded together,
attended with such risk as aforesaid, he may, by notice, require the owners or occupiers of such
buildings or portions of buildings, or at his option, the owners of the land occupied by such
buildings or portions of buildings, to execute such works or to take such measures as he may deem
necessary for the prevention of such danger.(2)No person shall be entitled to compensation for
damages sustained by reason of any action taken under or in pursuance of this section save when aAndhra Pradesh Municipalities Act, 1965

building is demolished in pursuance of an order made hereunder, or so far demolished as to require
reconstruction in which case the council shall make compensation to the owner thereof.(3)When
any building is entirely demolished under this section and the demolition thereof adds to the value
of other buildings in the immediate vicinity, the owners of such other buildings shall be bound to
contribute towards the compensation payable to the owner of the first named building in proportion
to the increased value acquired by their own property.(4)When any building is so far demolished
under this section as to require reconstruction, allowance shall be made in determining the
compensation for the benefit accruing to the premises from the improvement thereof.
251. Buildings unfit for human habitation.
(1)If any building or portion thereof intended for or used as a dwelling place appears to the
municipal health officer to be unfit for human habitation, he may by order prohibit the further use
of such structure for such purpose, after giving the owner and occupier of the structure a reasonable
opportunity of showing cause why such order should not be made.(2)When any such prohibitory
order has been made, the municipal health officer shall communicate the purport thereof to the
owner and occupier of the structure and on expiry of such period as is specified in the notice, not
being less than thirty days after the service of the notice, no owner or occupier of such structure
shall use or allow it to be used for human habitation, until the said officer certifies in writing that the
causes rendering it unfit for human habitation have been removed to his satisfaction.(3)When such
prohibitory order has remained in operation for three months, the said officer shall report the case
to the Commissioner, who shall place the matter before the council for considering the question
whether the structure should not be demolished. The Council shall give the owner not less than
thirty days notice of the time and place at which the question will be considered and the owner shall
be entitled to be heard when the question is taken into consideration.(4)If upon such consideration
the Council is of the opinion that the structure has not been rendered fit for human habitation and
that steps are not being taken with due diligence to render it so fit, it shall record a decision to that
effect with the grounds of the decision and the municipal health officer shall, in pursuance of the
said decision by notice, require the owner to demolish the structure.(5)If the owner undertakes to
execute forthwith the works necessary to render the structure fit for human habitation and the
municipal health officer considers that it can be so made fit, the council may postpone the execution
of its decision for such time not exceeding six months as it thinks sufficient for the purpose of giving
the owner an opportunity of executing the necessary works.
252. Abatement of over-crowding in dwelling houses or dwelling place.
(1)If it appears to the municipal health officer that any dwelling house or other building which is
used as a dwelling place or any room in such dwelling house or building is so over- crowded as to
endanger the health of the inmates thereof, he may report to the Commissioner who shall place the
matter before the council for an order to abate such over crowding; and the council may, by written
order, require the owner of the building, or room, within a reasonable time not exceeding thirty days
to be specified in the said order, to abate such overcrowding by reducing the number of lodgers,
tenants or other inmates of the building or room, or may pass such other orders as it may deem just
and proper.(2)The Council may, by written order, declare what amount of superficial and cubicAndhra Pradesh Municipalities Act, 1965

space shall be deemed for the purpose of sub-section (1) to be necessary for each occupant of a
building or room.(3)If any building or room referred to in sub-section (1) has been sublet, the
landlord of the lodgers, tenants, or other actual inmates of the same, shall for the purposes of this
section, be deemed to be the owner of the building or room.(4)Notwithstanding anything in the
Andhra Pradesh Buildings (Lease, Rent and Eviction) Control Act, 1960, it shall be incumbent on
every tenant, lodger or other inmate of a building or room to vacate on being required by the owner
so to do, in pursuance of any requisition made under sub-section (1).
253. Prohibition against feeding certain animals on filth.
- No person shall feed any animal, which is kept for dairy purposes or may be used for food on filth.
254. Prohibition against keeping animal so as to be a nuisance or dangerous.
- No person shall keep any animal on his premises so as to be a nuisance or so as to be a dangerous
to the public.
255. Power to destroy stray pigs and dogs.
(1)The Commissioner may give public notice that unlicensed pigs or dogs straying within specified
limits will be destroyed.(2)When such notice has been given, any person may destroy, in any
manner not inconsistent with the terms of the notice, any unlicensed pig or dog, as the case may be,
found straying within such limits.
256. Power to use or sell materials of dangerous structures taken down etc.
- When any officer of the municipality pulls down any structure or part thereof or cuts down any tree
or hedge or shrub or part thereof or removes any fruit by virtue of his powers under this chapter,
such officer may sell the materials or things taken down, cut down or removed and apply the
proceeds towards, payment of the expenses incurred.
257. Procedure where there is no owner or occupier.
- If after reasonable inquiry, it appears to any officer of the municipality that there is no owner or
occupier to whom notice can be given under any section in this chapter, he may himself take such
action as may appear to him to be necessary.
258. Limitation of compensation.
- No person shall be entitled, save as provided in Sections 237, 238 and 250 to compensation for any
damages sustained by reason of any action taken by the municipal authorities in pursuance of their
powers under this chapter.Andhra Pradesh Municipalities Act, 1965

Chapter 6
Licences and fees
259. Central or State Government not required to take out licence etc.
(1)The State Government or the Central Government shall not be required to take out any licence as
provide by or under this Act in respect of their property or in respect of any place in their occupation
or under their control.(2)The State Government or the Central Government shall not be required to
obtain any permission as provided by or under this Act in respect of erection, re-erection,
construction, alteration or maintenance of buildings used or required for the public service or for
any public purpose which is the property, or in the occupation of the Government concerned, or
which is to be erected on land, which is the property, or in the occupation, of the Government
concerned:Provided that, where the erection, re-erection, construction or material or structural
alteration of any such building as aforesaid (not being a building connected with defence, or a
building the plan or construction of which, in the opinion of the Government concerned, is treated
as confidential or secret) is contemplated, reasonable notice of the proposed work shall be given to
the council before it is commenced.(3)In the case of any such building (not being a building
connected with defence or a building the plan or construction of which in the opinion of the
Government concerned, is treated as confidential or secret) the Chairperson or any person,
authorised by him in this behalf, may, under intimation to the State Government, inspect the land
and building and all plans connected with its erection, re-erection, construction, or material
structural alteration, as the case may be, and may submit to the State Government a statement in
writing of any objections or suggestions which the Chairperson may deem fit to make with reference
to such erection, reaction, construction or material structural alteration.(4)Every objection or
suggestion submitted as aforesaid shall be considered by the State Government, which shall, after
such investigation if any, as they shall think advisable, and after obtaining the views of the Central
Government in the matter, where necessary pass orders thereon, and the building referred to
therein shall be erected, re-erected, constructed or altered, as the case may be, in accordance with
such orders:Provided that, if the State Government over-rule or disregard any such objection or
suggestion as aforesaid, they shall give reasons for so doing in writing.
260. Licences for places in which animals are kept.
(1)The owner or occupier of any stable, veterinary infirmary, stand, shed, yard or other place in
which animals are kept or taken in for purposes of profit shall apply to the municipal health officer
for a licence not less than thirty days and not more than ninety days before the opening of such
place, or the commencement of the year for which the licence is sought to be renewed, as the case
may be.(2)The municipal health officer may, by an order and under such restrictions and
regulations as he thinks fit, grant or refuse to grant such licence.(3)No person shall, without or
otherwise than in conformity with a licence, use any place for such a purpose:Provided that this
section shall not apply to any such place licensed as a place of public entertainment or resort under
the Andhra Pradesh (Andhra Area) Places of Public Resort Act, 1888 (Act II of 1888), or any other
law similar thereto for the time being in force.Andhra Pradesh Municipalities Act, 1965

261. General powers of control over stables, cattle-sheds and cow-houses.
(1)All stables, cattle-sheds and cow-houses whether they are built separately or whether they form
part of the residential buildings, shall be under the control of the municipal health officer as regards
their site, construction, materials and dimensions.(2)The municipal health officer may by notice
require that any stable, cattle-shed or cow-house be altered, paved, drained, repaired, disinfected or
kept in such a state as to admit of its being sufficiently cleaned or be supplied with water or be
connected with a sewer.(3)Every such notice shall be addressed to the owner of the building or land
to which the stable, cattle-shed or cow-house belongs.(4)The expense of executing any work in
pursuance of any such notice shall be borne by the said owner.
262. Power to direct discontinuance of use of buildings as stable, cattle-shed
or cow-house.
- If any stable, cattle-shed or cow-house is not constructed or maintained in the manner required by
or under this Act, the municipal health officer may, by notice, direct that the same shall be no longer
used as a stable, cattleshed or cow-house. Every such notice shall state the grounds on which it
proceeds.
263. Purposes for which places may not be used without licences.
(1)The council may publish a notification in the prescribed manner that no place within municipal
limits or at a distance within three kilometres of such limits shall be used for any one or more of the
purposes specified in Schedule IV without the licence of the Commissioner and except in accordance
with the conditions specified therein:Provided that no notification shall take effect--(a)until sixty
days from the date of publication: and(b)except with the previous sanction of the Government in
any area outside the municipal limits.(2)The owner or occupier of every such place shall, within
thirty days of the publication of such notification, apply to the Commissioner for a licence for the use
of such place for such purpose.(3)Applications for renewal of such licences shall be made not less
than thirty days and not more than ninety days before the end of every year and applications for
licences for places to be newly opened shall be made not less than thirty days and not more than
ninety days before they are opened.(4)The Commissioner may, by an order and under such
restrictions and regulations as to supervision and inspection as he thinks fit, grant or refuse to grant
or renew such licence.(5)In case the Commissioner refuses to grant or renew any such licence, he
shall record the reasons therefor.(6)Every such licence shall expire at the end of the year, unless for
special reasons the Commissioner considers it should expire at an earlier date when it shall expire at
such earlier date as may be specified therein.(7)Where a licence is granted or renewed under this
section for the use of any place outside the municipal limits, the council shall pay to the Gram
Panchayat; if any, having jurisdiction over such place or if there is no such Gram Panchayat, to such
other authority as the Government may specify such portion of the fee received for the grant or
renewal of the licence as the Government may, by general or special order, direct.Andhra Pradesh Municipalities Act, 1965

264. Application to be made for construction, establishment or installation of
factory, workshop or work-place in which steam or other power is to be
employed.
(1)Every person intending--(a)to construct or establish any factory, workshop or work-place in
which it is proposed to employ steam power, water-power or other mechanical power or Electrical
power; or(b)to install in any premises any machinery or manufacturing plant driven by steam, water
or other power as aforesaid (not being machinery or manufacturing plant exempted by rules), shall,
before beginning such construction, establishment or installation make an application in writing to
the council for permission to undertake the intended work.(2)The application shall specify the
maximum number of workers proposed to be employed on any day in the factory, workshop,
work-place or premises and shall be accompanied by--(i)a plan of the factory, work-shop,
work-place or premises prepared in such manner as may be prescribed by rules made in this behalf
by the Government; and(ii)such particulars as to the power, machinery, plant or premises as the
council may require by bye-laws made in this behalf.(3)The council shall, within sixty days after
obtaining approval under sub-section (4)--(a)grant the permission applied for, either absolutely or
subject to such conditions as it thinks fit to impose; or(b)refuse permission, if it is of opinion that
such construction, establishment or installation is objectionable by reason of the density of the
population in the neighbourhood or that it is likely to cause a nuisance.(4)(a)Before granting
permission under sub-section (3) the council shall obtain the approval of the Inspector of Factories
appointed under the Factories Act, 1948 (Central Act 63 of 1948), having jurisdiction in the area of
the municipality, or if there is more than one such inspector, of the inspector designated by the
Government in this behalf by general or special order, as regards the plan of the factory, workshop,
work-place or premises with reference to--(i)the adequacy of the provision for ventilation and
light;(ii)the sufficiency of the height and dimensions of the rooms and doors;(iii)the suitability of
the exists to be used in case of fire; and(iv)such other matters as may be prescribed by rules made by
the Government.(b)Before granting permission under sub-section (3), the council shall consult and
have due regard to the opinion of the Municipal Health Officer or where there is no such officer, of
the District Medical and Health Officer, as regards the suitability of the site of the factory,
work-shop, work-place or premises for the purpose specified in the application.(5)No worker shall
be employed on any day in any factory, workshop, work-place, or premises, unless the permission
granted in respect thereof under sub-section (3) authorises such employment, or unless fresh
permission authorising such employment has been obtained from the council. Before granting such
fresh permission, the council shall obtain the approval of the Inspector of Factories referred to in
sub-section (4) as regards the plan of the factory, work-shop, work-place, or premises, with
reference to the matters specified in that clause.(6)The grant of permission under this
section--(a)shall, in regard to the replacement of machinery, the levy of fees, the conditions to be
observed and the like, be subject to such restrictions and control as may be prescribed; and(b)shall
not be deemed to dispense with the necessity for compliance with the provisions of Sections 209 and
211 or Sections 220 and 221, as the case may be.Explanation. - The word 'worker' in sub-sections (2)
and (5) shall, in relation to any factory, workshop, workplace or premises have the same meaning as
in the Factories Act, 1948 (Central Act 63 of 1948).Andhra Pradesh Municipalities Act, 1965

265. Use of steam whistles etc.
(1)No person shall, without the written permission of the council, use or employ in any factory or
other place any steam whistle or steam trumpet for the purpose of summoning or dismissing
workers or persons employed.(2)In granting such permission, the council may impose such
conditions as it may think proper as to the times at which the whistle or trumpet may be used, and it
may revoke any such permission by giving a week's notice.
266. Council may issue directions for abatement of nuisance caused by
steam or other power.
(1)If, in any factory, work-shop or work-place in which steam-power, water-power or other
mechanical power or electrical power is used, nuisance in the opinion of the council caused by
reason of the particular kind of fuel employed or by reason of the noise or vibration created, the
Council may issue such directions as it thinks fit for the abatement of the nuisance within a
reasonable time to be specified for the purpose.(2)If there has been wilful default in carrying out
such directions or if abatement is found impracticable, the council may--(a)prohibit the use of the
particular kind of fuel employed; or(b)restrict the notice or vibration by prohibiting the working of
the factory, workshop or work-place between the hours of 9-30 p.m. and 5-30 a.m.
267. Power of Government to pass orders or give directions in respect of
action taken or omitted to be taken under Section 264, Section 265 or Section
266.
- The Government may, either generally or in any particular case, make such orders or give such
directions as they may deem fit in respect of any action taken or omitted to be taken under Section
264, Section 265, or Section 266.
268. Notification of residential, industrial, commercial, etc., areas in the
municipality.
(1)Every council shall, as soon as may be after commencement of this Act, and after consultation
with the Director of Public Health and of the Director of Town-Planning, and with the previous
approval of the Government, notify in the prescribed manner the localities, divisions, wards, streets
or portions of streets, in its local limits which shall be reserved for residential, industrial,
commercial or agricultural purposes.(2)The council may, at any time subsequent to the issue of a
notification under sub-section (1), in like manner and subject to the like consultation and approval,
notify any additional localities, divisions, wards, streets or portions of streets as areas which shall be
reserved for any of the purposes specified in sub-section (1).(3)(a)A notification issued under
sub-section (1) or Sub- section (2) may declare that a land in an area reserved for a particular
purpose shall not be used for any other purpose and that the use of a land in any reserved area shall
be confined only for the purpose for which the area is reserved or that the land may be used for any
other purpose subject to such restrictions, limitations and conditions as are specified in thatAndhra Pradesh Municipalities Act, 1965

notification.(b)The notification shall contain also such general information as to the situation and
limits of the areas proposed to be reserved for different purposes specified in sub-section (1) and the
restrictions, limitations and conditions, if any, proposed to be imposed in regard to the use of land
in each such reserved area.(4)Any person aggrieved by the issue of a notification under sub-section
(1) may appeal to the Government whose decision shall be final.
269. Power of Government to notify the location of the industries.
- Where the council has not published a notification under Section 263 or 268, the Government
may, by notification in the Andhra Pradesh Gazette, specify any particular industry or class of
industries to be located in any area reserved for residential, industrial, commercial or agricultural
purposes, under this Act.
270. The Commissioner may enter any factory, workshop or work place.
(1)The Chairperson, Commissioner or any person authorised by the Council in this behalf may enter
any factory, workshop or work place(a)at any time between sunrise and sunset;(b)at any time when
any industry is being carried on; and(c)at any time by day or by night, if he has reason to believe
that any offence is being committed under Section 264, Section 265 or Section 266(2)No claim shall
lie against any person for any damage or inconvenience necessarily caused by the exercise of powers
under this section or by the use of any force necessary for the purpose of affecting an entrance under
this section.
271. Provision of municipal slaughter-houses.
(1)The council shall provide a sufficient number of places for use as municipal slaughter-houses and
may charge rents and fees for their use at such rates as it may think fit.(2)The council may,--(a)place
the collection of such rents and fees under the management of such persons as may be appear to it
proper; or(b)farm out such collection for any period not exceeding three years at a time and on such
terms and conditions as it may think fit.(3)Municipal slaughter-houses may be situated within or,
with the sanction of the Government, outside the municipality.
272. Licence for slaughter-houses.
(1)The owner of any place within municipal limits or at a distance within three kilometres of such
limits which is used as a slaughter-house for the slaughtering of animals or for the skinning or
cutting up of any carcasses, shall apply to the municipal health officer for a licence not less than
thirty days and not more than ninety days before the opening of such place as a slaughter-house, or
the commencement of the year for which the licence is sought to be renewed as the case may
be:Provided that this sub-section shall not take effect in any area outside the municipal limits except
with the previous sanction of the Government.(2)The municipal health officer may, by an order and
subject to such restrictions and regulations as to supervision and inspection as he thinks fit, grant,
or refuse to grant such licence.Andhra Pradesh Municipalities Act, 1965

273. Slaughter of animals for sale as food.
- No person shall slaughter within the municipality except in a public or licensed slaughter-house
any cattle, horse, sheep, goat or pig, or any other animal for sale as food or skin or cut up any carcass
without or otherwise than in conformity with a licence from the municipal health officer or dry or
permit to be dried any skin in such a manner as to cause a nuisance.
274. Slaughter of animals during festivals and religious ceremonies.
- Subject to the provisions of the law relating to the prohibition of sacrifices of animals and birds for
the time being in force the municipal health officer may allow any animal to be slaughtered in such
places as he thinks fit on occasions of festivals and religious ceremonies or as a special
measure:Provided that no such place shall be outside the premises where festivals and religious
ceremonies are conducted.
275. Regulations of milk trade.
(1)No person shall, without, or otherwise than in conformity with a licence from the municipal
health officer,--(a)carry on within the municipality the trade or business of a dealer in, or importer
or seller or hawker of, milk, or dairy-produce;(b)use any place in the municipality for carrying on
the trade or business or selling of milk or dairy-produce:Provided that no such licence shall be given
to any person who is suffering from an infectious disease.(2)Such licence may be refused or may be
granted on such conditions as the municipal health officer may deem necessary which may extend to
the construction, ventilation, conservancy, supervision and inspection of the premises, whether
within or outside municipal limits where the animals from which the milk supply is derived are kept.
276. Public markets.
(1)All markets which are acquired, constructed, repaired or maintained out of the municipal fund
shall be deemed to be public markets; and such markets shall be open to all
persons.(2)Notwithstanding anything in the relevant law for the time being in force, every market
situated within the municipal limits and belonging to a Gram Panchayat, Panchayat Samithi or Zilla
Parishad shall vest in the municipality. The Government shall determine, in the manner prescribed,
the amount of compensation payable therefor to the Gram Panchayat, Panchayat Samithi or the
Zilla Parishad, as the case may be.
277. Power in respect of public markets.
(1)The council may provide places for use as public markets.(2)The council may, in any public
market, levy any one or more of the following fees at such rates and may place the collection of such
fees under the management of such persons as may appear to it proper or may farm out such fees
for any period not exceeding one year at a time and on such terms and subject to such conditions as
it may deem fit--(a)fees for the use of, or for the right to expose goods for sale in suchAndhra Pradesh Municipalities Act, 1965

markets;(b)fees for the use of shops, stalls, pens or stands in such markets;(c)fees on vehicles or
pack-animals carrying, or on persons bringing goods for sale in such markets;(d)fees on animals
brought for sale into, or sold in such markets; and(e)licence fees on brokers, commission agents,
weigh men and measurers practising their calling in such markets.(3)The council may, with the
sanction of the Government close any public market or part thereof.(4)The council may lease any
land, shop, godown, building or terrace of a building owned by it and situated anywhere in the
municipality for any period not exceeding five years at a time and subject to such terms and
conditions as the council may deem fit:Provided that it shall be competent for the council to grant,
with the prior sanction of the Government, any such lease for a period exceeding five years but not
exceeding twenty-five years at a time.
278. Control of the Municipal Health Office over public markets.
(1)No person shall, without the permission of the municipal health officer, or if the fees have been
farmed out, of the farmer sell or expose for sale any animal or article within any public
market.(2)The Municipal Health Officer may expel from any public market any person who or
whose servant has been convicted of disobeying any bye-laws at the time in force in such market and
may prevent such person from further carrying on by himself, or his servants or agents, any trade or
business in such market or occupying any shop, stall or other place therein and may determine any
lease or tenure which such person may possess in any such shop, stall or place.
279. Licence for private market.
(1)No person shall open a new private market or continue to keep open a private market unless he
obtains from the Council a licence to do so.(2)Application for such licence shall be made by the
owner of the place in respect of which the licence is sought not less than thirty days and not more
than ninety days, before such place is opened as a market, or the commencement of the year for
which the licence is sought to be renewed, as the case may be.(3)The Council shall, as regards
private markets already lawfully established and may, at its discretion as regards new private
markets, grant the licence applied for, subject to such regulations as to supervision and inspection
and to such conditions as to sanitation, drainage, water-supply, width of paths and ways, weights
and measures to be used, and rents and fees to be charged in such markets as the Council may think
proper; or the Council may refuse to grant any such licence for any new private market. The Council
may, however, at any time, for breach of the conditions thereof, suspend or cancel any licence which
has been granted under this section. The Council may also modify the conditions of the licence to
take effect from a specified date.(4)When a licence is granted, refused, suspended cancelled or
modified under this section, the Council shall cause a notice of such grant, refusal, suspension,
cancellation or modification in English and in the main language of the district to be pasted in some
conspicuous place at or near the entrance to the place in respect of which the licence was sought or
had been obtained.(5)Every licence granted under this section shall expire at the end of the year.Andhra Pradesh Municipalities Act, 1965

280. Fee for licence.
- When a licence granted under Section 279 permits the levy of any fees of the nature specified in
sub-section (2) of Section 277, a fee not exceeding fifteen per centum of the gross income of the
owner from the market in the preceding year shall be charged by the Council for such licence.
281. Sale in unlicensed private markets.
- It shall not be lawful for any person to sell, or expose for sale any animal or article in any
unlicensed private market.
282. Powers of Council in respect of private markets.
- The Council may, by notice, require the owner, occupier, or farmer of any private market
to--(a)construct approaches, entrances, passages, gates, drains and cess pits for such market and
provide it with latrines of such description and in such position and number as the Council may
think fit;(b)roof and pave the whole or any portion of the floor with such material as will, in the
opinion of the Council, secure imperviousness and ready cleansing;(c)ventilate it properly and
provide it with supply of water;(d)provide passages of sufficient width between the stalls and make
such alterations in the stalls, passage, shops, doors or other parts of the market as the Council may
direct; and(e)keep it in a cleanly and proper state and remove all filth and refuse therefrom.
283. Suspension or refusal of licence in default.
(1)If any person, after notice given to him in that behalf by the council, fails within the period and in
the manner laid down in the said notice, to carry out any of the works specified in Section 282, the
Council may suspend the licence, or may refuse to grant the licence, until such works have been
completed.(2)It shall not be lawful for any person to open or keep open any such market after such
suspension or refusal.
284. Prohibition against nuisances in private markets.
- No owner, occupier, agent or manager in charge of any private market or of any shop, stall, shed or
other place therein, shall keep the same so that it is a nuisance, or fall to cause anything that is a
nuisance to be at once removed to a place to be specified by the Council.
285. Power to close private markets.
- The Council or any officer duly authorised by it in that behalf, may close any private market in
respect of which no licence has been applied for or the licence for which has been refused, withheld
or suspended or which is held or kept open contrary to the provisions of this Act.Andhra Pradesh Municipalities Act, 1965

286. Acquisition of rights of private person to hold private markets.
(1)A Council may acquire the rights of any person to hold a private market in any place and to levy
fees therein. The acquisition shall be made under the Land Acquisition Act, 1894 (Central Act 1 of
1894) and such rights shall be deemed to be laid for the purposes of this Act, subject, however, to the
condition that the amount payable as compensation in respect of the rights so acquired shall be an
amount equal to twelve times the net average annual income actually derived from such market
during the period of five consecutive years immediately preceding the date of publication of the
notification under sub-section (1) of Section 4 of that Act.(2)On payment by the Council of the
compensation as provided in sub-section (1) in respect of such property and any other charges
incurred in acquiring it, the rights of such person to hold a private market and to levy fees therein
shall vest in the Council.
287. Duty of expelling lepers, etc., from markets and power to expel
disturbers.
- The person in charge of a market or the Municipal Health Officer shall prevent the entry therein or
expel therefrom any person suffering from leprosy, in whom the process of ulceration has
commenced, or from any infectious or contagious disease who sells or exposes for sale therein any
article or who, not having purchased the same, handles any articles exposed for sale therein, and he
may expel therefrom any person who is creating a disturbance therein.
288. Butchers, fish-mongers, poulterer's licence.
(1)No person shall, without or otherwise than in conformity with a licence from the Municipal
Health Officer, carry on the trade of a butcher, fish-monger or poulterer or use any place for the sale
of flesh or fish intended for human food in any place within municipal limits at a distance within
three kilometers of such limits: Provided that no licence shall be required for a place used for the
selling or storing for sale of preserved flesh or fish contained in airtight and hermitically sealed
receptacles;Provided further that no licence shall be required for any place included in a public
market established by or vested in a Panchayat Samithi or Zilla Parishad.(2)The Municipal Health
Officer, may, by an order and subject to such restrictions as to supervision and inspection as he
thinks fit, grant or refuse to grant such licence.(3)Every such licence shall expire at the end of the
year in which it is granted, unless for special reasons the Municipal Health Officer considers that it
should expire at an earlier date, when it shall expire at such earlier date as may be specified therein
289. Power to prohibit or regulate sale of articles in public streets.
(1)The Commissioner may, with the sanction of the Council, prohibit by public notice or licence or
regulate the sale or exposure for sale, of any animals or articles in or on any public street or part
thereof.(2)The Commissioner may farm out the collection of fees for licences leviable under
sub-section (1) for any period not exceeding one year at a time on such terms and conditions as may
be determined by the Council.Andhra Pradesh Municipalities Act, 1965

290. Decision of disputes as to whether places are markets.
- If any question arises whether any place where persons assemble for the sale or purchase of
articles of food or clothing, or live-stock or poultry, or cotton, groundnut or other industrial crops or
of any other raw or manufactured products is a market or not, the council shall make a reference to
the Government and the decision of the Government on the question shall be final.
291. Provision of public cart-stands, etc.
- The council may construct or provide and maintain public landing places, halting places and
cart-stands.
292. Prohibition of use of public place or sides of public street as
cart-stands, etc.
- Where a council has provided a public landing place, halting place or cart-stand, the Commissioner
may prohibit the use for the same purpose by any person within such distance thereof, as may be
determined by the council, or any public place or the sides of any public street.
293. Duty of Municipal Health Officer to inspect.
- It shall be the duty of the Municipal Health Officer to make provision for the constant and vigilant
inspection of animals, carcasses, meat, poultry, game, flesh, fish, fruit, vegetables, corn, bread, flour,
milk, ghee, butter, oil and any other edible articles exposed or hawked about for sale or deposited in
or brought to any place for the purpose of sale or of preparation for sale.
294. Powers of Municipal Health Officer for purpose of inspection.
(1)The Municipal Health Officer or any person authorised by him in writing for the purpose may,
without notice, enter any slaughter-house or any place where animals, poultry or fish intended for
food are exposed for sale or where articles of food are being manufactured or exposed for sale, at any
time by day or night, when the slaughter, exposure for sale or manufacture is being carried on and
inspect the same and any utensil or vessel used for manufacturing, preparing or containing any such
article.(2)If the Municipal Health Officer or any person so authorised by him has reason to believe
that in any place any animal intended for human food is being slaughtered or any carcass is being
skinned or cut up or that any food is being manufactured, stored, prepared, packed, cleansed, kept
or exposed for sale, or sold without or otherwise than in conformity with a licence, he may enter any
such place without notice, at any time by day or night, for the purpose of satisfying himself whether
any provision of laws, bye-laws or regulations or any condition of licence is being contravened.(3)No
claim shall lie against the Municipal Health Officer or any person acting under his authority or the
council, for any damage or inconvenience necessarily caused in good faith by the exercise of powers
under this section or by the use of any force necessary for effecting any entry into any place under
this section.(4)In any legal proceedings in respect of powers exercised under this section in which itAndhra Pradesh Municipalities Act, 1965

is alleged that any animals, poultry, fish or articles of food were not kept, exposed, hawked about,
manufactured, prepared, stored, packed, or cleansed for sale, or that they were not intended for
human food the burden of proof shall lie on the party so alleging.
295. Preventing inspection by Municipal Health Officer.
- No person shall, in any manner whatsoever, prevent the Municipal Health Officer or person duly
authorised by him from exercising his powers under the last preceding section.
296. Power of Municipal Health Officer to seize diseased animals, noxious
food etc.
- If any animal, poultry or fish intended for food appears to the municipal health officer or to a
person duly authorised by him to be diseased, or any food appears to him to be noxious or if utensil
or vessel used in manufacturing or preparing or containing such article, appears to be of such kind
or in such state as to render the article noxious, he may seize or carry away or secure such animal,
article, utensil, or vessel in order that the same may be dealt with as hereinafter
provided.Explanation. - Meat subject to the process of blowing and decomposition shall be deemed
to be noxious.
297. Removing or interfering with articles seized.
- No person shall remove or in any way interfere with an animal or article secured under the last
preceding section.
298. Power to destroy article seized.
(1)Where any animal or article of food is seized under Section 296 it may, with the consent of the
owner or person in whose possession it was found, be forthwith destroyed by the municipal health
officer so as to prevent its being used for human food or exposed for sale, and if the article is
perishable, without such consent.(2)Any expenses incurred in destroying any animal or article
under sub-section (1) shall be paid by the owner or person in whose possession it was at the time of
its seizure.
299. Production of seized articles, etc., before magistrate and power of
magistrate to deal with them.
(1)Articles of food, animals, poultry, fish, utensils, vessels, etc., seized under Section 296 and not
destroyed under Section 298, shall as soon as possible, be produced by the municipal health officer
before a Judicial Second Class Magistrate.(2)Whether or not complaint is laid before a Judicial
Second Class Magistrate of any offence under the Indian Penal Code or under this Act, if it appears
to the magistrate on taking such evidence as he thinks necessary that any such animal, poultry or
fish is diseased, or any such article is noxious or any such utensil or vessel is of such kind or in suchAndhra Pradesh Municipalities Act, 1965

state as is described in Section 296, he may order the same--(a)to be forfeited to the council; or(b)to
be destroyed at the expense of the owner or person in whose possession it was at the time of seizure
so as to prevent the same being again exposed or hawked about for sale, or used for human food for
the manufacture or preparation of, or for containing any such article as aforesaid.
300. Registration or closing of places for disposal of the dead.
(1)Every owner or person having the control of any place used at the date of the coming into
operation of this Act, as a place for burying, burning, or otherwise disposing of the dead shall, if
such place be not already registered, apply to the council to have such place registered.(2)If it
appears to the council that there is no owner or person having the control of such place, it shall
assume control of and register such place, or may, with the sanction of the Government, close it.
301. Licensing of places for disposal of the dead.
(1)No place for the disposal of the dead, whether public or private, shall be opened, formed,
constructed, or used, unless a licence has been obtained from the council on application.(2)Such
application for a licence shall be accompanied by a plan of the place to be registered, showing the
locality, boundary and extent thereof, the name of the owner or person or community interested
therein, the system of management and such further particulars as the council may require.(3)On
receipt of the application, the council shall cause a notice to be given inviting objections or
suggestions from the public within a period of thirty days from the date of such notice. The council
may, after considering the objections or suggestions received, if any,--(a)grant or refuse a licence;
or(b)postpone the grant of a licence until objections to the site have been removed or any particulars
called for by it have been furnished.
302. Provision of burial and burning grounds and crematoria within or
outside municipality.
(1)The council shall provide, free of charge, places to be used as burial or burning grounds or
crematoria either within or outside the limits of the municipality.(2)If the council provides any such
place outside the limits of the municipality, all the provisions of this Act and all bye-laws framed
under this Act for the management of such places within the municipality, shall apply to such place.
303. Register of burial grounds.
(1)A book shall be kept at the municipal office containing a list of all the burial or burning grounds
or crematoria, registered, licensed or provided by the municipality, together with the plans
thereof.(2)Notice that such place has been registered, licenced or provided as aforesaid shall be
affixed in English and in the main language of the district in some conspicuous place at or near the
entrance to the burial or burning ground or other place as aforesaid.(3)No person shall bury, burn
or otherwise dispose of any corpse except in a place which has been registered, licensed or provided
as aforesaid.Andhra Pradesh Municipalities Act, 1965

304. Report of burials and burnings.
- The person having control of a place for disposing of the dead shall give information of every burial
burning or other disposal of a corpse at such place to any person appointed by the municipal health
officer in that behalf.
305. Prohibition against use of burial and burning grounds dangerous to
health or overcrowded with graves.
(1)If the council is satisfied--(a)that any registered or licensed place for the disposal of the dead is in
such a state or situation as to be, or to be likely to become, dangerous to the health of persons living
in the neighbourhood thereof, or(b)that any burial ground is overcrowded with graves and if in the
case of a public burial or burning ground or other place as aforesaid, another convenient place duly
authorized for the disposal of the dead exists or has been provided for the persons who would
ordinarily make use of such place, it may, with the previous sanction of the Government, give notice
that it shall not be lawful after a period to be named, in such notice to bury, burn or otherwise
dispose of any corpse at such place.(2)Every notice given under sub-section (1) shall be published in
the prescribed manner.(3)After the expiry of the period named in such notice it shall not be lawful to
bury, burn or otherwise dispose of a corpse at such place.
306. Prohibition in respect of corpses.
- No person shall--(a)bury or cause to be buried, any corpse or part thereof in a grave whether dug
or constructed of masonry or other wise, in such manner that the surface of the coffin or the surface
of the body where no coffin is used, is at a depth less than one and a half meters from the surface of
the ground; or(b)build or dig or cause to be built or dug, any grave in any burial ground at a distance
less than half a metre from the margin of any other existing grave; or(c)without the sanction in
writing of the municipal health officer or an order in writing of a magistrate, reopen a grave;
or(d)when burning or causing to be burnt a corpse or part thereof permit the same or any part
thereof or its clothes to remain without being completely reduced to ashes; or(e)carry through any
street a corpse or part thereof not decently covered; or(f)while carrying a corpse or part thereof
within the municipality, leave the same in or near any street for any purpose whatever; or(g)remove,
otherwise than in a closed receptacle any corpse or part thereof kept or used for the purpose of
dissection.
307. Grave digger's licence.
- No person shall discharge the office of a grave digger or other attendant at a public place for the
disposal of the dead, other than a place provided by the Government, unless he has been licensed in
that behalf by the municipal health officer. Such licence may be withdrawn or cancelled at the
discretion of the council.Andhra Pradesh Municipalities Act, 1965

Chapter 7
Vital statistics and the prevention of diseases
308. Compulsory registration of vital statistics.
(1)The council shall register all births and deaths occurring in the municipality.(2)Information of
births and deaths shall be given and their registration shall be made and enforced in the prescribed
manner.
309. Definition of infectious disease.
- Infectious disease' means a disease specified in Schedule V.
310. Obligation of medical practitioner or owner or occupier of house to
report infectious disease.
(1)If any medical practitioner becomes cognizant of existence of any infectious disease in any private
or public dwellings not being a public hospital, in the municipality, he shall inform the municipal
health officer with the least practicable delay.(2)The information shall be communicated in such
form and with such details as the municipal health officer may require. The municipal health officer
may pay a fee not exceeding one rupee for each intimation by a private medical practitioner of a case
occurring in his practice.(3)This section shall apply to a Hakeem or a Vaidya.(4)With the previous
approval of the Collector of the district, the municipal health officer may direct the compulsory
notification by the owner or occupier of every house within the municipal limits during such period
and to such officer as the municipal health officer may specify of all deaths from or occurrence of
infectious diseases in his house.
311. Power of entry into suspected places.
- The municipal health officer shall, at any time by day or by night without notice, or after giving
such notice as may appear to him reasonable, inspect any place in which any infectious disease is
known or suspected to exist, and take such measures as he may think fit to prevent the spread of
such disease beyond such place.
312. Disinfection of buildings and articles.
(1)If the Municipal Health Officer is of opinion that the cleansing or disinfecting of any premises or
part thereof, or of any article therein which is likely to retain infection, will tend to prevent or check
the spread of any infectious disease, he may by notice require the occupier to cleanse or disinfect the
same in the manner and within the time specified in such notice.(2)If the municipal health officer
considers that immediate action is necessary, or that the occupier is, by reason of poverty or
otherwise unable effectually to comply with his requisition, the municipal health officer mayAndhra Pradesh Municipalities Act, 1965

himself, without notice, cause such premises or article to be cleansed or disinfected and for this
purpose may cause such article to be removed from the premises; and the expenses incurred by the
Municipal Health Officer shall be recoverable from the said occupier in cases in which he is, in the
opinion of the municipal health officer, not unable by reason of poverty effectually to comply with
such requisition.
313. Provision of places for disinfection and power to destroy infected
articles.
(1)The Municipal Health Officer shall, from time to time, notify places at which conveyances,
clothing, bedding, or other articles which have been exposed to infection from any infectious disease
shall be washed or disinfected.(2)The municipal health officer may direct any clothing, bedding or
other articles likely to retain such infection to be disinfected or destroyed and shall, on demand, give
compensation for any article destroyed under this subsection.(3)No person shall wash such clothing
or bedding or other articles in any places other than those set apart for such purposes under
sub-section (1).
314. Prohibition against transfer of infected articles.
- No person shall without previously disinfecting it give, lend, let, hire, sell, transmit or otherwise
dispose of any article, which he knows or has reason to know, has been exposed to infection from
any infectious disease:Provided that nothing in this section shall apply to a person who transmits
with proper precautions any article for the purpose of having it disinfected.
315. Power of "Chairperson" to prohibit use of water likely to spread
infection.
- If the chief medical officer of the district, the municipal health officer or the local medical officer
certifies that the water in any well, tank or other place within the limits of the municipality, is likely
if used for drinking, to endanger or cause the spread of any infectious disease, the Chairperson shall
by public notice, prohibit the use of such water for drinking and domestic purposes during a
specified period.
316. Municipal health officer may order removal of patients to hospitals.
- When a hospital or other place for the reception of persons suffering from infectious diseases is
provided by the council, the municipal health officer may, on a certificate signed by a medical
practitioner registered under the law relating to the registration of medical practitioners for the time
being in force, arrange for, or direct the removal to such hospital or place, or any person suffering
from an infectious disease who is, in the opinion of such medical practitioner without proper
lodging or accommodation, or without medical supervision directed to prevent the spread of the
disease, or who is in a place occupied by more than one family.Andhra Pradesh Municipalities Act, 1965

317. Prohibition against infected person carrying on occupation.
- If any person knows or has been certified by the municipal health officer, the local medical officer,
or a registered medical practitioner that he is suffering from an infectious disease, he shall not
engage in any occupation, or carry on any trade or business, which involves the risk of spreading the
disease.
318. Prohibition against person suffering from infectious disease entering
public conveyance.
(1)No person who is suffering from any infectious disease shall, without taking proper precautions
against spreading such disease, cause or allow himself to be conveyed in a public conveyance.(2)No
person who is suffering from any infectious disease shall enter a public conveyance without
previously notifying to the owner or driver or person-in-charge of such conveyance that he is so
suffering.(3)No owner, driver, or person-in-charge of a public conveyance shall knowingly carry or
permit to be carried in such conveyance any person suffering as aforesaid in contravention of
sub-section (1).(4)No owner or driver or person-in-charge of a public conveyance shall be bound to
convey any person suffering as aforesaid, unless and until the said person pays or tenders a sum
sufficient to cover any loss and costs that may be incurred in disinfecting such conveyance, anything
in any Act relating to public conveyances, for the time being in force to the contrary
notwithstanding.(5)A court convicting any person of contravening sub-section (1) or sub-section (2)
may levy, in addition to the penalty for the offence provided in this Act, an additional fine of such
amount as the Court deems sufficient to cover the loss and costs which the owner or driver must
incur for the purpose of disinfecting the conveyance. The amount of any additional fine so imposed
shall be awarded by the court to the owner or driver of the conveyance.Provided that if such
additional fine is imposed in a case which is subject to appeal, the amount shall not be paid to the
owner or driver before the period allowed for presenting the appeal has elapsed, or, if an appeal is
presented, before the decision of the appeal.(6)At the time of awarding compensation in any
subsequent civil suit relating to the same matter, the court shall take into account any sum which
the plaintiff shall have received under this section.
319. Letting of infected buildings.
(1)No person shall let or sub-let or allow any person to enter a building or any part of a building in
which he knows or has reason to know, that a person has been suffering from any infectious disease
without having the same and all articles therein liable to retain infection, disinfected to the
satisfaction of the municipal health officer.(2)For the purpose of sub-section (1), the keeper of a
hotel or lodging house shall be deemed to let the same or part of the same to any person
accommodated therein.Andhra Pradesh Municipalities Act, 1965

320. Power to order closure of places of public entertainment.
- In the event of the prevalence of any infectious disease within the municipality, the council may by
notice require the owner or occupier of any building, booth or tent used for purposes of public
entertainment to close the same for such period as it may fix.
321. Minor suffering from infectious disease not to attend school.
- No person, being the parent or having the care or charge of a minor who is or has been suffering
from an infectious disease or has been exposed to infection therefrom shall, after a notice from the
municipal health officer or the local medical officer that the minor is not to be sent to school or
college, permit such minor to attend school or college without having procured from the municipal
health officer, the local medical officer or a registered medical practitioner a certificate that in his
opinion such minor may attend without undue risk of communicating such disease to others. No fee
shall be charged by the Municipal Health Officer or the Local Medical Officer for the grant of a
certificate under this section. Small-pox
322. Compulsory vaccination.
(1)Vaccination shall be compulsory in every municipality in respect of such persons and to such
extent as may be prescribed.(2)The procedure prescribed in such rules for enforcing vaccination
shall be observed.
323. Obligation to give information of small-pox.
- Where an inmate of any dwelling place is suffering from small-pox, the head of the family to which
the inmate belongs, and in his default, the occupier or person-in-charge of such place, shall inform
the Municipal Health Officer with the least practicable delay.
324. Mosquito control.
- The council shall take such measures as may be necessary to prevent or eradicate the breeding of
mosquitoes in any area in the municipality.
325. Power of access to Commissioner for anti-malarial operations.
- The Commissioner or any person authorised by him in this behalf shall, for the purpose of
anti-malarial operation, have access to any area in the municipality which has been or is a breeding
place for mosquitoes.Andhra Pradesh Municipalities Act, 1965

Part 6 – Subsidiary Legislation and Penalties
Chapter 1
Rules, Bye-Laws and Regulations
326. Power of Government to make rules.
(1)The Government may by notification in A.P.Gazette make rules for carrying out all or any of the
purposes of this Act.(2)In particular and without prejudice to the generality of the foregoing power
they may make rules(a)with reference to all matters expressly required or allowed by this Act to be
prescribed;(b)[ with regard to all matters not expressly provided for in this Act, relating to electoral
rolls, conduct of elections and resolution of disputes relating to elections to any office, including
deposits to be made by candidates standing for direct elections and the conditions under which such
deposits may be forfeited;] [Substituted by Act No. 28 of 2005, dated 25.10.2005.](c)as to the
conditions on which property may be acquired by the council or on which property vested in or
belonging to the council may be transferred by sale, mortgage, lease, exchange or otherwise;(d)as to
the working of provident funds;(e)as to the matters mentioned in Rule 39 of the Taxation and
Finance Rules in Schedule II; as to the conditions on which grants-in-aid shall be paid from
municipal fund for purposes of education and medical relief and as to the conditions on which
grants and loans may be made to co-operative building societies;(f)as to the intermediate offices, if
any, through which correspondence between the municipal authorities and the Government or
officers of the Government shall pass;(g)as to the preparation of plans and estimates for works
which are to be partly or wholly constructed at the expense of the council and the power of to
municipal authorities or officers of the Government, to accord professional or administrative
sanction to estimates;(h)as to the accounts to be kept by the council, the manner in which such
accounts shall be audited and published and as to the conditions under which the rate-payers may
appear before auditors, inspect books and vouchers and take exception to items entered or omitted
therein;(i)as to the estimates of receipts and expenditure, returns, statements and reports to be
submitted by council;(j)as to the modes in which the officers of the Government shall advise and
assist council in carrying out the purposes of this Act;(k)as to the interpellation of the Chairperson
by the Members;(l)as to the moving of resolutions at the meetings of the Council;(m)for regulating
the sharing between local authorities of the proceeds of the x x x tax on carriages and carts, tax on
animals, and other taxes or income levied or obtained under this or any other Act;(n)as to the form
of registers and returns of births and deaths and the manner in which the registers shall be
maintained, the dates on which returns shall be made and the officer to whom returns shall be
sent;(o)as to the transfer of allotments entered in the sanctioned budget of a council from one head
to another;(p)as to the power of auditors, inspecting and superintending officers and officers
authorised to hold inquiries, to summon and examine witnesses, and to compel the production of
documents and all other matters connected with audit, inspection, and superintendence;(q)for
determining the cost of buildings and lands;(r)as to the fines to be imposed in respect of breach of
bye- laws made under Section 330;(s)as to the procedure to be followed in the making of a layout
and forming of street or road and the setting apart of areas for public purposes and for determining
the information and plans to be submitted with the applications for permission to make layouts andAndhra Pradesh Municipalities Act, 1965

form streets or roads and set apart areas for public purposes and for regulating the level and width
of public streets or roads and the height of buildings abutting thereon.(3)In making any rules, the
Government may provide that a breach thereof shall be punishable with a fine which may extend to
one hundred rupees.(4)Every rule made under this Act shall, immediately after it is made, be laid
before each House of the State Legislature if it is in session, and if it is not in session, in the session
immediately following for a total period of fourteen days which may be comprised in one session or
in two successive sessions, and if before the expiration of the session in which it is so laid or the
session immediately following, both Houses agree in making any modification in the rule or in the
annulment of the rule, the rule shall from the date on which the modification or annulment is
notified in the Andhra Pradesh Gazette, have effect only in such modified form or shall stand
annulled, as the case may be; so however, that any such modification or annulment shall be without
prejudice to the validity of anything previously done under that rule.
327.
[xxxxx]
328. Power to amend Schedules.
(1)The Government may, by notification, alter, add to or cancel Schedules I, II, III, IV, V, VI and
VII.(2)Where a notification has been issued under sub-section (1), there shall, unless the
notification is in the meantime rescinded, be introduced in the Legislative Assembly, as soon as may
be, but in any case during the next session of the Legislative Assembly following the date of the issue
of the notification, a Bill on behalf of the Government, to give effect to the alteration, addition or
cancellation, as the case may be, of the Schedules specified in the notification, and the notification
shall cease to have effect when such Bill becomes law, whether with or without modifications, but
without prejudice to the validity of anything previously done thereunder:Provided that if the
notification under sub-section (1) is issued when the Legislative Assembly is in session, such a Bill
shall be introduced in the Legislative Assembly during that session;Provided further that where for
any reason a Bill as aforesaid does not become law within six months from the date of its
introduction in the Legislative Assembly the notification shall cease to have effect on the expiration
of the said period of six months.(3)All references made in this Act, to any of the Schedules shall be
construed as relating to the Schedules as for the time being amended in exercise of the powers
conferred by this Section.
329.
[xxxxxx]
330. Power of council to make bye-laws.
- The council may make bye-laws, not inconsistent with this Act or with any other law, to
provide--(1)for all matters expressly required or allowed by this Act to be provided for byAndhra Pradesh Municipalities Act, 1965

bye-law;(2)for the due performance by all municipal officers and employees of the duties assigned to
them;(3)for the regulation of the time and mode of collecting the taxes and duties under this
Act;(4)for determining the conditions under which lands shall be deemed to be appurtenant to
buildings;(5)(a)for the use of public tanks, well, conduits and other places or works for
water-supply;(b)for the regulation of public bathing, washing and the like;(c)for the maintenance
and protection of the water-supply system, and the protection of the water-supply from
contamination;(d)for the conditions on which connections with the council's water-supply mains
may be made, for their alteration and repair and for their being kept in proper order;(e)for the
supply of water for consumption and use;(f)for the prevention of waste of water;(g)for the
measurement of water;(h)for the compulsory provision of cisterns and meters;(i)for the supply of
water in case of fire;(6)for the maintenance and protection of the lighting system;(7)(a)for the
maintenance and protection of the drainage system;(b)for the construction of house-drains and for
regulating their situation, mode of construction and materials;(c)for the alteration and repair of
house-drains;(d)for the cleansing of house-drains;(e)for the construction of cess-pools, septic-tanks,
filters and drains;(f)for the payment or apportionment of money payable on account of pipes or
drains common to more premises than one;(8)for the cleansing of latrines, earth-closets, ash-pits
and cess-pools and the keeping of latrines supplied with sufficient water for flushing;(9)(a)for the
testing of water pipes and drains in private premises, the recovery or the apportionment of the cost
of such testing, and the breaking up of ground or of buildings for the purposes of such testing;(b)for
the licensing of plumbers and fitters, and for the compulsory employment of licensed plumbers and
fitters;(10)for the protection of avenues, streets grass and other appurtenances of public streets and
other places;(11)for the regulation of the use of parks, gardens, and other public or municipal places
and institutions, but not including the regulation of traffic therein, the reservation thereof for
particular kinds of traffic, or the closing thereof or parts thereof to traffic;(12)(a)for the regulation of
building;(b)for determining information and plans to be submitted with applications to build;(c)for
the licensing of builders and surveyors and for the compulsory employment of licensed builders and
surveyors;(13)for the regulation of hotels, lodging houses, boarding houses, choultries, rest-houses,
emigration depots, restaurants, eating houses, cafes, refreshment rooms, coffee-houses, tea stalls
and any premises to which the public are admitted for repose or for the consumption of any food or
drink;(14)for regulating the mode of constructing stables, cattle-sheds and cow-houses and
connecting them with municipal drains;(15)for the sanitary control and supervision of places used
for any of the purposes specified in Schedule IV and of any trade or manufacture carried on
therein;(16)(a)for the control and supervision of slaughter houses and of places used for skinning
and cutting up carcasses;(b)for the control and supervision of the methods of slaughtering;(c)for the
control and supervision of butchers carrying on business in the municipality or at any
slaughter-house outside the municipality provided by the council or licensed by the municipal
health officer, as the case may be;(17)for the inspection of milch cattle, and the regulation of the
ventilation, lighting, cleaning drainage and water-supply of dairies and cattle-sheds in the
occupation of persons following the trade of dairy-man or milk seller;(18)for enforcing the
cleanliness of milk stores and milk shops and vessels and utensils used by the keepers thereof or by
hawkers for containing or measuring milk or preparing any milk product and for enforcing the
cleanliness of persons employed in the milk trade:(19)for requiring notice to be given whenever any
milch animal is affected with any contagious disease and prescribing the precautions to be taken in
order to protect milch cattle and milk against infection and contamination;(20)(a)for the inspectionAndhra Pradesh Municipalities Act, 1965

of public and private markets and shops and other places therein;(b)for the regulation of their use
and the control of their sanitary condition;(c)for licensing and controlling brokers, commission
agents, weigh men and measurers practising their calling in markets;(21)for prescribing the method
of sale of articles whether by measure, weight, tale or piece;(22)for the prevention of the sale or
exposure for sale of unwholesome meat, fish or provisions and securing the efficient inspection and
sanitary regulation of shops in which articles intended for human food are kept or sold;(23)(a)for
the regulation of burial and burning grounds and other places for the disposal of corpses;(b)for the
verification of deaths and the causes of death;(c)for the period for which corpses must be kept for
inspection;(d)for the period within which corpses must be conveyed to a burial or burning ground,
and the mode of conveyance of corpses through public places;(24)for the registration of births and
deaths;(25)for the training and licensing of nurses, dhais and midwives;(26)for the enumeration of
the inhabitants of the municipality;(27)for the prevention of infectious diseases of persons or
animals;(28)for the enforcement of compulsory vacination;(29)for the prevention of outbreaks of
fire;(30)for the prohibition and regulation of advertisements in public streets or parks;(31)in
general for securing cleanliness, safety and order and the good government and well-being of the
municipality and for carrying out all the purposes of this Act.
330A. Power of Government to make rules in lieu of bye-laws.
(1)If, in respect of any matters specified in Section 330 the council has failed to make any bye-laws
or if the bye-laws made by it are not, in the opinion of the Government, adequate, the Government
may make rules providing for such matters as they may think fit.(2)The rules made under this
section may add to alter or cancel any bye-laws made by the council.(3)If any provision of bye-laws
made by the council is repugnant to any provision of a rule made under this section, the rule shall
prevail, and the bye-laws, to the extent it is repugnant, be void.(4)The provisions of Sections 331,
sub-section (2) of Section 333 and Section 33-A shall apply to the rules made under this section as
they apply to the bye-laws made under Section 330.(5)Before making any rule under this section the
Government shall give the council an opportunity of showing cause against the proposal.
331. Power to give retrospective effect to certain bye-laws.
- Bye-laws with regard to the drainage of, and supply of water to, buildings and water-closets,
earth-closets, privies, ash-pits and cess-pools in connection with buildings and the keeping of
water-closets supplied with sufficient water for flushing may be made so as to affect buildings
erected before passing of the bye-laws or this Act.
332. Conditions precedent to making bye-laws.
- The council shall, before making or altering bye-laws, publish a draft of the proposed bye-laws and
alterations together with a notice specifying a date at or after which such draft will be taken into
consideration, and shall, before making the bye-laws or alterations, receive and consider any
objection or suggestion which may be made in respect of such draft by any person interested therein
before the date so specified.Andhra Pradesh Municipalities Act, 1965

333. Confirmation of bye-laws by Government.
(1)No bye-law or cancellation or alteration of bye-law shall have effect until the same is approved
and confirmed by the Government.(2)Any bye-law or cancellation or alteration of a bye-law when it
is duly confirmed shall be published in the prescribed manner in English and in the main language
of the district and shall come into operation three months after it is so published.
333A. Penalty for breaches of bye-laws.
- In making bye-laws the Municipal Council may, subject to the provisions of Clause (1) of Article 20
of the Constitution, provide that a breach thereof shall be punishable--(a)with fine which may
extend to fifty rupees and in case of a continuing breach with fine which may extend to fifteen
rupees for every day during which the breach continues after conviction for the first breach;
or(b)with fine which may extend to ten rupees for every day during which the breach continues after
receipt of notice from the executive authority to discontinue such breach.
334. Copies of Act, rules and bye-laws to be sold at municipal office.
- Complete copies in English and in the main language of the district--(a)of this Act,(b)of all rules
framed by the Government under clause (b) of Sub-section (2) of Section 326, and(c)of all bye-laws
in force for the time being, shall be kept at the municipal office and shall be sold to the public at cost
price.
335. Publication of regulations.
- Regulations made by the municipal authorities under this Act shall be published in such manner as
the council may determine.
Chapter 2
Penalties
336. General provisions regarding penalties specified in Schedules VI and
VII.
(1)Whoever -(a)contravenes any provision of any of the sections or rules specified in the first column
of Schedule VI, or(b)contravenes any rule or order made under any of the specified sections or rules
in the said Schedule, or(c)fails to comply with any direction lawfully given to him or any requisition
lawfully made upon him under or in pursuance of the provisions of any of the said sections or rules,
shall, on conviction, be punished with fine which may extend to the amount mentioned in that
behalf in the forth column of the said Schedule:Provided that the fine imposed shall, in no case, be
less than one-third of the said amount.(2)Whoever, after having been convicted of--(a)contravening
any provision of the sections or rules specified in the first column of Schedule VII,Andhra Pradesh Municipalities Act, 1965

or(b)contravening any rule or order made under any of the specified sections or rules in the said
Schedule, or(c)failing to comply with any direction lawfully given to him or any requisition lawfully
made upon him under or in pursuance of the provisions of any of the said sections or rules,
continues to contravene the said provision or to neglect to comply with the said direction or
requisition, as the case may be, shall, on conviction, be punished for each day after the previous date
of conviction during which he continues so to offend, with fine which may extend to the amount
mentioned in that behalf in the forth column of the said Schedule:Provided that the fine imposed
shall, in no case be less than one-third of the said amount.Explanation. - The entries in the third
column of Schedules VI and VII headed "subject" are not intended as definitions of the offences
described in the sections, sub-sections, or clauses mentioned in the first and second columns or
even as abstracts of those sections, sub-sections, or clauses, but are inserted merely as references to
the subject of the sections, sub-sections or clauses, as the case may be.
337. Penalty for acting as Member, Chairperson, or Vice-Chairperson when
disqualified.
(1)Whoever acts as a Member knowing that under this Act or the rules made thereunder he is not
entitled, or has ceased to be entitled, to hold such office shall, on conviction, be punished with fine
not exceeding two hundred rupees for every such offence.(2)Whoever acts as or exercises the
functions of the Chairperson or Vice-Chairperson of a council knowing that under this Act or the
rules made thereunder he is not entitled, or has ceased to be entitled, to hold such office or to
exercise such functions shall, on conviction, be punished with fine not exceeding one thousand
rupees for every such offence.(3)If the Chairperson or Vice-Chairperson of a council fails to hand
over any documents of, or any moneys or other properties vested in, or belonging to, the council
which are in or have come into his possession or control, to his successor in office or other
prescribed authority, in every case as soon as his term of office as Chairperson or Vice-Chairperson
expires and in the case of the Vice-Chairperson also on demand by the Chairperson, such
Chairperson or Vice-Chairperson shall, on conviction, be punished with fine not exceeding one
thousand rupees for every such offence.
338. Penalty for acquisition by any municipal officer of interest in contract or
work.
- If any municipal officer or employee knowingly acquires, directly or indirectly, by himself or by a
co-sharer or servant, or near relative or any benamidar, any share or interest in any contract or
employment with, by or on behalf of, the council, he shall be deemed to have committed an offence
under Section 168 of the Indian Penal Code:Provided that no person shall, by reason of being a
share-holder in, or member of, any company, be held to be interested in any contract entered into
between such company and the council unless he is a director of such company:Provided further
that nothing in this section shall apply to a teacher employed by a council who, with the sanction of
the Government, enters into a contract with the council with regard to the utilization for the purpose
of a school of any land or building owned by him or in which he has a share or interest.Andhra Pradesh Municipalities Act, 1965

339. Penalty for omission to take out licence for carriage or animal.
(1)Every owner or person in charge of any carriage or animal liable to tax who omits to obtain a
licence shall, on conviction, be punished with fine not exceeding fifty rupees and shall also pay the
amount of the tax payable by him in respect of such carriage or animal.(2)On payment of such fine
and tax and of such costs as may be awarded, such owner or person shall receive a licence for the
carriage or animal in respect of which he has been fined and for the period during which he has
found to be in default.(3)The provisions of this section shall apply to any person who having
compounded for the payment of a certain sum under Section 108, fails to pay such sum, and the
amount due for a licence shall, in such case, be taken as the amount so compounded for.
339A. Penalty for wilful prevention of distraint.
- Any person wilfully preventing distraint or sufficient distraint of property subject to distraint for
any tax due from any person, shall on conviction be liable to a fine not exceeding twice the amount
of the tax found to be due.
340. Penalty for unlawful building.
- If the construction or reconstruction of any building or well--(a)is commenced without the
permission of the Commissioner, or(b)is carried on or completed otherwise than in accordance with
the particulars on which such permission was based, or(c)is carried on or completed in
contravention of any lawful order or in breach of any provision contained in this Act or in any rule
or bye-law made thereunder or of any direction or requisition lawfully given or made, orif any
alterations or additions required by any notice issued under Section 217 or Section 228 are not duly
made, or if any person to whom a direction is given under Section 228 to alter or demolish a
building or well fails to obey such direction, the owner of the building or well or the said person, as
the case may be, shall be liable on conviction to a fine which may extend in the case of a building to
five hundred rupees subject to a minimum of fifty rupees and in the case of a well or hut to fifty
rupees, subject to a minimum of ten rupees and to a further fine which may extend in the case of a
building to one hundred rupees subject to a minimum of ten rupees and in the case of a well or hut
to ten rupees subject to a minimum of two rupees, for each day during which the offence is proved to
have continued after the first day.
341. Notice to conservancy worker before discharge, etc.
(1)Every conservancy worker employed by the council shall be entitled to one month's notice before
discharge or to one month's wages in lieu thereof, unless he is discharged for misconduct or was
engaged for a specified term and discharged at the end of it.(2)Where any conservancy worker
employed by the council, without reasonable cause, resigns his employment or absents himself from
his duties without giving one month's notice to the council, or neglects or refuses to perform his
duties, or any of them, he shall be liable on conviction to a fine not exceeding fifty rupees.(3)The
Government may, by notification in the Andhra Pradesh Gazette, direct that, on and from a date toAndhra Pradesh Municipalities Act, 1965

be specified in the notification, the provisions of Sub-sections (1) and (2) with respect to
conservancy workers shall apply also to any specified class of municipal employees whose functions
intimately concern the public health or safety.
342. Wrongful restraint of municipal authority or officer and his delegate.
- Every person, who prevents the municipal authority or officer or any person to whom the said
authority or officer has lawfully delegated its or his powers of entering into or on any land or
building, from exercising its or his lawful power of entering thereinto or thereon shall be deemed to
have committed an offence under Section 341 of the Indian Penal Code.
343. Penalty for not giving information or giving false information.
- If any person, who is required, by the provisions of this Act or by any notice or other proceedings
issued under this Act to furnish any information,--(a)omits to furnish it, or(b)knowingly furnishes
false information, such person shall be liable to a fine not exceeding on hundred rupees.[Chapter
III] [Inserted by Act No. 28 of 2005, dated 25.10.2005.] Corrupt Practices and Election
OffencesCorrupt Practices
343A. Corrupt Practices.
- The following shall be deemed to be corrupt practices for the purposes of this Act-(1) Bribery, that
is to say,-(A)Any gift, offer or promise by a candidate or his agent or by any other person with the
consent of a candidate or his election agent of any gratification, to any person whomsoever, with the
object directly or indirectly of inducing,-(a)a person to stand or not to stand as or to withdraw or not
to withdraw from being a candidate at an election, or(b)an elector to vote or refrain from voting at
an election, or as a reward to-(i)a person for having so stand or notstood, or for having withdrawn or
not having withdrawn his candidature; or(ii)an elector for having voted or refrained from
voting;(B)The receipt of, or agreement to receive, any gratification, whether as a motive or a
reward,-(a)by a person for standing or not standing as or for withdrawing or not withdrawing from
being a candidate, or(b)by any person whomsoever for himself or any other person for voting or
refraining from voting or inducing or attempting to induce any electoi vote or refrain from voting, or
any candidate to withdraw or not to withdraw his candidature.Explanation. - For the purposes of
this clause the term 'gratification' is not restricted to pecuniary gratification or gratifications
estimable in money and it includes all forms of entertainment and all forms of employment for
reward but it does not include the payment of any expenses bona fide incurred at, or for the purpose
of any election and duly entered in the account of election expenses.(2)Undue influence, that is to
say, any direct or indirect interference or attempt to interfere on the part of the candidate or his
agent or of any other person with the consent of the candidate or his election agent with the free
exercise of any elector right:Provided that-(a)without prejudice to the generality of the provisions of
this clause any such person as is referred to therein, who-(i)threatens any candidate or any elector
or any persdn in whom a candidate, or an, elector is interested, with injury of any kind including
social ostracism and excommunication or expulsion from any caste or community: or(ii)induces or
attempts to induce a candidate or an elector to believe that he, or any person in whom he isAndhra Pradesh Municipalities Act, 1965

interested will become or will be rendered an object of divine displeasure or spiritual censure, shall
be deemed to interfere with the free exercise of the electoral right of such candidate or elector within
the meaning of this clause:(b)a declaration of public policy, or a promise of public action, or the
mere exercise of a legal right without intent to interfere with an electoral right, shall not be deemed
to be interference within the meaning of this clause.(3)The appeal by a candidate or his agent or by
any other person with the consent of a candidate or his election agent to vote or refrain from voting
for any person on the ground of his religion, race, caste, community or language or the use of, or
appeal to religious symbols, or the use of, or appeal to national symbols such as the national flag or
the national emblem, for the furtherance of the prospects of the election of that candidate or for
prejudicially affecting the election of any candidate:Provided that no symbol allotted under this Act
to a candidate shall be deemed to be a religious symbol or a national symbol for the purposes of this
clause.(4)The promotion of, or attempt to promote feelings of enmity or hatred between different
classes of the citizens of India on grounds of religion, race, caste, community, or language by a
candidate, or his agent or any other person with the consent of a candidate or his election agent for
the furtherance of the prospects of the election of that candidate or of prejudicially affecting the
election of any candidate.(5)The propagation of the practice or the commission of sati or its
glorification by a candidate or his agent nor any other person with the consent of the candidate or
his election agent for the furtherance of the prospects of the election of that candidate or for
prejudicially affecting the election of any candidate.Explanation. - For the purpose of this clause,
"sati" and "glorification" in relation of sati shall have the meanings respectively assigned to them in
the Commission of Sati (Prevention) Act, 1987.(6)The publication by a candidate or his agent or by
any other person, with the consent of a candidate or his election agent of any statement of fact which
is false, and which he either believes to be false, or does not believe to be true in relation to the
personal character or conduct of any candidate or in relation to the candidature, or withdrawal of
any candidate, being a statement reasonably calculated to prejudice the prospects of that candidate's
election.(7)The hiring or procuring whether, on payment or otherwise of any vehicle or vessel by a
candidate or his agent nor by any other person with the consent of a candidate or his election agent,
or the use of such vehicle or vessel for the free conveyance of any elector other than that the
candidate himself, the members of his family or his agent to or from any polling station:Provided
that the hiring of a vehicle or vessel by an elector or by several electors at their joint costs for the
purpose of conveying him or them to and from any such polling station or place fixed for the poll
shall not be deemed to be a corrupt practice under this clause if the vehicle or vessel so hired is a
vehicle or vessel not propelled by mechanical power:Provided further that the use of any public
transport vehicle or vessel by any elector at his own cost for the purpose of going to or coming from
any such polling station or place fixed for the poll shall not be deemed to be a corrupt practice under
this clause. Explanation: In this clause the expression "vehicle" means any vehicle used or capable of
being used for the purpose of road transport, whether propelled by mechanical power or otherwise
and whether used for drawing other vehicles or otherwise.(8)The incurring or authorizing of
expenses in contravention of Section 343-ZC.(9)The obtaining or procuring or abetting or
attempting to obtain or procure by a candidate or his agent, or by any other person with the consent
of a candidate or his election agent, any assistance (other than the giving or vote) for the furtherance
of the prospects of that candidate's election, from any person in the service of the State or Central
Government, Local Authority or a Corporation owned or controlled by the State or Central
Government:Provided that where any person, in the service of the State or Central Government or aAndhra Pradesh Municipalities Act, 1965

Local Authority or a Corporation owned or controlled by the State or Central Government in the
discharge or purported discharge of his official duty, makes any arrangements or provides any
facilities or does any other act or things, for, to, or in relation to, any candidate or his agent or any
other person acting with the consent of the candidate or his election agent (whether by reason of the
office held by the candidate or for any other reason), such arrangements, facilities or act or thing
shall not be deemed to be assistance for the furtherance of the prospects of that candidate's
election.(10)Booth capturing by candidate or his agent or other person.Explanation. - (1) In this
section the expression 'agent' includes and election agent, a polling agent, and any person who is
held to have acted as an agent in connection with the election with the consent of the
candidate.(2)For the purposes of clause (9), a person shall be deemed to assist in the furtherance of
the prospects of a candidate's election if he acts as an election agent of that candidate.(3)For the
purposes of clause (9), notwithstanding anything contained in any other law, the publication in the
Andhra Pradesh Gazette of the appointment, resignation, termination of service, dismissal or
removal from service of a person in the service of the Government shall be conclusive proof-(i)of
such appointment, resignation, termination of service, dismissal or removal from service, as the case
may be; and(ii)where the date of taking effect of such appointment, resignation, termination of
service, dismissal or removal from service, as the case may be, is stated in such publication, also of
the fact that such person was appointed with effect from the said date, or in the case of resignation,
termination of service, dismissal or removal from service, such person ceased to be in such service
with effect from the said date.Electoral Offences
343B. Promoting enmity between classes in connection with election.
- Any person who, in connection with an election under this Act promotes or attempts to promote on
grounds of religion, race, caste, community or language, feelings or enmity or hatred, between
different classes of the citizens of India shall be punishable with imprisonment for a term which may
extend to three years and with fine which may extend to three thousand rupees.
343C. Prohibition of public meetings during period of forty-eight hours
ending with hour fixed for conclusion of poll.
(1)No person shall-(a)convene, hold, attend, join or address any pubic meeting or procession in
connection with an election; or(b)display to the public any election matter by mean of
cinematography, television or other similar apparatus; or(c)propagate any election matter to the
public by holding, or by arranging the holding of, any musical concert or any theatrical performance
or any other entertainment or amusement with a view to attracting the members of the public
thereto, in any polling area during the period of forty-eight hours ending with the hour fixed for the
conclusion of the poll for any election in that polling area.(2)any person who contravenes the
provision of sub-section (1) shall be punishable with imprisonment for a term which may extend to
two years, or with fine or with both.(3)In this section, the expression "election matter" means any
matter intended or calculated to influence or affect the result of election.Andhra Pradesh Municipalities Act, 1965

343D. Disturbance at election meetings.
(1)Any person who at a public meeting to which this section applies acts or incites others to act in a
disorderly manner for the purpose of preventing the transaction of the business for which the
meeting was called together, shall be punishable with imprisonment for a term which may extend to
six months or with fine which may extend to two thousand rupees or with both.(2)An offence
punishable under subsection (1) shall be cognisable.(3)This section applies to any public meeting of
a political character held in any Municipality/Nagar Panchayat between the date of the issue of
notification under this Act calling upon the voters to elect a ward member or members or
Chairperson and the date on which such election is held.(4)If any police officer reasonably suspects
any person of committing an offence under sub-section (1) he may, if requested to do by the
Chairman of the meeting require that person to declare to him immediately his name and address
and, if that person refuses or fails so to declare his name and address or if the police officer
reasonably suspects him of giving a false name or address, the police officer may arrest him without
warrant.
343E. Restrictions on the printing of pamphlets, posters etc.
(1)No person shall print or publish or cause to be printed or published, any election pamphlet or
poster which does not bear on its face the names and addresses of the printer and the publisher
thereof.(2)No person shall print or cause to be printed any election pamphlet or poster:-(a)unless a
declaration as to the identity of the publisher thereof, signed by him and attested by two persons to
whom he is personally known, is delivered by him to the printer in duplicate; and(b)unless, within a
reasonable time after the printing of the document, one copy of the declaration is sent by the
printer, together with one copy of the document-(i)where it is printed in the capital of the State, to
the Election Authority, and(ii)in any other case, to the District Magistrate of the District in which it
is printed.(3)For the purpose of this section,-(a)any process for multiplying copies of a document
other than copying it by hand, shall be deemed to be printing and the expression 'printer' shall be
construed accordingly; and(b)"election pamphlet or poster" means any printed pamphlet, handbill
or other document distributed for the purpose ofpromoting or prejudicing the election of a
candidate or group of candidates or any placard or poster having reference to an election, but does
not include any handbill, placard or poster merely announcing the date, time, place and other
particulars of an election meeting or routine instructions to election agents or workers.(4)Any
person who contravenes any of the provisions of sub-section (1) or sub-section (2) shall be
punishable with imprisonment for a term which may extend to six months, or with fine which may
extend to two thousand rupees or with both.
343F. Maintenance of secrecy of voting.
(1)Every officer, clerk, agent or other person who performs any duty in connection with the
recording or counting of votes at an election shall maintain, and aid in maintaining, the secrecy of
the voting and shall not (except for some purpose authorised by or under any law) communicate to
any person any information calculated to violate such secrecy.(2)Any person who contravenes
provisions of sub-section (1) shall be punishable with imprisonment for a term, which may extend toAndhra Pradesh Municipalities Act, 1965

three months or with fine or with both.
343G. Officers etc. at elections not to act for candidates or to influence
voting.
(1)No person who is a District Election Authority or an Election Officer or an Assistant Election
Officer, or a Presiding Officer or Polling Officer at an election, or an officer or clerk, appointed by
the Returning Officer or the Presiding Officer to perform any duty in connection with an election
shall in the conduct or the management of the election do any act (other than the giving of vote) for
the furtherance of the prospects of the election of a candidate.(2)No such person as aforesaid, and
no member of a police force, shall endeavour,-(a)to persuade any person to give his vote at an
election, or(b)to dissuade any person from giving his vote at an election, or(c)to influence the voting
of any person at an election in any manner.(3)Any person who contravenes the provisions of
sub-section (1) or subsection (2) shall be punishable with imprisonment, which may extend to six
months, or with fine or with both.
343H. Prohibition of canvassing in or near polling stations.
(1)No person shall, on the date or dates on which a poll is taken at any polling station, commit any of
the following acts within the polling station or in any public or private place within a distance of one
hundred meters of the polling station, namely,-(a)canvassing for votes; or(b)soliciting the vote of
any elector; or(c)persuading any elector not to vote for any particular candidate; or(d)persuading
any elector not to vote at the election; or(e)exhibiting any notice or signs (other than an official
notice) relating to the election.(2)Any person who contravenes the provisions of sub-section (1) shall
be punished with fine which may extend to two hundred and fifty rupees.
343I. Penalty for disorderly conduct in or near polling stations.
(1)No person shall, on the date or dates on which a poll is taken at any polling station,-(a)use or
operate within or at the entrance of the polling station, or in any public or private place in the
neighbourhood thereof, any apparatus for amplifying or reproducing the human voice, such as a
megaphone or a loudspeaker, or(b)shout, or otherwise act in a disorderly manner within or at the
entrance of the polling station or in any public or private place in the neighbourhood thereof, so as
to cause annoyance to any person visiting the polling station for the poll, or so as to interfere with
the work of the officers and other persons on duty at the polling station.(2)Any person who
contravenes, or willfully aids or abets the contravention of the provisions of sub-section (1) shall be
punishable with imprisonment which may extend to three months or with fine or with both.(3)If the
presiding officer of a polling station has reason to believe that any person is committing or has
committed an offence punishable under this section, he may direct any police officer to arrest such
person, and thereupon the police officer shall arrest him.(4)Any police officer may take such steps,
and use such force as may be reasonably necessary for preventing any contravention of the
provisions of sub-section (1), and may seize any apparatus used for such contravention.Andhra Pradesh Municipalities Act, 1965

343J. Penalty for misconduct at the polling station.
(1)Any person who during the hours fixed for the poll at any polling station misconducts himself or
fails to obey the lawful directions of the presiding officer may be removed from the polling station by
the presiding officer or by any police officer on duty or by any person authorised in this behalf by
such presiding officer.(2)The powers conferred by sub-section (1) shall not be exercised so as to
prevent any elector who is otherwise entitled to vote at a polling station from having opportunity of.
voting at that station.(3)If any person who has been so removed from polling station re-enters the
polling station, without the permission of the presiding officer, he shall be punishable with
imprisonment for a term which may extend to three months, or with fine, or with both.
343K. Penalty for failure to observe procedure for voting.
- If an elector to whom a ballot paper has been issued, refuses to observe the procedure prescribed
for voting, the ballot paper issued to him shall be liable for cancellation.
343L. Penalty for illegal hiring or procuring of conveyance at elections.
- If any person is guilty of any such corrupt practice as is specified in clause (7) of Section 343-A at
or in connection with an election, he shall be punishable with imprisonment which may extend to
three months and with fine.
343M. Breaches of official duty in connection with elections.
(1)If any person to whom, this section applies is without reasonable cause guilty of any act or
omission in breach of his official duty, he shall be punishable with fine, which may extend to five
hundred rupees.(2)An offence punishable under subsection (1) shall be congnisable.(3)No suit or
other legal proceedings shall lie against any such person for damages in respect of any such act or
omission as aforesaid.(4)The persons to whom this section " applies are the District Election
Officers, Election Officers, Assistant Election Officers, Polling Officers, and any other person
appointed to perform any duty in connection with the receipt of nominations or withdrawal of
candidatures, or the recording or counting of votes at an election and the expression "official duty"
shall for the purposes of this section be construed accordingly but shall not include duties imposed
otherwise than by or under this Act.
343N. Penalty for Government Servants etc. for acting as election agent,
polling agent or counting agent.
- If any person in the service of the State or Central Government or a Local Authority or a
Corporation owned or controlled by the State or Central Government acts as an election agent of a
candidate at an election he shall be punishable with imprisonment for a term which may extend to
three months, or with fine or with both.Andhra Pradesh Municipalities Act, 1965

343O. Prohibition of going armed to or near a polling station.
(1)No person other than the Returning Officer, any Police Officer and any other person appointed to
maintain peace and order, at a polling station who is on duty at the polling station, shall, on a
polling day, go armed with arms, as defined in the Arms Act, 1959, of any kind within the
neighbourhood of a polling station.(2)If any person contravenes the provisions of sub-section (1), he
shall be punishable with imprisonment for a term which may extend to two years, or with fine, or
with both.(3)An offence punishable under subsection (2) shall be cognizable.
343P. Removed of ballot papers or ballot boxes from polling stations to be an
offence.
(1)any person who, at any election, unauthorisedly takes or attempts to take a ballot paper or ballot
box out of polling station, or willfully aids or abets the doing of any such act shall be punishable with
imprisonment for a term which may extend to five years and with fine which may extend upto five
thousand rupees.(2)If the presiding officer of a polling station has reason to believe that any person
is committing or has committed an offence, punishable under subsection (1), such officer may,
before such person leaves the polling station, arrest or direct a police officer to arrest such person
and such person may cause him to be searched by a police officer:Provided that when it is necessary
to cause a woman to be searched the search shall be made by another woman with strict regard to
decency.(3)Any ballot paper found upon the person arrested on search shall be made over for safe
custody to a police officer by the presiding officer or when the search is made by a police officer,
shall be kept by such officer in safe custody.(4)An offence punishable under subsection (1) shall be
cognizable.
343Q. Offence of booth capturing.
(1)Whoever commits an offence of booth capturing shall be punishable with imprisonment for a
term which shall not be less than one year but which may extend to three years and with fine, and
where such offence is committed by a person in the service of the Government, he shall be
punishable with imprisonment for a term which shall not be less than three years but which may
extend to five years and with fine. Explanation: For the purposes of this sub-section and Section
343-ZE "booth capturing" includes, among other things, all or any of the following activities,
namely-(a)seizure of a polling station or a place fixed for the poll by any person or persons making
polling authorities surrender the ballot papers or voting machines and doing of any other act which
affects the orderly conduct of elections;(b)taking possession of polling station or a place fixed for the
poll by any person or persons and allowing only his or their own supporters to exercise their right to
vote and prevent others from free exercise of their right to vote;(c)coercing or intimidating or
threatening directly or indirectly threatening any elector and preventing him from going to the
polling station or a place fixed for the poll to cast his vote;(d)seizure of a place for counting of votes
by any person or persons, making the counting authorities surrender the ballot papers or voting
machines and the doing of anything which affects the orderly counting of votes;(e)doing by any
person in the service of Government, of all or any of the aforesaid activities or aiding or connivingAndhra Pradesh Municipalities Act, 1965

at, any such activity in the furtherance of the prospects of the election of a candidate.(2)An offence
punishable under subsection (1) shall be cognizanble.
343R. Liquor not to be sold, given or distributed on polling day.
(1)No spirituous, fermented or intoxicating liquors or other substances of a like nature shall be sold,
given or distributed at a hotel, eating house, tavern, shop or any other place, public or private,
within a polling area during the period of forth-eight hours ending with the hour fixed for the
conclusion of the poll for any election in that polling area.(2)Any person who contravenes the
provisions of sub-section (1), shall be punishable with imprisonment for a term which may extend to
six months, or with fine which may extend to two thousand rupees, or with both.(3)Where a person
is convicted of an offence under this section, the spirituous, fermented or intoxicating liquors or
other substances of a likenature found in his possession shall be liable to confiscation and the same
shall be disposed of in such manner as may be prescribed.
343S. Other offences and penalties thereunder.
(1)A person shall be guilty of an electoral offence if at any election he,-(a)fraudulently defaces or
fraudulently destroys any nomination paper; or(b)fraudulently defaces or destroys or removes any
list, notice or other documents affixed by or under the authority of a election officer;
or(c)fraudulently defaces or fraudulently destroys any ballot paper or the official mark or any ballot
paper or any declaration of identity or official envelope used in connection with voting by postal
ballot; or(d)without due authority supplies any ballot paper to any person or receives any ballot
paper from any person or is in possession of any ballot paper; or(e)fraudulently puts into any ballot
box anything other than the ballot paper which he is authorised by law to put in; or(f)without due
authority destroys, takes, opens or otherwt ; interferes with any ballot box or ballot papers then in
use for the purposes of the election; or(g)fraudulently or without due authority, as the case may be,
attempts to do any of the foregoing acts or willfully aids or abets the doing of any such acts.(2)Any
person guilty of an electoral offence under this section shall,-(a) if he is an election officer or an
assistant election officer or a presiding officer at a polling station or any other officer or clerk
employed on official duty in connection with the election, be punishable with imprisonment for a
term which may extend to two years or with fine or with both;(b)if he is any other person, be
punishable with imprisonment for a term which may extend to six months or with fine or with
both.(3)For the purposes of this section a person shall be deemed to be on official duty if his duty is
to take part in the conduct of an election or part of an election including the counting of votes or to
be responsible after an election for the used ballot papers and other documents in connection with
such election, but the expression "official duty" shall not include any duty imposed otherwise than
by or under this Act.
343T. Penalty for offences not otherwise providedfor.
- Whoever does any act in contravention of any of the provisions of this Act, or of any rule,
notification or order made, issued or passed, thereunder and not otherwise provided for in this Act
shall, on conviction be punished with imprisonment which may extend to two years or with fineAndhra Pradesh Municipalities Act, 1965

which may extend to two thousand rupees or with both.[Chapter IV] [Inserted by Act No. 28 of
2005, dated 25.10.2005.] Miscellaneous Election Matters
343U. Adjournment of poll in emergencies.
(1)If at an election the proceedings at any polling station are interrupted or obstructed by any riot or
open violence, or if at an election it is not possible to take the poll at any polling station or such place
on account of any natural calamity, or any other sufficient cause, the presiding officer for such
polling station shall announce an adjournment of the poll to a date to be notified later, and he shall
forthwith inform the election officer concerned.(2)Whenever a poll is adjourned under sub - section
(1), the election officer shall immediately report the circumstances to the District Election Authority
and the State Election Commission, and shall, as soon as may be, with the previous approval of the
State Election Commission, appoint the day on which the poll shall recommence, and fix the hours
during which, the poll will be taken, and shall not count the votes cast at such election until such
adjourned poll shall have been completed.(3)In every such case as aforesaid, the election officer
shall notify in such manner as the State Election Commission may direct, the date and hours of
polling fixed under subsection (2).
343V. Fresh poll in the case of destruction, etc., of ballot boxes.
(1)If at any election,-(a)any ballot box used at a polling station is unlawfully taken out of the custody
of the presiding officer or the election officer, or is accidentally or intentionally destroyed or lost, or
is damaged or tampered with, to such an extent, that the result of the poll at that polling station
cannot be ascertained; or(b)any voting machine develops a mechanical failure during the course of
the recording of votes; or(c)any such error or irregularity in procedure as is likely to vitiate the poll
is committed at a polling station, the election officer shall forthwith report the matter to the State
Election Commission.(2)Thereupon, the State Commission shall, after taking all material
circumstances into account; either-(a)declare the poll at that polling station to be void, appoint a
day, and fix the hours, for taking a fresh poll at that polling station and notify the day so appointed
and the hours so diced n such manner as it may deem fit, or(b)if satisfied that the result of a fresh
poll at that polling station will not, in any way, affect the result of the election or that the mechanical
failure of the voting machine or the error or irregularity in procedure is not material, issue such
directions to the election officer as it may deem proper for the further conduct and completion of the
election.(3)The provisions of this Act and of any rules or orders made thereunder shall apply to
every such fresh poll as they apply to the original poll.
343W. Adjournment of poll or countermanding of election on the ground of
booth capturing.
(1)If at any election,-(a)Booth capturing has taken place at a polling station or in such number of
polling stations as is likely to affect the result of such election or that the result of the poll at that
polling station cannot be ascertained; or(b)booth capturing takes place in any place for counting of
votes in such a manner that the result of the counting at that place cannot be ascertained, theAndhra Pradesh Municipalities Act, 1965

Election Officer shall forthwith report the matter to the State Election Commission.(2)The State
Election Commission shall, on the receipt of a report from the Election Officer under sub-section (1),
and after taking all material circumstances into account, either,-(a)declare that the poll at that
polling station be void, appoint a day, and fix the hours, for taking fresh poll at that polling station
and notify the date so appointed and hours so fixed in such manner as it may deem fit, or(b)if
satisfied that in view of the large number of polling stations involved in both capturing the result of
the election is likely to be affected or that booth capturing had affected counting of votes in such
manner as to affect result of the election, countermand the election in that
constituency.Explanation. - In this section, "booth capturing" shall have the same meaning as in
Section 343-Q.
343X. Destruction, loss, etc., of ballot papers at the time of counting.
(1)If any time before the counting of votes is completed any ballot papers used at a polling station
are unlawfully taken out of the custody of the election officer or are accidentally or intentionally
destroyed or lost or are damaged or tampered with, to such an extent that the result of the poll at
that polling station cannot be ascertained, the election officer shall forthwith report the matter to
the State Election Commission.(2)Thereupon, the State Election Commission shall, after taking all
material circumstances into account, either-(a)direct that the counting of votes shall be stopped,
declare the poll at that polling station to be void, appoint a day, and fix the hours, for taking a fresh
poll at that polling station and notify the date so appointed and hours so fixed in such manner as it
may deem fit, or(b)if satisfied that the result of a fresh poll at that polling station will not, in any
way, affect the result of the election, issue such directions to the election officer as it may deem
proper for the resumption and completion of the counting and for the further conduct and
completion of the election in relation to which the votes have been counted.(3)The provisions of this
Act and of any rules or orders made thereunder shall apply to every such fresh poll as they apply to
the original poll.
343Y. Electoral officers and staff etc. deemed to be on deputation.
(1)Any officer or staff employed in connection with the preparation, revision and correction of the
electoral rolls for, and the conduct of all elections shall be deemed to be on deputation to the State
Election Commission for the period during which they are so employed and such officers and staff
shall during that period, be subject to the control, superintendence and discipline of the State
Election Commission.(2)The District Election Authority, Election Officer, Assistant Election Officer,
Presiding Officer, Polling Officer and any other officer appointed under this Act, and any police
officer designated for the time being by the State Government for the conduct of any elections shall
be deemed to be on deputation to the State Election Commission for the period commencing on and
from the date of notification calling for such elections and ending with the date of declaration of the
results of such elections and such officer shall, during that period, be subject to the control,
superintendence and discipline of the State Election Commission.Andhra Pradesh Municipalities Act, 1965

343Z. Delegation of the powers of the Commission.
- The State Election Commissioner may, subject to such conditions and restrictions as he may
specify, by general or special order, delegate to any officer or authority in the State Government,
either generally or as respects any particular matter or class of matters any powers of the
Commission under this Act.
343ZA. Election petitions.
- No election held under this Act shall be called in question except by an election petition presented
in accordance with such rules as may be made in this behalf and to such authority as may be
specified in such rules.[Chapter V] [Inserted by Act No. 28 of 2005, dated 25.10.2005.] Election
Expenses
343ZB. Applications of chapter.
- This chapter shall apply to candidates of any election held under this Act.
343ZC. Account of election expenses.
(1)Every candidate, at any election held under this Act shall, either by himself , or by his election
agent, keep a separate and correct account of all expenditure incurred in connection with the
election, between the date on which the candidate concerned has been nominated, and the date of
declaration of the result of the election, both date inclusive (hereinafter in this chapter referred as
'Election Expenses').Explanation I. - 'Election expenses' for purpose of this Act shall mean all
expenses in connection with the election,-(a)incurred, or authorized by the contesting candidate, or
by his election agent;(b)incurred by any association, or body of persons, or by any individual (other
than the candidate or his election agent), aimed at promoting or procuring the election of the
candidate concerned; and(c)incurred by any political party, by which the candidate is set up, so as to
promote or procure his election;Provided that any expenses incurred by any political party as part of
its general propaganda, (which is distinguishable from its election campaign, for the promotion or
procuring the election of a particular candidate), by words, either written or spoken, or by signs or
visible representations, or by audiovisual devises, or through print or electronic media or otherwise,
shall not constitute 'election expenses' for purposes of this Act.Explanation II. - (1) For the removal
of doubts, it is hereby declared that any expenses incurred in respect of any arrangements made,
facilities provided or any other act or thing done by any person in the service of the Government and
belonging to any of the classes mentioned in clause (9) of Section 343-A in the discharge or
purported discharge of his official duty as mentioned in the proviso to that clause shall not be
deemed to be expenses in connection with the election incurred or authorized by a candidate or by
his election agent for the purposes of this sub-section.(2)The account of election expenses shall
contain such particulars, as may by order, be specified by the State Election Commission.(3)The
total of the said expenses shall not exceed such amount, as may by order, be specified by the State
Election Commission.Andhra Pradesh Municipalities Act, 1965

343ZD. Lodging of account with the District Election Authority.
- Every contesting candidate at an election shall, within forty five days from the date of declaration
of the result of the election, lodge with the District Election Authority, an account of his election
expenses, which shall be a true copy of the account kept by him, or by his election agent, under
Section 343-ZC";[Chapter VI] [Inserted by Act No. 28 of 2005, dated 25.10.2005.] Appointment of
Observers
343ZE. Appointment of Observers.
(1)The State Election Commission may nominate an Observer who shall be an officer of Government
to watch the conduct of election or elections in a ward or a group of wards or for a Municipality or a
group of Municipalities and to perform such other functions as may be entrusted to him by the
Commission in relation thereto.(2)The Observer nominated under subsection (1) shall have the
power to direct the Election Officer for the or for any of the wards for which he has been nominated,
to stop the counting of votes at any time before the declaration of the result, or not to declare the
result, if in the opinion of the Observer, booth capturing has taken place at a large number of polling
stations or at counting centers or any ballot papers used at a polling station are unlawfully taken out
of the custody of the Election Officer or are accidentally or intentionally destroyed or lost or are
damaged or tampered with, to such an extent that the result of the poll at that polling station cannot
be ascertained.(3)Where an Observer has directed the Election Officer under this section to stop
counting of votes or not to declare the result, the Observer shall forthwith report the matter to the
Commission and thereupon the Commission shall, after taking all material circumstances into
account, issue appropriate directions under Section 343-W or Section 343-X in the matter of
declaration of results.(4)It shall be competent for the State Election Commission to appoint an
Election Expenditure Observer for a group of wards or for a Municipality or group of Municipalities
so as to ensure that the provisions of Chapter V are strictly adhered to and in that behalf the
commission may issue such instructions as it deems fit, from time to time, to such Observers.
Part 7 – Procedure and Miscellaneous
344. General provisions regarding licences and permissions.
(1)Every licence and permission granted under this Act or any rule or bye-law made under this Act
shall specify the period if any for which, and the restrictions, limitations and conditions subject to
which, the same is granted, and shall be signed by the Commissioner.(2)Save as otherwise expressly
provided in or prescribed under this Act, for every such licence or permission, fees be charged on
such units and at such rates as may be fixed by the council.(3)The council may--(a)place the
collection of such fees under the management of such persons as may appear to it proper;(b)farm
out such collection for any period not exceeding three years at a time and on such terms and
conditions as it may think fit.(4)Every order of a municipal authority granting or refusing a licence
or permission shall be communicated to the person concerned.(5)Every order of a municipal
authority refusing, suspending, cancelling or modifying, a licence or permission shall be in writingAndhra Pradesh Municipalities Act, 1965

and shall state the grounds on which it proceeds.(6)Subject to the special provisions in Chapters IV
and VI of Part V regarding buildings and private markets and subject to such sanction as may by
required for the refusal of a licence or permission, any licence or permission, granted under this Act
or any rule or bye-law made under it, may at any time be suspended or revoked by the
Commissioner in consultation with the person or authority granting the licence or permission if any
of its restrictions, limitations or conditions is evaded or infringed by the grantee, or if the grantee is
convicted of a breach of any of the provisions of this Act, or of any rule, bye-law or regulation made
under it in any matter to which such licence or permission relates, or if the grantee has obtained the
same by misrepresentation or fraud;Provided that the grantee shall be given an opportunity to show
cause against such suspension or revocation.(7)It shall be the duty of the Commissioner to inspect
places in respect of which a licence or permission is required by or under this Act, and he may enter
any such place between sunrise and sunset and also between sunset and sunrise, if it is open to the
public or any industry is being carried on in it at the time; and if he has reason to believe that
anything is being done in any place without a licence or permission where the same is required by or
under this Act or otherwise than in conformity with the same, he may at any time by day or night,
without notice, enter such place for the purpose of satisfying himself whether any provision of law,
rules, byelaws or regulations, any condition of a licence or permission or any lawful direction or
prohibition is being contravened and no claim shall lie against any person for any damage or
inconvenience necessarily caused by the exercise of powers under this sub-section by the
Commissioner or any person to whom he has lawfully delegated his powers, or by any force
necessary for effecting any entrance under this sub-section.(8)when any licence or permission is
suspended or revoked or when the period for which it was granted or within which application for
renewal should be made, has expired, whichever expires later, the grantee shall, for all purposes of
this Act or any rule or bye-law made under this Act, be deemed to be without a licence or permission
until the order suspending or revoking the licence or permission is cancelled or, subject to
subsection (13), until the licence or permission is renewed as the case may be.(9)Every grantee of
any licence or permission shall, at all reasonable times, while such licence or permission remains in
force, produce the same at the request of the Commissioner or any person authorised by him in this
behalf.(10)Whenever any person is convicted of an offence in respect of the failure to obtain a
licence or permission or to make a registration required by the provisions of this Act or any rule or
bye-law made under this Act, the magistrate shall, in addition to any fine which may be imposed,
recover summarily and pay over to the council amount of the fee chargeable for the licence or
permission or for registration, and may in his discretion also recover summarily and pay over to the
council such amount, if any, as he may fix as the costs of the prosecution.(11)Save as otherwise
expressly provided in or prescribed under this Act, every application for a licence or permission or
for registration or the renewal of a licence or permission or registration, shall be made not less than
thirty days and not more than ninety days before the commencement of the year or of such less
period as is mentioned in the application.(12)Such recovery of the fee under sub-section (10) shall
not entitle the person convicted to a licence or permission or to registration as aforesaid.(13)The
acceptance by council of the pre-payment of the fee for a licence or permission or for registration
shall not entitle the person making such pre-payment to the licence or permission or to registration
as the case may be, but only to refund of the fee, in the case of refusal of the licence or permission or
registration; but an applicant for the renewal of a licence or permission or registration shall, until
communication of orders on his application, be entitled to act as if the licence or permission orAndhra Pradesh Municipalities Act, 1965

registration had been renewed; and save as otherwise specially provided in this Act, if orders on an
application for or renewal of licence or permission, or registration are not communicated to the
applicant within ninety days in the case of the grant of a licence, permission or registration and
thirty days in the case of the renewal of a licence, permission or registration, after the receipt of the
application by the Commissioner the application shall be deemed to have been allowed for the year
or for such shorter period as is mentioned in the application subject to the conditions imposed by or
under this Act. Appeals
345. Appeals.
(1)An appeal shall lie to the council from--(a)any notice issued or other action taken or proposed to
be taken by the Chairperson, Commissioner, municipal health officer or any other officer of the
municipality--(i)under Sections 140, 150, 157 to 161 (both inclusive) sub-sections (1) and (3) of
Section 217, Sub-section (3) of Section 228, Subsection (1) of Section 231, sub-section (1) of section
232, Sub-section (1) of Section 237 and Sections 239, 250, 261 and 262;(ii)under any bye-law
concerning house drainage and the connection of house drains with municipal drains or connections
with municipal water supply or lighting mains; or(b)any order of the Commissioner, municipal
health officer or any other officer of the municipality granting or refusing a licence or permission;
or(c)any order of the Commissioner made under Section 212 refusing to approve the site for
building, or under sub-section (6) of Section 344 suspending or revoking a licence; or(d)any other
order of the Commissioner, municipal health officer or any other officer of the municipality that
may be made appealable by rules under Section 326.(2)The decision of the council on an appeal
referred to it under sub-section (1) shall be final.(3)An appeal under this section shall be presented
and disposed of in the manner prescribed and no court-fee shall be chargeable therefor.
346. Limitation of time for appeal.
- In any case in which no time is prescribed by the foregoing provisions of this Act for the
presentation of an appeal allowed thereunder, such appeal, subject to the provisions of Section 5 of
the Limitation Act, 1963. (Central Act 36 of 1963) shall be presented--(a)where the appeal is against
an order granting a licence or permission, within thirty days after the date of the publication of the
order on the notice board of the council; and(b)in other cases, within thirty days after the date of the
receipt of the order or proceeding against which appeal is made.
347. Power of persons conducting election and other enquiries.
- All persons authorised by rule to conduct enquiries relating to elections and all inspecting or
superintending officers holding any enquiries into matters falling within the scope of their duties
shall have, for the purposes of such enquiries the same powers in regard to the issue of summons for
the attendance of witnesses and the production of documents, as are conferred on revenue officers
by the law relating to the issue of revenue summonses for the time being in force and all persons to
whom summonses are issued by virtue of the said powers shall be bound to obey such summonses.Andhra Pradesh Municipalities Act, 1965

348. Summons to attend and give evidence or produce documents.
- The Chairperson, Commissioner, Municipal Health Officer, Municipal Engineer or Town Planning
Officer may summon any person to appear before him, and to give evidence or produce documents
in respect of any question relating to taxation, or inspection or registration, or to the grant of any
licence or permission under the provisions of this Act.
349. Form of notices and permissions.
- All notices and permissions given, issued or granted, as the case may be, under the provisions of
this Act shall be in writing and in such form as may be prescribed.
350. Signature on documents.
(1)Every licence, permission, notice, bill, Schedule, summons or other document which is required
by this Act or by any rule, bye-law or regulation made under it to bear the signature of the
Chairperson or Commissioner or of any Municipal Officer shall be deemed to be properly signed if it
bears a facsimile of the signature of the Chairperson, Commissioner or of such Municipal Officer, as
the case may be stamped thereon.(2)Nothing in Sub-section (1) shall be deemed to apply to a cheque
drawn upon the municipal fund or to any deed of contract entered into by the council.
351. Publication of bye-laws, notices, orders etc.
- Every bye-law, order, notice or other document directed to be published under this Act shall be
written in, or translated into, the main language of the district and deposited at the municipal office,
and a copy shall be posted up in a conspicuous position at such office and such other places as the
council may direct, and a public proclamation shall be made throughout the municipality by beat of
drum that such copy has been so posted up and that the original is open to inspection at the
municipal office.
352. Notice of prohibition or setting apart of places.
- Whenever the council has set apart any place for any purpose authorised by this Act or has
prohibited the doing of anything in any place, the Commissioner shall forthwith cause to be put up a
notice in English and in the main language of the district at or near such place. Such notice shall
specify the purpose for which such place has been set apart or the act prohibited in such place.
353. Method of serving documents.
(1)When any notice, or other documents is required by this Act or by any rule, bye-law, regulation or
order made under it, is to be served on or sent to any person, the service or sending thereof may be
effected--(a)by giving or tendering the said document to such person; or(b)if such person is not
found, by leaving such document at his last known place of abode or business or by giving orAndhra Pradesh Municipalities Act, 1965

tendering the same to some adult member or servant of his family; or(c)if such person does not
reside in the municipality and his address elsewhere is known to the Commissioner by sending the
same to him by post registered; or(d)if none of the means aforesaid be available, by fixing the same
in some conspicuous part of such place of abode or business.(2)Where the person is an owner or
occupier of any building or land, it shall not be necessary to name the owner or occupier in the
notice or document, and in the case of joint owners and occupiers it shall be sufficient to serve it on,
or send it to , one of such owners or occupiers.(3)Whenever in any bill, notice, form or other
document, served or sent under this Act, a period is fixed within which any tax or other sum is to be
paid or any work executed or anything provided, such period shall save as otherwise provided in this
Act, be calculated from the date of such service or sending. Relations of occupier to owner.
354. Recovery by occupier of sum leviable from owner.
- If the occupier of any building or land makes on behalf of the owner thereof any payment for which
under this Act the owner but not the occupier is liable, such occupier shall be entitled to recover the
same from the owner and may deduct the same from the rent then or thereafter due by him to the
owner.
355. Obstruction of owner by occupier.
(1)If the occupier of any building or land prevents the owner from carrying into effect in respect
thereof any of the provisions of this Act, the Commissioner may by an order, require the said
occupier to permit the owner, within eight days from the date of service of such order, to execute all
such works as may be necessary.(2)Such owner shall, for the period during which he is prevented as
aforesaid, be exempt from any fine or penalty to which he might otherwise have become liable by
reason of default in executing such works.
356. Execution of work by occupier in default of owner.
- If the owner of any building or land fails to execute any work which he is required to execute under
the provisions of this Act or of any rule, bye-law, regulation or order made under it, the occupier of
such building or land may, with the approval of the Commissioner execute the said work and shall
be entitled to recover from the owner the reasonable expenses incurred in the execution thereof, and
may deduct the amount thereof from the rent then or thereafter due by him to the owner.
357. Power of entry to inspect, survey or execute the work.
- The Chairperson or Commissioner or any person authorised by him in this behalf may enter into or
on any building or land with or without assistants or workmen in order to make any enquiry,
inspection, test, examination, survey, measurement, or valuation or for the purpose of lawfully
placing or removing pipes or meters, or to execute any other work which is authorised by the
provisions of this Act or of any rule, bye-law, regulation or order made under it, or which it is
necessary for any of the purposes of this Act or in pursuance of any of the said provisions, to makeAndhra Pradesh Municipalities Act, 1965

or execute:Provided that--(a)except when it is in this Act otherwise expressly provided, no such
entry shall be made after sunset and before sunrise;(b)except when it is in this Act otherwise
expressly provided, no dwelling house, and no part of a public building, used as a dwelling place,
shall be so entered without the consent of the occupier thereof, unless the said occupier has received
at least two hours' previous notice of the intention to make such entry; and(c)sufficient notice shall
be given in every case even when any premises may otherwise be entered without notice, to enable
the inmates of any apartment appropriated to women to remove to some part of the premises where
their privacy may be preserved;(d)due regard shall be had, so far as may be compatible with the
exigencies of the purpose of the entry, to the social and religious usages of the occupants of the
premises.
358. Power of entry on lands adjacent to works.
(1)Chairperson or Commissioner or any person authorised by him in this behalf may, with or
without assistants or workmen enter on any land adjoining or within fifty meters of any work
authorised by this Act or by any rule, bye-law, regulation or order made under it, for the purpose of
depositing on such land any soil, gravel, stone or other materials, or of obtaining access to such
work or for any other purpose connected with the carrying on thereof.(2)The Chairperson or
Commissioner or any person authorised by him as aforesaid, shall, before entering on any land
under sub-section (1), give the owner or occupier three days previous notice of the intention to make
such entry and state the purpose thereof, and shall if so required by the owner or occupier fence off
so much of the land as may be required for such purpose.(3)The Chairperson or Commissioner shall
not be bound to make any payment, tender or deposit, before entering on any land under
sub-section (1), but as little damage as may be shall be done and the Chairperson or Commissioner
shall pay compension to the owner or occupier of land for such entry and for any temporary or
permanent damage that may result therefrom.(4)If such owner or occupier is dissatisfied with the
amount of compensation paid to him by the Chairperson or Commissioner he may appeal to the
council. Power to enforce licensing provisions, orders etc.
359. Consequences of failure to obtain licences, etc., or of breach of the
same.
- If, under this Act or any rule, bye-law or regulation made under it, the licence or permission of the
council Chairperson, Commissioner or other officer of the municipality or registration in the
municipal office is necessary for the doing of any act, and if such act is done without such licence or
permission or registration, or in a manner not consistent with the terms of any such licence or
permission, then--(a)the Chairperson, Commissioner or other officer may, by notice, require the
person so doing such act to alter, remove or, as far as practicable, restore to its original state the
whole or any part of any property move-able or immovable, public or private affected thereby,
within a time to be specified in the notice; and further.(b)if no penalty has been specially provided in
this Act for so doing such act, the person so doing it shall be liable, on conviction before a
magistrate, to a fine not exceeding fifty rupees for every such offence.Andhra Pradesh Municipalities Act, 1965

360. Time for complying with order and power to enforce in default.
(1)Whenever by in any notice, requisition, or order under this Act, or under any rule, bye-law or
regulation made under it, any person is required to execute any work or to take any measures or to
do anything, a reasonable time shall be named in such notice, requisition or order within which the
work shall be executed, the measures taken or the thing done.(2)If such notice, requisition or order
is not complied with, within the time so named, the Chairperson or Commissioner or other officer
concerned may cause such work to be executed or may take any measures or do anything which
may, in his opinion, be necessary for giving due effect to the notice; requisition or order as aforesaid;
and further if no penalty has been specially provided in this Act for failure to comply with such
notice, the said person shall be liable on conviction before a magistrate to a fine not exceeding fifty
rupees for every such offence.
361. Recovery of expenses from persons liable and limitation of liability of
occupier.
(1)The Commissioner may, subject to the provisions of Section 150, recover any reasonable expenses
incurred under Section 360 from the person or any one of the persons to whom the notice,
requisition or order was addressed, and may, in executing work or taking measures under Section
360 utilize any materials found on the property concerned or may sell them and apply the sale
proceeds in or towards the payment of the expenses incurred.(2)If the person to whom notice is
given is the owner of the property in respect of which it is given, the Commissioner may, whether
any action or other proceeding has been brought or taken against such owner or not, require the
person, if any, who occupies such property, or any part thereof, under the owner, to pay to the
council, instead of to the owner, the rent payable by him in respect of such property, as it falls due,
upto the amount recoverable from the owner under sub-section (1) or to such smaller amount as the
Commissioner may think proper; and any amount so paid shall be deducted from the amount
payable by the owner.(3)For the purpose of deciding whether action should be taken under
sub-section (2), the Commissioner may require any occupier of property to furnish information as to
the sum paid by him as rent on account of such property and as to the name and address of the
person to whom it is payable; and such occupier shall be bound to furnish such information.
362. Power of Commissioner to agree to receive payment of expenses in
instalments.
- Instead of recovering any such expenses as aforesaid in the manner provided under Section 364,
the Commissioner may, if he thinks fit, take an agreement from the person liable to the payment
thereof, to pay the same in instalments of such amounts and at such intervals as will serve the
payment of the whole amount due, with interest thereon, at such rates as may be prescribed at
within a period of not more than five years. Payment of compensation, etc. by and to the
municipalityAndhra Pradesh Municipalities Act, 1965

363. Power of municipality to pay compensation.
- If in any case not otherwise expressly provided for, in this Act, the Commissioner may, with the
approval of the Council pay compensation to any person who sustains damage by reason of the
exercise by any municipal authority, officer or servant of any of the powers vested in them by this
Act or any other law, or by any rule, bye-law or regulation made under it.
364. Recovery of sums due as taxes.
- All costs, damages, penalties, compensation charges, fees, other than school fees, expenses, rents,
contributions and other sums which under this Act or any other law or rules or bye-laws made
thereunder or under any contract in respect of water supply or drainage, made in accordance with
this Act, the rules or bye-laws, are due by any person to the council, may, if there is no special
provision in this Act for their recovery be demanded by bill as provided in the rules in Schedule II
and recovered in the manner provided therein.
365. Limitation for recovery of dues.
(1)No distraint shall be made, no suit shall be instituted and no prosecution shall be commenced in
respect of any sum due to the council under this Act after the expiration of a period of three years
from the date on which distraint might first have been made, or after the expiration of a period of
nine years from the date on which a suit might first have been instituted, or after the expiration of a
period of six years from the date on which prosecution might first have been commenced, as the
case may be, in respect of such sum;(2)It shall be the duty and responsibility of the Commissioner to
place before the council a list of arrears due to the council under this Act which, if no action is taken
within the period specified in sub-section (1), are likely to be time-barred, atleast one year before the
expiry of the said period stating the reasons for the delay in the recovery of such amount and
requesting for the instructions or directions of the Council in regard to the recovery of such
arrears.(3)If the Commissioner fails to furnish the list as aforesaid or omits to show in such list any
arrears, or if the arrears shown in the list are due to the failure on the part of any bill collector or
other employee of the council, entrusted with the collection of sums due to the council under this
Act, the Commissioner or such bill-collector or other employee, as the case may be, shall be deemed
to be negligent for which, action under sub-section (1) of Section 374 may be taken.
366. Persons empowered to prosecute.
- Subject to the provisions of Section 365, no person shall be tried for any offence against the
provisions of this Act, or of any rule or bye-law made under it, unless complaint is made by the
Commissioner or by a person expressly authorized in this behalf by the Council within three months
of the commission of the offence. But nothing therein shall affect the provisions of the Code of
Criminal Procedure, 1973 (Central Act 2 of 1974), in regard to the powers of certain magistrates to
take congizance of offences upon information received or upon their own knowledge or
suspicion;Provided that failure to take out a licence, obtain permission or secure registration underAndhra Pradesh Municipalities Act, 1965

this Act shall, for the purposes of this section, be deemed a continuing offence until the expiration of
the period, if any, for which the licence permission or registration is required and if no period is
specified, complaint may be made at any time within twelve months from the commencement of the
offence.
367. Imprisonment in default of payment and application of costs etc.
(1)In case any fine or costs imposed or assessed by a magistrate under this Act or under any rule or
bye-law made under it, shall not be paid, the magistrate may order the offender to be imprisoned in
default of payment subject to all the restrictions, limitations and conditions imposed in Sections 64
to 70 (both inclusive) of the Indian Penal Code.(2)Any fine, costs, tax or other sum imposed or
assessed by a magistrate under this Act or under any rule or bye-law made under it shall be
recoverable by such magistrate under the Code of Criminal Procedure, 1973 (Central Act 2 of 1974),
as if it were a fine and the same shall, except in the case of a fine on recovery, be paid to the council,
to be applied to the purposes of this Act.
368. Payment of compensation for damage to municipal property.
- If, on account of any act or omission any person has been convicted of an offence against the
provisions of this Act or against any rule or bye-law made under it and by reason of such act or
omission, damage has been caused to any property owned by or vesting in the council, the said
person shall pay compensation for such damage, notwithstanding any punishment to which he may
have been sentenced for the said offence. In the event of dispute, the amount of compensation
payable by the said person shall be determined by the magistrate before whom he was convicted of
the said offence on application made to him for the purpose of, by the Commissioner not later than
three months from the date of conviction; and in default of payment of the amount of compensation
so determined, it shall be recovered under a warrant from the said magistrate as it it were a fine
inflicted by him on the person liable therefor.
369. Institution of suits against municipal authorities, officers and servants.
(1)No suit for damages or compensation shall be instituted against the council, any municipal
authority, officer or servant, or any person acting under the direction of such council, municipal
authority, officer or servant, in respect of any act done in pursuance of execution or intended
execution of this Act or any rule, bye-law, regulation or order made under it or in respect of any
alleged neglect or default in the execution of this Act, or any rule, bye-law, regulation, or order made
under it, until the expiration of three months after a notice has been delivered or left at the
municipal office or at the place of abode of such officer, servant or person, stating the cause of
action, the relief sought and the name and the place of abode of the intending plaintiff and the plaint
shall contain a statement that such notice has been so delivered or left.(2)Every such suit shall be
instituted within six months after the date on which the cause of action arose or in a case of a
continuing injury or damage, during such continuance or within six months after the ceasing
thereof.(3)Where the defendant in any such suit is the Chairperson, the Commissioner or a
municipal officer or employee, payment of the sum or any part of any sum, payable by him in, or inAndhra Pradesh Municipalities Act, 1965

consequence of the suit whether in respect of costs, charges, expenses, compensation, for damages
or otherwise, shall be met from the municipal fund.
370. Provisions respecting institution etc., of civil and criminal actions and
obtaining of legal advice.
- The Commissioner may, ..............(a)take, or withdraw from, proceedings against any person who
commits--(i)any offence against this Act, rules, bye-laws or regulations;(ii)any offence which affects
or is likely to affect any property or interest of the council or the due administration of this
Act;(iii)any nuisance whatsoever;(b)compound any offence against this Act, the rules, bye-laws or
regulations which has been specified as compoundable in Schedule VI;(c)take, withdraw from or
compromise proceedings for the recovery of expenses or compensation claimed to be due to the
council;(d)withdraw or compromise any claim against any person in respect of a penalty payable
under a contract entered into with such person;(e)defend any suit or other legal proceedings
brought against the council or against any municipal authority, officer or employee, in respect of
anything done or omitted to be done as aforesaid;x x x x(f)compromise any claim, suit or legal
proceedings brought against the council or against any municipal authority, officer or employee, in
respect of anything, done or omitted to be done as aforesaid;(g)institute and prosecute any suit or
withdraw from or compromise any suit or claim, which has been instituted or made in the name of
the council or any other municipal authority officer or employee;(h)obtain such legal advice and
assistance as he may, from time to time, think it necessary or expedient to obtain, or as he may be
desired by the council to obtain, for any of the purposes mentioned in the foregoing clauses of this
section or for securing the lawful exercise or discharge of any power or duty vesting in or imposed
upon, any municipal authority or officer or employee.
371. Power of election authority to defend himself, if sued.
- The election authority may defend himself, if sued or joined as party in any proceeding relating to
the preparation or publication of electoral rolls or the conduct of elections, as the case may be, and
the expenses incurred by the election authority in so doing shall be payable from the municipal
fund.
372. Injunctions not be granted in election proceedings.
- Notwithstanding anything in the Code of Civil Procedure, 1908 (Central Act 5 of 1908), or in any
other law for the time being in force, no court shall grant any temporary injunction or make any
interim order restraining any proceeding which is being or about to be taken under this Act, for the
preparation or publication of electoral rolls or for the conduct of any elections.
373. Indemnity to the Government, Collector, Revenue Divisional Officer,
Municipal Authorities, Officers and Agents.Andhra Pradesh Municipalities Act, 1965

- No suit shall be maintainable against the Government, the District Collector, the Revenue
Divisional Officer or any Chairperson, Municipal Authority, officer or employee or any person acting
under the direction of any Chairperson, municipal authority, officer or employee, or of a magistrate,
in respect of anything done in good faith under this Act or any rule, bye-law, regulation or order
made under it.
374. Liability for loss, waste or misapplication.
(1)The Chairperson, every Member, the Commissioner, the Municipal Health Officer, the Municipal
Engineer, the Education Officer, the town planning officer and the bill collector or other employee of
the council, entrusted with the collection of sums due to the council under this Act, shall be liable for
the loss, waste or misapplication of any money or other property owned by or vested in the council,
if such loss, waste or misapplication is a direct consequence of his neglect or misconduct and a suit
for compensation may be instituted against him by the council with the previous sanction of the
Government or by the Government.(2)No such suit shall be instituted after three years after the
accrual of the cause of action.
375. Sanction for prosecution of Chairperson, Council, Commissioner or
Municipal Health.
- Officer or any other officer When the Chairperson any Member, the Commissioner or municipal
health officer or any other officer is accused of any offence alleged to have been committed by him
while acting or purporting to act in the discharge of his official duty, no court shall take cognizance
of such offence except with the previous sanction of the Government.
376. Assessments etc., not to be questioned.
(1)No assessment or demand made, and no charge imposed under the authority of this Act shall be
questioned or affected by reason of any clerical error or by reason of any mistake (a) in respect of the
name, residence, place of business or occupation of any person or (b) in the description of any
property or thing, or (c) in respect of the amount assessed, demanded or charged, provided that the
provisions of this Act have been in substance and effect, complied with; and no proceedings under
this Act shall, merely for defect in form, be quashed or set aside by any Court.Provided that the
person or property so assessed or charged is reasonably ascertainable.(2)No suit shall be brought in
any court to recover any sum of money collected under the authority of this Act or to recover
damages on account of any assessment or collection of money made under the said
authority;Provided that the provisions of this Act have been, in effect, complied with.(3)No distraint
or sale under this Act shall be deemed unlawful, nor shall any person making the same be deemed a
trespasser, on account of any error, defect or want of form in the bill, notice, Schedule, form,
summons, notice of demand, warrant of distraint, inventory, or other proceeding relating thereto, if
the provisions of this Act, the rules and bye-laws have in substance and effect been complied
with:Provided that every person aggrieved by any irregularity may recover compensation for any
special damage sustained by him.(4)Notwithstanding anything contained in sub-sections (1), (2)Andhra Pradesh Municipalities Act, 1965

and (3), no suit shall be entertained by any Court of law unless the aseeess pays fifty percent of the
tax levied and demanded.
377. Injunctions not to be granted in respect of revisions or amendment of
assessment books.
- Notwithstanding anything in the Code of Civil Procedure, 1908 (Central Act 5 of 1908) or in any
other law for the time being in force, no court shall grant any interim or temporary injunction or
make any interim orders restraining any proceeding which is being or about to be taken under Rule
8 in Schedule II to this Act, for the revision or amendment of the assessment books or restraining
such revision or amendment from taking effect Police.
378. Duties of Police Officers.
(1)It shall be the duty of every police officer:(a)to communicate without delay to the proper
municipal officer any information which he receives of the design to commit or of the commission of
any offence under this Act or any rule, bye-law or regulation made under it, and(b)to assist the
Chairperson, the Commissioner or any municipal officer or employee reasonably demanding his aid
for the lawful exercise of any power vesting in the Chairperson or the Commissioner or in such
municipal officer or employee under this Act, or any such rule, bye-law or regulation.(2)Any police
officer who omits or refuses to perform any duty imposed on him by this Act shall be deemed to
have committed an offence under the law governing the police force for the time being in force.
379. Power of Police Officers to arrest persons.
(1)If any police officer sees any person committing an offence against any of the provisions of this
Act or of any rule or bye- law made under it, he shall, if the name and address of such person are
unknown to him, and if the said person on demand declines to give his name and address, or gives a
name and address which such officer has reason to believe to be false, arrest such person.(2)No
person arrested under sub-section (1) shall be detained in custody(a)after his true name and address
are ascertained, or(b)without the order of a magistrate for any longer time, not exceeding
twenty-four hours from the hour of arrest than is necessary for bringing him before a magistrate.
380. Exercise of powers of Police Officer by Municipal Officers or Employees.
- The Government may empower any municipal officer or employee or any class of municipal
officers or employees to exercise the powers of police officer for the purposes of this Act and of the
Andhra Pradesh Towns Nuisances Act, 1889 (Act III of 1889).
381. Application of term of `Public Servant' to Municipal Officers, Agents and
sub-agents.Andhra Pradesh Municipalities Act, 1965

- Every municipal officer or employee, every contractor or agent for the collection of any municipal
tax, fee or other sum due to the council and every person employed by any such contractor or agent
for the collection of such tax, fee or sum shall be deemed to be a public servant within the meaning
of Section 21 of the Indian Penal Code.
382. Prohibition against obstruction of municipal authorities, employees and
contractors.
- No person shall obstruct or molest the council, the Chairperson, any Member, the Commissioner
or any other municipal officer or employee or any person employed by the council or any person
with whom a contract has been entered into on behalf of the council, in the performance of their
duty or of anything which they are empowered or required to do by virtue or in consequence of this
Act or of any bye-law, rule, regulation or order made under it.
383. Prohibition against removal of mark.
- No person shall remove any mark set up for the purpose of indicating any level or direction
incidental to the execution of any work authorised by this Act or by any bye-law, rule or order made
under it.
384. Prohibition against removal or obliteration of notice.
- No person shall, without authority in that behalf, remove, destroy, deface or otherwise obliterate,
any notice exhibited by, or under the orders of the council or the Commissioner or other officer
authorised by him in this behalf.
385. Prohibition against unauthorised dealings with public place or materials.
- No person shall, without authority in that behalf, remove earth, sand or other material or deposit
any matter or make any encroachment from, in, or on, any land vested in the council, or river,
estuary, canal, backwater or water course, not being private property or in any way obstruct the
same.
386. Oath of allegiance to be taken by Chairperson or Members.
(1)Every person who is elected to be a Chairperson or Member shall, before taking his seat, make at
a meeting of the council on oath or affirmation of his allegiance to the Constitution of India in the
following form, namely:-I, .................... having become a Chairperson/Member of the Municipal
Council swear in the name of God/solemnly affirm, that I will bear true faith and allegiance to the
Constitution of India as by law established, that I will uphold the sovereignty and integrity of India
and that I will faithfully discharge the duty upon which I am about to enter".(2)Any such
Chairperson or Member who fails to make, within three months of the date on which his term of
office commences or at one of the first three meetings held after the said date, whichever is later, theAndhra Pradesh Municipalities Act, 1965

oath or affirmation laid down in sub-section (1), shall cease to hold his office and his seat shall be
deemed to have become vacant.(3)No such Chairperson or Member shall take his seat at a meeting
of the council or do any act as such Member, unless he has made the oath or affirmation as laid
down in this section.(4)Where a person ceases to hold office under Sub-section (2) the
Commissioner shall report the same to the council at its next meeting and on application of such
person made within thirty days of the date on which he has ceased to be a member under that Sub-
section the council may grant him further time which shall not be less than three months for making
the oath or affirmation and if he makes the oath or affirmation within the time so granted, he shall,
notwithstanding anything in the foregoing sub-sections, continue to hold his office.
387. Delegation of powers by the Government.
(1)The Government may, by notification in the Andhra Pradesh Gazette, delegate to any person or
authority all or any of the powers vested in them by this Act except the power to make rules and
may, in like manner, withdraw any powers so delegated.(2)The exercise of any powers delegated
under Sub-section (1) shall be subject to such restrictions and conditions as may be prescribed or as
may be specified in the notification and also to control and revision by the Government.
387A. Power to give directions.
- The Government may from time to time give such directions not inconsistent with the provisions
of the Act or the rules made thereunder to the municipalities as it may consider necessary for
carrying out the purposes of this Act.
388. Adjudication of disputes between local authorities.
(1)When a dispute exists between a council and one or more than one local authority in regard to
any matters arising under the provisions of this Act or any other enactment and the Government are
of opinion that the local authorities concerned are unable to settle it amicably among themselves,
the Government may take cognizance of the dispute; and(a)decide it themselves, or(b)refer it for
inquiry and report to an arbitrator or a board of arbitrators.(2)The report referred to in Clause (b) of
sub-section (1) shall be submitted to the Government who shall decide the dispute in such manner
as they deem fit.(3)Any decision given under Clause (a) of sub-section (1) or under sub-section (2),
may at the instance, whether before or after the commencement of this Act, of the local authorities
concerned, be modified from time to time by the Government in such manner as they deem fit, and
any such decision with the modifications, if any, made therein under this sub-section, may, at the
instance of such local authorities be cancelled at any time by the Government. Any such decision or
any modification therein or cancellation thereof, shall be binding on each of the local authorities
concerned and shall not be liable to be questioned in any court of law.
389. Act to be read subject to Schedule IX in regard to first reconstitution of
councils, etc.Andhra Pradesh Municipalities Act, 1965

- In regard to the first constitution of a council for any local area under Section 3, or to the first
reconstitution in accordance with the provisions of this Act, of a council in existence at the
commencement thereof, and otherwise in first giving effect to the provisions of this Act, this Act
shall be read subject to the rules in Schedule IX.
389A. Notified Areas.
(1)(a)The Government may by notification in the Andhra Pradesh Gazette, declare any local area to
be a notified area, for the purpose of application of all or any of the provisions of this Act in the said
notified area.(b)Where any local area is declared as a notified area, the Government may pass such
orders as they may deem fit, as to exclude the local area from the jurisdiction of the local authority
concerned, as to the disposal of any part of the property vested in such local authority and as to the
discharge of the liabilities of such local authority relating to the said property, or arising from such
local area.(2)The Government may, by notification in the Andhra Pradesh Gazette,(a)apply or adopt
to a notified area or any part thereof, any provision of this Act or of any rule or bye-law made
thereunder.(b)impose in a notified area or any part thereof,(i)any tax, which might be imposed by
the council under the provisions of this Act if the notified area were a municipality;(ii)where it is a
mining area, a tax on mineral rights, subject to any limitations which may be imposed by Parliament
by law relating to mineral development and the rules made thereunder, and subject to such rules as
may be prescribed in this behalf:(c)appoint a committee for the purposes of-(i)the assessment and
recovery of any tax imposed under clause (b);(ii)arranging the due expenditure of the proceeds of
such taxes;(iii)the preparation and maintenance of proper accounts; and(iv)generally enforcing the
provisions of this Act or any rule or bye-law applied or adopted under clause (a);(d)provided
for(i)the total number of members of the committee, which shall not be less than seven but not more
than fifteen, to be nominated by the Government of whom(A)not less than two but not more than
four shall be officials;(B)not less than two but not more than four shall be persons representing the
mining or industrial managements within the notified area;(C)not less than two but not more than
four shall be persons representing the employees of such managements; and(D)not more than three
shall be other persons residing within the notified area;(ii)the persons who shall be the Chairperson
and Vice-Chairperson of the committee, or the manner in which they shall be chosen, from among
the members of the committee;(iii)the term of office of the members of the committee; and(iv)the
restrictions and conditions subject to which the committee may perform its functions.(3)The
proceeds of any tax imposed in a notified area under this section shall be expended in the same
manner in which the municipal fund might be expended under the provisions of this Act, if the
notified area were a municipality.(4)For the purpose of any provisions of this Act, which may be
applied or adopted to a notified area the committee appointed for such area shall be deemed to be a
council under this Act and the area shall be deemed to be a municipality.(5)The Government may, at
any time, modify or cancel any notification issued under this section.(6)Where by reason of the
cancellation under sub-section (5) of any notification issued under this section, any area ceases to be
a notified area, the Government may pass such orders as they may deem fit, as to the transfer of the
assets of the committee of such area, as to the discharge of the liabilities, if any, of such committee
and as to the manner in which the expended funds shall be applied.Andhra Pradesh Municipalities Act, 1965

389B. Power to transfer functions of Municipalities to Andhra Pradesh
Industrial Infrastructure Corporation.
- Notwithstanding anything contained in this Act, or in any other law for the time being in force
relating to the Municipalities or the notified area Committees, the Government may, in consultation
with any Municipality or the notified area Committee, as the case may be, and also the Andhra
Pradesh Industrial Infrastructure Corporation, by notification in the Andhra Pradesh Gazette, and
subject to such restrictions and conditions including those relating to the remittance of such
percentage of the property tax to a Municipality or to a notified area Committee and to such control
and revision as may be specified therein direct that any power or function vested in the Municipality
or the notified area Committee by or under this Act shall be transferred to and exercised and
performed by the Andhra Pradesh Industrial Infrastructure Corporation.
390. Amendment of Andhra Pradesh (Telangana Area) Mining Settlements
Act, 1956.
- After Section 60 of the Andhra Pradesh (Telangana Area) Mining Settlements Act, 1956, (Act XLIV
of 1956), the following section shall be inserted, namely:-"60A. extension of provisions of law
relating to municipalities or of rules thereunder:-(1)The Government may, at the request of the
Board or otherwise by notification declare that any of the provisions of the Andhra Pradesh
Municipalities Act, 1965, or of any rule made thereunder including those relating to taxation shall be
extended to and be in force in the Mining Settlement or any specified area therein.(2)The provisions
so notified shall be construed with such alterations not affecting the substance as may be necessary
or proper for the purpose of adapting them to the Mining Settlement or any special area
therein.(3)Without prejudice to the generality of the foregoing provision, all references to a council,
or Chairperson thereof shall be construed as references to Board, or Chairperson thereof, all
references to any officer or employee of a council as references to the corresponding officer or
employee of Board and all references to Municipal limit as references to the limits of the Mining
Settlement or the specified area therein, as the case may be."
391. Repeal of Andhra Pradesh (Andhra Area) District Municipalities Act,
1920 and Andhra Pradesh (Telangana Area) District Municipalities Act, 1956.
(1)The Andhra Pradesh (Andhra Area) District Municipalities Act, 1920 (Act V of 1920) is hereby
repealed.(2)On and from the commencement of this Act, except Chapter XIV, the other provisions
of the Andhra Pradesh (Telangana Area) District Municipalities Act 1956 (Act, XVIII of 1956) are
hereby repealed.(3)The provisions of the Government Buildings Act, 1899, (Central Act 4 of 1899)
shall cease to apply to buildings within the limits of municipalities constituted or deemed to be
constituted under this Act.(4)The provisions of Sections 89, 90 and 94 of the Andhra Pradesh
(Andhra Area) Public Health Act, 1939 (III of 1939), shall cease to apply to municipalities.Andhra Pradesh Municipalities Act, 1965

Schedule
Rules regarding Proceedings of the Council(Section 32)Mode of transacting business.
1. The council shall provide an office and shall meet therein for the
transaction of business atleast once in every month, upon such days and at
such times as it may fix and also at other times as often as a meeting is
called by the Chairperson:
Provided that [no meeting except a meeting referred to in clause (a) of sub-section (1) of Section 20
and subsection (3) of Section 23 of the Act] shall be held on a public holiday.Explanation. - For the
purposes of these rules, the expression `public holiday' includes Sundays and any other day
declared by the Government, by notification in the Andhra Pradesh Gazette, to be a public
holiday.(1)No meeting shall be held unless notice of the day and time when the meeting is to be held
and of the business to be transacted thereat has been given at least three clear days before the day of
the meeting.(2)In cases of urgency the Chairperson may convene a meeting on giving shorter notice
than that specified in sub-rule (1).(3)The agenda for the meeting shall be prepared by the
Commissioner in consultation with the Chairperson. The Commissioner may include in the agenda
any subject which in his opinion should be considered by the council and shall include therein any
subject specified by the Chairperson. On any subject included in the agenda the Chairperson as well
as the Commissioner shall have the right of recording his views in a note and such note shall be
circulated to the Members or placed before the council before or at the time of the consideration of
such subject by the council.
2.
(1)The Chairperson shall, on the requisition in writing of not less than one-third of the Members
then on the council, convene a meeting of the council provided that the requisition specifies the day,
other than a public holiday, the time and the purpose for which the meeting is to be held. The
requisition shall be delivered at the municipal office during office hours to the Chairperson or
Commissioner, Manager or any other person who may then be in charge of the office, atleast ten
clear days before the day of the meeting.(2)Where the Chairperson fails within forty-eight hours
from the delivery of such requisition to call a meeting, on the day specified therein, or within three
days from such day, the meeting may be called by the Members who signed the requisition on giving
the notice provided for in sub-rule (1) of Rule 2 to the other Members.
3. All meetings of the council shall be open to the public:-
Provided that the presiding Member may, and at the request of the council shall, in any particular
case, for reasons to be recorded in minutes book kept under Rule 9, direct that the public generally,
or any particular person, shall withdraw.Andhra Pradesh Municipalities Act, 1965

4. All questions which may come before the council at any meeting shall be
decided by a majority of the Members present and voting at the meeting and,
in every case of equality of votes, the presiding Member shall have and
exercise a second or casting vote.
5. No business shall be transacted at a meeting unless there be present
atleast six Members and if the number of Members then on the council
exceeds sixteen, at least one third of that number.
6. If within half an hour after the time appointed for a meeting a quorum is not
present, the meeting shall stand adjourned, unless all the Members present
agree to wait longer.
7. No resolution of the council shall be modified or cancelled within three
months after the passing thereof except at a meeting specially convened in
that behalf and by a resolution of the council supported by not less than
one-half of the number of Members than on the council.
8. Minutes of the proceedings at each meeting of the council shall be drawn
up and entered in a book to be kept for that purpose; and shall be signed by
the presiding member; and the said minutes shall, at all reasonable times
and without charge, be open at the municipal office to the inspection of any
person who pays any tax under this Act in the municipality.
9. Within three days of the date of the meeting, a copy of the minutes of the
proceedings at such meeting in English and in the main language of the
district, shall be forwarded by the Commissioner, to the Collector of the
district and another copy to the Regional Director of Municipal
Administration of the region, in which the municipality is situated. An
authenticated copy of the said minutes shall also be affixed to the notice
board of the municipal office and relevant extracts of the said minutes shall
be sent to the heads of departments of the Government and to the
superintending officers appointed under sub-section (1) of Section 63 for
information and necessary action. The Chairperson shall immediately submit
to the Collector and to the Regional Director a copy of any minute of dissent
that may be forwarded to him within forty-eight hours of the meeting by any
Member.Andhra Pradesh Municipalities Act, 1965

[When a Member gives a dissent note the Chairperson shall incorporate the same, in the Minutes
Book. If the Chairperson fails to record the dissent note given by any Member in the Minutes Book,
the Commissioner shall record the same and intimate the Member, who gave the dissent note].
10. The Commissioner shall have the custody of the proceedings and
records of the council and may grant copies of any such proceedings and
records on payment of such fees as the council may, by general or special
order, determine. Copies shall be certified by the Commissioner as provided
in Section 76 of the Indian Evidence Act, 1872 (Central Act 1 of 1872) and
copies so certified may be used to prove the records of the council in the
same manner as they may, under sub-section (5) of Section 78 of the said
Act, be used to prove the proceedings of that body.
11. The Chairperson elected by the council under Section 28 shall meet in the
office provided by the council under Rule 1.
12. The proceedings of every Chairperson elected by the council shall be
recorded in writing and submitted to the council.Andhra Pradesh Municipalities Act, 1965

