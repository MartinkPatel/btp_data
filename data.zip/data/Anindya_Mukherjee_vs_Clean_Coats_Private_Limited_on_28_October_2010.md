Anindya Mukherjee vs Clean Coats Private Limited on 28
October, 2010
Author: Anoop V. Mohta
Bench: Anoop V. Mohta
    ssm                                      1                          arbp.947.09.sxw
               IN THE  HIGH COURT OF JUDICATURE AT BOMBAY
                   ORDINARY ORIGINAL CIVIL JURISDICTION
                   ARBITRATION PETITION NO. 947  OF 2009
    Anindya Mukherjee
    C/o - Mrs. Kaberi Mukherjee,
    Flat No. C-2 Block - B,
    Malancha Apartment, 251,
    Pulin avenue, P.O. Rajbari,
    Kolkata 700 081                                     ....   Petitioner
                                                               (Orig. Respondent)
          Vs
    Clean Coats Private Limited,
    A private limited company incorporated
    under the Companies Act, 1956 and
    having its registered office at -Anindya Mukherjee vs Clean Coats Private Limited on 28 October, 2010

    122, Creative Industrial Premises,
    Sunder Nagar, Kalina,
    Mumbai - 400 098.                                      ....    Respondent.
                                                                   (Orig. Claimant)
    Mr. Sugandh Deshmukh for the petitioner.
    Mr. Tushar P. Gujjar i/by  M/s. Ashwin Ankhad & Co. for the Respondent. 
                            CORAM   :  ANOOP V. MOHTA, J.
          JUDGMENT RESERVED ON    :  27/09/2010.
          JUDGMENT DELIVERED ON  :  28/10/ 2010.
    JUDGMENT:
The Petitioner has challenged award dated 14th July, 2009, passed by ssm 2 arbp.947.09.sxw the
nominated sole Arbitrator, in view of an agreement dated 05/12/2007 (the agreement) between the
parties, under Section 34 of the Arbitration and Conciliation Act, 1996 (for short, the Arbitration
Act).
2 The operative part of the award is as under:-
"36. In the circumstances,
i) I direct the Respondent to pay Rs.9,40,167.50 towards liquidated damages to the
Claimant within 30 days from the date of publication of this order.
ii) As this amount has been crystallized only by this Award, I hold that the Claimant
is not entitled to any interest on the said damages up to the date of the Award.
iii) I further direct the Respondent to pay Rs.70,040/- to the Claimant towards salary
and other dues inclusive of interest @ 10% p.a. from 12th February, 2009 till the dateAnindya Mukherjee vs Clean Coats Private Limited on 28 October, 2010

of the Award.
iv) I further direct costs of the Arbitration be paid by the Respondent u/s. 31 of the
Act to the extent of Rs.
30,000/-.
37. Hence the total claims and costs payable by the Respondent to the Claimant comes to
Rs.10,40,207.50. I direct that the said amount be paid within 30 days from the date of publication of
this Award.
38. I further direct that in case the Respondent does not pay the aforesaid amount within 30 days as
directed, the Respondent is liable to pay interest to the Claimant on the ordered amount @ 18% p.a.
from the expiry of 30 days as aforesaid till payment, u/s. 31 of the Act.
39. This Award takes care of all the issues framed on 15th April, 2009. Issuewise answers are hence
not necessary."
     ssm                                              3                           arbp.947.09.sxw
    3      The basic events and particulars as per the Petition are as under:-
On 11/12/1999, the Petitioner being an expert in the field of marketing of coating, flooring and
concrete, joined as "SENIOR SALES EXECUTIVE" in Thortex Coating. The same company is
renamed now as Clean Coats Pvt. Ltd., the Respondent. On 01/04/2001, the Petitioner was
promoted as Assistant Project Manager of the Respondent and signed an agreement having
confidentiality and related clauses.
4 On 09/08/2006, the Petitioner was posted as Manager Project and Sales in Marketing
Department.
5 On 05/12/2007, both the parties signed an agreement having confidentiality and related penalty
and liquidated damage clauses. On 27/12/2006, the Respondent granted personal loan to the
Petitioner of Rs.1,50,000/- (Rupees one lac and fifty thousand only) with clause of 18% interest in
case the Petitioner leave the service before 5 years.
6 On 15/03/2008, the Petitioner resigned from the claimant Company.
7 On 13/06/2008, the Petitioner received a letter from the Respondent company dated 13th June,
2008 for settlement of accounts and again a communication by a fax in respect of full and finalAnindya Mukherjee vs Clean Coats Private Limited on 28 October, 2010

settlement for an ssm 4 arbp.947.09.sxw amount of Rs.67,238/- on 2nd December 2008.
8 On 03/12/2008, the Petitioner received a letter in respect of charges of breach of the alleged
agreement with a claim of damages of Rs.31.67 lakhs and intimating about the appointment of the
Arbitrator.
9 On 16/01/2009, the Petitioner received a communication of the minutes of the meeting held by
the Arbitrator thereby fixed the next date of hearing on 15th April, 2009 and a direction to deposit
Rs. 25,000/- within 28th February, 2009, as 50% of sitting fees of the Arbitrator.
10 On 20/02/2009, the Petitioner challenged the jurisdiction and validity of the agreement by
invoking Section 23 of the Indian Contract Act.
The same was rejected by the Arbitrator on 15/04/2009 and proceeded with the proceedings.
11 On 18/05/2009, the learned Arbitrator rejected the prayer of the Petitioner to supply the
necessary documents.
12 On 14/07/2009, the learned Arbitrator passed the impugned award in favour of the Claimants
Company and directed the Petitioner to pay an amount of Rs.10,40,207.50 and 18% interest thereon
after the expiry of 30 ssm 5 arbp.947.09.sxw days from the date of the order.
13 Both the parties have read and relied upon the agreed terms of the agreement dated 5th
December, 2007 which are as under:-
"1. The employee undertakes maintain confidentiality in all matters related to The
Company and its business and not to divulge or otherwise part with any technical or
commercial information related to the Company's products and services to any
outside party or organization, except as may be authorized to him/her by the
Company specifically to promote the business interests of the Company to approved
customers.
2. The Employee undertakes during the currency of employment to work full time
exclusively for the company and not to take up any parellel employment or
association of profit with any other organization engaged or interested in similar or
other business directly or indirectly during the period of his employment by The
Company and Twenty four months thereafter in the event of his resigning or
disassociating from the services of The Company.
3. In the event of the Employee ceasing to be in the employment of The Company
either by resignation or termination, he/she undertakes not to join or start a
competitive business in similar activities either directly or indirectly through friends,
relatives and associates or with anybody else, or part with any confidential
information as specified in the foregoing to any other organization engaged in similarAnindya Mukherjee vs Clean Coats Private Limited on 28 October, 2010

business for a minimum period of Twenty four months from the date of leaving the
organization.
4. In the event of breach of any of the terms and conditions set out in this agreement
by The Employee, The Company has the legal right to proceed against him/her as per
laws ssm 6 arbp.947.09.sxw of the land and claim liquidated damages of up to Rs.
10.00 Lakhs (Rupees Ten Lakhs only), the actual quantum of damages claimed would
however be decided at the sole discretion of The Company considering the
circumstances of the case. Mumbai courts will have the final jurisdiction in case of
dispute in this case.
5. Any disputes or difference arising under this agreement, if not settled amicably
shall be referred to a sole arbitration nominated by the CEO of the company. The
decision of such as arbitrator shall be final and binding on the Employee. The
arbitration shall be governed by the provisions of Indian Arbitration & Conciliation
act, 1996 and the venue of the arbitration shall be Mumbai."
                                  ig                       (Emphasis Added)
    14      It   is   necessary   to   have   a   clear   and   strict   interpretation   of   above 
negative and mandatory clauses, basically when the parties have agreed and acted
upon the same during the employment. The restriction was even extended after the
termination/expiry of the employment for 24 months.
The object and purpose of such clauses are quite clear from its contents itself.
15 In this global competitive and commercial world, various technical, business,
commercial, sensitive and financial information including confidential protected data
formulation including dealership network are very vital for running and developing
successful business. The data, material or information of the company including the
policy and market strategy, if any, need to be protected in all respect. It also means,
important ssm 7 arbp.947.09.sxw responsibility and the obligations on the employees
to protect vital information and/or data or material as collected and/or formed
and/or obtained by the employer. The importance of such data material needs to be
considered from the point of employer and its business interest and not only
employee's point of view. The national and international laws recognize importance
of such privacy and confidentiality. Such clauses are regular features of commercial
arrangements as it is based upon the trust, honesty and confidential relationship
between the parties. The concepts of "non-disclosure", "trade secrets" and
"confidentiality" therefore, need to be respected from the commerce as well as
outsourcings point of view.Anindya Mukherjee vs Clean Coats Private Limited on 28 October, 2010

16 Admittedly, the Petitioner re-signed and continued the services based upon the
agreement clauses in question dated 5th December, 2007. He resigned on even
without giving prior 60 days notice and joined the competitors. The Respondent,
therefore in view of Arbitration clauses raised claims on various heads against the
Petitioner, aggregating to sum of Rs.28.95 lacs with 18% interest thereon. The claims
based upon the breach of confidentiality, dues towards the company and the
customers and clients, non-receipt of "C" forms and miscellaneous damages.
17 As per the agreement clauses the Respondent was entitled to claim liquidate
damages up to Rs.10 lacs. The actual quantum of damages would ssm 8
arbp.947.09.sxw however be at the sole discretion of the company. Therefore, it is
clear that it is necessary for the Respondent to claim actual damages to substantiate
the same with material. Therefore, it is obligation of the Respondent to prove the
actual damages. The full and final settlement proposal given but was not accepted by
the Petitioner initially. The parties proceeded before the Arbitrator by filing
respective documents and materials and lead the evidence also.
The Arbitrator needs to consider the basic laws while assessing and granting any kind
of damages/ compensation. The Apex Court in the STATE OF RAJASTHAN & ANR.
VS. FERRO CONCRETE CONSTRUCTION PRIVATE LIMITED, (2009) 12 SCC 1,
has observed in paragraph No.55 as under:-
"55. While the quantum of evidence required to accept a claim may be a matter
within the exclusive jurisdiction of the arbitrator to decide, if there was no evidence
at all and if the arbitrator makes an award of the amount claimed in the claim
statement, merely on the basis of the claim statement without anything more, it has
to be held that the award on that account would be invalid. Suffice it to say that the
entire award under this head is wholly illegal and beyond the jurisdiction of the
arbitrator, and wholly unsustainable."
It is also necessary for the Arbitrator to decide firstly, whether the Defendant-Respondent is liable
for the damages or compensation and ssm 9 arbp.947.09.sxw thereafter to proceed to
assess/determine the quantum and/or liability. The interest on such determined or quantified
amount is also another aspect, depends upon the agreement between the parties, if any, otherwise, it
will be as per the provisions of Section 28/31 of the Act read with Section 34 of the Code of Civil
Procedure (for short, CPC).
19 The Respondent company by letter dated 3rd December, 2008 claimed damages of Rs.31.67 lacs
and appointed an Arbitrator, inspite of their communication/ fax dated 13th June, 2008/ 2nd
December, 2008, towards full and final settlement restricting to Rs.67,238/-. The Respondent even
denied the full and final settlement as referred in additional affidavit dated 11th April, 2009. The
Respondent-Company basically claimed loss of profit as the Petitioner joined the competitors'
Company within 24 months and disclosed the confidential material to them which resulted into loss
of business and profit to the company. Though there is no dispute that the Petitioner joined theAnindya Mukherjee vs Clean Coats Private Limited on 28 October, 2010

competitive company within 24 months by resigning from the Respondent-company, yet it is
necessary for the Respondent to prove the actual loss suffered by them only because of this conduct
of the Petitioner. Initially no details of claims were provided except the affidavit dated 30th April,
2009 in support of the claim. The statement of claims and the affidavit so filed were based upon the
internal memos and documents.
There were no material evidence and/or specification/ documents placed ssm 10 arbp.947.09.sxw
on record to show how many orders were managed to divert, by the Petitioner of the
Respondent-company. The loss to a particular contract/tender and/or loss to the business even if
any, depends upon the various aspects therefore, those factors unless brought on record by leading
independent witness to support the documents/ record/ affidavit, the liability so fasten upon the
Petitioner, in my view, is not correct. The detail Accounts and the Tax returns with supporting
material were not filed on record to show the said losses, if any. There is further no material on
record to show which and what role played by the Petitioner to divert the clients or the business of
the Respondent-company. Respective claims though raised referring to various companies and
claimed loss of business, yet no independent witness from the respective companies was examined
to support their case of loss in the year 2008-2009, which was well-known recession period
worldwide.
20 The challenge was raised by the Petitioner even to the agreement being null and void and
therefore, the power and the jurisdiction of the Arbitrator also. It was rightly rejected. In the
affidavit, the Respondent-
Company stated that they came to know at the first time on 5 th November, 2008 based upon the
internal communication dated 26th October, 2008, received from an officer of the Company Mr. A.
Vasudevan. The supporting material to the said communication are also not part of the record. Such
ssm 11 arbp.947.09.sxw internal communication, even if any, just cannot be the foundation to award
damages/ compensation for business loss as granted, though claims so raised is permissible. The
submissions that initially the Respondent-
claimant agreed for the final settlement and thereby waived/restricted their claim which they are
claiming now, under the clauses of the agreement in question, in my view, is also unsustainable, so
also the grant of award to the extent of Rs.10,40,207.50, in the present case.
Such clauses of confidentiality and/or non-disclosure or non-
competition need special attention in this world of global competition and outsourcing. It is very
important right and valuable asset of the owner of such trade secret or formula or information
and/or such material. There is no special and express statute in India, in this regard except such
agreements/ clauses governed by the law of contract in India and connected laws. I have elaborated
the aspect of Section 27 of the Contract Act referring to such covenants in Y.T. Entertainment
Limited Vs. One More Thought Entertainment Pvt. Ltd. & Ors., reported in 2009(6) Bom.C.R. 148,
as under:-Anindya Mukherjee vs Clean Coats Private Limited on 28 October, 2010

"9 Section 27 of the Indian Contract Act, 1872 provides as under :
"27. Agreement in restraint of trade, void.- Every agreement by which any one is
restrained from exercising a lawful profession, trade or business of ssm 12
arbp.947.09.sxw any kind, is to that extent void.
Exception 1.- Saving of agreement not to carry on business of which goodwill is sold.-
One who sells the goodwill of a business may agree with the buyer to refrain from
carrying on a similar business, within specified local limits, so long as the buyer, or
any person deriving title to the goodwill from him, carries on a like business therein,
provided that such limits appear to the Court reasonable, regard being had to the
nature of the business."
11 The submission with regard to the "Doctrine of Negative Covenant", based upon above Section, in
the facts and circumstances of the case, in no way sufficient to overlook the case of the petitioner.
The Doctrine of Negative Covenant cannot be extended blindly in each and every case, where the
parties knowing fully the principle behind the Doctrine, incorporate those provisions/clauses and
when it comes to payment, the defaulted party invokes the Doctrine to use as a shelter/umbrella to
avoid the obligations. The commercial transaction like this where the parties entered into the
contract of production of the film & having once obtained the benefits arising out of the finances so
received, just cannot be allowed to turn around to say that in view of the said Doctrine, no order
should be passed against them.
12 In my view, this Section cannot be interpreted or extended to assist a defaulted person/party and
specially in the present facts and circumstances of the case. There is nothing in this clause or section
to direct the parties to comply with agreed clauses and to pay the agreed amount or at least to secure
the same. Section 27 of the Contract Act just cannot be extended blindly in each and every case
merely because such clause is mentioned in the Agreement. Any direction and/or order to make the
payment of agreed amount against any person, in my view, cannot be said to be granting any order
of restrainment of trade or a lawful profession, trade or business. They can do or continue with their
business or trade but subject to agreed payment."
Such covenants/agreements revolving around and to protect the concept of confidentiality trade
secret are legally accepted mode even in India.
     ssm                                                 13                           arbp.947.09.sxw
    22      The submission that such agreement/ contract is null and void and 
    got   signed   coercively,   is   unacceptable.     Knowing   fully   the   effect   of   such Anindya Mukherjee vs Clean Coats Private Limited on 28 October, 2010

clauses, the Petitioner signed the same and acted accordingly. It is settled that such permissible
commercial agreements are binding to both the parties in all respect. In the present case, the full
and final settlement forwarded by the claimant vide letter dated 13th June, 2008, which the learned
counsel appearing for the Petitioner now ready and willing to accept the same. The learned
arbitrator, therefore, right in rejecting the said submission. The decision so given by the arbitrator is
well within his power and jurisdiction under the Act.
23 I am of the view that if the employee and employer relationship, considering the business and
trade, such agreement/ covenant has always element of commerce and business. It is not just a
simple employment agreement. Therefore, to say that such agreement is one sided or unfair or
unreasonable is unacceptable. Both the parties are bound of such terms and conditions in all
respect. Any breach of such clauses on the part of employee, in given case, can also be treated as
misconduct. The employer may take action by taking steps in accordance with law, apart from a
claim of damages or penalty.
     ssm                                             14                          arbp.947.09.sxw
    24     It is relevant to note the English Judges' observation on the concept 
of confidential information as under. [(1985) 1 All ER 724, Faccenda Chicken Ltd Vs. Fowler and
Ors.] [Saltman Engineering Co. Ltd. Vs. Compbell Engineering Co. Ltd. (1963) 3 All ER 413 "On the
other hand, it is perfectly possible to have a confidential document, be it a formula, a plan, a sketch,
or something of that kind, which is the result of work done by the maker on materials which may be
available for the use of anybody; but what makes it confidential is the fact that the maker of the
document has used his brain and thus produced a result which can only be produced by somebody
who goes through the same process."
25 In the present case, the Petitioner admittedly after resignation, working for the competitor. The
possibility of using the client lists and confidential information just cannot be ruled out. Though,
there is no direct evidence on record but in view of above admitted breach and facts and
circumstances itself, I am of the view that the Petitioner is liable to pay lump sum damages/
compensation of Rs.1 lacs instead of Rs.9,40,167.50, as awarded, specially when the Petitioner at the
relevant time admittedly working with the competitor. It is clear breach of the agreed clauses as
confidential information/ data must had traversed out of the private domain to the competitor's
domain through the Petitioner. The sufferer needs to be compensated in view of the admitted breach
itself.Anindya Mukherjee vs Clean Coats Private Limited on 28 October, 2010

     ssm                                             15                          arbp.947.09.sxw
    26     The Arbitrator has relied upon the company's brochure to prove that 
the Petitioner worked with a competitor and various memos dated 26th October and 10th
November, 2008 from Mr. P.K. Chandran and Chartered Accountant's certificate showing the losses
in the year 2008-2009 compared to the year 2007-2008. The Arbitrator also relied upon the list of
clients with whom the Respondent used to deal with while in the employment with the claimant. As
noted above, though the Petitioner had accessed to technical and commercial information including
clients' list and pricing, yet unless it is proved and supported by the documents that only because of
this conduct of the Petitioner, the Respondent company had lost orders of various clients and
thereby suffered loss of Rs. 31 lakhs so claimed. So far as the award of Rs.70,040/- and other dues
from February, 2009 till the date of award @ 10% is maintained, in view of observation made in
paragraph No.31 of the award.
27 The element of breach of confidential information with other elements of loss of profit and/or
loss just cannot be overlooked. The material to support the loss of profit of the company, though
placed on record, but not fully supported by any substantial material/ evidence, still the Arbitrator
restricted the amount below Rs.10 lacs in view of clause of the agreement. In my view, out of which
at least 10% to 20% such action/ conduct of Petitioner, contributed to loss of profit to the
Respondent ssm 16 arbp.947.09.sxw company. I am therefore, restricting it to 10% of the amount so
awarded by the Arbitrator i.e. Rs. 9,40,167/-. However, rounding it to Rs.1,00,000/-
(Rupees one lakh only).
28 As there is legal injury, it should be compensated. Therefore, I am inclined to grant lump sum
liquidated damages/ compensation of Rs.1,00,000/- instead of Rs.9,40,167.50. Therefore, total
claims and costs payable by the Petitioner-Original Respondent, to the Respondent-
Company comes to Rs. 1,00,000/- towards liquidated damages/compensation Rs. 70,040/- towards
the Salary and other dues with interest; and Rs.30,000/- towards the costs. Therefore, total claims
and costs payable by the Petitioner comes to Rs. 2,00,040/- in place of Rs. 10,40,207.50. This
amount is further subject to 18% p.a. future interest from 14th August, 2009 i.e. 30 days after
impugned award dated 14th July, 2009, till realization.
29 The order of costs as awarded is also maintained.
30 The award is modified accordingly.
31 The Petition is accordingly partly allowed with no order as to costs.Anindya Mukherjee vs Clean Coats Private Limited on 28 October, 2010

(ANOOP V. MOHTA, J.)Anindya Mukherjee vs Clean Coats Private Limited on 28 October, 2010

