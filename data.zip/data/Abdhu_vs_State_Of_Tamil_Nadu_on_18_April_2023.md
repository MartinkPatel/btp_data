Abdhu vs State Of Tamil Nadu on 18 April, 2023
Bench: M.Sundar, M.Nirmal Kumar
                                                                                H.C.P.No.2108 of 2022
                                  IN THE HIGH COURT OF JUDICATURE AT MADRAS
                                              DATED : 18.04.2023
                                                    CORAM
                               THE HONOURABLE MR.JUSTICE M.SUNDAR
                                                and
                           THE HONOURABLE MR.JUSTICE M.NIRMAL KUMAR
                                        H.C.P.No.2108 of 2022
                 Abdhu,
                 S/o.Mohamed                                       ... Petitioner/detenu
                                                     Versus
                 1.State of Tamil Nadu, represented by,
                   The Additional Chief Secretary to Government,
                   Department of Home, Prohibition and Excise,
                   Secretariat, Fort St.George,
                   Chennai-600 009.
                 2.The District Magistrate & District Collector,
                   Office of the District Collector,
                   Nilagiri District.
                 3.The Inspector of Police,
                   All Women's Police Station,
                   Devala, Nilagiri District.
                 4.The Superintendent of Police,
                   Central Prison,
                   Coimbatore.
                 5.The Superintendent of Police,
                   Nilagiri District.                                    ... Respondents
                 Page No.1/10
https://www.mhc.tn.gov.in/judis
                                                                                      H.C.P.No.2108 of 2022Abdhu vs State Of Tamil Nadu on 18 April, 2023

                           Petition filed under Article 226 of the Constitution of India praying for
                 issuance of a Writ of Habeas Corpus to call for records pertaining to the order
                 of detention passed by the 2nd respondent in No.Cr.M.P.No.3(Sexual
                 Offender)/2022 dated 19.04.2022 detaining me as a Sexual Offender as
                 defined under section 2(ggg) of Act 14/1982 and set aside the impugned order
                 of detention passed under the Tamil Nadu Act 14 of 1982 and direct the
                 respondents to produce the body of the detenu, namely, Abdhu, M/A-47 years,
                 son of Mohamed, Indian resident of Panthalur Hatti, Nelliyalam Post,
                 Panthalur Taluk, Nilgiris District now confirmed in Central Prison,
                 Coimbatore before this Court and set him at liberty.
                           For Petitioner       :      Mr.H.Maruthi Raj for
                                                       Mr.C.S.S.Pillai
                           For Respondents :           Mr.R.Muniyapparaj,
                                                       Additional Public Prosecutor assisted by
                                                       Mr.M.Sylvestor John, Advocate
                                                         ORDER
[Order of the Court was made by M.NIRMAL KUMAR, J.] Captioned 'Habeas Corpus Petition'
[hereinafter 'HCP' for the sake of convenience and brevity] has been filed by the detenu assailing
'detention order dated 19.04.2022 bearing reference Cr.M.P.No.03(Sexual Offender)/2022'
[hereinafter 'impugned detention order' for the sake of convenience]. To be noted, the third
respondent is the sponsoring authority https://www.mhc.tn.gov.in/judis and the second respondent
is the detaining authority as impugned detention order has been made by the second respondent.
2.Impugned detention order has been made under 'The Tamil Nadu Prevention of Dangerous
Activities of Bootleggers, Cyber law offenders, Drug-offenders, Forest-offenders, Goondas, Immoral
traffic offenders, Sand- offenders, Sexual-offenders, Slum-grabbers and Video Pirates Act, 1982
(Tamil Nadu Act No.14 of 1982)' [hereinafter 'Act 14 of 1982' for the sake of convenience and clarity]
on the premise that the detenu is a 'Sexual Offender' within the meaning of Section 2(ggg) of Act 14
of 1982.
3.There is no adverse case. The ground case which is the sole substratum of the impugned detention
order is Crime No.3 of 2022 on the file of Devala All Woman Police Station for alleged offences
under Section 328 and 506(1) of 'The Indian Penal Code (45 of 1860)' [hereinafter 'IPC' for the sake
of convenience and clarity] and Sections 5(1), 5(n) and 5(j)(ii) of 'Protection of Children from Sexual
Offences Act, 2012' [hereinafter 'POCSO' for the sake of convenience and clarity]. Owing to the
nature of the challenge to the impugned detention order, it is not necessary to delve into the factual
https://www.mhc.tn.gov.in/judis matrix or be detained further by facts.
4.Mr.H.Maruthi Raj, learned counsel representing the counsel on record for petitioner and
Mr.R.Muniyapparaj, learned Additional Public Prosecutor assisted by Mr.M.Sylvester John learned
counsel for all respondents are before us.Abdhu vs State Of Tamil Nadu on 18 April, 2023

5.The learned counsel for the petitioner raised several grounds attacking the Detention Order, but
laid stress on grounds L, M and U, which were raised in this petition questioning the subjective
satisfaction of the Detaining Authority, since the petitioner not filed bail petition, the real possibility
of coming out on bail does not arise, further the similar case relied by the Detaining Authority is not
similar.
6.The learned Additional Public Prosecutor submitted that the petitioner's contention to be rejected
for the reason that the Detaining Authority finding the nature of offence and its impact on the
society, its likelihood of disturbing public order, clamped Detention Order against the detenu.
https://www.mhc.tn.gov.in/judis
7.This Court considered the rival submissions and perused the materials available on record.
8.The ground (L) raised by the petitioner is to effect that the Detaining Authority had relied on the
bail granted in a similar case in C.M.P.No.816 of 2019, dated 18.11.2019 to infer there is a real
possibility of detenu coming out on bail. In the Detention Order, the same is referred in page 12 in
para 6, which is as follows:-
“6) .............................. In a similar case registered at Nilgiris District, Gudalur Police
Station Crime No.06/2019 under Section 5(j)(ii), 5(l)(n), 6 Prevention of Children
from Sexual Offences Act, 2012 and Section 506(i) Indian Penal Code, bail was
granted to the accused Mohan @ Kuttan by the Court of District Sessions and Fast
Track Mahila Judge, Udhagamandalam in Crl.M.P.No.816/2019 dated
18.11.2019........................” The similar bail order finds place in the booklet at page 73.
On perusal of the same, it is found that the present case against the detenu is for
offence under https://www.mhc.tn.gov.in/judis Sections 328 and 506(i) of IPC and
Sections 5(l), 5(n) and 5(j)(ii) of POCSO Act. In the similar case, the offences are
under Sections 5(j)(ii), 5(l), 5(n) and 6 of the POCSO Act. The IPC offences of
Sections 328 and 506(i) of IPC are found missing. Further, considering the period of
detention of 60 days, investigation completed, bail was granted in the similar case.
Hence, it cannot be said both the cases are similar in nature.
9.For point raised in ground (M), it is submitted that no bail application was filed by the
petitioner/detenu. The Sponsoring Authority confirms the petitioner/detenu had not filed any bail
petition, but presumes that the petitioner/detenu might come out on bail by filing bail petition
before the appropriate Court, which has been considered by the Detaining Authority and Detention
Order passed based on mere presumption, which is as follows:-
“6) .................Hence, I presume that there is a real possibility of the accused
Thiru.Abdhu coming out on bail by filing bail petition before the appropriate
Court..........................” In the absence of any material to show detenu relatives taking
steps to file bail petition, such presumption is not sustainable and that would surely
vitiate the Detention Order. In an identical situation, in a case decided by aAbdhu vs State Of Tamil Nadu on 18 April, 2023

https://www.mhc.tn.gov.in/judis Hon'ble Division Bench of this Court in “Kavitha
Velmurugan Versus The Secretary to Government of Tamil Nadu, Home, Prohibition
& Excise Department, Fort St.George, Chennai-600 009 reported in
MANU/TN/2804/2018” to which one of us was a party (Nirmal Kumar.J.,), wherein
it had held that there is lack of subjective satisfaction by the Detaining Authority at
the time of passing the Detention Order with regard to possibility of detenu coming
out on bail. The relevant portion of Kavitha Velmurugan case is extracted hereunder:-
“52.Be that as it may, in view of the fact that in respect of the ground case in Crime
No.458/2017 under Section 395 read with 397 I.P.C., no bail application admittedly
was filed on behalf of the detenu and in the absence of tangible materials to show
before this Court that even though the detenu is not filing bail applications, his
relatives takes place to file bail application before the appropriate Court, there is
absence of subjective satisfaction about the possibility of the detenu coming out on
bail and in this regard, there is lack of subjective satisfaction by the Detaining
Authority at the time of passing the detention order dated 18.12.2017 and on this
score, this Court set asides the detention order dated 18.12.2017 to prevent an
aberration of Justice and to promote substantial cause of Justice.”
https://www.mhc.tn.gov.in/judis
10.As regards the point raised in ground (U), it is seen that in the Detention Order at page 14 in para
7, it is mentioned that the petitioner/detenu has a right to make representation to the Chairman,
Advisory Board through the Superintendent, Borstal School, Pudhukottai. In this case, admittedly,
the petitioner/detenu is a major aged about 47 years, he is confined in Central Prison, Coimbatore.
The Additional Public Prosecutor has nothing to say since in the Detention Order it is mentioned
wrongly. This clearly shows the non-application of mind by the Detaining Authority.
11.Further, right of the detenu to make an effective representation qua the preventive detention
order is a Constitutional safeguard ingrained in Clause (5) of Article 22 of the Constitution of India.
In the light of the narrative thus far, this Constitutional safeguard is hampered. Therefore, we have
no difficulty in coming to the conclusion that the subjective satisfaction arrived at by the Detaining
Authority is impaired. The sequitur is, the impugned preventive detention order deserves to be
dislodged. https://www.mhc.tn.gov.in/judis
12.Ergo, the sequitur is, captioned HCP is allowed and impugned detention order dated 19.04.2022
bearing reference Cr.M.P.No.3(Sexual Offender)/2022 made by the second respondent is set aside
and the detenu Thiru.Abdhu, aged 47 years, son of Thiru.Mohammed is directed to be set at liberty
forthwith unless required in connection with any other case. There shall be no order as to costs.
                                                                   (M.S.,J.)     (M.N.K.,J.)
                                                                          18.04.2023
                 Index: Yes
                 Speaking
                 Neutral Citation: Yes / No
                 rsiAbdhu vs State Of Tamil Nadu on 18 April, 2023

P.S: Registry to forthwith communicate this order to Jail authorities in Central Prison, Coimbatore.
To
1.The Additional Chief Secretary to Government, Department of Home, Prohibition and Excise,
Secretariat, Fort St.George, Chennai-600 009.
2.The District Magistrate & District Collector, Office of the District Collector, Nilagiri District.
https://www.mhc.tn.gov.in/judis M.SUNDAR, J.
and M.NIRMAL KUMAR, J.
3.The Inspector of Police, All Women's Police Station, Devala, Nilagiri District.
4.The Superintendent of Police, Central Prison, Coimbatore.
5.The Superintendent of Police, Nilagiri District.
6.The Public Prosecutor, High Court of Madras, Chennai – 104.
18.04.2023 https://www.mhc.tn.gov.in/judisAbdhu vs State Of Tamil Nadu on 18 April, 2023

