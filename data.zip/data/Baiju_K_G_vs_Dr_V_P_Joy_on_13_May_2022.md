Baiju K.G vs Dr. V. P. Joy on 13 May, 2022
Author: D.Y. Chandrachud
Bench: Surya Kant, Dhananjaya Y Chandrachud
     CP(C) 244/2021
                                                          1
                                                                                    Reportable
                                       IN THE SUPREME COURT OF INDIA
                                           INHERENT JURISDICTION
                                    Contempt Petition (Civil) No 244 of 2021
                                                          in
                                       Writ Petition (Civil) No 213 of 2011
     Baiju K G & Ors                                                           ... Petitioner(s)
                                                    Versus
     Dr V P Joy                                                                ... Respondent(s)
                                                    JUDGMENT
Dr Dhananjaya Y Chandrachud, J 1 A contempt petition has been instituted before this Court by the
residents of Kasargod district in Kerala who were affected by the use of a toxic pesticide called
Endosulfan. The use of the pesticide led to a spread of mental and physical ailments among
residents of areas that were impacted by its use. A writ petition was instituted before this Court by
the persons affected by the CP(C) 244/2021 the State Governments to compensate all the affected
persons by distributing an amount of Rs 5 lakhs to each affected person within three months. This
Court also directed the State Governments to consider the feasibility of providing medical facilities
and treatment for life-long ailments arising from the effects of Endosulfan, considering the larger
number of affected persons. It is submitted by the petitioners, whose names are mentioned in the
list of Endosulfan victims prepared by the Government of Kerala, that the Government has failed to
comply with the order. The petitioners are yet to be compensated and the medical facilities have not
been improved because of which the affected persons in Kasargod District are compelled to travel to
Trivandrum, about 600 kms away for their treatment.Baiju K.G vs Dr. V. P. Joy on 13 May, 2022

2 A compliance report dated 9 May 2022 has been filed by the Chief Secretary to the Government of
Kerala. The report indicates that on 16 March 2022, the Chief Secretary convened a meeting in
connection with the need for disbursing compensation to the victims of Endosulfan, in compliance
with the judgment of this Court dated 10 January 2017. A team of officials from the Health and
Revenue departments has been constituted to visit the homes of 3704 victims to whom
compensation is yet to be provided. Of these victims, 102 are found to be bedridden, 326 to be
mentally disabled, 201 to be physically disabled, 119 to be afflicted with cancer while 2966 fall in the
residual category. The Government of Kerala has done virtually nothing for five years. Besides the
fact that the delay is appalling, the inaction is in CP(C) 244/2021 breach of the orders of this court.
3 The State Government has now taken a decision on 15 January 2022 by issuing GO(Rt) No
1877/2022/Fin to authorize the disbursal of an additional amount of Rs 200 crores for providing
compensation to the victims of Endosulfan. As of date, an amount of Rs 5 lakhs has been disbursed
only to eight persons who are the petitioners who have moved these contempt proceedings. We fail
to understand the logic or the rationale of the State Government in disbursing compensation only to
those who have the ability to move this Court.
4 There are a large number of victims to whom no compensation has been provided despite the
passage of over five years since the date of the judgment of this Court. Most of the victims, as the
data before the Court indicates, are from the marginalized segments of society. Many of the victims
are in a serious condition to whom compensation on an urgent basis has to be provided. In Nilabati
Behera v. State of Orissa1, this Court had discussed the basis of awarding compensation in public
law proceedings. This Court had observed that the onus of a public wrong can be attributed to the
State if it fails to protect the fundamental rights of the citizenry and compensation can be awarded
in such cases. Justice AS Anand in his concurring opinion had observed that:
“34. The public law proceedings serve a different purpose than the private law
proceedings. The relief of monetary 1 (1993) 2 SCC 746 CP(C) 244/2021
compensation, as exemplary damages, in proceedings under Article 32 by this Court
or under Article 226 by the High Courts, for established infringement of the
indefeasible right guaranteed under Article 21 of the Constitution is a remedy
available in public law and is based on the strict liability for contravention of the
guaranteed basic and indefeasible rights of the citizen.
The purpose of public law is not only to civilize public power but also to assure the citizen that they
live under a legal system which aims to protect their interests and preserve their rights. Therefore,
when the court moulds the relief by granting “compensation” in proceedings under Article 32 or 226
of the Constitution seeking enforcement or protection of fundamental rights, it does so under the
public law by way of penalising the wrongdoer and fixing the liability for the public wrong on the
State which has failed in its public duty to protect the fundamental rights of the citizen. The
payment of compensation in such cases is not to be understood, as it is generally understood in a
civil action for damages under the private law but in the broader sense of providing relief by an
order of making ‘monetary amends’ under the public law for the wrong done due to breach of public
duty, of not protecting the fundamental rights of the citizen. The compensation is in the nature ofBaiju K.G vs Dr. V. P. Joy on 13 May, 2022

‘exemplary damages’ awarded against the wrongdoer for the breach of its public law duty and is
independent of the rights available to the aggrieved party to claim compensation under the private
law in an action based on tort, through a suit instituted in a court of competent jurisdiction or/and
prosecute the offender under the penal law.
35. This Court and the High Courts, being the protectors of the civil liberties of the citizen, have not
only the power and jurisdiction but also an obligation to grant relief in exercise of its jurisdiction
under Articles 32 and 226 of the Constitution to the victim or the heir of the victim whose
fundamental rights under Article 21 of the Constitution of India are established to have been
flagrantly infringed by calling upon the State to repair the damage done by its officers to the
fundamental rights of the citizen, notwithstanding the right of the citizen to the CP(C) 244/2021
remedy by way of a civil suit or criminal proceedings…” (emphasis supplied) The inordinate delay by
the State Government in compensating the persons affected by the use of Endosulfan not only
reflects its failure to comply with the order of this Court but also further compounds the violation of
the fundamental rights of such persons. The failure to redress the infringement of their fundamental
rights becomes more egregious with each passing day. 5 That apart, in the order of this Court dated
10 January 2017, the State Government was directed to consider the feasibility of providing medical
facilities or treatment to deal with life-long health issues arising out of the effects of Endosulfan,
particularly having regard to the large number of persons involved. The State Government has not
disclosed what steps it has taken to provide for medical treatment and rehabilitation to these
victims. The right to health is an integral part of the right to life under Article 21 of the Constitution.
Without health, the faculties of living have little meaning. We would be justified in taking recourse
to the coercive arm of law. However, our immediate concern is providing relief and rehabilitation to
the victims who are suffering. We accordingly issue the following directions:
(i) Since the payment of compensation has been made, though belatedly to eight
petitioners who have moved these proceedings, costs quantified at Rs 50,000 each
shall be paid over in addition to each of the eight persons within a period of three
weeks from the date of this CP(C) 244/2021 order;
(ii) The Chief Secretary shall hold monthly meetings to ensure that the judgment of
this Court dated 10 January 2017 is diligently implemented by undertaking the
process of (a) identifying the victims of Endosulfan and drawing up a list of
beneficiaries; (b) ensuring the disbursement of compensation of Rs 5 lakhs to each of
the victims; and (c) taking steps for ensuring due medical facilities within reasonable
distance from their places of residence in terms of the earlier directions of this Court.
(iii) An affidavit of compliance shall be filed before this Court indicating the progress
which has been made between the date of this order and the next date of listing.
6 List the Contempt Petition on 18 July 2022.
…………...…...….......………………........J. [Dr Dhananjaya Y Chandrachud]
…..…..…....…........……………….…........J. [Surya Kant] New Delhi;Baiju K.G vs Dr. V. P. Joy on 13 May, 2022

May 13, 2022
CKB
CP(C) 244/2021
ITEM NO.29                          COURT NO.4                          SECTION PIL-W
                     S U P R E M E C O U R T O F I N D I A
                               RECORD OF PROCEEDINGS
CONMT.PET.(C) No.244/2021 in W.P.(C) No.213/2011 BAIJU K.G & ORS. Petitioner(s) VERSUS
DR. V.P. JOY Respondent(s) (With IA No.30400/2021 - EXEMPTION FROM FILING O.T.) Date :
13-05-2022 These matters were called on for hearing today. CORAM :
HON'BLE DR. JUSTICE D.Y. CHANDRACHUD HON'BLE MR. JUSTICE SURYA
KANT For Petitioner(s) Mr. P.N. Ravindran, Sr. Adv.
Mr. P.S. Sudheer, AOR Mr. Rishi Maheshwari, Adv.
Ms. Shruti Jose, Adv.
Mr. Bharat Sood, Adv.
For Respondent(s) Mr. Nishe Rajen Shonker, AOR Mrs. Anu K. Joy, Adv.
Mr. Alim Anvar, Adv.
UPON hearing the counsel the Court made the following O R D E R 1 In terms of the
signed reportable judgment, the following directions are issued:
CP(C) 244/2021
(i) Since the payment of compensation has been made, though belatedly to eight
petitioners who have moved these proceedings, costs quantified at Rs 50,000 each
shall be paid over in addition to each of the eight persons within a period of three
weeks from the date of this order;
(ii) The Chief Secretary shall hold monthly meetings to ensure that the judgment of
this Court dated 10 January 2017 is diligently implemented by undertaking the
process of (a) identifying the victims of Endosulfan and drawing up a list of
beneficiaries; (b) ensuring the disbursement of compensation of Rs 5 lakhs to each of
the victims; and (c) taking steps for ensuring due medical facilities within reasonable
distance from their places of residence in terms of the earlier directions of this Court.Baiju K.G vs Dr. V. P. Joy on 13 May, 2022

(iii) An affidavit of compliance shall be filed before this Court indicating the progress
which has been made between the date of this order and the next date of listing.
2 List the Contempt Petition on 18 July 2022.
                  (CHETAN KUMAR)                (SAROJ KUMARI GAUR)
                   A.R.-cum-P.S.                   Court Master
(Signed reportable judgment is placed on the file)Baiju K.G vs Dr. V. P. Joy on 13 May, 2022

