Andhra Pradesh Panchayat Raj Act, 1994
ANDHRA PRADESH
India
Andhra Pradesh Panchayat Raj Act, 1994
Act 13 of 1994
Published on 22 December 1998• 
Commenced on 22 December 1998• 
[This is the version of this document from 22 December 1998.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
Andhra Pradesh Panchayat Raj Act, 1994(Andhra Pradesh Act No. 13 of 1994)Last Updated 26th
October, 2019Statement of Objects and Reasons. - In the recent past, incidents have been reported
that certain stray dogs have become furious and attacking the animals and human beings especially
children and injuring them. There was one gruesome incident where a group of dogs attacked and
killed a 6 years old girl in Guntur District. Section 92 of the Andhra Pradesh Panchayat Raj Act,
1994 empowers the District Magistrate to order destroying of stray pigs or dogs. However the
Animal Birth Control (Dogs) Rules, 2001 issued under the provisions of the Prevention of Cruelty to
Animals Act, 1960 provide certain provisions to deal with this kind of furious and attacking dogs.To
prevent the infliction of unnecessary pain or suffering on animals especially dogs or pigs it is
proposed to delegate the power of the District Collector to Gram Panchayat to control and
administer furious stray dogs or pigs.Therefore, the Government have decided to suitable
amendment to the Andhra Pradesh Panchayat Raj Act, 1994 to delegate the powers of the District
Collector a respect of control and administer stray dogs or pigs to the Gram Panchayats.This Bill
seeks to give effect to the above decision.Received the assent of the Governor on the 4th January,
2018 and the said assent is hereby first published on the 9th January, 2018 in the Andhra Pradesh
Gazette for general information:Statement of Objects and Reasons - (Act No. 33 of 1998). - Under
Article 243 K of the Constitution of India read with sub-section (1) of Section 200 of the Andhra
Pradesh Panchayat Raj Act, 1994 (Act No. 13 of 1994), State Election Commission has been
constituted for the superintendence, direction and control of the preparation of electroral rolls for,
and the conduct of elections to all the Panchayat Raj Institutions governed by this Act.The
Government of India, Ministry of Law & Justice have stated that the Chief Election Commissioner of
India has brought to their notice that the State Election Commissions every where as only called as
ti t e Election Commission which results in confusion amongst public and even in the press
regarding the role and position of various State Election Commission and the Election Commission
of India. They have, therefore, advised to change the nomenclature of State Election Commissions to
avoid confusion between the two Election Commissions, one at national level and others at State
level. Accordingly, the Government have decided to change the nomenclature of the State Election
Commission and the State Election Commissioner as "Andhra Pradesh Election Commission for
Local Bodies" and Andhra Pradesh Election Commissioner for Local Bodies respectively byAndhra Pradesh Panchayat Raj Act, 1994

amending the Andhra Pradesh Panchayat Raj Act, 1994 suitably.Further It is noticed that in some
Gram Panchayats, the Ex-Sarpanches (Persons-in-Charge) have not handed over the records of the
Gram Panchayats to the newly elected Sarpanches in the Elections held during June, 1995. There is
no specific provision in the Andhra Pradesh Panchayat Raj Act, 1994 to lake necessary action against
those who have not handed over the records to the newly elected Sarpanches as in Section 221 of the
repealed Andhra Pradesh Gram Panchayats Act, 1964 which-empowered the Government to take
action against the concerned ex-Sarpanches who have not handed over the charge and records of the
Gram Panchayats to the newly elected Sarpanches.It has also been decided that they should
handover the documents, moneys or other properties within a period of thirty days and on failure to
do so, they shall be punishable with imprisonment which may extend upto six months or with fine
not exceeding two hundred and fifty rupees or with both for every such offence.Accordingly, it has
been decided to amend the Andhra Pradesh Panchayat Raj Act, 1994 suitably by inserting a new
Section 271-A after Section 271 on the lines of Section 221 of the repealed Andhra Pradesh Gram
Panchayats Act 1964.The Bill seeks to achieve the above objectives.Statement of Objects and
Reasons - (Act No. 7 of 2000). - Article 334 of Constitution of India providing for reservation of
seats to the Scheduled Castes, Scheduled Tribes and Anglo Indian Community in the House of
people and in the legislative Assemblies of the States ceases to have effect from 26th January, 2000
and under Article 243-D of the Constitution, the reservation of seats to the Scheduled Castes and
Scheduled Tribes in the Panchayat Raj Institutions shall cease to have effect on the expiration of the
period specified in Article 334. Section 203 of the Andhra Pradesh Panchayat Raj Act, 1994
accordingly provided for such reservations to cease after 25th January, 2000.However, the
Government of India have introduced a Constitution (Amendment) Bill in the Parliament for
extending the reservations for a further period of ten years. To bring the reservations for Scheduled
Tribes in the Panchayat Raj Institutions in the State, in conformity with the provisions of the
Constitution, as amended from time to time, it has been decided to amend Section 203 of the
Andhra Pradesh Panchayat Raj Act, 1994 to continue the reservations so long as they are provided
by Article 334 of the Constitution.This Bill seeks to give effect to the above decision.Appended to
L.A.Bill No. 16 of 1999.Statement of Objects and Reasons - (Act No. 8 of 2000). - Section 245 of the
Andhra Pradesh Panchayat Raj Act, 1994, provides for motion of no confidence in Upa-Sarpanch,
President or Vice-President or Chair-Person or the Vice-Chair persons of the Gram Panchayat,
[Mandal Praja Parishad] or [Zilla Praja Parishad], as the case may be, and the motion shall be
carried with the support of not less than two-thirds of the total number oi members. According to
the explanation to Rule 6 of the Rules issued thereunder while determining two-thirds of the total
number of members, any fraction below 0.5 and above shall be taken as one.The later part of the
explanation that any fraction of more than 0.5 should be considered as one, is quite valid as it
ensures the minimum statutory requirements of two-thirds majority and the previous part of the
explanation that any fraction below 0.5 should be ignored, is considered violative of Section 245 (2)
of the Act. This is creating legal complications and unnecessary litigation's. In order to put the
matter beyond any doubt, it has been decided to suitably amend Section 245 (2) of the Andhra
Pradesh Panchayat Raj Act with retrospective effect from 28-4-98.As the Legislative Assembly of the
State was not then in session and it has been decided to give effect to the above decision
immediately, the Andhra Pradesh Panchayat Raj (Second Amendment) Ordinance, 2000 (A.P.
Ordinance 5 of 2000) has been promulgated by the Governor on the 5th February, 2000.This Bill
seeks to replace the said Ordinance.Appended to L.A.Bill 4 of 2000.Statement of Objects andAndhra Pradesh Panchayat Raj Act, 1994

Reasons - (26 of 2000). - Section 2 of the Andhra Pradesh Panchayat Raj Act, 1994 contemplates
two qualifying dates, namely 1st January and 1st July of the year for preparation and publication of
the electoral rolls resulting in not only additional work but huge expenditure to the State Exchequer.
In order to adopt the Assembly Electoral Roll without any further exercise like draft publication and
final publication, it is proposed to amend the qualifying date as first January of the year for the
purpose of Panchayat Raj Elections.A person convicted for an election offence punishable under
Chapter II of Part V of the Act shall be disqualified from being elected at any election held under the
Act for a period of six years from the date of conviction. It is felt that persons who are convicted of
any offence punishable under Chapter IX A of the IPC, persons who are guilty of corrupt practices
and those who fail to file the account of election expenses should also be brought within the purview
of disqualifications. It is, therefore, proposed that disqualification should be for contesting in the
election.It is also proposed to use Electronic Voting Machines in the Panchayat Raj Elections.To
conduct fair elections to local bodies requires the candidates to keep their expenses within the
ceiling limit, maintain proper accounts of expenditure and also to file an account of election
expenses. The model Code of conduct is non-statutory in nature and is not capable of being
enforced. Therefore, it is proposed that provisions similar to those contained in Representation of
People Act, 1951 relating to maintenance of account of election expenses and also for the lodging of
account of election expenses with the District Election Authority should also be included in the
Andhra Pradesh Panchayat Raj Act, 1994 in order to enforce the ceiling on election expenditure as
otherwise it will not be possible to control money power in Panchayat Raj Elections.As the Legislate
Assembly of the State was not then in session having been prorogued, and it has been felt necessary
to give effect to the above decision, immediately, the Andhra Pradesh Panchayat Raj (Third
Amendment) Ordinance, 2000 (A. P. Ordinance 9 of 2000) was promulgated by the Governor on
the 31st July, 2000.Appended L.A. Bill No. 30 of 2000.This Act of the Andhra Pradesh Legislative
Assembly which was reserved by the Governor on the 15th April, 1994 for the consideration and
assent of the President of India, received the assent of the President on the 21st April, 1994 and first
published in the Andhra Pradesh Gazette, Part IV-B, Extraordinary No. 13, on April 22, 1994.An Act
to provide for the constitution of Gram Panchayats, [Mandal Praja Parishads] [Substituted 'Mandal
Parishads' by Act No. 41 of 2006, dated 23.9.2006.] and [Zilla Praja Parishad] [Substituted 'Zilla
Parishads' by Act No. 41 of 2006, dated 23.9.2006.] and for matters connected therewith or
incidental thereto.Be it enacted by the Legislative Assembly of the State of Andhra Pradesh in the
Forty-fifth Year of Republic of India as follows:
Part I – Preliminary
1. Short title, extent, [application] [Inserted by Act No. 7 of 1998.] and
commencement.
(1)This Act may be called the Andhra Pradesh Panchayat Raj Act, 1994.(2)It extends to the whole of
the State of Andhra Pradesh, except-(a)the Municipal Corporations governed by any law relating to
Municipal Corporations for the time being in force in the State;(b)the Municipalities governed by
the law relating to municipalities for the time being in force in the State;(c)a Notified Area declared
under Section 389-A of the Andhra Pradesh Municipalities Act, 1965 (Act 6 of 1965);(d)the miningAndhra Pradesh Panchayat Raj Act, 1994

settlements governed by the Andhra Pradesh (Telangana Area) Mining Settlements Act, 1956 (Act
XLIV of 1956); and(e)the cantonments governed by the Cantonments Act, 1924 (Central Act 2 of
1924).(2A)[ In their application to the Scheduled Areas in the State as referred to in clause (1) of
article 244 of the Constitution of India, the remaining provisions of this Act shall apply subject to
the provisions of Part VIA of this Act.] [Inserted by Act No. 7 of 1998.](3)It shall come into force on
such date and in such area as the Government may, by notification in the Andhra Pradesh Gazette,
appoint and they may appoint different dates for different areas and for different provisions.
2. Definitions.
- In this Act, unless the context otherwise requires, -(1)'Andhra Area' means the territories of the
State of Andhra Pradesh other than the Telangana area;(2)'Backward Classes' mean any socially and
educationally Backward Classes of citizens recognised by the Government for purpose of clause (4)
of Article 15 of the Constitution of India;[* * *] [Omitted by Section 2 of Act No. 5 of
1995.](3)'building' includes a house, out-house, shop, stable, latrine, shed (other than a cattle shed
in an agricultural land), hut, wall and any other such structure whether of masonry, bricks, wood,
mud, metal or other material whatsoever;(4)'casual vacancy' means a vacancy occurring otherwise
than by efflux of time, and 'casual election' means an election held to fill a casual
vacancy;(5)['Chairperson'] [The words Chairman and Vice-Chairman substituted with Chairperson
and Vice Chairperson by Section 7(i) and (ii) of Act. No. 37 of 2001.] means the Chairperson of a
[Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] elected
under Section 181;(6)'Chief [Executive Authority] [The words executive officer substituted with the
words Executive Authority through out the principal Act by Section 12 of Act No. 22 of 2002.]'
means the Chief Executive Authority of the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act
No. 41 of 2006, dated 23.9.2006.] appointed under Section 186;(7)'Collector' means any officer
incharge of a Revenue Division and includes a Deputy Collector, a Sub-Collector and an Assistant
Collector;(8)'Commissioner' means any officer who is authorised by the Government to exercise any
of the powers or discharge any of the duties of the Commissioner under this Act;(9)'Company'
means a Company as defined in the Companies Act, 1956 (Central Act 1 of 1956) and includes a
foreign company within the meaning of Section 591 of that Act;(10)'District Munsif' means the
District Munsif appointed under the Andhra Pradesh Civil Courts Act, 1972 (Act 19 of
1971);(11)'election authority' means such authority not being a member or office bearer of any local
authority as may, by notification, be appointed by the Andhra Pradesh Election Commissioner for
Local Bodies;(12)[ 'executive authority' means the Panchayat Secretary appointed to each Gram
Panchayat.] [Substituted by Section 2(1) of Act No. 22 of 2002.](13)[***] [Omitted by Section 2(2) of
Act No. 22 of 2002.](14)'factory' means a factory as defined in the Factories Act, 1948 (Central Act
63 of 1948) and includes any premises including the precincts thereof, wherein any industrial,
manufacturing or trade process is carried on with the aid of steam, water, oil, gas, electrical or any
other form of power which is mechanically transmitted and is not generated by human or animal
agency;(15)'Finance Commission' means the Finance Commission constituted by the Governor
under Section 235;(16)'Government' means the State Government;(17)'Gram Panchayat' means the
body constituted for the local administration of a village under the Act;(18)'Gram Sabha' means the
Gram Sabha which comes into existence under Section 6;(19)'house' means a building or a hut fit for
human occupation, whether as a residence or otherwise and includes any shop, factory, workshop orAndhra Pradesh Panchayat Raj Act, 1994

warehouse or any building used for garaging or parking buses or as a bus-stand, cattle shed (other
than a cattle shed in an agricultural land, poultry shed or dairy shed);(20)'hut' means any building
which is constructed, principally of wood, mud, leaves, grass, or thatch and includes any temporary
structure of whatever size or any small building of whatever material made, which the Gram
Panchayat may declare to be a hut for the purposes of this Act;(21)'latrine' includes privy, water
closet and urinal;(22)'Mandal' means such area in a district as may be declared by the Government
by notification to be a Mandal under Section 3 of the Andhra Pradesh District (Formation) Act, 1974
(Act 7 of 1974);(23)'[Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006,
dated 23.9.2006.]' means, a [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41
of 2006, dated 23.9.2006.] constituted or reconstituted under Section 148;(24)'[Mandal Praja
Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] Development
Officer' means, the officer appointed by that designation under Section 168;(25)'notification' means
a notification published in the Andhra Pradesh Gazette and the word 'notified' shall be construed
accordingly;(26)'nuisance' includes any act, omission, place or thing which causes or is likely to
cause injury, danger, annoyance or offence to the sense of sight, smell or hearing or disturbance to
rest or sleep or which is or may be dangerous to life, or injurious to health or property;(27)'ordinary
vacancy' means a vacancy occurring by efflux of time and 'ordinary election' means an election held
to fill an ordinary vacancy;(28)'owner' includes -(a)the person for the time being receiving or
entitled to receive whether on his own account or as agent, trustee, guardian, manager or receiver
for another person or for any religious or charitable purpose, the rent or profits of the property in
connection with which the word is used; and(b)the person for the time being in charge of the animal
or vehicle in connection with which the word is used;[(28-A) 'Panchayat Secretary' means the
"Panchayat Secretary" appointed under Section 30;] [Inserted by Section 2(3) of Act No. 22 of
2002.](29)'population' or 'population at the last census' means the population as ascertained at the
last preceding census of which the relevant figures have been published;(30)'prescribed' means
prescribed by the Government by rules made under this Act;(31)'President' means the President of a
[Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.]
elected under Section 153;(32)'private road' means any street, road, square, court, alley, passage or
riding path which is not a 'public road', but does not include a pathway made by the owner of
premises on his own land to secure access to, or the convenient use of such premises;(33)'public
road' means any street, road, square, court, alley, passage or riding path, over which the public have
a right of way whether a thoroughfare or not, and includes -(a)the roadway over any public bridge or
cause-way;(b)the footway attached to any such road, public bridge or cause-way; and(c)the drains
attached to any such road, public bridge or cause-way, and the land, whether covered or not by any
pavement, verandah or other structure, which lies on either side of the roadway upto the boundaries
of the adjacent property, whether that property is private property or property belonging to
Government;(34)[ 'qualifying date' in relation to the preparation and publication of every electoral
roll under this Act, means the first day of January of the year in which it is so prepared and
published.] [Substituted by Section 2 of Act No. 26 of 2000.][(34-A) "Recognised Political Party"
and "Registered Political party" shall have the meanings respectively assigned to them in the
Election Symbols (Reservation and Allotment) Order, 1968, issued by the Election Commission of
India under Article 324 of the Constitution of India and in the Registration of Political Parties and
Allotment of Symbols Order, 2001, issued by the . - under Article 243-K of the Constitution of
India.] [Inserted by Act No. 22 of 2006, dated 19.4.2006.](35)'registered voter' in the '[MandalAndhra Pradesh Panchayat Raj Act, 1994

Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.]' or
'registered voter in the district' means a person whose name appears in the electoral roll prepared
and published under Section 11 for any Gram Panchayat or Gram Panchayats comprised in the
Mandal or as the case may be, in the District;(36)'residence', 'reside' - A person is deemed to have
his 'residence' or to 'reside' in any house if he sometimes uses any portion thereof as a sleeping
apartment, and a person is not deemed to cease to reside in any such house merely because he is
absent from it or has elsewhere another dwelling in which he resides, if he is at liberty to return to
such house at any time and has not abandoned his intention of returning;(37)'Sarpanch' means the
Sarpanch of a Gram Panchayat elected under Section 14;(38)'Scheduled Castes' and 'Scheduled
Tribes' shall have the meaning respectively assigned to them in clause (24) and clause (25) of Article
366 of the Constitution of India;(39)'Andhra Pradesh Election Commission for Local Bodies' means
the Andhra Pradesh Election Commission for Local Bodies constituted under Section
200;(40)['Andhra Pradesh Election Commissioner for Local Bodies'] [Substituted by Section 2 of
Andhra Pradesh Act No. 33 of 1998.] means [Andhra Pradesh Election Commissioner for Local
Bodies] [Substituted by Section 2 of Andhra Pradesh Act No. 33 of 1998.] appointed by the
Governor under sub-Section (2) of Section 200;(41)'Telangana Area' means the territories specified
in sub-Section (1) of Section 3 of the States Reorganisation Act, 1956 (Central Act 37 of
1956);(42)'village' means any local area which is declared to be a village under this
Act;(43)'water-course' includes, any river, stream or channel, whether natural or artificial;(44)'year'
means the financial year;(45)'[Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of
2006, dated 23.9.2006.]' means a [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of
2006, dated 23.9.2006.] constituted under Section 177.
Part II – Gram Panchayat
Chapter I
Constitution, Administration and Control of Gram Panchayats
3. Declaration of a village for the purposes of this Act.
(1)The [Government] [Substituted by Section 3(1)(i) of Act No. 22 of 2002.] may, by notification and
in accordance with the rules made [***] [Omitted by Section 3(1)(ii) of Act No. 22 of 2002.] in this
behalf, declare any revenue village or hamlet thereof or any part of a mandal to be a village for the
purpose of this Act and specify the name of the village.Explanation. - For the purposes of this
sub-Section the expressions 'mandal' and 'revenue village' shall mean respectively any local area
which is recognised as a mandal or village in the revenue accounts of Government after excluding
therefrom the area, if any, included in -(a)a municipal corporation governed by the relevant law
relating to Municipal Corporations for the time being in force in the State;(b)a municipality
governed by the law relating to Municipalities for the time being in force in the State;(c)a mining
settlement governed by the Andhra Pradesh (Telangana Area) Mining Settlements Act, 1956;(d)a
cantonment governed by the Cantonments Act, 1924.(2)The [Government] [Substituted by Section
3(2)(a) of Act No. 22 of 2002.] may, by notification and in accordance with such rules as may be
prescribed in this behalf -(a)form a new village by separation of local area from any village or byAndhra Pradesh Panchayat Raj Act, 1994

uniting two or more villages or parts of villages or by uniting any local area to a part of any
village:[Provided that the Government shall take into consideration the financial viability of the
Gram Panchayat, to be newly created before bifurcation of the said Gram Panchayat, for the purpose
of providing a Panchayat Secretary.] [Added by Section 3(2)(b) of Act No. 22 of 2002.](b)increase
the local area of any village;(c)diminish the local area of any village;(d)alter the boundaries of any
village;(e)alter the name of any village;(f)cancel a notification issued under sub-Section (1).(3)The
[Government] [Substituted by Section 3(3) of Act No. 22 of 2002.] may pass such orders as it may
deem fit -(a)as to the disposal of the property vested in a Gram Panchayat which has ceased to exist,
and the discharge of its liabilities; and(b)as to the disposal of any part of the property vested in a
Gram Panchayat which has ceased to exercise jurisdiction over any local area, and the discharge of
the liabilities of the Gram Panchayat relating to such property or arising from such local area.An
order made under this sub-Section may contain such supplemental, incidental and consequential
provisions as the Commissioner may deem necessary, and in particular may direct -(i)that any tax,
fee or other sum due to the Gram Panchayat or where a Gram Panchayat has ceased to exercise
jurisdiction over any local area, such tax, fee, or other sum due to the Gram Panchayat as relates to
that area, shall be payable to such authorities as may be specified in the order;and(ii)that appeals,
petitions, or other applications with reference to any such tax, fee or sum which are pending on the
date on which the Gram Panchayat ceased to exist or, as the case may be, on the date on which the
Gram Panchayat ceased to exercise jurisdiction over the local area, shall be disposed of by such
authorities as may be specified in the order.
4. Constitution of Gram Panchayats for villages and their incorporation.
(1)A Gram Panchayat shall be deemed to have been constituted for a village on the date of
publication of the notification under Section 3 in respect of that village and the Special Officer
appointed under sub-Section (1) of Section 143 shall make arrangements for the election of the
members and of the Sarpanch of the Gram Panchayat as provided in that Section.(2)Subject to the
provisions of this Act, the administration of the village shall vest in the Gram Panchayat, but the
Gram Panchayat shall not be entitled to exercise functions expressly assigned by or under this Act or
any other law to its Sarpanch or executive authority, or to any other local authority or other
authority.(3)Every Gram Panchayat shall be a body corporate by the name of the village specified in
the notification issued under Section 3, shall have perpetual succession and a common seal, and
subject to any restriction or qualification imposed by or under this Act or any other law, shall be
vested with the capacity of suing or being sued in its corporate name, of acquiring, holding and
transferring property, of entering into contracts, and of doing all things necessary, proper or
expedient for the purposes for which it is constituted.
5. Township.
(1)The Government may declare, by a notification in the Andhra Pradesh Gazette, a village or any
other area to be a township if it is an industrial or institutional colony, a labour colony, a project
area, a health resort or a place of religious importance.(2)If the area declared as township under
sub-Section (1) comprises a village or forms part of a village, the Commissioner shall, under
sub-Section (2) of Section 3, cancel the notification issued under sub-Section (1) of that Section inAndhra Pradesh Panchayat Raj Act, 1994

respect of such village, or as the case may be, exclude such part from the village.(3)In regard to any
area other than a place of religious importance declared to be a township, the Government shall, by
notification in the Andhra Pradesh Gazette, constitute a township committee, which shall consist of
a Chairperson to be nominated by the Government and the following official and non-official
members, namely:-A. Official Members(i)in regard to a township constituted for an industrial or
institutional colony, labour colony, project area or health resort, the highest official representing the
industry, institution, project or health resort concerned;(ii)the Chief Executive Authority of the
[Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.]
concerned;(iii)the Divisional Engineer, Electricity Board, in whose jurisdiction the township is
located;(iv)the Executive Engineer, Panchayat Raj, of the Division in which the township is located;
and(v)an officer of the Tourism Department wherever necessary and in other cases an official
representing the management of the industry, institution, project or health resort concerned as may
be nominated by the Government; andB. Non-Official Members(i)the Member of the Lok Sabha in
whose constituency the township is located;(ii)the Member or Members of the Legislative Assembly
in whose constituency the township is located;(iii)one woman member, who is a registered voter in
the township to be nominated by the Government; and(iv)two persons who are registered voters in
the township, other than those persons specified in items (i) to (iii) and who are specially qualified
to assist and advise the Township Committee on its various activities to be nominated by the
Government:Provided that one of the Members to be nominated under this clause shall be a
member belonging to the Scheduled Castes or Scheduled Tribes.(4)The Chairperson and the
non-official members of the Committee under items (iii) and(iv)of sub-Section (3) shall hold office
during the pleasure of the Government and the official members and non-official members under
items (i) and (ii) of sub-Section (3) shall hold office so long as they hold their respective offices.(5)A
notification issued by the Government under sub-Section (3) may direct that any functions vested in
a Gram Panchayat by or under this Act shall be transferred to and performed by the township
committee and shall provide for-(i)the restrictions and conditions subject to which the township
committee may perform its functions; and(ii)any other matter incidental to, or connected with, the
transfer of the functions of a Gram Panchayat to the township committee including the
apportionment of the revenues between the township committee and the Gram Panchayat
concerned or any contributions or compensation that shall be paid by the township committee to the
Gram Panchayat concerned.(6)Every township committee shall, in regard to the conduct of its
business, follow such procedure as may be prescribed.(7)The Government may, by notification in
the Andhra Pradesh Gazette direct that any of the provisions of this Act or of the law relating to
municipalities for the time being in force or of any rules made thereunder or of any other enactment
for the time being in force elsewhere in the State but not in the village or local area or specified part
thereof referred to in sub-Section (1) shall apply to that village, local area or part to such extent and
subject to such modifications, additions and restrictions as may be specified in the notification.
6. Gram Sabha.
(1)There shall come into existence a Gram Sabha for every village on the date of publication of
notification under Section 3.(2)A Gram Sabha shall consist of all persons whose names are included
in the electoral roll for the Gram Panchayat referred to in Section 4 and such persons shall be
deemed to be the members of the Gram Sabha.(3)The Gram Sabha shall meet at least twice in everyAndhra Pradesh Panchayat Raj Act, 1994

year on such date and at such place and time as may be prescribed to consider the following matters
which shall be placed before it by the Gram Panchayat, namely:-(i)annual statement of accounts and
audit report;(ii)report on the administration of the preceding year;(iii)programme of works for the
year or any new programme not covered by the budget or the annual programme;(iv)proposals for
fresh taxation or for enhancement of existing taxes;(v)selection of schemes, beneficiaries and
locations; and(vi)such other matter as may be prescribed.The Gram Panchayat shall give due
consideration to the suggestions, if any, of the Gram Sabha.(4)The Gram Sabha shall observe such
rules of procedure at its meetings as may be prescribed.(5)[ Every meeting of the Gram Sabha within
10 days from the date prescribed under sub-Section (3) shall be convened and presided over by the
Sarpanch or in his absence by the Upa Sarpanch of the Gram Panchayat.] [Substituted by Section 4
of Act No. 22 of 2002.]
7. Total strength of a Gram Panchayat.
- [1] [Renumbered by Section 2 of Act No. 16 of 1996.] A Gram Panchayat shall consist of such
number of elected members inclusive of its Sarpanch as may be notified from time to time, by the
Commissioner in accordance with the following Table:-Table
Gram Panchayat with a Population at the LastCensus Number of Members
Upto 300 5
Exceeding 300 but not exceeding 500 7
Exceeding 500 but not exceeding 1,500 9
Exceeding 1,500 but not exceeding 3,000 11
Exceeding 3,000 but not exceeding 5,000 13
Exceeding 5,000 but not exceeding 10,000 15
Exceeding 10,000 but not exceeding 15,000 17
Exceeding 15,000 Between 19 & 21
(2)[ The Member of the [Mandal Praja Parishad] [Added by Section 2 of Act No. 16 of 1996.]
Territorial Constituency shall be permanent invitee to the meetings of Gram Panchayats and he shall
have the right to speak in and otherwise to take part in the proceedings of any meeting of the Gram
Panchayat or Gram Panchayats functioning within the local limits of the respective jurisdiction; but
shall not, by virtue of this Section be entitled to vote at any such meeting.](3)[ One representative
from each category of Self Help Group/Functional Group to be elected in a meeting of the Self Help
Group / Functional Group, which shall be presided over by the Sarpanch for co-option in the
manner prescribed. They shall have the right to speak in and otherwise to take part in proceedings
of any meeting but they shall not be entitled to vote at any such meeting.] [Added by Section 5 of Act
No. 22 of 2002.]
8. Election of members.
- All members of the Gram Panchayat shall be elected by the registered voters in the ward by the
method of secret ballot and in accordance with such rules as may be made in this behalf.Andhra Pradesh Panchayat Raj Act, 1994

9. Reservation of seats of members of Gram Panchayats.
(1)In every Gram Panchayat, out of the total strength of elected members determined under Section
7, the Commissioner shall, subject to such rules as may be prescribed, by notification, reserve
-(a)such number of seats to the Scheduled Castes and Scheduled Tribes as may be determined by
him, subject to the condition that the number of seats so reserved shall bear, as nearly as may be,
the same proportion to the total number of seats to be filled by direct election to the Gram
Panchayat, as the population of the Scheduled Castes, or as the case may be, Scheduled Tribes in
that village bears to the total population of that village, and such seats may be allotted by rotation to
different wards in a Gram Panchayat;[***] [Omitted by of Act No. 5 of 1995.](c)not less than
one-third of the total number of seats reserved under [clause (a) and sub-Section (1 A)] [Substituted
by Act No. 5 of 1995.] for women belonging to the Scheduled Castes, Scheduled Tribes or as the case
may be the Backward Classes;(d)not less than one-third (including the number of seats reserved for
women belonging to the Scheduled Castes, Scheduled Tribes and Backward Classes) of the total
number of seats to be filled by direct election to every Gram Panchayat shall be reserved for women
and such seats may be allotted by rotation to different wards in a Gram Panchayat.(1A)[ In addition
to the reservation of seats under sub-Section (1), there shall be reserved for the Backward Classes
such a number of seats as may be allocated to them in each Gram Panchayat in the manner
prescribed; so however that the number of offices of members of Gram Panchayats in the State
reserved for Backward Classes shall not be less than thirty-four per cent of the total number of
offices of the members of Gram Panchayats in the State. The number of seats allocated to each Gram
Panchayat shall be allotted by rotation to different wards in the Gram Panchayat:Provided that it
shall be competent for the Government to make special provision with regard to the manner and
quantum of seats to be reserved for Backward Classes in the Gram Panchayats situated in the
Scheduled areas by rules made in this behalf."] [Added by Act No. 5 of 1995.](2)Nothing in
[sub-Sections (1) and [(1A)] [Substituted by Act No. 5 of 1995.] shall be deemed to prevent women
and members of the Scheduled Castes, Scheduled Tribes or Backward Classes from standing for
election to the non-reserved seats in the Gram Panchayat.
10. Division of wards.
- For the purpose of electing members to a Gram Panchayat, the Commissioner shall, subject to such
rules as may be prescribed, divide the village into as many wards as there are seats, determined
under Section 7, on a territorial basis in such a manner that all wards shall have, as far as
practicable, equal number of voters and allot not more than one seat for each ward.
11. Preparation and Publication of electoral roll for a Gram Panchayat.
(1)The [*] [Omitted by Section 3(i)(a) of Act No. 26 of 2000.] electoral roll for Gram
Panchayat shall be prepared by the person authorised by the Andhra Pradesh Election
Commissioner for Local Bodies in such manner by reference to such qualifying date
as may be prescribed and the electoral roll for the Gram Panchayat shall come into
force immediately [upon its publication] [Substituted by of Act No. 26 of 2000.] in
accordance with the rules made by the Government in this behalf. The [*] [Omitted by ofAndhra Pradesh Panchayat Raj Act, 1994

Act No. 26 of 2000.] electoral roll for the Gram Panchayat shall consist of such part of the electoral
roll for the Assembly Constituency published under the Representation of the People Act, 1950
(Central Act 43 of 1950) as revised or amended under the said Act, upto the qualifying date, as
relates to the village or any portion thereof:[Provided that any amendment, transposition or
deletion of any entries in the electoral roll, or any inclusion of names in the electoral roll of the
Assembly Constituencies concerned, made by the Electoral Registration Officer under Section 22 or
Section 23, as the case may be, of the Representation of the People Act, 1950, up to the date of
election notification, for any election held under this Act, shall be carried out in the electoral roll of
the Gram Panchayat and any such names included shall be added to the part relating to the last
ward.] [Inserted by Section 3(i)(c) Act No. 26 of 2000.]Explanation. - Where in the case of any
Assembly Constituency there is no distinct part of the electoral roll relating to the village, all persons
whose names are entered in such roll under the registration area comprising the village and whose
addresses as entered are situated in the village shall be entitled to be included in the electoral roll for
the Gram Panchayat prepared for the purposes of this Act.(2)[ The electoral roll for a Gram
Panchayat:-(a)shall be prepared and published in the prescribed manner by reference to the
qualifying date,-(i)before each ordinary election; and(ii)before each casual election to fill a casual
vacancy in the office of the Sarpanch and Member of a Gram Panchayat; and(b)shall be prepared
and published in any year, in the prescribed manner, by reference to the qualifying date, if so
directed by the Andhra Pradesh Election Commission for Local Bodies:Provided that if the electoral
roll is not prepared and published as aforesaid, the validity, or continued operation of the said
electoral roll, shall not thereby be affected.] [Substituted by Section 3(ii) Act No. 26 of 2000.](3)The
[electoral roll] [Substituted by Section 3(iii) Act No. 26 of 2000.] published under sub-Section (1)
shall be the electoral roll for the Gram Panchayat and it shall remain in force till a fresh electoral roll
for the Gram Panchayat is published under this Section.(4)The electoral roll for the Gram Panchayat
shall be divided into as many parts as there are wards so that each part consists of the voters
residing in the concerned ward and for this purpose the electoral roll may be rearranged if such
rearrangement is found necessary.(5)Every person whose name appears in the part of the electoral
roll relating to a ward shall subject to the other provisions of this Act, be entitled to vote at any
election which takes place in that ward while the electoral roll remains in force and no person whose
name does not appear in such part of the electoral roll shall vote at any such election.(6)No person
shall vote at an election under this Act in more than one ward or more than once in the same ward
and if he does so, all his votes shall be invalid.Explanation. - In this Section, the expression
'Assembly Constituency' shall mean a constituency provided by law for the purpose of elections to
the Andhra Pradesh Legislative Assembly.
12. Rearrangement and republication of electoral rolls.
- Where, after the electoral roll for the Gram Panchayat has been published under sub-Section (1) of
Section 11, the village is divided into wards for the first time or the division of the village into wards
is altered or the limits of the village are varied, the person authorised by the Andhra Pradesh
Election Commissioner for Local Bodies in this behalf shall, in order to give effect to the division of
the village into wards or to the alteration of the wards, or to the variation of the limits, as the case
may be, authorise a re-arrangement and republication of the electoral roll for the Gram Panchayat
or any part of such roll in such manner, as the Andhra Pradesh Election Commissioner for LocalAndhra Pradesh Panchayat Raj Act, 1994

Bodies may direct.
13. Term of Office of members.
(1)Save as otherwise provided in this Act the term of office of members elected at ordinary elections
shall be five years from the date appointed by the Commissioner for the first meeting of the Gram
Panchayat after the ordinary elections.(2)Ordinary vacancies in the office of elected members shall
be filled at ordinary elections which shall be fixed [by the State Election Commission] [Substituted
'by the election authority' by Act No. 22 of 2006, dated 19.4.2006.] to take place on such day or days
within three months before the occurrence of the vacancies, as he thinks fit:Provided that the
Andhra Pradesh Election Commissioner for Local Bodies may, for sufficient reasons to be recorded
in writing, direct from time to time, the postponement or alteration of the date of an ordinary
election or any stage thereof within the period of three months aforesaid and the election authority
shall give effect to such directions.(3)(a)Every casual vacancy in the office of an elected member of a
Gram Panchayat shall be reported by the executive authority to the election authority within fifteen
days from the date of occurrence of such vacancy and shall be filled within four months from that
date.(b)A member elected in a casual vacancy shall enter upon office forthwith but shall hold office
only so long as the member in whose place he is elected would have been entitled to hold office if the
vacancy had not occurred.(c)No casual election shall be held to a Gram Panchayat within six months
before the date on which the term of office of its members expires by efflux of time.
14. Election and term of office of Sarpanch.
(1)There shall be a Sarpanch for every Gram Panchayat, who shall be elected in the prescribed
manner by the persons whose names appear in the electoral roll for the Gram Panchayat, from
among themselves. A person shall not be qualified to stand for election as Sarpanch, unless he is not
less than twenty-one years of age:Provided that a Member of the Legislative Assembly of the State or
of either House of Parliament who is elected to the office of Sarpanch or Upa-Sarpanch shall cease
to hold such office unless within one month from the date of election to such office he ceases to be a
Member of the Legislative Assembly of the State or of either House of Parliament by resignation or
otherwise.(2)The election of the Sarpanch may be held at the same time and in the same place as the
ordinary elections of the members of the Gram Panchayat.(3)Save as otherwise expressly provided
in, or prescribed under this Act, the term of office of the Sarpanch who is elected at an ordinary
election shall be five years from the date appointed by the election authority for the first meeting of
the Gram Panchayat after the ordinary election.(4)Subject to the provisions of sub-Section (5), any
casual vacancy in the office of the Sarpanch shall be filled within one hundred and twenty days from
the date of occurrence of such vacancy, by a fresh election under sub-Section (1); and a person
elected as Sarpanch in any such vacancy shall hold office only so long as the person in whose place
he is elected would have been entitled to hold office if the vacancy had not occurred.(5)Unless the
Commissioner otherwise directs, no casual vacancy in the office of the Sarpanch shall be filled
within six months before the date on which the ordinary election of the Sarpanch under sub-Section
(1) is due.(6)The provisions of Sections 18 to 22 shall apply in relation to the office of the Sarpanch
as they apply in relation to the office of an elected member of the Gram Panchayat.(7)The Sarpanch
shall be an ex-officio member of the Gram Panchayat and shall be entitled to vote at meetings of theAndhra Pradesh Panchayat Raj Act, 1994

Gram Panchayat.(8)A person shall be disqualified for election as Sarpanch if he is in arrears of any
dues, otherwise than in a fiduciary capacity to a [Mandal Praja Parishad] [Substituted 'Mandal
Parishad' by Act No. 41 of 2006, dated 23.9.2006.], or if he is interested in a subsisting contract
made with or any work being done for, the [Mandal Praja Parishad] [Substituted 'Mandal Parishad'
by Act No. 41 of 2006, dated 23.9.2006.] within whose jurisdiction the Gram Panchayat is situated
or any other Gram Panchayat within the jurisdiction of that [Mandal Praja Parishad] [Substituted
'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.]:Provided that a person shall not be
deemed to have any interest in such contract or work by reason only of his having a share or interest
in,-(i)a company as a mere shareholder but not as a director; or(ii)any lease, sale or purchase of
immovable property or any agreement for the same; or(iii)any agreement for the loan of money or
any security for the payment of money only;or(iv)any newspaper in which any advertisement
relating to the affairs of any of the aforesaid Gram Panchayat is Inserted.Explanation. - For the
removal of doubts it is hereby declared that where a contract is fully performed it shall not be
deemed to be subsisting merely on the ground that the [Mandal Praja Parishad] [Substituted
'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] has not performed its part of the
contractual obligation.(9)For every Gram Panchayat, one of the members shall be elected to be
Upa-Sarpanch by the Gram Panchayat, in the prescribed manner. If at an election held for the
purpose, no Upa-Sarpanch is elected fresh election shall be held:Provided that before an election of
Upa-Sarpanch is held, every casual vacancy in the office of an elected member of a Gram Panchayat
shall be filled.(10)A special meeting for the election of the Upa-Sarpanch shall be called on the same
date on which the results of the ordinary elections to the Gram Panchayat have been published. The
notice of the meeting for election of Upa-Sarpanch shall be given to the members so elected by
affixture of the same on the notice board at the office of the Gram Panchayat, immediately after such
publication:Provided that if, for any reason, the election of the Upa-Sarpanch is not held on the date
aforesaid the special meeting for the election of the Upa-Sarpanch shall be held on the next day,
whether or not it is a holiday observed by the Gram Panchayat:Provided further that the
Government may, from time to time, for reasons to be recorded in writing direct or permit the
holding of the election of the Upa-Sarpanch on any other day.
15. Reservation of Office of Sarpanch.
- [1] [Added by Section 4 of Act No. 5 of 1995.] Out of total number of offices of Sarpanch in the
State, the Commissioner shall, subject to such rules as may be prescribed, by notification
reserve-(a)such number of offices to the Scheduled Castes and Scheduled Tribes as may be
determined by him, subject to the condition that the number of offices so reserved shall bear, as
nearly as may be, the same proportion to the total number of offices to be filled in the State as the
population of the Scheduled Castes, or as the case may be, Scheduled Tribes in the State bears to the
total population of the State; and such seats may be allotted by rotation to different Gram
Panchayats in the State;[* * *] [Omitted by Section 4 (i) of Act No. 5 of 1995.](c)not less than
one-third of the total number of offices reserved under [clause (a) and sub-Section (2)] [Substituted
by Section 4 (ii) Act No. 5 of 1995.] for women belonging to the Scheduled Castes, Scheduled Tribes,
or as the case may be, Backward Classes; and(d)not less than one-third (including the number of
offices reserved for women belonging to the Scheduled Castes, Scheduled Tribes and the Backward
Classes) of the total number of offices to be filled in the State for women; and such offices may beAndhra Pradesh Panchayat Raj Act, 1994

allotted by rotation to different Gram Panchayats in the State.(2)[ In addition to the reservation of
offices of Sarpanch under sub-Section (1), there shall be reserved for the Backward Classes such
number of Offices of Sarpanch as may be allocated to them in each Mandal in the manner
prescribed; so, however, that the number of Offices or Sarpanchas in the State reserved for
Backward Classes shall not be less than thirty-four per cent of the total number of offices of
Sarpanchas of Gram Panchayats in the State. The number of offices of Sarpanchas allocated for
reservation to each Mandal shall be allotted by rotation to different Gram Panchayats in the
Mandal:Provided that it shall be competent for the Government to make special provision with
regard to the manner and quantum of seats to be reserved for Backward Classes in the Gram
Panchayats situated in the Scheduled areas, by rules made in this behalf.] [Added by Section 4 (iii)
of Act No 5 of 1995.]
16. Fresh elections in certain cases.
(1)If at an ordinary or casual election, no person is elected to fill a vacancy, a fresh election shall be
held on such day as the officer or authority authorised by the Andhra Pradesh Election
Commissioner for Local Bodies in this behalf, may fix.(2)The term of office of a member of a Gram
Panchayat elected under this Section shall expire at the time at which it would have expired if he had
been elected at the ordinary or casual election, as the case may be.
17. Qualifications of candidates.
- No person shall be qualified for election as a member of a Gram Panchayat unless his name
appears on its electoral roll and he is not less than twenty-one years of age.
18. Disqualification of certain office holders etc.
(1)No village servant and no officer or servant of the Government of India or any State Government
or of a local authority or an employee of any institution receiving aid from the funds of the
Government and no office bearer of any body constituted under a law made by the Legislature of the
State or of Parliament shall be qualified for being chosen as or for being a member of a Gram
Panchayat.Explanation. - For the purpose of this Section, the expression "village servant" means in
relation to-(i)the Andhra Area, any person who holds any of the village offices of neeraganti,
neeradi, vetti, kawalkar toti, talayar, tandalagar, sathsindi or any such village office by whatever
designation it may be locally known;(ii)the Telangana Area, any person who holds any of the village
offices of neeradi, kawalkar, sathsindhi or any such village office by whatever designation it may be
locally known.(2)A person who having held an office under the Government of India or under the
Government of any State or under any local authority has been dismissed for corruption or for
disloyalty to the State or to the local authority shall be disqualified for a period of five years from the
date of such dismissal.(3)For the purpose of sub-Section (2), a certificate issued by the Andhra
Pradesh Election Commissioner for Local Bodies to the effect that a person having held office under
the Government of India or under the Government of State or under any local authority has or has
not been dismissed for corruption or for disloyalty to the State or to the local authority shall be
conclusive proof of that fact:Provided that no certificate to the effect that a person has beenAndhra Pradesh Panchayat Raj Act, 1994

dismissed for corruption or for disloyalty to the State or to the local authority shall be issued unless
an opportunity of being heard has been given to the said person.(4)[ ***] [Omitted by Section 2(1) of
Act No. 37 of 2001.](5)Apart from the disqualifications specified in sub-Sections [(1) and (2)]
[Substituted by Section 2(2) of Act No. 37 of 2001.] of this Section and Sections 19 and 20, a person
shall be disqualified for being chosen as, and for being, a member of a Gram Panchayat if he is
otherwise disqualified by or under any law for the time being in force for the purposes of elections to
the Legislature of the State:Provided that no person shall be disqualified on the ground that he is
less than twenty-five years of age, if he has attained the age of twenty-one years:Provided further
that where a person is convicted for an offence specified under sub-Section (1) or sub-Section (2) of
Section 8 of the Representation of People Act, 1951 (Central Act 43 of 1951) or under Section 19 of
this Act, while he is a member or office bearer of a Gram Panchayat, [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or [Zilla Praja Parishad]
[Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.], the disqualification arising
out of such conviction shall not take effect until the expiry of the time for filing an appeal against
such conviction and where an appeal is filed until the disposal of the appeal:Provided also that a
person convicted for an offence under sub-Section (1) of Section 8 of the Representation of People
Act, 1951 (Central Act 43 of 1951) shall be disqualified for being chosen as or for continuing as a
member of a Gram Panchayat, [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No.
41 of 2006, dated 23.9.2006.] or a [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41
of 2006, dated 23.9.2006.] for a period of six years from the date of conviction and a person
convicted under sub-Section (2) thereof shall be disqualified for a period of six years from the date
of conviction and for a further period of five years from the date of release.
19. Disqualification of candidates.
(1)A person who has been convicted by a Criminal Court,-(a)for an offence under the Protection of
Civil Rights Act, 1955 (Central Act 22 of 1955); or(b)for an offence involving moral delinquency;
shall be disqualified for election as a Member for a period of five years from the date of conviction or
where he is sentenced to imprisonment while undergoing sentence and after a period of five years
from the date of expiration thereof.(2)A person shall be disqualified for being chosen as a member if
on the date fixed for scrutiny of nominations for election, or on the date of nomination under
sub-Section (2) of Section 16 he is -(a)of unsound mind and stands so declared by a competent
court;(b)a deaf-mute [* * *] [Omitted by Section 6 of Act No. 22 of 2002.];(c)an applicant to be
adjudicated an insolvent or an undischarged insolvent;(d)interested in a subsisting contract made
with, or any work being done for, the Gram Panchayat, [Mandal Praja Parishad] [Substituted
'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.], [Zilla Praja Parishad] [Substituted 'Zilla
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or any State or Central Government:Provided
that a person shall not be deemed to have any interest in such contract or work by reason only of his
having a share or interest in-(i)a company as a mere shareholder but not as a director;(ii)any lease,
sale or purchase of immovable property or any agreement for the same; or(iii)any agreement for the
loan of money or any security for the payment of money only;or(iv)any newspaper in which any
advertisement relating to the affairs of the Gram Panchayat is Inserted;Explanation. - For the
removal of doubts it is hereby declared that where a contract is fully performed it shall not be
deemed to be subsisting merely on the ground that the Gram Panchayat, [Mandal Praja Parishad]Andhra Pradesh Panchayat Raj Act, 1994

[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.], [Zilla Praja Parishad]
[Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.], the State or Central
Government has not performed its part of the contractual obligation.(dd)[ already a member of a
Nagar Panchayat or a Municipality constituted under the Andhra Pradesh Municipalities Act, 1965
or a member of a Municipal Corporation constituted under any law relating to Municipal
Corporations for the time being in force in the State of Andhra Pradesh;] [Inserted by Act No. 22 of
2006, dated 19.4.2006.](e)employed as paid legal practitioner on behalf of the Gram Panchayat or
as legal practitioner against the Gram Panchayat;(f)employed as a [***] [Omitted by Section 5 of Act
No. 5 of 1995.] manager or Secretary of any Company or Corporation (other than a co-operative
society) in which not less than twenty-five per cent of the paid up share capital is held by the State
Government;(g)an Honorary Magistrate under the Code of Criminal Procedure, 1973 (Central Act 2
of 1974) with jurisdiction over any part of the village;(h)already a member of the Gram Panchayat
whose term of office will not expire before his fresh election can take effect or has already been
elected as a member of the Gram Panchayat whose term of office has not yet commenced;(i)in
arrears of any dues including the sums surcharged otherwise than in a fiduciary capacity, to the
Gram Panchayat upto and inclusive of the previous year, in respect of which a bill or notice has been
duly served upon him and the time, if any, specified therein for payment has expired:Provided that
where any person has paid such dues into the Government treasury or into a bank approved by the
Government to the credit of the Gram Panchayat Fund and obtained a challan or receipt therefor in
token of such payment, he shall not be disqualified to become a member of the Gram Panchayat on
and from the date of such payment.(3)A person having more than two children shall be disqualified
for election or for continuing as member:Provided that the birth within one year from the date of
commencement of the Andhra Pradesh Panchayat Raj Act, 1994 hereinafter in this Section referred
to as the date of such commencement, of an additional child shall not be taken into consideration
for the purposes of this Section:Provided further that a person having more than two children
(excluding the child if any born within one year from the date of such commencement) shall not be
disqualified under this Section for so long as the number of children he had on the date of such
commencement does not increase:Provided also that the Government may direct that the
disqualification in this Section shall not apply in respect of a person for reasons to be recorded in
writing.
19A. [ Disqualification on ground of corrupt practice or election offences.
[Inserted by Section 4 of Act No. 26 of 2000.]
- Any person who is convicted of any offence punishable under Chapter IX A of the Indian Penal
Code, 1860, and any person against whom a finding of having indulged in any corrupt practice is
recorded in the verdict in an election petition filed in accordance with Section 233, or any person
convicted of an offence punishable under Chapter II of Part V of this Act, for a period of six years
from the date of such conviction or verdict, as the case may be.
19B. Disqualification for failure to lodge account of election expenses.
- If the Andhra Pradesh Election Commission for Local Bodies is satisfied that a person-(a)has failed
to lodge an account of election expenses within the time and in the manner required by or under thisAndhra Pradesh Panchayat Raj Act, 1994

Act, and(b)has no good reason or justification for the failure, the Andhra Pradesh Election
Commission for Local Bodies shall, after following the procedure prescribed, by order published in
the Andhra Pradesh Gazette, declare him:(i)to be ineligible for a period of three years from the date
of the said order to contest any election held for any office under this Act; and(ii)to have ceased to
hold office; in case he is elected.]
20. Disqualification of members.
- Subject to the provisions of Section 22, a member shall cease to hold office as such if he-(a)is or
becomes subject to any of the disqualifications specified in Section 19;(aa)[ is elected as a member to
a Ward/Office reserved for Scheduled Castes or Scheduled Tribes or Backward Classes on the basis
of a community certificate and subsequently the said community certificate is cancelled under
Section 5 of the Andhra Pradesh (Scheduled Castes, Scheduled Tribes and Backward Classes)
Regulation of issue of Community Certificates Act, 1993.] [Inserted by Section 3 of Act No. 37 of
2001.](b)absents himself from the meetings of the Gram Panchayat for a period of ninety days,
reckoned from the date of the commencement of his term of office, or of the last meeting which he
attended, or of his restoration to office as member under sub-Section (1) of Section 21, as the case
may be, or if within the said period, less than three ordinary meetings have been held, absents
himself from three consecutive ordinary meetings held after the said date:Provided that in the case
of a woman member, a period of not more than four months at a time shall be excluded in reckoning
the period of absence aforesaid, if for reasons of physical disability due to advanced stage of
pregnancy and delivery, such member absents herself from meetings after giving a written
intimation to the Executive Authority of the date from which she would be absent:Provided further
that no meeting from which a member absented himself shall be counted against him under this
clause if -(i)due notice of that meeting was not given to him in the prescribed manner; or(ii)the
meeting was held on a requisition of members.Explanation. - For the purpose of this
clause,(i)"ordinary meeting" shall mean a meeting held after giving a notice of at least three days
before the day of the meeting;(ii)where a meeting other than an ordinary meeting intervenes
between one ordinary meeting and another ordinary meeting, those two ordinary meetings shall be
regarded as being consecutive to each other.
20A. [ Disqualification of Sarpanch or Upa Sarpanch for failure to convene
the meetings of Gram Sabha. [Added by Section 7 of Act No. 22 of 2002.]
(1)Subject to the provisions of Section 22, a Sarpanch or as the case may be, a Upa-Sarpanch shall
cease to hold office as such, if he fails to convene the meetings of the Gram Sabha as required under
sub-Section (5) of Section 6 and further even on or before a date specified in a show cause notice
issued on him after the expiry of ten days, requiring him to convene the meetings of the Gram Sabha
and cease to exercise the powers and perform the functions of the Sarpanch or Upa-Sarpanch as the
case may be, unless such cessation has otherwise occurred before that date and for a period of one
year from such date, he shall not be eligible to be elected as Sarpanch or Upa-Sarpanch as the case
may be.(2)Every such cessation as is referred to in sub-Section (1) shall be intimated by the
Divisional Panchayat Officer in writing to the Sarpanch or the Upa Sarpanch as the case may be.Andhra Pradesh Panchayat Raj Act, 1994

20B. Disqualification of Sarpanch or Upa-Sarpanch for failure to close audit
of the accounts.
- A Sarpanch or as the case may be, a Upa Sarpanch shall cease to hold office as such, if he fails to
get the accounts of the Gram Panchayat audited within the period as required under the proviso to
sub-Section (3) of Section 266.]
21. Restoration of members to office.
(1)Where a person ceased to be a member under Section 18 or clause (a) of Section 20 read with
Section 19, he shall be restored to office for such portion of the period for which he was elected as
may remain unexpired at the date of such restoration, if and when the conviction or the sentence is
annulled on appeal or revision or the disqualification caused by the sentence is removed by an order
of the Government; and any person elected to fill the vacancy in the interim shall, on such
restoration, vacate office.(2)Where a person incurs the disqualification specified under clause (b) of
Section 20, the executive authority shall forthwith send a report in that regard to the District
Panchayat Officer concerned, who shall, on satisfying himself after due verification, that the person
has ex-facie ceased to be a member, intimate that fact by registered post to the member concerned
and report the same to the Gram Panchayat forthwith. If such member applies for restoration of his
membership to the Gram Panchayat within thirty days of the receipt by him of such intimation, he
shall be deemed to have been restored to his membership and the executive authority shall report
the fact of such restoration to the Gram Panchayat at its next meeting:Provided that a member who
is so restored to his membership again incurs the disqualification under the said clause (b), the
Gram Panchayat may, on his application for restoration filed within a period of thirty days of the
receipt by him of the intimation from the District Panchayat Officer regarding the disqualification
restore him to his membership.
22. Authority to decide questions of disqualifications of members.
(1)Where an allegation is made that any person who is elected as a member of a Gram Panchayat is
not qualified or has become disqualified under Section 17, Section 18, Section 19 or Section 20 by
any voter or authority to the Executive Authority in writing and the Executive Authority has given
intimation of such allegation to the member through the District Panchayat Officer and such
member disputes the correctness of the allegation so made, or where any member himself entertain
any doubt whether or not he has become disqualified under any of those Sections, such member or
any other member may, and the Executive Authority, at the direction of the Gram Panchayat or the
Commissioner shall, within a period of two months from the date on which such intimation is given
or doubt is entertained, as the case may be, apply to the [District Court] [Substituted by Section 8 of
Act No. 22 of 2002.] having jurisdiction over the area in which the office of the Gram Panchayat is
situated for decision.(2)Pending such decision, the member shall be entitled to act as if he is
qualified or were not disqualified.(3)Where a person ceases to be the Sarpanch or Upa-Sarpanch of
a Gram Panchayat as a consequence of his ceasing to be a member of the Gram Panchayat under
clause (b) of Section 20 and is restored later to his membership of the Gram Panchayat underAndhra Pradesh Panchayat Raj Act, 1994

sub-Section (2) of Section 21, he shall with effect from the date of such restoration, be deemed to
have been restored also to the office ofSarpanch or Upa-Sarpanch, as the case may be.
22A. [ Bar of jurisdiction. [Inserted by Section 9 of Act No. 22 of 2002.]
- No order passed or proceedings taken under the provisions of this Act, shall be called in question
in any Court, in any suit or application; and no injunction shall be granted by any Court except
District Court in respect of any action taken or about to be taken in pursuance of any power
conferred by or under this Act.]
23. Resignation of members, Upa-Sarpanch, Sarpanch.
(1)The Sarpanch, Upa-Sarpanch or any member may resign his office in the manner
prescribed.(2)(a)Notwithstanding that the resignation of a person from the office of Sarpanch has
taken effect under sub-Section (1), the Commissioner may by notification record a finding, with
reasons therefor, that such person is guilty of wilful omission or refusal to carry out, or disobedience
of, the provisions of the Act or any rules, bye-laws, regulations or lawful orders made thereunder or
abuse of the powers vested in him, while he held the office of Sarpanch:Provided that the
Commissioner shall, before issuing such notification give the person concerned an opportunity for
Explanation. -Provided further that no action under this clause shall be taken after the expiration of
one year from the date on which the resignation has taken effect.(b)A person aggrieved by the
notification issued under clause (a) may, within thirty days from the date of publication of such
notification prefer an appeal to the Government and the Government shall in case the appeal is
allowed, cancel such notification.(c)A person in respect of whom a notification was issued under
clause (a) shall, unless the notification is cancelled under clause (b), be ineligible for election as
Sarpanch for a period of three years from the date of publication of such notification.
24. Cessation of Upa-Sarpanch.
- The Upa-Sarpanch shall cease to hold the office as such on the expiry of his term of office as a
member of the Gram Panchayat or on his otherwise ceasing to be such member.
25. Powers and functions of the Sarpanch.
- Save as otherwise provided by or under this Act, the Sarpanch shall-(a)make arrangements for the
election of the Upa-Sarpanch within one month from the date of occurrence of the Vacancy;(b)have
full access to the records of the Gram Panchayat;(c)exercise administrative control over the
executive authority, if there is one, for the purpose of implementation of the resolutions of the Gram
Panchayat or any committee thereof;(d)exercise all the powers and perform all the functions
specifically conferred or imposed on the Sarpanch by this Act or the rules made thereunder;(e)have
power to require any [Executive Authority] [The words executive officer substituted with the words
Executive Authority through out the principal Act by Section 12 of Act No. 22 of 2002.] of any village
within the jurisdiction of the Gram Panchayat to furnish any information on any matter fallingAndhra Pradesh Panchayat Raj Act, 1994

within such categories as may be prescribed in respect of such village or any person or property
therein, required for the purpose of this Act;(f)intimate to the District Panchayat Officer, every case
where any member has incurred any disqualification under Sections 16 to 20; and(g)act only within
the terms of sanction given in any resolution of the Gram Panchayat.
26. Devolution and delegation of Sarpanch's powers and functions and filling
up of vacancies in the office of Sarpanch.
(1)When the office of Sarpanch is vacant, the Upa-Sarpanch shall exercise the powers and perform
the functions of the Sarpanch until a new Sarpanch is declared elected and assumes office.(2)If the
Sarpanch has been continuously absent from jurisdiction for more than fifteen days or is restrained
by an order of a Court from exercising the powers and performing the functions of the Sarpanch, or
is incapacitated for more than fifteen days, his powers and functions during such absence, restraint
or incapacity shall devolve on the Upa-Sarpanch.(3)When the Sarpanch is under suspension or
when the office of Sarpanch is vacant or the Sarpanch has been continuously absent from
jurisdiction for more than fifteen days or is restrained by an order of a Court from exercising the
powers and performing the functions of the Sarpanch or is incapacitated for more than fifteen days
and the Upa-Sarpanch also is under suspension or there is either a vacancy in the office of
Upa-Sarpanch or the Upa-Sarpanch has been continuously absent from jurisdiction for more than
fifteen days or is restrained by an order of a Court from exercising the powers and performing the
functions of the Upa-Sarpanch or is incapacitated for more than fifteen days, the powers and
functions of the Sarpanch shall devolve on a member of Gram Panchayat appointed by the
Commissioner in this behalf.The member so appointed shall be styled as the temporary Sarpanch
and he shall exercise the powers and perform the functions of the Sarpanch until a new Sarpanch or
Upa-Sarpanch is declared elected or either the Sarpanch or the Upa-Sarpanch ceases to be under
suspension or returns to jurisdiction or ceases to be restrained by an order of a Court or recovers
from his incapacity, as the case may be.(4)The Upa-Sarpanch or the temporary Sarpanch appointed
under sub-Section (3) shall report to the District Panchayat Officer, any vacancy in the office of
Sarpanch within one month from the date of occurrence of such vacancy.(5)Subject to such rules as
may be prescribed, the Sarpanch may, by an order in writing, delegate any of his powers and
functions, with such restrictions and conditions as may be specified in the order, to the
Upa-Sarpanch or in case there is a vacancy in the office of Upa-Sarpanch or the Upa-Sarpanch has
been continuously absent from jurisdiction for more than fifteen days or is restrained by an order of
a Court from exercising his powers and performing his functions, to any member.(6)The reference
to the powers and functions of Sarpanch in sub-Sections (1), (2), (3) and (5) shall, where he is also
the executive authority, be deemed to include a reference to his powers and functions as Executive
Authority.(7)The exercise of any powers or the performance of any functions devolving on the
Upa-Sarpanch under sub-Section (2) or delegated to the Upa-Sarpanch or any member under
sub-Section (5), shall be subject to the control and revision by the Sarpanch.
27. Removal of temporary Sarpanch.
- The Commissioner may, by order, for sufficient cause to be specified therein, remove the
temporary Sarpanch appointed under sub-Section (3) of Section 26 after giving him an opportunityAndhra Pradesh Panchayat Raj Act, 1994

to show cause against such removal.
28. Rights of individual members.
(1)Any member may call the attention of the executive authority to any neglect in the execution of
Gram Panchayat work, to any waste of Gram Panchayat property or to the wants of any locality and
may suggest any improvements which may appear desirable and thereupon, the Executive
Authority, shall explain at the next meeting of the Gram Panchayat, the action, if any, that has been
taken or is proposed to be taken with reference to the matter to which attention has been called, or
the improvements suggested by the member.(2)Every member shall have the right to move
resolutions and to interpellate the Sarpanch on matters connected with the administration of the
Gram Panchayat, subject to such rules as may be prescribed.(3)Every member shall have access
during office hours to the records of the Gram Panchayat after giving due notice to the executive
authority, provided that the executive authority, may, for reasons given in writing, forbid such
access:Provided that the member who has been denied such access may prefer an appeal to the
Extension Officer (Panchayats) whose decision thereon shall be final.
29. No Sarpanch, Upa-Sarpanch or members to receive remuneration.
- No Sarpanch, Upa-Sarpanch or member shall receive, or be paid from the funds at the disposal of
or under the control of the Gram Panchayat, any salary or other remuneration for services rendered
by him whether in his capacity as such or in any other capacity. Nothing in this Section shall prevent
the Sarpanch from receiving any honorarium, fixed by order, by the Government.
30. Appointment of Executive Authoritys for certain Gram Panchayats.
(1)A whole time or a part-time Executive Authority shall be appointed by the Commissioner for any
Gram Panchayat or for any group of contiguous Gram Panchayats which may be notified by him in
this behalf:Provided that before notifying a group of Gram Panchayats under this sub-Section, the
Commissioner shall obtain the approval of the Government.(2)In the case of every Gram Panchayat
not so notified and also in the case of any Gram Panchayat so notified, if there is no Executive
Authority in-charge, the Sarpanch of the Gram Panchayat shall, subject to such rules as may be
prescribed, exercise the powers and perform the functions of the Executive Authority.(3)Save as
otherwise prescribed, no Executive Authority appointed under sub-Section (1) shall undertake any
work unconnected with his office without the sanction of the Government.(4)The Executive
Authority shall be subordinate to the Gram Panchayat.
31. Functions of Executive Authority.
- [(1) The Panchayat Secretary, with the approval of, or on the direction of the Sarpanch, convene
the meetings of the Gram Panchayat so that at least one meeting of the Gram Panchayat is held
every month and if he fails to discharge that duty, with the result that no meeting of the Gram
Panchayat is held within a period of ninety days from the last meeting he shall be liable toAndhra Pradesh Panchayat Raj Act, 1994

disciplinary action under the relevant rules:Provided that where the Sarpanch fails to give his
approval for convening the meeting so as to hold a meeting within the period of ninety days
aforesaid, the Panchayat Secretary shall himself convene the meeting in the manner prescribed.]
[Substituted by Section 10 of Act No. 22 of 2002.](2)The Executive Authority shall ordinarily attend
to the meetings of the Gram Panchayat or of any committee thereof and shall be entitled to take part
in the discussions thereat, but he shall not be entitled to vote or to move any resolution.
32. Functions of the Executive Authority.
- The Executive Authority shall -(a)be responsible for implementing the resolutions of the Gram
Panchayat and of the Committee thereof:Provided that where the Executive Authority considers that
a resolution has not been legally passed or is in excess of the powers conferred by this Act or that if
carried out, it is likely to endanger human life or health or the public safety, the Executive Authority
shall:(i)where he is the Sarpanch directly;(ii)where he is not the Sarpanch, through the Sarpanch,
refer the matter to the Commissioner for orders, and his decision shall be final;(b)control all the
officers and servants of the Gram Panchayat;(c)exercise all the powers and perform all the functions
specifically conferred or imposed on the Executive Authority by or under this Act and subject to all
restrictions and conditions imposed by or under this Act, exercise the executive power for the
purpose of carrying out the provisions of this Act and be directly responsible for the due fulfilment
of the purpose thereof.
33. Emergency powers of Sarpanch.
- In case of emergency, the Sarpanch may, in consultation with the Executive Authority, if any,
direct the execution of any work or the doing of any act which requires the sanction of the Gram
Panchayat or any of its committees and the immediate execution or the doing of which is, in his
opinion, necessary for the service or safety of the general public, but he shall report the action taken
under this Section and the reasons thereof to the Gram Panchayat or the concerned committee at its
next meeting:Provided that he shall not direct the execution of any work or the doing of any act in
contravention of any order of the Government.
34. Exercise of functions of Executive Authority by Health Officer in certain
cases.
- The Commissioner may, by general or special order, authorise the Health Officer of the District to
exercise such of the functions of an Executive Authority under this Act in such area and subject to
such restrictions and conditions and to such control and revision as may be specified in such order.
35. Delegation of functions of Executive Authority.
- Subject to such restrictions and control as may be prescribed, the Executive Authority may, by an
order in writing, delegate any of his functions as such -(i)if he is the Sarpanch, to the Upa-Sarpanch
and in the absence of the Upa-Sarpanch, to any other member;(ii)if he is not the Sarpanch, to theAndhra Pradesh Panchayat Raj Act, 1994

Sarpanch; in the absence of the Sarpanch to the Upa-Sarpanch and in the absence of both Sarpanch
and Upa-Sarpanch to any other member.The exercise or discharge of any functions so delegated
shall be subject to such restrictions and conditions as may be laid down by the Executive Authority
and shall also be subject to his control and revision.
36. Officers and other employees of Gram Panchayat.
(1)Subject to such rules as may be made under the proviso to Article 309 of the Constitution, the
Government shall fix and may alter the number, designations and grades of and the salaries, fees
and allowances payable to such officers and other employees of a Gram Panchayat as may be
prescribed.(2)The Government shall pay, out of the Consolidated Fund of the State, the salaries,
allowances, leave allowances, pension and contributions, if any towards provident fund or
pension-cum- provident fund of the officers and other employees referred to in sub-Section
(1).(3)The classification and methods of recruitment, conditions of service, pay and allowances, and
discipline and conduct of the officers and employees referred to in sub-Section (1) shall be regulated
in accordance with such rules as may be made under the proviso to Article 309 of the
Constitution.(4)Every holder of the post specified in sub-Section (1), who is appointed immediately
before the commencement of this Act, shall, notwithstanding anything in this Act, continue to hold
such post, subject to such rules as may be made under the proviso to Article 309 of the Constitution,
and until provision in that behalf is so made, the law for the time being in force regulating the
recruitment and conditions of service applicable to such holder immediately before such
commencement shall continue to apply to such holder.(5)All officers and other employees of the
Gram Panchayat shall be subordinate to the Gram Panchayat.(6)The Government may, from time to
time by order, give such directions to any Gram Panchayat or any officer, authority or person
thereof, as may appear to them to be necessary for the purpose of giving effect to the provisions of
this Section and Section 30; and the Gram Panchayat, officer, authority or person shall comply with
all such directions.(7)The provisions of this Section shall also apply to the public health
establishment of Gram Panchayats, notwithstanding anything in the Andhra Pradesh (Andhra Area)
Public Health Act, 1939 (Act 3 of 1939) or any other law similar thereto for the time being in force in
the State.(8)Subject to such rules as may be made under the proviso to Article 309 of the
Constitution the Commissioner may appoint such engineering and other staff as he considers
necessary for the purposes of any Gram Panchayat or two or more Gram Panchayats.
37. Presidency at meetings.
- Save as otherwise provided by or under this Act, every meeting of a Gram Panchayat shall be
presided over by the Sarpanch, in his absence by the Upa-Sarpanch and in the absence of both
Sarpanch and Upa-Sarpanch by a member chosen by the meeting to preside for occasion.
38. Minutes of proceedings.
- The minutes of the proceedings at every meeting of a Gram Panchayat shall be recorded and action
taken thereon in the manner prescribed.Andhra Pradesh Panchayat Raj Act, 1994

39. Power to call for records.
- A Gram Panchayat or a committee thereof may, at any of its meetings, require the Executive
Authority to furnish any document in his custody, in so far as such document relates to any of the
subjects included in the agenda for such meeting and the Executive Authority shall comply with
every such requisition.
40. Beneficiary committees and functional Committees.
(1)For every Gram Panchayat there shall be a Committee by name "Beneficiary Committee" for the
execution of the works of the Gram Panchayat. The composition, including co-option of persons who
are not members of the Gram Panchayat and the powers and functions and other related matters of
the Beneficiary Committee, shall be such as may be prescribed.(2)For every Gram Panchayat there
shall be constituted functional committees respectively for agriculture, public health, water supply,
sanitation, family planning, education and communication and for any other purposes of this
Act.(3)The constitution including co-option of persons who are not members of the Gram Panchayat
and powers of a functional committee shall be in accordance with such rules as may be prescribed.
41. Proceedings of Gram Panchayats and Committees.
(1)The proceedings of every Gram Panchayat and of all committees thereof shall be governed by
such rules as may be prescribed and by regulations, not inconsistent with such rules or the
provisions of this Act, made by the Gram Panchayat with the approval of the Commissioner.(2)The
Commissioner shall have power to add to, omit or alter any regulations submitted for his approval
under sub-Section (1).(3)The rules that may be prescribed under sub-Section (1) may provide for
preventing any member or Sarpanch or any member or Chairman of a Committee from voting on, or
taking part in the discussion of any matter in which apart from its general application to the public,
he has any direct or indirect pecuniary interest whether by himself or through some other person, or
from being present or presiding at any meeting of the Gram Panchayat or of the committee during
the discussion of any such matter.
42. Appointment of Joint Committee.
- A Gram Panchayat may, and if so required by the Government shall, join with one, or more than
one, other local authority in constituting a joint committee for any purpose in which they are
interested or for any matter for which they are jointly interested or for any matter for which they are
jointly responsible. The composition, powers and functions and other incidental and consequential
matters shall be such as may be prescribed.
43. Administration report.
- The Executive Authority of every Gram Panchayat shall prepare a report on its administration for
each year, as soon as may be after the close of such year and not later than prescribed date, in suchAndhra Pradesh Panchayat Raj Act, 1994

form and with such details as may be prescribed and place it before the Gram Panchayat for its
consideration.
44. Powers of inspecting and superintending Officers and of the Government.
(1)The Commissioner shall supervises the administration of all Gram Panchayats in the State and
shall also exercise the powers and perform the functions vested in him by or under this
Act.(2)(a)The Government may appoint such other officers as they may consider necessary for the
purpose of inspecting or superintending the operations of all or any of the Gram Panchayats
constituted under this Act.(b)In particular and without prejudice to the generality of the foregoing
provision, the Government may appoint District Panchayat Officers, Divisional Panchayat Officers
and Extension Officers (Panchayats) and define the territorial jurisdiction of each such
officer.(c)The Government shall have power to regulate the classification, methods of recruitment,
conditions of service, salary and allowances and discipline and conduct of the officers referred to in
clauses (a) and (b) and of the members of their establishment.(3)The cost of the officers and the
members of the establishment aforesaid shall be paid out of the Consolidated Fund of the
State.(4)The District Panchayat Officers, the Divisional Panchayat Officers and the Extension
Officers (Panchayats) shall exercise such powers and perform such functions as may be prescribed,
or as may be delegated to them under this Act.(5)The Commissioner or the District Collector or any
officer appointed under sub-Section (2) or any other officer or person whom the Government or the
Commissioner or the District Collector may empower in this behalf, may enter on and inspect, or
cause to be entered on and inspected,-(a)any immovable property or any work in progress under the
control of any Gram Panchayat or Executive Authority;(b)any school, hospital, dispensary,
vaccination station, country, or other institutions maintained, by or under the control of, any Gram
Panchayat and any records, registers or other documents kept in such institution;(c)the office of any
Gram Panchayat and any records, registers or other documents kept therein. Gram Panchayats and
their Sarpanches, executive authorities, officers and servants shall be bound to afford to the officers
and persons aforesaid, such access, at all reasonable times, to Gram Panchayat property or
premises, and all documents as may, in the opinion of such officers or persons, subject to such rules
as may be prescribed, be necessary to enable them to discharge their duties, under this
Section.(6)The Commissioner or any officer or person whom the Government, or the Commissioner
may empower in this behalf may,-(a)direct the Gram Panchayat to make provision for and to
execute or provide any public work or amenity or service of the description referred to in Section
45;(b)call for any record, register or other document in the possession, or under the control, of any
Gram Panchayat or Executive Authority;(c)require any Gram Panchayat, or Executive Authority to
furnish any return, plan, estimate, statement, account or statistics;(d)require any Gram Panchayat,
or Executive Authority to furnish any information or report on any matter connected with such
Gram Panchayat;(e)record in writing for the consideration of any Gram Panchayat, or Executive
Authority any observations in regard to its or his proceedings or functions.
Chapter II
Powers, Functions and Property of Gram PanchayatsAndhra Pradesh Panchayat Raj Act, 1994

45. Duty of Gram Panchayat to Provide for Certain Matters.
(1)Subject to the provisions of this Act and the rules made thereunder, it shall be the duty of a Gram
Panchayat within the limits of its funds to make reasonable provisions for carrying out the
requirements of the village in respect of the following matters, namely:-(i)the construction, repair
and maintenance of all buildings vested in the Gram Panchayat and of all public roads in the village
(other than the roads vested in the [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act
No. 41 of 2006, dated 23.9.2006.] and [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No.
41 of 2006, dated 23.9.2006.] and the roads classified by the Government as National and State
Highways) and of all bridges, culverts, road dams and causeways on such roads;(ii)the lighting of
public roads and public places;(iii)the construction of drains and their maintenance and the disposal
of drainage water and sullage;(iv)the cleaning of streets, the removal of rubbish heaps,jungle growth
and prickly-pear, filling in of the disused wells, insanitary ponds, pools, ditches, pits or hollows and
other improvements of the sanitary condition of the village;(v)the provision of public latrines and
arrangements to clean latrines, whether public or private;(vi)the opening and maintenance of
cremation and burial-grounds, and the disposal of unclaimed dead bodies of human beings or of
animals;(vii)preventive and remedial measures connected with any epidemic or with
malaria;(viii)the sinking and repairing of wells, the excavation, repair and maintenance of ponds or
tanks and the construction and maintenance of water works, for the supply of water for washing and
bathing purposes and of protected water for drinking purposes;(ix)the conservation of manurial
resources, preparation of compost and sale of manure;(x)the registration of births and
deaths;(xi)the establishment and maintenance of cattle ponds; and(xii)all other matters expressly
declared obligatory by or under this Act or any other law.(2)Apart from the matters specified in
sub-Section (1), the Government may, subject to such rules as may be made in this behalf, entrust
the Gram Panchayats with any functions in relation to the subjects specified in Schedule-I.(3)The
Gram Panchayats shall do resource planning at village level.(4)No suit for damages for failure or for
enforcement of the duty to make provision in respect of any of the matters specified in sub-Section
(1) shall be maintainable against any Gram Panchayat, Executive Authority, officer or servant of the
Gram Panchayat.
46. Power of Gram Panchayat to provide for certain other matters.
- Subject to the provisions of this Act and the rules made thereunder, a Gram Panchayat may also
make such provision as it thinks fit for carrying out the requirements of the village in respect of the
following matters, namely:-(i)the construction and maintenance of dharmashalas, sarais and rest
houses for travellers;(ii)the planting and preservation of groves and trees on the sides of roads and
other public places;(iii)the promotion and development of pre-primary education, elementary
education, social and health education, cottage industries and trade;(iv)the establishment and
maintenance of dispensaries and the payment of subsidies to rural medical practitioners;(v)the
establishment and maintenance of wireless receiving sets, play grounds, akhadas, clubs and other
centres for recreation and physical culture;(vi)the laying and maintenance of parks;(vii)the
establishment and maintenance of libraries and reading rooms;(viii)the provision of relief to the
crippled, the destitute and the sick;(ix)the establishment and maintenance of nurseries and stores of
improved seeds and agricultural implements of the production and distribution of improved seeds,Andhra Pradesh Panchayat Raj Act, 1994

pesticides and Insecticides and the holding of agricultural shows including cattle shows;(x)the
propagation of improved methods of cultivation in the village including laying out of demonstration
plots with a view to increasing production;(xi)the encouragement of co-operative management of
lands in the village and the organisation of joint co-operative farming; and the promotion of
co-operatives for the manufacture of bricks, tiles, hinges, doors, windows, rafters or other building
materials as provided in the village housing project schemes sponsored by the Central
Government;(xii)the establishment and maintenance of ware-houses and granaries;(xiii)the
establishment and maintenance of cattle sheds;(xiv)the extension of village sites;(xv)the
improvement of cattle including purchase and maintenance of stud bulls and the provision of
veterinary relief;(xvi)the control of fairs, jataras and festivals;(xvii)the organisation of voluntary
labour for community development works in the village;(xviii)the establishment and maintenance of
maternity and child welfare centres;(xix)the organisation of watch and ward;(xx)the provision of
relief against famine or other calamities;(xxi)the destruction of stray and owner-less dogs;(xxii)the
preparation of statistics of unemployment;(xxiii)the opening and maintenance of public
markets;(xxiv)the opening and maintenance of public slaughter houses;(xxv)the implementation of
land reform measures in the village including consolidation of holdings and soil
conservations;(xxvi)the setting up of organisation to promote good will and social harmony between
different communities, the removal or untouchability, the provision of house sites for harijans, the
eradication of corruption, the prohibition of or temperance in the consumption of intoxicating
drinks or drugs which are injurious to health and the discouragement of gambling and
litigation;(xxvii)other measures of public utility calculated to promote the safety, health,
convenience, comfort or moral, social and material well-being of the residents of the village.
47. Maintenance of common dispensaries, child welfare centres etc.
- Subject to the provisions of this Act and the rules made thereunder, two or more Gram Panchayats
may establish and maintain common dispensaries, child welfare centres and institutions of such
other kind as may be prescribed.
48. Transfer of management of forests to Gram Panchayat.
(1)Subject to any law for the time being in force the Government may, by notification, transfer to any
Gram Panchayat with its consent and subject to such conditions as may be agreed upon, the
management and maintenance of a forest adjacent to the village; and they may by a like notification,
withdraw management and maintenance of such forest from the Gram Panchayat after giving an
opportunity to the Gram Panchayat to make its representation.(2)When the management and
maintenance of any forest is transferred to Gram Panchayat under sub-Section (1), the income
derived by the Gram Panchayat from the forest under its management and maintenance or the
expenditure incurred by the Gram Panchayat, for such a management and maintenance shall be
apportioned between the Government and the Gram Panchayat in such manner as the Government
may, by order, determine.Andhra Pradesh Panchayat Raj Act, 1994

49. Transfer to Panchayats of institutions or works.
(1)Subject to such rules as may be prescribed, the Government, the District Collector or the Revenue
Divisional Officer, [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006,
dated 23.9.2006.] or [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated
23.9.2006.] or any person or body of persons, may transfer to the Gram Panchayat, with its consent
and subject to such conditions as may be agreed upon, the management of any institution, or the
execution or maintenance of any work, or the exercise of any power or the discharge of any duty,
whether within or without the village, and whether provided for in this Act or not.(2)When the
management of any institution is transferred to the Gram Panchayat under sub-Section (1), all
property, endowments and funds belonging thereto, shall be held by the Gram Panchayat in trust for
the purposes to which such property, endowments and funds were lawfully applicable at the time of
such transfer.
50. Power of Commissioner of Land Revenue to transfer, resume control of
endowments and inams.
(1)(a)Subject to the control of the Government, the Commissioner of Land Revenue may, by
notification, make over to a Gram Panchayat, with its consent, the management and
superintendence of any charitable endowment in respect of which powers and duties attached to the
said Commissioner under the provisions of the Andhra Pradesh Escheats and Bona Vacantia Act,
1974 (Act 35 of 1974) and thereupon all powers and duties attaching to the Commissioner in respect
thereof shall attach to the Gram Panchayat as if it had been specifically named in the said
Regulation or law, and the Gram Panchayat shall manage and superintend such endowment.(b)The
Commissioner of Land Revenue may of his own motion, and shall on a direction from the
Government, by notification in the Andhra Pradesh Gazette, resume the management and
superintendence of any endowment made over to a Gram Panchayat under clause (a) and upon such
resumption, all the powers and duties attaching to the Gram Panchayat in respect of the endowment
shall cease and determine.(2)The Government may assign to a Gram Panchayat with its consent a
charitable inam resumed by the Government or any authority, provided that the net income from
such inam can be applied exclusively to any purpose to which the funds of such Gram Panchayat
may be applied; and may revoke any assignment so made.(3)No order of resumption under clause
(b) of sub-Section (1) or of revocation under sub-Section (2), shall be passed unless the Gram
Panchayat has had an opportunity of making its representation.
51. Limitation of power to accept donations and trusts.
- A Gram Panchayat may accept donations for, or trust relating exclusively, to the furtherance of any
purpose to which its funds may be applied.Andhra Pradesh Panchayat Raj Act, 1994

52. Maintenance of cattle pounds.
(1)Notwithstanding anything in the Cattle Trespass Act, 1871 (Central Act 1 of 1871) -(i)any cattle
pound so transferred to a Gram Panchayat, or a cattle pound established by a Gram Panchayat
under this Act, shall be maintained and controlled by the Gram Panchayat;(ii)a pound keeper for
every cattle pound referred to in clause (i), shall be appointed by the Gram Panchayat; and(iii)all
sums on account of fines and surplus unclaimed sale proceeds realised under the Cattle Trespass
Act, 1871 in respect of any cattle pound referred to in clause (i) shall be credited to the Gram
Panchayat Fund.(2)Subject to the provisions of sub-Section (1) the provisions of the Cattle Trespass
Act, 1871 shall, as far as may be applicable to the cattle pounds referred to in clause (i) of
sub-Section (1).
53. Vesting of public roads in Gram Panchayat.
(1)All public roads in any village, other than National Highways, State High Ways and Roads vesting
in [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or
[Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.]
shall vest in the Gram Panchayat together with all pavements, stones and other materials thereof, all
works, materials and other things provided therefor, all sewers, drains drainage works, tunnels and
culverts, whether made at the cost of the Gram Panchayat Fund or otherwise, in along side or under
such roads, and all works, materials and things appertaining thereto:Provided that the Gram
Panchayat shall take steps to remove encroachments on, and prevent, un-authorised use of, any
road other than a National Highway passing through the Gram Panchayat.(2)The Government may,
after giving an opportunity to the Gram Panchayat of making a representation by notification,
exclude from the operation of this Act any such public road, sewer, drain, drainage work, tunnel or
culvert, and may also modify or cancel such notification.
54. Collected sewage etc., belong to Gram Panchayat.
- All rubbish, sewage, filth and other matter collected by a Gram Panchayat under this Act shall
belong to it.
55. Vesting of Communal Property or Income in Gram Panchayat.
- Any property or income which by custom belongs to or has been administered for the benefit of the
villagers in common or the holders in common of village land generally or of lands of a particular
description or of lands under a particular source of irrigation, shall vest in the Gram Panchayat and
be administered by it for the benefit of the villagers or holders aforesaid.
56. Maintenance of irrigation works, execution of kudimaramat etc.
(1)(a)Subject to such conditions and control as may be prescribed, the Government may transfer to
any Gram Panchayat the protection and maintenance of any village irrigation work, the regulation ofAndhra Pradesh Panchayat Raj Act, 1994

turns of irrigation, or of distribution of water from any such irrigation work to the field depending
on it.(b)Subject to such restriction and control as may be prescribed, the fishery rights in minor
irrigation tanks and the right to auction weeds and reeds in such tanks and the right to plant trees
on the bunds of such tanks and enjoy the usufruct thereof shall vest in the Gram Panchayat.(2)The
Gram Panchayat shall have power, subject to such restrictions and control as may be prescribed, to
execute kudimaramat in respect of any irrigation source in the village and to levy such fee and on
such basis for the purposes thereof as may be prescribed:Provided that nothing in this Section shall
be deemed to relieve the village community or any of its members of its or his liability under the
Andhra Pradesh (Andhra Area) Compulsory Labour Act, 1858 (Central Act 1 of 1858) or any other
law similar thereto for the time being in force in respect of any irrigation source in the village, in
case the Gram Panchayat makes default in executing the kudimaramat in respect of that irrigation
source.
57. Vesting of the management of ferries in Gram Panchayats etc.
- Notwithstanding anything in the Andhra Pradesh (Andhra Area) Canals and Public Ferries Act,
1890 (Act 2 of 1890) and the Andhra Pradesh (Telangana Area) Ferries Act, 1314 Fasli (Act 2 of 1314
F), the management of a public ferry in the Andhra Area, and of a Government ferry in the
Telangana area other than a ferry mentioned in sub-Section (2) shall vest -(a)in the case of a ferry
connecting any public road under the management of a Gram Panchayat and lying wholly within the
jurisdiction of that Gram Panchayat, in such Gram Panchayat and in the case of a ferry connecting
any public road under the management of a Gram Panchayat and lying within the jurisdiction of
more than one Gram Panchayat, in a joint committee of the Gram Panchayats concerned;(b)in case
of a ferry connecting any public road under the management of a [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] and lying wholly within the
jurisdiction of that [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006,
dated 23.9.2006.], in such [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of
2006, dated 23.9.2006.] and in the case of ferry connecting any public road under the management
of a [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.] and lying within the jurisdiction of more than one [Mandal Praja Parishad] [Substituted
'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.], in a joint committee of the [Mandal
Praja Parishads] [Substituted 'Mandal Parishads' by Act No. 41 of 2006, dated 23.9.2006.]
concerned;(c)in the case of a ferry connecting any public road under the management of a Gram
Panchayat or a [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.] and lying partly within the jurisdiction of a municipality, in a joint committee of the
Gram Panchayat or a [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of
2006, dated 23.9.2006.] as the case may be, and the Municipality concerned.(2)The Government
may, subject to such conditions as may be agreed upon transfer the management of any such ferry
connecting a National Highway or a State Highway and lying wholly within the jurisdiction of a
Gram Panchayat or a [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of
2006, dated 23.9.2006.] to such Gram Panchayat or [Mandal Praja Parishad] [Substituted 'Mandal
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] and in case the said ferry is lying within the
jurisdiction of more than one Gram Panchayat or [Mandal Praja Parishad] [Substituted 'Mandal
Parishad' by Act No. 41 of 2006, dated 23.9.2006.], to the [Zilla Praja Parishad] [Substituted 'ZillaAndhra Pradesh Panchayat Raj Act, 1994

Parishad' by Act No. 41 of 2006, dated 23.9.2006.] concerned.(3)The constitution and powers of the
procedure to be adopted by any joint committee referred to in sub-Section (1) and the method of
resolving any difference of opinion arising between the local authorities concerned in connection
with the works of such committee shall be in accordance with such rules as may be
prescribed.(4)The income realised by a [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No.
41 of 2006, dated 23.9.2006.], [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No.
41 of 2006, dated 23.9.2006.] or a Gram Panchayat from any ferry under its management under
sub-Section (1) or sub-Section (2) shall form part of its funds. The income realised by joint
committee referred to in sub-Section (1) or by a [Zilla Praja Parishad] [Substituted 'Zilla Parishad'
by Act No. 41 of 2006, dated 23.9.2006.] under sub-Section(2)from a ferry under its management
shall be apportioned in equal shares between the local authorities concerned and the amount so
apportioned shall form part of the funds of such local authorities.Explanation. - For the purpose of
this Section, the expression 'Public Ferry' in relation to the Andhra Area, and expression
'Government Ferry' in relation to Telangana Area, shall respectively have the meaning assigned to
them in the Andhra Pradesh (Andhra Area) Canals and Public Ferries Act, 1890 (Act 2 of 1890) and
the Andhra Pradesh (Telangana Area) Ferries Act, 1314 Fasli (Act 2 of 1314 F).
58. Certain Government porambokes to vest in Gram Panchayat etc.
(1)The following porambokes namely, grazing grounds, threshing floors, burning and burial
grounds, cattle stands, cart stands and topes, which are at the disposal of the Government and are
not required by them for any specific purpose shall vest in the Gram Panchayat subject to such
restrictions and control as may be prescribed.(2)The Government may, at any time by notification in
the Andhra Pradesh Gazette, direct that any porambokes referred to in sub-Section (1) shall cease to
vest in the Gram Panchayat if it is required by them for any specific purpose and thereupon such
porambokes shall vest in the Government.(3)The Gram Panchayat shall have power, subject to such
restrictions and control as may be prescribed, to regulate the use of any other poramboke which is at
the disposal of the Government, if the Gram Panchayat is authorised in that behalf by an order of
the Government.(4)The Gram Panchayat may, subject to such restrictions and control as may be
prescribed, plant trees on any poramboke the use of which is regulated by it under sub-Section
(3).Explanation. - If any question arises whether a land is a poramboke or not, for the purposes of
this Section, the question shall be referred to the Government whose decision thereon shall be final.
59. Acquisition of immovable property required by Gram Panchayat.
- Any immovable property which any Gram Panchayat may require for the purpose of this Act or any
rules made thereunder may be acquired under the provisions of the Land Acquisition Act, 1894
(Central Act 1 of 1894) and on payment of the compensation awarded under the said Act, in respect
of such property and of any other charges incurred in acquiring it, the said property shall vest in the
Gram Panchayat.Andhra Pradesh Panchayat Raj Act, 1994

Chapter III
Taxation and Finance
60. Taxes leviable by Gram Panchayats.
(1)A Gram Panchayat shall levy in the village,-(a)a House tax;(b)kolagaram, or katarusum that is to
say, tax on the village produce sold in the village by weight, measurement or number subject to such
rules as may be prescribed;(c)such other tax as the Government may, by notification, direct any
Gram Panchayat or class of Gram Panchayats to levy subject to such rules as may be
prescribed:Provided that no such notification shall be issued and no such rule shall be made except
with the previous approval of the Legislative Assembly of the State.(2)A duty shall also be levied on
transfers of property situated in the area under the jurisdiction of the Gram Panchayat in
accordance with the provisions of Section 69.(3)Subject to such rules as may be prescribed the Gram
Panchayat may also levy in the village,-(i)a vehicle tax;(ii)a tax on agricultural land for a specific
purpose;(iii)a land-cess at the rate of two naya paise in the rupee on the annual rental value of all
occupied lands which are not occupied by or adjacent and appurtenant to buildings;(iv)fees for use
of porambokes or communal lands under the control of the Gram Panchayat;(v)fees for the
occupation of building including chavadies and sarais under the control of the Gram
Panchayat.(4)Every Gram Panchayat may also levy a duty in the form of a surcharge on the
seigniorage fees collected by the Government on materials other than minerals and minor minerals
quarried in the village:Provided that the rate at which such duty shall be levied shall be fixed by the
Gram Panchayat with the previous approval of the Government.(5)Every Gram Panchayat may, with
the previous approval of the prescribed authority also levy, in respect of lands lying within its
jurisdiction, a duty in the form of a surcharge at such rate, not exceeding twenty-five naya paise in
the rupee, as may be fixed by the Gram Panchayat,-(a)in the Andhra Area, on the land cess, leviable
under Section 78 of the Andhra Pradesh(Andhra Area) District Boards Act, 1920 (Act XIV of 1920)
and on the education tax leviable under Section 37 of the Andhra Pradesh Education Act, 1982 (Act 1
of 1982);(b)in the Telangana Area, on the local cess, leviable under Section 135 of the Andhra
Pradesh (Telangana Area) District Boards Act, 1955 (Act 1 of 1956) and on the education tax leviable
under Section 37 of the Andhra Pradesh Education Act, 1982 (Act 1 of 1982).(6)Any resolution of a
Gram Panchayat abolishing an existing tax or reducing the rate at which a tax is levied shall not be
carried into effect without the previous approval of the Commissioner.
61. House Tax.
(1)The house tax referred to in clause (a) of sub-Section (1) of Section 60 shall subject to such rules
as may be prescribed, be levied on all houses in the village on any one of the following basis,
namely:-(a)annual rental value, or(b)capital value, or(c)such other basis as may be
prescribed:Provided that no house tax shall be levied on poultry sheds and annexes thereto which
are essential for running the poultry farms.(2)The house-tax shall, subject to the prior payment of
the land revenue, if any, due to the Government in respect of the site of the house be a first charge
upon the house and upon the movable property, if any, found within or upon the same and
belonging to the person liable to pay such tax.(3)The house-tax shall be levied every year and shall,Andhra Pradesh Panchayat Raj Act, 1994

save as otherwise expressly provided in the rules made under sub-Section (1) be paid by the owner
within thirty days of the commencement of the year. It shall be levied at such rates as may be fixed
by the Gram Panchayat, not being less than the minimum rates and not exceeding the maximum
rates, prescribed in regard to the basis of levy adopted by the Gram Panchayat.(4)The Government
may make rules providing for-(i)the exemption of special classes of houses from the tax;(ii)the
manner of ascertaining the annual or capital value of houses or the categories into which they fall for
the purposes of taxation;(iii)the person who shall be liable to pay the tax and the giving of notice of
transfer of houses;(iv)the grant of exemptions from the tax on the ground of poverty;(v)the grant of
vacancy and other remissions; and(vi)the circumstances in which, and the conditions subject to
which houses constructed, reconstructed or demolished, or situated in areas included in or excluded
from the village, during any year, shall be liable or cease to be liable to the whole or any portion of
the tax.(5)If the occupier of a house pays the house-tax on behalf of the owner thereof, such occupier
shall be entitled to recover the same from the owner and may deduct the same from the rent then or
thereafter due by him to the owner.
62. Levy of House Tax on a direction by Government.
(1)The Government may, by order published in the Andhra Pradesh Gazette, for special reasons to
be specified in such order direct any Gram Panchayat to levy the house-tax referred to in clause (a)
of sub-Section (1) of Section 60 at such rates and with effect from such date not being earlier than
the first day of the year immediately following that in which the order is published, as may be
specified in the order.Such direction may be issued in respect of all buildings in a Gram Panchayat
or in respect of only such buildings belonging to the undertakings owned or controlled by the State
Government or Central Government and the buildings belonging to the State Government as may be
specified therein.(2)When an order under sub-Section (1) has been published, the provisions of this
Act relating to house-tax shall apply as if the Gram Panchayat had, on the date of publication of such
order, by resolution determined to levy the tax at the rate and with effect from the date specified in
the order, and as if no other resolution of the Gram Panchayat under Section 60 determining the
rate at which and the date from which the house-tax shall be levied, had taken effect.(3)A Gram
Panchayat shall not alter the rate at which the house-tax is levied in pursuance of an order under
sub-Section (1) or abolish such tax except with the previous sanction of the Government.
63. Tax on advertisement.
- Every person who erects, exhibits, fixes or retains upon or over any land, building, wall, hoarding
or structure any advertisement or who displays any advertisement to public view in any manner
whatsoever, in any place whether public or private, shall pay on every advertisement which is so
erected, exhibited, fixed, retained, or displayed to public view, a tax calculated at such rates and in
such manner and subject to such exemptions as the Gram Panchayat may with the approval of the
[Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] by
resolution determine:Provided that the rates shall be subject to the maximum and minimum
prescribed by the Government in this behalf:Provided further that no tax shall be levied under this
Section on any advertisement or a notice-(a)of a public meeting; or(b)of an election to any
legislative body or to the Gram Panchayat, [Mandal Praja Parishad] [Substituted 'Mandal Parishad'Andhra Pradesh Panchayat Raj Act, 1994

by Act No. 41 of 2006, dated 23.9.2006.] or [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by
Act No. 41 of 2006, dated 23.9.2006.]; or(c)of a candidature in respect of such an election:Provided
also that no such tax shall be levied on any advertisement which is not a sky-sign and which-(a)is
exhibited within the window of any building; or(b)relates to the trade or business carried on within
the land or building upon or over which such advertisement is exhibited or to any sale or letting of
such land or building or any effects therein or to any sale, entertainment or meeting to be held upon
or in the same land or building; or(c)relates to the name of the land or building upon or over which
the advertisement is exhibited or to the name of the owner or occupier of such land or building;
or(d)relates to the business of any railway administration; or(e)is exhibited within any railway
station or upon any wall or other property of a railway administration except any portion of the
surface of such wall or property fronting any street.Explanation I. - The word "structure" in this
Section shall include any movable board on wheels used as an advertisement or an advertisement
medium.Explanation II. - The expression "sky-sign" shall in this Section, mean any advertisement,
supported on or attached to any post, pole, standard framework or other support wholly or in part
upon or over any land, building, wall or structure which, or any part of which shall be visible against
the sky from some point in any public place and includes all and every part of any such post, pole,
standard framework or other support. The expression "sky-sign" shall also include any balloon,
parachute or other similar device employed wholly or in part for the purposes of any advertisement
upon or over any land, building or structure or upon or over any public place but shall not
include,-(a)any flagstaff, pole, vane or weathercock unless adopted or used wholly or in part for the
purpose of any advertisement; or(b)any sign or any board, frame or other contrivance securely fixed
to or on the top of the wall or parapet of any building or on the cornice or on blocking course of any
wall or to the ridge of a roof:Provided that such board, frame or other contrivance be of one
continuous face and not open work, and does not extend in height more than one meter above any
part of the wall or parapet or ridges, to, against or on which it is fixed or supported; or(c)any
advertisement relating to the name of the land or building upon or over which the advertisement is
exhibited or to the name of the owner or occupier of such land or building; or(d)any advertisement
relating exclusively to the business of a railway administration and placed wholly upon or over any
railway, railway station, yard, platform or station approach belonging to railway administration and
so placed that it cannot fall into any street or public place; or(e)any notice of land or building to be
sold or let, placed upon such land or building.Explanation III. - "Public place" shall, for the purpose
of this Section mean any place which is open to the use and enjoyment of the public, whether it is
actually used or enjoyed by the public or not.
64. Prohibition of advertisement without written Permission of Executive
Authority.
(1)No advertisement shall be erected, exhibited, fixed or retained upon or over any land, building,
wall, boarding or structure within the Gram Panchayat or shall be displayed in any manner
whatsoever in any place without the written permission of the Executive Authority.(2)The Executive
Authority shall not grant such permission, if-(i)the advertisement contravened any bye-law made by
the Gram Panchayat under Section 270;(ii)the tax, if any, due in respect of the advertisement has
not been paid.(3)Subject to the provisions of sub-Section (2) in the case of an advertisement liable to
the advertisement tax, the Executive Authority shall grant permission for the period to which theAndhra Pradesh Panchayat Raj Act, 1994

payment of the tax relates and no fees shall be charged in respect of such permission:Provided that
the provisions of this Section shall not apply to any advertisement relating to the business of a
railway administration erected, exhibited, fixed or retained on the premises of such administration.
65. Permission of the Executive Authority to become void in certain cases.
- The permission granted under Section 64 shall become void in the following cases, namely:-(a)if
the advertisement contravenes any bye-law made by the Gram Panchayat under Section 270;(b)if
any addition to the advertisement be made except for the purpose of making it secure under the
direction of Engineer of the Panchayat Raj and Rural Development Department or the [Mandal
Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.]
Development Officer;(c)if any material change be made in the advertisement or any part
thereof;(d)if the advertisement or any part thereof falls otherwise than through accident;(e)if any
addition or alteration be made to or in the building, wall or structure upon or over which the
advertisement is erected, exhibited, fixed or retained, if such addition or alteration involves the
disturbance of the advertisement, or any part thereof; and(f)if the building, wall or structure upon
or over which the advertisement is erected, exhibited, fixed or retained, be demolished or destroyed.
66. Owner or person in occupation to be deemed responsible.
- Where any advertisement is erected, exhibited, fixed or retained upon or over any land, building,
wall, hoarding or structure in contravention of the provisions of Section 63 or Section 64 or after the
written permission for the erection, exhibition, fixation or retention thereof for any period has
expired or becomes void, the owner or person in occupation of such land, building, wall, hoarding or
structure shall be deemed to be the person who has erected, exhibited, fixed or retained such
advertisement in such contravention, unless he proves that such contravention was committed by a
person not in his employment or under his control or was committed without his connivance.
67. Removal of unauthorised advertisements.
- If any advertisement is erected, exhibited, fixed or retained contrary to the provisions of Section
63, Section 66 or after the written permission for the erection, exhibition, fixation or retention
thereof for any period has expired or become void, the Executive Authority may, by notice in
writing, require the owner or occupier of the land, building, wall, hoarding or structure upon or
over, which the same is erected, exhibited, fixed or retained to take down or remove such
advertisement or may enter any building, land or property and have the advertisement removed,
and the costs thereof shall be recoverable in the same manner as property tax.
68. Collection of tax on advertisements.
- The Executive Authority may farm out of the collection of any tax on advertisement leviable under
Section 63 for any period not exceeding one year at a time on such terms and conditions as may be
determined by the Gram Panchayat.Andhra Pradesh Panchayat Raj Act, 1994

69. Duty on transfers of property.
(1)The duty on transfers of property shall be levied by the Government-(a)in the form of a surcharge
on the duty imposed by the Indian Stamp Act, 1899 (Central Act 2 of 1899) as in force for the time
being in the State, on every instrument of the description specified below, in so far as it relates to the
whole or part of immovable property as the case may be, situated in the area under the jurisdiction
of a Gram Panchayat; and(b)at such rate as may be fixed by the Government not exceeding five
percentum on the amount specified below against such instrument:
 Description of instrument Amount on which duty shall be levied
 (1) (2)
(i) Sale of immovable propertyThe amount of value of the consideration for thesale as set
forth in the instrument or the market value of theproperty
which is the subject matter of the sale, whichever ishigher.
(ii)Exchange of immovable
propertyThe market value of the property of greatervalue which is the
subject matter of exchange.
(iii) Gift of immovable propertyThe market value of the property which is thesubject matter
of the gift.
(iv)Mortgage with possession of
immovable propertyThe amount secured by the mortgage as set-forthin the
instrument
(v)Lease for a term exceeding one
hundred years orin perpetuity of
immovable propertyAn amount equal to one-sixth of the whole amountor value of
the rents which would be paid or delivered in respectof the
first fifty years of the lease, as set-forth in theinstrument.
(2)On the introduction of the duty aforesaid-(a)Section 27 of the Indian Stamp Act, 1899 (Central
Act 2 of 1899) shall be read as if it specifically required the particulars to be set-forth separately in
respect of property situated in the area under the jurisdiction of a Gram Panchayat and in respect of
property situated outside such area; and(b)Section 64 of the same Act shall be read as if it referred
to the Gram Panchayat as well as the Government.(3)The duty levied under this Section shall be
apportioned among the Gram Panchayat, [Mandal Praja Parishad] [Substituted 'Mandal Parishad'
by Act No. 41 of 2006, dated 23.9.2006.] and the [Zilla Praja Parishad] [Substituted 'Zilla Parishad'
by Act No. 41 of 2006, dated 23.9.2006.] concerned in such manner as may be prescribed.(4)The
Government shall make rules for regulating the collection of the duty and the apportionment thereof
among the Gram Panchayat, [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41
of 2006, dated 23.9.2006.] and [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of
2006, dated 23.9.2006.] concerned and the deduction of any expenses incurred by the Government
in the collection thereof.(5)The Government may by order exempt, subject to such conditions and
terms as may be specified therein, any instrument or class of instruments from the levy of duty
under this Section.
70. Vehicle tax.
- The vehicle tax referred to in clause (i) of sub-Section (3) of Section 60 shall, subject to such rulesAndhra Pradesh Panchayat Raj Act, 1994

as may be made in this behalf including rules relating to the exemptions and restrictions, be levied
every year on all vehicles kept or used within the village at such rates as may be fixed by the Gram
Panchayat not being less than the minimum rates and not exceeding the maximum rates
prescribed.Explanation. - In this Section, "vehicle" means a conveyance suitable for use on roads or
rails and includes any kind of carriage, cart, wagon, wheel barrows, truck, bicycle, tricycle and
rickshaw, but does not include a motor vehicle as defined in the Motor Vehicles Act, 1988 (Central
Act 59 of 1988).
71. Special tax leviable by a Gram Panchayat.
- Subject to such rules as may be prescribed, a Gram Panchayat shall levy a special tax on houses at
such rates as may be prescribed, to provide for expenses connected with the construction,
maintenance, repair, extension and improvement of water or drainage works or the lighting of the
public streets and public places, and other similar works.
72. Composition of tax payable by owner of a factory or a contiguous group
of buildings.
- Subject to such conditions and restrictions as may be prescribed, a Gram Panchayat may, on
application by the owner of a factory or a contiguous group of buildings, permit him to compound
all or any of the taxes payable by him under this Act, by paying in lieu thereof such lumpsum
amount as may be agreed upon between him and the Gram Panchayat. Where there is no such
agreement the matter may be referred to the Government in the manner prescribed and the
Government shall, after giving to the Gram Panchayat and the owner of the factory or a contiguous
group of buildings concerned an opportunity of making a representation, decide the lumpsum
amount payable by the owner of the factory or a contiguous group of buildings under this Section.
The decision of the Government in this regard shall be final.
73. Power to write-off irrecoverable amounts.
- Subject to such restrictions and control as may be prescribed, a Gram Panchayat may write off any
tax, fee or other amount whatsoever due to it, whether under a contract or otherwise, or any sum
payable in connection therewith, if in its opinion such tax, fee, amount or sum is
irrecoverable:Provided that where the District Collector or any of his subordinates is responsible for
the collection of any tax, fee or other amount due to a Gram Panchayat, the power to write off such
tax, fee or amount or any sum payable in connection therewith on the ground of its being
irrecoverable, shall be exercised by the Commissioner of Land Revenue or subject to his control by
the District Collector or any officer authorised by him.
74. Gram Panchayat Fund.
(1)All moneys received by the Gram Panchayat shall constitute a fund called the "Gram Panchayat
Fund", and shall be applied and disposed of in accordance with the provisions of this Act and otherAndhra Pradesh Panchayat Raj Act, 1994

laws:Provided that the Gram Panchayat shall credit, subject to such rules as may be prescribed, the
proceeds of any tax or fee levied under this Act, to a special fund earmarked for the purpose of
financing any specific public improvement. A separate account shall be kept of the receipts into and
the expenditure from such special fund.(2)Subject to the provisions of sub-Section (1), the receipts
which shall be credited to the Gram Panchayat Fund shall include-(i)the house-tax and any other tax
or any cess or fee levied under this Act;(ii)the proceeds of the duty collected under sub-Section (4) of
Section 60;(iii)the proceeds of the duty on transfers of property levied under Section 69 which are
paid to the Gram Panchayat;[***] [Omitted by Section 4(i) of Act. no. 37 of 2001.](iv)[]
[Renumbered by Section 4(ii) of Act. no. 37 of 2001.] any payment made to the Gram Panchayat by
a market committee in pursuance of sub-Section (3) of Section 11 of the Andhra Pradesh (Andhra
Area) Commercial Crops Markets Act, 1933 (Act XX of 1933), or any other law similar thereto for the
time being in force;(v)the taxes and tolls levied in the village under Sections 117 and 118 of the
Andhra Pradesh (Andhra Area) Public Health Act, 1939 (Act III of 1939); or under the
corresponding provision of any other law similar thereto for the time being in force in the
State;(vi)any payment made to the Gram Panchayat by the Government under Section 13 of the
Andhra Pradesh Entertainments Tax Act, 1939 (Act X of 1939);(vii)the amount contributed by the
[Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] to
the Gram Panchayat in respect of markets in the village classified as [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] markets or paid by the
[Mandal Praja Parishads] [Substituted 'Mandal Parishads' by Act No. 41 of 2006, dated 23.9.2006.]
to the Gram Panchayat towards the latter's share of the income derived from such markets as per
the apportionment made under Section 112 and the amount paid by a [Zilla Praja Parishad]
[Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or any of the joint committees
referred to in Section 57 to the Gram Panchayat towards the latter's share of the income derived
from a ferry under the management of the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act
No. 41 of 2006, dated 23.9.2006.] or joint committee, as the case may be, as per the apportionment
made under the said Section;(viii)fees for the temporary occupation of village sites, roads and other
similar public places or parts thereof in the village;(ix)fees levied by the Gram Panchayat in
pursuance of any provision in this Act, or any rule or other made thereunder;(x)income from
endowments and trusts under the management of the Gram Panchayat;(xi)the net assessment on
service inams which are resumed by Government after the commencement of this Act;(xii)income
derived from village fisheries, vested in the Gram Panchayat including the weeds and
reeds;(xiii)income derived from ferries under the management of the Gram
Panchayat;(xiv)unclaimed deposits and other forfeitures;(xv)the seigniorage fees collected by the
Government every year from persons permitted to quarry in the village for materials including
minor minerals other than major minerals;(xvi)all income derived from porambokes which vest in
the Gram Panchayat or the user of which is regulated by the Gram Panchayat and also the penalty
and penal assessment, if any, levied in respect of unauthorised occupation thereof under any law for
the time being in force;(xvii)all income derived from trees standing on porambokes although the
user of the porambokes is not vested in the Gram Panchayat;(xviii)income from leases of
Government property obtained by the Gram Panchayat;(xix)a sum equivalent to one-tenth of the
gross income derived by the Government every year from fines imposed by Magistrates in respect of
offences committed in the village under this Act, or any rule or bye-law made thereunder or any
other provision of law which is prescribed in this behalf;(xx)grants received from the Government,Andhra Pradesh Panchayat Raj Act, 1994

the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or
[Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.];(xxi)income from investments of amounts taken from the Gram Panchayat
Fund;(xxii)all other receipts accruing from the sources of Gram Panchayat revenue specified in this
Act; and(xxiii)all sums other than those enumerated above which arise out of, or are received in aid
of, or for expenditure on any institutions or services maintained or financed from the Gram
Panchayat Fund or managed by the Gram Panchayat.](3)All moneys received by the Gram
Panchayat shall be lodged in the nearest Government treasury.[Provided that the amounts received
as funds under the Jawahar Rozgar Yojana, Employment Assurance Scheme or other Wage
Employment Schemes shall be lodged in nearby Nationalised Banks or Co-operative Banks or Post
Offices in such manner as may be prescribed.] [Added by Section 2 of Act No. 16 of 1998.](4)[ All
orders or cheques against the Gram Panchayat Fund shall be signed by such authority as may be
prescribed.] [Substituted by Act No. 17 of 1996.]
75. Expenditure from Gram Panchayat Fund.
(1)The purpose to which the Gram Panchayat Fund may be applied include all objects expressly
declared obligatory or discretionary by this Act or any rules made thereunder or by any other laws or
rules and the fund shall be applicable thereto within the village subject to such rules or special
orders as the Government may prescribe or issue and shall, subject as aforesaid, be applicable to
such purposes outside the village if the expenditure is authorised by this Act or specially sanctioned
by the Commissioner.(2)(a)It shall be the duty of every Gram Panchayat to provide for the payment
of -(i)any amounts falling due on any loans contracted by it;(ii)the salaries and allowances and the
pensions, pensionary contributions and provident fund contributions of its officers and
servants;(iii)sums due under any decree or order of a Court;(iv)contributions, if any, levied by the
[Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.]
subject to such limits as may be specified by Commissioner; and(v)any other expenses rendered
obligatory by or under this Act or any other law.(3)A Gram Panchayat may, with the sanction of the
Government, contribute to any fund for the defence of India.(4)A Gram Panchayat may, with the
sanction of the Commissioner, also -(i)contribute towards the expenses of any public exhibition,
ceremony or entertainment in the village;(ii)contribute to any charitable fund, or to the funds of any
institution for the relief of the poor or the treatment of diseased or infirmity or the reception of
diseased or infirm persons or the investigation of the causes of disease;(iii)contribute to the funds of
any institution established for promoting community development or the aims of Panchayat Raj;
and(iv)defray any other extraordinary charges.
76. Election expenses to be borne by the Government.
- The cost of the preparation and revision of the electoral roll, the cost of the election expenses,
including the conduct of elections to the GramPanchayat and the cost of maintenance of election
establishment employed in connection therewith, shall be borne by the Government.Andhra Pradesh Panchayat Raj Act, 1994

77. Preparation and sanction of budget.
(1)The Executive Authority shall in each year frame before the prescribed date and place before the
Gram Panchayat, the budget showing the probable receipts and expenditure during the following
year and the Gram Panchayat shall, within one month of the date on which the budget is placed
before it, sanction the budget with such modifications, if any, as it thinks fit:Provided that if for any
reasons, the budget is not sanctioned by the Gram Panchayat under this sub-Section before the
expiration of the period of one month aforesaid, the Executive Authority shall submit the budget to
the Divisional Panchayat Officer, who shall sanction it with such modifications, if any, as he thinks
fit.(2)Where the budget is sanctioned by the Gram Panchayat it shall be forwarded by the Executive
Authority on or before such date as may be prescribed to the Divisional Panchayat Officer. The
Divisional Panchayat Officer shall make such suggestions or modifications as he may deem fit within
one month from the date of its receipt and return it to the Gram Panchayat which shall consider the
same and approve the budget with or without modifications, at a special meeting convened for the
purpose; and the budget so approved at such meeting shall be final.(3)If in the course of a year a
Gram Panchayat finds it necessary to alter figures shown in the budget with regard to its receipts or
to the distribution of the amounts to be expended on the different services undertaken by it, a
supplemental or revised budget may be framed, sanctioned, submitted and modified in the manner
provided in sub-Sections (1) and (2).
78. Contribution to expenditure by other local authorities.
- If the expenditure incurred by the Government or by any other Gram Panchayat or the [Mandal
Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or [Zilla
Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or by any
other local authority in the State for any purpose authorised by or under this Act is such as to benefit
the inhabitants of the village, the Gram Panchayat may, with the sanction of the Commissioner, and
shall, if so directed by him, make a contribution towards such expenditure.
79. Recovery of loans and advances made by the Government.
(1)Notwithstanding anything in the Local Authorities Loan Act, 1914 (Central Act 9 of 1914), or any
other law similar thereto for the time being in force, the Government may-(a)by order direct any
person having custody of the Gram Panchayat Fund to pay to them in priority to any other charges
against such fund, except charges for the service of authorised loans, any loan or advance made by
them to the Gram Panchayat for any purpose to which its funds may be applied under this
Act;(b)recover any such loan or advance by suit.(2)The person to whom the order referred to in
clause (a) of sub-Section (1) is addressed shall be bound to comply with such other.
Chapter IV
Public Safety, Convenience and HealthAndhra Pradesh Panchayat Raj Act, 1994

80. Vesting of water works in Gram Panchayats.
(1)All public water-courses, springs, reservoirs, tanks, cisterns, fountains wells, stand-pipes and
other water works (including those used by the public to such an extent as to give a prescriptive
right to their use) whether existing at the commencement of this Act or afterwards made, laid or
erected and whether made, laid or erected at the cost of the Gram Panchayat or otherwise for the use
or benefit of the public, and also any adjacent land, not being private property, appertaining thereto
shall vest in the Gram Panchayat and be subject to its control:Provided that nothing in this
sub-Section shall apply to any work which is, or is connected with, a work of irrigation or to any
adjacent land appertaining to any such work.(2)Subject to such restrictions and control as may be
prescribed, the Gram Panchayat shall have the fishery rights in any water work vested in it under
sub-Section (1), the right to supply water from any such work for raising seed beds on payment of
the prescribed fee, and the right to use the adjacent land appertaining thereto for planting of trees
and enjoying the usufruct thereof or for like purpose.(3)The Government may, by notification,
define or limit such control or may, assume the administration of any public source of water supply
and public land adjacent and appertaining thereto after consulting, the Gram Panchayat and giving
due regard to its objections, if any.
81. Setting apart of public tanks etc., for certain purposes.
(1)(a)The Gram Panchayat may, in the interests of Public Health, regulate or prohibit the washing of
animals or of clothes or other articles or fishing in any public spring, tank or well or in any public
water course or part thereof and may set apart any such place for drinking or for bathing or for
washing animals or clothes or for any other specified purpose.(b)The powers conferred by clause (a)
may, in the case of any private spring, tank, well, or water course, be exercised by the Gram
Panchayat, with the consent of the owner of such place.(c)The Gram Panchayat may, in the interests
of public health, regulate or prohibit the washing of animals or of clothes or of other articles, in any
private spring, tank, well or water-course from which the public have a right to take water for
drinking purposes.(2)The Executive Authority on receipt of a certificate from any health or medical
officer in the service of the Government, the Gram Panchayat or the [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or [Zilla Praja Parishad]
[Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] stating that the water in any
well, tank, spring or other sources of water supply to which the public have access in the village, is
likely to endanger or cause the spread of any dangerous disease, shall, by public notice, prohibit the
use of such water, such notice shall be served by affixing a copy of it near the source of water-supply
and by beat of drum stating the number of days during which such prohibition shall last. The
Executive Authority may modify the notice or extend the period of operation thereof without the
production of a further certificate.
82. Prohibition against using places so set apart for purposes other than
those Notified.
- No person shall-(a)bathe in or defile, the water in any place set apart for drinking or cookingAndhra Pradesh Panchayat Raj Act, 1994

purposes either by a Gram Panchayat or in the case of private property, by the owner thereof;
or(b)deposit any offensive or deleterious matter in the bed of any place set apart as aforesaid when
such bed is dry; or(c)wash clothing in any place set apart as aforesaid; or(d)wash any animal or any
cooking utensil or wool, skins or other foul or offensive substance or deposit any offensive or
deleterious matter in any other place set apart as aforesaid or set apart for bathing or for washing
clothes.(e)allow the water from a sink, sewer, drain engine or boiler, or any other offensive matter
belonging to him or flowing from any building or land belonging to or occupied by him, to pass into
any place set apart as aforesaid or set apart for bathing or for washing clothes.
83. Contribution from persons having control over places of pilgrimage etc.
- Where a mosque, temple, mutt or any place of religious worship or instruction or any place which
is used for holding fairs, or festivals or for other like purposes, is situated within the limits of a
village or in the neighbourhood thereof and attracts either throughout the year or on particular
occasions a large number of persons, any special arrangements necessary for public health, safety or
convenience, whether permanent or temporary, shall be made by the Gram Panchayat but the
Government may, after consulting the trustee or other person having control over such place,
require him to make such recurring or non-recurring contribution to the funds of the Gram
Panchayat as they may determine.
84. Cleaning of Private Latrines.
- The Executive Authority of a Gram Panchayat may contract with the owner or occupier of any
premises to remove rubbish or filth or any particular kind of rubbish or filth, from such premises or
any place belonging thereto, on such terms as to times and periods of removal and other matters as
may deem fit and suitable to the Executive Authority and on payment of fees at such rate calculated
to cover the cost of the service as the Gram Panchayat may fix.
85. Registration of burial and burning grounds.
(1)Every owner or person having control of any place used at the commencement of this Act as a
place for burying, burning or otherwise disposing of the dead, shall, if such place be not already
registered under any law applicable thereto, apply to the Gram Panchayat to have such place
registered under this Act.(2)If it appears to such Gram Panchayat that there is no owner or person
having the control of such place, the Gram Panchayat shall assume such control and register such
place or may close it.
86. Licensing of places for disposal of the dead.
(1)No new place for the disposal of the dead whether private or public, shall be opened, formed,
constructed or used, unless a licence is obtained from the Gram Panchayat on application.(2)Such
application for a licence shall be accompanied by a plan of the place to be licensed showing the
locality, boundary and extent thereof, the name of the owner or person or community interestedAndhra Pradesh Panchayat Raj Act, 1994

therein, the system of management and such further particulars as the Gram Panchayat may
require.(3)The Gram Panchayat to which an application is made, may, in consultation with the
District Health Officer -(a)grant or refuse a licence, or(b)postpone the grant of licence, until
objections, if any, to the site, considered reasonable by the Gram Panchayat have been removed or
any particulars called for by it have been furnished.(4)The District Collector may cancel or modify
any order passed by Gram Panchayat under sub-Section (3).
87. Provision of burning and burial grounds.
- A Gram Panchayat may, and shall, if no sufficient provision exists, provide at the cost of the Gram
Panchayat Fund, places to be used as burial or burning grounds or crematoria, and may charge rents
and fees for the use thereof.
88. A book to be kept of places registered, licensed or provided.
(1)A book shall be kept at the office of every Gram Panchayat in which the places registered, licensed
or provided under Section 85, Section 86, Section 87 and all such places registered, licensed or
provided before the commencement of this Act shall be recorded.(2)A notice in English and in the
chief language of the village that such place has been registered, licensed or provided as aforesaid,
shall be affixed at or near the entrance to such place conspicuously.
89. Prohibition against burying or burning in unauthorised places.
- No person shall bury, burn or otherwise dispose of or cause of suffer to be buried, burnt or
otherwise disposed or any corpse in any place within two hundred metres of a dwelling place or any
source of drinking water supply other than a place registered, licensed or provided as aforesaid.
90. Notices to be given to Gram Panchayat of burials etc.
- The person having control of a place for disposing of the dead shall give information of every
burial, burning or other disposal, of a corpse at such place to any person appointed by the Gram
Panchayat.
91. Prohibition against use of burial and burning grounds dangerous to
health or overcrowded with graves.
(1)If a Gram Panchayat is satisfied,-(a)that any registered or licensed place for the disposal of the
dead is in such a state or a situation as to be or to be likely to become, dangerous to the health of
persons living in the neighbourhood thereof; or(b)that any burial ground is overcrowded with
graves, and if in the case of a public burial or burning ground or other place as aforesaid, another
convenient place duly authorised for the disposal of the dead exists or has been provided for the
persons who would ordinarily make use of such place, it may, with the approval of Commissioner,
give notice that it shall not be lawful, after a period of not less than two months to be specified inAndhra Pradesh Panchayat Raj Act, 1994

such notice, to bury, burn or otherwise dispose of, any corpse at such place.(2)Every notice given
under sub-Section (1) shall be published by affixture to the notice board in the office of the Gram
Panchayat and in the village by beat of drum.(3)No person shall, in contravention of any notice
under this Section and after the expiration of the period specified in such notice, bury, burn or
otherwise dispose of, or cause or permit to be buried, burnt or otherwise disposed of, any corpse at
such place.
92. [ Power to control and administer stray dogs or pigs. [Substituted by Act
No. 8 of 2018.]
- A Gram Panchayat shall have power to control and administer stray dogs or pigs in such manner as
may be prescribed.]
93. Prohibition against allowing outflow of filth.
- No owner or occupier of any premises shall allow the water from any sink, drain, latrine, or stable
or any other filth, to flow out of such premises to any portion of a public road except a drain or
cesspool or to flow out of such premises in such a manner as to cause nuisance by the soakage of the
said water or filth into the walls or ground at the side of a drain forming a portion of such public
road.
94. Power as to sanitation and conservancy.
(1)If it appears necessary to improve the sanitary conditions of any area within the village, the
Executive Authority may, by written notice, require owner or occupier of any of the lands, and
houses in area, within a reasonable period to be specified in the notice, -(a)to remove a hut or privy
either wholly or in part;(b)to construct in a building, private drains there for to alter or to remove,
any private drain thereof;(c)to cause any land or building to be cleansed to the satisfaction of the
Executive Authority;(d)where any land or building contains a well, pool, ditch, pond, tank or any
drain, filth or stagnant water which is injurious to health or offensive to the neighbourhood or is
otherwise a source of nuisance, to cause the same to be filled up, cleansed or deepened or to cause
the water to be removed therefrom or drained off or to take such other action as may be deemed
necessary by the Executive Authority;(e)to cause any land overgrown with vegetation, under growth,
prickly-pear or jungle which is in any manner injurious to health or dangerous to the public or
offensive to the neighbourhood or an impediment to efficient ventilation, to be cleared of the
vegetation, undergrowth, prickly pear or jungle;(f)to convert any step well into a draw-well:Provided
that the Executive Authority shall hear and decide objections, if any, raised by the person on whom a
notice is so served.(2)If any work required under sub-Section (1) is not executed within the period
specified in the notice the Executive Authority may himself cause such work to be carried out, and
may recover the cost of such work or part thereof from the owner or occupier referred to in
sub-Section (1) in the manner hereinafter provided.Andhra Pradesh Panchayat Raj Act, 1994

95. Prohibition against working of quarry near public roads.
(1)No person shall work a quarry in, or remove stones, earth or other material from, any place
within twenty metres of a public road or of other immovable property vesting in or belonging to the
Gram Panchayat except under a licence issued by a Gram Panchayat. The Gram Panchayat may
either grant or refuse to grant a licence and in the later case the reasons for refusal shall be
communicated to the person concerned.(2)If, in the opinion of the Gram Panchayat, the working of
any quarry or the removal of stone, earth or other material from any place is dangerous to any
person residing in, or having legal access to, the neighbourhood thereof or creates or is likely to
create a nuisance, the Gram Panchayat may require the owner or person having control of the said
quarry or place to discontinue working the same or to discontinue removing stone, earth or other
material from such place or to take such action in respect of such quarry or place as it shall deem
necessary for the purpose of preventing danger or of abating the nuisance arising or likely to arise
therefrom.
96. Prohibition against destruction in or over public roads.
- No person shall build any wall or erect any fence or other obstruction or projection or make any
encroachment in or over any public road except as hereinafter provided.
97. Prohibition against and regulation of door, gate, bar or ground floor
window opening outwards.
(1)No door, gate, bar or ground floor window shall, without a licence from the Executive Authority,
be hung or placed so as to open outwards upon any public road vested in the Gram
Panchayat.(2)The Executive Authority may, by notice, require the owner of such door, gate, bar or
ground floor window to alter it, so that no part thereof when open shall project over the public road.
98. Removal of encroachments.
(1)The Executive Authority may, by notice, require the owner or occupier of any building to remove
or alter any projection, encroachment or obstruction, other than a door, gate, bar or ground floor
window, situated against or in front of such building and in or over any public road vested in such
Gram Panchayat.(2)If the owner or the occupier of the building proves that any such projection,
encroachment or obstruction has existed for a period sufficient under the law of limitation to give
any person a prescriptive title thereto or that it was erected or made with the permission or licence
of any local authority duly empowered in that behalf, and that the period, if any, for which the
permission or licence is valid has not expired, the Gram Panchayat shall make reasonable
compensation to every person who suffers damages by the removal or alteration of the same.Andhra Pradesh Panchayat Raj Act, 1994

99. Power to allow certain projections and erections.
(1)The Executive Authority may, with the approval of the Gram Panchayat, grant a licence, subject to
such conditions and restrictions as he may think fit to the owner or occupier of any building to put
up verandahs, balconies, sunshades, weather frames and the like, to project over a public road
vested in such Gram Panchayat; or to construct any step or drain covering necessary for access to
the building.(2)The Executive Authority may grant a licence, subject to such conditions and
restrictions as he may think fit for the temporary erection of pandal and other structures in a public
road vested in such Gram Panchayat; or in any other public place the control of which is vested in
such Gram Panchayat.(3)The Executive Authority shall have power with the approval of the Gram
Panchayat, to lease the roadsides vested in such Gram Panchayat for occupation on such terms and
conditions and for such period as the Gram Panchayat may fix.(4)But neither a licence under
sub-Section (1) nor a lease under sub-Section (3) shall be granted if the projection, construction or
occupation, as the case may be, is likely to be injurious to health or cause public inconvenience or
otherwise materially interfere with the use of the road as such.(5)The Government may, by
notification, restrict and place under such control as they may think fit the exercise, by any Gram
Panchayat of the powers under sub-Sections (1) and (3).(6)On the expiry of any period for which a
licence has been granted under this Section the Executive Authority may without notice, cause any
projection or construction put up under sub-Section (2) to be removed, and the cost of so doing shall
be recoverable, in the manner hereinafter provided from the person to whom the licence was
granted.
100. Prohibition of building on sewer, drain etc., without permission.
(1)No building shall be erected without the written permission of the Executive Authority or any
person authorised by such Executive Authority, over any sewer or drain or any part of sewer or drain
or upon any ground which has been covered, raised or levelled wholly or in part by road sweepings
or other rubbish.(2)The Executive Authority or the person authorised by him as aforesaid may, by
notice, require any person who has erected a building without such permission or in a manner
contrary to or inconsistent with the terms of such permission to demolish the same.
101. Prohibition against making holes and causing obstruction in public
roads.
(1)No person shall make a hole or cause any obstruction in any public road vested in a Gram
Panchayat except with the previous permission of the Executive Authority and subject to such
conditions as the Executive Authority may impose.(2)When such permission is granted such person
shall, at his own expense, cause such hole or obstruction to be sufficiently fenced and enclosed until
the hole or obstruction to be sufficiently lighted during the night.(3)If any person contravenes the
provisions of this Section, the Executive Authority shall fill up the hole or remove the obstruction or
cause the hole or obstruction to be lighted, as the case may be, and may recover the cost of so doing
from such person.Andhra Pradesh Panchayat Raj Act, 1994

102. Prohibition against planting or felling trees on public roads etc., without
permission.
(1)No person shall plant any tree on any public road or other property vesting in or belonging to a
Gram Panchayat, except with the previous permission of the Executive Authority and on such
conditions as the Executive Authority may impose.(2)No person shall fell, remove, destroy lop or
strip bark, leaves or fruits from or otherwise damage any tree vesting in or belonging to a Gram
Panchayat and growing on any such public road or property except with the previous permission or
order of the Executive Authority and on such conditions as the Executive Authority may impose.
103. Recovery of penalty and compensation for unauthorised occupation of
land.
(1)If any person, without the previous sanction of the Gram Panchayat, occupies any land which is
set apart for any public purpose and is vested in or belongs to it, he shall be bound to pay in respect
of such occupation such sum as may be demanded by the Gram Panchayat by way of penalty; and
any such sum may be recovered in the manner hereinafter provided.(2)The Executive Authority
may, by notice require any person on whom a penalty is or may be imposed under sub-Section (1) to
vacate such land and to remove any building or other construction or anything deposited on it.(3)If
any damage to the property of the Gram Panchayat has been caused by any person occupying any
land for which he is liable to pay penalty under sub-Section (1), he shall be liable to pay
compensation to the Gram Panchayat for such damage in addition to and irrespective of any penalty
that may be imposed on or recovered from him, and the amount of such compensation, shall in case
of dispute, be determined and recovered in the manner hereinafter provided.
104. Public Markets.
(1)The Gram Panchayat may provide places for use as public market and, with the sanction of the
Commissioner, close any such market or part thereof.(2)Subject to such rules as may be prescribed
the Gram Panchayat may levy one or more of the following fees in any public market at such rates,
not exceeding the maximum rates, if any prescribed in this behalf, as the Gram Panchayat may think
fit-(a)fees for the use of, or for the right to expose goods for sale in such market;(b)fees for the use of
shops, stalls, pens or stands in such markets;(c)fees on vehicles including motor vehicles as defined
in the Motor Vehicles Act, 1988 (Central Act 59 of 1988) or pack-animals bringing or persons
carrying, any goods for sale in such markets;(d)fees on animals brought for sale into or sold in such
market;(e)licence fees on brokers, commission agents, weighmen and measures practising their
calling in such market.
105. Licence for private markets.
(1)No person shall open a new private market or continue to keep open a private market unless he
obtain from the Gram Panchayat a licence to do so.(2)Application for such licence shall be made by
the owner of the place in respect of which the licence is sought not less than thirty and not moreAndhra Pradesh Panchayat Raj Act, 1994

than ninety days before such place is opened as a market, or the commencement of the year for
which the licence is sought to be renewed, as the case may be.(3)The Gram Panchayat shall, as
regards private markets already lawfully established and may, as regards new private markets, grant
the licence applied for, subject to such regulations as to supervision and inspection and to such
conditions as to sanitation, drainage, water supply, width of paths and ways, weights and measures
to be used, and rents and fees to be charged in such market, as the Gram Panchayat may think
proper; or the Gram Panchayat may, for reasons to be recorded in writing, refuse to grant any such
licence for any new private market. The Gram Panchayat may, however, at any time for breach of
any condition of the licence suspend or cancel the licence granted under this Section. The Gram
Panchayat may also modify any of the conditions of the licence to take effect from a specified
date.(4)When a licence is granted, refused, suspended, cancelled or modified under this Section, the
Gram Panchayat shall cause a notice of such grant, refusal, suspension, cancellation or modification
in the chief language of the village to be pasted conspicuously at or near the entrance to the place in
respect of which the licence was sought or had been obtained.(5)Every licence granted under this
Section shall expire at the end of the year.(6)Any person aggrieved by an order of the Gram
Panchayat under sub-Section (3) may appeal against such order to the Commissioner who may, if he
thinks fit, suspend the execution of the order, pending the disposal of the appeal.
106. Fee for licence.
- When a licence granted under Section 104 permits the levy of any fees of the nature specified in
sub-Section (2) of Section 104 a fee not exceeding fifteen per cent of gross income of the owner from
the market in the preceding year, shall be charged by the Gram Panchayat for such licence.
107. Power exercisable by Executive Authority in respect of public markets.
- The Executive Authority may expel from any public market any person who or whose servant has
been convicted of disobeying any bye-laws for the time being in force in such market, and may
prevent such persons from further carrying on by himself or his servants or agents, any trade or
business in such market, or occupying any shop, stall or other place therein and may determine any
lease or tenure which such person may possess in any shop, stall or place.
108. Powers exercisable by Gram Panchayat in respect of private markets.
(1)The Gram Panchayat may by notice, require the owner, occupier, or farmer of any private market
to, -(a)construct approaches, entrances, passages, gates, drains and cess-pits for such market and
provide it with latrines of such description and in such position and number as the Gram Panchayat
may think fit;(b)roof and pave the whole or any portion of it or pave any portion of the floor with
such material as will in the opinion of the Gram Panchayat secure imperviousness and ready
cleansing;(c)ventilate it properly and provide it with an adequate supply of water;(d)provide
passages of sufficient width between the stalls and make such alterations in the stalls, passages,
shops, doors or other parts of the market as the Gram Panchayat may direct;(e)keep it in a cleanly
and proper state, remove all filth and refuse therefrom and dispose of them at such place and in
such manner as the Gram Panchayat may direct; and(f)make such other sanitary arrangements asAndhra Pradesh Panchayat Raj Act, 1994

the Gram Panchayat may consider necessary.(2)If any person, after notice given to him in that
behalf by the Gram Panchayat, fails within the period and in the manner laid down in the said
notice, to carry out any of the works specified in sub-Section (1), the Gram Panchayat may suspend
the licence of the said person, or may refuse to grant him a licence until such work is completed.(3)It
shall not be lawful for any person to keep open any private market during such suspension or until
the licence is renewed.(4)No owner, occupier, agent or manager in-charge of any private market, or
of any shop, stall, shed or other place therein, shall keep the same so that it is a nuisance, or fail to
cause anything that is a nuisance in such market, shop, stall, shed or other place to be at once
removed to a place to be specified by the Gram Panchayat.
109. Decisions of disputes as to whether places are market.
- If any question arises as to whether any place is a market or not, the Gram Panchayat shall make a
reference thereon to the Government and their decision shall be final.
110. Prohibition of sale in unlicensed private market etc.
- No person shall sell or expose for sale any animal or article,(a)in any unlicensed private market;
or(b)in any public or licensed private market without the permission of the Executive Authority or
licensee, as the case may be, or of any person authorised by him.
111. Prohibition against sale in or upon public roads.
- The Executive Authority may, with the sanction of the Gram Panchayat, prohibit by public notice
or licence or regulate the sale or exposure for sale of any animals or articles in or upon any public
road or place or part thereof.
112. Classification of markets.
(1)The Government shall have power to classify public and private markets situated in a village as
[Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.]
markets and Gram Panchayat markets and provide for the control of any such market and for the
apportionment of the income derived therefrom between the [Zilla Praja Parishad] [Substituted
'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.], [Mandal Praja Parishad] [Substituted
'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] and the Gram Panchayat or the payment
of a contribution in respect thereof to the Gram Panchayat or the [Zilla Praja Parishad] [Substituted
'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or [Mandal Praja Parishad] [Substituted
'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] as the case may be.(2)In the case of
markets classified as [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006,
dated 23.9.2006.] markets, the Gram Panchayat and its Executive Authority shall not exercise any
of the powers conferred on them by Sections 104 to 111 or both inclusive.Andhra Pradesh Panchayat Raj Act, 1994

113. Vesting of places used as markets situated in estates taken over by the
Government.
- With effect on and from the date of deposit of final compensation under sub-Section (1) of Section
41 of the Andhra Pradesh (Andhra Area) Estates (Abolition and Conversion into Ryotwari) Act, 1948
(Act XXIV of 1948) in respect of any estates any place used as a market in such estates, which was
vested in the Government under the provisions of the said Act, shall stand transferred to, and vest
in, the Gram Panchayat in whose limits such place is situated and, thereupon, the Gram Panchayat
shall provide such place for use as a public market.
114. Classification of public roads, fairs and festivals etc.
- The classification of public roads, fairs and festivals, choultries, dispensaries and libraries in any
Gram Panchayat area as appertaining to the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by
Act No. 41 of 2006, dated 23.9.2006.], [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by
Act No. 41 of 2006, dated 23.9.2006.] or the Gram Panchayat shall be made by the Commissioner in
such manner as may be prescribed.
115. Public landing places, cart-stands etc.
- Subject to such rules as may be prescribed, the Gram Panchayat may : -(a)provide public landing
places, halting places, and cart stands (which last expression includes stands for animals and
vehicles of any description including motor vehicles) and levy fees for their use:Provided that it shall
be open to the Gram Panchayat to permit any person to compound such fees by paying in lieu
thereof such lumpsum amount as may be fixed by the Gram Panchayat;(b)where any such place or
stand has been provided, prohibit the use for the same purpose by any person within such distance
thereof, of any public places or the sides of any public road, as the Gram Panchayat may, subject to
the control of the Commissioner specify.
116. Private cart-stands.
- No person shall open a new private cart-stand and or continue to keep open a private cart-stand
unless he obtain from the Gram Panchayat a licence to do so. Such licence shall be renewed every
year.(2)The Gram Panchayat shall as regards private cart-stands already lawfully established, and
may, at its discretion, as regards new private cart-stands, grant the licence applied for subject to
such conditions as the Gram Panchayat may think fit as to supervision and inspection, conservancy
and such other matters as may be prescribed, or the Gram Panchayat may refuse to grant such
licence, for any new cart-stand.(3)The Gram Panchayat may modify conditions of the licence to take
effect from a specified date.(4)The Gram Panchayat may at any time suspend or cancel any licence
granted under sub-Section (2) for breach of the conditions thereof.(5)The Gram Panchayat may levy
on every grant or renewal of a licence under this Section, a fee not exceeding two hundred rupees.Andhra Pradesh Panchayat Raj Act, 1994

117. Public slaughter houses.
- Subject to such rules as may be prescribed, every Gram Panchayat may provide places for use as
public slaughter houses and charge rents and fees for their use.
118. Prohibition or regulation of the use of places for slaughtering animals
and licensing of slaughterers.
- The Government shall have power to make rules for-(a)prohibiting or regulating the slaughter,
cutting up or skinning of animals specified in the rules, on all occasions not excepted therein, at
places other than public slaughter-houses;(b)licensing persons to slaughter animals specified in the
rules for purposes of sale to the public; and(c)the inspection of slaughter-houses and of the meat
therein and the payment of remuneration to the officers employed for such inspection.
119. Purposes for which places may not be used without licence.
- The Gram Panchayat may notify in the prescribed manner, that no place within the limits of the
village shall be used for any one or more of the purposes specified in the rules made in this behalf
without a licence issued by the Executive Authority in the prescribed manner and except in
accordance with the conditions specified in such licence:Provided that no such notification shall
take effect until the expiry of a period of sixty days from the date of publication.
120. Applications to be made for construction, establishment, or installation
of factory, workshop or work place in which steam or other power is to be
employed.
(1)Every person intending, -(a)to construct or establish any factory, workshop or work-place in
which it is proposed to employ-steam power, water power or other mechanical power or electrical
power; or(b)to install in any premises any machinery or manufacturing plant driven by steam, water
or other powers as aforesaid, not being machinery or manufacturing plant exempted by rules made
in this behalf, shall, before beginning such construction, establishment or installation, obtain the
permission of the Gram Panchayat in the prescribed manner for undertaking the intended
work.(2)The application to be made under sub-Section (1) shall conform to such rules and shall be
processed in such manner and in consultation and approval of such authorities and subject to such
conditions as may be prescribed.
121. Construction of buildings.
- No piece of land shall be used as a site for the construction of a building and no building shall be
constructed or reconstructed and no addition or alteration shall be made to an existing building
without the permission of the Gram Panchayat granted in accordance with the provisions of any
rules or bye-laws made under this Act, relating to the use of building sites or the construction or
reconstruction of buildings:Provided that the Government may, in respect of all Gram Panchayats orAndhra Pradesh Panchayat Raj Act, 1994

with the consent of the Gram Panchayat, in respect of any particular Gram Panchayat or portion
thereof, exempt all buildings or any class of buildings from all or any of the provisions of any rules
or bye-laws made under this Act.
122. Power of Gram Panchayat to issue directions for abatement of nuisance
caused by steam or other power.
(1)If in any factory, workshop or workplace in which steam power, water power or other mechanical
power or electrical power is used, nuisance is caused by reason of the particular kind of fuel
employed or by reason of the noise or vibration created, the Gram Panchayat may issue such
directions as it thinks fit for the abatement of nuisance within a reasonable time to be specified for
the purpose.(2)If there has been willful default in carrying out such directions or if abatement is
found impracticable, the Gram Panchayat may,-(a)prohibit the use of the particular kind of fuel
employed, or(b)restrict the noise or vibration by prohibiting the working of the factory, workshop or
work-place between the hours of 9.30 p.m. and 5.30. a.m.
123. Form of licences, notices, permissions.
- All licences, notices, permissions, given, issued or granted, as the case may be, under the
provisions of this Act, shall be in accordance with such rules as may be made in this behalf.
124. Power of Government to pass order to give directions.
- The Government may, either generally or in any particular case, make such order or give such
directions as they may deem fit, in respect of any action taken or omitted to be taken under Section
119, Section 120 or Section 122.
125. Modification of the Andhra Pradesh (Andhra Area) Places of Public
Resort Act, 1888.
- Notwithstanding anything in the Andhra Pradesh (Andhra Area) Places of Public Resort Act, 1888
or any other Act similar thereto for the time being in force in the State, when the Government
extend that Act to any village or part thereof -(a)the authority to whom application shall be made for
a licence under that Act in respect of any place or building to be used exclusively for purposes other
than the holding of cinematograph exhibitions and who may grant or refuse such licence shall be the
Executive Authority, and(b)the appeal from the order of the Executive Authority granting, refusing,
revoking or suspending a licence under that Act shall lie to the Gram Panchayat.
Chapter V
General and Miscellaneous (Gram Panchayats)Andhra Pradesh Panchayat Raj Act, 1994

126. Power to name streets and number buildings.
(1)The Gram Panchayat may, in the manner prescribed, cause a name to be given to any street and
shall cause a number to be affixed to the side or outer door of any building or to some place at the
entrance of such building and in a like manner, may, from time to time, cause such name or number
to be altered.(2)No person shall, without lawful authority, destroy, pull down, or deface any such
name or number or any number assigned to any building in any such area.(3)When a number has
been affixed, the owner of the building shall be bound to maintain such number and to replace it if
removed or defaced, and if he fails to do so, the prescribed authority may, by notice require him to
replace it.
127. General provisions regarding licences and permissions.
(1)Every licence and permission granted under this Act or any rule or bye-law made under this Act
shall specify the period, if any, for which, and the restrictions, limitations and conditions subject to
which the same is granted and shall be signed by the Executive Authority or by some person duly
authorised by him in this behalf.(2)Save as otherwise expressly provided in or may be prescribed
under this Act, for every such licence or permission fees may be charged on such units and at such
rates as may be fixed by the Gram Panchayat:Provided that a person who is a barber, washerman,
medari or kummari or other village artisan by profession shall not be liable to pay any fees in
relation to the licence granted to him for the use of any place in the Gram Panchayat for exercising
his profession or transacting his business as such.(3)Every order of the authority competent under
this Act or any rule or bye-law made thereunder to pass an order refusing, suspending, cancelling or
modifying a licence or permission shall be in writing and shall state the grounds on which it
proceeds:Provided that every application for a licence or permission under this Act shall be disposed
of within fifteen days from the date of receipt thereof or from the date of receipt of approvals or
completion of other formalities prescribed failing which it shall be deemed that licence or
permission is granted.(4)Subject to the special provisions regarding private markets, any licence or
permission granted under this Act or any rule or bye-law made thereunder it may, at any time, after
giving the persons concerned an opportunity of making a representation be suspended or revoked
by the Executive Authority if any of the restrictions, limitations or conditions laid down in respect
thereof is evaded or infringed by the grantee, or if the grantee is convicted of a breach of any of the
provisions of this Act, or of any rule, bye-law or regulation made under it, in any matter to which
such licence or permission relates or if the grantee has obtained the same by misrepresentation or
fraud.(5)It shall be the duty of the Executive Authority to inspect places in respect of which a licence
or permission is required by or under this Act, and he may enter any such place between sunrise and
sunset, and also between sunset and sunrise if it is open to the public or any industry is being
carried on in it at that time; and if he has reason to believe that anything is being done in any place
without a licence or permission where the same is required by or under this Act, or otherwise than
in conformity with the same, he may at any time by day or night without notice enter such place for
the purpose of satisfying himself whether any provision of law, rules, bye-laws or regulations, any
condition of a licence or permission or any lawful direction or prohibition is being contravened; and
no claim shall lie against any person for any damage or inconvenience necessarily caused by the
exercise of powers under this sub-Section by the Executive Authority or any person to whom he hasAndhra Pradesh Panchayat Raj Act, 1994

lawfully delegated his powers; or by the use of any force necessary for effecting an entrance under
this sub-Section.(6)When any licence or permission is suspended or revoked or when the period for
which its was granted, or within which application for renewal should be made has expired,
whichever expires later, the grantee shall for all purposes of this Act, or any rule or bye-law made
under this Act, be deemed to be without a licence or permission, until the order suspending or
revoking the licence or permission is cancelled or subject to sub-Section (11) until the licence or
permission is renewed as the case may be.(7)The grantee of every licence or permission shall, at all
reasonable times, while such licence or permission remains in force, produce the same at the
request of the Executive Authority.(8)Whenever any person is convicted of an offence in respect of
the failure to obtain a licence or permission or to make a registration as required by the provisions
of this Act or any rule or bye-law made thereunder, the Magistrate shall, in addition to any fine
which may be imposed, recover summarily and pay over to the Gram Panchayat the amount of the
fee chargeable for the licence or permission or for registration and may, in his discretion, also
recover summarily and pay over to the Gram Panchayat such amount, if any, as he may fix, as the
costs of the prosecution.(9)Save as otherwise expressly provided in or may be prescribed under this
Act, every application for a licence or permission or for registration under this Act or any rule,
bye-law or regulation made thereunder or for renewal thereof, shall be made not less than thirty and
not more than ninety days before the commencement of the period or such less period as is
mentioned in the application.(10)Recovery of the fee under sub-Section (8) shall not entitle the
person convicted to a licence or permission or to registration as aforesaid.(11)The acceptance by or
on behalf of a Gram Panchayat of the prepayment of the fee for a licence or permission or for
registration shall not entitle the person making such prepayment to the licence or permission or of
registration, as the case may be but only to refund of the fee in case of refusal of the licence or
permission or of registration, but an applicant for the renewal of a licence or permission or
registration shall, until communication of orders on his application, be entitled to act as if the
licence or permission or registration had been renewed and save as otherwise specially provided in
this Act, if orders on an application for licence or permission or for registration are not
communicated to the applicant within thirty days or such longer period as may be prescribed in any
class of cases after the receipt of the application by the Executive Authority, the application shall be
deemed to have been allowed for the period if any, for which it would have been ordinarily allowed
and subject to the law, rules bye-laws and regulations and all conditions ordinarily imposed.
128. Appeal from the order of Executive Authority.
(1)An appeal shall lie to the Gram Panchayat from -(a)any order of the Executive Authority granting,
refusing, suspending or revoking a licence or permission;(b)any other order of the Executive
Authority that may be made appealable by rules made under Section 268.(2)A second appeal shall
lie from the decision of the Gram Panchayat passed in an appeal under sub-Section (1) to such
authority as may be prescribed whose decision thereon shall be final.
129. Limitation of time for appeal.
- In any case in which no time is fixed by the foregoing provisions of this Act for the presentation of
an appeal allowed thereunder, such appeal shall, subject to the provisions of Section 5 of the IndianAndhra Pradesh Panchayat Raj Act, 1994

Limitation Act, 1963 (Central Act 36 of 1963) be presented within thirty days after the date of receipt
of the order from which the appeal is preferred.
130. Government and Market Committees not to obtain licences and
permissions.
- Nothing in this Act or in any rule, bye-law or regulation made thereunder shall be construed as
requiring the taking out of any licence or the obtaining of any permission under this Act or any such
rule, bye-law or regulation in respect of any place in the occupation or under the control of the State
or Central Government or of a [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No.
41 of 2006, dated 23.9.2006.] or [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of
2006, dated 23.9.2006.] or of a Market Committee constituted under the Andhra Pradesh
(Agricultural Produce and Livestock) Markets Act, 1966 (Act 16 of 1966) or in respect of any
property of the State or Central Government or of any property belonging to such [Mandal Praja
Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or [Zilla Praja
Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or Market
Committee.
131. Time for complying with notice, order etc., and power to enforce in
default.
(1)Whenever by any notice, requisition or order under this Act, or under any rule, bye-law or
regulation made thereunder, any person is required to execute any work to take any measures or to
do anything, a reasonable time shall be named in such notice, requisition or order within which the
work shall be executed, the measures taken or the thing done.(2)If such notice, requisition or order
is not complied with within the times so named-(a)the Executive Authority may cause such work to
be executed or may take any measures or do anything which may in his opinion be necessary for
giving due effect to the notice, requisition or order and all expenses thereby incurred by the Gram
Panchayat shall be paid by the person or persons upon whom a notice was served and shall be
recoverable in the manner hereinafter provided; and further(b)if no penalty has been specially
provided, in this Act for failure to comply with such notice, requisition or order the said person shall
be punishable with fine not exceeding fifty rupees for every such offence.
132. Powers of entry and inspection.
(1)Subject to such restrictions and conditions as may be prescribed the Executive Authority or any
person authorised by him may, between sunrise and sunset on any day enter any place building or
land with or without notice and with or without assistants or workmen in order to make an inquiry,
inspection, test, examination, survey, measurement or valuation or to execute any other work which
is authorised by the provisions of the Act or of any rule, bye-law, regulation or order made under it
or which it is necessary to make or execute for any of the purposes of this Act or in pursuance of any
of the said provisions.(2)No claim shall lie against any person for any damage or inconvenience
necessarily caused by the exercise of powers under sub-Section (1) or the use of any force necessaryAndhra Pradesh Panchayat Raj Act, 1994

for effecting an entrance under that sub-Section.
133. Testing of weights and measures.
- The Executive Authority or any person authorised by him may examine and test the weights and
measures used in the markets and shops in the village with a view to the prevention and punishment
of offences relating to such weights and measures under Chapter XIII of the Indian Penal Code
(Central Act 45 of 1860).
134. Power to call for information from Executive authority.
(1)The Executive Authority may, by an order in writing require the Executive Authority having
jurisdiction over the Gram Panchayat to furnish him information on any matter falling within such
categories as may be prescribe in respect of villages within his jurisdiction or any part thereof or any
person or property therein and such Executive Authority shall comply with such order.(2)The order
shall specify the period within which it may be complied with but the Executive Authority may, from
time to time, extend such period.
135. Limitation for recovery of dues.
- No distraint shall be made, no suit shall be instituted and no prosecution shall be commenced in
respect of any tax or other amount due to a Gram Panchayat under this Act or any rule, bye-law,
regulation or order made under it after the expiration of a period of three years from the date on
which distraint might first have been made, a suit might first have been instituted, or prosecution
might first have been commenced, as the case may be, in respect of such tax or amount.
136. Persons empowered to prosecuted.
- Save as otherwise expressly provided in this Act, no person shall be tried for any offence against
this Act or any rule or bye-law made thereunder, unless complaint is made within twelve months of
the commission of the offence by the police, the Executive Authority or person expressly authorised
in this behalf by the Gram Panchayat or Executive Authority:Provided that failure to take out a
licence, obtain permission or secure registration under this Act, shall, for the purposes of this
Section be deemed a continuing offence until the expiration of the period, if any, for which the
licence, permission or registration is required and if no period is specified, complaint may be made
at any time within twelve months from the commencement of the offence.
137. Power to compound offences.
(1)The Executive Authority may, subject to such restrictions and control, as may be prescribed,
compound for a sum not exceeding rupees five hundred, any offence against the provisions of this
Act or any rule or bye-law made thereunder, which may by rules, be declared compoundable.(2)On
payment of the amount by way of composition no further proceedings shall be taken or continuedAndhra Pradesh Panchayat Raj Act, 1994

against the defaulter in regard to the offence or alleged offence so compounded.(3)Nothing in this
Section shall apply to election offences.
138. prosecutions and compositions to be reported to Gram Panchayat.
- Every prosecution instituted or offence compounded by the Executive Authority shall be reported
by him to the Gram Panchayat at its next meeting.
138A. [ Notice of action against Gram Panchayat. [Inserted by Section 5 of
Act No. 37 of 2001.]
(1)Subject to the provisions of Section 138, no suit or other legal proceeding shall be brought against
any Gram Panchayat or the Sarpanch or the executive authority or any member, officer or servant of
such Gram Panchayat or against any person acting under the direction of such Gram Panchayat,
Sarpanch, executive authority, member, officer or servant, in respect of any act done or purporting
to be done under this Act or in respect of any alleged neglect or default in the execution of the
provisions of this Act or any rule, bye-law, regulation or order made under it, until the expiration of
two months next after notice in writing stating the cause of action, the nature of the relief sought,
the amount of compensation claimed and the name and place of residence of the intended plaintiff,
has been left at the office of the Gram Panchayat and if the proceeding is intended to be brought
against any such Sarpanch, executive authority, member, officer, servant or person, also delivered to
him or left at his place of residence, and unless such notice is given, the court shall not entertain
such suit or legal proceeding.(2)Every such proceeding shall, unless it is a proceeding for the
recovery of immovable property or for a declaration of title thereto, be commenced within six
months after the date on which the cause of action arose or in case of a continuing injury or damage,
during such continuance or within six months after the ceasing thereof.(3)If any Gram Panchayat or
person to whom notice is given under sub-Section (1) tenders amends to the plaintiff before the
proceeding is commenced and if the plaintiff does not in such proceeding recover more than the
amount so tendered, he shall not recover any costs incurred by him after such tender, and the
plaintiff shall also pay all cost incurred by the defendant after such tender.]
139. Assistance of police to the Gram Panchayat.
- Every Police Officer in whose jurisdiction the village is situated, shall be bound to assist the Gram
Panchayat and its officers and servants in the exercise of their lawful authority.
140. Wrongful restraint of Executive Authority or his delegates.
- Any person who prevents the Executive Authority or any person to whom the Executive Authority
has lawfully delegated his powers of entering on or into any place, building or land, from exercising
his lawful power of entering thereon or thereinto shall be deemed to have committed an offence
under Section 344 of the Indian Penal Code (Central Act 45 of 1860).Andhra Pradesh Panchayat Raj Act, 1994

141. Punishment for obstructing Gram Panchayat.
- Whoever obstructs a Gram Panchayat or the Sarpanch, the Executive Authority or a member of the
Gram Panchayat or any person employed by the Gram Panchayat or any person with whom it has
contracted in the performance of its duty under the provisions of this Act or of any rule made
thereunder, or prevents or tries to prevent any person from doing anything which he is empowered
or required to do, by virtue of this Act, or removes any mark set up for the purpose of indicating any
level or direction incidental to the carrying out of any work authorised by this Act, or removes,
destroys, or defaces or otherwise obliterates any notice put up or exhibited by the Gram Panchayat
or under its authority, shall be liable on conviction to a fine not exceeding fifty rupees.
142. Penalty for not giving information or giving false information.
- Any person required by this Act or by any notice or other proceedings issued thereunder to furnish
any information, who omits to furnish such information or knowingly furnishes false information
shall be punishable with fine not exceeding ten rupees.Supplemental Provisions
143. Special provisions in the case of [***] [Omitted by Section 2 (i) of Act No.
2 of 1996.] Gram Panchayats.
(1)Notwithstanding anything in this Act, when a local area is notified as a village under Section 3, for
the first time, the Commissioner shall appoint a special officer to exercise the powers and perform
the functions of the Gram Panchayat and its Sarpanch and Executive Authority until the members
and Sarpanch thereof who are duly elected assume office.(2)The special officer shall cause
arrangements for the election of the members of the Gram Panchayat to be made before such date as
may be fixed by the Commissioner in this behalf:Provided that the Commissioner may, from time to
time, postpone the date so fixed, if for any reason, the elections cannot be completed before such
date.(3)[ "The Government, or as the case may be, an officer authorised by the Government, shall
appoint a special officer or a person-in-charge or a committee of persons-in-charge to a Gram
Panchayat, if for any reason, the process of election to such Gram Panchayat is not
completed.(4)The special officer or person-in-charge or the committee of persons-in-charge,
appointed under sub-Section (3) shall exercise the powers and perform the functions of the gram
panchayat and its Sarpanch and executive authority until the members and Sarpanch elected thereof
assume office".] [Added by Section 2 (ii) of Act No. 2 of 1996.]
144. Public roads, markets, wells, tanks etc., to be open to all.
- All roads, markets, wells, tanks, reservoirs and water ways vested in or maintained by a Gram
Panchayat shall be open to the use and enjoyment of all persons, irrespective of their caste and
creed.Andhra Pradesh Panchayat Raj Act, 1994

145. Power to farm out fees.
- A Gram Panchayat shall have power to farm out the collection of any fees due to it under this Act
or any rule, bye-law or regulation made thereunder, for any period not exceeding three years at a
time on such conditions as it thinks fit.
146. Extension of provisions of law relating to District Municipalities or of
rules thereunder.
(1)The Commissioner may, at the request of the Gram Panchayat or otherwise, by notification,
declare that any of the provisions of the law relating to municipalities for the time being in force or
of any rule made thereunder including those relating to taxation, shall be extended to and be in
force in the village or any specified area therein.(2)The provisions so notified shall be construed
with such alterations not affecting the substance as may be necessary or proper for the purpose of
adopting them to the village or specified area therein.(3)Without prejudice to the generality of the
foregoing provision, all references to a municipal council or the Chairperson or the Executive
Authority thereof shall be construed as references to the Gram Panchayat or the Sarpanch or the
Executive Authority thereof, all references to any officer or servant of a municipal council as
reference to corresponding officer or servant of the Gram Panchayat and all references to the
municipal limits as references to the limits of the village or the specified area therein, as the case
may be.
147. Transfer of functions of Gram Panchayats to other local authorities or
vice-versa.
- Notwithstanding anything in this Act, or in any law relating to other local authorities, the
Government may, in consultation with the [Mandal Praja Parishad] [Substituted 'Mandal Parishad'
by Act No. 41 of 2006, dated 23.9.2006.] or [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by
Act No. 41 of 2006, dated 23.9.2006.] or other local authority as the case may be, and the Gram
Panchayat concerned, by notification, and subject to such restrictions and conditions and to such
control and revision as may be specified therein, direct that, -(i)any power or function vested in the
Gram Panchayat by or under this Act, shall be transferred to and exercised and performed by the
[Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or
[Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or the
other local authority; and(ii)any power or function vested in the [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or [Zilla Praja Parishad]
[Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or the other local authority
shall be transferred to and exercised and performed by the Gram Panchayat.Explanation. - For the
purpose of this Section, 'local authority' includes, the Andhra Pradesh Industrial Infrastructure
Corporation Limited.Andhra Pradesh Panchayat Raj Act, 1994

Part III – Constitution and Incorporation, Composition, Powers,
Functions, Etc., of [Mandal Praja Parishads] [Substituted
'Mandal Parishads' by Act No. 41 of 2006, dated 23.9.2006.]
148. Constitution and incorporation of [Mandal Praja Parishads] [Substituted
'Mandal Parishads' by Act No. 41 of 2006, dated 23.9.2006.].
(1)There shall be constituted by the Government by notification from time to time, and with effect
on and from such date, as may be specified therein constitute a [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] for each mandal.(2)Where
under sub-Section (2) of Section 3 of the Andhra Pradesh Districts (Formation) Act, 1974 (Act 7 of
1974), a Mandal is redelimited or a new Mandal is formed, the Government may, by notification,
reconstitute the [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006,
dated 23.9.2006.] for the redelimited Mandal or constitute a new [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] for the new Mandal. On
such reconstitution or constitution the [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by
Act No. 41 of 2006, dated 23.9.2006.] or [Mandal Praja Parishads] [Substituted 'Mandal Parishads'
by Act No. 41 of 2006, dated 23.9.2006.] concerned functioning immediately before such
reconstitution or constitution, shall stand abolished:Provided that in reconstituting the [Mandal
Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] the
Government may direct that the President, the Vice-President or an elected member of the [Mandal
Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] which was
functioning immediately before such redelimitation and who is otherwise qualified to hold such
office in the reconstituted [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of
2006, dated 23.9.2006.] shall be the President, Vice-President or elected member of the
reconstituted [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.] as if he was elected to such office in the reconstituted [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.].(3)Where after a [Mandal
Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] is
constituted for a Mandal, a part of such Mandal is included in a neighbouring Municipality or
Municipal Corporation, and,(i)in case the residuary part of the Mandal is viable for the constitution
of a separate [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.] such residuary part shall be redelimited into a separate Mandal under the Andhra
Pradesh Districts (Formation) Act, 1974 (Act 7 of 1974) and a [Mandal Praja Parishad] [Substituted
'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] shall be constituted for such newly
formed Mandal and that portion of the Mandal prior to its redelimitation which is included in the
neighbouring Municipality or Municipal Corporation shall be included in an adjoining Mandal
which forms part of such Municipality or Municipal Corporation; or(ii)in case the residuary portion
of the Mandal is not viable to be constituted into a separate [Mandal Praja Parishad] [Substituted
'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.], it shall be competent for the
Government, -(a)to include such residuary portion of the Mandal in the adjoining Mandal or
Mandals and abolish the [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 ofAndhra Pradesh Panchayat Raj Act, 1994

2006, dated 23.9.2006.] constituted for such Mandal; or(b)to form a new Mandal by adding to such
residuary portion, areas from the adjoining Mandal or Mandals and constitute a [Mandal Praja
Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] for such new
Mandal:Provided that where a [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No.
41 of 2006, dated 23.9.2006.] is constituted under clause (i) or sub-clause (b) of clause (ii), the
Government may direct that the President, Vice-President or an elected member of the abolished
[Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.]
who is otherwise qualified to hold such office in the newly constituted [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] shall be the President,
Vice-President or elected Member of the newly constituted [Mandal Praja Parishad] [Substituted
'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] as if he was elected to such office in the
newly constituted [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006,
dated 23.9.2006.].Explanation. - For the removal of doubts it is hereby declared that, -(i)the
President, Vice-President or an elected member of the newly constituted [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] continued under this
sub-Section shall hold office only for the residue of the term of the President, Vice-President or an
elected member of the abolished [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No.
41 of 2006, dated 23.9.2006.]:Provided further that where a [Mandal Praja Parishad] [Substituted
'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] is abolished under clause (a), the
President, Vice-President or an elected member holding office immediately before such abolition
shall unless he is continued under the foregoing proviso cease to hold their respective
offices.(4)Every [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006,
dated 23.9.2006.] shall, by the name of the Mandal for which it is constituted or reconstituted, be a
body corporate having perpetual succession and a common seal with power to acquire, hold and
dispose of property and to enter into contracts and may by its corporate name sue and be
sued.(5)The notification under sub-Section (2) may contain such supplemental, incidental and
consequential provisions as the Government may deem necessary and the Government may, from
time to time, amend any such notification.
149. Composition of [Mandal Praja Parishad] [Substituted 'Mandal Parishad'
by Act No. 41 of 2006, dated 23.9.2006.].
(1)Every [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.] shall consist of the following members namely:-(i)persons elected under Section
151;(ii)the Member of the Legislative Assembly of the State representing a constituency which
comprises either wholly or partly the Mandal concerned;[(ii-a) any Member of the Legislative
Council of the State who is a registered voter in the Mandal concerned;] [Inserted by Act No. 22 of
2007, dated 9.8.2007.](iii)the Member of the House of the People representing a constituency
which comprises either wholly or partly the Mandal concerned;(iv)any Member of the Council of
States who is a registered voter in the Mandal concerned;(v)one person belonging to minorities to be
co-opted in the prescribed manner by the members specified in clause (i) from among persons who
are registered voters in the Mandal and who are not less than 21 years of age.(2)No person shall be a
member in more than one of the categories specified in sub-Section (1). A person who is or becomes
a Member of [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, datedAndhra Pradesh Panchayat Raj Act, 1994

23.9.2006.] in more than one such category shall, by notice in writing signed by him and delivered
to the [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.] Development Officer, within fifteen days from the date of the first meeting referred to in
sub-Section (3) of Section 153, intimate in which one of the said categories he wishes to serve, and
thereupon he shall cease to be the Member in the other category or categories. In default of such
intimation within the aforesaid period, his membership in the [Mandal Praja Parishad] [Substituted
'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] category acquired earlier shall, and his
membership acquired later in the other shall not, cease at the expiration of such period. The
intimation given under this sub-Section shall be final and irrevocable.
150. Division of Mandal into constituencies.
- For the purpose of electing the members specified in clause (i) of sub-Section (1) of Section 149,
the Commissioner shall, subject to such rules as may be made in this behalf, divide each [Mandal
Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] area into
as many territorial constituencies as he may, by notification specify, in such manner that, as far as
practicable, shall consist of a population ranging between three thousand and four thousand; and
that the ratio between the population of each constituency and the number of seats allotted to it
shall, as far practicable, be the same throughout the [Mandal Praja Parishad] [Substituted 'Mandal
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] area:Provided that the ratio between the
population of the territorial area of a [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act
No. 41 of 2006, dated 23.9.2006.] and the number of seats in such Parishad to be filled by election
shall, as far as practicable, be the same throughout the State.
151. Election of members from territorial constituencies.
(1)One member shall be elected to the [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by
Act No. 41 of 2006, dated 23.9.2006.] from each territorial constituency specified in Section 150 by
the method of secret ballot by the persons who are registered voters in the territorial constituency
concerned:Provided that a registered voter in the [Mandal Praja Parishad] [Substituted 'Mandal
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] shall be entitled to contest from any territorial
constituency of the [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006,
dated 23.9.2006.].(2)For purpose of preparation and publication of the electoral roll for the
elections to the office of member under this Section, the provisions of Sections 11 and 12 shall,
mutatis mutandis apply, subject to such rules as may be made in this behalf.
152. Reservation of seats of Members of [Mandal Praja Parishad] [Substituted
'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.].
(1)In every [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.] out of the total strength of elected members determined under Section 150, the
Commissioner shall, subject to such rules as may be prescribed, by notification, reserve-(a)such
number of seats to the members belonging to Scheduled Castes and Scheduled Tribes as may beAndhra Pradesh Panchayat Raj Act, 1994

determined by him, subject to the condition that the number of seats so reserved shall bear, as
nearly as may be, the same proportion to the total number of seats to be filled by direct election to
the [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.], as the population of the Scheduled Castes, or as the case may be, the Scheduled Tribes
in that Mandal bears to the total population of that Mandal, and such seats may be allotted by
rotation to different constituencies in a [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by
Act No. 41 of 2006, dated 23.9.2006.] in the manner prescribed.[***] [Omitted by Section 6 (A) (i)
of Act 5 of 1995.](c)not less than one-third of the total number of seats reserved under [clause (a)
and sub-Section (1A)] [Subs by Section 6 (A) (ii) of Act 5 of 1995.] for women belonging to the
Scheduled Castes, Scheduled Tribes or as the case may be, the Backward Classes;(d)not less than
one-third (including the number of seats reserved for women belonging to the Scheduled Castes,
Scheduled Tribes and Backward Classes) of the total number of seats to be filled by direct election to
every [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.] shall be reserved for women and such may be allotted by rotation to different
constituencies in a [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006,
dated 23.9.2006.] in the manner prescribed.(1A)[ In addition to the reservation of seats under
sub-Section (1), there shall be reserved for the Backward Classes such number of seats as may be
allocated to them in each [Mandal Praja Parishad] [Inserted by Section 6 (B) of Act 5 of 1995.] in the
manner prescribed; so however that the number of offices of members of [Mandal Praja Parishads]
[Substituted 'Mandal Parishads' by Act No. 41 of 2006, dated 23.9.2006.] in the State reserved for
Backward Classes shall not be less than thirty-four per cent of the total number of offices of the
members of [Mandal Praja Parishads] [Substituted 'Mandal Parishads' by Act No. 41 of 2006, dated
23.9.2006.] in the State. The number of seats allocated to each [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] shall be allotted by rotation
to different territorial constituencies in the [Mandal Praja Parishad] [Substituted 'Mandal Parishad'
by Act No. 41 of 2006, dated 23.9.2006.]:Provided that it shall be competent for the Government to
make special provisions with regard to the manner and quantum of seats to be reserved for
Backward Classes in the [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of
2006, dated 23.9.2006.] situated either wholly or partly in the Scheduled areas, by rules made in
this behalf.](2)Nothing in [sub-Sections (1) and 1A] [Subs by Section 6 (C) of Act 5 of 1995.] shall be
deemed to prevent women and Members of the Scheduled Castes, Scheduled Tribes or Backward
Classes from standing for election to the non-reserved seats in the [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.].
153. Election, reservation and term of office of President, Vice-President.
(1)For every [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.] there shall be one President and one Vice-President who shall be [elected by and from
among the elected members specified in clause (i) of sub-Section (1) of Section 149 by show of hands
duly obeying the party whip given by such functionary of the recognised political party as may be
prescribed] [Subs by Section 7 (A) (i) of Act 5 of 1995.]. If at an election held for the purpose no
President or Vice-President is elected, fresh election shall be held. The names of the President and
the Vice-President so elected shall be published in the prescribed manner:Provided that if a Member
of the Legislative Assembly of the State or of either House of Parliament is elected to either of theAndhra Pradesh Panchayat Raj Act, 1994

said offices, he shall cease to hold such office unless within fifteen days from the date of election to
such office he ceases to be a Member of the Legislative Assembly of the State or of either House of
Parliament by resignation or otherwise:[Provided further that a member voting under this
sub-section in disobedience of the party whip [shall cease to hold office in the manner prescribed]
[Added by Section 7 (A) (ii) of Act 5 of 1995.] and the vacancy caused by such cessation shall be filled
as a casual vacancy.](2)Out of the total number of offices of President in the State, the
Commissioner shall, subject to such rules as may be prescribed, by notification reserve -(a)such
number of offices to the members belonging to Scheduled Castes and Scheduled Tribes as may be
determined by him, subject to the condition that the number of offices so reserved shall bear, as
nearly as may be, the same proportion to the total number of offices to be filled in the State as the
population of the Scheduled Castes or as the case may be, the Scheduled Tribes in the State bears to
the total population of the State; and such offices may be allotted by rotation to different [Mandal
Praja Parishads] [Substituted 'Mandal Parishads' by Act No. 41 of 2006, dated 23.9.2006.] in the
State in the manner prescribed.[***] [Omitted by Section 7 (B) (i) of Act 5 of 1995.](c)not less than
one-third of the total number of offices reserved under [clause (a) and sub-Section 2A] [Subs by
Section 7 (B) (ii) of Act 5 of 1995.] for women belonging to the Scheduled Castes, Scheduled Tribes,
or as the case may be, the Backward Classes; and(d)not less than one-third (including the number of
offices reserved for women belonging to the Scheduled Castes, Scheduled Tribes and the Backward
Classes) of the total number of offices to be filled in the State for women; and such offices may be
allotted by rotation to different [Mandal Praja Parishads] [Substituted 'Mandal Parishads' by Act
No. 41 of 2006, dated 23.9.2006.] in the State in the manner prescribed.(2A)[ In addition to the
reservation of offices of President under sub-Section (1), there shall be reserved for the Backward
Classes such number of offices of President as may be allocated to them in each district in the
manner prescribed; so however, that the number of offices of President in the State reserved for
Backward Classes shall not be less than thirty-four per cent of the total number of offices of
Presidents of [Mandal Praja Parishads] [Inserted by Section 7 (B) (iii) of Act 5 of 1995.] in the State.
The number of offices of Presidents allocated for reservation to each district shall be allotted by
rotation to different [Mandal Praja Parishads] [Substituted 'Mandal Parishads' by Act No. 41 of
2006, dated 23.9.2006.] in the district.](3)The first meeting of the [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] to elect a President and
Vice-President shall be called as soon as may be, after the results of the ordinary elections to the
office of elected members of the [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No.
41 of 2006, dated 23.9.2006.] have been published. The notice of the date and time of the meeting
for the election of President and Vice-President shall be given to the elected members in the
prescribed manner:Provided that if, for any reason, the election of the President or Vice-President is
not held on the date fixed as aforesaid, the meeting for the election of the President and
Vice-President shall be held on the next day, whether or not it is a holiday observed by the [Mandal
Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.].(4)Every
President or Vice-President shall cease to hold office on the expiration of his term of office as a
member.(5)Save as otherwise expressly provided in, or prescribed under this Act, the term of office
of the President or Vice-President who is elected at an ordinary election shall be five years from the
date appointed by the Andhra Pradesh Election Commissioner for Local Bodies for the first meeting
of the [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.] after the ordinary election.(6)Any casual vacancy in the office of the President orAndhra Pradesh Panchayat Raj Act, 1994

Vice-President shall be filled within a period of six months from the date of occurrence of the
vacancy by a fresh election under sub-Section (3) and a person elected as President or
Vice-President in any such vacancy shall hold office only so long as the person in whose place he is
elected would have been entitled to hold office if the vacancy had not occurred.
153A. [ Resolution of disputes relating to cessation for disobedience of party
whip. [Inserted by Act No. 22 of 2006, dated 19.4.2006.]
- Where a member against whom a proceeding that he ceased to hold office as a consequence of the
disobedience of the party whip is issued in pursuance of the second proviso to sub-section (1) of
Section 153 and the affected member disputes the correctness of the proceedings, he may apply to
the District Court having jurisdiction over the area in which the office of the [Mandal Praja
Parishad] is situated, for a decision.]
154. Term of office of member of [Mandal Praja Parishad] [Substituted
'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.].
- Save as otherwise provided in this Act, -(i)an ex-officio member of the [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] shall hold office so long as
he continues to hold the office by virtue of which he became such ex-officio member;(ii)a member
elected at an ordinary election or a co-opted member shall hold office for a term of five years from
the date appointed by the Andhra Pradesh Election Commissioner for Local Bodies for the first
meeting of the [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.] after the said ordinary election.
155. Qualification of candidates for election.
- No person shall be eligible for election as member of a [Mandal Praja Parishad] [Substituted
'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] unless his name appears in the electoral
roll of the [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.] concerned and he has completed the age of twenty-one years.
156. Disqualifications.
(1)A member of the [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006,
dated 23.9.2006.] shall be disqualified for election as President or Vice-President if he is in arrears
of any dues, otherwise than in a fiduciary capacity to a Gram Panchayat, a [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or the [Zilla Praja
Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or if he is interested
in a subsisting contract made with, or any work being done for, any Gram Panchayat in the Mandal
or the [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.] or the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated
23.9.2006.] within whose jurisdiction the [Mandal Praja Parishad] [Substituted 'Mandal Parishad'Andhra Pradesh Panchayat Raj Act, 1994

by Act No. 41 of 2006, dated 23.9.2006.] is situated or any other [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] within the jurisdiction of
that [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated
23.9.2006.]:Provided that a person shall not be deemed to have any interest in such contract or
work by reason only of his having a share or interest in -(i)a company as a mere shareholder but not
as a director;(ii)any lease, sale or purchase of immovable property or any agreement for the same;
or(iii)any agreement for the loan of money or any security for the payment of money only;or(iv)any
newspaper in which any advertisement relating to the affairs of any of aforesaid [Mandal Praja
Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] is
Inserted.(2)The provisions of [Sections 18, 19, 19-A, 19-B, 20, 21 and 22] [Substituted 'Sections 18,
19, 20, 21 and 22' by Act No. 22 of 2006, dated 19.4.2006.] shall apply to a member of the [Mandal
Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] as they
apply to a member of the Gram Panchayat subject to the variations that for the expressions, "Gram
Panchayat," "Executive Authority," "Sarpanch," "Upa-Sarpanch" and "District Panchayat Officer,"
the expressions "[Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006,
dated 23.9.2006.]", "[Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006,
dated 23.9.2006.] Development Officer", "President," "Vice-President" and "Chief Executive
Authority," shall respectively be substituted:Provided that nothing in clause (b) of Section 20 shall
apply to a member of the [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of
2006, dated 23.9.2006.] specified in clause (ii), clause (iii) and clause (iv) of sub-Section (1) of
Section 149.
157. Resignation of President, Vice-President or member.
- The President, the Vice-President, elected member or co-opted member may resign his office in
such manner as may be prescribed.
158. Permanent invitees to the meetings of the [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.].
- The Collector, the Sarpanches of all the Gram Panchayats within the jurisdiction of the [Mandal
Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.], [the
member of the [Zilla Praja Parishad] [Subs by Section 8 of Act No. 5 of 1995.] specified in clause (i)
of sub-Section (3) of Section 177 elected from the Mandal concerned, the Chairperson, [Zilla Praja
Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.], and the President
of Agricultural Marketing Committee] shall be permanent invitees to the meetings of the [Mandal
Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] and they
shall have the right to speak in and otherwise to take part in the proceedings of any meeting of a
[Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.]
functioning within the local limits of their respective jurisdictions but shall not, by virtue of this
Section be entitled to vote at any such meeting.Andhra Pradesh Panchayat Raj Act, 1994

159. President of a [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by
Act No. 41 of 2006, dated 23.9.2006.] may invite certain persons to attend its
meetings.
(1)The President of a [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006,
dated 23.9.2006.] may for purposes of consultation, invite any person other than an office bearer of
any political party having experience and specialised knowledge of any subject under the
consideration of the [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006,
dated 23.9.2006.] to attend the meeting of the [Mandal Praja Parishad] [Substituted 'Mandal
Parishad' by Act No. 41 of 2006, dated 23.9.2006.]. Such person shall have the right to speak in, and
otherwise to take part in the proceedings of such meeting but shall not, by virtue of this Section be
entitled to vote at any such meeting.(2)A person attending a meeting under sub-Section (1) shall be
entitled to such allowances as may be prescribed.
160. Rules for the conduct of the business at a meeting of a [Mandal Praja
Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.].
- Every [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.] shall in regard to the conduct of business at its meetings, follow such rules as may be
prescribed.
161. Powers and functions of a [Mandal Praja Parishad] [Substituted 'Mandal
Parishad' by Act No. 41 of 2006, dated 23.9.2006.].
(1)Subject to the provisions of this Act, the administration of the Mandal shall vest in the [Mandal
Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.]. Every
[Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.]
shall endeavour to install among the people within its jurisdiction spirit of self-help and initiative
and harness their enthusiasm for raising the standard of living, it shall exercise all the powers
conferred on, and perform all the functions entrusted to it by or under this Act, and such other
powers and functions as may be conferred on, and entrusted to it by the Government for carrying
out the purposes of this Act, but it shall not exercise the powers or perform the functions expressly
assigned by or under this Act, or any other law to its President or to the [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] Development Officer or the
[Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or any
other authority, it shall do extension and review functions at the mandal level effectively. It may,
with the previous approval of the Government and subject to such terms and conditions as may be
prescribed borrow moneys for carrying out the purposes of this Act. It shall also exercise and
perform such of the powers and functions of the District Board including the powers to levy any tax
or fees as may be transferred to it under this Act.(2)Every [Mandal Praja Parishad] [Substituted
'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] shall exercise such powers and perform
such functions as may be entrusted to it by rules made in this behalf in regard to the subjectsAndhra Pradesh Panchayat Raj Act, 1994

enumerated in Schedule I. In particular, the [Mandal Praja Parishad] [Substituted 'Mandal
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] shall exercise the powers and perform the
functions specified in Schedule-II.(3)Notwithstanding anything in this Act, the [Mandal Praja
Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] may with the
prior approval of the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated
23.9.2006.] levy contributions from the funds of the Gram Panchayats in the Mandal.(4)Every
[Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.]
may levy with the prior sanction of the Government a duty in the form of a surcharge on any tax
imposed by a Gram Panchayat or on land cess or local cess levied within its jurisdiction in such
manner and subject to such maximum as may be prescribed.
162. Maintenance of common water works and other institutions.
(1)Notwithstanding anything in this Act and subject to the rules made in this behalf, two or more
Gram Panchayats may, -(i)construct and maintain water works for supply of water for washing and
bathing purposes and protected water for drinking purposes from a common source, and(ii)entrust
to [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.]
with its consent and on such terms as may be agreed upon the management of any institution or the
execution or maintenance of any work.(2)Subject to the provisions of this Act and the rules made
thereunder, two or more [Mandal Praja Parishads] [Substituted 'Mandal Parishads' by Act No. 41 of
2006, dated 23.9.2006.] may establish and maintain common dispensaries, child welfare centres
and institutions of such other kinds, as may be prescribed.
163. Power of [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act
No. 41 of 2006, dated 23.9.2006.] to call for documents from the [Mandal Praja
Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.] Development Officer.
- A [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.] may, at any time require the [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by
Act No. 41 of 2006, dated 23.9.2006.] Development Officer to furnish any document in his custody.
The said officer shall comply with every such requisition.
164. Power of [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act
No. 41 of 2006, dated 23.9.2006.] to call for information from Executive
Authority.
- A [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.] may require any Executive Authority of any village within the jurisdiction of the
[Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] to
furnish any information on any matter falling within such categories as may be prescribed in respect
of such village or any person or property therein required for the purposes of this Act.Andhra Pradesh Panchayat Raj Act, 1994

165. Powers and functions of the President and Vice-President.
(1)The President of a [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006,
dated 23.9.2006.] shall, -(a)exercise administrative control over the [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] Development Officer for
the purposes of implementation of the resolution of the [Mandal Praja Parishad] [Substituted
'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.];(b)preside over and conduct the
meetings of the [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006,
dated 23.9.2006.]; and(c)have full access to all records of the [Mandal Praja Parishad] [Substituted
'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.].(2)In case of emergency the President
may in consultation with the [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41
of 2006, dated 23.9.2006.] Development Officer direct the execution of any work or the doing of any
act which requires the sanction of the [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by
Act No. 41 of 2006, dated 23.9.2006.] and the immediate execution or the doing of which is, in his
opinion, necessary for the service or safety of the general public, but he shall report the action taken
under this sub-Section and the reasons therefor to the [Mandal Praja Parishad] [Substituted
'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] at its next meeting:Provided that he
shall not direct the execution of any work or the doing of any act in contravention of any order of the
Government.(3)The Vice-President shall exercise such powers and perform such functions of the
President as the President may, from time to time, delegate to him in writing.(4)When the office of
the President is vacant the Vice-President of the [Mandal Praja Parishad] [Substituted 'Mandal
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] shall exercise the powers and perform the
functions of the President until a new President is elected.(5)If the President has been continuously
absent from the Mandal for more than fifteen days or is incapacitated for more than fifteen days, his
powers and functions during such absence or incapacity shall devolve on the
Vice-President.(6)When the office of the President is vacant or the President has been continuously
absent from the Mandal for more than fifteen days or is incapacitated for more than fifteen days and
there is either a vacancy in the office of Vice-President or the Vice-President has been continuously
absent from the Mandal for more than fifteen days or is incapacitated for more than fifteen days, the
powers and functions of the President shall devolve on a member of the [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] appointed by the
Government in this behalf. The member so appointed shall be styled as the temporary President and
he shall exercise the powers and perform the functions of the President subject to such restrictions
and conditions as may be prescribed until a new President or Vice-President assumes office after his
election or until the President or the Vice-President returns to the Mandal or recovers from his
incapacity, as the case may be.
166. Right of individual members to draw attention in respect of [Mandal
Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.] etc.
- Any member of a [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006,
dated 23.9.2006.] may draw the attention of the President or the [Mandal Praja Parishad]Andhra Pradesh Panchayat Raj Act, 1994

[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] Development Officer to any
neglect in the execution of [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of
2006, dated 23.9.2006.] work, to any waste of [Mandal Praja Parishad] [Substituted 'Mandal
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] property or to the needs of any locality and may
suggest any improvement which may appear desirable.
167. Powers and functions of [Mandal Praja Parishad] [Substituted 'Mandal
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] Development Officer.
(1)The [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.] Development Officer shall be the Chief Executive Authority of the [Mandal Praja
Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.]. He shall be
responsible for implementing the resolutions of the [Mandal Praja Parishad] [Substituted 'Mandal
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] and shall also exercise such powers and perform
such functions as may be entrusted to him by the Government. He shall also exercise such powers of
supervision over the Gram Panchayats in the Mandal as may be prescribed.(2)The [Mandal Praja
Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] Development
Officer shall, with the approval of, or on the direction of the President, convene the meetings of the
[Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] so
that at least one meeting of the [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No.
41 of 2006, dated 23.9.2006.] is held every month and if the [Mandal Praja Parishad] [Substituted
'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] Development Officer fails to discharge
that duty, with the result that no meeting of the [Mandal Praja Parishad] [Substituted 'Mandal
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] is held within a period of ninety days from the
last meeting, he shall be liable to disciplinary action under the relevant rules:Provided that where
the President fails to give his approval for convening the meeting so as to hold a meeting within a
period of ninety days aforesaid, the [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act
No. 41 of 2006, dated 23.9.2006.] Development Officer may himself convene the meeting in the
manner prescribed.(3)The [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of
2006, dated 23.9.2006.] Development Officer shall ordinarily attend the meetings of the [Mandal
Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] and shall
be entitled to take part in the discussions thereat but he shall not be entitled to vote or to move any
resolution.(4)Subject to the provisions of Section 168 the staff borne on the establishment of the
[Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.]
and the staff working in institutions and schemes transferred by the Government or the Head of the
Department of Government to the [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act
No. 41 of 2006, dated 23.9.2006.] shall be under the administrative control and supervision of the
[Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.]
Development Officer.(5)Notwithstanding anything in sub-Section (1) of Section 161 and subject to
all other provisions of this Act, and the rules made thereunder, the [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] shall have power to issue
such specific direction as it may think fit regarding the performance by the [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] Development Officer of any
of the functions assigned to him under this Act.(6)The Government shall pay out of the ConsolidatedAndhra Pradesh Panchayat Raj Act, 1994

Fund of the State, the salaries, allowances, leave allowances, pension and contribution if any
towards the provident fund or provident fund-cum-pension fund of the [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] Development Officer
appointed by them for [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of
2006, dated 23.9.2006.].(7)The Government shall have power to make rules to regulate the
classification and methods of recruitment, conditions of services, pay and allowances and
disciplinary conduct of the [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of
2006, dated 23.9.2006.] Development Officer.
168. The [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No.
41 of 2006, dated 23.9.2006.] Development Officer and other officers and staff
of a [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of
2006, dated 23.9.2006.] to be subordinate to the [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.].
- The [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.] Development Officer and other officers and staff of a [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] and the staff employed in
the institutions and schools under the [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by
Act No. 41 of 2006, dated 23.9.2006.] shall be subordinate to the [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.].
169. Officers and other employees of [Mandal Praja Parishad] [Substituted
'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.].
(1)The Government may, at any time create such posts of officers and other employees of [Mandal
Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] as they
may consider necessary for carrying out the purposes of this Act.(2)All appointments to the posts
created under sub-Section (1) and transfer of the holders of such posts shall be made subject to the
provisions of the Andhra Pradesh Public Employment (Regulation of Age of Superannuation) Act,
1984 (Act 23 of 1984), the Andhra Pradesh(Regulation of Appointments to Public Services and
Rationalisation of Staff Pattern and Pay Structure) Act, 1994 (Act 2 of 1994) and such rules as may
be made under the proviso to Article 309 of the Constitution of India.(3)The Government shall pay,
out of the Consolidated Fund of the State, the salaries, allowances, leave allowances, pension and
contributions, if any, towards the provident fund or Pension-cum-Provident fund of the officers and
other employees of a [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006,
dated 23.9.2006.] who hold any of the posts referred to in sub-Section (1).(4)The classification and
methods of recruitment, conditions of service, pay and allowances and discipline and conduct of the
officers and other employees referred to in sub-Section (3), shall be regulated in accordance with the
provisions of the Andhra Pradesh Public Employment (Regulation of Age of Superannuation) Act,
1984 (Act 23 of 1984), the Andhra Pradesh (Regulation of Appointments to Public Services and
Rationalisation of Staff Pattern and Pay Structure) Act, 1994 (Act 2 of 1994) and such rules as may
be made under the proviso to Article 309 of the Constitution until rules in that behalf are so made,Andhra Pradesh Panchayat Raj Act, 1994

the law for the time being in force regulating the recruitment and conditions of service, pay and
allowances and conduct, applicable to such holder shall continue to apply to such holder.(5)The
Government may, from time to time, by order give such directions to any [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or any officer, authority, or
person thereof as may appear to them to be necessary for the purpose of giving effect to the
provisions of this Section and the [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act
No. 41 of 2006, dated 23.9.2006.] Development Officer, authority or person shall comply with all
such directions.
170. Allowances for attending a meeting of the [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.].
(1)There shall be paid to the members of a [Mandal Praja Parishad] [Substituted 'Mandal Parishad'
by Act No. 41 of 2006, dated 23.9.2006.] including its President and Vice-President and to the
Members of the Legislative Assembly and of either House of Parliament for attending a meeting of
the [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.] such allowances as may be prescribed.(2)There shall also be paid to the President in
respect of his tours on duty whether within or outside the Mandal but within the District such
allowances as may be prescribed.
171. [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of
2006, dated 23.9.2006.] Fund.
(1)All moneys received by a [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of
2006, dated 23.9.2006.] shall constitute a fund called the [Mandal Praja Parishad] [Substituted
'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] Fund and shall be applied for the
purposes specified in this Act and for such other purposes and in such manner as may be
prescribed.(2)All moneys received by the [Mandal Praja Parishad] [Substituted 'Mandal Parishad'
by Act No. 41 of 2006, dated 23.9.2006.] shall be lodged in the nearest Government
treasury:[Provided that the amounts received as funds under the Jawahar Rozgar Yojana,
Employment Assurance Scheme or other Wage Employment Schemes shall be lodged in nearby
Nationalised Banks or Co-operative Banks or Post Offices in such manner as may be prescribed.]
[Added by Section 3 of Act No. 16 of 1998.](3)All orders or cheques against the [Mandal Praja
Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] Fund shall be
signed by the [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.] Development Officer.
172. Income and expenses of a [Mandal Praja Parishad] [Substituted 'Mandal
Parishad' by Act No. 41 of 2006, dated 23.9.2006.].
(1)The sources of income of a [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41
of 2006, dated 23.9.2006.] shall consist of, -(i)funds relating to institutions and schemes
transferred by the Government or Heads of Departments of the Government to the [Mandal PrajaAndhra Pradesh Panchayat Raj Act, 1994

Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.];(ii)funds relating
to the community development programmes;(iii)Central and State aid and aid received from the All
India bodies and institutions for the development of cottage and village industries, khadi, silk, coir,
handicrafts and the like;(iv)donations and contributions received by the [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] from Gram Panchayats or
from the public in any form;(v)such income of the [Zilla Praja Parishad] [Substituted 'Zilla Parishad'
by Act No. 41 of 2006, dated 23.9.2006.] as the Government may, by order, allocate to it;(vi)such
share of the land revenue, State taxes or fees as may be prescribed;(vii)proceeds from taxes,
surcharge or fee which the [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of
2006, dated 23.9.2006.] is empowered to levy under this Act or any other law;(viii)such
contributions as the [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006,
dated 23.9.2006.] may levy from Gram Panchayats;(ix)any other income from remunerative
enterprises and the like.(2)Government shall also make an annual grant at the rate of five rupees per
person residing in the Mandal calculated on the basis of the last preceding census of which figures
are available.(3)The expenses of the [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act
No. 41 of 2006, dated 23.9.2006.] shall include the salaries and allowances of its officers and other
employees, the allowances to be paid under Sections 159 and 170, any item of expenditure directed
by the Government for carrying out the purposes of this Act and such other expenses as may be
necessary for such purposes.
173. Election expenses to be borne by the Government.
- The cost of the election expenses including the conduct of elections to the [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] and the cost of
maintenance of election establishment employed in connection therewith shall be borne by the
Government.
174. Budget of [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act
No. 41 of 2006, dated 23.9.2006.].
(1)The [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.] Development Officer shall, in each year frame and place before the [Mandal Praja
Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] on or before the
prescribed date a budget showing the probable receipts and expenditure during the following year,
and the [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.] shall sanction the budget with such modifications, if any, as it thinks fit.(2)The budget
as so sanctioned shall be submitted by the [Mandal Praja Parishad] [Substituted 'Mandal Parishad'
by Act No. 41 of 2006, dated 23.9.2006.] Development Officer on or before such date as may be
prescribed, to the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated
23.9.2006.] and where there is no such [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No.
41 of 2006, dated 23.9.2006.] to the District Collector, and if the [Zilla Praja Parishad] [Substituted
'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or the District Collector, as the case may be
is satisfied that adequate provision has not been made therein for giving effect to the provisions of
this Act, it or he shall have power to approve the budget with such modifications as may beAndhra Pradesh Panchayat Raj Act, 1994

necessary to secure such provisions.(3)If, for any reason the budget is not sanctioned by the
[Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.]
under sub-Section (1) before the date referred to in sub-Section (2) the [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] Development Officer shall
submit the budget to the District Collector who shall sanction it with such modifications, if any, as
he thinks fit and forward it to the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of
2006, dated 23.9.2006.] which shall thereupon approve the budget as if it were submitted to it
under sub-Section (2), where there is no [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act
No. 41 of 2006, dated 23.9.2006.] for the District, the sanction accorded by the District Collector
shall be final.(4)If, in the course of a year, the [Mandal Praja Parishad] [Substituted 'Mandal
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] finds it necessary to make any alterations in the
budget with regard to its receipts or items of expenditure, a revised or supplemental budget may be
framed, submitted and sanctioned or approved as far as may be in the manner provided in
sub-Sections (1), (2) and (3).
175. Joint Committee of [Mandal Praja Parishad] [Substituted 'Mandal
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] and other local authorities.
- A [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.] may, and if so required by the Government shall, join with one or more than one other
local authority in constituting a joint committee for any purpose for which they are jointly
responsible.
176. Constitution, powers and functions of Joint Committee.
- The constitution, powers and procedure of the Joint Committee referred to in Section 175 and the
method of settling differences of opinion arising in connection with such committee between the
local authorities concerned shall be in accordance with such rules as may be prescribed.
Part IV – Constitution, Incorporation, Composition, Powers,
Functions, Etc., of [Zilla Praja Parishad] [Substituted 'Zilla
Parishads' by Act No. 41 of 2006, dated 23.9.2006.]
177. Constitution, incorporation and composition of [Zilla Praja Parishad]
[Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.].
(1)There shall be constituted by the Government by notification a [Zilla Praja Parishad] [Substituted
'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] for a District with effect from such date as
may be specified therein.(2)Every [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of
2006, dated 23.9.2006.] shall, by the name of the District for which it is constituted, be a body
corporate having perpetual succession and a common seal with power to acquire, hold and dispose
of property and to enter into contracts and may by its corporate name, sue and be sued.(3)EveryAndhra Pradesh Panchayat Raj Act, 1994

[Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] shall
consist of the following members, namely:-(i)persons elected under Section 179;(ii)the Member of
the Legislative Assembly of the State representing the constituency which comprises either wholly or
partly the district concerned:Provided that such Member of the Legislative Assembly shall have the
right to speak in and otherwise to take part in the proceedings of a meeting of any Standing
Committee of the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated
23.9.2006.] but he shall not be entitled to vote at a meeting of such Standing Committee, unless he
is also a member of that Standing Committee:Provided further that no Member of the Legislative
Assembly representing a constituency the whole of which forms part of the local area within the
jurisdiction of any of the Municipal Corporations or any of the Municipalities in the State shall be
the member of the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated
23.9.2006.] of the concerned district;[(ii-a) any Member of the Legislative Council of the State who
is a Member of the Mandal Praja Parishad; [Inserted by Act No. 22 of 2007, dated
9.8.2007.]Provided that such Member of the Legislative Council of the State shall have the right to
speak in, and otherwise to take part in the proceedings of a meeting of any standing committee of
the zilla Praja Parishad, but he shall not be entitled to vote at a meeting of any standing committee,
unless he is also a member of that standing committee.](iii)The member of the House of People
representing the constituency which comprises either wholly or partly the district
concerned:Provided that no Member of the House of the People representing a constituency the
whole of which forms part of the local area within the jurisdiction of any of the Municipal
Corporations in the State shall be the Member of the [Zilla Praja Parishad] [Substituted 'Zilla
Parishad' by Act No. 41 of 2006, dated 23.9.2006.]:Provided further that a Member of the House of
the People representing a constituency which comprises more than one district including a portion
of any district, shall be a member of the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act
No. 41 of 2006, dated 23.9.2006.] of all such districts with the right to speak in, and otherwise to
take part in the proceedings of their meetings with voting rights; he shall also have the right to speak
in and otherwise to take part in the meetings of any Standing Committee of the [Zilla Praja
Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] but he shall not be
entitled to vote at a meeting of any Standing Committee unless he is also a member of that Standing
Committee.(iv)the Member of the Council of States who is a registered voter in the district:Provided
that such Member of the Council of States shall have the right to speak in, and otherwise to take part
in the proceedings of a meeting of any Standing Committee of the [Zilla Praja Parishad] [Substituted
'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.], but he shall not be entitled to vote at a
meeting of that Standing Committee, unless he is also a member of that Standing Committee;(v)two
persons belonging to minorities to be co-opted in the prescribed manner by the members specified
in clause (i) from among persons who are registered voters in the District and who are not less than
21 years of age.(4)No person shall be a Member in more than one of the categories specified in
sub-Section (3). A person who is or becomes a Member of a [Zilla Praja Parishad] [Substituted 'Zilla
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] in more than one such category, shall, by notice
in writing signed by him and delivered to the Chief Executive Authority, within fifteen days from the
date of the first meeting of the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of
2006, dated 23.9.2006.] referred to in sub-Section (4) of Section 181, intimate in which one of the
said categories he wishes to serve, and thereupon, he shall cease to be the member in the other
category or categories. In default of such intimation within the aforesaid period, his membership inAndhra Pradesh Panchayat Raj Act, 1994

the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] in
the category acquired earlier shall, and his membership acquired later in the other category shall
not, cease at the expiration of such period. The intimation given under this sub-Section shall be final
and irrevocable.(5)No person other than a Member of the House of the People, shall be entitled to
be a member of more than one [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of
2006, dated 23.9.2006.] at a time.
178. Mandals to be territorial constituencies.
- For purposes of electing the members specified in clause (i) of sub-Section (3) of Section 177 every
Mandal in the District shall be a territorial constituency and the Andhra Pradesh Election
Commissioner for Local Bodies shall allot not more than one seat for each such territorial
constituency.
179. Election of members from territorial constituencies.
(1)One member shall be elected to the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No.
41 of 2006, dated 23.9.2006.] from each territorial constituency specified in Section 178 by the
method of secret ballot by the registered voters in the territorial constituency concerned:Provided
that a registered voter in the district shall be entitled to contest from any territorial constituency of
the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated
23.9.2006.].(2)For purposes of preparation and publication of the electoral roll for the elections to
the office of member under this Section, the provisions of Sections 11 and 12 shall, mutatis mutandis
apply subject to such rules as may be made in this behalf.
180. Reservation of seats of members of [Zilla Praja Parishad] [Substituted
'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.].
(1)In every [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated
23.9.2006.], out of the total strength of elected members determined under Section 179, the
Commissioner shall, subject to such rules as may be prescribed, by notification, reserve, -(a)such
number of seats to the Scheduled Castes and Scheduled Tribes as may be determined by him,
subject to the condition that the number of seats so reserved shall bear, as nearly as may be, the
same proportion to the total number of seats to be filled by direct election to the [Zilla Praja
Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] as the population of
the Scheduled Castes or as the case may be Scheduled Tribes in the District bears to the total
population of the District and such seats may be allotted by rotation to different constituencies in a
District in the manner prescribed;[***] [Omitted by Section 9 (A) of Act No. 5 of 1995.](c)not less
than one-third of the total number of seats reserved under [clause (a) and sub-Section 1A] [Subs by
Section 9 (A) (ii) of Act No. 5 of 1995.] for women belonging to the Scheduled Castes, Scheduled
Tribes or as the case may be, the Backward Classes;(d)not less than one-third (including the number
of seats reserved for women belonging to the Scheduled Castes, Scheduled Tribes and backward
classes) of the total number of seats to be filled by direct election to the [Zilla Praja Parishad]Andhra Pradesh Panchayat Raj Act, 1994

[Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] for women and such seats may
be allotted by rotation to different constituencies in the district in the manner prescribed.(1A)[ In
addition to the reservation of seats under sub-Section (1), there shall be reserved for the Backward
Classes such number of seats as may be allocated to them in each [Zilla Praja Parishad] [Inserted by
Section 9 (B) of Act No. 5 of 1995.] in the manner prescribed; so however that the number of offices
of members of [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated
23.9.2006.] in the State reserved for Backward Classes shall not be less than thirty-four per cent of
the total number of offices of the members of [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by
Act No. 41 of 2006, dated 23.9.2006.] in the State. The number of seats allocated to each [Zilla Praja
Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] shall be allotted by
rotation to different territorial constituencies in the [Zilla Praja Parishad] [Substituted 'Zilla
Parishad' by Act No. 41 of 2006, dated 23.9.2006.].](2)Nothing in [sub-Sections (1) and (1 A)] [Subs
Section 9 (C) of Act No. 5 of 1995.] shall be deemed to prevent women and members of the
Scheduled Castes, Scheduled Tribes or Backward classes from standing for election to the
non-reserved seats in the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006,
dated 23.9.2006.].
181. Election of Chairperson and Vice-Chairperson.
(1)For every [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated
23.9.2006.] there shall be one Chairperson and one Vice-Chairperson who shall be [elected by and
from among the elected members specified in clause (i) of sub-Section (3) of Section 177 by show of
hands duly obeying the party whip given by such functionary of the recognised political party as may
be prescribed] [Subs by Section 10 (A) (i) of Act No. 5 of 1995.]. If at an election held for the purpose
no Chairperson or Vice-Chairperson is elected fresh election shall be held. The names of the
Chairperson and the Vice-Chairperson so elected shall be published in the prescribed
manner:Provided that if a Member of the Legislative Assembly of the State or of either House of
Parliament is elected to either of the said offices, he shall cease to hold such office unless within
fifteen days from the date of election to such office he ceases to be Member of the Legislative
Assembly of the State or of either House of Parliament by resignation or otherwise.[Provided further
that a member voting under this sub-Section in disobedience of the party whip [shall cease to hold
office in the manner prescribed] [Added by Section 10 (A) (ii) of Act No. 5 of 1995.] and the vacancy
caused by such cessation shall be filled as a casual vacancy.](2)[ Out of the total number of offices of
Chairperson in the State, the Commissioner shall, subject to such rules as may be prescribed, by
notification reserve,-(a)such number of offices to the members belonging to Scheduled Castes and
Scheduled Tribes as may be determined by him, subject to the condition that the number of offices
so reserved shall bear, as nearly as may be, the same proportion to the total number of offices to be
filled in the State as the population of the Scheduled Castes or as the case may be, the Scheduled
Tribes in the State bears to the total population of the State and such offices may be allotted by
rotation to different [Zilla Praja Parishad] in the State in the manner prescribed;(b)thirty-four per
cent of the total number of such offices of Chairperson in the State for Backward Classes; and such
offices may be allotted by rotation to different [Zilla Praja Parishad] [Substituted 'Zilla Parishads' by
Act No. 41 of 2006, dated 23.9.2006.] in the State in the manner prescribed;(c)not less than
one-third of the total number of offices reserved under clauses (a) and(b)for women belonging toAndhra Pradesh Panchayat Raj Act, 1994

the Scheduled Castes, Scheduled Tribes, or as the case may be, the Backward Classes; and(d)not less
than one-third (including the number of offices reserved for women belonging to Scheduled Castes,
Scheduled Tribes and the backward classes) of the total number of offices to be filled in the State for
women and such offices may be allotted by rotation to different [Zilla Praja Parishad] [Substituted
'Zilla Parishads' by Act No. 41 of 2006, dated 23.9.2006.] in the State in the manner
prescribed.](3)The offices reserved for Scheduled Castes, Scheduled Tribes, Backward Classes and
Women may be allotted by rotation to different [Zilla Praja Parishad] [Substituted 'Zilla Parishads'
by Act No. 41 of 2006, dated 23.9.2006.] in the different regions in the State in the manner
prescribed.(4)The first meeting of the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No.
41 of 2006, dated 23.9.2006.] to elect a Chairperson and Vice-Chairperson shall be called as soon as
may be, after the results of the ordinary elections to the office of elected members of the [Zilla Praja
Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] have been
published. The notice of the date and time of the meeting for the election of Chairperson and
Vice-Chairperson shall be given to the elected members in the prescribed manner:Provided that if,
for any reason, the election of the Chairperson or Vice-Chairperson is not held on the date fixed as
aforesaid, the meeting for the election of the Chairperson and Vice-Chairperson shall be held on the
next day, whether or not it is a holiday observed by the [Zilla Praja Parishad] [Substituted 'Zilla
Parishad' by Act No. 41 of 2006, dated 23.9.2006.].(5)Every Chairperson or Vice-Chairperson shall
cease to hold office on cessation as an elected member.(6)Save as otherwise expressly provided in,
or prescribed under this Act, the term of office of the Chairperson or Vice-Chairperson who is
elected at an ordinary election shall be five years from the date appointed by the Andhra Pradesh
Election Commissioner for Local Bodies for the first meeting of the [Zilla Praja Parishad]
[Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] after the ordinary
election.(7)Any casual vacancy in the office of the Chairperson or Vice-Chairperson shall be filled
within a period of six months from the date of occurrence of the vacancy by a fresh election under
sub-Section (4) and a person elected as Chairperson or Vice-Chairperson in any such vacancy shall
hold office only so long as the person in whose place he is elected would have been entitled to hold
office if the vacancy had not occurred.
181A. [ Resolution of disputes relating to cessation for disobedience of party
whip. [Inserted by Act No. 22 of 2006, dated 19.4.2006.]
- Where a member against whom a proceeding that he ceased to hold office as a consequence of the
disobedience of the party whip is issued in pursuance of the second proviso to sub-section (1) of
Section 181 and the affected member disputes the correctness of the proceedings, he may apply to
the District Court having jurisdiction over the area in which the office of the [Zilla Praja Parishad]
[Subs by Section 10 (B) of Act No. 5 of 1995.] is situated, for a decision.]
182. Term of office of a member of a [Zilla Praja Parishad] [Substituted 'Zilla
Parishad' by Act No. 41 of 2006, dated 23.9.2006.].
- Save as otherwise provided in this Act,-(i)an ex-officio member of the [Zilla Praja Parishad]
[Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] shall hold office so long as heAndhra Pradesh Panchayat Raj Act, 1994

continues to hold the office by virtue of which he became such ex-officio member;(ii)a member
elected at an ordinary election or a co-opted member shall hold office for a term of five years from
the date appointed by the Andhra Pradesh Election Commission for Local Bodies for the first
meeting of the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated
23.9.2006.] after the said ordinary election.
183. Qualification of candidates for election.
- No person shall be eligible for election as member of a [Zilla Praja Parishad] [Substituted 'Zilla
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] unless his name appears in the electoral rolls of
the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.]
concerned and he has completed the age of twenty-one years.
184. Disqualifications.
(1)A member of the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated
23.9.2006.] shall be disqualified for election as Chairperson or Vice-Chairperson if he is in arrears
of any dues, otherwise than in a fiduciary capacity to any [Mandal Praja Parishad] [Substituted
'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] in the District or the [Zilla Praja
Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or if he is interested
in a subsisting contract made with or any work being done for any [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] in the District or the [Zilla
Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.]:Provided that
a person shall not be deemed to have any interest in such contract or work by reason only of his
having a share or interest in -(i)a company as a mere shareholder but not as a director; or(ii)any
lease, sale or purchase of immovable property or any agreement for the same; or(iii)any agreement
for the loan of money or any security for the payment of money only;or(iv)any newspaper in which
any advertisement relating to the affairs of any of the aforesaid [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or [Zilla Praja Parishad]
[Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] is Inserted.(2)The provisions
of [Sections 18, 19. 19-A, 19-B, 20, 21 and 22] [Substituted 'Sections 18, 19, 20, 21 and 22' by Act No.
22 of 2006, dated 19.4.2006.] shall apply to a member of the [Zilla Praja Parishad] [Substituted
'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] as they apply to a member of the Gram
Panchayat subject to the variations that the expressions, "Gram Panchayat," "Executive Authority",
"Sarpanch", "Upa-Sarpanch", the expressions "[Zilla Praja Parishad] [Substituted 'Zilla Parishad' by
Act No. 41 of 2006, dated 23.9.2006.]", "Chief Executive Authority", "Chairperson",
"Vice-Chairperson" and "Chief Executive Authority" shall respectively be substituted:Provided that
nothing in clause (b) of Section 20 shall apply to a member of the [Zilla Praja Parishad] [Substituted
'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] specified in clauses (ii) to (iv) of
sub-Section (3) of Section 177.Andhra Pradesh Panchayat Raj Act, 1994

185. Resignation of Chairperson, Vice-Chairperson or member.
- The Chairperson, the Vice-Chairperson, an elected member or co-opted member may resign his
office in such manner as may be prescribed.
186. Appointment of Chief Executive Officer and his powers and functions.
(1)There shall be Chief Executive officer for every [Zilla Praja Parishad] [Substituted 'Zilla Parishad'
by Act No. 41 of 2006, dated 23.9.2006.] who shall be appointed by the Government.(2)Every Chief
Executive Officer shall be liable to be transferred by the Government.(3)Save as otherwise expressly
provided by or under this Act, the executive power for the purpose of carrying out the provisions of
this Act, shall vest in the Chief Executive Authority who shall -(a)exercise all the powers and
perform all the functions specially conferred or imposed upon him by or under this Act, or under
any other law for the time being in force; and(b)lay down the duties of all officers and servants of, or
holding office under [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated
23.9.2006.] in accordance with the rules made by the Government.(4)Subject to the provisions of
this Act, and the rules made thereunder, the Chief Executive Officer, -(a)shall be entitled to
-(i)attend the meeting of the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of
2006, dated 23.9.2006.] or any of its Standing Committees (including any meeting of the [Mandal
Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.]) and take
part in the discussions thereat but shall not be entitled to vote or to move any resolution;(ii)call for
any information, return, statement of account or report from any officer or servant of, or holding
office under the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated
23.9.2006.] or a [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006,
dated 23.9.2006.].(b)shall exercise supervision and control over the acts of the officers and servants
holding office under the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006,
dated 23.9.2006.] or the institutions thereunder in matters of executive administration and those
relating to accounts and records of the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No.
41 of 2006, dated 23.9.2006.] or the institutions thereunder;(c)shall have the custody of all papers
and documents connected with the proceedings of the [Zilla Praja Parishad] [Substituted 'Zilla
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] and of its Standing Committees;(d)shall be
responsible for implementing the resolutions of the [Zilla Praja Parishad] [Substituted 'Zilla
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] and of the standing Committees thereof;(e)shall
supervise and control the execution of all activities of the [Zilla Praja Parishad] [Substituted 'Zilla
Parishad' by Act No. 41 of 2006, dated 23.9.2006.];(f)shall take necessary measures for the speedy
execution of all works and development schemes of the [Zilla Praja Parishad] [Substituted 'Zilla
Parishad' by Act No. 41 of 2006, dated 23.9.2006.];(g)shall have the power to enter upon and
inspect any work, scheme or institution under the management of the [Zilla Praja Parishad]
[Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.];(h)shall have the power to
enter upon and inspect any work, scheme or institution under the management of a [Mandal Praja
Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] if the [Zilla Praja
Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or any of its
Standing Committees so direct;(i)shall be the competent authority to enter into agreements and to
sign and execute them in the name and on behalf of the [Zilla Praja Parishad] [Substituted 'ZillaAndhra Pradesh Panchayat Raj Act, 1994

Parishad' by Act No. 41 of 2006, dated 23.9.2006.] from time to time;(j)shall implement such
specific directions issued by the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of
2006, dated 23.9.2006.] as it may think fit regarding the performance by him of any of the functions
assigned to him under the act:Provided that such directions are in conformity with the terms and
conditions governing planning, community development and other development activities entrusted
by the Government or any other authority;(k)shall immediately execute the orders passed by the
Government in exercise of the powers conferred by the Act and rules made thereunder or any other
law for the time being in force and shall forthwith send a compliance report to the Government and
place a copy thereof before the Chairperson and Vice-Chairperson;(l)shall exercise such other
powers and perform such other functions as may be prescribed.(5)The Chief Executive Officer shall,
with the approval of, or on the direction of the Chairperson convene the meetings of the [Zilla Praja
Parishad] [Substituted 'Zilla Parishads' by Act No. 41 of 2006, dated 23.9.2006.] so that at least one
meeting of the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated
23.9.2006.] is held every month and if the Chief Executive Officer fails to discharge that duty, with
the result that no meeting of the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of
2006, dated 23.9.2006.] is held within a period of ninety days from the last meeting, he shall be
liable to disciplinary action under the relevant rules:Provided that where the Chairperson fails to
give his approval for convening the meeting so as to hold a meeting within the period of ninety days
aforesaid the Chief Executive Officer may himself convene the meeting in the manner
prescribed.(6)Subject to the provisions of Section 195 the staff borne on the establishment of the
[Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] and the
staff working in institutions and schemes transferred by the Government or the Head of Department
of Government to the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006,
dated 23.9.2006.] shall be under the administrative control and supervision of the Chief Executive
Officer.(7)The Government shall pay out of the Consolidated Fund of the State, the salaries,
allowances, leave allowances, pension and contributions, if any, towards the provident fund or
provident fund-cum-pension fund of the Chief Executive Officer appointed under sub-Section
(1).(8)The Government shall have power to make rules to regulate the classification and methods of
recruitment, conditions of service, pay and allowances and disciplinary conduct of the Chief
Executive Officer appointed under sub-Section (1).
187. Standing Committees of a [Zilla Praja Parishad] [Substituted 'Zilla
Parishad' by Act No. 41 of 2006, dated 23.9.2006.].
(1)For every [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated
23.9.2006.] there shall be constituted the following standing Committees, the subjects assigned to
each such standing committee being those specified against it, namely:-(i)Standing Committee for
Planning and Finance: District Plan, budget, taxation, finance and coordination of the work relating
to other committees.(ii)Standing Committee for Rural Development: Poverty Alleviation
Programme, Area Development Programmes, employment, housing, cooperation, thrift and small
savings, Industries including cottage, village and small scale industries, trusts and
statistics.(iii)Standing Committee for Agriculture: Agriculture, Animal Husbandry, soil reclamation
including contour bunding, social forestry, fisheries and sericulture.(iv)Standing Committee for
Education and Medical Services: Education including Social Education, medical services, publicAndhra Pradesh Panchayat Raj Act, 1994

health and sanitation including drainage, relief for distress in grave emergencies.(v)Standing
Committee for Women Welfare: Development of Women and welfare of children.(vi)Standing
Committee for Social Welfare: Social Welfare of Scheduled Caste, Scheduled Tribes and Backward
Classes and cultural affairs.(vii)Standing Committee for Works: Communications, rural water
supply, power and irrigations.(2)Every standing Committee shall consist of the Chairperson of the
[Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] who
shall be ex-officio member and such other members [as may be elected from among the members of
the [Zilla Praja Parishad] [Subs by Section 11 of Act No. 5 of 1995.]] in accordance with the rules
made in that behalf.(3)The Vice-Chairperson shall be ex-officio Member and Chairperson of the
Standing Committee for Agriculture, two offices of the Chairperson of the Standing Comittees shall
be filled by nomination by the Chairperson of the [Zilla Praja Parishad] [Substituted 'Zilla Parishad'
by Act No. 41 of 2006, dated 23.9.2006.] from among the women members of the [Zilla Praja
Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] in the manner
prescribed and the Chairperson of the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No.
41 of 2006, dated 23.9.2006.] shall be the Chairperson of the rest of the four offices of the
Chairperson of the Standing Committees.(4)The powers and functions of the Standing Committee,
the permanent invitees to it and other incidental and consequential matters shall be such as may be
prescribed.(5)The District Collector shall have right to participate in the meetings of all Standing
Committees without voting rights.(6)The decisions of the Standing Committees shall be subject to
ratification by the general body of the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No.
41 of 2006, dated 23.9.2006.] which shall have the power to approve, modify, rescind or reverse
them.
188. Permanent invitees to [Zilla Praja Parishad] [Substituted 'Zilla Parishad'
by Act No. 41 of 2006, dated 23.9.2006.].
(1)The following shall be the permanent invitees to the meetings of the [Zilla Praja Parishad]
[Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.]:(i)The Chairperson, District
Co-operative Marketing Society;(ii)The Chairperson, Zilla Grandhalaya Samstha;(iii)The
Chairperson, District Co-operative Central Bank;(iv)The District Collector;(v)All Presidents of
[Mandal Praja Parishads] [Substituted 'Mandal Parishads' by Act No. 41 of 2006, dated 23.9.2006.]
in the District.(2)The permanent invitees shall be entitled to participate in the meetings of the [Zilla
Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] without right
to vote.
189. Special invitees.
(1)The Chairperson or Vice-Chairperson of a [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by
Act No. 41 of 2006, dated 23.9.2006.] or the Chairperson of a Standing Committee thereof may, for
purposes of consultation, invite any person other than an office bearer of any political party having
experience and specialised knowledge of any subject under its consideration to attend its meeting.
Such persons shall have the right to speak in and otherwise to take part in the proceedings of such
meeting, but shall not, by virtue of this Section, be entitled to vote at any such meeting.(2)A person
attending a meeting under sub-Section (1) shall be entitled to such allowances as may be prescribed.Andhra Pradesh Panchayat Raj Act, 1994

190. Rules for conduct of business at meetings.
- Every [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.]
or a Standing Committee thereof shall in regard to the conduct of business at its meetings follow
such rules as may be prescribed.
191. Power of [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41
of 2006, dated 23.9.2006.] or its Standing Committee to call for documents
from Chief Executive Officer.
- A [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or a
Standing Committee thereof may, at any time require the Chief Executive Officer to furnish any
document in his custody and he shall comply with every such requisition.
192. Powers and functions of the [Zilla Praja Parishad] [Substituted 'Zilla
Parishad' by Act No. 41 of 2006, dated 23.9.2006.].
(1)Every [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.]
shall exercise such powers and perform such functions as may be entrusted to it by rules made in
this behalf with regard to the subjects enumerated in the First Schedule. The [Zilla Praja Parishad]
[Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] shall also have the power to
-(i)examine and approve the budgets of [Mandal Praja Parishads] [Substituted 'Mandal Parishads'
by Act No. 41 of 2006, dated 23.9.2006.] in the district;(ii)distribute the funds allotted to the district
by the Central or State Government among the [Mandal Praja Parishads] [Substituted 'Mandal
Parishads' by Act No. 41 of 2006, dated 23.9.2006.] and Mandals in the district for which [Mandal
Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] are not
constituted;(iii)co-ordinate and consolidate the plans prepared in respect of the Mandals in the
district and prepare plans in respect of the entire district;(iv)secure the execution of plans, projects,
schemes or other works either solely relating to the individual Mandals or common to two or more
Mandals in the district;(v)supervise generally the activities of the [Mandal Praja Parishads]
[Substituted 'Mandal Parishads' by Act No. 41 of 2006, dated 23.9.2006.] in the district;(vi)exercise
and perform such of the powers and functions of the District Board including the powers to levy any
tax or fees, as may be transferred to it under this Act;(vii)exercise and perform such other powers
and functions in relation to any development programme as the Government may by notification
confer on or entrust to it;(viii)advise Government on all matters relating to development activities
and maintenance of services in the district, whether undertaken by local authorities or
Government;(ix)advise Government on the allocation of work among Gram Panchayats and
[Mandal Praja Parishads] [Substituted 'Mandal Parishads' by Act No. 41 of 2006, dated 23.9.2006.]
and coordination of work between the said bodies and among the various Gram Panchayats
themselves;(x)advise Government on matters concerning the implementation of any statutory or
executive order specially referred by the Government to the [Zilla Praja Parishad] [Substituted 'Zilla
Parishad' by Act No. 41 of 2006, dated 23.9.2006.];(xi)collect such data as it deems
necessary;(xii)publish statistics or other information relating to the activities of the localAndhra Pradesh Panchayat Raj Act, 1994

authorities;(xiii)require any local authority to furnish information regarding its activities;(xiv)accept
trusts relating exclusively to the furtherance of any purpose for which its funds may be
applied;(xv)establish, maintain, or expand secondary, vocational and industrial schools;(xvi)borrow
money for carrying out the purposes of this Act with the previous approval of the Government and
subject to such terms and conditions as may be prescribed.(2)The [Zilla Praja Parishad]
[Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] may, with the approval of the
Government levy contributions from the funds of the [Mandal Praja Parishads] [Substituted
'Mandal Parishads' by Act No. 41 of 2006, dated 23.9.2006.] in the district.
193. Powers and functions of Chairperson and Vice-Chairperson of the [Zilla
Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated
23.9.2006.].
(1)The Chairperson of [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006,
dated 23.9.2006.] shall-(a)exercise administrative control over the Chief Executive Officer for the
purposes of implementation of the resolutions of the [Zilla Praja Parishad] [Substituted 'Zilla
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or any Standing Committee thereof;(b)preside
over and conduct the meetings of the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No.
41 of 2006, dated 23.9.2006.];(c)have full access to all records of the [Zilla Praja Parishad]
[Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.].(2)The Vice-Chairperson shall
exercise such powers and perform such functions of the Chairperson as the Chairperson may, from
time to time delegate to him in writing.(3)When the office of the Chairperson is vacant, the
Vice-Chairperson of the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006,
dated 23.9.2006.] shall exercise the powers and perform the functions of the Chairperson until a
new Chairperson is elected.(4)If the Chairperson has been continuously absent from the district for
more than fifteen days or is incapacitated for more than fifteen days his powers and functions
during such absence or incapacity shall devolve on the Vice-Chairperson.(5)When the office of the
Chairperson is vacant or the Chairperson has been continuously absent from the district for more
than fifteen days or is incapacitated for more than fifteen days and there is either a vacancy in the
office of the Vice-Chairperson or the Vice-Chairperson has been continuously absent from the
district for more than fifteen days or is incapacitated for more than fifteen days, the powers and
functions of the Chairperson shall devolve on a member of the [Zilla Praja Parishad] [Substituted
'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] appointed by the Government. The
member so appointed shall be styled as the temporary chairperson and he shall exercise the powers
and perform the functions of the Chairperson subject to such restrictions and conditions as may be
prescribed until a new Chairperson or Vice-Chairperson assumes office after his election, or until
the Chairperson or the Vice-Chairperson returns to the district or recovers from his incapacity, as
the case may be.(6)It shall be the duty of the Chairperson or the person for the time being exercising
the powers and performing the functions of the Chairperson to convene the meetings of the [Zilla
Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] so that at least
one meeting of the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated
23.9.2006.] is held in every ninety days. If the Chairperson or such person fails to discharge that
duty with the result that no meeting is held within the said period of ninety days or within thirty
days following such period he shall with effect from the date of expiration of thirty days aforesaidAndhra Pradesh Panchayat Raj Act, 1994

cease to be the Chairperson or as the case may be cease to exercise the powers and perform the
functions of the Chairperson, unless such cessation has otherwise occurred before that date, and for
a period of one year from that date he shall not be eligible to be elected as Chairperson or to exercise
the powers and perform the functions of the Chairperson:Provided that in reckoning any such
period of ninety days or the period of thirty days following such period as the case may be referred
to above any public holiday shall be excluded.(7)Where the District Collector is satisfied that the
Chairperson or the person for the time being exercising the powers and performing the functions of
the Chairperson has ex-facie ceased to be the Chairperson or as the case may be ceased to exercise
the powers and functions of the Chairperson under sub-Section (6) he shall forthwith intimate that
fact by registered post to the Chairperson or such person.
194. Rights of individual members to draw attention in respect of [Zilla Praja
Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.]
Works.
- Any member of a [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated
23.9.2006.] may draw the attention of the Chairperson or Chief Executive Officer of the [Zilla Praja
Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] to any neglect in the
execution of [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated
23.9.2006.] work to any waste of Parishad property or to the needs of any locality and may suggest
any improvement which may appear desirable.
195. Officers and other employees of the [Zilla Praja Parishad] [Substituted
'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.].
(1)The Government may, at any time create such posts of officers and other employees of a [Zilla
Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] as they may
consider necessary for carrying out the purposes of this Act.(2)All appointments to the posts created
under sub-Section (1) and transfer of the holders of such posts shall be made, subject to the
provisions of the Andhra Pradesh Public Employment (Regulation of Age of Superannuation) Act,
1984 (Act 23 of 1984), the Andhra Pradesh (Regulation of Appointments to Public Services and
Rationalisation of Staff Pattern and Pay Structure) Act, 1994, (Act 2 of 1994), and such rules as may
be made under the proviso to Article 309 of the Constitution.(3)The Government shall pay, out of
the Consolidated Fund of the State, the salaries, allowances, leave allowances, pension and
contributions, if any, towards the provident fund or of a pension cum-provident fund of the officers
and other employees of a [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006,
dated 23.9.2006.] who hold any of the posts referred to in sub-Section (1).(4)The classification and
methods of recruitment, conditions of service, pay and allowances and discipline and conduct of the
officers and the employees referred to in sub-Section (1), shall be regulated in accordance with the
provisions of the Andhra Pradesh Public Employment (Regulation of Age of Superannuation) Act,
1984 (Act 23 of 1984), the Andhra Pradesh (Regulation of Appointments to Public Services and
Rationalisation of Staff Pattern and Pay Structure) Act, 1994 (Act, 2 of 1994) and such rules as may
be made under the proviso to Article 309 of the Constitution. Until the rules in that behalf are soAndhra Pradesh Panchayat Raj Act, 1994

made, the law for the time being in force regulating the recruitment and conditions of service, pay
and allowances and discipline and conduct, applicable to such holder shall continue to apply to such
holder.(5)The Government, may from time to time, by order give such directions to any Parishad or
any officer, authority or person thereof, as may appear to them to be necessary for the purpose of
giving effect to the provisions of this Section; and the [Zilla Praja Parishad] [Substituted 'Zilla
Parishad' by Act No. 41 of 2006, dated 23.9.2006.], officer, authority or person shall comply with all
such directions.
196. Allowances for attending meeting of a [Zilla Praja Parishad] [Substituted
'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or a Standing
Committee.
(1)There shall be paid to the non-official members of a [Zilla Praja Parishad] [Substituted 'Zilla
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] and a Standing Committee thereof such
allowances as may be prescribed for attending a meeting of the [Zilla Praja Parishad] [Substituted
'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or such committee.(2)There shall be paid to
the Chairperson or Vice-Chairperson of the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act
No. 41 of 2006, dated 23.9.2006.] in respect of their/his tours on duty, whether within or outside
the district but not outside the State, such allowances as may be prescribed.
197. Funds of the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act
No. 41 of 2006, dated 23.9.2006.].
(1)All moneys received by the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of
2006, dated 23.9.2006.] shall constitute a fund called the [Zilla Praja Parishad] [Substituted 'Zilla
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] Fund and shall be applied for the purposes
specified in this Act and for such other purposes and in such manner as may be prescribed.(2)All
moneys received by the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006,
dated 23.9.2006.] shall be lodged in the nearest Government Treasury:[Provided that the amounts
received as funds under the Jawahar Rozgar Yojana, Employment Assurance Scheme or other Wage
Employment Schemes shall be lodged in nearby Nationalised Banks or Co-operative Banks or Post
Offices in such manner as may be prescribed.] [Added by Section 4 of Act No. 16 of 1998.](3)All
orders or cheques against the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of
2006, dated 23.9.2006.] Fund shall be signed by the Chief Executive Authority.
198. Income and expenses of a [Zilla Praja Parishad] [Substituted 'Zilla
Parishad' by Act No. 41 of 2006, dated 23.9.2006.].
(1)The sources of income of [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of
2006, dated 23.9.2006.] shall consist of-(i)the Central or State Government funds allotted to the
[Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated
23.9.2006.];(ii)grants from all India bodies and institutions for the development of cottage, village
and small scale industries and the like;(iii)[ such share of the State taxes or fees as may beAndhra Pradesh Panchayat Raj Act, 1994

prescribed;] [Substituted by Section 6(i) of Act. No. 37 of 2001.](iv)proceeds from taxes or fees
which the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated
23.9.2006.] may, under any law, levy;(v)income from endowments or trusts administered by the
[Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.];[***]
[Omitted by Section 6(ii) of Act. No. 37 of 2001.](vi)[] [Renumbered by Section 6(iii) of Act. No. 37
of 2001.] donations and contributions from the [Mandal Praja Parishads] [Substituted 'Mandal
Parishads' by Act No. 41 of 2006, dated 23.9.2006.], or from the public in any form;(vii)such
contributions as the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated
23.9.2006.] may levy from the [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No.
41 of 2006, dated 23.9.2006.] with the previous approval of the Government;(viii)any other income
from remunerative enterprises and the like.](2)The Government shall also make an annual grant at
the rate of two rupees per person residing in the District calculated on the basis of the last preceding
census of which figures are available.(3)The expenses of the [Zilla Praja Parishad] [Substituted 'Zilla
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] shall include the salaries and allowances of its
officers and other employees, the allowances to be paid under Section 189 and Section 196, any item
of expenditure directed by the Government for carrying out the purposes of this Act and such other
expenses as may be necessary for such purposes.
199. The Budget of the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by
Act No. 41 of 2006, dated 23.9.2006.].
(1)The Chief Executive Officer shall in each year, frame and place before the prescribed date, a
budget showing the probable receipts and expenditure during the following year, and the [Zilla Praja
Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] shall sanction the
budget, with such modifications, if any, as it thinks fit.(2)The budget so sanctioned shall be
submitted to the Government by the Chief Executive Officer through the Chairperson on or before
such date as may be fixed by the Government and if the Government are satisfied that adequate
provision has not been made therein or that it is otherwise unsatisfactory for giving effect to the
provisions of this Act, they shall have the power to approve the budget with such modifications as
they may consider necessary to secure such provision.(3)If, for any reason, the budget is not
sanctioned by the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated
23.9.2006.] under sub-Section (1) before the date referred to in sub-Section (2), the Chief Executive
Officer shall submit the budget to the Government who shall thereupon approve the budget as it
were submitted to them under sub-Section (2).(4)If, in the course of a year, the [Zilla Praja
Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] finds it necessary to
make any alterations in the budget with regard its receipts or items of expenditure a revised or
supplemental budget may be framed, submitted and sanctioned or approved as far as may be, in the
manner provided in sub-Sections (1), (2) and (3).
Part V – Constitution of Andhra Pradesh Election Commission
for Local Bodies Conduct of Election and Election OfficersAndhra Pradesh Panchayat Raj Act, 1994

Chapter I
Election Commission and Conduct of Elections
200. Constitution of Andhra Pradesh Election Commission for Local Bodies.
(1)There shall be constituted a [Andhra Pradesh Election Commission for Local Bodies] [Substituted
'State Election Commission' by Act No. 33 of 1998.] for Local Bodies for the superintendence,
direction and control of the preparation of electoral rolls for, and the conduct of elections to, all the
Panchayat Raj institutions governed by this Act.(2)The said Andhra Pradesh. Election Commission
for Local Bodies shall consist of a Andhra Pradesh. Election Commissioner for Local Bodies. The
Governor on the recommendation of the Government shall appoint a person who is holding or who
has held an office not less in rank than that of a Principal Secretary to Government as Andhra
Pradesh Election Commissioner for Local Bodies.(3)The conditions of service and tenure of office of
the Andhra Pradesh. Election Commissioner for Local Bodies shall be such as the Governor may, by
rule, determine:Provided that the Andhra Pradesh Election Commissioner for Local Bodies shall not
be removed from his office except in like manner and on the like grounds as a Judge of a High Court
and the conditions of service of the Andhra Pradesh Election Commissioner for Local Bodies shall
not be varied to his disadvantage after his appointment.
201. Powers and functions of the Andhra Pradesh Election Commissioner for
Local Bodies.
(1)All elections to the Panchayat Raj institutions shall be held under the supervision and control of
the Andhra Pradesh Election Commission for Local Bodies and for this purpose it shall have power
to give such directions as it may deem necessary to the Commissioner, District Collector or any
officer or servant of the Government and the Panchayat Raj institutions so as to ensure efficient
conduct of the elections under this Act.(2)The preparation of electoral rolls for the conduct of all
elections under the Act shall be done under the supervision and control of the Andhra Pradesh
Election Commission for Local Bodies.(3)For the purpose of this Section the Government shall
provide the Andhra Pradesh Election Commission with such staff as may be necessary.(4)On the
request of the Andhra Pradesh Election Commission for Local Bodies, the State Government shall
place at the disposal of the Commission such staff of the State Government, Gram Panchayats,
[Mandal Praja Parishads] [Substituted 'Mandal Parishads' by Act No. 41 of 2006, dated 23.9.2006.]
and [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] for
the purpose of conduct of elections under this Act.(5)The Andhra Pradesh Election Commissioner
for Local Bodies may, subject to control and revision delegate his powers to such officers as he may
deem necessary.
201A. [ Voting machines at elections. [Inserted by Section 5 of Act No. 26 of
2000.]
- Notwithstanding anything contained in this Act or the rules made thereunder, the giving andAndhra Pradesh Panchayat Raj Act, 1994

recording of votes by voting machines in such manner as may be prescribed, may be adopted in such
Ward or Wards or Constituency or Constituencies as the Andhra Pradesh Election Commission for
Local Bodies may, having regard to the circumstances of each case, specify.Explanation. - For the
purpose of this Section, "Voting Machines" means any machine or apparatus whether operated
electronically or otherwise used for giving or recording of votes and any reference to a ballot box or
ballot paper in this Act or the rules made threunder shall, save as otherwise provided, be construed
as including a reference to such voting machine wherever such voting machine is used at any
election.]
202. [ Symbols for elections under the Act. [Substituted by Act No. 22 of
2006, dated 19.4.2006.]
- The State Election Commission shall by notification, specify the symbols that may be chosen by
candidates contesting any election under this Act and the restrictions to which their choice shall be
subject:Provided that the State Election Commission shall not in the case of elections to gram
panchayats allot to any contesting candidate any symbol reserved for a recognised political party or
a registered political party but in the case of elections to [Mandal Praja Parishads] and [Zilla Praja
Parishad] [Substituted 'Zilla Parishads' by Act No. 41 of 2006, dated 23.9.2006.], the State Election
Commission shall allot symbols including the symbols reserved for a recognised political party, or,
as the case may be symbols if any, reserved for a registered political party where any candidate is set
up by such political party.]
202A. [ Reservations to Backward Classes. [Added by Section 13 of Act No. 5
of 1995.]
- For the purpose of reserving the offices of Sarpanch, President and Chairman and members of the
Gram Panchayats, [Mandal Praja Parishads] and [Zilla Praja Parishad] [Substituted 'Zilla Parishads'
by Act No. 41 of 2006, dated 23.9.2006.] to the members belonging to the backward classes under
this Act, the population figures of the backward classes, gathered in the Socio-Economic Survey
conducted by the Andhra Pradesh Backward Classes Co-operative Finance Corporation Limited,
Hyderabad, shall be taken as the basis.]
202B. [ Voter identity Cards. [Inserted by Act No. 22 of 2006, dated 19.4.2006.]
- With a view to preventing personation of electors, provision may be made by rules made under this
Act, for the production before the Presiding Officer of a polling station by every such elector, of his
identity card before the delivery of a ballot paper or ballot papers to him, if under the rules made in
that behalf under the Registration of Electors Rules, 1960 made under the Representation of the
People Act, 1950, electors of the Legislative Assembly Constituency or Constituencies in which the
Gram Panchayat, [Mandal Praja Parishad] Territorial Constituency or [Zilla Praja Parishad]
[Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] Territorial Constituency, as
the case may be, is situated, have been supplied with identity cards with or without their respective
photographs attached thereto.]Andhra Pradesh Panchayat Raj Act, 1994

203. Reservation of offices [to cease on the expiration of the period specified
in Article 334.] [Subs by Section 2(ii) of Act No. 7 of 2000.]
- The provisions of this Act relating to reservation of offices of Sarpanch, President and Chairman
and members of the Gram Panchayats, [Mandal Praja Parishads] [Substituted 'Mandal Parishads' by
Act No. 41 of 2006, dated 23.9.2006.] and [Zilla Praja Parishad] [Substituted 'Zilla Parishads' by Act
No. 41 of 2006, dated 23.9.2006.] for the Scheduled Castes and Scheduled Tribes [shall cease to
have effect on the expiration of the period specified in article 334 of the Constitution of India.] [Subs
by Section 2(i) of Act No. 7 of 2000.]
204. Injunctions not to be granted in election proceedings.
- Notwithstanding anything in the Code of Civil Procedure, 1908, or in any other law for the time
being in force, no court shall grant any permanent or temporary injunction or make any interim
order restraining any proceeding which is being or about to be taken under this Act for the
preparation or publication of any electoral roll or for the conduct of any election.
205. Requisitioning of premises for election purposes.
(1)If it appears to the Andhra Pradesh Election Commissioner for Local Bodies that in connection
with any election held under this Act, -(a)any premises are needed for or likely to be needed for the
purpose of being used as a polling station or for the storage of ballot boxes after a poll has been
taken, or(b)any vehicle is needed or is likely to be needed for the purpose of transport of personnel
or ballot boxes to or from any polling station, or transport of members of the police force for
maintaining order during the conduct of such election, or transport of any officer or other person for
performance of any duties in connection with such election, the Andhra Pradesh Election
Commissioner for Local Bodies may, by order in writing, requisition such premises or such vehicle,
as the case may be, and may make such further orders as may appear to him to be necessary or
expedient, in connection with the requisitioning:Provided that no vehicle which is being lawfully
used by a candidate or his agent for any purpose, connected with election of such candidate shall be
requisitioned under this sub-Section until the completion of the poll at such election.(2)The
requisition shall be effected by an order in writing addressed to the person deemed by the Andhra
Pradesh Election Commissioner for Local Bodies to be the owner or person in possession of the
property and such order shall be served in the prescribed manner on the person to whom it is
addressed.(3)Whenever any premises is requisitioned under sub-Section (1), the period of such
requisition shall not extend beyond the period for which such property is required for any of the
purposes mentioned in that sub-Section.Explanation. - For purposes of this Section 'premises'
means any land, building or part of a building and includes a hut, shed or other structure or any part
thereof and 'vehicle' means any vehicle used or capable of being used for the purpose of road
transport, whether propelled by mechanical power or otherwise.Andhra Pradesh Panchayat Raj Act, 1994

206. Payment of compensation.
(1)Whenever in pursuance of Section 205, the Andhra Pradesh Election Commissioner for Local
Bodies requisitions any premises, there shall be paid to the person interested compensation the
amount of which shall be determined by taking into consideration the following namely:-(i)the rent
payable in respect of the premises or if no rent is so payable, the rent payable for similar premises in
the locality;(ii)if in consequence of the requisition of the premises the person interested is
compelled to change his residence or place of business, the reasonable expenses, if any, incidental to
such change:Provided that where any person interested being aggrieved by the amount of
compensation so determined makes an application within the prescribed time to the Andhra
Pradesh Election Commissioner for Local Bodies for referring the matter to an arbitrator, the
amount of compensation to be paid shall be such as the arbitrator appointed in this behalf by the
Andhra Pradesh Election Commissioner for LocaL Bodies may determine:Provided further that
where there is any dispute as to the title to receive the compensation or as to the apportionment of
the amount of compensation, it shall be referred by the A.P. Election Commissioner for Local Bodies
to an arbitrator appointed in this behalf by the said Commissioner for determination, and shall be
determined in accordance with the decision of such arbitrator.Explanation. - In this sub-Section, the
expression "person interested" means the person who was in actual possession of the premises
requisitioned under Section 205 immediately before the requisition or where no person was in such
actual possession, the owner of such premises.(2)Whenever in pursuance of Section 205, the A.P.
Election Commissioner for Local Bodies requisitions any vehicle, there shall be paid to the owner
thereof compensation the amount of which shall be determined by the A.P. Election Commissioner
for Local Bodies on the basis of the fares or rates prevailing in the locality for the hire of such
vehicle:Provided that where the owner of such vehicle, being aggrieved by the amount of
compensation so determined, makes an application within the prescribed time to the A.P. Election
Commissioner for Local Bodies for referring the matter to an arbitrator, the amount of
compensation to be paid shall be such as the arbitrator appointed in this behalf by the A.P. Election
Commissioner for Local Bodies may determine:Provided further that where immediately before the
requisitioning, the vehicle was by virtue of a hire purchase agreement, in the possession of a person,
other than the owner, the amount determined under this sub-Section as the total compensation
payable in respect of the requisition shall be apportioned between that person and the owner in such
manner as they may agree upon, and in default of agreement, in such manner as the arbitrator
appointed by the A.P. Election Commissioner for Local Bodies in this behalf may decide.
207. Power to obtain information.
- The A.P. Election Commissioner for Local Bodies may with a view to requisitioning any property
under Section 205 or determining the compensation payable under Section 206 by order, require
any person to furnish to such authority as may be specified in the order, such information in his
possession relating to such property as may be specified.Andhra Pradesh Panchayat Raj Act, 1994

208. Eviction from requisitioned premises.
(1)Any person remaining in possession of any requisitioned premises in contravention of any order
made under Section 205 may summarily be evicted from the premises by an officer empowered by
the A.P. Election Commissioner for Local Bodies in this behalf.(2)Any officer so empowered may,
after giving to any woman not appearing in public, reasonable warning and facility to withdraw,
remove or open any lock or bolt or break open any door of any building or do any other act
necessary for effecting such eviction.
209. Penalty for contravention of any order regarding requisitioning.
- If any person contravenes any order made under Section 205 or Section 207 he shall be punishable
with imprisonment for a term which may extend to one year or with fine or with both.
210. Electoral officers and staff etc., deemed to be on deputation.
(1)Any officer or staff employed in connection with the preparation, revision and correction of the
electoral rolls for, and the conduct of all elections shall be deemed to be on deputation to the A.P.
Election Commission for Local Bodies for the period during which they are employed and such
officers and staff shall during that period, be subject to the control, superintendence and discipline
of the A.P. Election Commission for Local Bodies.(2)The Returning Officer, Assistant Returning
Officer, Presiding Officer, Polling Officer and any other officer appointed under this Act, and any
police officer designated for the time being by the State Government for the conduct of any elections
shall be deemed to be on deputation to the A.P. Election Commission for Local Bodies for the period
commencing on and from the date of notification calling for such elections and ending with the date
of declaration of the results of such elections and such officer shall, during that period, be subject to
the control, superintendence and discipline of the A.P. Election Commission for Local Bodies.
Chapter II
Election Offences
211. Corrupt practices.
- The following shall be deemed to be corrupt practices for the purposes of this Act:-(1)Bribery, that
is to say,-(A)any gift, offer or promise by a candidate or his agent or by any other person with the
consent of a candidate or his election agent, of any gratification, to any person whomsoever, with the
object, directly or indirectly, of inducing -(a)a person to stand or not to stand as or to withdraw or
not to withdraw from being a candidate at an election, or(b)an elector to vote or refrain from voting
at an election, or as a reward to-(i)a person for having so stood or not stood, or for having
withdrawn or not having withdrawn his candidature, or(ii)an elector for having voted or refrained
from voting;(B)the receipt of, or agreement to receive, any gratification, whether as a motive or a
reward-(a)by a person for standing or not standing as or for withdrawing or not withdrawing fromAndhra Pradesh Panchayat Raj Act, 1994

being a candidate, or(b)by any person whomsoever for himself or any other person for voting or
refraining from voting or inducing or attempting to induce any elector to vote or refrain from voting,
or any candidate to withdraw or not to withdraw his candidature.Explanation. - For the purpose of
this clause the term "gratification" is not restricted to pecuniary gratification or gratifications
estimable in money and it includes all forms of entertainment and all forms of employment for
reward but it does not include the payment of any expenses bonafide incurred at, or for the purpose
of any election and duly entered in the account of election expenses.(2)Undue influence, that is to
say, any direct or indirect interference or attempt to interfere on the part of the candidate or his
agent, or of any other person with the consent of the candidate or his election agent with the free
exercise of any electoral right:Provided that-(a)without prejudice to the generality of the provisions
of this clause any such person as is referred to thereon, who-(i)threatens any candidate or any
elector or any person in whom a candidate or an elector is interested, with injury of any kind
including social ostracism and ex-communication or expulsion from any caste or community;
or(ii)induces or attempts to induce a candidate or an elector to believe that he, or any person in
whom he is interested will become or will be rendered an object of divine displeasure or spiritual
censure, shall be deemed to interfere with the free exercise of the electoral right of such candidate or
elector within the meaning of this clause;(b)a declaration of public policy, or a promise of public
action, or the mere exercise of a legal right without intent to interfere with an electoral right, shall
not be deemed to be interference within the meaning of this clause.(3)The appeal by a candidate or
his agent or by any other person with the consent of a candidate or his election agent to vote or
refrain from voting for any person on the ground of his religion, race, caste, community or language
or the use of, or appeal to religious symbols or the use of, or appeal to national symbols such as the
national flag or the national emblem, for the furtherance of the prospects of the election of that
candidate or for prejudicially affecting the election of any candidate:Provided that no symbol
allotted under this Act to a candidate shall be deemed to be a religious symbol or a national symbol
for the purposes of this clause.(4)The promotion of, or attempt to promote, feelings of enemity or
hatred between different classes of the citizens of India on grounds of religion, race, caste,
community, or language by a candidate, or his agent or any other person with the consent of a
candidate or his election agent for the furtherance of the prospects of the election of that candidate
or of pre-judicially affecting the election of any candidate.[(4-A) The propagation of the practice or
the commission of sati or its glorification by a candidate or his agent or any other person with the
consent of the candidate or his election agent for the furtherance of the prospects of the election of
that candidate of for pre-judicially affecting the election of any candidate.Explanation. - For the
purpose of this clause, "sati" and "glorification" in relation of sati shall have the meanings
respectively assigned to them in the Commission of Sati (Prevention) Act, 1987.] [Inserted by Act
No. 22 of 2006, dated 19.4.2006.](5)The publication by a candidate or his agent or by any other
person, with the consent of a candidate or his election agent or any statement of fact which is false,
and which he either believes to be false, or does not believe to be true in relation to the personal
character or conduct of any candidate or in relation to the candidature, or withdrawal of any
candidate, being a statement reasonably calculated to prejudice the prospects of that candidate's
election.(6)The hiring or procuring whether, on payment or otherwise of any vehicle or vessel by a
candidate or his agent or by any other person with the consent of a candidate or his election agent,
or the use of such vehicle or vessel for the free conveyance of any elector other than that the
candidate himself, the members of his family or his agent to or from any polling station:ProvidedAndhra Pradesh Panchayat Raj Act, 1994

that the hiring of a vehicle or vessel by an elector or by several electors at their joint costs for the
purpose of conveying him or them to and from any such polling station or place fixed for the poll
shall not be deemed to be a corrupt practice under this clause if the vehicle or vessel so hired is a
vehicle or vessel not propelled by mechanical power:Provided further that the use of any public
transport vehicle or vessel by any elector at his own cost for the purpose of going to or coming from
any such polling station or place fixed for the poll shall not be deemed to be a corrupt practice under
this clause.Explanation. - In this clause, the expression "vehicle" means any vehicle used or capable
of being used for the purpose of road transport, whether propelled by mechanical power or
otherwise and whether used for drawing other vehicles or otherwise.(6A)[ The incurring or
authorising of expenses in contravention of Section 230A.] [Added by Section 6 of Act No. 26 of
2000.](7)The obtaining or procuring or abetting or attempting to obtain or procure by a candidate
or his agent, or by any other person with the consent of a candidate or his election agent, any
assistance (other than the giving of vote) for the furtherance of the prospects of that candidate's
election, from any person in the service of the State, Central Government, local authority or a
corporation owned or controlled by the State or Central Government:Provided that where any
person, in the service of the State or Central Government or a local authority in the discharge or
purported to discharge of his official duty, makes any arrangements or provides any facilities or does
any other act or thing, for to or in relation to, any candidate or his agent or any other person acting
with the consent of the candidate or his election agent (whether by reason of the office held by the
candidate or for any other reason), such arrangements, facilities or act or thing shall not be deemed
to be assistance for the furtherance of the prospects of that candidate's election.(8)[ Booth capturing
by a candidate or his agent or other person.] [Inserted by Act No. 22 of 2006, dated
19.4.2006.]Explanation. - (1) In this Section, the expression "agent" includes an election agent, a
polling agent, and any person who is held to have acted as an agent in connection with election with
the consent of the candidate.(2)For the purpose of clause (7), a person shall be deemed to assist in
the furtherance of the prospects of a candidate's election if he acts as an election agent of that
candidate.(3)For the purpose of clause (7) notwithstanding anything contained in any other law, the
publication in the Andhra Pradesh Gazette of the appointment, resignation, termination of service,
dismissal or removal from service of a person in the service of the Government shall be conclusive
proof -(i)of such appointment, resignation, termination of service, dismissal or removal from
service, as the case may be; and(ii)where the date of taking effect of such appointment, resignation,
termination of service, dismissal or removal from service, as the case may be, is stated in such
publication, also of the fact that such person was appointed with effect from the said date, or in the
case of resignation, termination of service, dismissal or removal from service, such person ceased to
be in such service with effect from the said date.(4)[ For the purposes of sub-section (8), booth
capturing shall have the same meaning as in Section 224.] [Added by Act No. 22 of 2006, dated
19.4.2006.]
212. [ Penalty for illegal hiring or procuring of conveyance at elections.
[Substituted by Act No. 22 of 2006, dated 19.4.2006.]
- If any person is guilty of any such corrupt practice as is specified in subsection (7) of Section 211 at
or in connection with an election, he shall be punishable with imprisonment which may extend to
three months and with fine.]Andhra Pradesh Panchayat Raj Act, 1994

213. Promoting enemity between classes in connection with election.
- Any person who in connection with an election under this Act, promotes or attempts to promote on
grounds of religion, race, caste, community or language, feelings of enemity or hatred, between
different classes of the citizens of India shall be punishable with imprisonment for a term which may
extend to three years and with fine which may extend to three thousand rupees.
214. [ Prohibition of public meetings before the date of poll. [Substituted by
Act No. 22 of 2006, dated 19.4.2006.]
(1)No person shall,-(a)convene, hold, attend, join or address any public meeting or procession in
connection with an election:or(b)display to the public any election matter by means of
cinematography, television or other similar apparatus; or(c)propagate any election matter to the
public by holding, or by arranging the holding of, any musical concert or any theatrical performance
or any other entertainment or amusement with a view to attracting the members of the public
thereto, in any polling area during the period of forty-eight hours prior to the hour fixed for the
conclusion of the poll in the case of [Mandal Praja Parishads] and [Zilla Praja Parishad] [Substituted
'Zilla Parishads' by Act No. 41 of 2006, dated 23.9.2006.] and forty four hours prior to the hour
fixed for the conclusion of the poll in the case of Gram Panchayats.(2)Any person who contravenes
the provisions of sub-section (1) shall be punishable with imprisonment for a term which may
extend to two years, or with fine or with both.(3)In this section, the expression "election matter"
means any matter intended or calculated to influence or affect the result of election.]
215. Disturbance at election meetings.
(1)Any person who at a public meeting to which this Section applies acts or incites others to act in a
disorderly manner for the purpose of preventing the transaction of the business for which the
meeting was called together, shall be punishable [with imprisonment which may extend to six
months or with fine which may extend to two thousand rupees] [Substituted 'with fine which may
extend to two hundred and fifty rupees' by Act No. 22 of 2006, dated 19.4.2006.].[(1-A) An offence
punishable under subsection (1) shall be cognizable.] [Inserted by Act No. 22 of 2006, dated
19.4.2006.](2)This Section applies to any public meeting of a political character held in any
constituency between the date of the issue of notification under this Act calling upon the
constituency to elect a member or members or office bearers of a local authority and the date on
which such election is held.(3)If any police officer reasonably suspects any person of committing an
offence under sub-Section (1) he may, if requested to do by the Chairman of the meeting require that
person to declare to him immediately his name and address and, if that person refuses or fails so to
declare his name and address or if the police officer reasonably suspects him of giving a false name
or address, the police officer may arrest him without warrant.Andhra Pradesh Panchayat Raj Act, 1994

216. Restrictions on the printing of pamphlets, posters etc.
(1)No person shall print or publish or cause to be printed or published, any election pamphlet or
poster which does not bear on its face the names and addresses of the printer and the publisher
thereof.(2)No person shall print or cause to be printed any election pamphlet or poster,-(a)unless a
declaration as to the identity of the publisher thereof, signed by him and attested by two persons to
whom he is personally known, is delivered by him to the printer in duplicate; and(b)unless, within a
reasonable time after the printing of the document, one copy of the declaration is sent by the
printer, together with one copy of the document,-(i)where it is printed in the capital of the State, to
the A.P. Election Commissioner for local bodies, and(ii)in any other case, to the District Magistrate
of the district in which it is printed.(3)For the purpose of this Section,-(a)any process for
multiplying copies of a document other than copying it by hand, shall be deemed to be printing and
the expression 'printer' shall be construed accordingly; and(b)"election pamphlet or poster" means
any printed pamphlet, hand-bill or other document distributed for the purpose or promoting or
prejudicing the election of a candidate or group of candidates or any play card or poster having
reference to an election, but does not include any hand-bill, play card or poster merely announcing
the date, time, place and other particulars of an election meeting or routine instructions to election
agents or workers.(4)Any person who contravenes any of the provisions of sub-Section (1) or
sub-Section (2) shall be punishable with imprisonment for a term which may extend to six months,
or with fine which may extend to two thousand rupees or with both.
217. Maintenance of secrecy of voting.
(1)Every Officer, clerk, agent or other person who performs any duty in connection with the
recording or counting of votes at an election shall maintain, and aid in maintaining, the secrecy of
the voting and shall not (except for some purpose authorised by or under any law) communicate to
any person any information calculated to violate such secrecy.(2)Any person who contravenes
provisions of sub-Section (1) shall be punishable with imprisonment for a term which may extend to
three months or with fine or with both.
218. Officers etc, at elections not to act for candidates or to influence voting.
(1)No person who is a District Election Officer or a Returning Officer, or an assistant returning
officer, or a presiding officer or polling officer at an election, or an officer or clerk appointed by the
returning officer or the presiding officer to perform any duty in connection with an election shall in
the conduct or the management of the election do any act other than the giving of vote for the
furtherance of the prospects of the election of a candidate.(2)No such person as aforesaid, and no
member of a police force, shall endeavour,-(a)to persuade any person to give his vote at an election,
or(b)to dissuade any person from giving his vote at an election, or(c)to influence the voting of any
person at an election in any manner.(3)Any person who contravenes the provisions of sub-Section
(1) or sub-Section (2) shall be punishable with imprisonment which may extend to six months or
with fine or with both.Andhra Pradesh Panchayat Raj Act, 1994

219. Prohibition of canvassing in or near polling stations.
(1)No person shall, on the date or dates on which a poll is taken at any polling station, commit any of
the following acts within the polling station or in any public or private place within a distance of one
hundred metres of the polling station, namely:-(a)canvassing for votes; or(b)soliciting the vote of
any elector; or(c)persuading any elector not to vote for any particular candidate; or(d)persuading
any elector not to vote at the election; or(e)exhibiting any notice or signs (other than an official
notice) relating to the election.(2)Any person who contravenes the provisions of sub-Section (1)
shall be punished with fine which may extend to two hundred and fifty rupees.
220. Penalty for disorderly conduct in or near polling stations.
(1)No person shall, on the date or dates on which a poll is taken at any polling station, -(a)use or
operate within or at the entrance of the polling station, or in any public or private place in the
neighbourhood thereof, any apparatus for amplifying or reproducing the human voice, such as a
megaphone or a loudspeaker, or(b)shout, or otherwise act in a disorderly manner within or at the
entrance of the polling station or in any public or private place in the neighbourhood thereof, so as
to cause annoyance to any person visiting the polling station for the poll, or so as to interfere with
the work of the officers and other persons on duty at the polling station.(2)Any person who
contravenes, or willfully aids or abets the contravention of the provisions of sub-Section (1) shall be
punishable with imprisonment which may extend to three months or with fine or with both.(3)If the
presiding officer of a polling station has reason to believe that any person is committing or has
committed an offence punishable under this Section, he may direct any police officer to arrest such
person, and thereupon the police officer shall arrest him.(4)Any police officer may take such steps,
and use such force as may be reasonably necessary for preventing any contravention of the
provisions of sub-Section (1), and may seize any apparatus used for such contravention.
221. Penalty for misconduct at the polling station.
(1)Any person who during the hours fixed for the poll at any polling station misconducts himself or
fails to obey the lawful directions of the presiding officer may be removed from the polling station by
the presiding officer or by any police officer on duty or by any person authorised in this behalf by
such presiding officer.(2)The powers conferred by sub-Section (1) shall not be exercised so as to
prevent any elector who is otherwise entitled to vote at a polling station from having opportunity of
voting at that station.(3)If any person who has been so removed from polling station re-enters the
polling station without the permission of the presiding officer he shall be punishable with
imprisonment for a term which may extend to three months, or with fine, or with both.
221A. [ Penalty for failure to observe procedure for voting. [Inserted by Act
No. 22 of 2006, dated 19.4.2006.]
- If an elector to whom a ballot paper has been issued, refuses to observe the procedure prescribed
for voting, the ballot paper issued to him shall be liable for cancellation.]Andhra Pradesh Panchayat Raj Act, 1994

221B. [ Prohibition of going armed to or near a polling station. [Inserted by
Act No. 22 of 2006, dated 19.4.2006.]
(1)No person other than a Police Officer and any other person appointed to maintain peace and
order, at a polling station who is on duty at the polling station, shall, on a polling day, go armed with
arms, as defined in the Arms Act, 1959, of any kind within the neighbourhood of a polling
station.(2)If any person contravenes the provisions of sub-section (1), he shall be punishable with
imprisonment for a term which may extend to two years, or with fine, or with both.(3)An offence
punishable under subsection (2) shall be cognizable.]
222. Breaches of official duty in connection with elections.
(1)If any person to whom this Section applies is without reasonable cause guilty of any act or
omission in breach of his official duty, he shall be punishable with fine which may extend to five
hundred rupees.(2)No suit or other legal proceedings shall lie against any such person for damages
in respect of any such act or omission as aforesaid.(3)The persons to whom this Section applies are
the District Election Officers, returning officers, assistant returning officers, presiding officers,
polling officers and any other person appointed to perform any duty in connection with the receipt
of nominations or withdrawal of candidatures, or the recording or counting of votes at an election
and the expression "official duty" shall for the purposes of this Section be construed accordingly but
shall not include duties imposed otherwise than by or under this Act.
223. Penalty for Government servants etc., for acting as election agent,
polling agent, or counting agent.
- If any person in the service of the State or Central Government or a local authority or a
Corporation owned or controlled by the State or Central Government acts as an election agent or a
polling agent or counting agent of a candidate at an election he shall be punishable with
imprisonment for a term which may extend to three months, or with fine or with both.
224. [ Offence of both capturing. [Substituted by Act No. 22 of 2006, dated
19.4.2006.]
(1)Whoever commits an offence of booth capturing shall be punishable with imprisonment for a
term which shall not be less than one year but which may extend to three years and with fine, and
where such offence is committed by a person in the service of the Government, he shall be
punishable with imprisonment for a term which shall not be less than three years but which may
extend to five years and with fine.Explanation. - For the purposes of this sub-section and Section
232-A "booth capturing" includes, among other things, all or any of the following activities,
namely:(a)seizure of a polling station or a place fixed for the polHoy any person or persons making
polling authorities surrender the ballot papers or voting machines and doing of any other act which
affects the orderly conduct of elections;(b)taking possession of polling station or a place fixed for the
poll by any person or persons and allowing only his or their own supporters to exercise their right toAndhra Pradesh Panchayat Raj Act, 1994

vote and prevent others from free exercise of their right to vote:(c)coercing or intimidating or
threatening directly or indirectly threatening any elector and preventing him from going to the
polling station or a place fixed for the poll to cast his vote;(d)seizure of a place for counting of votes
by any person or persons, making the counting authorities surrender the ballot papers or voting
machines and the doing of anything which affects the orderly counting of votes;(e)doing by any
person in the service of Government, of all or any of the aforesaid activities or aiding or conniving
at, any such activity in the furtherance of the prospects of the election of a candidate.(2)An offence
punishable under subsection (1) shall be cognizable.]
225. Removal of ballot papers or ballot boxes from polling stations to be an
offence.
(1)Any person who at any election fraudulently takes or attempts to take a ballot paper or ballot box
out of polling station, or willfully aids or abets the doing of any such act shall be punishable with
imprisonment for a term which may extend to five years and with fine which may extend upto five
thousand rupees.(2)If the presiding officer of a polling station has reason to believe that any person
is committing or has committed an offence punishable under sub-Section (1), such officer may,
before such person leaves the polling station arrest or direct a police officer to arrest such person
and may cause him to be searched by a police officer:Provided that when it is necessary to cause a
woman to be searched the search shall be made by another woman with strict regard to
decency.(3)Any ballot paper found upon the person arrested on search shall be made over for safe
custody to a police officer by the presiding officer or when the search is made by a police officer,
shall be kept by such officer in safe custody.[225-A. "Liquor not to be sold given or distributed on
polling day. [Inserted by Act No. 22 of 2006, dated 19.4.2006.](1)No spirituous, fermented or
intoxicating liquors or other substances of a like nature shall be sold, given or distributed at a hotel,
eating house, tavern, shop or any other place, public or private, within a polling area during the
period of forty-eight hours prior to the hour fixed for the conclusion of the poll in the case of
[Mandal Praja Parishads] and [Zilla Praja Parishad] [Substituted 'Zilla Parishads' by Act No. 41 of
2006, dated 23.9.2006.] and forty four hours prior to the conclusion of poll in the case of Gram
Panchayats and also on the counting day.(2)Any person who contravenes the provisions of
sub-section (1), shall be punishable with imprisonment for a term which may extend to six months,
or with fine which may extend to two thousand rupees, or with both.(3)Where a person is convicted
of an offence under this section, the spirituous, fermented or intoxicating liquors or other
substances of a like nature found in his possession shall be liable to confiscation and the same shall
be disposed of in such manner as may be prescribed.]
225B. [ Adjournment of poll in emergencies. [Inserted by Act No. 22 of 2006,
dated 19.4.2006.]
(1)If at an election the proceedings at any polling station are interrupted or obstructed by any riot or
open violence, or if at an election it is not possible to take the poll at any polling station or such place
on account of any natural calamity, or any other sufficient cause, the Presiding Officer for such
polling station shall announce an adjournment of the poll to a date to be notified later, and he shallAndhra Pradesh Panchayat Raj Act, 1994

forthwith inform the Returning Officer concerned.(2)Wherever a poll is adjourned under
sub-section (1), the Returning Officer shall immediately report the circumstances to the District
Election Authority and the State Election Commission, and shall, as soon as may be, with the
previous approval of the State Election Commission, appoint the day on which the poll shall
recommence, and fix the hours during which, the poll will be taken, and shall not count the votes
cast at such election until such adjourned poll shall have been completed.(3)In every such case as
aforesaid, the Returning Officer shall notify in such manner as the State Election Commission may
direct, the date and hours of polling fixed under subsection (2).]
225C. [ Fresh poll in the case of destruction etc., of ballot boxes. [Inserted by
Act No. 22 of 2006, dated 19.4.2006.]
(1)If at any election, -(a)any ballot box used at a polling station is unlawfully taken out of the
custody of the Presiding Officer or the Returning Officer, or is accidentally or intentionally
destroyed or lost or is damaged or tampered with, to such an extent, that the result of the poll at that
polling station cannot be ascertained; or(b)any voting machine develops a mechanical failure during
the course of the recording of votes; or(c)any such error or irregularity in procedure as is likely to
vitiate the poll is committed at a polling station, the Returning Officer shall forthwith report the
matter to the State Election Commission.(2)Thereupon the State Election Commission shall, after
taking all material circumstances into account; either-(a)declare the poll at that polling station to be
void, appoint a day, and fix the hours, for taking a fresh poll at that polling station and notify the day
so appointed and the hours so fixed in such manner as it may deem fit; or(b)if satisfied that the
result of a fresh poll at that polling station will not, in any way, affect the result of the election or
that the mechanical failure of the voting machine or the error or irregularity in procedure is not
material, issue such directions to the Returning Officer as it may deem proper for the further
conduct and completion of the election.(3)The provisions of this Act and of any rules or orders made
thereunder shall apply to every such fresh poll as they apply to the original poll.]
225D. [ Destruction, loss, etc., of ballot papers at the time of counting.
[Inserted by Act No. 22 of 2006, dated 19.4.2006.]
(1)If any time before the counting of votes is completed any ballot papers used at a polling station
are unlawfully taken out of the custody of the Returning Officer or are accidentally or intentionally
destroyed or lost or are damaged to tampered with, to such an extent that the result of the poll at
that polling station cannot be ascertained, the Returning Officer shall forthwith report the matter to
the State Election Commission.(2)Thereupon, the State Election Commission shall, after taking all
material circumstances into account, either,-(a)direct that the counting of votes shall be stopped,
declare the poll at that polling station to be void, appoint a day, and fix the hours, for taking a fresh
poll at that polling station and notify the date so appointed and hours so fixed in such manner as it
may deem fit; or(b)if satisfied that the result of a fresh poll at that polling station will not, in any
way, affect the result of the election, issue such directions to the Returning Officer as it may deem
proper for the resumption and completion of the counting and for the further conduct and
completion of the election in relation to which the votes have been counted.(3)The provisions of thisAndhra Pradesh Panchayat Raj Act, 1994

Act and of any rules or orders made thereunder shall apply to every such fresh poll as they apply to
the original poll.]
226. Impersonation at elections.
- Whoever at an election applies for a ballot paper or votes in the name of any other person, whether
living or dead or in a fictitious name, or who having voted once at such election applies at the same
election for a ballot paper in this own name, and whoever abets, procures or attempts to procure the
voting by any person in any such way shall be punished with imprisonment for a term which may
extend to five years and with fine which may extend to five thousand rupees.
227. Other offences and penalties thereunder.
(1)A person shall be guilty of an electoral offence if at any election he, -(a)fraudulently defaces or
fraudulently destroys any nomination paper; or(b)fraudulently defaces or destroys or removes any
list, notice or other document affixed by or under the authority of a returning officer;
or(c)fraudulently defaces or fraudulently destroys any ballot paper or the official mark of any ballot
paper or any declaration or identity or official envelope used in connection with voting by postal
ballot; or(d)without due authority supplies any ballot paper to any person or receives any ballot
paper from any person or is in possession of any ballot paper; or(e)fraudulently puts into any ballot
box anything other than the ballot paper which he is authorised by law to put in; or(f)without due
authority destroys, takes, opens or otherwise interferes with any ballot box or ballot papers then in
use for the purposes of the election; or(g)fraudulently or without due authority as the case may be,
attempts to do any of the foregoing acts or willfully aids or abets the doing of any such acts.(2)Any
person guilty of an electoral offence under this Section shall,(a)if he is a returning officer or an
assistant returning officer or a presiding officer at a polling station or any other officer or clerk
employed on official duty in connection with the election, be punishable with imprisonment for a
term which may extend to two years or with fine or with both;(b)if he is any other person, be
punishable with imprisonment for a term which may extend to six months or with fine or with
both.(3)For the purposes of this Section a person shall be deemed to be on official duty if duty is to
take part in the conduct of an election or part of an election including the counting of votes or to be
responsible after an election for the used ballot papers and other documents in connection with such
election, but the expression "official duty" shall not include any duty imposed otherwise than by or
under this Act.
228. Penalty for offences not otherwise provided for.
- Whoever does any act in contravention of any of the provisions of this Act, or of any rule,
notification or order made, issued or passed, thereunder and not otherwise provided for in this Act
shall, on conviction, be punished with imprisonment which may extend to two years and with fine
which may extend to two thousand rupees.Andhra Pradesh Panchayat Raj Act, 1994

229. Offences by companies.
(1)Where an offence under this Act, has been committed by a company, every person who at the
time the offence was committed, was in charge of and was responsible to the company for the
conduct of the business of the company as well as the company shall be deemed to be guilty of the
offence and shall be liable to be proceeded against and punished accordingly:Provided that nothing
contained in this sub-Section shall render any such person liable to any punishment if he proves
that the offence was committed without his knowledge or that he had exercised all due diligence to
prevent the commission of such offence.(2)Notwithstanding anything contained in sub-Section (1)
where any offence under this Act has been committed by a company and it is proved that offence has
been committed with the consent or connivance or is attributable to any neglect on the part of any
director, manager, Secretary or other officer of the company, such director, manager, Secretary or
other official shall be deemed to be guilty of that offence and shall be liable to be proceeded against
and punished accordingly.Explanation. - For the purposes of this Section, -(a)"company" means any
body corporate and includes a firm or other association of individuals; and(b)"director" in relation
to a firm means a partner in the firm.[Chapter II A] [Substituted by Section 7 of Act. No. 26 of
2000.] Election Expenses
230. Application of Chapter.
- This Chapter shall apply to candidates of any election held under this Act.
230A. Account of election expenses.
(1)Every candidate, at any election held under this Act shall, either by himself, or by his election
agent, keep a separate and correct account of all expenditure incurred in connection with the
election between the date on which the candidate concerned has been nominated, and the date of
declaration of the result of the election both dates inclusive (herein after in this Chapter referred to
as 'election expenses').Explanation I. - 'Election Expenses' for purpose of this Act shall mean all
expenses in connection with the election, -(a)incurred, or authorised by the contesting candidate, or
by his election agent;(b)incurred by any association, or body of persons, or by any individual (other
than the candidate or his election agent), aimed at promoting or procuring the election of the
candidate concerned; and(c)incurred by any political party, by which the candidate is set up, so as to
promote or procure his election:Provided that any expenses incurred by any political party as part of
its general propaganda,(which is distinguishable from its election campaign, for the promotion or
procuring the election of a particular candidate), by words, either written or spoken, or by signs or
visible representations, or by audio visual devises, or through print or electronic media or otherwise,
shall not constitute 'election expenses' for purposes of this Act.Explanation II. - (1) For the removal
of doubts, it is hereby declared that any expenses incurred in respect of any arrangements made,
facilities provided or any other act, or thing done by any person in the service of the Government
and belonging to any of the classes mentioned in clause (7) of Section 211 in the discharge or
purported discharge of his official duty as mentioned in the proviso to that clause shall not be
deemed to be expenses in connection with the election incurred or authorised by a candidate or by
his election agent for the purposes of this sub-Section.(2)The account of election expenses shallAndhra Pradesh Panchayat Raj Act, 1994

contain such particulars, as may, by order, be specified by the State Election Commission.(3)The
total of the said expenses shall not exceed such amount, as may, by order, be specified by the State
Election Commission.
230B. Lodging of account with the District Election Authority.
- Every contesting candidate at an election shall, within forty five days from the date of declaration
of the result of the election, lodge with the District Election Authority, an account of his election
expenses, which shall be a true copy of the account kept by him, or by his election agent, under
Section 230A.]
Chapter III
Miscellaneous Election Matters Vacation of Seats and Offices
231. Adjournment of poll or countermanding of election on the ground of
booth capturing.
(1)If at any election, -(a)booth capturing has taken place at a polling station or in such number of
polling stations as is likely to affect the result of such election or that the result of the poll at that
polling station cannot be ascertained; or(b)booth capturing takes place in any place for counting of
votes in such manner that the result of the counting at that place cannot be ascertained, the
returning officer shall forthwith report the matter to the A.P. Election Commissioner for Local
Bodies.(2)The A.P. Election Commissioner for Local Bodies shall on the receipt of a report from the
returning officer under sub-Section (1) and after taking all material circumstances into account,
either, -(a)declare that the poll at that polling station be void, appoint a day, and fix the hours, for
taking fresh poll at that polling station and notify the date so appointed and hours so fixed in such
manner as he may deem fit, or(b)if satisfied that in view of the large number of polling stations
involved in booth capturing the result of the election is likely to be affected or that booth capturing
had affected counting of votes in such manner as to effect the result of the election, countermand the
election in that constituency.Explanation. - In this Section "booth capturing" shall have the same
meaning as in Section 224.
232. Power to delegate.
- The A.P. Election Commissioner for Local Bodies may, subject to such conditions and restrictions
as the Government may, by general or special order, impose, by order in writing delegate to any
officer or authority subordinate to him, either generally or as respects any particular matter or class
of matters any of his powers under this Act.Andhra Pradesh Panchayat Raj Act, 1994

232A. [ Appointment of Observers. [Inserted by Act No. 22 of 2006, dated
19.4.2006.]
(1)The State Election Commission may nominate an Observer who shall be an officer of Government
to watch the conduct of election or elections for such specified area or areas in the district and to
perform such other functions as may be entrusted to him by the Commission in relation
thereto.(2)The Observer nominated under Subsection (1) shall have the power to direct the
Returning Officer for the or for any of the wards or constituencies for which he has been nominated,
to stop the counting of votes at any time before the declaration of the result, or not to declare the
result, if in the opinion of the Observer, booth capturing has taken place at a large number of polling
stations or at counting centres or any ballot papers used at a polling station are unlawfully taken out
of the custody of the Returning Officer or are accidentally or intentionally destroyed or lost or are
damaged or tampered with, to such an extent that the result of the poll at that polling station cannot
be ascertained.(3)Where an Observer has directed the Returning Officer under this section to stop
counting of votes or not to declare the result, the Observer shall forthwith report the matter to the
Commission and thereupon the Commission shall, after taking all material circumstances into
account, issue appropriate directions under Section 225-D or Section 231 in the matter of
declaration of results.(4)It shall be competent for the State Election Commission to appoint an
Election Expenditure Observer for a group of wards or constituencies or for a Mandal or group of
Mandals so as to ensure that the provisions of Sections 230-A and 230-B are strictly adhered to and
in that behalf the Commission may issue such instructions as it deems fit, from time to time, to such
Observers.]
233. Election petitions.
- No election held under this Act shall be called in question except by an election petition presented
to such authority and in accordance with such rules as may be made in this behalf.
234. Prohibition of holding dual offices and vacation of seats.
(1)No person shall be entitled to contest in the elections to the offices of member of the Gram
Panchayat from more than one ward or to the office of member of the [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or [Zilla Praja Parishad]
[Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] from more than one territorial
constituency.(2)No person shall be a member of the Gram Panchayat, member of the [Mandal Praja
Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or [Zilla Praja
Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] simultaneously and
if he is so elected, he shall retain only one office and vacate the other office or offices in the manner
prescribed.(3)Where a person is elected to more than one office of member of the Gram Panchayat
or [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.]
or [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] and
Sarpanch or President or Chairperson he shall retain one office and vacate the other office or offices
in the manner prescribed except when his continuance as member of the [Mandal Praja Parishad]Andhra Pradesh Panchayat Raj Act, 1994

[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or [Zilla Praja Parishad]
[Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] is necessary to continue as
President or as the case may be the Chairperson thereof.
Part VI – Finance Commission
235. Constitution of Finance Commission.
(1)The Governor shall on the recommendation of the State Government constitute a Finance
Commission as soon as may be within one year from the date of commencement of the Constitution
(Seventy-third) Amendment Act, 1992 and thereafter on the expiration of every fifth year.(2)The
Finance Commission shall consist of a Chairman and four other members of whom one shall be the
Member Secretary. The Governor shall, by order appoint, on the recommendation of the
Government, the Chairman and other members of the Commission.(3)The Government shall make
available to the Finance Commission such staff as may be necessary for the discharge of the
functions conferred on the Finance Commission.
236. Qualifications for appointment as, and the manner of selection of,
members of the Commission.
- The Chairman of the Commission shall be selected from among persons who have had experience
in public affairs and the other members shall be selected from among persons who -(a)have special
knowledge of the finances and accounts of Government; or(b)have had wide experience in financial
matters and in administration; or(c)have special knowledge of economics.
237. Personal interest to disqualify members.
- Before appointing a person to be a member of the Commission the Governor shall satisfy himself
that the person will have no such financial or other interest as is likely to affect prejudicially his
functions as a member of the Commission; and the Governor shall also satisfy himself from time to
time with respect to every member of the Commission that he has no such interest and any person
who is, or whom the Governor proposes to appoint to be a member of the Commission shall,
whenever required by the Governor so to do, furnish to him such information as the Governor
considers necessary for the performance by him of his duties under this Section.
238. Disqualifications for being a member of the Commission.
- A person shall be disqualified for being appointed as, or for being a member of the Commission,
-(a)if he is of unsound mind;(b)if he is an undischarged insolvent;(c)if he has been convicted of an
offence involving moral turpitude;(d)if he has such financial or other interest as is likely to affect
prejudicially his functions as a member of the Commission.Andhra Pradesh Panchayat Raj Act, 1994

239. Term of office of members and eligibility for reappointment.
- Every member of the Commission shall hold office for such period as may be specified in the order
of the Governor, appointing him, but shall be eligible for reappointment:Provided that he may, by
letter addressed to the Governor, resign his office.
240. Conditions of service and salaries and allowances of members.
- The members of the Commission shall render whole-time or part-time service to the Commission
as the Governor in each case specify, and there shall be paid to the members of the Commission
such fees or salaries and such allowances as the State Government may, by rules made in this behalf,
determine.
241. Functions of the Commission.
(1)The Finance Commission shall review the financial position of the Gram Panchayats, [Mandal
Praja Parishads] [Substituted 'Mandal Parishads' by Act No. 41 of 2006, dated 23.9.2006.] and
[Zilla Praja Parishad] [Substituted 'Zilla Parishads' by Act No. 41 of 2006, dated 23.9.2006.] and
make recommendations to the Government as to, -(a)the principles which should govern -(i)the
distribution between the State and the said Gram Panchayats and Parishads of the net proceeds of
the taxes, duties, tolls and fees leviable by the State, which may be divided between them and the
allocation between the said Gram Panchayats and Parishads at all levels of their respective shares of
such proceeds;(ii)the determination of the taxes, duties, tolls and fees which may be assigned to or
apportioned by, the said Gram Panchayats and Parishads;(iii)the Grant-in-Aid to the said Gram
Panchayats and Parishads from the Consolidated Fund of the State;(b)the measures needed to
improve the financial position of the said Gram Panchayats and Parishads.(2)The Government shall
cause every recommendation made by the Commission under this Section together with an
explanatory memorandum as to the action taken thereon to be laid before the Legislature of the
State.
242. Procedure and powers of the Commission.
(1)The Commission shall determine their procedure and in the performance of their functions shall
have all the powers of a Civil Court under the Code of Civil Procedure. 1908 (Central Act 5 of 1908)
while trying a suit in respect of the following matters, namely -(a)summoning and enforcing the
attendance of witnesses;(b)requiring the production of any document;(c)requisitioning any public
record from any court or office.(2)The Commission shall have power to require any person to
furnish information on such points or matters as in the opinion of the Commission may be useful
for, or relevant to, any matter under the consideration of the Commission and any person so
required shall, notwithstanding anything contained in sub-Section (2) of Section 54 of the Indian
Income-Tax Act, 1922 (Central Act 2 of 1922) or in any other law for the time being in force, be
deemed to be legally bound to furnish such information within the meaning of Section 176 of the
Indian Penal Code. (Central Act 45 of 1860).(3)The commission shall be deemed to be a Civil CourtAndhra Pradesh Panchayat Raj Act, 1994

for the purposes of Sections 345 (1) and 346 of the Code of Criminal Procedure, 1973. (Central Act 2
of 1974).Explanation. - For the purposes of enforcing the attendance of witnesses, the local limits of
the Commission's jurisdiction shall be the limits of the territory of the State of Andhra Pradesh.[Part
VI-A] [Inserted by Act No. 7 of 1998.] Special provisions relating to the Panchayats, [Mandal Praja
Parishads] [Substituted 'Mandal Parishads' by Act No. 41 of 2006, dated 23.9.2006.] and [Zilla
Praja Parishad] [Substituted 'Zilla Parishads' by Act No. 41 of 2006, dated 23.9.2006.] located in the
scheduled areas
242A. Application of this Part.
(1)The provisions of this Part shall apply to the Gram Panchayats, [Mandal Praja Parishads]
[Substituted 'Mandal Parishads' by Act No. 41 of 2006, dated 23.9.2006.] and [Zilla Praja Parishad]
[Substituted 'Zilla Parishads' by Act No. 41 of 2006, dated 23.9.2006.] constituted in the Scheduled
Areas in the State.(2)The provisions of this Part shall prevail over anything inconsistent therewith
elsewhere in this Act.
242B. Declaration of village in Scheduled Areas.
- For the purposes of Section 3, a village shall ordinarily consist of a habitation or a group of
habitations or a hamlet or a group of hamlets thereof comprising a community or communities and
managing their affairs in accordance with traditions and customs.
242C. Functions of Gram Sabha.
(1)Every Gram Sabha shall be competent to safeguard and preserve the traditions and customs of
the people, their cultural identity, community resources and without detriment to any law for the
time being in force, the customary mode of dispute resolution.(2)Every Gram Sabha shall,
-(i)approve plans, programmes and projects for social and economic development before such plans,
programmes and projects are taken up for implementation by the Gram Panchayat, at the village
level;(ii)be responsible for the identification of selection of persons as beneficiaries under poverty
alleviation and other programmes.(3)Every Gram Panchayat shall obtain from the Gram Sabha a
certification of utilisation of funds by that Panchayat for the plans, programmes and projects
referred to in sub-Section (2).
242D. Reservation of seats of members of Gram Panchayat and [Mandal
Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.] and offices of Sarpanches of Gram Panchayats and Presidents of
[Mandal Praja Parishads] [Substituted 'Mandal Parishads' by Act No. 41 of
2006, dated 23.9.2006.].
- The reservation of seats in the Scheduled Areas to every Gram Panchayat and [Mandal Praja
Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] shall be in
proportion to the population of the communities in that Gram Panchayat or the [Mandal PrajaAndhra Pradesh Panchayat Raj Act, 1994

Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] as the case may
be:Provided that the reservation for the Scheduled Tribes shall not be less than one-half of the total
number of seats:Provided further that all seats of Sarpanches of Gram Panchayats and Presidents of
[Mandal Praja Parishads] [Substituted 'Mandal Parishads' by Act No. 41 of 2006, dated 23.9.2006.]
shall be reserved for the Scheduled Tribes.
242E. Nomination of persons.
- The Government may nominate persons belonging to such Scheduled Tribes who have no
representation in [Mandal Praja Parishads] [Substituted 'Mandal Parishads' by Act No. 41 of 2006,
dated 23.9.2006.]:Provided that such nomination shall not exceed one tenth of the total members to
be elected in that [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006,
dated 23.9.2006.].
242F. Acquisition of land in the Scheduled Areas.
- The [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.] shall be consulted before making the acquisition of land in the Scheduled Areas for
development projects and before resettling or rehabilitating persons evicted by such projects in the
Scheduled Areas, the actual planning and implementation of the projects in the Scheduled Areas
shall be coordinated at the State level.
242G. Management of minor water bodies in the Scheduled Areas.
- Planning and management of minor water bodies in the Scheduled Areas shall be entrusted to
Gram Panchayats, [Mandal Praja Parishads] [Substituted 'Mandal Parishads' by Act No. 41 of 2006,
dated 23.9.2006.] or the [Zilla Praja Parishad] [Substituted 'Zilla Parishads' by Act No. 41 of 2006,
dated 23.9.2006.], as the case may be, in such manner as may be prescribed.
242H. Minor minerals in the Scheduled Areas.
(1)The recommendations of the Gram Panchayats, made in such manner as may be prescribed, shall
be taken into consideration prior to grant of prospecting licence or mining lease, for minor minerals
in the Scheduled Areas.(2)The prior recommendation of the Gram Panchayat, made in such manner
as may be prescribed, shall be taken into consideration for grant of concession for the exploitation of
minor minerals by auction.
242I. Powers and functions of Gram Panchayats and [Mandal Praja
Parishads] [Substituted 'Mandal Parishads' by Act No. 41 of 2006, dated
23.9.2006.].
(1)The Gram Panchayat or as the case may be, the Gram Sabha shall exercise such powers and
perform such functions in such manner and to such extent as may be prescribed in respect of theAndhra Pradesh Panchayat Raj Act, 1994

following matters, namely: -(a)enforcement of prohibition or regulation or restriction of the sale and
consumption of any intoxicant;(b)the ownership of minor forest produce;(c)prevention of alienation
of land in the Scheduled Areas and restoration of any unlawfully alienated land of a Scheduled
Tribe;(d)management of village markets by whatever name called; and(e)exercising control over
money lending to the Scheduled Tribe;(2)The [Mandal Praja Parishad] [Substituted 'Mandal
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] shall exercise such powers and perform such
functions in such manner and to such extent as may be prescribed, in respect of the following
matters, namely:-(a)exercising control over institutions and functionaries in all social Sectors;
and(b)control over local plans and resources for such plans including tribal sub-plans.
Part VII – Miscellaneous
243. Transfer of powers and functions of District Board to [Mandal Praja
Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.] and [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No.
41 of 2006, dated 23.9.2006.].
(1)Notwithstanding anything in the relevant District Boards Act or any other law, the Government
may, by notification and subject to such control, restrictions, conditions and reservations as may be
specified therein, direct that any powers exercisable or functions performable by a District Board by
or under the relevant District Boards Act or any other law for the time being in force including the
powers to levy any tax or fees, shall be transferred to a [Mandal Praja Parishad] [Substituted
'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or a [Zilla Praja Parishad] [Substituted
'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] and thereafter the Mandal Parishad or the
[Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] as the
case my be, shall exercise and perform the powers and functions transferred to it.(2)When any
powers and functions of the District Board are transferred to a [Mandal Praja Parishad] [Substituted
'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or a [Zilla Praja Parishad] [Substituted
'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] under sub-Section (1), all references in the
relevant District Boards Act or any other law for the time being in force to the District Board with
reference to such powers and functions shall be construed as references to the [Mandal Praja
Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or the [Zilla
Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.], as the case
may be.
244. Application of the relevant District Boards Act to [Mandal Praja
Parishads] [Substituted 'Mandal Parishads' by Act No. 41 of 2006, dated
23.9.2006.] and [Zilla Praja Parishad] [Substituted 'Zilla Parishads' by Act No.
41 of 2006, dated 23.9.2006.].
(1)The Government may, by notification, direct that such of the provisions of the relevant District
Boards Act, including the provisions relating to the levy and collection of any tax or fee as may beAndhra Pradesh Panchayat Raj Act, 1994

specified in such notification, shall apply to the [Mandal Praja Parishad] [Substituted 'Mandal
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] and the [Zilla Praja Parishad] [Substituted 'Zilla
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] constituted under this Act.For the purpose of
facilitating the application of these provisions to the [Mandal Praja Parishad] [Substituted 'Mandal
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] and [Zilla Praja Parishad] [Substituted 'Zilla
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] constituted under this Act, the Government may,
by notification, make such adaptations and modifications of the relevant District Boards Act and the
rules made thereunder whether by way of repealing, amending or suspending any provision thereof,
as may be necessary or expedient and thereupon the relevant District Boards Act and the rules made
thereunder shall have effect subject to the adaptations and modifications so
made.(2)Notwithstanding that no provision or insufficient provision has been made under
sub-Section (1) for the adaptations of the provisions of the relevant District Boards Act, or the rules
made thereunder, any court, tribunal or authority required or empowered to enforce these
provisions may, for the purpose of facilitating their application to any [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or the [Zilla Praja
Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] construe these
provisions in such manner, without affecting the substance, as may be necessary or proper in regard
to the matter before the court, tribunal or authority.
245. Motion of no confidence in Upa-Sarpanch, President or Chairperson.
(1)A motion expressing want of confidence in the Upa-Sarpanch or President or Vice-President or
Chairperson or Vice-Chairperson may be made by giving a written notice of intention to move the
motion in such form and to such authority as may be prescribed, signed by not less than one-half of
the total number of members of the Gram Panchayat, [Mandal Praja Parishad] [Substituted 'Mandal
Parishad' by Act No. 41 of 2006, dated 23.9.2006.], or as the case may be the [Zilla Praja Parishad]
[Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] and further action on such
notice shall be taken in accordance with the procedure prescribed:Provided that no notice of motion
under this Section shall be made within two years of the date of assumption of office by the person
against whom the motion is sought to be moved:Provided further that no such notice shall be made
against the same person more than once during his term of office.Explanation. - For the removal of
doubts, it is hereby declared that for the purpose of this Section the expression "total number of
members" means, all the members who are entitled to vote in the election to the office concerned
inclusive of the Sarpanch, President or Chairperson but irrespective of any vacancy existing in the
office of such members at the time of meeting:Provided that a suspended office-bearer or member
shall also be taken into consideration for computing the total number of members and he shall also
be entitled to vote in a meeting held under this Section.(2)if the motion is carried with the support
of [***] [Omitted by Section 2(i) of Andhra Pradesh Act No. 8 of 2000.] two thirds of the total
number of members in the case of a Upa-Sarpanch, the Commissioner shall and in the case of the
President or Vice-President or Chairperson or Vice-Chairperson, the Government shall by
notification remove him from office and the resulting vacancy shall be filled in the same manner as a
casual vacancy.[Explanation. - For the purposes of this Section, in the determination of two-thirds
of the total number of members, any fraction below 0.5 shall be ignored and any fraction of 0.5 or
above shall be taken as one.] [Added by Section 2(ii) of Andhra Pradesh Act No. 8 of 2000.]Andhra Pradesh Panchayat Raj Act, 1994

246. Power to cancel or suspend resolution of a Gram Panchayat, [Mandal
Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.] or [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41
of 2006, dated 23.9.2006.].
(1)The Government may either suo moto or on a reference made to them by the Executive Officer or
[Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.]
Development Officer or as the case may be, the Chief Executive Officer, in the manner prescribed by
order in writing cancel any resolution passed by a Gram Panchayat, [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or a [Zilla Praja Parishad]
[Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or any standing Committee of
a [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] if in
their opinion such resolution,(a)is not legally passed, or(b)is in excess or abuse of the powers
conferred by or under this Act, or any other law;or(c)on its execution is likely to cause danger to
human life, health or safety or is likely to lead to a riot or affray.(2)The Government shall, before
taking action under sub-Section (1), give the Gram Panchayat, [Mandal Praja Parishad] [Substituted
'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or the [Zilla Praja Parishad]
[Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] as the case may be, an
opportunity for explanation.(3)If in the opinion of the District Collector, immediate action is
necessary to suspend a resolution on any of the grounds referred to in clause (c) of sub-Section (1),
he may make a report to the Government and the Government may, by order in writing, suspend the
resolution.
247. Power of Government to take action in default of a Gram Panchayat,
[Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006,
dated 23.9.2006.] or a [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by
Act No. 41 of 2006, dated 23.9.2006.].
(1)If at any time it appears to the Government that a Gram Panchayat or the Sarpanch thereof or a
[Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or
the President thereof or a [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006,
dated 23.9.2006.] or the Chairperson thereof or any standing Committee of the [Zilla Praja
Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] has made default in
performing any function or discharging any duty imposed by or under this Act, or any relevant law
for the time being in force, the Government may, by order in writing fix a period for performing
such function or discharging such duty.(2)If such function or duty is not performed or discharged by
any authority aforesaid within the period so fixed, the Government may appoint some person to
perform that function or discharge that duty and may direct that the expenses incurred in that
regard shall be paid by the person having the custody of the Gram Panchayat Fund, [Mandal Praja
Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] Fund or the
[Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] Fund, as
the case may be, in priority to any other charges against such fund except charges for the service of
authorised loans.Andhra Pradesh Panchayat Raj Act, 1994

248. Power of Government to issue directions.
(1)Notwithstanding anything contained in this Act, it shall be competent for the Commissioner or
the Government to issue such directions as they may consider necessary to the Executive Officer,
[Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.]
Development Officer or the Chief Executive Officer for the proper working of the Gram Panchayat,
[Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or
as the case may be, the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006,
dated 23.9.2006.] or for the implementation of the resolutions thereof and the Executive Officer,
[Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.]
Development Officer or as the case may be, the Chief Executive Officer shall implement those
directions, failing which, he shall be liable for disciplinary action under the relevant rules.(2)The
Sarpanch of the Gram Panchayat, the President of [Mandal Praja Parishad] [Substituted 'Mandal
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or as the case may be, the Chairman of the [Zilla
Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] shall ensure
that the Executive Officer, [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of
2006, dated 23.9.2006.] Development Officer or as the case may be, the Chief Executive Officer
implements the directions issued by the Government under sub-Section (1) and shall not do
anything in derogation to the directions of the Government aforesaid. The Sarpanch, the President
or the Chairman who contravenes the provisions of this Section shall be deemed to have willfully
omitted or refused to carry out the orders of the Government for the proper working of the Gram
Panchayat, [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.] or as the case may be, the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No.
41 of 2006, dated 23.9.2006.] within the meaning of Section 249.
249. Powers of Government to remove Sarpanch, President or Chairperson
etc.
(1)If in the opinion of the District Collector the Sarpanch or the Upa-Sarpanch and in the opinion of
the Government the President or the Vice-President or as the case may be, the Chairperson or the
Vice-Chairperson, -(i)wilfully omitted or refused to carry out the orders of the Government for the
proper working of the concerned local body; or(ii)abused his position or the powers vested in him;
or(iii)is guilty of misconduct in the discharge of his duties; or(iv)persistently defaulted in the
performance of his functions and duties entrusted to him under the Act to the detriment of the
functioning of the concerned local body or has become incapable of such performance:The Collector
or as the case may be, the Government, may remove such Sarpanch or Upa- Sarpanch, President or
Vice-President or as the case may be the Chairperson or the Vice-Chairperson, after giving him an
opportunity for Explanation. -Provided that the proceedings initiated under this sub-Section may be
continued notwithstanding the fact that the Sarpanch or Upa-Sarpanch, President or
Vice-President, or as the case may be, the Chairperson or Vice-Chairperson ceased to hold office by
resignation or other-wise and shall be concluded within two years from the date of such cessation
and where on such conclusion the authority competent to remove him, records a finding after giving
an opportunity of making a representation to the person concerned that the charge or charges
proved against him are sufficient for his removal, then the provision of sub-Section (3) shall apply toAndhra Pradesh Panchayat Raj Act, 1994

the person against whom such finding is recorded.(2)Where the Sarpanch or Upa-Sarpanch, the
President or the Vice-President or the Chairperson of Vice-Chairperson is removed under
sub-Section (1) the vacancy shall, subject to the provisions of sub-Section (3) be filled as casual
vacancies.(3)A Sarpanch or Upa-Sarpanch, a President or a Vice-President or Chairperson or
Vice-Chairperson removed from his office under this Section shall not be eligible for re-election as
Sarpanch or Upa-Sarpanch, President or Vice-President or Chairperson or Vice-Chairperson for a
period of two years from the date of the removal.(4)If the District Collector is satisfied that any
elected member of the Gram Panchayat or the Government are satisfied that any elected member of
a [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.]
or [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] is
guilty of any misconduct while acting or purporting to act in the discharge of his duties, or in the
performance of the functions, under this Act, the District Collector or as the case may be, the
Government may, by order, remove such member, after giving him an opportunity for explanation,
and any member so removed shall not be eligible for re-election as a member for a period of two
years from the date of removal.(5)Where a member of Gram Panchayat, [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or [Zilla Praja Parishad]
[Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] is removed under sub-Section
(4), the vacancy shall be filled in such manner and within such time as may be prescribed.(6)If the
District Collector is of the opinion that a Sarpanch or a Upa-Sarpanch or any member of a Gram
Panchayat or the Government are of the opinion that any President or Vice-President or the
Chairperson or Vice-Chairperson or any member of a [Mandal Praja Parishad] [Substituted 'Mandal
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or [Zilla Praja Parishad] [Substituted 'Zilla
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] wilfully omitted or refused to carry out the
orders of Government for the proper working of the concerned local body or abused his position or
the powers vested in him, and that the further continuance of such person in office would be
detrimental to the interests of the concerned local body or the inhabitants of the Village, Mandal or
District, the District Collector or as the case may be, Government may, by order, suspend such
Sarpanch or Upa-Sarpanch or President or Vice-President or as the case may be, the Chairperson or
Vice-Chairperson or member from office for a period not exceeding three months, pending
investigation into the said charges and action thereon under the foregoing provisions of this
Section:Provided that no order under this sub-Section shall be passed unless the person concerned
has had an opportunity of making a representation against the action proposed:Provided further
that it shall be competent for the Government to extend, from time to time, the period of suspension
for such further period not exceeding three months; so however that the total period of suspenstion
shall not exceed six months:Provided also that a person suspended under this sub-Section shall not
be entitled to exercise the powers and perform the functions attached to his office and shall not be
entitled to attend the meetings of the concerned local body except a meeting held for the
consideration of a no-confidence motion.(7)Any person aggrieved by an order of removal passed by
the District Collector under sub-Section (1) or Sub-Section (4) may within thirty days from the date
of the order prefer an appeal to the Government and the Government may, pending a decision on
such appeal, stay the order appealed against.Andhra Pradesh Panchayat Raj Act, 1994

250. Powers of Government to dissolve Gram Panchayat, [Mandal Praja
Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.] or [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41
of 2006, dated 23.9.2006.].
(1)(i)If at any time, it appears to the Government that a Gram Panchayat, [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or a [Zilla Praja Parishad]
[Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] is not competent to perform
its functions or has failed to exercise its powers or perform its functions or has exceeded or abused
any of the powers conferred upon it by or under this Act, or any other law for the time being in force,
the Government may direct the Gram Panchayat, [Mandal Praja Parishad] [Substituted 'Mandal
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or as the case may be, [Zilla Praja Parishad]
[Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] to remedy such incompetency,
failure, excess or abuse or to give a satisfactory explanation therefor and if the Gram Panchayat,
[Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or
the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.], fails
to comply with such direction, the Government may dissolve it with effect from a specified date and
reconstitute it either immediately or within six months from the date of dissolution, and cause any
or all of the powers and functions of the Gram Panchayat, [Mandal Praja Parishad] [Substituted
'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or the [Zilla Praja Parishad]
[Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] to be exercised and performed
by such person or authority as the Government may appoint in that behalf during the period of its
dissolution and any person or authority so appointed may, if the Government so direct, receive
remuneration for the services rendered from the funds of the Gram Panchayat, [Mandal Praja
Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or the [Zilla
Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.], as the case
may be.(ii)With effect from the date specified for the dissolution of a Gram Panchayat, [Mandal
Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or [Zilla
Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] under clause
(i), all its members including its Sarpanch, Upa-Sarpanch, President or Vice-President and
Chairperson or Vice-Chairperson, as the case may be, shall forthwith be deemed to have vacated
their offices as such and they shall not be entitled to be restored to office after the expiration of the
period of dissolution. The vacancies arising out of vacation of offices under this Section shall be
deemed to be casual vacancies and filled accordingly within a period of six months from the date of
dissolution:Provided that no casual elections to fill the vacancies under this Section shall be held
where the remainder of the period for which the dissolved Gram Panchayat, [Mandal Praja
Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or, as the case
may be, the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated
23.9.2006.] would have continued had it not been dissolved is less than six months.(2)The
Government may, by notification, authorise the District Collector to exercise the powers of the
Government under sub-Section (1) in respect of Gram Panchayats.(3)If, at any time, it appears to
the Government that a Standing Committee of a [Zilla Praja Parishad] [Substituted 'Zilla Parishad'
by Act No. 41 of 2006, dated 23.9.2006.] is not competent to perform its functions or has failed toAndhra Pradesh Panchayat Raj Act, 1994

exercise its powers or perform its functions or has exceeded or abused any of the powers conferred
upon it by or under this Act, or any other law for the time being in force, the Government may direct
the Standing Committee to remedy such incompetency, failure, excess or abuse, or to give a
satisfactory explanation therefor and if the Standing Committee fails to comply with such direction,
the Government may dissolve the Standing Committee and direct the [Zilla Praja Parishad]
[Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] to re-constitute the dissolved
Standing Committee immediately thereafter.
250A. [ Special provision in the case of Mandal Praja Parishad and Zilla Praja
Parishad. [Inserted by Act No. 17 of 2011, dated 20.12.2011.]
(1)The Government, or as the case may be, an officer authorized by the Government, shall appoint a
Special Officer or a Person-in-charge or a Committee of persons-in-charge to a Mandal Praja
Parishad or a Zilla Praja Parishad, if for any reason, the process of election to such Mandal Praja
Parishad or Zilla Praja Parishad is not completed, in accordance with the Act.(2)The Special Officer
or Person-in-charge or the Committee of persons-in-charge, appointed under sub-section (1) shall
exercise the powers, discharge the duties and perform the functions of the Mandal Praja Parishad or
Zilla Praja Parishad until the members, the President and Vice-President of Mandal Praja Parishad
and the members, the Chairman and Vice-Chairman of Zilla Praja Parishad elected thereof
respectively, assume office.(3)The term of the Special Officer or Person-in-charge or Committee of
persons-in-charge appointed under subsection (1) shall be for a period of six months from the date
of appointment or till the date of assumption of office, of the members and office bearers of Mandal
Praja Parishad and Zilla Praja Parishad respectively, whichever is earlier.(4)Subject to such rules as
may be made in this behalf, the administration of the Mandal Praja Parishad or as the case may be,
the Zilla Praja Parishad shall be carried on by the Special Officers or a Person-in-charge or a
Committee of persons-in-charge appointed under sub-section (1) in accordance with the provisions
of the Act and the rules made thereunder.]
251. Acts of Gram Panchayats, [Mandal Praja Parishad] [Substituted '<SPAN
class=amd2><A TITLE =] and [Zilla Praja Parishad] [Substituted 'Zilla
Parishads' by Act No. 41 of 2006, dated 23.9.2006.] not to be invalidated by
informality, vacancy, etc.
(1)No act of a Gram Panchayat shall be deemed to be invalid by reason only of a defect in the
establishment of such Gram Panchayat or on the ground that the Sarpanch, Upa-Sarpanch or any
member of such Gram Panchayat was not entitled to hold, or continue in such office by reason of
any disqualification or by reason of any irregularity or illegality in his election, as the case may be, or
by reason of such act having been done during the period of any vacancy in the office of the
Sarpanch, Upa-Sarpanch, or member of such Gram Panchayat.(2)The provisions of sub-Section (1)
shall mutatis-mutandis apply to the acts of a [Mandal Praja Parishad] [Substituted 'Mandal
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or a [Zilla Praja Parishad] [Substituted 'Zilla
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or a Standing Committee thereof.Andhra Pradesh Panchayat Raj Act, 1994

252. Oath of allegiance.
(1)Every person who is elected to be the Sarpanch or member of a Gram Panchayat or the President
or member of a [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006,
dated 23.9.2006.] or the Chairperson or member of a [Zilla Praja Parishad] [Substituted 'Zilla
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] shall, before taking his seat make, at a special
meeting or any other meeting of the Gram Panchayat, [Mandal Praja Parishad] [Substituted
'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or the [Zilla Praja Parishad]
[Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.], as the case may be, an oath or
affirmation of his allegiance to the Constitution of India in the form prescribed.(2)Any such
Sarpanch, President or Chairperson or member who fails to make, within three months of the date
on which his term of office commences, or at one of the first three meetings held after the said date,
whichever is later, the oath or affirmation laid down in sub-Section (1) shall cease to hold his office
and his seat shall be deemed to have become vacant.(3)No such Sarpanch, President or Chairperson
or member shall take his seat at a meeting of the Gram Panchayat, [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or, as the case may be, of
the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or
do any act as such member unless he has made the oath or affirmation as laid down in this
Section.(4)Where a person ceases to hold office under sub-Section (2), the Executive Officer, the
[Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.]
Development Officer, or as the case may be, the Chief Executive Officer, shall report the same to the
Gram Panchayat, [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006,
dated 23.9.2006.] or the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006,
dated 23.9.2006.] at its next meeting and on application of such person made within thirty days of
the date on which he has ceased to be Sarpanch, President or Chairperson or member under that
sub-Section, the Gram Panchayat, [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act
No. 41 of 2006, dated 23.9.2006.] or the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act
No. 41 of 2006, dated 23.9.2006.] may grant him further time which shall not be less than four
months and not more than nine months for making the oath or affirmation and if he makes the oath
or affirmation within the time so granted, he shall, notwithstanding anything in this Act, continue to
hold his office.(5)Where on an application made by a person who ceases to hold office under
sub-Section (2), the Government are satisfied that such person for reasons beyond his control, has
not been able to make the oath or affirmation within the period specified in sub-Section (2) or
within further time, if any, granted to him under sub-Section (4), they may, by an order, grant such
further time as they deem fit to the person to make the oath or affirmation. If such person makes the
oath or affirmation within the time granted he shall, notwithstanding anything in this Act, continue
to hold his office.
253. Administration report.
(1)Every [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.] shall furnish to the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of
2006, dated 23.9.2006.] and every [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41
of 2006, dated 23.9.2006.] shall furnish to the Government a report on its administration for eachAndhra Pradesh Panchayat Raj Act, 1994

year, as soon as may be, after the close of such year, in such form and with such details as may be
prescribed. The [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006,
dated 23.9.2006.] shall, while furnishing the report to [Zilla Praja Parishad] [Substituted 'Zilla
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] as aforesaid send a copy thereof to the
Government.(2)The [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated
23.9.2006.] shall consider the administration report of each [Mandal Praja Parishad] [Substituted
'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] and forward it to the Government with
its remarks.(3)The report of the [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No.
41 of 2006, dated 23.9.2006.] shall be prepared by the [Mandal Praja Parishad] [Substituted
'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] Development Officer and that of [Zilla
Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] by its Chief
Executive Officer and the [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of
2006, dated 23.9.2006.] or the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of
2006, dated 23.9.2006.] shall consider and forward it to the [Zilla Praja Parishad] [Substituted 'Zilla
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or the Government, as the case may be, with its
resolution thereon.(4)The administration report of the Gram Panchayat shall be prepared by the
Executive Officer if there is one and if there is no Executive Officer by the [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] Development Officer
having jurisdiction over the Gram Panchayat. The same shall be forwarded to District Panchayat
Officer who shall process it in the prescribed manner.
254. Recovery of sums due to the Gram Panchayats, [Mandal Praja
Parishads] [Substituted 'Mandal Parishads' by Act No. 41 of 2006, dated
23.9.2006.] or [Zilla Praja Parishad] [Substituted 'Zilla Parishads' by Act No.
41 of 2006, dated 23.9.2006.] as arrears of land revenue.
- Any sum due to, or recoverable by, a Gram Panchayat, [Mandal Praja Parishad] [Substituted
'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or a [Zilla Praja Parishad] [Substituted
'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] under this Act may be recovered as if it
were an arrear of land revenue.
255. Power of entry of inspecting officers.
(1)Any Officer or person whom the Government may empower in this behalf may enter on and
inspect, -(a)any immovable property, or any work in progress under the control of any Gram
Panchayat, [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.] or the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated
23.9.2006.];(b)any school, hospital, dispensary, vaccination station, choultry or other institution
maintained by, or under the control of any Gram Panchayat, [Mandal Praja Parishad] [Substituted
'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or [Zilla Praja Parishad] [Substituted
'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] and any records, registers or other
documents kept in such institution;(c)the office of any Gram Panchayat, [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or [Zilla Praja Parishad]Andhra Pradesh Panchayat Raj Act, 1994

[Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] and any records, registers or
other documents kept therein.(2)The Gram Panchayat, [Mandal Praja Parishad] [Substituted
'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or the [Zilla Praja Parishad]
[Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] shall be bound to afford to the
officer or person referred to in sub-Section (1) such access at all reasonable times, to its property or
premises and to all documents as may, in the opinion of such officer or person, be necessary to
enable him to discharge his duties under the said sub-Section.
256. Power to call for records etc.
- The Government or any officer or person duly empowered by them in this behalf, may, -(a)call for
any record, register or other document in the possession or under the control of any Gram
Panchayat, [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.] or [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated
23.9.2006.];(b)require any Gram Panchayat, [Mandal Praja Parishad] [Substituted 'Mandal
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or [Zilla Praja Parishad] [Substituted 'Zilla
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] to furnish any return, plan, estimate, statement,
account or statistics;(c)require any Gram Panchayat, [Mandal Praja Parishad] [Substituted 'Mandal
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or [Zilla Praja Parishad] [Substituted 'Zilla
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] to furnish any information or report on any
matter connected with such Gram Panchayat, [Mandal Praja Parishad] [Substituted 'Mandal
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or [Zilla Praja Parishad] [Substituted 'Zilla
Parishad' by Act No. 41 of 2006, dated 23.9.2006.]; and(d)record in writing for the consideration of
any Gram Panchayat, [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of
2006, dated 23.9.2006.] or [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006,
dated 23.9.2006.] any observations, the Government, officer or person may think proper to make in
regard to the proceedings or duties of such Gram Panchayat, [Mandal Praja Parishad] [Substituted
'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or [Zilla Praja Parishad] [Substituted
'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.].
257. Protection of acts done in good faith.
- No suit, prosecution or other legal proceedings shall be instituted against any person for anything
which is, in good faith, done or intended to be done under this Act or under the rules made
thereunder.
258. Chairperson, President, Sarpanch etc., to be public servants.
- The Chairperson, the Vice-Chairperson or a member of a [Zilla Praja Parishad] [Substituted 'Zilla
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] the President, the Vice-President or a member of
a [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.],
the Sarpanch, Upa-Sarpanch or member of a Gram Panchayat, the Chief Executive Officer, or any
Officer or servant of a [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006,
dated 23.9.2006.] or a [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 ofAndhra Pradesh Panchayat Raj Act, 1994

2006, dated 23.9.2006.] Development Officer, the Executive Officer, or any Officer or servant of a
[Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or a
[Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or
the Gram Panchayat shall be deemed to be a public servant, within the meaning of Section 21 of
Indian Penal Code (Central Act 45 of 1860).
259. Power of [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act
No. 41 of 2006, dated 23.9.2006.] and [Zilla Praja Parishad] [Substituted 'Zilla
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] to make bye-laws.
(1)Subject to such rules as may be made, a [Mandal Praja Parishad] [Substituted 'Mandal Parishad'
by Act No. 41 of 2006, dated 23.9.2006.] with the approval of the [Zilla Praja Parishad] [Substituted
'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] and the [Zilla Praja Parishad] [Substituted
'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] may, with the approval of the Government,
make bye-laws for carrying out any of the purposes for which it is constituted.(2)The Government
shall have power to make rules regarding the procedure for making of bye-laws under this Section,
the publication thereof and the date on which they shall come into effect.
260. Delegation of powers etc.
(1)The Government may, by notification, authorise any officer or person to exercise any of the
powers vested in them by this Act except the power to make rules; and may in like manner withdraw
such authority.(2)The Commissioner or the District Collector may, by notification, authorise any
officer or person to exercise any of the powers vested by or under this Act in the Commissioner or
the District Collector, as the case may be, and may in like manner withdraw such authority.(3)The
exercise of any power delegated under sub-Section (1) or sub-Section (2) shall be subject to such
restrictions and conditions as may be prescribed or as may be specified in the notification and also
to control and revision by the delegating authority, or where such authority is the Government, by
such persons as may be empowered by the Government in this behalf. The Government shall also
have power to control and revise the acts or proceedings of any persons so empowered.(4)The
exercise of any power conferred on the Commissioner or the District Collector by any of the
provisions of this Act, including sub-Sections (2) and (3) of this Section, shall whether such power is
exercised by the Commissioner or the District Collector himself or by any person to whom it has
been delegated under sub-Section (2), be subject to such restrictions and conditions as may be
prescribed and also to control by the Government or by such person as may be empowered by them
in this behalf. The Government shall also have power to control the acts or proceedings of any
persons so empowered.(5)(a)The Andhra Pradesh Election Commissioner for Local Bodies, may by
notification, authorise any officer or person to exercise in any local area in the revenue district in
regard to any Gram Panchayat or all Gram Panchayats in that area, any of the powers vested in him
by or under this Act, or in regard to any [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by
Act No. 41 of 2006, dated 23.9.2006.] or [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act
No. 41 of 2006, dated 23.9.2006.] in so far as it relates to the conduct of elections under this Act,
and may, in like manner, withdraw such authority.(b)The provisions of sub-Sections (3) and (4)Andhra Pradesh Panchayat Raj Act, 1994

shall apply, as far as may be, in regard to the power delegated under this sub-Section.(c)The Andhra
Pradesh Election Commissioner for Local Bodies may appoint such number of additional, joint,
deputy or assistant election authorities, as it thinks fit to exercise such powers and perform such
functions as are assigned by the Andhra Pradesh Election Commission for Local Bodies.(6)A
[Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or
a [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or any
person exercising or performing any powers or functions by or under the provisions of this Act may
delegate its or his powers or functions in writing to any person or authority, subject to such
restrictions, limitations and conditions as may be prescribed and also to control and revision by the
Government.Provided that the President of a [Mandal Praja Parishad] [Substituted 'Mandal
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or the Chairperson of a [Zilla Praja Parishad]
[Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] shall not delegate his powers
to any person or authority other than the Vice-President of the [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or the Vice-Chairperson of
the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.], as
the case may be, if he is in office.
261. Power to transfer institutions and works.
- The Government may transfer any institution or work under their management or control to a
[Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or a
[Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.]
and [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] may
transfer any institution under its management or control to any [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or Gram Panchayat,
subject to such conditions, limitations and restrictions as may be specified by the Government or the
[Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.], as the
case may be:Provided that no such transfer shall be made unless the prior consent of the concerned
[Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or
[Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.],
as the case may be, is obtained.
262. Emergency Powers of the Government, Commissioner and District
Collector.
(1)Subject to such control as may be prescribed, the Government, the Commissioner or the District
Collector may, in cases of emergency, direct or provide for the execution of any work, or the doing of
any act which a Gram Panchayat or Executive Officer is empowered to execute or do, and the
immediate execution or doing of which is in his opinion necessary for the safety of the public, and
may direct that the expenses of executing such work or doing such act shall be paid by the person
having the custody of the Gram Panchayat Fund in priority to any other charges against such fund
except charges for the service of authorised loans.(2)The powers of the nature referred to in
sub-Section (1) may be exercised by the Government in the case of a [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or a [Zilla Praja Parishad]Andhra Pradesh Panchayat Raj Act, 1994

[Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] subject to the variation that
for the expression "Executive Authority", the expression "[Mandal Praja Parishad] [Substituted
'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] Development Officer" or as the case may
be "Chief Executive Officer" and for the expression "Gram Panchayat Fund", the expression
"[Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.]
Fund" or as the case may be the "[Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of
2006, dated 23.9.2006.] Fund" is substituted.
263. Control over electrical undertakings of Gram Panchayats.
- The administration by a Gram Panchayat of any undertaking for the generation, transmission,
supply or use of electrical energy shall be subject to such control as may be prescribed, not
inconsistent with the provisions of the Indian Electricity Act, 1910 (Central Act 9 of 1910) or the
Electricity (Supply) Act, 1948 (Central Act 54 of 1948) as in force for the time being, the rules made
under those Acts, and the terms of the licence granted thereunder to the Gram Panchayat.
264. Power of review and revision by Government.
(1)The Government may, either suo motu or on application from any person interested, call for and
examine the record of a Gram Panchayat, [Mandal Praja Parishad] [Substituted 'Mandal Parishad'
by Act No. 41 of 2006, dated 23.9.2006.] or a [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by
Act No. 41 of 2006, dated 23.9.2006.] or of its Standing Committees or of any authority, officer or
person, in respect of any proceeding to satisfy themselves as to regularity of such proceeding or the
correctness, legality or propriety of any decision or orders passed therein and, if in any case, it
appears to the Government that any such decision or order should be modified, annulled or
reversed, or remitted for reconsideration, they may pass orders accordingly:Provided that the
Government shall not pass any order prejudicial to any party unless such party has had an
opportunity of making a representation.(2)The Government may stay the execution of any such
decision or order pending exercise of their powers under sub-Section (1) in respect thereof.(3)The
Government may suo motu at any time or on an application received from any person interested
within ninety days of the passing of an order under sub-Section (1), review any such order if it was
passed by them under any mistake, whether of fact or of law, or in ignorance of any material fact.
The provisions contained in the proviso to sub-Section (1) and in sub-Section (2) shall apply in
respect of any proceeding under this sub-Section as they apply to a proceeding under sub-Section
(1).(4)Every application preferred under sub-Section (1) shall be accompanied by a fee of fifteen
rupees.
265. Liability of Sarpanch, President, Chairperson etc., for loss, waste or
mis-application of property.
(1)If, after giving the Sarpanch, Upa-Sarpanch, President, Vice-President, Chairperson,
Vice-Chairperson or the Executive Officer, the [Mandal Praja Parishad] [Substituted 'Mandal
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] Development Officer, the Chief ExecutiveAndhra Pradesh Panchayat Raj Act, 1994

Authority an Opportunity of showing cause to the contrary, the Commissioner is satisfied that the
loss, waste, misapplications of any money or other property owned by or vested in the Gram
Panchayat, [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.], or as the case may be, the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No.
41 of 2006, dated 23.9.2006.] is a direct consequence of misconduct or gross neglect, on the part of
such person, the Commissioner may, by order in writing, direct such person to pay to the Gram
Panchayat, [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.] or as the case may be, the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No.
41 of 2006, dated 23.9.2006.] before the date fixed by him, the amount required to reimburse it for
such loss, waste or misapplication, unless such person proves that he had acted in good faith.(2)If
the amount is not so paid, the Commissioner shall cause it to be recovered as arrears of land revenue
and credited to the fund of the Gram Panchayat, [Mandal Praja Parishad] [Substituted 'Mandal
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or, as the case may be, [Zilla Praja Parishad]
[Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.].(3)An appeal shall lie within
thirty days from any decision of the Commissioner under this Section to the Government whose
decision thereon shall be final.
266. Accounts and Audit.
(1)The accounts of the Gram Panchayats, [Mandal Praja Parishads] [Substituted 'Mandal Parishads'
by Act No. 41 of 2006, dated 23.9.2006.] and [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by
Act No. 41 of 2006, dated 23.9.2006.] shall be maintained in such manner and in such form as may
be prescribed. The accounts maintained by the said local bodies shall be audited by the Director of
State Audit appointed under Section 3 of the Andhra Pradesh State Audit Act, 1989 (Act 9 of
1989).(2)For the purpose of proper maintenance of accounts and matters connected therewith or
incidental thereto, it shall be competent for the Director of State Audit to issue such directions as he
deems necessary to the Chief Executive Officer, who shall ensure that the said directions are carried
out by the said local bodies.(3)[ Notwithstanding anything contained in sub-Section (1), every local
body shall engage Chartered Accountants from out of the panels of Chartered Accountants made by
the Director of State Audit to get audited of the accounts maintained under sub-Section (1) and for
speedy finalisation of their accounts:Provided that every Sarpanch of a Gram Panchayat shall have
to close the accounts of the Gram Panchayat and get them audited before the end of third quarter of
the succeeding financial year.] [Added by Section 11 of Act No. 22 of 2002.]
267. Assessments etc., not to be impeached.
(1)No assessment or demand made, and no charge imposed, under the authority of this Act, shall be
impeached or affected by reasons of any clerical error or by reason of any mistake -(a)in respect of
the name, residence, place of business or occupation of any persons, or(b)in the description of any
property or thing, or(c)in respect of the amount assessed, demanded or charged, provided that the
provisions of this Act have in substance and effect been compiled with; and no proceedings under
this Act shall, merely, for defect in form, be quashed or set aside by any court.(2)No suit shall be
brought in any Court to recover any sum of money collected under the authority of this Act or to
recover damages on account of assessment or collection of money made under the saidAndhra Pradesh Panchayat Raj Act, 1994

authority:Provided that the provisions of this Act have in substance and effect been compiled
with.(3)No distraint or sale under this Act shall be deemed unlawful, nor shall any person making
same be deemed a trespasser, on account of any error, defect, or want of form in the bill, notice,
schedule, form, summons, notice of demand, warrant of distraint, inventory or other proceeding
relating thereto, if the provisions of this Act and of the rules and bye-laws made thereunder have in
substance and effect been compiled with:Provided that every person aggrieved by any irregularity
may recover satisfaction for any special damages sustained by him.(4)Notwithstanding anything in
the Code of Civil Procedure, 1908 (Central Act 5 of 1908) or in any other law for the time being in
force, no court shall grant any permanent or temporary injunction or make any interim orders
restraining any proceeding which is being or about to be taken under this Act for the revision or
amendment of the assessment books or restraining such revision or amendment from taking effect.
Part VIII – Rules, Bye-Laws and Penalties
268. Power of Government to make rules for the purposes of this Act.
(1)The Government shall, in addition to the rule making powers, conferred on them by any other
provisions of this Act, have power to make rules generally to carry out all or any of the purposes of
this Act.(2)In particular, and without prejudice to the generality of the foregoing power, the
Government may make rules, -(i)as to all matters under this Act, relating to electoral rolls or the
conduct of elections, not expressly provided for in this Act, including deposits to be made by
candidates standing for election and the conditions under which such deposits may be forfeited, and
the conduct of inquiries and the decision of disputes relating to electoral rolls or elections;[***]
[Omitted by Section 14 of Act No. 5 of 1995.](iii)as to the interpellation of the Sarpanch, President or
Chairperson by the members of the Gram Panchayat, [Mandal Praja Parishad] [Substituted 'Mandal
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or as the case may be of the [Zilla Praja
Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] and the moving of
resolutions at meeting of a Gram Panchayat, [Mandal Praja Parishad] [Substituted 'Mandal
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or the [Zilla Praja Parishad] [Substituted 'Zilla
Parishad' by Act No. 41 of 2006, dated 23.9.2006.];(iv)as to the delegation of any function of a Gram
Panchayat, [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.] or a [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated
23.9.2006.] respectively to the Sarpanch, President or Chairperson or any member or officer of the
Gram Panchayat, [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006,
dated 23.9.2006.] or [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated
23.9.2006.] or any employee of the State or Central Government;(v)as to the transfer of allotments
entered in the sanctioned budget of a Gram Panchayat, [Mandal Praja Parishad] [Substituted
'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or [Zilla Praja Parishad] [Substituted
'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] from one head to another;(vi)as to the
estimates of receipts and expenditure, returns, statements and reports to be submitted by Gram
Panchayat, [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.] or [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated
23.9.2006.];(vii)as to the accounts to be kept by Gram Panchayat, [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or [Zilla Praja Parishad]Andhra Pradesh Panchayat Raj Act, 1994

[Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.], the audit and publication of
such accounts and the conditions under which rate payers may appear before auditors, inspect book
and accounts, and take exceptions to items entered or omitted;(viii)as to the preparation of plans
and estimates for works and the powers of Gram Panchayat, [Mandal Praja Parishad] [Substituted
'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or [Zilla Praja Parishad] [Substituted
'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] and of servants of the State or Central
Government to accord professional or administrative sanction to estimates;(ix)as to the powers of
auditors to disallow and surcharge items, appeals against order of disallowance or surcharge and the
recovery of sums disallowed or surcharged;(x)as to the powers of auditors, inspecting and
superintending officers and officers authorised to hold inquiries to summon and examine witnesses
and to compel the production of documents and all other matters connected with audit, inspection
and superintendence;(xi)as to the conditions on which property may be acquired by a Gram
Panchayat, [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated
23.9.2006.] or [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated
23.9.2006.] or on which property vested in or belonging to a Gram Panchayat, [Mandal Praja
Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or [Zilla Praja
Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] may be transferred
by sale, mortgage, lease, exchange or otherwise;(xii)as to the conditions on which and the mode in
which contracts may be made by or on behalf of Gram Panchayat, [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or [Zilla Praja Parishad]
[Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.];(xiii)as to the assessment and
realisation of taxes under this Act and the revision of and appeals against assessment;(xiv)as to the
acceptance in lieu of any tax or other amount due to a Gram Panchayat under this Act, of any service
by way of cartage or otherwise;(xv)as to the form and contents of licences, permissions and notices
granted or issued under this Act, the manner of their issue or the method of their service, and the
modifications, suspension or cancellation thereof;(xvi)as to the powers of executive authorities to
call for information on any matter, to summon and examine witnesses, and to compel the
production of document;(xvii)as to the regulation or registration of building and the use of sites for
building;(xviii)for the determination of any claim to trees growing on public roads or other property
vesting in or belonging to Gram Panchayats or on porambokes or on lands, the use of which is
regulated by them under Section 102, and for the presumptions to be drawn in regards to the
ownership of such trees;(xix)as to the provisions of cattle sheds by the Gram Panchayat wherein
owners of cattle may stall cattle and as to the fees leviable in respect thereof;(xx)as to the disposal of
household and farmyard waste in the village, the acquisition of land by the Gram Panchayat for
laying out plots, for digging pits in which such waste may be thrown, the assignment of any of those
plots to persons in the village and the conditions subject to which such assignment may be made,
including the rent to be charged;(xxi)as to the duties to be discharged by village officers in relation
to Gram Panchayats and their executive authorities;(xxii)for regulating the sharing between local
authorities in the State, of the proceeds of any tax or income levied or obtained under this or any
other Act;(xxiii)as to the accounts to be kept by owners, occupiers and farmer, private markets and
the audit and inspection of such accounts;(xxiv)as to the manner of publication of any notification
or notices to the public under this Act;(xxv)for the use of the facsimiles of the signatures of the
executive authorities and officers of Gram Panchayat, [Mandal Praja Parishad] [Substituted 'Mandal
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or [Zilla Praja Parishad] [Substituted 'ZillaAndhra Pradesh Panchayat Raj Act, 1994

Parishad' by Act No. 41 of 2006, dated 23.9.2006.];(xxvi)regarding proceedings of Gram Panchayats
and their committees; and(xxvii)relating to assessment levy, and collection of taxes and the lodging
of moneys received by the Gram Panchayat, [Mandal Praja Parishad] [Substituted 'Mandal Parishad'
by Act No. 41 of 2006, dated 23.9.2006.] or [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by
Act No. 41 of 2006, dated 23.9.2006.] and payment of moneys from their Funds.(3)All rules made
under this Act shall be published in the Andhra Pradesh Gazette.(4)Every rule made under the Act
shall immediately after it is made, be laid before the Legislative Assembly of the State if it is in
session, and if it is not in session, in the session immediately following for a total period of fourteen
days which may be comprised in one session or in two successive sessions and if before the
expiration of the session in which it is so laid or the session immediately following the Legislative
Assembly agrees in making any modification in the rule or in the annulment of the rule, the rule
shall, from the date on which the modification or annulment is notified, have effect only in such
modified form or shall stand annulled, as the case may be, so however that any such modification or
annulment shall be without prejudice to the validity or anything previously done under that rule.
269. Penalties for breach of rules.
- A rule under this Act may provide that a breach thereof shall be punishable with fine which may
extend to fifty rupees, or in case of continuing breach with fine not exceeding five rupees for every
day during which the breach continues after conviction for the first breach.
270. Bye-laws and penalties for their breach.
(1)Subject to the provisions of this Act and of any other law and to such rules as may be prescribed, a
Gram Panchayat may, with the approval of the Commissioner, make bye-laws for carrying out any of
the purposes for which it is constituted.(2)A bye-law made by the Gram Panchayat may provide that
any person who commits a breach thereof shall be liable to pay by way of penalty such sum as may
be fixed by the Gram Panchayat not exceeding fifteen rupees, or in case of a continuing breach, not
exceeding five rupees for every day during which the breach continues after a penalty has been
levied for the breach.(3)The Government shall have power to make rules regarding the procedure
for the making of bye-laws, the publication thereof and the date on which they shall come into effect.
271. General provisions regarding penalties specified in Schedules III and IV.
(1)Whoever, -(a)contravenes any of the provisions of this Act specified in the first and second
columns of Schedule-III, or(b)contravenes any rule or order made under any of the provisions so
specified; or(c)failing to comply with any direction lawfully given to him, or any requisition lawfully
made upon him under or in pursuance of any of the said provisions, shall be punishable with fine
which may extend to the amount mentioned in that behalf in the fourth column of the said
Schedule.(2)Whoever after having been convicted of, -(a)contravening any of the provisions of this
Act specified in the first and second columns of Schedule IV; or(b)contravening any rule or order
made under any of the provisions so specified; or(c)failing to comply with any directions lawfully
given to him, or any requisition lawfully made upon him under or in pursuance of any of the said
provisions, continues to contravene the said provisions or the said rule or order, or continues to failAndhra Pradesh Panchayat Raj Act, 1994

to comply with the said direction or requisition shall be punishable for each day after the previous
date of conviction during which he continues so to offend, with fine which may extend to the
amount mentioned in that behalf in the fourth column of the said Schedule.Explanation. - The
entries in the third column of Schedules III and IV headed 'subject' are not intended as definitions
of the offences described in the provisions specified in the first and second columns thereof or even
as abstracts of those provisions, but are Inserted merely as references to the subject dealt with
therein.
271A. [ Penalty for not handling over documents, moneys etc., to the newly
elected Sarpanch or Upa-Sarpanch of a Gram Panchayat. [Inserted by Andhra
Pradesh Act No. 33 of 1998, dated 22.12.1998.]
(1)Any Sarpanch who having been the Sarpanch, Temporary Sarpanch or Upa-Sarpanch of a Gram
Panchayat fails to hand over any documents of or any moneys or other properties vested in or
belonging to, the Gram Panchayat, which are in, or have come into, his possession or control, to his
successor in office or other prescribed authority, -(i)in every case, within a period of thirty days from
the expiry of the term of office as such Sarpanch, Temporary Sarpanch or Upa-Sarpanch; and(ii)in
the case of person, who was the Upa-Sarpanch also within a period of thirty days on demand by the
Sarpanch shall be punishable with imprisonment which may extend upto six months or with fine
not exceeding one thousand rupees or with both, for every such offences.(2)Any person who is
convicted under sub-Section (1) fails to handover any documents of, or any moneys or other
properties vested in, or belonging to the Gram Panchayat, which are in or have come into, his
possession, or control to his successor in office, shall be punishable for each day after conviction
during which he continues to persist in his offence with a fine not exceeding one hundred
rupees.(3)In cases falling under sub-Sections (1) and (2), the court may, apart from ordering
conviction for the offence, order the seizure of the documents, moneys or other properties of the
Gram Panchayat from the person convicted.]
272. Recovery of amounts due as taxes.
- All costs, damages, compensation, penalties, charges, fees (other than school fees), expenses, rents
(not being rents for land and buildings demised by the Gram Panchayat), contributions and other
amounts which under this Act or any other law or rules or bye-laws made thereunder are due by any
person to the Gram Panchayat may, if there is no special provision in this Act, or the rules made
thereunder for their recovery, be demanded by a bill as provided in the rules for the recovery of
taxes made under the Act and recovered in the manner provided therein.
273. Adjudication of disputes between local authorities.
(1)When a dispute exists between a local authority and one or more other local authorities in regard
to any matter arising under the provisions of this or any other Act and the Government are of
opinion that the local authorities concerned are unable to settle it amicably among themselves, the
Government may take cognizance of the dispute; and(a)decide it themselves, or(b)refer it forAndhra Pradesh Panchayat Raj Act, 1994

enquiry and report to an arbitrator or a board of arbitrators or to a joint committee constituted for
the purpose by an order of the Government.(2)The reports referred to in clause (b) of sub-Section
(1) shall be submitted to the Government who shall decide the dispute in such manner as they may
deem fit.(3)Any decision given under clause (a) of sub-Section (1) or under sub-Section (2) may be
modified from time to time, by the Government in such manner as they deem fit, and any such
decision with the modification, if any, made therein under this sub-Section, may be cancelled at any
time by the Government.Any such decision or any modification therein or cancellation thereof shall
be binding on all the local authorities concerned and shall not be, liable to be questioned in any
court of law.(4)Where one of the local authorities concerned is a cantonment authority or the port
authority of a major port, the powers of the Government under this Section shall be exercisable only
with the concurrence of the Central Government.
274. Act to read subject to Schedules V and VI in regard to first constitution
or reconstitution etc.
(1)In regard to the first constitution of a Gram Panchayat, [Mandal Praja Parishad] [Substituted
'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or [Zilla Praja Parishad] [Substituted
'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] for a village, Mandal or District or to the
first reconstitution in accordance with the provisions of this Act of such bodies in existence at the
commencement thereof, and otherwise in first giving effect to the said provisions they shall be read
subject to the rules in Schedules V and VI.(2)The Government shall have power, by notification in
the Andhra Pradesh Gazette, to amend, add to or repeal the rules in the said Schedules.
275. Power to remove difficulties.
(1)If any difficulty arises in first giving effect to the provisions of this Act or as to the first
constitution or reconstitution of any Gram Panchayat, [Mandal Praja Parishad] [Substituted
'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or [Zilla Praja Parishad] [Substituted
'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] after the commencement of this Act, the
Government, as occasion may require, may by order published in the Andhra Pradesh Gazette, do
anything which appears to them necessary for removing the difficulty.(2)All orders made under
sub-Section (1) shall, as soon as may be after they are made, be placed on the table of Legislative
Assembly of the State and shall be subject to such modification by way of amendments or repeal as
the Legislative Assembly may make either in the same session or in the next session.
276. Repeal and savings.
(1)The following Acts are hereby repealed, namely:-(i)The Andhra Pradesh Gram Panchayats Act
1964. (Act 2 of 1964),(ii)The Andhra Pradesh Mandal Praja Parishads, Zilla Praja Parishads and
Zilla Pranalika and Abhivrudhi Sameeksha Mandals Act, 1986 (Act 31 of 1986), and(iii)The Andhra
Pradesh Local Bodies Electoral Reforms Act, 1989, (Act 28 of 1989).(2)On such repeal the
provisions of Sections 8 and 18 of the Andhra Pradesh General Clauses Act, 1981 (Act 1 of 1981) shall
apply.Andhra Pradesh Panchayat Raj Act, 1994

277. Amendment of Act 9 of 1989.
- In the Andhra Pradesh State Audit Act, 1989 (Act 9 of 1989), in Section 2, for clauses (c) and (d),
the following clause shall be substituted, namely:-"(c) a Gram Panchayat, a township, a [Mandal
Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] or a [Zilla
Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.] constituted
under the Andhra Pradesh Panchayat Raj Act, 1994."
278. Transitional provisions in regard to elections.
- The first ordinary elections to the Gram Panchayats, [Mandal Praja Parishads] [Substituted
'Mandal Parishads' by Act No. 41 of 2006, dated 23.9.2006.] and [Zilla Praja Parishad] [Substituted
'Zilla Parishads' by Act No. 41 of 2006, dated 23.9.2006.] in accordance with the provisions of this
Act shall be held [within a period not exceeding one year and six months] [Subs by Section 2 (2) of
Act No. 33 of 1995.] from the date of commencement of this Act.
I
General Powers and Functions of Panchayats(Sections 45, 161 and 192)
1. Agriculture, including agricultural extension.
2. Land improvement, implementation of land reforms, land consolidation
and soil conservation.
3. Minor irrigation, water management and watershed development.
4. Animal husbandry, dairying and poultry.
5. Fisheries
6. Social forestry and farm forestry.
7. Minor forest produce.
8. Small scale industries, including food processing industries.
9. Khadi, village and cottage industries.Andhra Pradesh Panchayat Raj Act, 1994

10. Rural housing.
11. Drinking water.
12. Fuel and fodder.
13. Roads, culverts, bridges, ferries, waterways and other means of
communication.
14. Rural electrification, including distribution of electricity.
15. Non-conventional energy sources.
16. Poverty alleviation programme.
17. Education, including primary and secondary schools.
18. Technical Training and vocational education.
19. Adult and non-formal education.
20. Libraries.
21. Cultural activities.
22. Markets and fairs.
23. Health and sanitation, including hospitals, primary health centres and
dispensaries.
24. Family Welfare.
25. Women and child development.
26. Social welfare, including welfare of the handicapped and mentally
retarded.Andhra Pradesh Panchayat Raj Act, 1994

27. Welfare of the weaker Sections, and in particular, of Scheduled Castes
and the Scheduled Tribes.
28. Public Distribution System.
29. Maintenance of community assets.
II
Powers and Functions of the [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41
of 2006, dated 23.9.2006.](Sections 45, 161 and 192)
1. Community Development. - The execution of all programmes under
Community Development in association with panchayats, co-operative
societies, voluntary organisations and the people.
2. Agriculture. - The doing of everything necessary to step up agriculture
Production and in particular, -
(i)multiplication and distribution of improved seeds;(ii)distribution of fertilizers;(iii)popularisation
of improved techniques, methods and practices and improved implements;(iv)achieving
self-sufficiency in green manure and composting of farmyard manure;(v)encouraging fruit and
vegetable cultivation;(vi)reclamation of land and conservation of soil;(vii)providing credit for
agricultural purposes;(viii)propagating and assisting in plant protection methods;(ix)laying out
demonstration plots and working out better methods of farm managements;(x)bringing more
acreage under irrigation by renovating and sinking wells, repairing and digging private tanks and
maintaining Government minor irrigation sources and supply channels;(xi)utilising more power for
agricultural purposes;(xii)exploiting underground water sources by sinking wells, filter points and
tube wells;(xiii)tree planting;(xiv)growing of village forests.
3. Animal Husbandry and Fisheries.
(i)upgrading local stock by introducing pedigree breeding bulls and castrating scrub
bulls;(ii)introducing improved breeds of cattle, sheep, pigs and poultry;(iii)controlling contagious
diseases by systematic protection;(iv)introducing improved fodders and feeds;(v)establishing and
maintaining of artificial insemination centres, first aid centres and minor veterinary
dispensaries;(vi)educating the people about the importance of better cattle for both milk and
draught.Andhra Pradesh Panchayat Raj Act, 1994

4. [ Health and Rural Sanitation.] [Subs by Section 15 of Act No. 5 of 1995.]
(i)Expanding existing medical and health services and bringing them within the reach of
people.(ii)Establishing and maintaining Primary Health Centres and Maternity
Centres.(iii)Providing protected drinking water facilities.(iv)Ensuring systematic
vaccination.(v)Controlling epidemics.(vi)Providing drains and soakage pits for village and house
drainage.(vii)Encouraging the use of sanitary type of latrines and utilising human
waste.(viii)Popularising of smokeless chullas.(ix)Supervising the work in Government
hospitals.(x)Enlisting people's participation for the improvement of such hospitals.(xi)Securing the
co-operation of the people and the panchayats during epidemics.(xii)Carrying out environmental
sanitation campaigns and educating the public in (a) nutrition, (b) maternity and child health (c)
communicable diseases and (d) family planning and the like.(xiii)Implementing health programme
subject to the technical control of concerned district officers.
5. Education. - Maintenance and expansion to Elementary and Basic Schools
and in particular, -
(i)management of Government and taken over Aided Elementary and Higher Elementary
Schools;(ii)establishment of Adult Education Centres and Adult Literacy Centres;(iii)provision and
improvement of accommodation for schools with people's participation;(iv)conversion of existing
Elementary Schools into Basic Schools; and(v)taking of such action as may be necessary for the
promotion of education for all children until they complete the age of fourteen years.
6. Social Education. - The creation of a new outlook among the people and
making them self-reliant, hard working and responsive to community action
and in particular, -
(i)establishment of information community and recreation centre;(ii)establishment of Youth
Organisation, Mahila Mandals, Farmer clubs and the like;(iii)establishment and popularisation of
libraries;(iv)organisation of watch and ward;(v)encouragement of physical and cultural
activities;(vi)organisation of voluntary sanitary squads;(vii)training and utilisation of the services of
Gram Sahayaks.
7. Communications.
(i)Formation and maintenance of inter village roads;(ii)Rendering such assistance as may be
necessary for the formation and maintenance of Village Roads which serve as feeders.
8. Co-operation. - The Securing of economic development along democratic
lines by the application of co-operation in its infinitely varying forms and in
particular, -Andhra Pradesh Panchayat Raj Act, 1994

(i)establishment of co-operative credit, industrial, irrigation, farming and multipurpose societies in
order to serve the maximum number of families.(ii)encouragement of thirft and small savings.
9. Cottage Industries. - Development of cottage, village and small scale
industries in order to provide better employment opportunities and thereby
raise the standard of living and in particular, -
(i)the establishment and maintenance of production-cum-training centres;(ii)the improvement of
the skills of artisans and craftsmen;(iii)the popularisation of improved implements;
and(iv)implementation of schemes for the development of cottage, village and small scale industries
financed by the Khadi and Village Industries Commission and the All India Boards.
10. Women Welfare. - The implementation of schemes specially designed for
Welfare of women and children and in particular the establishment of Women
and Child Welfare Centres, LIteracy Centres, Crafts and Dress Making
Centres and like.
11. Social Welfare.
(i)The management of hostels subsidised by Government for the benefit of Scheduled Tribes,
Scheduled Castes and Backward Classes;(ii)The implementation of Rural Housing Schemes;(iii)The
maintenance of diseased beggers and control of vagrancy;(iv)The strengthening of Voluntary Social
Welfare Organisations and Coordinating their activities;(v)The propagation of temperance and
prohibition; and(vi)The removal of untouchability.
12. Emergency Relief. - Provision of emergency relief through voluntary
efforts in case of distress owing to fires, floods, epidemics and other wide
spread calamities.
13. Collection of Statistics. - Collection and compilation of such statistics as
may be found necessary either by the Mandala Parishad, the [Zilla Praja
Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.]
or the Government.
14. Self-Help Programme. - Formulation and execution of suitable
programmes for stepping-up production and for raising the incomes and
standards of living for the improvement of sanitation and for the provision of
amenities for the people.Andhra Pradesh Panchayat Raj Act, 1994

15. Trusts. - Management of trusts for the furtherence of any purpose to
which the funds of the [Mandal Praja Parishad] [Substituted 'Mandal
Parishad' by Act No. 41 of 2006, dated 23.9.2006.] may be applied.
III
Ordinary Penalties(Section 271)
SectionSub-Section
or clauseSubjectFine which
may be
imposed
(1) (2) (3) (4)
81 (2)Disobeying notice prohibiting use of water towhich public
have accessFifty rupees
82 (a) Bathing etc., in places set apart for drinkingpurposes Fifty rupees
82 (b)Depositing any offensive etc., matter in placesset apart for
drinking purposesFifty rupees
82 (c)Washing clothes in places set apart fordrinking, bathing or
washing clothesFifty rupees
82 (d)Washing animals etc., in places set apart fordrinking,
bathing or washing clothes.Fifty rupees
82 (e)Allowing water from a sink, sewer etc., intoplaces set apart
for drinking, bathing or washing clothesFifty rupees
85 (1) Failure to register any place for the disposalof the deadOne hundred
rupees
86 (1)Opening etc., or using any place for thedisposal of the dead
without a licenceOne hundred
rupees
89 ...Burying, burning etc., of corpse within twohundred metres of
dwelling place or source of drinking watersupplyOne hundred
rupees
90 ...Failure to give information of burials orburning in a burial
ground or burning groundTwenty
rupees
91 (3)Buying or burning or otherwise disposing of acorpse in a
prohibited placeOne hundred
rupees
93 ... Allowing filth to flow in public road etc.,Twenty
rupees
94 (1) Failure to execute the work as required by thenotice Fifty rupees
95 (1) Quarrying near a public road, etc., without alicence Fifty rupees
96 ...Unlawful building of wall or erecting of fence,etc., in or over
public roadOne hundred
rupees
97 ...Andhra Pradesh Panchayat Raj Act, 1994

Allowing doors, ground floor windows, etc., toopen outwards
or without licence or contrary to noticeTwenty
rupees
98 (1) Failure to remove or alter encroachmentTwo hundred
rupees
100 (1)Unlawful construction of building over a drainon ground
leveled etc., by rubbishTwo hundred
rupees
100 (2)Failure to obey requisition to demolish abuilding constructed
without permission or contrary to the termsof permissionTwo hundred
rupees
101 (1) Unlawful making of hole or placing obstructionin public road Fifty rupees
101 (2) Failure to fence, enclose etc., hole orobstruction Fifty rupees
102 (1)Planting of trees without permission on anypublic road or
other property vested in a Gram PanchayatTwo hundred
rupees
102 (2)Felling etc., without permission of trees,growing on public
road or other property vested in a GramPanchayat or on a
poramboke or land the use of which is regulatedby it under
Section 102Two hundred
rupees
103 (2)Failure to remove any building etc., on landvested in Gram
PanchayatTwo hundred
rupees
105 (1)Opening or keeping open a private market incontravention of
Section 105Five hundred
rupees
108 ...Failure to obey directions to constructapproaches, etc., for a
private market or to roof etc.One hundred
rupees
110 ...Sale or exposure for sale in public or privatemarket of any
animal or articles without permissionTwenty
rupees
111. ....Sale etc., of articles in public roads or placesafter prohibition
or without licence or contrary to regulationsTen rupees
115. (b)Using any public place or roadside as a landingor halting
place or as a cart-stand within prohibited distanceFifty rupees
116 (1)Opening a new private cart-stand or continuingto keep open
a private cart-stand without licence or contrary tolicenceTwo hundred
rupees
118 (a)Slaughtering, cutting up or skinning etc.,cattle etc., outside
slaughter house.Two hundred
rupees
118 (b)Slaughtering etc., any cattle etc., withoutlicence or contrary
to licenceTwenty
rupees
119. ...Using a place for any of the purposes specifiedin Schedule III
without licence or contrary to licenceOne hundred
rupees
120. ... Unlawful erection of factory, workshopOne thousand
rupees
122. ... Disobedience of order regarding abatement ofnuisanceOne hundred
rupeesAndhra Pradesh Panchayat Raj Act, 1994

126. (2) Unlawful defacement etc., of numbers assigned tobuildings Five rupees
126. (3) Failure to replace number when required to do soTwenty
rupees
127. (7) Failure to produce licence on request Five rupees
144. ...Obstructing a person in the use or enjoyment ofa public
road, market, well, tank, etcOne hundred
rupees
IV
Penalties For Continuing Breaches(Section 271)
SectionSub-Section or
clauseSubjectFine which may
be imposed
(1) (2) (3) (4)
81 (2)Disobeying notice prohibiting use of water towhich
public have accessTen rupees
82 (e)Allowing water from a sink, sewer etc., intoplaces set
apart for drinking, bathing or washing clothesTen rupees
86 (1)Using any place for the disposal of the deadwithout a
licenceTwenty rupees for
each occasion
93 ... Allowing filth to flow in public road etc., Ten rupees
94 (1) Failure to execute the work as required by thenotice Ten rupees
95 (1) Quarrying near a public road, etc., without alicence Ten rupees
96 ...Unlawful building of wall or erecting of fence,etc., in or
over public roadTwenty rupees
97 ...Allowing doors, ground floor windows, etc., toopen
outwards or without licence or contrary to noticeTen rupees
98 (1) Failure to remove or alter encroachment Ten rupees
100 (1)Unlawful construction of building over a drainor on
ground levelled etc., by rubbishFifty rupees
100 (2)Failure to obey requisition to demolish abuilding
constructed without permission or contrary to the
termsof permissionFifty rupees
101 (1)Unlawful making of hole or placing obstructionin public
roadTen rupees
103 (2)Failure to remove any building etc., on landvested in
Gram Panchayat.Fifty rupees
105 (1)Opening or keeping open a private market
incontravention of Section 105One hundred
rupees
108 ...Failure to obey directions to constructapproaches, etc.,
for a private market or to roof etc.Ten rupeesAndhra Pradesh Panchayat Raj Act, 1994

110 ...Sale or exposure for sale in public or privatemarket of
any animal or articles without permissionTen rupees
116 (1)Keeping open a private cart-stand withoutlicence or
contrary to licenceTwenty rupees
119 ...Using a place for any of the purposes specifiedin
Schedule III without licence or contrary to licenceTwenty rupees
120 ...Unlawful erection of factory, work-shop Onehundred
rupees 
122 ... Disobedience of order regarding abatement ofnuisance Fifty rupees
V
Transitional Provisions (Gram Panchayats)(Section 274)
1. Definitions. - In these rules, unless the context otherwise requires, -
(a)'Old Panchayats Act' means the Andhra Pradesh Gram Panchayat Act, 1964;(b)'Panchayat' means
a panchayat constituted under the old Panchayats Act;(c)'Member' means a member of a panchayat
constituted under the Old Panchayats Act;(d)'Sarpanch' means a Sarpanch of a Gram Panchayat
constituted under the Old Panchayats Act.
2. Existing villages to be deemed to be villages for purposes of this Act. - (1)
Every local area which, at the commencement of this Act, is a village under
the old Panchayats Act shall be deemed to have been declared to be a village
under this Act.
(2)Every Gram Panchayat in existence at the commencement of this Act shall be deemed to be a
Gram Panchayat constituted under this Act.
3. Total number of members of Gram Panchayat. - Notwithstanding anything
contained in this Act, the total number of members of a Gram Panchayat
fixed under the old Panchayats Act, shall be deemed to be the total number
of members of the Gram Panchayat as deemed to have been constituted
under this Act by virtue of sub-rule (2) of rule 2 until their number is altered
by the Commissioner.
4. Term of office of existing Sarpanches and members. - (1) The Sarpanches
and members of a Gram Panchayat holding office at the commencement of
this Act shall, subject to the provisions of Sections 18 and 20, continue to
hold such office upto and inclusive of the date fixed by the Government or
upto the date on which special officers who may be appointed by theAndhra Pradesh Panchayat Raj Act, 1994

Commissioner assume office whichever is early.
(2)Any vacancy in the office of the Sarpanch, the Upa-Sarpanch or a member of a Gram Panchayat
at the commencement of this Act or which may occur thereafter shall not be filled until the next
ordinary elections.
5. First ordinary election. - The Andhra Pradesh Election Commissioner for
Local Bodies shall cause the first ordinary election under this Act to a Gram
Panchayat and the first meeting of the Gram Panchayat under sub-Section (1)
of Section 13 after such election, to be held on any day before the date
appointed by the said Commissioner.
6. Reconstitution of Panchayats dissolved or superseded before the
commencement of this Act. - Any Panchayat dissolved or superseded under
the old Panchayats Act and awaiting reconstitution at the commencement of
this Act, shall be reconstituted in accordance with the provisions of this Act.
7. Constitution of Panchayats for villages notified before the commencement
of this Act. - Where, before the commencement of this Act, a village was
notified under the old Panchayats Act, for constituting a panchayat but no
panchayat was constituted, the special officer appointed, if any, therefor,
shall be deemed to have been appointed under this Act and the provisions of
Section 143 shall apply to such a case. Where no such special officer was
appointed, a special officer shall be appointed for such a village under this
Act as if it has been notified under this Act on the date of the commencement
of this Act.
8. Executive Officers to be deemed to be Executive Officers appointed under
this Act. - The Executive Officers of the Gram Panchayats which are deemed
to be Gram Panchayats from the date of commencement of this Act and
holding office as such on the said date, shall be deemed to have been
appointed under this Act.
9. Devolution of property, rights and liabilities. - (1) All property, all rights of
whatever kind, used, enjoyed or possessed by, and all interests of whatever
kind, owned by or vested in, or held in trust, by or for any panchayat, as well
as all liabilities legally subsisting against it, shall, on and from the date of
commencement of this Act and subject to such directions as the GovernmentAndhra Pradesh Panchayat Raj Act, 1994

may, by general or special order give in this behalf, pass to such Gram
Panchayat as deemed to be constituted under this Act.
(2)All arrears of taxes or other payments by way of composition for a tax or due for expenses or
compensation or otherwise due to a panchayat at the commencement of this Act may be recovered
as if they had accrued under this Act.(3)All proceedings taken by or against any panchayat or other
authority or any person under the old Panchayats Act in so far as they are not inconsistent with this
Act, be continued by or against such Gram Panchayat, authority or person under this Act.
10. Continuance of existing taxes. - Any tax, cess, fee or duty which was
being lawfully levied by or on behalf of any panchayat at the commencement
of this Act under any law, shall continue to be levied by or on behalf of the
Gram Panchayat at the rates fixed and in pursuance of the assessment made
by or under such law for the year in which this Act was brought into force
and in the subsequent years also until the Government, by general or special
order, otherwise direct, or assessment is made by or under this Act,
whichever is earlier.
11. Action taken under old Panchayats Act to continue. - Any action taken
under the old Panchayats Act by any authority, before the commencement of
this Act shall, unless inconsistent with this Act, be deemed to have been
taken by the authority competent to take such action under this Act, unless
and until superseded by action taken by such authority, whether it be the
same as the authority competent to take such action under the old
Panchayats Act or not.
12. Removal of difficulty. - If any difficulty arises in giving effect to the
provisions of these rules, the Government, as occasion may require, may
after previous publication, by notification in the Andhra Pradesh Gazette, do
anything which appears to them necessary for removing the difficulty.
VI
Transitional Provisions ([Mandal Praja Parishads] [Substituted 'Mandal Parishads' by Act No. 41 of
2006, dated 23.9.2006.] and [Zilla Praja Parishad] [Substituted 'Zilla Parishads' by Act No. 41 of
2006, dated 23.9.2006.])(Section 274)Abolition of Mandala Praja Parishads and Devolution of
Assets and Liabilities:(1)With effect on and from the constitution of a [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] under this Act, the Mandal
Praja Parishad or Parishads in the Mandal for which the Mandal Panchayat is constituted, shall
stand abolished.(2)On such abolition of a Mandal Praja Parishad under sub-rule (1), (Act 31 ofAndhra Pradesh Panchayat Raj Act, 1994

1986),(a)the Collector may pass such orders as he deems fit as to the devolution on the [Mandal
Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] comprised
in the area of such Mandal of the assets or institutions belonging to such Mandal Praja Parishad or
Mandal Praja Parishads or as to the disposal otherwise of such assets;(b)all rights vesting in a
Mandal Praja Parishad and all liabilities against it shall devolve on the [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] concerned;(c)all contracts
made by or on behalf of a Mandal Praja Parishad prior to its abolition and subsisting on the day of
such abolition may be transferred by the Collector to the [Mandal Praja Parishad] [Substituted
'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] concerned.(3)In respect of all arrears of
taxes or other payments by way of composition for a tax, or due for expenses or compensation, or
otherwise due to the said Mandal Praja Parishad on such abolition, it shall be competent for the
Collector to pass such orders as he may deem fit for their recovery by the [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.] as if they had accrued to it
and had become due, under the provisions of this Act.(4)All taxes, fees and duties, which
immediately before such abolition were being levied by the said Mandal Praja Parishad shall be
deemed to have been levied by the relevant [Mandal Praja Parishad] [Substituted 'Mandal Parishad'
by Act No. 41 of 2006, dated 23.9.2006.] under the provisions of this Act, and shall continue to be in
force accordingly until such taxes, fees and duties are revised, cancelled or superseded by anything
done or any action taken under this Act.(5)All proceedings taken by or against the Mandal Praja
Parishad or authority or any person under the Andhra Pradesh Mandal Praja Parishads, Zilla Praja
Parishads and Zilla Pranalika and Abhivrudhi Sameeksha Mandals Act, 1986 (Act 31 of 1986)
(hereinafter called the Mandals Act) may be continued by or against the [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.], authority or person as if
the said proceedings had been started under the provisions of this Act.(6)Any action taken under the
Mandals Act by any authority before such abolition shall be deemed to have been taken by the
authority competent to take such action under this Act as if this Act had then been in force.(7)With
effect on and from the constitution of [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No.
41 of 2006, dated 23.9.2006.], for any district under this Act, the Zilla Praja Parishad constituted for
such district under sub-Section (1) of Section 43 of the Mandals Act shall stand abolished.(8)All
assets and rights vesting in a Zilla Praja Parishad at the time of its abolition under
sub-Section(7)and all liabilities against it at such abolition under the Mandals Act or any other law
for the time being in force, shall devolve on the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by
Act No. 41 of 2006, dated 23.9.2006.], constituted under this Act.(9)Notwithstanding anything in
this Act, every officer or employee who immediately before such abolition was in the service of the
Zilla Praja Parishad shall be deemed to be an officer or employee of the [Zilla Praja Parishad]
[Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated 23.9.2006.], under this Act and every
officer or employee who, immediately before the abolition of the Mandal Praja Parishad was in the
service of the Mandal Praja Parishad shall be the employee of one of the [Mandal Praja Parishads]
[Substituted 'Mandal Parishads' by Act No. 41 of 2006, dated 23.9.2006.], as may be ordered by the
District Collector and it shall also be competent for the District Collector to transfer such officer or
employee to any other service as may be directed by the Government:Provided that, -(i)the terms
and conditions applicable to such officers and employees consequent on their absorption in the
service of the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated
23.9.2006.], or [Mandal Praja Parishad] [Substituted 'Mandal Parishad' by Act No. 41 of 2006,Andhra Pradesh Panchayat Raj Act, 1994

dated 23.9.2006.], shall not be less favourable than those applicable to such employees immediately
before such abolition as respects pay and allowances, leave, pension, gratuity, provident fund and
age of superannuation; and(ii)the services rendered by any such officer or other employee under the
Zilla Praja Parishad or Mandal Praja Parishad upto such abolition shall be deemed to be service
under the [Zilla Praja Parishad] [Substituted 'Zilla Parishad' by Act No. 41 of 2006, dated
23.9.2006.], constituted under this Act, or as the case may be, of the [Mandal Praja Parishad]
[Substituted 'Mandal Parishad' by Act No. 41 of 2006, dated 23.9.2006.], and he shall be entitled to
count that service for the purpose of increments, leave, pension, or provident fund and
gratuity.(10)"The Special Officers appointed under Section 76 of the Andhra Pradesh Mandal Praja
Parishads, Zilla Praja Parishads and Zilla Pranalika and Abhivrudhi Sameeksha Mandals Act, 1986
shall, notwithstanding the repeal of the said Act continue to hold office and continue to exercise the
same powers and perform the same functions as they were exercising or performing immediately
before the commencement of this Act, until the first ordinary elections to the [Mandal Praja
Parishads] [Substituted 'Mandal Parishads' by Act No. 41 of 2006, dated 23.9.2006.] and [Zilla
Praja Parishad] [Substituted 'Zilla Parishads' by Act No. 41 of 2006, dated 23.9.2006.] in
accordance with the provisions of this Act are held and the newly elected members and office
bearers thereof assume office."Andhra Pradesh Panchayat Raj Act, 1994

