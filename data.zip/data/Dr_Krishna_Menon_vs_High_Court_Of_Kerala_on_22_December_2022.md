Dr.Krishna Menon vs High Court Of Kerala on 22 December,
2022
Author: A.Muhamed Mustaque
Bench: A.Muhamed Mustaque
           IN THE HIGH COURT OF KERALA AT ERNAKULAM
                            PRESENT
         THE HONOURABLE MR. JUSTICE A.MUHAMED MUSTAQUE
                               &
        THE HONOURABLE MRS. JUSTICE SHOBA ANNAMMA EAPEN
THURSDAY, THE 22ND DAY OF DECEMBER 2022 / 1ST POUSHA, 1944
                    WP(C) NO. 26500 OF 2020
PETITIONER/S:
           VYSAKH K.G., AGED 31 YEARS, S/O.GOKULDAS,
           KONDRAPPASSERY HOUSE, KUNDALIYOOR, P.O.
           ENGANDIYOOR, THRISSUR DISTRICT, PIN 680 616
           BY ADVS.
           T.C.GOVINDASWAMY
           SMT.KALA T.GOPI
           SRI.B.NAMADEVA PRABHU
           SRI.R.ANEESH
RESPONDENT/S:
    1      UNION OF INDIA
           REPRESENTED BY THE SECRETARY TO THE GOVERNMENT OF
           INDIA, MINISTRY OF INFORMATION AND TECHNOLOGY,
           NEW DELHI - 110 001.
    2      THE REGISTRAR GENERAL
           HONBLE HIGH COURT OF KERALA, ERNAKULAM.
    3      THE WEBMASTER,
           WEBMASTER@INDIANKANOON.COM
    4      GOOGLE INDIA PVT.LTD.NO.3
           RMZ INFINITY - TOWER E OLD MADRAS ROAD, 3RD, 4TH
           AND 5TH FLOORS, BANGALORE - 560 016.
           WP(C) NO. 26500 OF 2020
                                    -2-
     5
          ADDL. R5: GOOGLE LLC ( A LIMITED LIABILITY CO.),
          1600, AMPHIETHEATRE, PARKWAY, MOUNTAIN VIEW, CA
          94043, USA.
          ADDL. R5 IS SUO MOTU IMPLEADED AS PER ORDER DATED
          01/04/2022 IN WPC.26500/2020.
          BY ADVS.Dr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

          SHRI B.G.HARINDRANATH
          SHRI SANTHOSH MATHEW
          SMT. RIJI RAJENDRAN
          SHRI C.M.ANDREWS
          SHRI ARUN THOMAS
          SHRI JENNIS STEPHEN
          SMT.KARTHIKA MARIA
          SHRI ANIL SEBASTIAN PULICKEL
          SHRI JAISY ELZA JOE
          SHRI ABI BENNY AREECKAL
          SMT.VRINDA BHANDARI
          SHRI ABHINAV SEKHRI
          SHRI TANMAY SINGH
          SHRI KRISHNESH BAPAT
          SHRI MISHRA ANANDITA VIPINKANT
          SHRI MANU S., ASG OF INDIA
          SMT. MITHA SUDHINDRAN
          SHRI HARISH ABRAHAM
          SHRI ADITYA VIKRAM BHAT
          SHRI AMITH KRISHNAN H.
     THIS WRIT PETITION (CIVIL) HAVING BEEN FINALLY HEARD
ON   6/10/2022,ALONG   WITH   WP(C).6687/2017   AND   CONNECTED
CASES,   THIS COURT ON 22.12.2022 DELIVERED THE FOLLOWING:
            IN THE HIGH COURT OF KERALA AT ERNAKULAM
                            PRESENT
         THE HONOURABLE MR. JUSTICE A.MUHAMED MUSTAQUE
                               &
        THE HONOURABLE MRS. JUSTICE SHOBA ANNAMMA EAPEN
THURSDAY, THE 22ND DAY OF DECEMBER 2022 / 1ST POUSHA, 1944
                    WP(C) NO. 6687 OF 2017
PETITIONER/S:
           XXXXX XXXXX XXXXX
           BY ADVS.
           SRI.M.J.THOMAS
           SRI.ADARSH MATHEW
           SRI.VIPIN P.VARGHESE
           SMT. DHANYA T MALLAR
           SRI.DILJITH K.MANOHAR
RESPONDENT/S:
    1      UNION OF INDIA
           REPRESENTED BY SECRETARY BY GOVERNMENT, MINISTRY
           OF COMMUNICATION AND IT DEPARTMENT OF ELECTRONIC
           AND INFORMATION TECHNOLOGY, ELECTRONICS NIKETAN,
           6, CGO COMPLEX, LODHI ROAD, NEW DELHI - 110 003.
    2      GOOGLE INC,Dr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

           1600, AMPHIETHEATRE PARKWAY, MOUNTAIN VIEW, CA
           94043, USA REPRESENTED BY ITS MANAGING DIRECTOR.
    3      GOOGLE INDIA (PVT) LTD. NO.3,
           RM2 INFINITY TOWER E OLD MADRAS ROAD, 4TH AND 5TH
           FLOOR, BANGALORE - 560 016.
    4      ADDL.R4. THE REGISTRAR GENERAL,
           HIGH COURT OF KERALA, HIGH COURT ROAD, ERNAKULAM,
           KERALA-682 031.
           IS IMPLEADED AS PER ORDER DATED 29-01-2020 IN IA
           3/19 IN WP(C)
    5      ADDL. R5: GOOGLE LLC (A LIMITED LIABILITY CO.),
           1600, AMPHIETHEATRE PARKWAY, MOUNTAIN VIEW, CA
           94043, USA.
           WP(C) NO. 6687 OF 2017
                                    -2-
          ADDL. R5 IS SUO MOTU IMPLEADED AS PER THE ORDER
          DATED 01/04/2022 IN WPC.6687/2017.
          BY ADVS.
          SRI.C.M.ANDREWS
          SRI.SANTHOSH MATHEW
          SHRI.B.G.HARINDRANATH
          SRI.ADITYA VIKRAM BHAT
          SRI.ANIND THOMAS
          ASSISTANT SOLICITOR GENERAL
          SRI MANU S., DSG OF INDIA
          SRI.SUVIN R.MENON, CGC
      THIS WRIT PETITION (CIVIL) HAVING BEEN FINALLY HEARD
ON   6/10/2022,ALONG    WITH   WP(C).2604/2021,   7642/2020   AND
CONNECTED CASES,       THIS COURT ON 22.12.2022 DELIVERED THE
FOLLOWING:
            IN THE HIGH COURT OF KERALA AT ERNAKULAM
                            PRESENT
         THE HONOURABLE MR. JUSTICE A.MUHAMED MUSTAQUE
                                &
        THE HONOURABLE MRS. JUSTICE SHOBA ANNAMMA EAPEN
THURSDAY, THE 22ND DAY OF DECEMBER 2022 / 1ST POUSHA, 1944
                    WP(C) NO. 20387 OF 2018
PETITIONER/S:
           VINU JOHN ALEXANDER
           AGED 26 YEARS
           S/O.ALEXANDER, AGED 26 YEARS,PUTHANPURATH VEEDU,
           AADARSH NAGAR,HOUSE NO.71, PATTOM
           VILLAGE,THIRUVANANTHAPURAM DISTRICT.
           BY ADVS.
           SRI.C.A.CHACKO
           SMT.C.M.CHARISMADr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

           SMT.MEGHA K.XAVIER
           SRI.P.RAHIM
RESPONDENT/S:
    1      UNION OF INDIA
           REPRESENTED BY SECRETARY TO GOVERNMENT,MINISTRY
           OF TELECOMMUNICATIONS, NEW DELHI-110 001.
    2      STATE OF KERALA
           REPRESENTED BY SECRETARY TO GOVERNMENT,DEPARTMENT
           OF ELECTRONICS AND INFORMATION
           TECHNOLOGY,SECRETARIAT, THIRUVANANTHAPURAM-695
           001.
    3      HIGH COURT OF KERALA
           REPRESENTED BY ITS REGISTRAR GENERAL,HIGH COURT
           ROAD, ERNAKULAM-682 031.
    4      NATIONAL INFORMATICS CENTRENIC
           REPRESENTED BY ITS AUTHORIZED SIGNATORY,CDAC
           BUILDINGS, KELTRON COMPOUND,VELLAYAMBALAM,
           THIRUVANANTHAPURAM-695 031.
    5      INDIAN KANOON
           POST BOX NO.3804, BANGALURU,KARNATAKA, PIN-560
           038, REPRESENTED BY ITS CHIEF EXECUTIVE OFFICER.
           WP(C) NO. 20387 OF 2018
                                     -2-
     6    GOOGLE LLC ( A LIMITED LIABILITY CO.)
          1600, AMPLIE THEATRE ,PARKWAY, MOUNTAIN VIEW, CA
          94043, USA.
          ADDL.R6 SUO MOTU IMPLEADED AS PER ORDER DATED
          4/4/2022 IN WPC 20387/2018.
          BY ADVS.
          SRI.M.L.SURESH KUMAR, CGC
          SANTHOSH MATHEW
          SRI.B.UNNIKRISHNA KAIMAL
          ARUN THOMAS
          JENNIS STEPHEN
          KARTHIKA MARIA
          VRINDA BHANDARI
          ABHINAV SEKHRI
          TANMAY SINGH
          KRISHNESH BAPAT
          MISHRA ANANDITA VIPINKANT
          SHRI S.KANNAN SR.GP
          ASSISTANT SOLICITOR GENERAL
          SRI MANU S., DSG OF INDIA
          SRI.SUVIN R.MENON, CGCDr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

      THIS WRIT PETITION (CIVIL) HAVING BEEN FINALLY HEARD
ON   6/10/2022,   ALONG   WITH   WP(C).6687/2017   AND   CONNECTED
CASES,   THIS COURT ON 22.12.2022 DELIVERED THE FOLLOWING:
            IN THE HIGH COURT OF KERALA AT ERNAKULAM
                             PRESENT
         THE HONOURABLE MR. JUSTICE A.MUHAMED MUSTAQUE
                                &
        THE HONOURABLE MRS. JUSTICE SHOBA ANNAMMA EAPEN
THURSDAY, THE 22ND DAY OF DECEMBER 2022 / 1ST POUSHA, 1944
                    WP(C) NO. 7642 OF 2020
PETITIONER/S:
           DR.KRISHNA MOHAN
           AGED 60 YEARS
           S/O. DR. P.G. MENON, SASTHARAM, RAMANATHAPURAM,
           PALAKKAD DISTRICT 678 001.
           BY ADVS.
           JACOB SEBASTIAN
           SRI.K.V.WINSTON
           SMT.ANU JACOB
RESPONDENT/S:
    1      HIGH COURT OF KERALA
           HIGH COURT ROAD, MARINE DRIVE, KOCHI 682 031,
           REPRESENTED BY ITS REGISTRAR.
    2      UNION OF INDIA,
           REPRESENTED BY ITS SECRETARY TO GOVERNMENT,
           MINISTRY OF TELECOMMUNICATIONS, NEW DELHI 110
           001.
    3      INDIAN KANOON,
           P.O. BOX NO. 3804, BENGALURU, KARNATAKA, 560 038,
           REPRESENTED BY ITS CHIEF EXECUTIVE OFFICER,
           SUSHANT SINHA.
    4      GOOGLE INDIA PVT.LTD.,
           HEAD OFFICE AT BLOCK-1, DIVYASREE OMEGA, SURVERY
           NO. 13, KONDAPUR VILLAGE, HYDERABAD, ANDHRA
           PRADESH 500 032, REPRESENTED BY ITS CHIEF
           EXECUTIVE OFFICER.
    5      STATE OF KERALA,
           REPRESENTED BY ITS SECRETARY TO GOVERNMENT,
           DEPARTMENT OF ELECTRONICS AND INFORMATION
           TECHNOLOGY, SECRETARIAL, THIRUVANANTHAPURAM 695
           001.
     WP(C) NO. 7642 OF 2020
                              -2-
6   NATIONAL INFORMATICS CENTRE,
    CDAC BUILDINGS, KELTRON COMPOUND VELLAYAMBALAM,
    MANAVEEYAM ROAD, NANDAVANAM, VELLAYAMBALAM,
    THIRUVANANTHAPURAM 695 033, REP. BY ITS DEPUTY
    DIRECTOR, GENERAL.Dr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

7   YAHOO INDIA PVT.LTD.,
    UNIT NO. 1261, 6TH FLOOR, BUILDING NO 12,
    SOLITTARE CORPORATE PARK NO. 167, GURU
    HARGOVINDJI MARG, ANDHERI GHATKOPAR LINK ROAD,
    ANDHERI EAST, MUMBAI 400 093, REPRESENTED BY ITS
    CHIEF EXECUTIVE OFFICER.
8   ADDL. R8: GOOGLE LLC ( A LIMITED LIABILITY CO.),
    1600, AMPHIETHEATRE, PARKWAY, MOUNTAIN VIEW, CA
    94043, USA.
    ADDL. R8 SUO MOTU IMPLEADED AS PER ORDER DATED
    01/04/2022 IN WPC.7642/2020.
    BY ADVS.
    B.G.HARINDRANATH
    SANTHOSH MATHEW
    SRI.RIJI RAJENDRAN
    HARISH ABRAHAM
    ARUN THOMAS
    JENNIS STEPHEN
    KARTHIKA MARIA
    ANIL SEBASTIAN PULICKEL
    JAISY ELZA JOE
    ABI BENNY AREECKAL
    VRINDA BHANDARI
    ABHINAV SEKHRI
    TANMAY SINGH
    KRISHNESH BAPAT
    MISHRA ANANDITA VIPINKANT
    AMITH KRISHNAN H.
    C.M.ANDREWS
    ADITYA VIKRAM BHAT
    SHRI S.GOPINATHAN SR.GP
    ASSISTANT SOLICITOR GENERAL
    SRI MANU S., DSG OF INDIA
    SRI.SUVIN R.MENON, CGC
 WP(C) NO. 7642 OF 2020
                                 -2-
      THIS WRIT PETITION (CIVIL) HAVING BEEN FINALLY HEARD
ON   6/10/2022,   ALONG   WITH   WP(C).6687/2017   AND   CONNECTED
CASES,   THIS COURT ON 22.12.2022 DELIVERED THE FOLLOWING:
            IN THE HIGH COURT OF KERALA AT ERNAKULAM
                            PRESENT
         THE HONOURABLE MR. JUSTICE A.MUHAMED MUSTAQUE
                               &
        THE HONOURABLE MRS. JUSTICE SHOBA ANNAMMA EAPEN
THURSDAY, THE 22ND DAY OF DECEMBER 2022 / 1ST POUSHA, 1944
                    WP(C) NO. 8174 OF 2020
PETITIONER/S:
    1      JOMINI SAMUEL
           AGED 41 YEARSDr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

           W/O.SAMUEL, KOYIKALETH HOUSE, KOZHENCHERRY,
           PATHANAMTHITTA.
    2      SHEBA ANNA SAMUEL
           D/O.SAMUEL, KOYIKALETH HOUSE, KOZHENCHERRY,
           PATHANAMTHITTA.
           BY ADVS.
           SRI.B.S.SWATHI KUMAR
           SMT.ANITHA RAVINDRAN
           SRI.HARISANKAR N UNNI
           SMT.P.S.BHAGYA SURABHI
RESPONDENT/S:
    1      UNION OF INDIA
           REPRESENTED BY SECRETARY TO GOVERNMENT, MINISTRY
           OF COMMUNICATION AND IT DEPARTMENT OF ELECTRONIC
           AND INFORMATION TECHNOLOGY, ELECTRONICS NIKETAN,
           6, CGO COMPLEX, LODHI ROAD, NEW DELHI-110003
    2      GOOGLE INDIA (PVT) LTD
           HEAD OFFICE AT BLOCK 1, DIVYASREE OMEGA, SURVEY
           NO.13, KONDAPUR VILLAGE, HYDERABAD, ANDRA PRADESH
           500032 REPRESENTED BY ITS CHIEF EXECUTIVE OFFICER
    3      INDIAN KANOON,
           P.O.BOX NO.3804, BENGALURU, KARNATAKA, 500038,
           REPRESENTED BY ITS CHIEF EXECUTIVE OFFICER
           MR.SUSHANT SINHA
           WP(C) NO. 8174 OF 2020
                                    -2-
     4    HIGH COURT OF KERALA
          MARINE DRIVE, ERNAKULAM- 682031, REPRESENTED BY
          ITS REGISTRAR GENERAL
     5    ADDL. R5: GOOGLE LLC ( A LIMITED LIABILITY CO.),
          1600, AMPHIETHEATRE, PARKWAY, MOUNTAIN VIEW, CA
          94043, USA.
          ADDL. R5 SUO MOTU IMPLEADED AS PER ORDER DATED
          01/04/2022 IN WPC.8174/2020.
          BY ADVS.
          SRI.RIJI RAJENDRAN
          SANTHOSH MATHEW
          B.G.HARINDRANATH
          C.M.ANDREWS
          SMT.MITHA SUDHINDRAN
          BHARADWAJASUBRAMANIAM.R
          ARUN THOMAS
          JENNIS STEPHEN
          KARTHIKA MARIA
          ANIL SEBASTIAN PULICKELDr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

          JAISY ELZA JOE
          ABI BENNY AREECKAL
          VRINDA BHANDARI
          ABHINAV SEKHRI
          TANMAY SINGH
          KRISHNESH BAPAT
          MISHRA ANANDITA VIPINKANT
          ADITYA VIKRAM BHAT
          HARISH ABRAHAM
          AMITH KRISHNAN H.
          MANU S., DSG OF INDIA
          SUVIN R.MENON, CGC
     THIS WRIT PETITION (CIVIL) HAVING BEEN FINALLY HEARD
ON   6/10/2022,ALONG   WITH    WP(C).6687/2017   AND   CONNECTED
CASES,   THIS COURT ON 22.12.2022 DELIVERED THE FOLLOWING:
            IN THE HIGH COURT OF KERALA AT ERNAKULAM
                            PRESENT
         THE HONOURABLE MR. JUSTICE A.MUHAMED MUSTAQUE
                                &
        THE HONOURABLE MRS. JUSTICE SHOBA ANNAMMA EAPEN
THURSDAY, THE 22ND DAY OF DECEMBER 2022 / 1ST POUSHA, 1944
                    WP(C) NO. 21917 OF 2020
PETITIONER/S:
           DR.NIKHIL S RAJAN
           AGED 37 YEARS
           SON OF SOMARAJAN, RESIDING AT BHARGAVI,
           NELLIMUKKU,KOLLAM, KERALA-691 012
           BY ADVS.
           JOHNSON GOMEZ
           SRI.SANJAY JOHNSON
           SHRI.JOHN GOMEZ
           SMT.SREEDEVI S.
RESPONDENT/S:
    1      THE UNION OF INDIA
           REPRESENTED BY THE JOINT SECRETARY., MINISTRY OF
           INFORMATION AND BROADCASTING, ROOM NO. 552, A-
           WING SHASTRI BHAVAN, NEW DELHI 110 001.
    2      THE REGISTRAR GENERAL,
           HIGH COURT OF KERALA, ERNAKULAM-682 031.
    3      THE WEBMASTER,
           INDIAN KANOON, WEBMASTER@INDIANKANOORN.COM.
    4      GOOGLE INDIA PVT. LTD.
           1ST FLOOR, 3 NORTH AVENUE, MAKER MAXITY, BANDRA
           KURLA COMPLEX, BANDRA EAST, MUMBAI, INDIA-400051
    5      ADDL. R5: GOOGLE LLC ( A LIMITED LIABILITY CO.),
           1600, AMPHIETHEATRE PARKWAY, MOUNTAIN VIEW, CADr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

           94043, USA.
           ADDL. R5 IS SUO MOTU IMPLEADED AS PER ORDER DATED
           01/04/2022 IN WPC.21917/2020.
           WP(C) NO. 21917 OF 2020
                                    -2-
          BY ADVS.
          SHRI MANU S., DSG
          SRI.JAISHANKAR V.NAIR, CGC
          B.G.HARINDRANATH
          SRI.SANTHOSH MATHEW
          Riji Rajendran
          C.M.ANDREWS
          SRI.ARUN THOMAS
          SRI.JENNIS STEPHEN
          SRI.VIJAY V. PAUL
          SMT.KARTHIKA MARIA
          SRI.ANIL SEBASTIAN PULICKEL
          SMT.DIVYA SARA GEORGE
          SMT.JAISY ELZA JOE
          SHRI.ABI BENNY AREECKAL
          SMT.LEAH RACHEL NINAN
          MITHA SUDHINDRAN(K/000859/2015)
          ADITYA VIKRAM BHAT
          HARISH ABRAHAM
          AMITH KRISHNAN H.
     THIS WRIT PETITION (CIVIL) HAVING BEEN FINALLY HEARD
ON   6/10/2022,ALONG   WITH   WP(C).6687/2017   AND   CONNECTED
CASES,   THIS COURT ON 22.12.2022 DELIVERED THE FOLLOWING:
             IN THE HIGH COURT OF KERALA AT ERNAKULAM
                             PRESENT
          THE HONOURABLE MR. JUSTICE A.MUHAMED MUSTAQUE
                                  &
         THE HONOURABLE MRS. JUSTICE SHOBA ANNAMMA EAPEN
THURSDAY, THE 22ND DAY OF DECEMBER 2022 / 1ST POUSHA, 1944
                     WP(C) NO. 2604 OF 2021
PETITIONER/S:
            xxxxx xxxxx xxxxx
            BY ADV ANITHA MATHAI MUTHIRENTHY
RESPONDENT/S:
     1      THE REGISTRAR GENERAL
            HIGH COURT OF KERALA, COCHIN-682 031.Dr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

     2      WWW.INDIANKANOON.ORG
            NO PHYSICAL ADDRESS FOUND, E-MAIL-
            API@INDIANKANOON.COM
     3      WWW.MYNATION.NET
            NO PHYSICAL ADDRESS FOUND, E-MAIL-
            ADMIN@MYNATION.NET
     4      ADDL. R4: GOOGLE LLC ( A LIMITED LIABILITY CO.),
            1600, AMPHIETHEATRE, PARKWAY, MOUNTAIN VIEW, CA
            94043, USA.
            ADDL. R4 SUO MOTU IMPLEADED AS PER ORDER DATED
            01/04/2022 IN WPC.2604/2021.
            BY ADVS.
            B.G.HARINDRANATH
            AMITH KRISHNAN H.
            SRI.SANTHOSH MATHEW
            Smt.Riji Rajendran
      THIS WRIT PETITION (CIVIL) HAVING BEEN FINALLY HEARD
ON   6/10/2022,   ALONG   WITH   WP(C).6687/2017   AND   CONNECTED
CASES,    THIS COURT ON 22.12.2022 DELIVERED THE FOLLOWING:
            IN THE HIGH COURT OF KERALA AT ERNAKULAM
                              PRESENT
         THE HONOURABLE MR. JUSTICE A.MUHAMED MUSTAQUE
                                 &
        THE HONOURABLE MRS. JUSTICE SHOBA ANNAMMA EAPEN
THURSDAY, THE 22ND DAY OF DECEMBER 2022 / 1ST POUSHA, 1944
                      WP(C) NO. 12699 OF 2021
PETITIONER/S:
           XXXXX XXXXX XXXXX
           BY ADVS.
           RAJIT
           ARJUN S.
RESPONDENT/S:
    1      UNION OF INDIA
           4TH FLOOR, A-WING, BHAWN, NEW DELHI-110 001,
           REPRESENTED BY THE SECRETARY-MINISTRY OF LAW AND
           JUSTICE
    2      THE HIGH COURT OF KERALA,
           HIGH COURT ROAD, MARINE RIVE, KOCHI-682 031,
           KERALA REPRESENTED BY THE REGISTRAR GENERAL.
    3      MINISTRY OF TELECOMMUNICATION,
           SANCHAR BHAWAN, 20, ASHOKA ROAD, NEW DELHI-110
           001, REPRESENTED BY THE SECRETARY DEPARTMENT OF
           TELECOMMUNICATION
    4      GOVERNMENT OF KERALA,
           GOVERNMENT SECRETARIAT, THIRUVANANTHAPURAM,Dr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

           KERALA-695 001, REPRESENTED BY THE CHIEF
           SECRETARY-GOVT OF KERALA
    5      GOOGLE INDIA PVT LTD,
           NO 3, RMZ INFINITY TOWER E, OLD MADRAS ROAD,
           BANGALORE, KARNATAKA-560 016, REPRESENTED BY ITS
           CEO.
           WP(C) NO. 12699 OF 2021
                                     -2-
     6    INDIANKANOON NO 724,
          1ST FLOOR, 9TH CROSS, 10TH MAIN, INDIRA NAGAR,
          BENGALURU, KARNATAKA-560 038, REPRESENTED BY ITS
          PROPRIETOR SUSHANT SINHA.
     7    ADDL. R7: GOOGLE LLC (A LIMITED LIABILITY CO.),
          1600, AMPHIETHEATRE PARKWAY, MOUNTAIN VIEW, CA
          94043, USA.
          ADDL. R7 IS SUO MOTU IMPLEADED AS PER ORDER DATED
          01/04/2022 IN WPC.12699/2021.
          BY ADVS.
          SRI.GIRISH KUMAR.V., CGC
          BABU PAUL
          Riji Rajendran
          C.M.ANDREWS
          MITHA SUDHINDRAN(K/000859/2015)
          ADITYA VIKRAM BHAT
          HARISH ABRAHAM
          SRI.SANTHOSH MATHEW
          SRHI B.G.HARINDRANATH
      THIS WRIT PETITION (CIVIL) HAVING BEEN FINALLY HEARD
ON   6/10/2022,   ALONG   WITH   WP(C).6687/2017   AND   CONNECTED
CASES,   THIS COURT ON 22.12.2022 DELIVERED THE FOLLOWING:
            IN THE HIGH COURT OF KERALA AT ERNAKULAM
                            PRESENT
         THE HONOURABLE MR. JUSTICE A.MUHAMED MUSTAQUE
                                &
        THE HONOURABLE MRS. JUSTICE SHOBA ANNAMMA EAPEN
THURSDAY, THE 22ND DAY OF DECEMBER 2022 / 1ST POUSHA, 1944
                    WP(C) NO. 29448 OF 2021
PETITIONER/S:
           ADITHYA GOKUL M.S.
           AGED 26 YEARS
           GOKULAM HOUSE, KANJIRANOOJI, PERUVAYAL P.O,
           KOZHIKODE - 673008.
           BY ADV BIMALA BABYDr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

RESPONDENT/S:
    1      UNION OF INDIA
           REPRESENTED BY SECRETARY BY GOVERNMENT, MINISTRY
           OF COMMUNICATION AND IT DEPARTMENT OF ELECTRONIC
           AND INFORMATION TECHNOLOGY, ELECTRONICS NIKETAN,
           6, CGO COMPLEX, LODHI ROAD, NEW DELHI - 110003.
    2      GOOGLE INC
           1600, AMPHIETHEATRE PARKWAY, MOUNTAIN VIEW, CA
           94043, USA, REPRESENTED BY ITS MANAGING DIRECTOR.
    3      GOOGLE INDIA PRIVATE LIMITED
           NO.3, RM2 INFINITY TOWER E OLD MADRAS ROAD, 4TH
           AND 5TH FLOOR, BANGALORE - 560016.
           BY ADVS.
           SRI.JAISHANKAR V.NAIR, CGC
           Riji Rajendran
           MITHA SUDHINDRAN(K/000859/2015)
    THIS WRIT PETITION (CIVIL) HAVING BEEN FINALLY
HEARD ON 6/10/2022, ALONG WITH WP(C).6687/2017 AND
CONNECTED CASES,      THIS COURT ON 22.12.2022
DELIVERED THE FOLLOWING:
                                                                        'C.R'
                   A.MUHAMED MUSTAQUE
                                    &
                 SHOBA ANNAMMA EAPEN, JJ.
                  -----------------------------------------
           W.P.(C).Nos. 26500/2020, 6687/2017,
            20387/2018, 7642/2020, 8174/2020,
           21917/2020, 2604/2021, 12699/2021 &
                               29448/2021
                  -----------------------------------------
           Dated this the 22nd day of December 2022
                             JUDGMENT
A.Muhamed Mustaque, J.
These cases present a question of seminal importance in judicial information policy followed by the
Courts in India. They have been placed before us on a reference order of the learned Single Judge,
Justice Anil K. Narendran in W.P. (C).No.6687/2017, dated 15/3/2021, to determine the questions
involved, finally, by an authoritative pronouncement. In the detailed reference order running up toDr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

more than 80 pages, the learned W.P.(C).Nos.26500/2020 & con.cases single Judge referred the
point of law to be answered by us, thus:
68. Therefore, the question that has to be considered in this writ petition is as to
whether, in writ petitions filed under Article 226 of the Constitution of India seeking
a writ of mandamus commanding the statutory authority to consider the application
for contracting marriage under the Special Marriage Act, 1954 or for registration of
marriage under the Kerala Registration of Marriages (Common) Rules, 2008; a writ
of habeas corpus seeking production of fiancée or minor children under illegal
detention; etc., which are not matters involving public interest, a party to that
proceedings can seek an order to mask his/her name and address and that of the
party respondent(s) in the cause title of the judgment and also his/her name and that
of the party respondent(s) in the body of the judgment, in order to protect his/her
right to privacy, described as the 'right to be let alone'.
2. After the reference, some more cases not related to family matters, have also been placed before
us for consideration. The points involved in these cases are related to the publication of Court
judgments, other than judgments in which anonymity is protected under the law and allowing free
access to such information.
W.P.(C).Nos.26500/2020 & con.cases
3. The brief facts of each case are set out hereunder:
3.(i) W.P. (C) No. 26500 of 2020: Criminal proceedings were initiated against the
petitioner for an offence punishable under Section 354-D Indian Penal Code in
C.C.No.344/2015 on the file of the Judicial First Class Magistrate Court, Chavakkad.
Subsequently, in the Crl.M.C No.5477/2016 filed before this Court, the de facto complainant filed an
affidavit stating that she does not wish to pursue the matter and consented to quash the entire
proceedings. By judgment dated 7/9/2016, Crl.M.C No.5477/2016 was allowed and the proceedings
in C.C.No.344/2015 were quashed. This judgment has been published by Indian Kanoon and
indexed by Google.
The petitioner submits that the right to be forgotten being recognized as a part of the right
W.P.(C).Nos.26500/2020 & con.cases to privacy and the judgment being of no public importance,
there is no justification for it being in the public domain.
3.(ii). W.P. (C) No. 21917 of 2020: Petitioner, a Dentist by profession, was accused in Crime No. 1111
of 2013 of Kollam East Police Station, but was subsequently acquitted of all the charges in the year
2019. A bail order dated 9/5/2014 in Bail Application No. 2662 of 2014 in the above proceedings
was published by the website Indian Kanoon, and the same appears on a search on Google. The
petitioner also submits that the order on Indian Kanoon incorrectly states the crime number.Dr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

Relying upon the judgment of Justice K.S.Puttaswamy (Retd) and another v. Union of India and
Others [(2017) 10 SCC 1], the petitioner submits that the right to privacy includes the right to be
forgotten. In light of which, the W.P.(C).Nos.26500/2020 & con.cases petitioner is entitled to the
protection of his fundamental right to privacy and has a right to erase contents that are unnecessary,
irrelevant, inadequate or no longer relevant.
3.(iii). W.P (C) 8174 of 2020: The first petitioner (P1) is the mother and the second petitioner (P2) is
her daughter, who is an MBBS student. The petitioners submit that in the year 2014, when P2 was
wrongfully detained and confined, P1 filed a habeas corpus petition. Subsequently, P2 was released
and the writ petition [W.P. (Crl) 266/2014] was closed. The grievance of the petitioners is that
judgment in the above writ petition is published by Indian Kanoon on its website, which appears on
the search engine, Google, putting the identity of P2 in the public domain and causing substantial
prejudice to her.
W.P.(C).Nos.26500/2020 & con.cases
3.(iv). W.P (C) No. 6687/ 2017: The petitioner, an Indian resident, had approached this Court in
W.P. (C) No. 23996/2015 for a direction to solemnize her marriage to a US citizen under the Special
Marriages Act, 1954.
The writ petition was disposed of on 7/8/2015 by this Court with a direction to the Marriage Officer
to receive the intended marriage notice and solemnize the marriage. The marriage however, could
not be solemnized due to differences between the parties.
The petitioner is aggrieved by the publication of the said judgment on Indian Kanoon with her name
in the cause title, which has been indexed by the search engine, Google (respondents 2 and 3). The
petitioner submits that substantial prejudice has been caused to her due to the information being
available in the public domain, which has caused her mental trauma and agony.
W.P.(C).Nos.26500/2020 & con.cases Petitioner submits that the rule that the publication of Court
records will not violate the right to privacy is subject to the exceptions in the interest of decency.
It is the petitioner's submission that the first respondent, Ministry of Communication and IT
Department of Electronic and Information Technology, is the nodal agency that regulates and
formulates the policies of the Government in relation to information technology, electronics and the
internet, in light of which it should compel the second respondent, an intermediary to de-index the
links to the page.
3.(v). W.P (C) No. 7642 of 2020: Aggrieved by the publication of the judgments of the learned Single
Judge of this Court in Bail Application No.7123/2017 in which he was granted anticipatory bail, and
Criminal M.C. No. 4510/2018 by which the criminal proceedings against the petitioner and
W.P.(C).Nos.26500/2020 & con.cases his father were quashed, the petitioner has approached this
Court.Dr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

The petitioner, a Homoeopathic Doctor, submits that the third respondent, Indian Kanoon has
without the prior permission of this Court, or the petitioner as mandated by the IT (Reasonable
Security Practices and Procedures and Sensitive Personal Data or Information) Rules, 2011
published the above judgments, which are available on the respondent 4 and respondent 7 search
engines.
The petitioner submits that his right to privacy has been violated and that his right to be forgotten
which emanates from the right to privacy, should be protected.
The petitioner further submits that respondents 5 and 6 regulate intermediaries and are duty bound
to ensure that intermediaries do not infringe the W.P.(C).Nos.26500/2020 & con.cases privacy of
persons when exercising their right to publish.
3.(vi). W.P. (C) No. 20387 of 2018: The petitioner was the 3rd accused in C.P. No. 61/2011 and the
complainant (CW3) in CP. No. 62/2011, on the file of the Judicial First Class Magistrate Court-II,
Nedumangad.
The matter being settled between the parties, the petitioner and the other accused filed Crl. M.C. No.
100/2013 to quash proceedings in C.P. No. 61/2011 and Crl. M.C. No.109/2013 to quash
proceedings in C.P. No. 62/2011. Both CPs were quashed by a common order dated 10/1/2013. The
above two Crl.M.C. Nos.100/2013 and 109/2013 were published on the website of Indian Kanoon.
The petitioner submits his right to privacy has been infringed and that no guidelines have been
issued by respondents 1 to 3 regarding publication W.P.(C).Nos.26500/2020 & con.cases of details
of individuals in cases that have been settled between the parties.
3.(vii). W.P.(C) No. 12699 of 2021: The petitioner's grievance is that the publication of judgments
disclosing the petitioner and her parent's identity, in W.P (C) No.20773/2010 and Tr.P(C) No.
353/2013, where the petitioner's parents are arrayed as parties on opposite sides, is an intrusion of
her privacy.
The petitioner submits that such publication by the 6th respondent, Indian Kanoon is in
contravention of the Hon'ble Supreme Court e- Committee's communication dated 16.07.2013,
directing all High Courts to refrain from uploading case related information except case number and
its status on the internet, in cases relating to, inter alia, matrimonial matters.
3.(viii). W.P. (C) No. 29448 of 2021: It is the petitioner's case that he has been falsely arrayed
W.P.(C).Nos.26500/2020 & con.cases as accused in Crime No. 734/2020 for the offences
punishable under Section 67(B)(a)(b) of the Information Technology Act and Section 15 of the
Protection of Children from Sexual Offences Act. The petitioner approached this Court for
anticipatory bail in B.A. No. 6482/2020 and the same was allowed as per judgment dated
16/10/2020. This order of the Court has been published on Indian Kanoon which has then been
indexed by the search engine Google. The petitioner submits that his right to privacy has been
infringed.Dr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

3.(ix). W.P.(C) No. 2604 of 2021: Aggrieved by the petitioner's name, age, father's name and
residential address in a judgment in O.P.(F.C) No.64/2019 in relation to her minor child's custody
matter being visible to the general public on various search engines, she has approached this Court
claiming that her right to privacy as W.P.(C).Nos.26500/2020 & con.cases enshrined under Article
21 of the Constitution is being violated.
PROLOGUE:
4. We shall advert to the arguments and submissions of the learned counsels who appeared for the
parties and Shri B.G.Harindranath, learned counsel for the Kerala High Court whose submissions
are more as an amicus curiae, hereafter under the respective subcategories for a proper
understanding of the issues and arguments thereon. We think that before adverting to the distinct
issues, we need to discuss the right of privacy of individuals and the interest of the public qua
judicial institutions. Accordingly, we have categorized the subjects for discussion and consideration
viz. privacy, Courts as democratic institutions, open data and public interest and the right to be
forgotten, for elucidation on the W.P.(C).Nos.26500/2020 & con.cases broader premises of the
issues involved in these cases:
(I) ON PRIVACY:
5. Humans by nature are social animals. They are not living in isolation in society. They possess
freedom and liberty of choice. Humans possess certain inalienable rights which are so fundamental
and related to their person and body. The aspiration of humans as individuals is to live with dignity.
This notion of the individual's right to choose a life of his own began to be confronted with, in
history when the sovereign started limiting his authority. The moral value of sensations to secure a
private life, not entangled with the public sphere, created a sense of possessiveness in man. This
individualistic notion and idea of private reason identified with the dignity of the individual is a
starting point for defining privacy as a right. The learned counsel W.P.(C).Nos.26500/2020 &
con.cases Shri B.G.Harindranath placing reliance on Peter Semayne v. Richard Grecham [All ER
Rep 62; 5 Co Rep 91 a], decided by the Court of Kings Bench in the year 1604 wherein the Court
recognised the right of the homeowner to defend his house against unlawful entry even by the
King`s agents, submitted that no one has the absolute freedom to encroach on the private life of
individuals except as authorised by law. He also drew attention to the earliest article on right to
privacy written by Samuel D. Warren; Louis D. Brandeis in Harvard Law Review, Vol. 4, No. 5. (Dec.
15, 1890), pp. 193-220, 205. In a prelude of this article, the authors mention the evolution of the
right to privacy.
Thus, in very early times, the law gave a remedy only for physical interference with life and property,
for trespasses vi et armis. Then the "right to life" served only to protect the subject from battery in
its various forms; liberty meant freedom from actual restraint; and the right to property secured to
the individual his lands and his cattle. Later, there came a recognition of man's
W.P.(C).Nos.26500/2020 & con.cases spiritual nature, of his feelings and his intellect. Gradually
the scope of these legal rights broadened; and now the right to life has come to mean the right to
enjoy life,-the right to be let alone; the right to liberty secures the exercise of extensive civilDr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

privileges; and the term "property" has grown to comprise every form of possession-intangible, as
well as tangible. Lord Cottenham stated that a man "is entitled to be protected in the exclusive use
and enjoyment of that which is exclusively his," and cited with approval the opinion of Lord Eldon,
as reported in a manuscript note of the case of Wyatt v. Wilson, in 1820, respecting an engraving of
George the Third during his illness, to the effect that "if one of the late king's physicians had kept a
diary of what he heard and saw, the court would not, in the king's lifetime, have permitted him to
print and publish it;" and Lord Cottenham declared, in respect to the acts of the defendants in the
case before him, that "privacy is the right invaded.
The principle which protects personal writings and all other personal productions, not against theft
and physical appropriation, but against publication in any form, is in reality not the principle of
private property, but that of an inviolate personality.
6. The problem of the present nature of the right to privacy, as in these cases, has arisen as an
impact of technology in our lives. Technology has W.P.(C).Nos.26500/2020 & con.cases opened the
world around us and created a virtual public space. The doors to this public space have been opened
forever, making the identity of the individual digitally immortal. Digital immortality defines the
continuation of an active or passive digital presence even after death. The online presence of data
permanently raises new issues regarding the right to privacy. The social and ethical problems in
relation to digital immorality and artificial intelligence which can identify the data stored through
algorithms are the subject matter of debate across the globe. This problem before the Courts in India
essentially stems from this new era of technology due to the lack of legislation or regulation. The
intersection of privacy and technology has become a challenge to the judicial administrator as well.
The law Courts are attempting to keep up with the advancement of technology to bring changes in
the judicial administration and function, as well as to W.P.(C).Nos.26500/2020 & con.cases
champion the rights of individuals to protect their privacy. The challenges in these writ petitions
before us, throw up issues on the judicial side and open our eyes to judicial administration. The first
and foremost important task for us, in this case, is defining privacy in the context of data made
available by parties before the Court. In light of the declaration of privacy as a fundamental right by
the Apex Court in Justice K.S.Puttaswamy's case (supra) we are inclined to define privacy in relation
to Court data as data concerning the names of the party/parties and identifying their cause before
the Court. There are different dimensions of the information before Courts which plays an integral
role in encouraging fair and transparent decision- making by the Courts, giving them legitimacy and
contributing to the dissemination of information about the judicial process among the public. This
also brings up friction between the right to W.P.(C).Nos.26500/2020 & con.cases privacy and the
right to anonymity. Justice Chandrachud in Justice K.S.Puttaswamy's case (supra), in relation to
privacy and anonymity, observed as follows:
312. A distinction has been made in contemporary literature between anonymity on
one hand and privacy on the other.
Both anonymity and privacy prevent others from gaining access to pieces of personal information,
yet they do so in opposite ways. Privacy involves hiding information whereas anonymity involves
hiding what makes it personal.Dr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

7. Privacy is about choice. This choice is sought to be extended as anonymity in Court proceedings.
Privacy in the judicial information context is essentially related to the contents of the information in
the case. Anonymity on the other hand, in the judicial information sphere, is a process of denying
information to the public about the identity of the parties related to a case. Anonymity is the subject
of privacy in a Courtroom and there exists a subtle distinction between anonymity and privacy in
relation to the contents W.P.(C).Nos.26500/2020 & con.cases of the judicial proceedings. The
nature of privacy can be classified as informational privacy. Undoubtedly, we have to hold that
personal information as above, of the parties in a case, has to be classified as data forming part of his
or her privacy. The individual's right to exercise control over his personal data and to be able to
control his/her own life has been recognized in Justice K.S.Puttaswamy's case (supra) in the
separate judgment authored by Justice Sanjay Kishan Kaul without recognizing it as an absolute
right.
629. The right of an individual to exercise control over his personal data and to be able to control
his/her own life would also encompass his right to control his existence on the internet. Needless to
say that this would not be an absolute right. The existence of such a right does not imply that a
criminal can obliterate his past, but that there are variant degrees of mistakes, small and big. and it
cannot be said that a person should be profiled to the nth extent for all and sundry to know.
W.P.(C).Nos.26500/2020 & con.cases Justice Chandrachud also recognised this right in the above
judgment of Justice K.S.Puttaswamy's case (supra) holding:
248. Privacy has distinct connotations including (i) spatial control; (ii) decisional
autonomy; and (iii) informational control. Spatial control denotes the creation of
private spaces. Decisional autonomy comprehends intimate personal choices such as
those governing reproduction as well as choices expressed in public such as faith or
modes of dress. Informational control empowers the individual to use privacy as a
shield to retain personal control over information pertaining to the person.
8. The interplay of providing information about the parties and providing
information on the contents of the cause in a Court of law requires a balancing
exercise. It is exactly that exercise that has to be considered by this Court in these
writ petitions in the absence of any legislation.
Anonymity though is different from privacy, it becomes a facet of privacy when the cause and
content in a case are identified with the parties in the lis. The privacy aspect of such information
W.P.(C).Nos.26500/2020 & con.cases about the identity of the parties cannot be separated from the
cause that is being considered by the Court in open transparent court proceedings. The sensitive and
personal information of individual parties was exposed to the public when the Court started making
judgments available through its web portals. Law reporters beaming court news online, have
worldwide online viewers and followers. The judgments became a gold mine of data for online
publishers, to the satisfaction of lawyers, litigants, researchers etc. Such publishers and legal
databases developed search tools using algorithms for easy identification of the judgments with
reference to the name of parties, subject and text of the judgments. Search engines like Google help
users find the information they are looking for, using keywords and phrases. No one has anyDr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

grievance against the open, transparent court proceedings and the conduct of cases in the open
justice W.P.(C).Nos.26500/2020 & con.cases system. The problem for them is allowing their
personal and private information to remain permanently in the digital public space, invading their
right to privacy and right to forget the past. The task for us, therefore, is to decide not only on the
privacy claimed in the present but also in the future.
II. ON EVOLUTION OF COURTS IN INDIA AS A DEMOCRATIC INSTITUTION AND ITS MARCH
TOWARDS THE DIGITAL AGE:
A. Tracing The Evolution Of Courts In India:
a). Judiciary in India during pre constitutional era:
9. On a Sunday morning, 10th November 1612, the Judges of England were
summoned before King James I, upon complaint of the Archbishop of Canterbury.
The Archbishop explained to the King that the Judges were delegates of the King and what the
W.P.(C).Nos.26500/2020 & con.cases King might do himself when it seemed best to him, what he
usually left to these delegates. Sir Edward Coke, considered the greatest Judge at that time,
answered on behalf of the Judges, "that by the law of England, the King in person could not adjudge
any cause; all cases, civil and criminal, were to be determined in some court of justice according to
the law and custom of the realm.
"But," said the King, "I thought law was founded upon reason, and I and others have
reason as well as the judges." "True it was," Coke responded, "that God had endowed
his Majesty with excellent science and great endowments of nature; but his Majesty
was not learned in the laws of his realm of England, and causes which concern the life
or inheritance or goods or fortunes of his subjects are not to be decided by natural
reason, but by the artificial reason and judgment of the law, which law is an art which
requires long study and experience before that a man can attain to the
W.P.(C).Nos.26500/2020 & con.cases cognizance of it." [See, 'The Spirit of the
Common Law' by Roscoe Pound]. In the history of the English Court system, perhaps
this conversation was the first assertive declaration of independence of Judges. In
ancient times, the Judges during the reign of Kings were considered to be loyal
servants of the King. The idea of an independent judiciary came into existence with
the idea of separation of powers. The evolution of the independent judiciary in India
can be dated back to the Constitution though independent judiciary, in a limited
sphere, existed in the pre-
constitutional era as well. The disputes between private litigants were decided by
independent Courts in India in different periods. During the medieval period
(1192-1700 CE), in most parts of India, the public legal systems in the Centre and
provincial capitals were based on Islamic principles under the Muslim leaders of the
Delhi Sultanate dynasties and the Mughal empire. W.P.(C).Nos.26500/2020 &Dr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

con.cases However, in areas distanced from the standard institutions of Muslim Rule
such as rural India and Hindu-dominated villages, local legal practices continued. It
is important to note that the general principles of Islamic jurisprudence were adopted
in the Indian scenario under the Muslim Rulers. The focus of the administration of
justice was through a qazi, who was appointed in accordance with Islamic law. The
process was neither adversarial nor investigative in a formal manner of civil
procedure. There was no scope for appeal. The resolution of the dispute by qazi was
acceptable to all as they were endowed with honesty, impartiality, virtuousness etc.
[See, "Courts of India, Past to Present", published by Supreme Court of India (Page
42)].
10. At the beginning of the 18th Century, East India Company took responsibility for
the administration of justice in India, confining to W.P.(C).Nos.26500/2020 &
con.cases the presidency towns of Calcutta, Madras and Bombay. In each of these
towns, the Company had set up its own Courts. East India Company was confronted
with the problem of administering justice to persons living beyond the limits of the
Presidency towns. The first important step was taken in 1772 by Warren Hastings
with the establishment of the Sadar or Chief Courts. The Sadar Dewani Adalat was
vested with appellate jurisdiction in civil matters and Sadar Nizamat Adalat with the
power to revise the proceedings of the Criminal Courts. The Governor and members
of the Bengal Council were the Judges of the Sadar Dewani Adalat. The Nizamat
Adalat was presided over by an Indian official appointed by the Nawab Nazim of
Bengal. The East India Company faced financial difficulties resulting in the passing of
the Regulating Act of 1773. The Bengal Council was reconstituted and a provision was
made for the establishment of a Supreme Court of Judicature in
W.P.(C).Nos.26500/2020 & con.cases Calcutta of which the judges were appointed
by the Crown. [See for more reading - Orby Mootham's "The East India Company's
Sadar Courts 1801-1834 Pg.3 & 4].
11. The history of the present Courts in India owes its origin to the Courts established
by the East India Company and thereafter during the period of the British Empire.
The focus of the East India Company was purely of a commercial nature. "As the
company began to transform itself from commercial concern into a political power,
the Mayor's Courts and Justices of the Peace were found to be incapable of fitting into
the new atmosphere as effective agencies for the discharge of judicial administration.
It was to remedy this defect, Regulating Act established the Supreme Court...." [See
Chapter III "Federal Court of India"
by M.V.Pylee].
W.P.(C).Nos.26500/2020 & con.cases
12. The Crown appointed the Judges of the Supreme Court, marking a shift from being a Company's
Court to a King's Court. The establishment of the Supreme Court under the Regulating Act allowedDr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

greater intervention by the English Government and Parliament in Indian affairs and control over
the Company's proceedings. The policy underlying the Regulating Act caused conflict between the
Court and the Council which led to the passage of the Act of Settlement of 1781. This Act set limits to
the jurisdiction of the Supreme Court in matters concerning revenue to safeguard the interests of
the executive. It also recognised the Civil and Criminal Provincial Courts, existing independently of
the Supreme Court; and of the Governor-General and Council as the Chief Appellate Court of the
country. [See Chapters II & III "History and Constitution of the Courts and Legislative Authorities in
India", by Herbert Cowell] W.P.(C).Nos.26500/2020 & con.cases
13. Subsequently, to do away with the anomalous procedure followed by the Supreme Courts, the
Indian High Courts Act, 1861 was enacted to abolish the Supreme Courts and Sadar Adalat. In their
place, High Courts of Judicature for each of the three Presidencies were authorised to be
constituted. M.P. Jain in his book "Outlines of Indian Legal History", writes about the three
Presidency Courts as follows:
The emergence of the three High Courts was, indeed, a momentous step forward in
the process of evolution of a proper system for the administration of law and justice
in the country. For over eighty years, there had been in existence two parallel systems
of judicature in the Presidencies. The evolution of these systems had been
complicated and divergent. They represented two different sources of power. The
Supreme Courts represented, derived their jurisdiction from, and were under the
control of, the Crown. On the other hand, the Adalats represented, derived
jurisdiction from, and were under the control of, the Company.
The Judges of the High Court were to hold their office during the Queen's pleasure.
However, with W.P.(C).Nos.26500/2020 & con.cases the enactment of the
Government of India Act of 1935, the convention of judicial independence was
formalised. Judges were to serve a fixed term and could only be removed earlier by
the Crown on certain fixed grounds.[See Chapter XIX "Outlines of Indian Legal
History" by M.P.Jain]. The author writes as follows:
The Act further laid down that no discussion could take place in the legislature with
respect to the conduct of a High Court Judge in the discharge of his duties. These
safeguards along with the security of tenure and salary, mentioned above, were
regarded as sufficient to maintain the independence of the High Court vis-a-vis the
Provincial Government.
The Act of 1935 provided for the establishment of a Federal Court; its jurisdiction
extending to disputes between the Dominion and the Provinces, interpretation of
Acts or Orders in Council, etc. The Federal Courts were also empowered to entertain
appeals from judgments, decrees and W.P.(C).Nos.26500/2020 & con.cases final
orders of any High Court of British India. [See "Legal and Constitutional History of
India", by M.Rama Jois]Dr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

14. The Courts established during the British rule including the Federal Courts under the
government of India Act 1935 never reflected the WILL OF THE PEOPLE. The appointment of the
judges and the nature of disputes always insulated the interest of the ruling British from being
agitated.
b). The Emergence Of Judiciary In India As A Democratic Institution In the Post-Constitutional
Period:
15. The supremacy of law in India reflected the WILL of the people, on the adoption of the
Constitution on 26th November 1949, which effectively came into force on 26th January 1950. The
very democratic character of the Constitution ensured the creation of institutions accountable to the
people. The Legislature, Executive and W.P.(C).Nos.26500/2020 & con.cases Judiciary, though
form different pillars of the state, in essence, are created to sustain the Will of the people. One of the
aspects of democracy is the creation of an independent judiciary. In the First Judges Case, S.P Gupta
v. Union of India [1981 Supp SCC 87], the Court spoke about the concept of independence of the
judiciary as follows:
The concept of independence of the judiciary is a noble concept which inspires the
constitutional scheme and constitutes the foundation on which rests the edifice of our
democratic polity. If there is one principle which runs through the entire fabric of the
Constitution, it is the principle of the rule of law and under the Constitution, it is the
judiciary which is entrusted with the task of keeping every organ of the State within
the limits of the law and thereby making the rule of law meaningful and effective. It is
to aid the judiciary in this task that the power of judicial review has been conferred
upon the judiciary and it is by exercising this power which constitutes one of the most
potent weapons in armory of the law, that the judiciary seeks to protect the citizen
against violation of his constitutional or legal rights or misuse of abuse of power by
the State or its officers. The judiciary stands between the citizen and the State as a
bulwark against executive excesses and misuse or abuse of W.P.(C).Nos.26500/2020
& con.cases power by the executive and therefore it is absolutely essential that the
judiciary must be free from executive pressure or influence and this has been secured
by the Constitution makers by making elaborate provisions in the Constitution to
which detailed reference has been made in the judgments in Sankalchand Sheth's
case (supra). But it is necessary to remind ourselves that the concept of independence
of the judiciary is not limited only to independence from executive pressure or
influence but it is a much wider concept which takes within its sweep independence
from many other pressures and prejudices. It has many dimensions, namely
fearlessness of other power centers, economic or political, and freedom from
prejudices acquired and nourished by the class to which the Judges belong".
16. The independent judiciary was thus obliged to ensure that the supremacy of law prevailed. The
Constitution envisages that the judiciary not only states the law through an interpretative process
but also protects the Constitution and democracy. In that process, the judiciary cannot act like
unelected legislators and erode parliamentary supremacy to legislate by undermining the rule ofDr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

law. The essence of democracy, characteristically, is defined by the role of each institution to
W.P.(C).Nos.26500/2020 & con.cases sustain the balance contemplated in the Constitution, making
each independent in its own sphere. Democracy literally means rule by the people. The term is
derived from the Greek dēmokratia, which was coined from dēmos ("people") and kratos ("rule") in
the middle of the 5th Century BCE to denote the political systems then existing in some Greek
city-states, notably Athens [Source online Britannica, viewed on 11/12/24]. The independent
judiciary being a creation of democracy, must also possess the character of democratic institutions
by allowing public scrutiny. In a true liberal democracy, public opinion is necessary. This public
opinion prevents missteps and allows institutions to improve their functioning. "One of the major
political theorists of obligatory public processes was Jeremy Bentham; he argued that a host of
institutions ought to operate under the principle of "publicity," so that the "Tribunal of Public
Opinion" could assess W.P.(C).Nos.26500/2020 & con.cases the results. Through publicity ("the
very soul of justice"), judges, while presiding at trial, would themselves be "on trial." The idea of
public oversight of judges coupled with legal protections for judicial independence was a departure
from Renaissance conceptions of judges, who were beholden to the monarchs who appointed them.
The public's new authority to judge judges (and, inferentially, the government)helped to turn "rites"
into "rights." The more that spectators were active participants ("auditors," to borrow again from
Bentham), the more Courts could serve as a venue for the dissemination of information"
[See article "Reinventing Court as Democratic Institution", authored by Judith
Resnik]. The judiciary in India being a democratic institution, needs to possess and
reflect openness, transparency and accountability; the essential elements and values
of democracy.
W.P.(C).Nos.26500/2020 & con.cases B. Enhancing Judicial Standards To Ensure
Credibility:
17. In a quest to ensure credibility and to sustain people's confidence, judges themselves through
internal mechanisms adopted core judicial values. Restatement of values of judicial life as adopted
by the full Supreme Court on 7th May 1997, assured the public of confidence in the judicial system.
Besides, Bangalore Principles of Judicial Conduct 2002 adopted by a judicial group on
strengthening judicial integrity, in a meeting of Chief Justices at the Hague, gave momentum to
judicial ethics and standards to be followed by all.
C. Evolving Accountability And Transparency In Judicial Function In The Era Of Digital Space:
18. The independence of the judiciary cannot be assessed in isolation of its functioning. The
functioning of the judiciary, on both W.P.(C).Nos.26500/2020 & con.cases administrative and
judicial sides, must carry the edifice of the democratic character to sustain public confidence.
Accordingly, Courts in India generally follow an open Court justice system. The closed-door justice
system is a challenge to public confidence.
19. In Supreme Court Advocates on Record Association and another v. Union of India [(2016) 5 SCC
1], the Court opined on judicial function and public confidence as follows:Dr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

Indisputably, this concept of independence of judiciary which is inextricably linked
and connected with the constitutional process related to the functioning of judiciary
is a "fixed-star" in our constitutional consultation and its voice centres around the
philosophy of the Constitution. The basic postulate of this concept is to have a more
effective judicial system with its full vigour and vitality so as to secure and strengthen
the imperative confidence of the people in the administration of justice.
20. The functioning of the Court and public confidence are mutually interlinked to
ensure the independence of the judiciary and augur confidence
W.P.(C).Nos.26500/2020 & con.cases about the judges who are administering
justice.
The judiciary cannot ignore measures to gain public confidence and is compelled to adopt steps for
enhancing transparency in its functioning. The judiciary was quick to embrace Information
Communication Technology (ICT) tools to bring transparency to the administration of justice. One
of the challenges faced by lawyers, clerks, litigants etc. was the lack of information on details of the
cases before the Court. The Court also found it difficult to provide information to all, with its limited
human resources. One of the objectives of the e-committee of the Supreme Court of India is to make
the justice delivery system accessible, cost-effective, transparent and accountable. ICT tools are used
in the judiciary for improving the justice delivery system to enhance efficiency, timelines, better
access to justice, provide citizen-centric services etc. In Swapnil Tripathi v. Supreme Court Of India
[(2018) W.P.(C).Nos.26500/2020 & con.cases 10 SCC 639], the Apex Court in the context of
live-streaming of Court proceedings, elaborated the concept of open justice, judicial accountability
and transparency and opined as follows:
As no person can be heard to plead ignorance of law, there is corresponding
obligation on the State to spread awareness about the law and the developments
thereof including the evolution of the law which may happen in the process of
adjudication of cases before this Court. The right to know and receive information, it
is by now well settled, is a facet of Article 19(1)(a) of the Constitution and for which
reason the public is entitled to witness Court proceedings involving issues having an
impact on the public at large or a section of the public, as the case may be. This right
to receive information and be informed is buttressed by the value of dignity of the
people. One of the proponents has also highlighted the fact that litigants involved in
large number of cases pending before the Courts throughout the country will be
benefitted if access to Court proceedings is made possible by way of live streaming of
Court proceedings. That would increase the productivity of the country, since scores
of persons involved in litigation in the Courts in India will be able to avoid visiting the
Courts in person, on regular basis, to witness hearings and instead can attend to their
daily work without taking leave.
W.P.(C).Nos.26500/2020 & con.cases The Apex Court after a discussion on the
importance of open justice system in the light of Article 145 (4) of the Constitution,
153-B of Civil Procedure Code 1908 and section 327 of Code of Criminal ProcedureDr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

1973 held as follows:
Live-streaming of proceedings is crucial to the dissemination of knowledge about
judicial proceedings and granting full access to justice to the litigant. Access to justice
can never be complete without the litigant being able to see, hear and understand the
course of proceedings first hand. Apart from this, live-streaming is an important facet
of a responsive judiciary which accepts and acknowledges that it is accountable to the
concerns of those who seek justice. Live-streaming is a significant instrument of
establishing the accountability of other stake-holders in the justicing process,
including the Bar. Moreover, the government as the largest litigant has to shoulder
the responsibility for the efficiency of the judicial process. Full dissemination of
knowledge and information about Court proceedings through live-streaming thus
subserves diverse interests of stake holders and of society in the proper
administration of justice.
21. The approach as above, alludes to the emphasis on public interest to make open
justice more intimately connected to the people and to have
W.P.(C).Nos.26500/2020 & con.cases trust and confidence in the justice delivery
system. The judiciary neither wields the power of armoury nor has the executive fiat
of force to enforce its decisions, except the force of public opinion. The carefully
crafted transparency is the fountainhead of the clamoring independence that it
vouches for. In a liberal democracy, every public institution is built on public
reasoning. Public reasoning endorses collective affirmation on a larger common
good.
III. OPEN DATA AND LEGAL ECOSYSTEM:
22. In a liberal and democratic system, judicial administration is only a part of the
larger legal ecosystem. In the larger legal ecosystem, justice and law enforcement
integrate with the socio, economic, political and cultural aspirations of the society
and the state. In such a scenario, the Court cannot claim a monopoly over the data
available with the judiciary. The modern W.P.(C).Nos.26500/2020 & con.cases
government will have to solve many issues pertaining to the legal ecosystem, on the
assimilation of data with different stakeholders focusing on governance, welfare and
the common good of the citizens. Rapid advancement in artificial intelligence and
machine learning would alter the approach of the government and the stakeholders
in solving many problems plaguing administration and policy-making. Data analytics
can offer solutions to increase accountability and drive social good, welfare policy
formulations etc. Withholding data would be detrimental to the public interest.
Though Courts have not formed any policy on open data, the larger public interest
compels the judiciary to share data with the public, stakeholders, researchers,
government etc. The Government of India announced the National Data Sharing and
Accessibility Policy in 2012. An open data platform in India has been set up by the
National Informatics Centre in compliance with the W.P.(C).Nos.26500/2020 &Dr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

con.cases Open Data Policy of India. The objectives of the policy are to have
community participation, citizen engagement to help the Government formulate
policies and to ensure better governance. The data available with the Court, if shared,
would be of immense help to many stakeholders. For example, the police will be able
to identify the issues relating to lopsided investigations. The Government will be able
to take measures regarding human trafficking, establishing Courts to tackle any
particular kind of offence etc. In the larger interest, the data collected must be shared
to benefit governance as well. Therefore, the Court cannot ignore the larger legal
ecosystem in which administration of justice operates while deciding a matter of this
nature.
IV ON THE RIGHT TO BE FORGOTTEN:
A. Evolution Of The Right To Be Forgotten:
W.P.(C).Nos.26500/2020 & con.cases
23. The right to be forgotten is a right that developed as a consequence of the dignity
of an individual, adopted to forget the past and live in the present. It is based on the
broader rights in Articles 7 and 8 of the Charter of Fundamental Rights of the EU
(Charter). Article 7 relates to the general right to privacy of individuals.
Whereas, Article 8 grants protection of personal data as a fundamental right subject to other
fundamental rights [See Art. 52(1) of the Charter].
24. Although the Data Protection Directive of 1995 (Directive 95/46/EC) contained no express right
to be forgotten, the Court of Justice of the European Union (CJEU) in its decision in the Google
Spain v. AEPD [Case C-131/12 Judgment of the Court (Grand Chamber) Google Spain SL v. Agencia
Española de Protección de Datos (AEPD], held that an implied right existed in the Directive.
W.P.(C).Nos.26500/2020 & con.cases
25. The CJEU relied upon Articles 6, 12 and 14 of the Directive 95/46/EC to hold that individuals
have control over their personal information and a general right to "erase" said information.
"Article 6(1) unequivocally provides that personal information may not be kept for
any longer than necessary to fulfill the purpose for which the information was
originally collected. Article 12 not only grants individuals the right to block the
processing of any information that does not comply with the Directive's requirements
but also provides the right to apply to have such information erased. Article 14 grants
EU citizens the right to object to data processing and requires the controller to
comply with valid objections." [See Shaniqua Singleton, "Balancing A Right To Be
Forgotten With Right To Freedom Of Expression In The Wake Of Google Spain v.
AEPD, GA. J. INT'L & COMP. L., Vol. 44] W.P.(C).Nos.26500/2020 & con.casesDr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

26. In Google Spain v. AEPD, the grievance of the plaintiff was that links to newspaper articles
relating to his insolvency proceedings were available on a Google search of his name. Contending
that although the article was truthful, it injured his reputation and violated his privacy, thereby
warranting erasure as it was no longer relevant. Although the CJEU did not direct the removal of the
article itself which was published lawfully, it directed Google to remove links to the webpage
containing personal information on any of the four conditions, such as where information was
i)inadequate, ii)irrelevant,
iii)no longer relevant, or iv)excessive in relation to the purposes of the processing at issue. This was
to be applicable even to information published lawfully and that was factually correct. The CJEU
held:
[I]t is undisputed that activity of search engines plays a decisive role in the overall
dissemination of those data in W.P.(C).Nos.26500/2020 & con.cases that it renders
the latter accessible to any internet user making a search on the basis of the data
subject's name, including to internet users who otherwise would not have found the
web page on which those data are published.
27. The recognition of this right to be forgotten is further supported by the General Data Protection
Regulation (GDPR) which supersedes Directive 95/46/EC and expressly recognises this right.
Article 17 of the GDPR lays down when a data subject can exercise the right of erasure, the
obligation of data controllers to erase links to third-party websites, and the exceptions to the when
the right can be exercised.
B. Defining The Right To Be Forgotten:
28. The right to be forgotten is derived from the broader category of the right to privacy. Cécile de
Terwangne in her paper "Internet Privacy and the Right to be Forgotten/ Right to Oblivion", defines
the right to be forgotten as 'the right for natural persons to have information about them
W.P.(C).Nos.26500/2020 & con.cases deleted after a certain period of time.' The basis of this right
to be forgotten being 'internet privacy', this concept relates to individual autonomy, rather than
secrecy or intimacy. Terwangne writes:
In the context of the Internet this dimension of privacy means informational
autonomy or informational self determination. The Internet handles huge quantities
of information relating to individuals. Such personal data are frequently processed: it
is disclosed, disseminated, shared, selected, downloaded, registered and used in all
kinds of ways. In this sense, the individual autonomy is in direct relation to personal
information. Information self determination means the control over one's personal
information, the individual's right to decide which information about themselves will
be disclosed, to whom and for what purpose.
29. The right to be forgotten consists of various facets or forms of rights which is important in
defining the extent of this right. Professors W. Gregory Voss And Celine Castets-Renard's in theirDr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

paper "Proposal For An International Taxonomy On The Various Forms Of The "Right To Be
Forgotten":
W.P.(C).Nos.26500/2020 & con.cases A Study On The Convergence Of Norms"
categorize the right to be forgotten into five different rights. The 'right to
rehabilitation' is a right that existed prior to the digital age and refers to social
reintegration subsequent to a judicial conviction. Legislation in the United Kingdom,
France, the United States etc. provides for the erasure of conviction records subject to
the fulfillment of certain conditions. The 'right to erasure/deletion' is a right provided
by data protection legislation. It allows for the erasure of personal data where it is
inaccurate or obsolete. Article 17 of the GDPR sets out this right to erasure when the
data collected is no longer relevant for the purposes it was originally processed,
where consent is withdrawn by data subject etc. This right is subject to freedom of
speech and expression, public interest in the area of public health, archiving for
public interest etc. This right to erasure/deletion is not a W.P.(C).Nos.26500/2020 &
con.cases general right and applies only in the limited cases enumerated in the data
protection law. The authors Voss and Renard write that the right to erasure/deletion
'is not an overarching right to be forgotten, but merely the possibility to have data
deleted in certain circumstances'.
30. The 'right to delisting' and 'right to oblivion' are facets of the right to be forgotten in the digital
context. The right to delisting or de-indexing is the right of individuals to request search engines to
delink web pages containing personal information about them. The authors Voss and Renard write:
This applies where the information is inaccurate, inadequate, irrelevant or excessive
for the purposes of the data processing. This right operates in the context of search
engines' processing of personal data and, which are considered as "controllers" under
Directive 95/46170. The CJEU's decision involves a mere right to delisting (and not
to be completely forgotten) because the court orders the erasure of web links, but not
the related article. In other words, "the source is preserved". Finally, in order to
W.P.(C).Nos.26500/2020 & con.cases recognize a right to delisting, neither the
economic interest of the operator of the search engine nor the interest of the general
public in having access to that information shall prevail over the data subject's
reputation and privacy.
31. Whereas, the 'right to obscurity' according to the authors refers to making personal information
relatively hard to find. According to Hartzog and Stutzman, information is obscure online if it lacks
one or more key factors i.e. search visibility, unprotected access, identification, or clarity that are
essential for its discovery or comprehension. However, there is no legal recognition of this right at
present. [See Woodrow Hartzog & Frederic Stutzman, The Case for Online Obscurity, 101 CALIF, L.
REV. 1, 4 (Feb. 2013).]
32. The last categorisation of the right is the 'right to oblivion' which allows individuals to demand
the deletion of personal information collected by information society services. An example of thisDr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

right can be seen in the personal W.P.(C).Nos.26500/2020 & con.cases data protection law of
Nicaragua. The authors Voss and Renard, with regard to the right to oblivion, write:
The right to oblivion of data collected by information society services is a real right to
be forgotten which can be exercised without the condition of providing evidence. It is
not necessary to prove that the data are irrelevant, out-of-date, or illegal. Besides, it is
not merely a right to obscurity, because the data are deleted. Therefore, it is a broad
right to obtain the erasure, meeting a social demand for this right, especially with
respect to social network services.
33. The interpretation of the extent to which this right to be forgotten will be applicable in India, is
an important consideration in determining the liability of the different stakeholders, actors,
publishers etc. and the extent to which this right will be available in different judicial proceedings.
Whether the right is available on current as well as future claims is a question to be answered by us
in the context of the different factual matrices before us. This right to be W.P.(C).Nos.26500/2020
& con.cases forgotten is predicated on the past, as is evident from its nomenclature which includes
the term "forgotten". Therefore, it can only apply retrospectively, on information that has already
been disclosed, rather than being claimed to mask information ex-ante.
C. Right To Erasure:
34. Under Article 17 of the GDPR, individuals have the right to have their personal data erased if the
personal data is no longer necessary for the purpose for which it was collected. In the European
context, the right to erasure is considered as the right to be forgotten. However, in the Indian
context, we are looking at these concepts by relating them to fundamental rights. We may have to
distinguish this right on broader aspects. We have already observed that the right to be forgotten is
predicated on the past. The right to erasure does not depend upon the passage
W.P.(C).Nos.26500/2020 & con.cases of time or any period. Erasure means to delete. In the Indian
scenario, these rights rest on fundamental rights not like in Europe, where it is based on European
directives and more or less a regulatory mechanism exists related to data transmission or
dissemination of personal information. Therefore, the right to erasure cannot be understood in the
same manner, as we refer to the right to be forgotten. The right to be forgotten can be claimed to
erase memory to move forward in life with dignity. Whereas, when the information is incorrect or
irrelevant the right to erasure can be claimed. In a given case, a party, if implicated in a criminal
case is later, on investigation found to be innocent and has no connection with the crime involved,
such a party may be permitted to invoke the right to erasure immediately to delete all details
published online. In a claim based on the right to be forgotten, what is to be considered is the
W.P.(C).Nos.26500/2020 & con.cases interest of a party to erase memory related to events in the
past and to build a future with sincerity and good deeds and move forward in life. This is the
distinction we want to draw here. PROBLEMS STATED:
35.(a) The publication of Court judgments online in criminal matters offends the fundamental right
i.e the right to be forgotten.Dr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

35.(b) Judgments arising out of matrimonial and family disputes are purely private disputes. Law
recognizes the protection of privacy. Therefore, the publication of judgments online and allowing
them to be viewed in the digital space is violative of privacy.
35.(c) Publishers of judgments, like Indian Kanoon and other law journals, have no right to publish
the details of parties ignoring the privacy rights W.P.(C).Nos.26500/2020 & con.cases of litigants
which includes their right to be forgotten.
35.(d) The absence of a judicial policy regulating uploading of judgments containing details of
names of parties and allowing them to be indexed by search engines in the digital space is violative
of the right to privacy of litigants.
35.(e) Search engines, like Google, shall erase or redact personal data contained in the judgments
from the digital domain.
35.(f) Digital eternity in retaining judgments in the digital domain forever is violative of the
fundamental right to be forgotten. REFRAMING THE DISCUSSION ON THE JUDICIARY'S
APPROACH TO BUILDING MEASURES TO RAISE PUBLIC CONFIDENCE AND ALLOWING
JUDGMENTS CONTAINING PERSONAL DATA IN THE PUBLIC SPHERE:
W.P.(C).Nos.26500/2020 & con.cases
36. The identity of the judiciary based on public confidence is not ordinarily possible without there
being free flow of information on judicial functioning. A litigant or an accused before Court of law is
a private person on whom the public seldom shows interest to gaze. Therefore, they question why
their personal data is allowed to appear in the public sphere. On the same lines, if a litigant or
accused is a public figure, the curiosity of the public to watch judicial conduct and function is so
high. Often, the media carries headlines of breaking news with minute-by-minute details of the
Court proceedings, including what the judge spoke during the proceedings in such cases where a
public figure is involved. In open justice, as we discussed earlier, the Courtroom must afford an
opportunity to the public to form opinions about its functioning. This is the foremost consideration
in building public confidence. It is not necessarily the case details W.P.(C).Nos.26500/2020 &
con.cases of 'X' or 'Y' that a commoner wants to know, but the information on how a case of 'X' or 'Y'
is decided in the Court of law. However scant curiosity may have been shown in Court proceedings,
Courts cannot count on the number of people interested, to deny such information from coming into
the public sphere. The sense of public sphere must guide the Court in allowing judgments to come
into the public domain. Jürgen Habermas, a German philosopher and social theorist, defines the
concept of 'Public Sphere' as:
We mean first of all a realm of our social life in which something approaching public
opinion can be formed. Access is guaranteed to all citizens. A portion of the public
sphere comes into being in every conversation in which private individuals assemble
to form a public body. They then behave neither like business or professional people
transacting private affairs, nor like members of a constitutional order subject to theDr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

legal constraints of a state bureaucracy. Citizens behave as a public body when they
confer in an unrestricted fashion-that is, with the guarantee of freedom of assembly
and association and the freedom to express and publish their opinions-about matters
of general interest. In a large public body this kind of W.P.(C).Nos.26500/2020 &
con.cases communication requires specific means for transmitting information and
influencing those who receive it"
[See The Public Sphere:An Encyclopedia Article (1964) Stable URL:
http://links.jstor.org/sici?
sici=0094-033X%28197423%290%3A3%3C49%3ATPSAEA %3E2.0.CO%3B2-Z viewed on
13/12/22]
37. Courtrooms by virtue of Section 153-B of CPC and Section 327 of Cr.P.C. are statutorily public
spheres where people are allowed to view proceedings and form public opinion. The very idea of
keeping Courtrooms open to the public is to safeguard the open Court principle which is a
fundamental aspect of the democratic ecosystem.
38. The rationale behind Section 74 of the Evidence Act making judicial records public records is to
allow the public to have access to the information in such records. Indian law recognizes Open Court
justice. "The phrase 'Open Courts', refers to a longstanding practice, mostly
W.P.(C).Nos.26500/2020 & con.cases in common law countries, wherein all proceedings before a
Court of law are held in full public view. If proceedings are held in full public view it follows that
anybody, be it a court reporter or a journalist or an innovator like Indiankanoon.org can produce
such data." [See the research report on "Open Courts in the Digital Age: A prescription for an Open
Data Policy" by VIDHI Centre for Legal Policy, Page 9]. This research also refers to the
jurisprudential underpinnings of 'Open Court' practices. The research has relied on the works of
Jeremy Bentham, John Bowring (ed)(William Tait, Edinburgh 1843) 316, 355). Bentham justified
'Open Courts' on the following reasoning:
In the darkness of secrecy, sinister interest and evil in every shape have full swing.
Only in proportion as publicity has place can any of the checks applicable to judicial
injustice operate. Where there is no publicity there is no justice. Publicity is the very
soul of justice. It is the keenest spur to exertion and the surest of all guards against
improbity. It keeps the judge himself while trying under trial.
W.P.(C).Nos.26500/2020 & con.cases
39. It is pointed out in the research that Open Courts will help to ensure the integrity of the process
by acting as a check against arbitrariness, perjury and abuse of power. In Open Court proceedings,
any onlooker is entitled to watch proceedings and report any case that the Court considers. If that
cannot be prevented, can Courts prevent uploading and publishing of the judgments online? It is
here that the issue of anonymity related to privacy crops up. The parties may not have any objection
to the uploading of the judgments by masking the details of the litigants. There may be a plethora ofDr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

reasons for a litigant to prevent disclosure of the names or the content. That perhaps requires a
balancing exercise to be generally guided by the governing informational policy of the judiciary. In
the research conducted by VIDHI, they also allude to opposite interests, juxtaposing the right to
information with the right to privacy. After referring to Article 8 of W.P.(C).Nos.26500/2020 &
con.cases the Right to Information Act, 2005 the research admits that a balancing exercise has to be
evolved regarding the right to privacy and that disclosure of personal information in litigation, is in
the larger public interest. This is the problem and dilemma in these cases. We cannot ignore the
privacy rights of individuals. We also cannot ignore the larger public interest of the Court making
judicial function open to all to ensure public confidence. Section 8(1)(j) of the Right to Information
Act, 2005 exempts disclosure of information related to personal information which has no
relationship to any public activity or interest and such information if disclosed would result in an
invasion of the privacy of the individuals. We have already noted the larger public interest related to
the Open Court system. The public has every right to know how a judge conducted a particular case
with details of the parties, contents etc. The digital platform only W.P.(C).Nos.26500/2020 &
con.cases allows easy access to such information through the digital space. Nevertheless, it was
available to the public in all respects in the brick-and-mortar system as well. The mere extension of
an Open Court system in a digital space cannot itself be called violative of privacy rights, in the
absence of any law laid down in this regard by the Parliament. Law has already recognised the Open
Court system.
40. Justice Chandrachud in Justice K.S.Puttaswamy's case (supra), discussed the threefold
requirement when the right to privacy, including informational privacy, is restrained. It reads thus:
310. While it intervenes to protect legitimate State interests, the State must
nevertheless put into place a robust regime that ensures the fulfilment of a threefold
requirement. These three requirements apply to all restraints on privacy (not just
informational privacy).
They emanate from the procedural and content-based mandate of Article 21. The first requirement
that there must be a law in existence to justify an encroachment on privacy is
W.P.(C).Nos.26500/2020 & con.cases an express requirement of Article 21. For, no person can be
deprived of his life or personal liberty except in accordance with the procedure established by law.
The existence of law is an essential requirement. Second, the requirement of a need, in terms of a
legitimate State aim, ensures that the nature and content of the law which imposes the restriction
falls within the zone of reasonableness mandated by Article 14, which is a guarantee against
arbitrary State action. The pursuit of a legitimate State aim ensures that the law does not suffer from
manifest arbitrariness. Legitimacy, as a postulate, involves a value judgment. Judicial review does
not reappreciate or second guess the value judgment of the legislature but is for deciding whether
the aim which is sought to be pursued suffers from palpable or manifest arbitrariness. The third
requirement ensures that the means which are adopted by the legislature are proportional to the
object and needs sought to be fulfilled by the law. Proportionality is an essential facet of the
guarantee against arbitrary State action because it ensures that the nature and quality of the
encroachment on the right is not disproportionate to the purpose of the law. Hence, the threefold
requirement for a valid law arises out of the mutual interdependence between the fundamentalDr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

guarantees against arbitrariness on the one hand and the protection of life and personal liberty, on
the other. The right to privacy, which is an intrinsic part of the right to life and liberty, and the
freedoms embodied in Part III is subject to the same restraints which apply to those freedoms.
W.P.(C).Nos.26500/2020 & con.cases
41. On the right to privacy written by Samuel D. Warren; Louis D. Brandeis in Harvard Law Review,
Vol. 4, No. 5. (Dec. 15, 1890), pp. 193-220, the authors opine that the right to privacy does not
extend to publications made in Court.
2. The right to privacy does not prohibit the communication of any matter, though in its nature
private, when the publication is made under circumstances which would render it a privileged
communication according to the law of slander and libel.
Under this rule, the right to privacy is not invaded by any publication made in a court of justice, in
legislative bodies, or the committees of those bodies; in municipal assemblies, or the committees of
such assemblies, or practically by any communication. made in any other public body, municipal or
parochial, or in any body quasi public, like the large voluntary associations formed for almost every
purpose of benevolence, business, or other general interest; and (at least in many jurisdictions)
reports of any such proceedings would in some measure be accorded a like privilege. Nor would the
rule prohibit any publication made by one in the discharge of some public or private duty, whether
legal or moral, or in conduct of one's own affairs, in matters where his own interest is concerned.
W.P.(C).Nos.26500/2020 & con.cases
42. Individual privacy rights must yield to the larger public interest in the absence of any legislation.
The Court has limitations in balancing interests affecting a class of individuals and that of public
interest. This exercise has to be done by the Legislature. The Court, however, may address the
fundamental rights claimed by individuals which might not have a bearing on the collective goal.
The Court cannot assume the role of the legislature to address a class and command the law. If the
Court attempts to carry out such an exercise on a notion of upholding fundamental rights, it would
in essence be encroaching upon the competency of the legislature to make laws. However, nothing
prevents the Court from adjudicating individual grievances and balancing such individual
grievances against public interest as referable under Section 8(1)(j) of the Right To Information Act,
2005 if such individual rights have reasons W.P.(C).Nos.26500/2020 & con.cases to depart. Ronald
Dworkin, in his famous book 'Taking Rights Seriously' argues that, "Individual rights are political
trumps held by individuals. Individuals have rights when, for some reason, a collective goal is not a
sufficient justification for denying them what they wish, as individuals, to have or to do, or not a
sufficient justification for imposing some loss or injury upon them." [See Introduction, pg. xi].
43. The Madras High Court in Karthick Theodre v. Registrar General, Madras High Court and
Others [2021 SCC Online Mad 2755], the judgment authored by Justice N.Anand Venkatesh,
considered the issue of whether an accused, who has been acquitted of all the charges as against
him, had the right to seek erasure of personal information from the public domain. The learned
Judge opined, at para.37, as follows:Dr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

37. There must be a proper policy formulated in this regard by means of specific
rules. In other words, some basic W.P.(C).Nos.26500/2020 & con.cases criteria or
parameters must be fixed, failing which, such an exercise will lead to utter confusion.
This Court must take judicial notice of the fact that the criminal justice system that is
prevalent in this country is far from satisfactory. In various cases involving heinous
crimes, this Court helplessly passes orders and judgments of acquittal due to slipshod
investigation, dishonest witnesses and lack of an effective witness protection system.
This Court honestly feels that our criminal justice system is yet to reach such
standards where courts can venture to pass orders for redaction of name of an
accused person on certain objective criteria prescribed by rules or regulations. It will
be more appropriate to await the enactment of the Data Protection Act and Rules
thereunder, which may provide an objective criterion while dealing with the plea of
redaction of names of accused persons who are acquitted from criminal proceedings.
If such uniform standards are not followed across the country, the constitutional
courts will be riding an unruly horse which will prove to be counterproductive to the
existing system.
44. As rightly opined by the learned Judge, formulation of uniform standards is the job of the
Legislature after evaluating various parameters and balancing different interests including the
interest of the public. The Courts cannot remain oblivious to their limitation in formulating
standards to bind different interests. We are, W.P.(C).Nos.26500/2020 & con.cases therefore, of the
view that the Court cannot prevent the dissemination of case details in the public domain citing the
privacy of individual litigants.
45. The Hon'ble Supreme Court in its judgment in R. Rajagopal alias R.R. Gopal And Another v.
State of T.N. And Others [(1994) 6 SCC 632] held that the right to privacy does not extend to Court
records and other public records.
(1) The right to privacy is implicit in the right to life and liberty guaranteed to the citizens of this
country by Article 21. It is a "right to be let alone". A citizen has a right to safeguard the privacy of
his own, his family, marriage, procreation, motherhood, child-bearing and education among other
matters. None can publish anything concerning the above matters without his consent -- whether
truthful or otherwise and whether laudatory or critical. If he does so, he would be violating the right
to privacy of the person concerned and would be liable in an action for damages. Position may,
however, be different, if a person W.P.(C).Nos.26500/2020 & con.cases voluntarily thrusts himself
into controversy or voluntarily invites or raises a controversy.
(2) The rule aforesaid is subject to the exception, that any publication concerning the aforesaid
aspects becomes unobjectionable if such publication is based upon public records including court
records. This is for the reason that once a matter becomes a matter of public record, the right to
privacy no longer subsists and it becomes a legitimate subject for comment by press and media
among others. We are, however, of the opinion that in the interests of decency [Article 19(2)] an
exception must be carved out to this rule, viz., a female who is the victim of a sexual assault, kidnap,
abduction or a like offence should not further be subjected to the indignity of her name and theDr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

incident being publicised in press/media.
46. It is true that the judgment in Rajagopal's case (supra) was rendered much before the
declaration by the Apex Court that the right to privacy is a fundamental right. However, this Court
cannot ignore the major premise on which the decision was rendered in Rajagopal's case. In
W.P.(C).Nos.26500/2020 & con.cases Rajagopal's case, the Apex Court held that publication based
on public records cannot be objected to on the ground of the right to privacy. The judicial function is
a public function and the records are treated as public records. Every litigant approaches the Court
knowing fully well that the details of the case and the details of the party would form part of the
public records.
47. We have already adverted to the nature of the right to be claimed as the right to be forgotten. It
cannot be claimed in respect of current records or proceedings before the Court. The right to be
forgotten if claimed in current proceedings would be an affront to the principle of open justice and
the larger public interest. The 'right to be forgotten' is contextually related to the past, and cannot be
claimed as a 'right in presentium'. An individual has every right to live their life in the moment,
erasing the past. This is an W.P.(C).Nos.26500/2020 & con.cases essential facet of the right to live
with dignity. Merely as in the past, he has been subject to accusation of a crime or had been involved
in a crime, shall not haunt him his entire life. The very idea of a fixed term of imprisonment is to
erase his past and move forward with a new lease of life, after the sentence. If such an individual is
not allowed to erase his past and control the information on his person, no doubt, it would violate
his right to live with dignity. However, the Court cannot make a declaration in current proceedings,
acknowledging the right to be forgotten to erase data for the current and the future. That will be
against the very essence of the recognition of the right as a right to be forgotten. The Apex Court in
the privacy judgment in para.636 of Justice K.S. Puttaswamy's case (supra),realising this aspect, put
forward as follows:
W.P.(C).Nos.26500/2020 & con.cases
636. Thus, the European Union Regulation of 2016 [ Regulation No. (EU) 2016/679
of the European Parliament and of the Council of 27-4-2016 on the protection of
natural persons with regard to the processing of personal data and on the free
movement of such data, and repealing Directive No. 95/46/EC (General Data
Protection Regulation).] has recognised what has been termed as "the right to be
forgotten". This does not mean that all aspects of earlier existence are to be
obliterated, as some may have a social ramification. If we were to recognise a similar
right, it would only mean that an individual who is no longer desirous of his personal
data to be processed or stored, should be able to remove it from the system where the
personal data/information is no longer necessary, relevant, or is incorrect and serves
no legitimate interest. Such a right cannot be exercised where the information/data is
necessary, for exercising the right of freedom of expression and information, for
compliance with legal obligations, for the performance of a task carried out in public
interest, on the grounds of public interest in the area of public health, for archiving
purposes in the public interest, scientific or historical research purposes or statisticalDr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

purposes, or for the establishment, exercise or defence of legal claims. Such
justifications would be valid in all cases of breach of privacy, including breaches of
data privacy.
48. In individual cases, the Court may, after adverting to time and space, order the erasure of past
records. However, nothing prevents the W.P.(C).Nos.26500/2020 & con.cases Legislature from
bringing in Legislation recognizing the right to be forgotten to erase such records after the expiry of
such period as it deems fit to fix. Further, laying down the grounds when such a right to be forgotten
can be exercised is the prerogative of the Legislature. As the right to be forgotten is not an absolute
right, it is crucial that the legislature enumerates the grounds when an individual can claim this
right. Art. 17 of GDPR lays down grounds such as, where information is no longer necessary,
withdrawal of consent by individuals, unlawful processing of information etc. The Article reads thus:
1. The data subject shall have the right to obtain from the controller the erasure of
personal data concerning him or her without undue delay and the controller shall
have the obligation to erase personal data without undue delay where one of the
following grounds applies:
a. the personal data are no longer necessary in relation to the purposes for which they
were collected or otherwise processed;
W.P.(C).Nos.26500/2020 & con.cases b. the data subject withdraws consent on
which the processing is based according to point (a) of Article 6(1), or point (a) of
Article 9(2), and where there is no other legal ground for the processing;
c. the data subject objects to the processing pursuant to Article 21(1) and there are no
overriding legitimate grounds for the processing, or the data subject objects to the
processing pursuant to Article 21(2);
d. the personal data have been unlawfully processed; e. the personal data have to be
erased for compliance with a legal obligation in Union or Member State law to which
the controller is subject;
f. the personal data have been collected in relation to the offer of information society
services referred to in Article 8(1).
2. Where the controller has made the personal data public and is obliged pursuant to
paragraph 1 to erase the personal data, the controller, taking account of available
technology and the cost of implementation, shall take reasonable steps, including
technical measures, to inform controllers which are processing the personal data that
the data subject has requested the erasure by such controllers of any links to, or copy
or replication of, those personal data.
W.P.(C).Nos.26500/2020 & con.casesDr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

3. Paragraphs 1 and 2 shall not apply to the extent that processing is necessary:
a. for exercising the right of freedom of expression and information;
b. for compliance with a legal obligation which requires processing by Union or
Member State law to which the controller is subject or for the performance of a task
carried out in the public interest or in the exercise of official authority vested in the
controller;
c. for reasons of public interest in the area of public health in accordance with points
(h) and
(i) of Article 9(2) as well as Article 9(3);
d. for archiving purposes in the public interest, scientific or historical research purposes or
statistical purposes in accordance with Article 89(1) in so far as the right referred to in paragraph 1
is likely to render impossible or seriously impair the achievement of the objectives of that
processing; or e. for the establishment, exercise or defence of legal claims.
The legislature alone is competent to enumerate such grounds and carve out exceptions to the
claims of such a right to be forgotten. The W.P.(C).Nos.26500/2020 & con.cases judiciary is not
competent to legislate and lay down legal norms for a class.
ANSWERING THE PROBLEMS STATED:
A. Criminal Records And The Right To Be Forgotten:
49. The demand of persons involved in criminal cases that their records have to be
erased or the names redacted based on the right to be forgotten is, essentially,
claimed in respect of the records of recent origin. The right to be forgotten can be
claimed to erase past records. The learned counsel for one of the petitioners, Shri
Johnson Gomez argued that the implication of this is that a bail order pertaining to a
client in the year 2013 alone appears in the public domain and his subsequent
acquittal from all charges finds no place in the digital domain. It was argued that in
the absence of rules, the Court shall not upload the judgment online. Similarly, Smt.
Kala T. Gopi, submitted that her client who was involved in a
W.P.(C).Nos.26500/2020 & con.cases criminal case and charge-sheeted in the year
2013, had compromised with the de facto complainant and the entire criminal case
was quashed by this Court. However, on a search online of his name, the case
quashed by this Court appears in the digital space affecting his image and denting
marriage prospects. The learned counsel Smt. Kala T. Gopi submits that the
judgment has two parts, one related to personal data of the individual and the other
related to the facts and law. It is submitted that absolutely, there was no necessity to
publish the names of the parties while uploading the judgment. Advocate Smt.Dr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

Bimala Baby appearing for one of the petitioners submitted that her client had
approached this Court aggrieved by an exhibition of a bail order online.
It is submitted that due to crawling and indexing, her client's name appears on the search engine
Google. Learned counsel points out that the moment the client's name is typed into the search
engine, W.P.(C).Nos.26500/2020 & con.cases the case details related to him appear. Shri Jacob
Sebastian appearing for another writ petitioner argued that his client is a well-known doctor and
whenever his name is typed into Google, a judgment in a bail application and criminal case appears
in the results. These cases are from the years 2017 and 2018. Similar prayers also have been made in
W.P.(C). No.20387 of 2018 to the effect of removing names and contents of the case of the petitioner
in the Criminal M.C. filed before this Court in the year 2013.
50. As adverted to earlier, the right to be forgotten can be claimed as a right to erase past memory.
The public records relating to the petitioners who were either accused or parties to the criminal
proceedings cannot be erased forever. The digital space is a dynamic space allowing vibrant data to
be refreshed without the constraints of time and space. The boundaries of W.P.(C).Nos.26500/2020
& con.cases privacy have no limitations in the digital space. In the real world, humans have
limitations created by space and time. In the normal course of human conduct, time will erase
memory. This particular problem in a digital space of allowing information to remain forever would
certainly affect the right claimed as a right to be forgotten. The internet has unlimited capacity to
remember. The Court cannot generally balance the interest claimed by the individuals and the
information available in the digital domain for eternity. The Court, no doubt, would be able to form
an opinion after adverting to the attending circumstances of a particular case to order the removal of
personal data or erasure of such data from digital space after considering the factors relating to such
cases.
51. Thus, we are of the opinion that the claim to erase or redact personal information based on the
W.P.(C).Nos.26500/2020 & con.cases right to be forgotten, in current proceedings or proceedings
concluded recently is a myth and cannot be relied on to prevent the uploading of judgments in the
Court Information System. B. The Right To Privacy Claimed In Matrimonial, Family, Custody
Matters Etc.:
52. The learned Counsel Shri B.G. Harindranath fairly submitted that the law already recognizes the
right to privacy in matrimonial, family, custody disputes etc. The counsel placed reliance on Section
22 of the Hindu Marriage Act, 1955 which reads thus:
22 Proceedings to be in camera and may not be printed or published. (1) Every
proceeding under this Act shall be conducted in camera and it shall not be lawful for
any person to print or publish any matter in relation to any such proceeding except a
judgment of the High Court or of the Supreme Court printed or published with the
previous permission of the Court.
(2) If any person prints or publishes any matter in contravention of the provisions contained in
sub-section W.P.(C).Nos.26500/2020 & con.cases (1), he shall be punishable with fine which mayDr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

extend to one thousand rupees.
53. The learned counsel also referred to Section 11 of the Family Courts Act, 1984 which reads thus:
11. Proceedings to be held in camera.-In every suit or proceedings to which this Act
applies, the proceedings may be held in camera if the Family Court so desires and
shall be so held if either party so desires. -In every suit or proceedings to which this
Act applies, the proceedings may be held in camera if the Family Court so desires and
shall be so held if either party so desires.
54. We also find that under regulation 48 of Adoption Regulation, 2022 there is a
complete bar against the publication of details of adoptive parents, name of the child,
etc., which reads thus:
48. Confidentiality of adoption records.―All agencies or authorities involved in the
adoption process shall ensure that confidentiality of adoption records is maintained,
except as permitted under any other law for the time being in force and for such
purpose, the adoption order may not be displayed on any public portal.
W.P.(C).Nos.26500/2020 & con.cases
55. Advocate Babu Paul submitted that an office memorandum has already been issued by the High
Court in relation to matrimonial matters.
56. In family, matrimonial, child custody and adoption matters, if the legislature had already
intended to protect the privacy of the parties involved therein, merely for the reason that it does not
exist in other laws related to family, matrimonial disputes etc, the Court cannot hold that the
protection to the right to privacy does not exist in such matters. The recognition of the right to
privacy as a fundamental right is of recent origin in our country. The protection accorded to privacy
in matrimonial, family disputes, custody and adoption in a slew of legislations signifies that the
open justice principle is not in contemplation of the legislature in those matters. The legislature's
wisdom to deny open Court function to the public W.P.(C).Nos.26500/2020 & con.cases is
essentially a recognition of the protective rights of the parties in relation to their privacy. In those
circumstances, we are of the considered view that in matters related to family disputes, matrimonial
disputes, child custody, invoking writ jurisdiction of this Court, the Court shall not publish details of
the parties to identify the cause before the Court if the party/ies desire so. The learned counsel Shri
Vipin V.Varghese appearing for the petitioner in WPC 6687/2017 submitted that his client
approached this Court seeking a relief invoking writ jurisdiction to conduct a marriage under the
Special Marriage Act, 1954 which never materialised in spite of this Court granting relief to
solemnise marriage with the person who resides in a foreign country under the Special Marriage
Act, 1954. According to the counsel, the Google search engine exhibits his client's name and links the
judgment delivered by this Court. W.P.(C).Nos.26500/2020 & con.cases Though this matter is not
directly arising from a Family Court jurisdiction, taking note of the fact that the jurisdiction of this
Court was invoked to solemnise the marriage, we are of the view that in such matters, on request ofDr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

the parties, the Registry shall mask the names and details of the parties, in recognition of the right to
privacy in relation to matrimonial and related affairs.
57. Similarly, it is the case of the writ petitioner in 2604/2021 that the writ petitioner had
approached this Court on an earlier occasion in a dispute related to custody. So also is the claim of
the writ petitioner in 12699 of 2021 arising from a family dispute.
C. Publishing Judgments By Indian Kanoon And In Other Online Law Journals:
58. The Case Information System software is a giant move under the initiative of the e-committee to
make the Indian Judiciary more transparent and W.P.(C).Nos.26500/2020 & con.cases more
litigant friendly. The CIS versions are available for District Judiciary and High Courts exclusively.
This Case Information System software for the District Judiciary is created under the guidance of
the e-committee, Supreme Court of India through the software team at the National Informatics
Center (NIC), Pune. The whole idea of CIS, in a nutshell, is that the litigant should be able to view
the daily status of his case, the orders of the case, hearing dates of his case, the progress of the case
on any particular date etc. online from any part of the world. [Source e- committee Of Supreme
Court Of India Website Viewed On 14/12/22] The Judgments are gold mines of data. In a few of the
cases, the challenge is in regard to permitting the use of Court Information Systems by technology
innovators in the legal domain like Indian Kanoon. On typing a subject or name of the parties, one
can easily search and find out the cases they are looking for on the Indian Kanoon
W.P.(C).Nos.26500/2020 & con.cases website. Indian Kanoon obtains judgments from the Case
Information System of Courts which are accessible and free of cost. The Courts shall have no
copyright claim over judgments as the same forms part of public records. Under the Copyright Act
1957, reproduction for judicial reporting, or reproduction or publication of judgments are not
infringements of copyright. Indian Kanoon provides access to different statutes and case laws of
various Courts and the Supreme Court of India, free of charge. The reliefs sought against Indian
Kanoon are to block the personal data of the petitioners and also to remove and erase the disclosure
of the identity of some of the petitioners herein. Though there was resistance on the side of Indian
Kanoon in regard to the maintainability of the writ petition seeking prayers against them, we are not
considering the above at this juncture for the simple reason that substantial relief is sought against
the W.P.(C).Nos.26500/2020 & con.cases publication of the judgment by the High Court on the
websites and the portal, and allowing Indiankaoon and other publishers to obtain data from Case
Information System. Advocate Santhosh Mathew, learned counsel appearing for Indian Kanoon
further submitted that the law does not prohibit the publication of public records and Indian
Kanoon never published judgments with the personal details of the parties in cases where the
anonymity of parties is protected. He also tried to distinguish between the right to be forgotten with
the right of erasure. The judgments forming part of the Court records are public documents as
referable under Section 74 of the Indian Evidence Act. There cannot be any dispute in regard to
publishing the contents of the judgment even if such judgments are ordered to be masked in regard
to the details of the parties to protect their identity. We have already overruled the right to claim
privacy in the public sphere in an Open W.P.(C).Nos.26500/2020 & con.cases Court system. The
Courtroom is open to all. The Court cannot gloss over the protection available to publishers of
judgments under Article 19(1)(a) of our Constitution. Reporting and publishing judgments are partDr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

of freedom of speech and expression and that cannot be taken away lightly without the aid of law.
D. Absence of Judicial Policy or Rules Linking Judgments Online And In Digital Space:
59. Transparency and informed consent are part of good governance in administration. Informed
consent in this context postulates that the litigant is aware that his or her personal details in the case
will be published on the Court website. The autonomy of a litigant to choose a public forum or
private forum to adjudicate disputes amenable for private adjudication is not lost sight of. In private
forums, litigants need not have such worries of publication of judgments W.P.(C).Nos.26500/2020
& con.cases in the public domain. The approach of the judiciary to help litigants be informed about
their case in an easily accessible way though is a laudable service to them, has its pitfalls. They have
not been informed about the publication of their case details online with personal identifications.
We have overruled the objections on the ground of privacy and the right to be forgotten but that
doesn't mean that the judiciary will have unbridled power over the choices exercised by a litigant
who has approached the Court seeking justice. The litigant must be put on notice about the
publication of judgments online. In many jurisdictions where strict personal data protection laws
are in force, they have adopted such a policy of informed consent. The following are the details of
the privacy notice in the judiciary in the UK.[See https://www.judiciary.uk/ (viewed on
14/12/2022)]:
What is your personal data?
W.P.(C).Nos.26500/2020 & con.cases Personal data is any information about a living
individual that can be used to identify them, for instance, name, address, date of
birth, email address, qualifications.
It may also include what are known as special categories of personal data. This is
information concerning an individual's racial or ethnic origin, political opinions,
religious or philosophical beliefs, Trade Union membership, genetic or biometric
data, health data, or data concerning their sex life or sexual orientation.
What do we mean by processing?
When we refer to processing we mean any activity the judiciary, while exercising a
judicial function, perform on or with your personal data such as collection, storage,
adaptation, destruction, or other use. This includes, but is not limited to, taking notes
during court or tribunal hearings, drafting and having published judgments or
orders.
How do we process your personal data?
The judiciary process your data consistently with data protection law. This is set out
in the UK General Data Protection Regulation, the Law Enforcement Directive and
the Data Protection Act 2018.Dr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

Why do the judiciary process your data?
The judiciary process your data in court and tribunal proceedings to carry out their
constitutional function of doing justice according to law. They do so to support the
rule of law.
W.P.(C).Nos.26500/2020 & con.cases Legal basis for processing The judiciary
process your data in the exercise of the statutory and inherent common law
jurisdiction of the courts and tribunals. They do so as this is necessary in the public
interest or in the exercise of official authority vested in them. The public interest is
the administration of justice.
The judiciary may also process your data whilst acting in a judicial capacity when to
do so is necessary to comply with legislation or where it is in their legitimate interest
to do so.
Sharing your personal data Court and tribunal proceedings are, except in exceptional
circumstances or where required by law, such as rules of court or a court or tribunal
order, required to be held in public. This is an aspect of the constitutional right to
open justice.
There is generally therefore no expectation of privacy in personal data which is
processed by the judiciary exercising judicial functions.
Your personal data may be shared by the judiciary whilst acting in a judicial capacity
with, but not limited to, ● parties to court cases and their legal representatives;
● witnesses to court cases;
W.P.(C).Nos.26500/2020 & con.cases ● other courts and tribunals in the United
Kingdom, such as the Supreme Court of the United Kingdom;
● HM Courts and Tribunals Service;
● law reporters and the media generally;
● public authorities;
● regulatory bodies; and ● the public.
Your personal data may also be shared with other courts and tribunals in other
countries where this is necessary further to the administration of justice or to comply
with, or to fulfil, legal obligations.Dr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

Publication of your personal data Personal data processed by the judiciary exercising
judicial functions may be published in court or tribunal orders or judgments. This is
necessary in the public interest of the administration of justice. It is necessary to
enable individuals to understand their rights and obligations, which is an aspect of
the rule of law.
Publication of judgments is also a requirement of the constitutional principle of open
justice and is necessary means to support the rule of law. As such it is in the public
interest.
A court or tribunal may, where it is strictly necessary in the interests of the
administration of justice, place restrictions on personal data, such as an individual's
W.P.(C).Nos.26500/2020 & con.cases name, which is placed in a judgment. It may
also hold legal proceedings in private and place restrictions on access to court and
tribunal files. Such decisions are judicial decisions and can only be taken within legal
proceedings. Individuals wishing to raise such matters should seek legal advice.
Subject Access Rights The UK General Data Protection Regulation ordinarily
provides individuals with rights concerning their personal information, such as the
right to request a copy of information held by the organisation that has processed it.
Those rights do not apply where your personal data is processed by the judiciary
exercising judicial functions.
If you wish to obtain access to personal information processed by the judiciary
exercising judicial functions you may be able to do so under provisions set out in
rules of court, such as the Civil Procedure Rules, Family Procedure Rules, Criminal
Procedure Rules or relevant Tribunal Procedure Rules. You should refer to those
rules or to information provided by His Majesty's Courts and Tribunals Service.
Further Information about Data Protection If you wish to receive further information
about data protection law generally you can contact the Information Commissioner
at:
Information Commissioner's Office Wycliffe House, Water Lane, Wilmslow, Cheshire
SK9 5AF W.P.(C).Nos.26500/2020 & con.cases Tel: 0303 123 1113 Visit the
Information Commissioner's Office website (external link, opens in a new tab) You
should be aware that where the judiciary are exercising judicial functions the
Information Commissioner has no supervisory authority.
Further Information about this Privacy Notice If you are unhappy with any aspect of
this Privacy Notice or have concerns about how your personal data was processed by
the judiciary exercising judicial functions you can contact the Judicial Data
Protection Panel. The Panel can be contacted via the Judicial Office Data Privacy
Officer at:Dr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

11th Floor Thomas More Building, Royal Courts of Justice, London WC2A 2LL Or by
email: JODataPrivacyOfficer@judiciary.uk
60. It is imperative for the judiciary to give notice of the publication of judgments and about privacy
on its websites to reflect the true character of a democratic institution. It is also desirable for the
High Court to consider the constitution of grievance redressal mechanisms and
W.P.(C).Nos.26500/2020 & con.cases also to appoint an officer to redress grievances on the
administrative side.
E. SEARCH ENGINES AND DIGITAL ETERNITY:
61. Google India and Google Global have been made party to these proceedings. A search engine is a
software programme that helps users find the information they are looking for online, using
keywords or phrases. The information in the digital space would remain there forever unless it is
erased using technological tools. The data available on the internet for eternity is a direct affront to
the right to be forgotten. Google is one of the providers of search engine. It is popularly known as
Google search. It is reported that more than 3.5 billion searches per day are handled by the search
engine. It is claimed by Google that they continuously map the web and other sources to connect
users to provide the most W.P.(C).Nos.26500/2020 & con.cases relevant and helpful information.
[See Google.com viewed on 15/12/2022].
62. The learned Senior Counsel Shri Sajan Poovayya argued in extenso and submitted that Google
neither discharges a public function nor is under the State authority. Therefore, no directions are
warranted against them. A detailed argument has been raised by the counsel stating that Google
LLC., a company incorporated in the US is not a publisher and only an intermediary. The learned
counsel relied on various judgments arising from domestic Courts and international Courts.
Pointing out to the judgment in Google LLC. v. Defteros [(2022) HCA 27] of the Australian High
Court, the counsel submitted that the act of providing hyperlinks in a search or re-search does not
amount to publication. Therefore, it is submitted that the Google search engine only enables the
parties to access information that is W.P.(C).Nos.26500/2020 & con.cases already available in the
public domain. The learned counsel further argued that the relevant provisions of Information
Technology (Intermediary Guidelines and Digital Media Ethics Code) Rules, 2021 (hereafter
Intermediary Rules) categorically recognizes and exempts transient and incidental storage from the
ambit of publishing or hosting. It is submitted that it is the publisher that is responsible for the
content it creates and, therefore, the direction is to be passed only against the publishers and not
against Google search. His argument was that intermediaries are not responsible for the unlawful
actions of third parties. The learned Counsel also raised arguments on the right to privacy claimed
by the petitioner and submitted that the right to privacy is not an absolute right but is subject to
reasonable restrictions. He also submitted that the right to know is an indivisible facet of the
Constitution. The right to privacy claimed cannot result in the W.P.(C).Nos.26500/2020 &
con.cases effacement of public records. The learned counsel relied on the judgment of the Apex
Court in Shreya Singhal v. Union of India [(2013) 12 SCC 73] and submitted that intermediaries are
not in a position to determine the legitimacy or veracity of any claims for removal in the absence of
Court order directing intermediaries to take such action. The learned Counsel appearing for GoogleDr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

India submitted that they are neither necessary nor a proper party in the proceedings as they are not
operating the search engine online. The learned Central Government Counsel relying on the
Intermediary Rules submitted that Google is an intermediary and they are also bound by the
Intermediary Rules. He referred to various rules and the nature of content in the search engine and
submitted that Google would come within the meaning of an intermediary, as defined in the Rules.
The learned Government Pleader, Shri Kannan submitted that the High Court is a Court of record
W.P.(C).Nos.26500/2020 & con.cases and publication of judgments online would only serve the
public interest.
63. We are not called upon here to determine the responsibility or liability of Google for publishing
judgments online in terms of the Intermediary Rules. The publication of the judgments online and
allowing the same to remain online forever may infringe upon the right of a party based on the right
to be forgotten. We have already adverted to the nature of a right that can be claimed as a right to be
forgotten. If the judgments of the Court are allowed to remain online for eternity, certainly, it would
invade such rights of the parties. The problem that has arisen in the absence of legislation is
determining the period or circumstances under which a party can invoke the aforesaid right. We are
not remaining oblivious to this fact. A litigant may in the future, approach this Court to
W.P.(C).Nos.26500/2020 & con.cases remove online content. In the absence of legislation, the
Court may have to recognise his right and direct removal of such content available online on a
case-to-case basis. The contention by the learned counsel for Google that they are only an
intermediary and they are not liable for the contents or publication of the judgments, no doubt, the
said contention has to be upheld. We are not here to decide upon compliance or non- compliance
with the Intermediary Rules. The argument of the learned Central Government Counsel that Google
has to be treated as an intermediary and therefore has to follow the Intermediary Rules does not
require meritorious consideration in these cases. We are called upon, in these cases, to decide on the
points involved qua fundamental rights claimed by the petitioners. Irrespective of these rules, the
State and non-State actors are bound to respect the fundamental rights of the citizens. There is no
difficulty in identifying W.P.(C).Nos.26500/2020 & con.cases Google as a non-State actor by its
nature of function and operation which could have an impact on the socio, cultural, economic and
political life of the citizen. They are qualified to be identified as a non-State actor. Even in the OECD
Guidelines for Multi-national Enterprises, guiding principles on business and human rights, an
enterprise like Google is liable as a non State actor for human rights violation. Google is
incorporated in the United States of America and OECD is an intergovernmental organisation of
which US is also a party. The Guidelines aim to promote positive contributions by enterprises to
economic, environmental and social progress worldwide. [See OECD Guidelines for Multi-national
Enterprises, 2011 Edition]. Further, there is no difficulty in holding that the claim based on
fundamental rights can be enforced horizontally. However, the judgments are public records and,
making them available to the public to view through the W.P.(C).Nos.26500/2020 & con.cases
process of a search made online, cannot be found fault with. At the same time, we cannot hold that
Google is content blind to the publications made online; can they allow any prohibited nature of
content to appear online? For example, paedophilic content. An algorithm means a set of procedures
used for solving a problem or performing a computation. In the era of artificial intelligence, it is
quite possible for Google to identify the nature of the content and remove the same. Google is not a
mere passive conduit. They are now using AI tools to identify the needs and requirements of a userDr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

online and attempting to bring out the best results in what they are looking for online. Keeping aside
the Intermediary Rules etc., we are of the firm view that Google cannot claim itself as a mere
intermediary, allowing the contents to appear for the viewers or users in the digital platform. The
publication of any valid records is protected by the Constitution W.P.(C).Nos.26500/2020 &
con.cases as forming part of Article 19(1)(a), the right to freedom of speech and expression. There is
no difficulty for Google during the era of advancement of AI to create a tool and identify particular
data and remove the same. If that is not done, it would really infringe the claim based on the right to
be forgotten.
64. In summation, we hold as follows:
i. We declare that a claim for the protection of personal information based on the
right to privacy cannot co-exist in an Open Court justice system.
ii. We hold that right to be forgotten cannot be claimed in current proceedings or in a
proceedings of recent origin. It is for the Legislature to fix grounds for the invocation
of such a right. However, the Court, having regard to the facts and circumstances of
the case and duration involved related to a crime or any other
W.P.(C).Nos.26500/2020 & con.cases litigation, may permit a party to invoke the
above rights to de-index and to remove the personal information of the party from
search engines. The Court, in appropriate cases, is also entitled to invoke principles
related to the right to erasure to allow a party to erase and delete personal data that is
available online.
iii. We declare and hold that in family and matrimonial cases, arising from the Family
Court jurisdiction or otherwise and also in other cases where the law does not
recognise the Open Court system, the Registry of the Court shall not publish personal
information of the parties or shall not allow any form of publication containing the
identity of the parties on the website or on any other information system maintained
by the Court if the parties to such litigation so insist. W.P.(C).Nos.26500/2020 &
con.cases iv. We hold that the Registry of the High Court is bound to publish privacy
notices on its website in both English and Vernacular languages.
RELIEFS:
65.(i). W.P. (C) No. 26500 of 2020: The petitioner was involved in a crime. Thereafter, based on an
order of this Court, the criminal complaint was quashed as the de facto complainant raised no
objection. We are of the view that this is not a case where the petitioner can invoke the right to be
forgotten to delete past records. We, therefore, decline the prayer and dismiss the petition.
65.(ii). W.P. (C) No. 21917 of 2020: The petitioner was involved in a crime. His grievance for
removal from the digital domain of his involvement in a criminal case and of a bail order obtained
by him cannot be acceded to. The writ petition is, therefore, dismissed. W.P.(C).Nos.26500/2020 &
con.casesDr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

65.(iii). W.P. (C) No. 8174 of 2020: The matter pertains to a habeas corpus petition. The petitioner
approached this Court alleging the detention of her daughter. We do not find any reason to hold that
the personal information shall not be published online. The writ petition fails, and is accordingly,
dismissed.
65.(iv). W.P. (C) No. 6687 of 2017: The petitioner approached this Court for solemnising marriage
under the Special Marriage Act. Since the matter is related to matrimonial and family affairs, and we
have recognised the right to privacy in such matters, we hold that the petitioner is entitled to the
relief sought. This Court has already granted interim relief in tune with the final reliefs sought. We
make the interim relief granted absolute.
65.(v). W.P. (C) No. 7642 of 2020: The petitioner was involved in a criminal case related to an
W.P.(C).Nos.26500/2020 & con.cases allegation of rape. This Court had quashed the proceedings
against the petitioner and his father. We are not inclined to grant reliefs sought for removal of the
judgment in the public domain. The writ petition fails and is, accordingly, dismissed.
65.(vi). W.P. (C) No. 20387 of 2018: The petitioner was involved in a criminal case and approached
this Court for quashing the criminal case. The petitioner and the de facto complainant settled. The
criminal case was quashed in the year 2013. According to us, the petitioner is not entitled to the
relief sought. Dismissed.
65.(vii). W.P. (C) No. 12699 of 2021: The petitioner approached this Court earlier in a Transfer
petition related to a matrimonial case. The petitioner also approached this Court in regard to a
dispute related to passport arising out of a matrimonial dispute. Considering the
W.P.(C).Nos.26500/2020 & con.cases nature of the dispute involved, and the publication of the
judgment in the public domain, we are of the view that a right to privacy would be invaded.
Accordingly, we allow this writ petition and direct Google LLC to de-index the names and also direct
the Registry to ensure Indian Kanoon hides the personal information of the parties online.
65.(viii). W.P. (C) No. 29448 of 2021: The petitioner was involved in a crime. The petitioner is
aggrieved by the publication of the order in bail online. In light of our views, Writ Petition is only to
be dismissed. Accordingly dismissed.
65.(ix). W.P.(C) No. 2604 of 2021: The petitioner had approached this Court earlier in O.P.
(FC).No.64/2019 to obtain custody of the minor child. By publication of the judgment online, the
identity and name of the child are revealed. That W.P.(C).Nos.26500/2020 & con.cases being the
case, the petitioner is entitled to relief in this case. There shall be a direction to the additional
respondent Google LLC to de-index the judgment in O.P.(FC).No.64/2019 and there shall also be a
direction to the Registry to ensure that Indian Kanoon redacts the names and personal information
of the parties or removes the publication of the judgment.
65.(x). The Registrar of the High Court of Kerala is directed to publish the privacy notice within two
months in both English and Malayalam languages on the websites of the High Court and the District
Judiciary.Dr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

All cases stand disposed of as above. No costs.
Sd/-
A.MUHAMED MUSTAQUE, JUDGE Sd/-
SHOBA ANNAMMA EAPEN, JUDGE ms APPENDIX OF WP(C) PETITIONER EXHIBITS EXHIBIT
P1 A TRUE COPY OF THE JUDGMENT DATED 07/09/2016 RENDERED IN CRIMINAL MC
NO.5477 OF 2016 BY THE HO'BLE HIGH COURT.
EXHIBIT P2 A TRUE COPY OF SCREEN SHOT WITH REFERENCE TO THE PETITIONER'S
COMMUNICATION WITH THE INDIAN KANOON. EXHIBIT P3 A TRUE COPY OF THE WEB
SITE POLICY OF THE 3RD/4TH RESPONDENT.
EXHIBIT P4 A TRUE COPY OF THE JUDGMENT RENDERED BY HON'BLE HIGH COURT OF
KARNATAKA IN WP NO.62038/2016 BY JUDGMENT DATED 23/1/2017 EXHIBIT P5 TRUE
COPY OF THE JUDGMENT OF THE HON'BLE HIGH COURT OF ORISSA, CUTTACK IN BLAPL
NO.4592 OF 2020 DATED 23/11/2020.
APPENDIX OF WP(C) 6687/2017 PETITIONER EXHIBITS EXHIBIT P1 TRUE COPY OF THE
JUDGMENT IN WP(C)NO.23996/2015 DATED 7/8/2015 EXHIBIT P2 TRUE COPY OF THE WEB
PAGE. EXHIBIT P3 TRUE COPY OF THE LETTER SEND TO THE 3RD RESPONDENT DATED
12/12/2016 RESPONDENT EXHIBITS EXHIBIT R3(a) TRUE COPY OF THE TERMS OF SERVICE
OF GOOGLE SEARCH ENGINE.
APPENDIX OF WP(C) 20387/2018 PETITIONER EXHIBITS EXT.P1: TRUE COPY OF ORDER
DATED 10.01.2013 IN CRL.M.C.NO.100/2013.
EXT.P2: TRUE COPY OF ORDER DATED 10.01.2013 IN CRL.M.C.NO.109/2013.
EXT.P3: TRUE COPY OF REQUESTS MADE BY PETITIONER'S FATHER THROUGH THE
WEBSITE OF 5TH RESPONDENT ALONG WITH THE COMMUNICATION OF 5TH
RESPONDENT.
EXT.P4: TRUE COPY OF GENERAL INFORMATION PROVIDED IN THE WEBSITE OF 5TH
RESPONDENT.
EXT.P5: TRUE COPY OF LAWYER DATED 21.03.2018 CAUSED TO THE 5TH RESPONDENT
THROUGH THEIR WEBSITE.
EXT.P6: TRUE COPY OF REPLY SENT BY 5TH RESPONDENT THROUGH E-MAIL.
RESPONDENT EXHIBITS Exhibit R3(A) TRUE COPY OF THE OFFICE CIRCULAR NO.Dr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

3/2017 DATED 21/12/20176 ISSUED BY THE 3RD RESPONDENT APPENDIX OF WP(C)
7642/2020 PETITIONER EXHIBITS EXHIBIT P1 A TRUE COPY OF THE AFFIDAVIT DATED
OCTOBER 17, 2017 FILED ON BEHALF OF THE VICTIM BEFORE THIS HONOURABLE COURT
IN BAIL APPLICATION NO. 7123/2017.
EXHIBIT P2 A TRUE COPY OF THE JUDGMENT DATED NOVEMBER 7, 2017 IN BAIL
APPLICATION NO. 7123/2017 OF THIS HONOURABLE COURT AS PUBLISHED IN
INDIANKANOON. ORG.
EXHIBIT P3 A TRUE COPY OF THE JUDGMENT DATED DECEMBER 5, 2018 IN CRIMINAL
M.C. NO. 4510/2018 OF THIS HONOURABLE COURT AS PUBLISHED IN
HTTPS//SERVICES.ECORUTS.GOV.IN/ECOURTIND IAHC/CASES/.
EXHIBIT P4 A TRUE COPY OF THE SCREENSHOT OF THE GOOGLE SEARCH RESULTS FOR
DR. KRISHNA MOHAN.
EXHIBIT P5 A TRUE COPY OF THE CORRESPONDENCE THROUGH EMAIL BETWEEN THE
PETITIONER AND THE THIRD RESPONDENT.
EXHIBIT P6 A TRUE COPY OF THE DISCLAIMER PUBLISHED ON INDIANKANOON.ORG
TITLED WHY IS MY COURT CASE ON INTERNET.
EXHIBIT P7 A TRUE COPY OF THE JUDGMENT RENDERED BY HE EUROPEAN COURT OF
JUSTEST IN GOOGLE SPAIN SL, GOOGLE IN C.V. AGENCIA ESPANOLA DE PROTECTION DE
DATOS (ES), MARIO COSTEJA GONZALEZ.
APPENDIX OF WP(C) 8174/2020 PETITIONER EXHIBITS EXHIBIT P1 TRUE COPY OF THE
JUDGMENT IN WP(CRL.) NO.266/2014 DATED 30.06.2014 EXHIBIT P1(A) TRUE COPY OF THE
DOWNLOADED JUDGMENT IN WP(CRL.) 266/2014 DATED 30.06.2014 AS PUBLISHED BY
RESPONDENTS 2 AND 3 IN THEIR WEB PAGE EXHIBIT P2 TRUE COY OF THE PRINT OUT OF
WEB PAGE OF THE 3RD RESPONDENT RESPONDENT EXHIBITS Exhibit R3(1) TRUE COPY OF
THE CERTIFICATE OF INCORPORATION OF THE 3RD RESPONDENT DATED 23/07/2014.
Exhibit R3(2) TRUE COPY OF THE BOARD RESOLUTION OF THE 3RD RESPONDENT
AUTHORIZING THE DEPONENT TO REPRESENT THE 3RD RESPONDENT.
Exhibit R3(3) TRUE COPY OF THE REPORT OF THE JOINT PARLIAMENTARY COMMITTEE ON
PERSONAL DATA PROTECTION BILL, 2019 DATED DECEMBER 16, 2021.
Exhibit R3(4) TRUE COPY OF THE ORDER OF THE HIGH COURT OF GUJARAT IN
DHARAMRAJ BHANUSHANKAR DAVE V., STATE OF GUJARAT, SCA NO.1854 OF 2015.
Exhibit R3(5) TRUE TYPED COPY OF THE CASE REMOVAL POLICY OF THE RESPONDENT,
WHICH IS DISPLAYED ON ITS WEBSITE AT HTTPS://INDIANKANOON.ORG/COURT CASEDr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

ONLINE.HTML Exhibit R3(6) A TRUE AND CORRECT COPY OF CLAUSE 20 AND CLAUSE 63 OF
DATA PROTECTION BILL, 2021. APPENDIX OF WP(C) 21917/2020 PETITIONER EXHIBITS
EXHIBIT P1 A TRUE IMAGE OF THE GOOGLE SEARCH RESULTS OF NIKHIL S RAJAN AS ON
20.09.2020.
EXHIBIT P2 A TRUE COPY OF THE BAIL ORDER DATED 9TH MAY 2014 PASSED BY THE
HON'BLE HIGHCOURT OF KERALA, IN BAIL APPLICATION NO. 2662 OF 2014.
EXHIBIT P3 A TRUE COPY OF THE JUDGMENT DATED 11.02.2019 PASSED BY THE HON'BLE
COURT OF THE II ADDITIONAL SESSIONS JUDGE, KOLLAM.
EXHIBIT P4 A TRUE COPY OF THE REPRESENTATION DATED 22.09.2020 SUBMITTED TO
RESPONDENT NO.3. EXHIBIT P5 A TRUE COPY OF THE REPRESENTATION DATED
07.10.2020 SUBMITTED TO RESPONDENT NO.1. EXHIBIT P6 A TRUE COPY OF THE
REPRESENTATION DATED 07.10.2020 SUBMITTED TO RESPONDENT NO.4. EXHIBIT P7 A
TRUE COPY OF THE REPRESENTATION DATED 07.10.2020 SUBMITTED TO RESPONDENT
NO.2. RESPONDENT EXHIBITS EXHIBIT R3(1): TRUE COPY OF THE CERTIFICATE OF
INCORPORATION DATED 23/07/2014 ISSUED BY GOVERNMENT OF INDIA, MINISTRY OF
CORPORATE AFFAIRS IN THE NAME OF THE 3RD RESPONDENT.
EXHIBIT R3(2): TRUE COPY OF THE BOARD RESOLUTION APPOINTING MR.SUSHANT
SINHA AS THE TRUE AND LAWFUL REPRESENTATIVE OF TYE 3RD RESPONDENT
COMPANY.
EXHIBIT R3(3): TRUE COPY OF THE INTRODUCTION OF THE JOINT COMMITTEE ON THE
PERSONAL DATA PROTECTION BILL, 2019.
APPENDIX OF WP(C) 21917/2020 EXHIBIT R3(4): TRUE COPUY OF THE CASE REMOVAL
POLICY OF 3RD RESPONDENT WHICH IS DISPLAYED ON ITS WEBSITE AT
HTTPS://INDIANKANOON.ORG/COURT CASE ONLINE.HTML.
EXHIBIT R3(5): TRUE COPY OF THE CLAUSE 20 AND CLAUSE 62 OF HE PERSONAL DATA
PROTECTION BILL, 2019.
EXHIBIT R3(6): TRUE COPY OF THE ORDER DATED 19/01/2017 IN SCA NO.1854 OF 2015 OF
THE HIGH COURT OF GUJARAJ AT AHMADABAD.
EXHIBIT R3(7): TRUE COPY OF THE DISCLAIMER POLICY OF 3RD RESPONDENT WHICH IS
DISPLAYED ON ITS WEBSITE AT HTTPS://INDIANKANOON.ORG/DISCLAIMER.HTML .
EXHIBIT R3(8): TRUE COPY OF THE EMAIL DATED 30/11/2018 SENT BY THE PETITIONER AS
WELL AS THE RESPONSE DATED 30/11/2018 OF RESPONDENT NO.3.Dr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

EXHIBIT R3(9): TRUE COPY OF THE EMAIL DATED 21/12/2019 SENT BY THE PETITIONER AS
WELL AS THE RESPONSE DATED 26/12/2019 OF RESPONDENT NO.3.
EXHIBIT R3(10): TRUE COPY OF THE EMAIL DATED 22/09/2020 AND REMINDER EMAIL
DATED 03/10/2020 SENT BY THE PETITIONER'S COUNSEL AS WELL AS THE RESPONSE
DATED 09/10/2020 OF RESPONDENT NO.3.
APPENDIX OF WP(C) 2604/2021 PETITIONER EXHIBITS EXHIBIT P1 A TRUE COPY OF THE
PAGE OF GOOGLE SEARCH WHEN THE PETITIONER'S NAME SEARCHED. EXHIBIT P2 A
TRUE COPY OF THE PAGE OF YAHOO SEARCH WHEN THE PETITIONERS NAME IS
SEARCHED. EXHIBIT P3 A TRUE COPY OF THE PAGE OF MICROSOFT BING WHEN THE
PETITIONERS NAME IS SEARCHED.
EXHIBIT P4 A TRUE COPY OF THE JUDGMENT DATED 06.02.2019 IN OP(FC) 64/2019.
EXHIBIT P5 A TRUE COPY OF THE WEBPAGE OF THE 2ND RESPONDENT WITH THE
PERSONAL DETAILS OF THE PETITIONER ALONG WITH THE JUDGMENT IN OP(FC)
64/2019.
EXHIBIT P6 A TRUE COPY OF THE WEBPAGE OF THE 3RD RESPONDENT WITH THE
PERSONAL DETAILS OF THE PETITIONER ALONG WITH THE JUDGMENT IN OP(FC)
64/2019.
EXHIBIT P7 A TRUE COPY OF THE REPRESENTATION DATED 22.01.2021 ALONG WITH THE
POSTAL RECEIPT.
RESPONDENT EXHIBITS Exhibit R1(A) TRUE COPY OF THE LETTER DATED 23/04/2019 SENT
BY E-COMMITTEE OF THE HONOURABLE SUPREME COURT OF INDIA TO THE
HONOURABLE THE CHIEF JUSTICE OF THE HIGH COURT OF KERALA Exhibit R1(B) TRUE
COPY OF THE HIGH COURT OFFICE MEMORANDUM NO. ECC6/35942/2019 DATED
18/05/2019 Exhibit R1(C) TRUE COPY OF THE OFFICE CIRCULAR NO.3/2017 DATED
21/12/2017 ISSUED BY THE HONOURABLE HIGH COURT OF KERALA Exhibit R1(D) TRUE
COPY OF THE OFFICE CIRCULAR NO.
2/2019 DATED 30/09/2019 ISSUED BY THE HONOURABLE HIGH COURT OF KERALA,
APPENDIX OF WP(C) 2604/2021 Exhibit R1(E) TRUE COPY OF THE OFFICE CIRCULAR NO.
4/2020 DATED 22/12/2020 ISSUED BY THE HONOURABLE HIGH COURT OF KERALA
APPENDIX OF WP(C) 12699/2021 PETITIONER EXHIBITS Exhibit P1 A TRUE COPY OF THE
JUDGMENT IN WPC 20773/2010 RENDERED BY THIS HONBLE COURT DATED 10.8.2010
Exhibit P2 A TRUE COPY OF THE ORDER IN TRPC 353/2013 DATED 22.7.2014 OF THIS HOBLE
COURT Exhibit P3 TRUE COPY OF THE SCREEN SHOT OF THE SEARCH RESULTS OF THE
5TH RESPONDENT Exhibit P4 TRUE COPY OF THE SCREENSHOTS OF THE JUDGMENT IN
WPC NO 20773 OF 2010 FROM THE WEBSITE OF THE 6TH RESPONDENT Exhibit P5 TRUEDr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

COPY OF THE SCREENSHOTS OF THE JUDGMENT IN TRPC NO 353 OF 2014 FROM THE
WEBSITE OF THE 6TH RESPONDENT Exhibit P6 A TRUE COPY OF THE COMMUNICATION
FROM THE E-COMMITTEE OF THE HONBLE SUPREME COURT OF INDIA TO ALL HIGH
COURTS DATED 16.7.2013 Exhibit P7 TRUE COPY OF THE EXPLANATION OF THE 6TH
RESPONDENT PUBLISHED ON HIS WEBSITE RESPONDENT EXHIBITS Exhibit R2(a) TRUE
COPY OF THE LETTER DATED 23/04/2019 Exhibit R2(b) THE TRUE COPY OF THE OM DATED
18/5/2019 Exhibit R2(c) TRUE COPY OF THE OFFICE CIRCULAR NO.3/2017 DATED 21.12.2017
Exhibit R2(d) TRUE COPY OF THE OFFICE CIRCULAR NO.2/2019 DATED 30.09.2019 Exhibit
R2(e) TRUE COPY OF THE OFFICE CIRCULAR NO.4/2020 DATED 22/12/2020 APPENDIX OF
WP(C) 29448/2021 PETITIONER EXHIBITS Exhibit P1 TRUE COPY OF THE JUDGMENT DATED
16.10.2020 PASSED BY THIS HON'BLE COURT IN B.A NO. 6482/2020.
Exhibit P2 TRUE COPY OF THE WEB PAGE SHOWN IN GOOGLE.
Exhibit P3 TRUE COPY OF THE LETTER SEND TO THE 3RD RESPONDENT DATED 22.10.2021
BY THE PETITIONER.Dr.Krishna Menon vs High Court Of Kerala on 22 December, 2022

