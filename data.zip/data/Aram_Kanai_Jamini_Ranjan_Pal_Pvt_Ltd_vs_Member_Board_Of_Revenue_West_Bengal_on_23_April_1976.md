Aram Kanai Jamini Ranjan Pal Pvt. Ltd vs Member Board Of
Revenue, West Bengal on 23 April, 1976
Equivalent citations: 1976 AIR 1545, 1976 SCR 110, AIR 1976 SUPREME
COURT 1545, 1976 3 SCC 369, 1976 TAX. L. R. 1773, 1977 (1) SCJ 270, 1976 8
STA 10, 1976 SCC (TAX) 285, 38 STC 1
Author: Jaswant Singh
Bench: Jaswant Singh, A.C. Gupta
           PETITIONER:
ARAM KANAI JAMINI RANJAN PAL PVT. LTD.
        Vs.
RESPONDENT:
MEMBER BOARD OF REVENUE, WEST BENGAL
DATE OF JUDGMENT23/04/1976
BENCH:
SINGH, JASWANT
BENCH:
SINGH, JASWANT
GUPTA, A.C.
CITATION:
 1976 AIR 1545            1976 SCR  110
 1976 SCC  (3) 363
ACT:
     Bengal Finance (Sales Tax) Act, 1941-S. 20(3)-Scope of-
Additional  Commissioner  reassessed  turnover  taking  into
consideration material  not available to assessing authority
competent.
HEADNOTE:
     Section 20(3)  of the  Bengal Finance  (Sales Tax) Act,
1941 provides  that the Commissioner, Upon application or of
his own  motion, may  revise why  assessment made  or  order
passed under  the Act  or the  Rules thereunder  by a person
appointed under  s. 3 to assist him and the Board of revenue
may,  in  like  manner,  revise  any  order  passed  by  the
Commissioner.
     At the  time of assessment of the appellant's sales taxAram Kanai Jamini Ranjan Pal Pvt. Ltd vs Member Board Of Revenue, West Bengal on 23 April, 1976

return the  Commercial    Tax  officer  enhanced  the  gross
turnover and  charged the  enhanced amount  to  tax  and  in
addition imposed  a penalty. On appeal under s. 20(1) of the
Act, the  Assistant Commissioner  reduced the enhancement of
gross    turnover  is as  well as the penalty. The appellant
filed a  revision application  before  the  Commissioner  of
Commercial Taxes. Before the filing of revision application,
under orders  of the  Additional Commissioner an enquiry was
conducted by  a Commercial Tax officer who detected numerous
discrepancies of  a serious  nature in  the accounts. On the
basis of  this report,  the Additional Commissioner enhanced
the assessment by a huge sum and charged the entire enhanced
amount to  tax. On further revision to the Board of Revenue,
the appellant  contended that  while exercising his power of
revision under  s. 20(3) of the Act, the Commissioner had to
confine himself  to an  examination of  the mate rial before
the assessing  officer and  could not  take additional facts
into consideration which plea was rejected by the Board.
     The High  Court  held  that  (1)  under  s.  20(3)  the
Additional Commissioner  as competent  to reassess the gross
turnover by  taking into consideration additional   material
which had  not been  made available to the assessing officer
and  (ii)   the  Additional  Commissioner  was  vested  with
authority under.  s. 20(3)  read with  r. 80A to rely on the
report under  s. 14(1)  initiated long  before the filing of
the revision petition.
     Dismissing the appeal,
^
     HELD: The  Commissioner or Additional Commissioner can.
in exercise  of his revisional power, re-assess the turnover
and while  doing so,  rope in  the escaped items of turnover
and thereby enhance the gross turnover [116G]
     (1) The  word "Revise", the dictionary meaning of which
is 'to  re-examine, to  review, to  correct or  to amend the
fault", is  not hedged  or. qualified  by any  condition  or
limitation.  The   controlling  expressions  like  "for  the
purpose  of   satisfying  himself  as  to  the  legality  or
propriety of  the order  passed ed"  or "regularity  of flue
proceedings" which  are susceptible  of being  construed  as
restricting the  revisional power  to  rectification  of  an
illegality or  impropriety of  the order or of' irregularity
in the  proceeding are  also not  be found  therein There is
also nothing  in the  Bengal Sales  Tax Rules.  1941 to  cir
circumscribe or  limit the  power.  It  is  not,  therefore,
unreasonable to  infer  that  the  amplitude  of  the  power
conferred on the Commissioner or the Additional Commissioner
is more  extensive than  the power  exercisable by  the High
Court under s. 115 of the Code of Civil Procedure. It can be
eerily equated  with the  power exercisable be the appellate
authority in  an appeal  under sub. . 2 of s. 20 of the Act.
[115F-H]
111
     Indira Sohanlal  v. Custodian of Evacuee Property DelhiAram Kanai Jamini Ranjan Pal Pvt. Ltd vs Member Board Of Revenue, West Bengal on 23 April, 1976

and Others  A.I.R. 1956  S.C. 77:  East Asiatic  Co. (India)
Ltd. v. The State of Madras 7 S.T.C. 299, State of Kerala v.
K. M.  Cheria Abdulla  & Co.  [1965] 16 S.T.C. 875, Swastik.
Oil Mills  Ltd. v. H. B. Munshi Deputy Commissioner of Sales
Tax. Bombay  [1968] 2  S.C.R. 492,  State of  Madras v.  The
Madura Knitting Co Ltd. (1959) 10 S.T.C. 155, referred to.
     Deputy  Commissioner  of  Agricultural  Income-Tax  and
Sales Tax  , Quilon and Anr. v. Chanalakshmi Vilas     Cashe
w Co.  (1969) 24  S.T.C. 491,  The State  of  Kerala  v.  M.
Appukutty (1963) 14 S.T.C. 242 and Commissioner. (of income.
tax, Bombay  v. Shapoorji  Pallonji Mistry  (1962) 44 I.T.R.
891, distinguished.
     (2) on  a combined  reading of s. 20(3) and rule 80A of
the Rules it is immaterial whether the Commissioner proceeds
to make the enquiry before or after tho filing of a revision
petition so  long he  affords to  the person  likely  to  be
adversely affected  by his  action an  opportunity of  being
hearer [119 H]
     In the  instant case, the Commercial Tax officer called
upon to  make on  enquiry, gave  adequate opportunity to the
appellant to  explain the  discrepancies And  the suspicious
circumstances, relating to the alleged suppression bn of the
turnover and  the Additional Commissioner gave notice to the
former and  furnished him with a full copy of the report. It
cannot  be   said  that   the  Commercial  Tax  officer  and
Additional Commissioner  committed any  illegality or breach
of any  statutory provision  or  rule  or  transgressed  the
limits of their jurisdiction. 1120 A-C
JUDGMENT:
CIVIL APPELLATE JURISDICTION: Civil Appeals Nos. 669 and 670 of 1971.
Appeal by Special Leave from the Judgment and order dated the 11th June, 1970 of the Calcutta
High Court in Sales Tax reference No. 395 of 1969.
S. T. Desai, H. S. Parihar and 1. N. Shroff, for the Appellant. E L. N. Sinha, Solicitor General,
Sukumar mar Basu and G.
5. Chatterjee for respondent in C.A. 669/71.
Leila Seth, Sukumar Basu, G. S. Chatterjee, for Respondent in C.A. 670/71.
The Judgement of the Court was delivered by JASWANT SINGH, J.-These two appeals Nos. 669 and
670 of 1971 by special leave from the common judgment dated June lt, 1970 of the High Court at
Calcutta in Sales Tax References Nos. 395 of 1965; and 521 of 1967 which raise important questions
as to the scope and extant of the revisional power of the Commissioner, Commercial Taxes, under
section 20(3) of the Bengal Finance (Sales Tax) Act;, 1941 (Act VI of 1941) (hereinafter referred to asAram Kanai Jamini Ranjan Pal Pvt. Ltd vs Member Board Of Revenue, West Bengal on 23 April, 1976

the Act'), and shall be disposed of by this judgment.
The facts giving rise to these appeals are: The appellant which is a Private Limited Company,
incorporated under the Indian Companies Act, 1913, and is registered as a dealer under the Act
submitted a return for 4 quarters ending with the last date of Chaitra, 1364 B.S. (corresponding to
the period commencing with April 14, 1957, And ending with April 13, 1958) showing a gross
turnover of sales of Rs. 35,93,402/- By his order dated December 7, 1959, the Commercial Tax
officer, Rajakatra Charge, rejected the appellant's books of accounts on the ground of absence of
purchase and sale vouchers and of stock statements and enhanced the gross turnover shown by the
appellant by Rs. 50,000/- and charged the entire enhanced amount to tax subject to deduction
under section 5(2)(be of the Act. He also imposed a penalty of Rs. 1,000/- under section 11(1) of the
Act. On appeal under section 20(1) of the Act, the Assistant Commissioner, Commercial Taxes,
Burrabazar Circle, by his order dated September 10, 1960, reduced the enhancement of gross
turnover from Rs. 50,000/- lo Rs. 25,000/- and the penalty from Rs. 1,000/- to Rs. 500/-. Not
satisfied with this reduction, the appellant moved The Commissioner, Commercial Taxes, West
Bengal, in revision under section 20(3) of` the Act on November 10, 1960. I before the filing of the
said revision petition, the Commercial Tax officer, Central Section, to whom power under section
14(1) of the 11 Act has been duly delegated started an enquiry on January 20, 1960 to the and served
on the appellant a notice dated October 25, 1960 to the following effect:-
"You are hereby directed to furnish the undersigned with the serial Nos. Of the cash
memos printed by you in 1363 B.S., 1364 B.S., 1365 B.S., 1366 B.S. and 1367 B.S. The
names of the suppliers of these memos relevant bills Nos. and dates, amount, dates of
payment and modes of l payment also are to be indicated. I The information may be
supplied to the undersigned on 31st October, 1960 at 4 p.m. positively."
In response to the notice, the appellant appeared before the Commercial Tax Officer, who after
hearing the former and examining the cash memos and other material submitted a report of the
investigation made by him to the Assistant Commissioner, Central Section observing inter alia that
two original cash memos issued by the appellant bearing serial No. 30727-26 dated January 24 for
Rs. 69.50 in respect of sale of Banarsi Saree and No. 31310-37 dated December 25, 1966 for Rs.
62.20 in respect of sale of ready- made garments were not properly recorded in the appellant's
books of accounts and records and that on reference to the appellant's books of accounts and cash
memos, it had been found that cash memo No. 30727-26 was issued in respect of mill-made cloth
for Rs. 11.75 on August 18, 1964 and not in respect of Banarsi saree for Rs. 69.50 an January 24 and
cash memo No. 31310-37 was issued in respect of sale of mill-made cloth for Rs. 9.37 and not in
respect of sale of already-made garments for Rs. 62.20 on December 25, 1966. He also observed in
his report that in cash memo No. 31310-37, the date appeared to have been tampered with by
subsequent insertion of the numerals "66" after the date of issue and that the actual date appear ed
to be December 25 and that the appellant had not been able to furnish a satisfactory explanation
with regard to these discrepancies. The Commercial Tax officer further stated in his report that his
investigation revealed that the appellant got duplicate sets of 1,00,000 cash memos bearing serial
Nos. 2850 to 29500 and 30501 to 31500 printed and supplied by M/s Blackwoods India Limited
and did not record sales to the extent of Rs. 30,00,000/- which in the absence of any evidence to theAram Kanai Jamini Ranjan Pal Pvt. Ltd vs Member Board Of Revenue, West Bengal on 23 April, 1976

contrary appeared to be entirely taxable. This report was received by the Additional Commissioner,
Commercial Taxes, while the aforesaid revision petition was still pending before him. he, thereupon
gave the following notice to the appellant:-
"on discovery of fresh materials, as reported by the Commercial Tax officer, Central
Section, in his report dated 27-12-60 (copy enclosed), it appears that you have
suppressed sales "estimated to be Rs. 30,00,000 in respect of the assessment of four
quarters ending Chaitra 1364 B.S. The above revision petition which has been filed
before me is against the appellate order in respect of the assessment for the said
period. It also appears that sales to the extent of Rs. 30,00,000 (estimated) escaped
taxation from the original assessment and consequently from the Assistant
Commissioner's appellate order. The above revision petition will be heard by me on
5-10-61 at 11.30 a.m. and the report dated 27-12-60, submitted by the Commercial
Tax officer, Central Section, will be considered at the time of hearing of the revision
petition. You should, therefore, appear before me on that date at the hour fixed either
in person or by a duly instructed agent to represent your case, failing which the
matter will be decided ex-parte without any further reference to you."
In reply to the notice, the appellant wrote back denying that it had any transaction with M/s
Blackwoods India Ltd. in relation to the printing of the duplicate sets of the cash memos in question
and stating inter alia that on the matter being referred to the later, they could not say from whom
actually, the order in question was received nor could they give any relevant particulars. It was
further added by the appellant that the proposed enhancement of gross and taxable sales by Rs.
30,00,000/- was unjustified and unwarranted.
The Additional Commissioner disposed of the revision petition be enhancing the assessment by Rs.
20,00,000/- as against the admitted gross turnover of Rs. 35,93,402/- and charged the entire
enhanced amount of Rs. 20,00,000/- to tax subject to deduction under section 5 (2) (b) of the Act,
The appellant thereupon took the matter in further revision to the Board of Revenue, West Bengal
contending that the conclusions arrived at by the Additional Commissioner, Commercial Taxes were
wholly unwarranted and that while exercising his power of revision under section 20(3) of the Act,
the Commissioner had to confine himself to the examination of the material before the Assessing
officer and could not take additional facts into consideration. The Board negatived both the
contentions and rejected the revision application. Thereupon the appellant made an application to
the Board under section 21(1) of the Act requesting that the points of law arising 10-833SCI/76 from
its decision be referred for decision to the High Court. Although at the hearing of the application,
the appellant stressed that reference be made on three points, the Board allowed the application in
part and referred only the following question of law for decision to the High Court:-
Whether on the Facts and circumstances of the case, in 5 exercise of his powers under
section 20(3) of the Bengal Financc (Sales Tax) Act, 1941, the Additional
Commissioner was competent to reassess the gross turnover of the petitioner by
taking into consideration additional material which had not been made available to
the assessing officer"Aram Kanai Jamini Ranjan Pal Pvt. Ltd vs Member Board Of Revenue, West Bengal on 23 April, 1976

The appellant did not rest content with this limited reference and made an
application under sub-sections 2(b) and (3) of section 21 of the Act to the High Court
which directed the Board to submit for its decision The following further question of
law:-
"Whether on the facts admitted or found by the Tribunals below, the Additional
Commissioner of Commercial Taxes was vested with the authority or jurisdiction,
under sub-section (3) of section 20 of the Bengal Financc (Sales Tax) Act, 1941, read
with rule 80A of the Rules framed thereunder to admit or rely on the purported
report, dated December 27, 1960, of The Commercial Tax officer of the Central
Section, pursuant to the enquiry, under subsection (1) of section 14 of the said Act,
initiated long before The filing of the revision petition in question by the petitioner
before the Commissioner of Commercial Taxes, West Bengal ?"
The Board thereupon referred the above quoted second question of law as well to The High Court for
its decision.
After hearing The appellant and the Revenue, the High Court by its common judgment dated June
11, 1970 answered both the aforesaid questions in the affirmative. Aggrieved by this judgment of the
High Court, the appellant applied for and obtained special leave to appeal to this Court.
Appearing for the appellant, Mr. Desai has strenuously urged that the revisional power of the
Additional Commissioner under section 20(3) of the Act was a limited one and he was not
competent to act as an original assessing authority and reassess the gross turn over by taking into
consideration the additional material comprising fresh sources of revenue which was not available
to the Assessing officer. He has further urged that the Additional Commissioner, could not admit or
rely on the report dated December 27, 1960, of the Commercial Tax officer, Central Section, based
on the enquiry under section 14(1) of the Act which was initiated long before The filing of The
revision application before the Commissioner, Commercial Taxes. West Bengal.
Though both these contentions are inextricably linked up, we shall deal with them separately.
Turning to the first contention, we wish to make it clear that the scope and ambit of the revisional
jurisdiction varies from statute to statute and it is difficult to make general observations in regard
thereto. For ascertaining the true scope, content and ambit of the revisional jurisdiction of the
Commissioner or the Additional Commissioner, as the case may be, of Commercial Taxes under the
Act, it is necessary to notice section 20 thereof which in so far as is material for the purpose of these
appeals stood thus at the relevant time:-
"20(3). Subject to such rules as may be prescribed and for reasons to be recorded in
writing, the Commissioner upon application or of his own motion may revise any
assess made or order passed under this Act or the rules thereunder by a person
appointed under section 3 to assist him, and subject as aforesaid, the Board of
Revenue may, in like manner, revise any order passed by the Commissioner :Aram Kanai Jamini Ranjan Pal Pvt. Ltd vs Member Board Of Revenue, West Bengal on 23 April, 1976

Provided that before rejecting g any application for the revision of any such order the
Commissioner or the Board of Revenue, as the case may be, shall consider it and shall
record reasons for such rejection.:
Provided further that no application for revision shall lie to the Commissioner in
respect of any assessment if an appeal lies under sub-section (1) to the Commissioner
in respect of such assessment (5) Before any order is passed under this section which
is likely to affect any person adversely, such person shall be given reasonable
opportunity of being heard."
The section as extracted above is very widely worded. The word 'revise' occurring therein (which in
dictionary is describe as meaning to 'reexamine, to review, to correct, or to amend the fault') is not
hedged or qualified by any condition or limitation. The controlling expressions like 'for the purpose
of satisfying himself as to the legality Or' propriety of the order passed' or 'regularity of the
proceeding' which are susceptible of being construed as restricting the reversional power to
rectification of an illegality or impropriety of the order or of irregularity in the proceeding are also
not to be found therein. There is also nothing in the Bengal Sales Tax Rules, 1941 (hereinafter called
'the Rules') to circumscribe or limit the power. It is not, therefore, unreasonable to infer that the
amplitude of the power conferred on the Commissioner or the Additional Commissioner is more
extensive than the power exercisable by the High Court under section 115 OF the Code of Civil
Procedure. In fact, it can be easily equated with the power exercisable by the appellate authority in
an appeal under sub-section (2) of section 20 of the Act. We are fortified in this view by the
following observations made by this Court in Indira Sohanial v. custodian of Evacuee Property Delhi
and others(1).
(1) A T R. 1956 S. C. 77.
"Section 27 is very wide in its terms and it cannot be construed as being subject to
any limitation such as filing of an appeal. Nor can the scope of revisional powers be
confined only to matters of jurisdiction or illegal lithe, because under s. 27 the
Custodian General, can exercise revisional powers for the purpose of satisfying
himself as to "the legality or propriety" of any order of the Custodian- The following
observations made by Ramaswami, J. in East Asiatic Co. (India) Ltd. v. The State of
Madras(1) are also relevant :-
"The purposes of this Act are two fold, viz., the levy of a general tax on the sale of
goods to supplement the lost revenues and for promoting the general public good;
and secondly, to see that this is done under the provisions of the Act and not by
carrying out in a capricious or arbitrary manner. Therefore, a revisional authority has
to be created. What is revision ? The essence of revisional jurisdiction lies in the duty
of the superior tribunal or officer entrusted with such jurisdiction to see that the
subordinate tribunals or officers keep themselves within the bounds prescribed by
law and that they do what their duty requires them to do and that they do it in a legal
manner. This jurisdiction being one of superintendent and correction in appropriateAram Kanai Jamini Ranjan Pal Pvt. Ltd vs Member Board Of Revenue, West Bengal on 23 April, 1976

cases, it is exercisable even suo motu as is clear from the numerous statutory
provisions relating to revision found in various Acts and Regulations such as the Civil
Procedure Code, Criminal Procedure Code, Income Tax Act, etc. The jurisdiction of
suo motu revision is not cribbed and cabined or confined by conditions and
qualifications. The purpose of such an amplitude being given Suo motu revisions
appears to be as much to safeguard the interests of the exchequer as in the interests
of the assesses. The State can never be the appellant and if there is an order against
the State to its prejudice, and naturally the assesses in whose favour the order is
passed does not prefer an appeal, the State would suffer unless its interests are
safeguarded by the exercise of such supervisory jurisdiction as the one given to the
authorities above mentioned."
Thus the Commissioner or the Additional Commissioner can, in exercise of his revisional power,
re-assess the turnover and while doing so rope in escaped items of turnover and thereby enhance
the gross turnover.
Having found that the power of revision exercisable by the Com missioner, Commercial Taxes is not
tramelled by any limitation, let us now see whether the commissioner while exercising the revisional
power is confined to the order of assessment and the record of pro-
T.C. 299 ceedings of the Assessing officer or can he travel outside the same and re-assess the gross
turnover by taking additional material under consideration. The following observations made in the
majority judgment of this Court in the State of Kerala v. K. M. Cheria Abdulla Co.(1) are helpful in
deciding this matter:-
"The words of section 12(2) of the Madras General Sales Tax Act, 1939, that the
Deputy Commissioner 'may pass such order with respect thereto as he thinks fit'
means such order as may in the circumstances of the case for rec rectifying the defect
be regarded by him as just. Power to pass such order as the revising authority thinks
fit may in some cases include power to make or direct such further enquiry as the
Deputy Commissioner may find necessary for rectifying the illegality or impropriety
of the order, or irregularity in the proceeding. It is therefore not right baldly to
propound that in passing an order in the exercise of his revisional jurisdiction, the
Deputy Commissioner must in all cases be restricted to the record maintained by the
Officer subordinate to him, and can never make enquiry outside that record.
Therefore, conferment of power under rule 14-A of the Madras General Sales Tax
Rules, 1939, to make further enquiry in cases where after being satisfied about the
illegality or impropriety of the order or irregularity in the proceeding, the revising
authority thinks it just for rectifying the defect to do so does not amount to enlarging
the jurisdiction conferred by section 12(2)."
It will also be apposite in this connection to refer to the following operations made by the Madras
High Court in State of Madras v. The Madras Knitting Co. Ltd.(2) "The powers given to the revising
authority under section 12(2) were not confined to errors patent on the face of the record but wouldAram Kanai Jamini Ranjan Pal Pvt. Ltd vs Member Board Of Revenue, West Bengal on 23 April, 1976

extend to probing further into the records like calling for despatch registers and other evidence."
It will also be useful in this connection to refer to the decision of this Court in Swastik oil Mills Ltd.
v. H. B. Munshi, Deputy Cont missioner of Sales Tax, Bombay(3) where this Court did not accept the
principle laid down by the Andhra Pradesh High Court in State of Andhra Pradesh v. T. G.
Lakshmaiah Chetty & Sons(4), that the Deputy Commissioner of Sales Tax while exercising
revisional powers under the Sales Tax Act of 1946 or of 1953 or of 1959 could not travel beyond the
material or record that is available to the assessing authority and was not entitled to find data to
institute an enquire. so as to include additional material in order to judge the correctness of the
order sought to be revised and held:
(1) (1965) 16 S.T.C. 875. (3) [1968] 2 S. C. R.492. (2) (1959) 10 S.T.C. 155. (4) 12
S.T.C.663.
"Whenever a power is conferred on an authority to revise an order, the authority is
entitled to examine the correctness, legality and propriety of the order and to pass
such suitable orders as the authority may think fit in the circumstances of the
particular case before it. When exercising such powers, there is no reason why the
authority should not be entitled, to hold an enquiry or direct an enquiry to be held
and, for that purpose, admit additional material. The proceedings for revision, if
started suo motu, must not of course be based on a mere conjecture and there should
be some ground for invoking the revision powers. Once these powers are invoked, the
actual interference must be based on sufficient grounds, and, if it is considered
necessary that some additional enquiry should be made to arrive at a proper and just
decision, there can be no bar to the revising authority holding a further enquiry or
directing such an enquiry to be held by some other appropriate authority. 'This
principle has been clearly recognised by this Court in the State of Kerala v. Abdullah
and Company (1965) 16 S.T.C. 875."
The decisions of this Court in Deputy Commissioner of Agricultural income tax and Sales Tax,
Quilon and Anr. v. Dhanalakshmi Vilas Cashew Co.(1) the State of Kerala v. V.M. Appukutty and
Commissioner of Income-tax, Bombay v. Shapoorji Pallonji Mistry(3) relied upon by Mr. Desai in
support of his contention that while exercising his revisional power under section 20(3) of the Act,
the Com Commissioner cannot travel outside the return made by the assessee and the assessment
order passed by the Sales Tax officer with a view to finding out suppressed or escaped items of
turnover and enhance the assessment are distinguishable as in all those cases there were specific
and separate provisions which enabled escaped turnover or income being brought to tax after
following a special procedure. In Dhanalakshimi Vilas Cashew Co`s case (supra), there was rule 33
of Kerala General Sales Tax Rules, 1950, in M. Appukutty case (supra), there was rule 17 of the
Madras General Sales Tax Rules, 1939; and in Shapoorji Pallonji Mistry`s case (supra) there were
sections 34 and 33B of the Income Tax Act, 1922 which enabled escaped turnover or escaped income
to be brought to tax. In the Act before us, however there are no separate or specific provisions for
assessment of` escaped turnover which may, by implication, be said to exclude from the ambit of the
revisional jurisdiction of the Commissioner the taking of additional facts into consideration andAram Kanai Jamini Ranjan Pal Pvt. Ltd vs Member Board Of Revenue, West Bengal on 23 April, 1976

enhancing the gross turn over.
In view of the foregoing discussion we have no hesitation in repelling the first contention raised on
behalf of the appellant by Mr. Desai and in holding that the High Court was right in answering the
First question referred to it by the Board of Revenue in the affirmative.
This takes us to the second contention advanced on behalf of the appellant which is covered by the
second question referred by the (1) (1969) 24 S.T.C. 491.
(2) (1963) 14 S.T.C.242.
(3) (1962) 44 I.T.R. 891.
Board of Revenue at the requisition of the High Court. For effectively dealing with this contention, it
is necessary to advert to the following two previsions viz. section 14 of the Act and rule 80A of the
Rules:
"14. (1) The Commissioner may, subject to such conditions as may be prescribed,
require any dealer
(a) to produce before him any accounts, registers or documents,
(b) to furnish any information, relating to stock of goods of, or purchases, sales or
deliveries of goods by, the dealer or relating to any other matter, as may be deemed
necessary for the purposes of this Act.
(2) (a) All accounts, registers and documents relating to the stocks of goods of, or
purchases, sales and deliveries of goods by any dealer; and
(b) all goods kept in any place of business of any dealer shall at all reasonable times
be open to inspection of the Commissioner.
(3) If the Commissioner has reason to suspect that any dealer is attempting to evade
payment of any tax under this Act, he may, for reasons to be recorded in writing,
seize such accounts, registers or documents, of the dealer as may be necessary, and
shall grant a receipt for the same, and shall retain the same only for so long as may be
necessary for examination thereof or for a prosecution.. "
"Rule 80A. The appellate or revisional authority may, before finally disposing of the
matter, make such inquiry or cause such inquiry to he made by such officer as it may
think fit."
A combined reading of the provisions of Section 20(3) of the Act and rule 80A of the Rules would
show that the., Commissioner, Commercial taxes is empowered to make or cause to be made suchAram Kanai Jamini Ranjan Pal Pvt. Ltd vs Member Board Of Revenue, West Bengal on 23 April, 1976

enquiry as he may think fit for proper exercise of the revisional jurisdiction conferred on him under
section 20(3) of the Act. It would be further noticed that the Commissioner can, under; section 14 of
the Act, call upon ,. dealer to produce any accounts, registers or documents or to furnish any
information relating to his business as may be deemed necessary. for the purpose of the Act which
include the exercise of recessional jurisdiction. It would also be noticed that the powers under
section 14 of the Act have been duly delegated to the Commercial Tax Officer. In this state of affairs,
it is immaterial whether the Commissioner proceeds to make the enquiry before or after filing of a
revision petition so long as he affords to the person likely to be adversely affected by his action, an
opportunity of being heard. In the instant case, the whole thing was duly processed s already stated.
the Commercial Tax officer, Central Section, by his notice dated October 25, 1960 gave adequate
opportunity to the appellant to explain the discrepancies in its cash memos and books of accounts.
Another opportunity to explain the suspicions circumstances relating to the alleged suppression of
the turnover as also to refute the material collected by the Commercial Tax officer, Central Section,
as a result of the investigation made by him and to show cause why action to subject the escaped
turnover to tax be not taken was afforded to the appellant by the Additional Commissioner,
Commercial Taxes, when on receipt of the ,aforesaid report dated December 27, 1960 of the
Commercial Tax officer, Central Section, he gave a notice to the former and furnished him with a full
copy of the report. It cannot therefore, be maintained with any show of force that, in admitting and
relying, on the aforesaid report dated December 27, 1960 of the Commercial Tax officer, Central
Section, the Additional Commissioner, Commercial Taxes committed any illegality or breach of any
statutory provision or rule or transgressed the limits of his jurisdiction. It will also not be out of
place to mention that the contention which is the subject matter of the second question was never
raised before the Board or Revenue as appears from the statement of the case drawn by it. We arc,
therefore, clearly of the view that the High Court was right in answering the second question also in
the affirmative.
In the result, the appeals fail and are hereby dismissed but in the circumstances of the case without
any order as to costs.
P.B.R.                                    Appeals dismissed.Aram Kanai Jamini Ranjan Pal Pvt. Ltd vs Member Board Of Revenue, West Bengal on 23 April, 1976

