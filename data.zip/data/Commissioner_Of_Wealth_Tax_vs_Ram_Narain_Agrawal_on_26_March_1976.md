Commissioner Of Wealth-Tax vs Ram Narain Agrawal on 26
March, 1976
Equivalent citations: [1977]106ITR965(ALL)
Author: R.M. Sahai
Bench: R.M. Sahai
JUDGMENT
 R.M. Sahai, J. 
1. The assessee was assessed to wealth-tax as an individual for the assessment years 1964-65,
1965-66, 1966-67 and 1967-68. The accounting years followed by the assessee were Ram Navmi
years. No voluntary returns of wealth were filed by him as required under Section 14(1) of the Act.
The Wealth-tax Officer issued notice under Section 17 of the Act calling for return of net wealth for
the assessment years which were served on the assessee on 26th of October, 1969. The returns were
filed on 18th September, 1970. The assessments were completed on 30th January, 1971, and the
Wealth-tax Officer initiated penalty proceedings under Section 18(1)(a) of the Act for delay in filing
the returns. The returns of wealth filed were belated. Against the notice under Section 18(1)(a) dated
30th January, 1971, the assessee filed an application under Section 18(2A) of the Wealth-tax Act for
waiver of penalty before the Commissioner of Wealth-tax, Lucknow, which was rejected by him.
After the rejection of the application for waiver of penalty the Wealth-tax Officer issued a fresh
show-cause notice on 28th August, 1971, which was served on the assessee but he did not appear nor
did he file any explanation. The Wealth-tax Officer in the circumstances levied penalty under
Section 18(1)(a) as in his opinion the assessee had not only not complied with the provisions of
Sub-section (1) of Section 14 of the Wealth-tax Act but also did not file the returns in time in
response to the notice issued under Section 17 of the Wealth-tax Act. The assessee filed appeals
which were dismissed by the Appellate Assistant Commissioner of Income-tax, Gorakhpur Range,
against which the assessee preferred appeals before the Tribunal. The Income-tax Appellate
Tribunal rejected the contentions raised on behalf of the assessee but allowed the appeal partly as it
was of the opinion that the increased scale of penalty was applicable only in a case where the default
in furnishing the return of net wealth occurred on or after 1st of April, 1969. After allowing the
appeal the Tribunal directed the Wealth-tax Officer to impose penalty on the scale in force prior to
the Finance Act, 1969. Aggrieved by this order an application was filed on behalf of the
Commissioner of Wealth-tax under Section 27(1) to draw up a statement of case which was allowed
and the following question was referred for the opinion of the High Court:
"Whether, on the facts and circumstances of the case, the Tribunal was right in law in
holding that the Finance Act, 1969, was not retrospective in effect and the penaltiesCommissioner Of Wealth-Tax vs Ram Narain Agrawal on 26 March, 1976

under Section 18(1)(a) of the Wealth-tax Act, 1957, were exigible in these cases for the
assessment years 1964-65, 1965-66, 1966-67 and 1967-68 on the scale in force prior
to the Finance Act, 1969?"
2. On the findings recorded by the Tribunal the only question that arises for consideration is
whether penalty has to be calculated in accordance with the provisions contained in Finance Act,
1969, or as it stood before the amendment. It has been vehemently urged by Mr. Deokinandan,
counsel for the department, that once the return was not filed a default occurred in the eye of law
and this continued till the assessee did not file the return and as the proceedings were initiated by
filing of the return at a time when the Finance Act, 1969, came into force, the law applicable in the
case of the assessee would be the law as it was amended by Finance Act, 1969, and not the
unamended law. He has cited a number of authorities in support of the proposition that it was a case
of continuous default and the Tribunal erred in applying the unamended law.
3. In the alternative he has submitted that the penalty should be levied up to 31st of March, 1969,
under the old Act and after 1st March, 1969, under the provisions of the new Act. He has placed
reliance on Jain Brothers v. Union of India [1970] 77 ITR 107 (SC), Commissioner of Income-tax v.
Data Ram Satpal [1975] 99 ITR 507 (All), Biswanath Ghosh v. Income-tax Officer [1974] 95 ITR 372
(Orissa), Municipal Board, Saharanpur v. Kripa Ram AIR 1965 All 160, Masooma Bibi v.
Mohammad Said Khan AIR 1942 All 77, State v. A.H. Bhiwandiwalla AIR 1955 Bom 161 and G.D.
Bhattar v. State AIR 1957 Cal 483.
4. On the other hand, Mr. Gulati has relied on Commissioner of Gift-tax v. C. Muthukumaraswamy
Mudaliar [1975] 98 ITR 540 (Mad), Commissioner of Income-tax v. Data Ram Satpal [1975] 99 ITR
507 (All) and Continental Commercial Corporation v. Income-tax Officer [1975] 100 ITR 170 (Mad).
A perusal of Section 18(1)(a) before and after the amendment would show that there was no change
in the clause levying penalty but the rate of penalty was vitally altered after April 1, 1969. The answer
to the question referred shall depend on two things--one the point of default and, secondly, the
applicability of law. The assessee admittedly did not file any return at the end of the period
contemplated and as such there was an infringement and it attracted the penal clause. The breach
and the application of law were simultaneous. It is a different thing that the assessee may have been
able to explain and may satisfy that there was valid ground for not complying with the provisions of
the law within the time allowed but none the less the default was there. Penalty provisions are
quasi-criminal in nature. As such it is imperative that they should be construed strictly. The law
operative on the date when the infringement takes place is the law applicable unless it is made
punishable ex post facto. If the argument of the department is accepted it shall make the operation
of the amended law retrospective when there are no such words in the statute itself. There is no
scope for culling out an intention of the legislature as the language is explicit and unambiguous. It is
well-settled both by English and Indian courts that a fiscal statute cannot be regarded as
retrospective by implication. We cannot read any intention of retrospective operation by
implication. Moreover, we are concerned with a penal provision and the rule against the
retrospectsvity applies with greater rigour in such cases. The decision in Commissioner of
Income-tax v. Data Ram Satpal [1975] 99 ITR 507 (All) does not help the department. Penalty
proceedings in this case was initiated for filing inaccurate particulars. It was held by a DivisionCommissioner Of Wealth-Tax vs Ram Narain Agrawal on 26 March, 1976

Bench that in such cases the date of default will be the date on which the return was filed. The ratio
of the decision is contained in the following sentence:
"In our opinion, the law which will apply to penalty proceedings will be the law as it
stood on the day on which the default is committed."
5. The default in cases of non-filing of return takes place after the expiry of time or notice whereas
default in cases of filing inaccurate particulars arises only when the return is filed. The other two
decisions, Jain Brothers v. Union of India [1970] 77 ITR 107 (SC) and Biswanath Ghosh v.
Income-tax Officer [1974] 95 ITR 372 (Orissa), are equally of no assistance. The first decision was
concerned with the validity of Section 18. The argument raised regarding Articles 14, 19(1)(f) and
265 of the Constitution was rejected. The other decisions related to the levy of interest under the
provisions of the Income-tax Act. The scope of the two Sections 139, relating to interest, and 271,
relating to penalty (in pari materia to Section 18(1)(a) of the Wealth-tax Act) are entirely different.
The last decision, Jain Brothers v. Union of India [1970] 77 ITR 107 (SC) was concerned with the
validity of Section 297(2)(g) of the Income-tax Act. It was held that the provisions were not hit by
Article 14 of the Constitution of India and the legislature in fixing the date, i.e., 1st April, 1962, for
the applicability of the amended and unamended law did not act arbitrarily. The other four decisions
were in support of the submissions as to what is meant by continuing default. It has been urged that
the default which occurred before the Act was amended ceased only after the returns were filed in
1970 and the occasion to impose penalty having arisen at a time when the Finance Act, 1969, had
come into force, the court below should have calculated the penalty in accordance with the amended
law. By filing of the return the default did not cease. It had already taken place and the assessee by
his act only absolved himself from computation of penalty for future. Once the law has applied it
shall apply to the entire period of default. It cannot be said to be in a state of suspension. We may
further point out that the question referred for our opinion is only in regard to the applicability of
the Finance Act, 1969, with retrospective effect. No argument appears to have been raised on behalf
of the department before the Tribunal that penalty up to April 1, 1969, should be levied in
accordance with the unamended Act and thereafter under the amended Act nor has any such
question been referred. The decision more in point is one on which reliance has been placed by Mr.
Gulati appearing for the assessee. It concerns with the provisions of the Gift-tax Act but the section
dealing with the penalty in the Gift-tax Act and Section 18(1)(a) of the Wealth-tax Act being in pan
materia we have looked into it and we are in respectful agreement with its ratio.
6. For the reasons stated above we answer the question referred to us in the affirmative, against the
department and in favour of the assessee. The assessee shall be entitled to his costs which we assess
at Rs. 200.Commissioner Of Wealth-Tax vs Ram Narain Agrawal on 26 March, 1976

