Anisha vs State Represented By on 3 July, 2023
Author: M.Sundar
Bench: M.Sundar
                                                                                         H.C.P.No.914 of 2023
                                     IN THE HIGH COURT OF JUDICATURE AT MADRAS
                                                       DATED : 03.07.2023
                                                              CORAM
                                       THE HONOURABLE MR.JUSTICE M.SUNDAR
                                                      and
                                     THE HONOURABLE MR.JUSTICE R.SAKTHIVEL
                                                       H.C.P.No.914 of 2023
                     Anisha                                              ..    Petitioner /
                                                                               Wife of detenu
                                                                 Vs.
                     1.           State represented by
                                  Secretary to Government
                                  Home, Prohibition and Excise Department
                                  Secretariat
                                  Chennai – 600 009
                     2.           The District Magistrate and District Collector
                                  Office of the District Magistrate and District Collector
                                  Erode District
                                  Erode
                     3.           The Superintendent of Police
                                  Erode District
                                  Erode
                     4.           The Superintendent of Prison
                                  Central Prison-Coimbatore
                                  Coimbatore District
                     Page Nos.1/9
https://www.mhc.tn.gov.in/judis
                                                                                        H.C.P.No.914 of 2023
                     5.           The Inspector of PoliceAnisha vs State Represented By on 3 July, 2023

                                  Erode South Police Station
                                  Erode District                                    ... Respondents
                                  Petition filed under Article 226 of the Constitution of India praying
                     for issuance of a writ of habeas corpus to call for the records relating to the
                     petitioner's husband detention order under Tamil Nadu Act 14 of 1982 vide
                     detention order dated 18.08.2022 on the file of the 2nd respondent made in
                     his proceedings in Cr.M.P.No.22/Sexual Offender/2022-C1 and quash the
                     same as illegal and consequently direct the respondents to produce the
                     petitioner's husband namely Syed Ali, son of Kasim Sait, aged 40 years
                     before this Court and set him at liberty.
                                  For Petitioner           :     Mr.Jayan
                                  For Respondents          :     Mr.E.Raj Thilak
                                                                 Additional Public Prosecutor
                                                            ORDER
[Order of the Court was made by M.SUNDAR, J.,] Captioned 'Habeas Corpus Petition' ['HCP' for the
sake of brevity] has been filed by the wife of the detenu assailing a 'preventive detention order dated
08.08.2022 bearing reference Cr.M.P.No.22/Sexual Offender/2022- C1' [hereinafter 'impugned
preventive detention order' for the sake of convenience and brevity]. To be noted, fifth respondent is
the sponsoring https://www.mhc.tn.gov.in/judis authority and second respondent is the detaining
authority as impugned preventive detention order has been made by second respondent.
2. Impugned detention order has been made under 'The Tamil Nadu Prevention of Dangerous
Activities of Bootleggers, Cyber law offenders, Drug-offenders, Forest-offenders, Goondas, Immoral
traffic offenders, Sand-offenders, Sexual-offenders, Slum-grabbers and Video Pirates Act, 1982
(Tamil Nadu Act No.14 of 1982)' [hereinafter 'Act 14 of 1982' for the sake of convenience and clarity]
on the premise that the detenu is a 'Sexual Offener' within the meaning of Section 2(ggg) of Act 14 of
1982.
3.There is no adverse case. The solitary case which is the sole substratum of the impugned detention
order is Crime No.279 of 2022 on the file of Erode South Police Station for alleged offences under
Sections 5(l), 5(m), 5(n) read with Section 6, 16 and17 of Protection of Child from Sexual Offences
Act, 2012 and Sections 468, 471 and 506(ii) of 'Indian Penal Code, 1860 (Act 45 of 1860)' ['IPC' for
brevity] and Sections 34 and 35 of Aadhaar (Targetted Delivery of Financial and Other Subsidies
Benefits and Services) Act, 2016. Owing to the nature of the challenge to the impugned detention
order, it is not necessary to delve into the factual matrix or be https://www.mhc.tn.gov.in/judis
detained further by facts.
4. Mr.Jayan, learned counsel on record for petitioner and Mr.E.Raj Thilak, learned State Additional
Public Prosecutor, for all respondents are before us.
5. Learned counsel for petitioner submits that 'live and proximate link' between the grounds ofAnisha vs State Represented By on 3 July, 2023

detention and purpose of detention has snapped as petitioner was arrested on 02.06.2022 but the
impugned detention order has been made only on 18.08.2022.
6. Mr.E.Raj Thilak, learned State Additional Public Prosecutor, submits to the contrary by saying
that materials had to be collected /collated and time was consumed in this exercise. Considering the
facts and circumstances of the case and nature of ground case, we find that this explanation of
learned Prosecutor is unacceptable.
7. We remind ourselves of Sushanta Kumar Banik's case [Sushanta
https://www.mhc.tn.gov.in/judis Kumar Banik Vs. State of Tripura & others reported in 2022
LiveLaw (SC) 813 : 2022 SCC OnLine SC 1333]. To be noted, Banik case law arose under 'Prevention
of Illicit Traffic in Narcotic Drugs and Psychotropic Substances Act, 1988' [hereinafter 'PIT NDPS
Act' for the sake of brevity] in Tirupura, wherein after considering the proposal by the Sponsoring
Authority and after noticing the trajectory the matter took, Hon'ble Supreme Court held that the
'live and proximate link between grounds of detention and purpose of detention snapping' point
should be examined on a case to case basis. Hon'ble Supreme Court has held in Banik case law that
this point has two facets. One facet is 'unreasonable delay' and other facet is 'unexplained delay'. We
find that the captioned matter falls under latter facet i.e., unexplained delay.
8. To be noted, Banik case has been respectfully followed by this Court in Gomathi Vs.The Principal
Secretary to Government and others reported vide Neutral Citation of Madras High Court being
2023/MHC/334, Sadik Basha Yusuf Vs. The State of Tamil Nadu and others reported vide Neutral
Citation of Madras High Court being https://www.mhc.tn.gov.in/judis 2023/MHC/733, Sangeetha
Vs. The Secretary to the Government and others reported vide Neutral Citation of Madras High
Court being 2023:MHC:1110, N.Anitha Vs. The Secretary to Government and others reported vide
Neutral Citation of Madras High Court being 2023:MHC:1159 and a series of other orders in HCP
cases.
9. Be that as it may, we are informed by the learned Prosecutor that charge sheet /final report has
been filed within the prescribed time in the trial Court. If the detenu moves for regular bail in the
trial Court, we make it clear that the same will be heard on its own merits and in accordance with
law untrammeled by this order, which has been made for the limited purpose of Habeas Corpus
legal drill.
10. Before concluding, we also remind ourselves that preventive detention is not a punishment and
HCP is a high prerogative writ. https://www.mhc.tn.gov.in/judis
11. Apropos, the sequitur is, captioned HCP is allowed. Impugned detention order dated 18.08.2022
bearing reference Cr.M.P.No.22/Sexual Offender/2022 C1 made by the second respondent is set
aside and the detenu Thiru.Syed Ali, aged 40 years, son of Thiru.Kasim Sait is directed to be set at
liberty forthwith, if not required in connection with any other case / cases. There shall be no order
as to costs.
                                                                    (M.S.,J.)         (R.S.V.,J.)
                                                                           03.07.2023Anisha vs State Represented By on 3 July, 2023

                     Index : Yes
                     Speaking order
                     Neutral Citation : Yes
                     gpa
P.S: Registry to forthwith communicate this order to Jail authorities in Central Prison, Coimbatore
https://www.mhc.tn.gov.in/judis To
1. The Secretary to Government Home, Prohibition and Excise Department Secretariat Chennai –
600 009
2. The District Magistrate and District Collector Office of the District Magistrate and District
Collector Erode District Erode
3. The Superintendent of Police Erode District Erode
4. The Superintendent of Prison Central Prison-Coimbatore Coimbatore District
5. The Inspector of Police Erode South Police Station Erode District
6. The Public Prosecutor Madras High Court, Chennai https://www.mhc.tn.gov.in/judis
M.SUNDAR, J., and R.SAKTHIVEL, J., gpa 03.07.2023 https://www.mhc.tn.gov.in/judisAnisha vs State Represented By on 3 July, 2023

