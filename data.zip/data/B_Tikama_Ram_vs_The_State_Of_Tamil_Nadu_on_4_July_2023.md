B.Tikama Ram vs The State Of Tamil Nadu on 4 July, 2023
Author: M.Sundar
Bench: M.Sundar
                                                                                      H.C.P.No.669 of 2023
                                     IN THE HIGH COURT OF JUDICATURE AT MADRAS
                                                   DATED: 04.07.2023
                                                          Coram
                                       THE HONOURABLE MR.JUSTICE M.SUNDAR
                                                       and
                                      THE HONOURABLE MR.JUSTICE R.SAKTHIVEL
                                                  H.C.P.No.669 of 2023
                     B.Tikama Ram                                                        .. Petitioner
                                                               vs
                     1.The State of Tamil Nadu
                       Rep. by its Secretary to Government,
                       Prohibition and Excise Department,
                       Fort St.George, Chennai – 600 009.
                     2.The Commissioner of Police,
                       Salem City, Salem District.
                     3.The Superintendent of Police,
                       Central Prison, Salem.
                     4.The Inspector of Police,
                       Kondalampatty Police Station,
                       Salem City, Salem.                                        ..     Respondents
                                  Petition filed under Article 226 of the Constitution of India
                     praying for issuance of a writ of habeas corpus calling for the
                     records          in   detention   order    passed   in   C.M.P.No.138/Drug
                     Offender/Salem           City/2022   dated     31.10.2022   passed         by    2nd
                     respondent herein and quash the same and direct the respondentsB.Tikama Ram vs The State Of Tamil Nadu on 4 July, 2023

                     to produce the body of the detenu namely Khimaram, aged 28, son
https://www.mhc.tn.gov.in/judis
                     1/14
                                                                                     H.C.P.No.669 of 2023
                     of Bagaram Sanphara, Safara, Safada, Jalor District, Rajasthan
                     State, who is now confined in Central Prison, Salem, Salem District,
                     before this Court and set him at liberty.
                                  For Petitioner           :     Mr.R.Dineshkumar
                                  For Respondents          :     Mr.E.Raj Thilak,
                                                                 Additional Public Prosecutor
                                                          ORDER
[Order of the Court was made by M.SUNDAR, J.] When the captioned 'Habeas Corpus Petition'
(hereinafter 'HCP' for the sake of convenience and clarity) was listed in the Admission Board on
25.04.2023, this Court made the following order:
'Captioned Habeas Corpus Petition has been filed in this Court on 27.03.2023 inter
alia assailing a detention order dated 31.10.2022 bearing reference C.M.P
.No.138/Drug Offender/Salem City/2022 made by 'second respondent' [hereinafter
'Detaining Authority' for the sake of convenience and clarity]. To be noted, fourth
respondent is the Sponsoring Authority.
2. To be noted, friend of detenu is the petitioner.
3. Mr.R.Dinesh Kumar, learned counsel on record for habeas corpus petitioner is before us. Learned
counsel for petitioner submits that ground case qua the detenu is for alleged offences under Sections
273 and 328 of 'The Indian Penal Code (45 of 1860)' [hereinafter 'IPC' for the sake of convenience
and clarity] read with Sections 6 and 24[1] of Cigarette and Other Tobacco Products Act, 2003 and
Sections 57 and 59 of Food, Safety and Standard Act, 2006 https://www.mhc.tn.gov.in/judis read
with Section 8(c) read with Section 20(b)(ii)(B) of Narcotic Drugs and Psychotropic Substances Act,
1985 in Crime No.450 of 2022 on the file of Kondalampatty Police Station.
4. The aforementioned detention order has been made on the premise Prevention of Dangerous
Activities of Bootleggers, Cyber law offenders, Drugoffenders, Forest- offenders, Goondas, Immoral
traffic offenders, Sandoffenders, Sexual-offenders, Slum-grabbers and Video Pirates Act, 1982
(Tamil Nadu Act No.14 of 1982)' [hereinafter 'Act 14 of 1982' for the sake of convenience and
clarity].B.Tikama Ram vs The State Of Tamil Nadu on 4 July, 2023

5. The detention order has been assailed inter alia on the ground that as the detenu hails from
Rajasthan, he knows only Hindi but the detention order in a language known to the detenu was not
served which prevented the detenu from making an effective representation.
6. Prima facie case made out for admission. Admit. Issue Rule nisi returnable by four weeks.
7. Mr.R.Muniyapparaj, learned Additional Public Prosecutor, State of Tamil Nadu accepts notice for
all respondents. List the captioned Habeas Corpus Petition accordingly.'
2. The aforementioned order made in the 25.04.2023 Admission listing shall be read as an integral
part and parcel of this order which means that the short forms, short references and abbreviations
used in the order in the Admission listing shall be used in the instant order also.
3. There is no adverse case. The ground case which is the sole substratum of the impugned detention
order is Crime No.450 of 2022 on the file of Kondalampatty Police Station for the alleged
https://www.mhc.tn.gov.in/judis offences under Sections 273, 328 IPC r/w Sections 6, 24(1) of
Cigarette and Other Tobacco Products Act, 2003 and Sections 57 and 59 of Food Safety and
Standard Act, 2006 r/w Section 8(c) r/w 20(b)(ii)(B) of NDPS Act. Owing to the nature of the
challenge to the impugned detention order, it is not necessary to delve into the factual matrix or be
detained further by facts.
4. Mr.R.Dineshkumar, learned counsel on record for petitioner and Mr.E.Raj Thilak, learned State
Additional Public Prosecutor for all respondents are before us.
5. When the matter was taken up, it was submitted that co-
accused in the solitary ground case (Rajesha Kumar, S/o.Ghevaram) was also clamped with similar
preventive detention order i.e., preventive detention order similar to the impugned preventive
detention order, Rajesha Kumar's preventive detention order was challenged by way of HCP No.768
of 2023 and the same was allowed by this Court in and by an order dated 14.06.2023. This order has
been placed before us and a scanned reproduction of the same is as follows:
https://www.mhc.tn.gov.in/judis https://www.mhc.tn.gov.in/judis
https://www.mhc.tn.gov.in/judis https://www.mhc.tn.gov.in/judis
https://www.mhc.tn.gov.in/judis https://www.mhc.tn.gov.in/judis
https://www.mhc.tn.gov.in/judis https://www.mhc.tn.gov.in/judis
6. There is no disputation that the same point is available to the detenu in the case on hand also. We
remind ourselves of age old adage 'Sauce to Goose is sauce to Gander too'. Sequitur is, impugned
preventive detention order deserves to be dislodged.
7. Ergo, the sequitur is, captioned HCP is allowed. Impugned detention order dated 31.10.2022
bearing reference C.M.P.No.138/Drug offender/Salem City/2022 made by the second respondent is
set aside and the detenu Thiru.Khimaram, aged 28 years, son of Thiru.Bagaram, is directed to be setB.Tikama Ram vs The State Of Tamil Nadu on 4 July, 2023

at liberty forthwith, if not required in connection with any other case / cases.
There shall be no order as to costs.
(M.S.,J.) (R.S.V.,J.) 04.07.2023 Index : Yes Neutral Citation : Yes mmi P.S: Registry to forthwith
communicate this order to Jail authorities in Central Prison, Salem. To
1.The Secretary to Government, Prohibition and Excise Department, Fort St.George, Chennai – 600
009.
2.The Commissioner of Police, Salem City, Salem District.
https://www.mhc.tn.gov.in/judis
3.The Superintendent of Police, Central Prison, Salem.
4.The Inspector of Police, Kondalampatty Police Station, Salem City, Salem.
5.The Public Prosecutor, High Court, Madras.
https://www.mhc.tn.gov.in/judis M.SUNDAR, J., and R.SAKTHIVEL , J., mmi 04.07.2023
https://www.mhc.tn.gov.in/judisB.Tikama Ram vs The State Of Tamil Nadu on 4 July, 2023

