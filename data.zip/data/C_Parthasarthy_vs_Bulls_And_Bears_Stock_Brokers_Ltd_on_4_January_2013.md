C. Parthasarthy vs Bulls And Bears (Stock Brokers) Ltd. on 4
January, 2013
Author: V.K. Shali
Bench: V.K. Shali
*              IN THE HIGH COURT OF DELHI AT NEW DELHI
+                     CRIMINAL M.C. NO.4200/2002
                                          Decided on : 4th January, 2013
C. PARTHASARTHY                                            ......Petitioner
             Through:                 Mr. Anshu Mahajan & Mr. Karan Arora,
                                      Advocates.
                           Versus
BULLS AND BEARS (STOCK BROKERS) LTD.          ......Respondent
             Through: Mr. P.K. Arya, Mr. Ashish Sharma,
                      Mr. Narinder Chaudhary & Mr. Rahul
                      Tomar, Advocates.
                                       WITH
                      CRIMINAL M.C. NO.2253/2003
PRADEEP VAKIL                                                 ......Petitioner
             Through:                 Mr. Sandeep Mittal, Advocate.
               Versus
STATE & ANR.                                                ......Respondents
             Through:                 Mr. Sunil Sharma, APP for the State.
                                      Mr. P.K. Arya, Mr. Ashish Sharma,
                                      Mr. Narinder Chaudhary & Mr. Rahul
                                      Tomar, Advocates for R-2.
CORAM:
HON'BLE MR. JUSTICE V.K. SHALI
V.K. SHALI, J.
1. This order shall dispose of abovementioned two petitions as similar facts and common question of
law and facts are involved in both these cases, however, for facility of reference, the facts of only
Criminal M.C. No.4200 of 2002 are given.
2. These are the petitions under Section 482 Cr.P.C. for quashing of Complaint No.44/1/2001 filed
under Sections 120- B/406/418/420/468/471/477 IPC, titled as Bulls & Bears (Stock Brokers) Ltd.
vs. Pradeep Vakil & Ors., pending in the court of learned Metropolitan Magistrate, Delhi.C. Parthasarthy vs Bulls And Bears (Stock Brokers) Ltd. on 4 January, 2013

3. Briefly stated the facts of the case bearing No.4200/2002 are that a complaint was filed by the
respondent against the present petitioners. The present petitioner i.e. C.Parthasarthy was impleaded
as respondent/accused No.2 in the complaint and he was shown to be as Chairman-cum-Managing
Director (CMD) of M/s. Karvy Consultants Ltd. Similarly, Pradeep Vakil was impleaded as accused
no.1 and his designation was mentioned as Chairman-cum-Managing Director of M/s Vatsa
Corporation Ltd. It was alleged in the complaint that the respondent is a corporate body duly
registered under Companies Act and accused No.1, that is, M/s. Vatsa Corporation Ltd. which is a
public limited company and accused No.2, that is, the present petitioner, C. Parthasarthy, was the
Registrar and Share Transfer Agent of accused No.1.
4. It is alleged that the complainant invested in 40200 shares each of `10/- of accused No.1
company and sent them for transfer to its own name on 1.6.1996 and 10.9.1996, out of which it is
alleged that only 37700 shares were transferred on different dates by accused No.2 in its name. It
was alleged that although the needful was to be done within a period of 60 days but it was done
belatedly in order to manipulate the share price in the stock exchange. The respondent/complainant
alleged that this was done deliberately with an ulterior motive and still the petitioner, who is the
respondent in the complaint, did not transfer 2500 shares to the complainant. It is alleged that
these 2500 shares were not transferred to the complainant as it was informed that there was a
mismatch in the ownership as recorded on the certificate and the master data provided by M/s.
Vatsa Corporation Ltd./accused no.1.
5. On the basis of these facts, it was alleged that M/s. Vatsa Corporation Ltd. and M/s. Karvy
Consultants Ltd., which was working as a Registrar for transfer of share certificates, forged the share
certificates and misappropriated the same to their own advantage and the certificates, which were
allegedly forged, were sent to the respondent/complainant as genuine. Because of this, the
respondent/complainant alleged that it was cheated by the petitioner along with M/s. Vatsa
Corporation Ltd. It is alleged that they committed breach of trust and forgery in the share
certificates with a view to cause wrongful loss to the complainant and wrongful gain to themselves.
Accordingly, they were sought to be summoned and punished for offences under Sections 120-
B/406/418/420/468/471/477 IPC.
6. The complaint was filed on 2.3.2001. The respondent/complainant examined one Yatish Kumar
Aggarwal, Director of respondent company Bears and Bulls (Stock Brokers) Ltd. as a witness at the
stage of pre- summoning, who supported the averments made in the complaint. On the basis of the
aforesaid pre-summoning evidence, the learned Magistrate passed a summoning order against one
Pradeep Vakil, the Managing Director of M/s. Vatsa Corporation Ltd. and the present petitioner C.
Parthasarthy, CMD, M/s. Karvy Consultants Ltd. to face the trial for an offence under Sections
420/468/471 IPC.
7. Feeling aggrieved by the aforesaid summoning order, the petitioner preferred the present
petition, which came up for hearing for the first time on 19.12.2002 on which date, notice was issued
to the respondent/complainant for 13.2.2003 and till then, the proceedings before the trial court
qua the petitioner were directed to be stayed. This stay order has continued till date, that is, for
almost 10 years.C. Parthasarthy vs Bulls And Bears (Stock Brokers) Ltd. on 4 January, 2013

8. I have heard the learned counsel for the petitioner as well as the learned counsel for the
respondent. The learned counsel for the petitioner has raised number of points for the purpose of
quashing of the complaint and the consequent proceedings which have been continued. These can
be summed up as under.
9. The first point which has been raised by the learned counsel for the petitioner is that the
respondent/complainant has made allegations that he had purchased shares of M/s. Vatsa
Corporation Ltd. and M/s. Vatsa Corporation Ltd. is alleged to be the accused No.1, while as if one
sees the complaint, instead of making M/s. Vatsa Corporation Ltd. as an accused, Pradeep Vakil,
who is stated to be the CMD of M/s. Vatsa Corporation Ltd., has been impleaded as a party. The
learned counsel contended that under the provisions of IPC since the Managing Director has been
impleaded as accused, there is no provision in the IPC where a person can be sought to be
impleaded as an accused under the vicarious liability. For this purpose, the learned counsel has
relied upon Maksud Saiyed vs. State of Gujarat & Ors.; (2008) 5 SCC 668.
10. The second submission which is made by the learned counsel for the petitioner is to the effect
that if one sees the entire complaint of the respondent/complainant, it essentially constitutes
grievance which is of a civil nature. By filing the present complaint and simply using the words
'wrongful loss, cheating and forgery', the civil offence does not get converted into a criminal offence.
It has been contended that this conversion of civil disputes between the parties on account of
non-transfer of 2500 shares and the belated transfer of 37,700/- shares, the petitioner could not be
prosecuted for the offences of cheating, breach of trust or forgery and this is being done deliberately
with a view to bring more pressure on the petitioner. In this regard, the learned counsel has placed
reliance on case titled Suneet Gupta vs. Anil Triloknath Sharma; 2008 (7) SCALE 110, Manju Gupta
vs. Lt. Col. M.s. Paintal; (1982) 2 SCC 412 and All Cargo Movers (I) Pvt. Ltd. vs. Dhanesh Badarmaol
Jain & Anr.; AIR 2008 SC 247.
11. The third submission which has been made by the learned counsel is to the effect that de hors the
fact that a civil dispute is sought to be converted into criminal dispute, if one sees the complaint as
well as the statement which is purported to have been recorded by the respondent/complaint in
support of its complaint, it does not make out any offence under Sections 406/420/468 or even 471
IPC. It has been contended that not only in the complaint but also in the statement, even the basic
ingredients of the aforesaid four penal offences have not been made out by the
respondent/complainant and the learned Magistrate without any application of mind has ordered
the issuance of summons to the petitioner.
12. It has been contended by the learned counsel that the Apex Court in Pepsi Foods Ltd. & Anr. vs.
Special Judicial Magistrate & Ors.; 1998 Crl. LJ 1 has categorically observed that summoning of an
accused in a criminal offence is something very serious as it puts the accused persons, so
summoned, to a great degree of peril of facing an unending trial, mental torture and harassment
and, therefore, this should not be done in a casual manner.
13. On account of the aforesaid reasons, the learned counsel for the petitioner has prayed that not
only the complaint but also the consequent proceedings, which have been taken out by theC. Parthasarthy vs Bulls And Bears (Stock Brokers) Ltd. on 4 January, 2013

respondent/complainant against the petitioner deserve to be quashed.
14. The respondent has refuted the submissions made by the learned counsel for the petitioner. He
has contended that the petitioner has not challenged the order of summoning and so far as the
merits of the case are concerned, the complaint does not deserve to be quashed as the said matter
has to be considered by the trial court as to whether the respondent/complainant would be able to
prove the offence by producing the evidence against the petitioner or not. In this regard, it was
contended by him that so far as the question of appreciation of evidence is concerned or the
reliability of testimony of witness is concerned, this cannot be considered at this stage and the
respondent/complainant may be permitted to adduce evidence in this regard before the trial court.
The learned counsel has also placed reliance on two judgments of this court of the learned Single
Judge in case titled Pratap Narayan vs. State through CBI; 2009 (4) JCC 2988 and Sunil Kapoor &
Anr. vs. State & Anr.; 2009 (4) JCC 2995.
15. I have carefully considered the submissions made by the respective sides and gone through the
judgments cited. I find that there is a considerable merit in all the three submission made by the
learned counsel for the petitioner.
16. The first point which has been raised by the learned counsel for the petitioner is with regard to
the vicarious liability. According to the complaint, the grievance of the petitioner is essentially
against the two companies, that is, M/s. Vatsa Corporation Ltd. and M/s. Karvy Consultants Ltd. So
far as the first company M/s. Vatsa Corporation Ltd. is concerned, it is alleged that the respondent
has purchased 40200 shares of the said company and he had applied for transfer of these shares to
its own name which was to be done by M/s. Karvy Consultants Ltd.
Reference in the complaint is also made to M/s. Vatsa Corporation Ltd. as accused No.1 while as the
accused No.2 is sought to be made as a party through its CMD. But if one sees the complaint, instead
of making M/s. Vatsa Corporation Ltd. as a party, which is a juristic person, the
respondent/complainant has chosen to make Pradeep Vakil as a party. Similarly, in respect of
accused No.2 also, the grievance of the respondent/complainant is against M/s. Karvy Consultants
Ltd. but he has chosen to make its CMD, C. Parthasarthy, the present petitioner as a party.
17. There is no dispute about the fact that the company is a juristic person and can be sued and can
sue also. It can be an accused also. Section 305 of the Cr.P.C clearly lays down that when a company
is an accused, it has to be made as an accused through its CMD or a Company Secretary or Chief
Executive Officer but nevertheless the accused remains the company and not the CMD in its
individual capacity. While as in the instant case, the respondent/complainant has sought to
prosecute the CMD of both these companies as individuals as if they are vicariously liable for the
acts of the company. This cannot be permitted to be done. The Supreme Court in Maksud Saiyed's
case (supra) has reiterated this very point that unless and until there is a specific provision in the
statute which fastens vicarious liability on the principle officer of the company, he cannot be held
liable and admittedly, under the IPC, there is no provision which would make the CMD or a
principle officer of a company vicariously liable for an offence of cheating, breach of trust, forgery or
using forged documents as genuine. Therefore, on this point, the complaint of theC. Parthasarthy vs Bulls And Bears (Stock Brokers) Ltd. on 4 January, 2013

respondent/complainant deserves to be quashed.
18. The second point which is raised by the petitioner is also of a considerable weight. A perusal of
the complaint would show that essentially the grievance of the respondent/complainant is twofold.
Firstly, that he had applied for transfer of shares, which ought to have been done by M/s. Karvy
Consultants Ltd. within a period of 60 days but it seems to have taken more time which is stated by
the respondent/complainant to be deliberate with a view to manipulate the share price in the stock
market. Even if it is assumed that there was a delay in transfer of the share certificates, there is no
allegation that this was done with a 'dishonest intention' to cause 'wrongful loss' to the
respondent/complainant and wrongful gain to themselves.
19. The respondent/complainant in the complaint has used the words 'cheating, forgery, using
forged documents as genuine or criminal misappropriation'. Essentially, if one goes through the
entire complaint, the grievance is regarding non-timely transfer of shares and some of the shares
having been informed to the respondent/complainant as being 'forged and fake'. This, at best,
constitutes a civil dispute between the beneficiary and the service provider, namely, M/s. Karvy
Consultants Ltd. and the petitioner. This civil dispute could not be converted into a criminal dispute
with a view to put pressure on other side. The Supreme Court has noted in a number of cases that in
the present times, there is a greater tendency of the parties to convert civil dispute into criminal
dispute because of the feeling that if a civil dispute is converted into a criminal dispute, a quicker
relief will be obtained by the parties. Reliance in this regard is placed on a case titled Inder Mohan
Goswami & Anr. Vs. State of Uttaranchal & Ors.; AIR 2008 SC 251 and Indian Oil Corporation Vs.
NEPC India Ltd. & Ors.; AIR 2006 SC 2780. This is precisely the intention in the instant case also
where a civil dispute is sought to be converted into a criminal dispute. This is a gross abuse of the
process of law and this cannot be permitted to be done. Therefore, on this score also, the
respondent's complaint deserves to be quashed.
20. The third point which has been urged by the learned counsel for the petitioner is even de hors
the fact that a civil dispute is not sought to be converted into criminal dispute, if one sees the entire
complaint and the offence which has been accused by the respondent/complainant, it does not
satisfy even the basic ingredients of any of the offences for which the petitioner and Pradeep Vakil
were summoned. To illustrate this, I will hereinafter refer to Sections 406/420/468 & 471 IPC and
also show that all the ingredients prima facie are not satisfied.
"A. Ingredients of Section 406 IPC :-
To prove offence under this Section, the prosecution must prove :
(i) that the accused was entrusted with property or with dominion over it.
(ii) that he (a) misappropriated it, or (b) converted it to his own use, or (c) used it, or
(d) disposed of it.
B. The essential ingredients to attract Section 420 IPC are :C. Parthasarthy vs Bulls And Bears (Stock Brokers) Ltd. on 4 January, 2013

(i) cheating; (ii) dishonest inducement to deliver property or to make, alter or destroy
any valuable security or anything which is sealed or signed or is capable of being
converted into a valuable security, and (iii) mens rea of the accused at the time of
making the inducement. The making of a false representation is one of the
ingredients for the offence of cheating under Section 420.
C. Ingredients of Section 468 IPC :-
To prove offence under this Section, the prosecution must prove :
(i) that the document is a forgery;
(ii) that the accused forged the document;
(iii) that he did as above intending that the forged document would be used for the
purpose of cheating.
D. Ingredients of Section 471 IPC :-
Under this Section there must be -
(i) Fraudulent or dishonest use of a document as genuine.
(ii) Knowledge or reasonable belief on the part of the person using the document that
it is a forged one."
21. A perusal of the aforesaid four Sections would clearly show that the perusal of the complaint
does not satisfy the basic ingredients of any of the offences even prima facie. For example, to test
this proposition under Section 406 IPC, criminal breach of trust, there has to be an entrustment of
the property to the person who is sought to be prosecuted. There is no doubt about the fact that
share certificates are valuable property but there is no averment in the complaint much less in the
statement of the witness recorded at the pre-summoning stage that these were personally entrusted
by the respondent/complainant in the personal capacity to either Pradeep Vakil or even to C.
Parthasarthy. Therefore, they could not have been prosecuted for an offence of criminal breach of
trust because the very entrustment of the valuable property was absent qua them.
22. Similarly, with regard to cheating, there has been absolutely no representation on the part of the
petitioner or Pradeep Vakil to the respondent/complainant. It is the respondent/complainant who
had purchased the shares of M/s. Vatsa Corporation Ltd. of his own and then applied for transfer of
the same to the service provider, that is, M/s. Karvy Consultants Ltd. of which the present petitioner
happens to be the CMD. Similarly, when 2500 share certificates are not transferred by the petitioner
in favour of the respondent/complainant on the plea that they are 'forged and fake' share
certificates, then merely because this communication has been sent by M/s. Karvy Consultants Ltd.
to the respondent/complainant that it is the CMD of M/s. Vatsa Corporation Ltd. who has forgedC. Parthasarthy vs Bulls And Bears (Stock Brokers) Ltd. on 4 January, 2013

these certificates, it cannot be assumed that the offence of forgery has been committed, therefore,
prima facie unless and until the ingredients of these offences are not satisfied, a person ought not to
have been summoned as an accused, while as in the instant case, the learned Magistrate, without
any application of mind and in a most casual manner, has ordered summoning of the present
petitioners in a very serious offence of cheating, breach of trust, forgery and using forged documents
as genuine.
23. The Apex Court in Pepsi Food's case (supra) has very tellingly cautioned the courts that they
should not resort to the power of summoning in a casual manner as it puts the liberty of a person in
jeopardy. I, therefore, feel that in the instant case, this basic principle has not been borne in mind by
the learned Magistrate.
24. For the reasons mentioned above, I feel that the pendency of the complaint for the last more
than a decade as well as summoning of the present petitioners in the said complaint for offences
under Sections 420/406/468/471 IPC is a gross abuse of the process of law and, therefore, the same
deserves to be quashed. Ordered accordingly.
V.K. SHALI, J.
JANUARY 04, 2013 'AA'C. Parthasarthy vs Bulls And Bears (Stock Brokers) Ltd. on 4 January, 2013

