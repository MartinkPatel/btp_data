Antrix Corporation Ltd. vs Devas Multimedia Private Limited on
29 August, 2022
Author: Sanjeev Sachdeva
Bench: Sanjeev Sachdeva
                                      *IN THE HIGH COURT OF DELHI AT NEW DELHI
                                      %                                  Judgment Reserved on: 01st June, 2022
                                                                     Judgment pronounced on: 29th August, 2022
                                      + O.M.P. (COMM) 11/2021 & I.A. 3035/2021, I.A. 3037/2021, I.A.
                                      4940/2021, I.A. 12541/2021 & I.A. 2507/2022
                                      ANTRIX CORPORATION LTD.                                    ..... Petitioner
                                                                            versus
                                      DEVAS MULTIMEDIA PRIVATE LIMITED                           ..... Respondents
                                      Advocates who appeared in this case:
                                      For the Appellants: Mr. N. Venkataraman, Additional Solicitor General with
                                                          Mr. Chetan Sharma, Additional Solicitor General with Mr.
                                                          V. Chandrashekar, Mr. Ajay Bhargava, Mr. Arvind Ray,
                                                          Mr. Karan Gupta, Ms. Varsha S. Suneja, Mr. Ram Narayan,
                                                          Advocates and Mr. Bhasker Singh, Legal Officer
                                      For the Respondent : Mr. Maninder Singh, Senior Advocate with Mr. A.
                                                           Sebastian, Mr. Prabhas Bajaj, Mr. Ajay Sabharwal, Ms.
                                                           Angelika Awasthi and Mr. Prashant Jain, Advocates for
                                                           Official Liquidator of Devas.
                                                              Mr. Suhail Dutt, Senior Advocate with Ms. Anuradha Dutt,
                                                              Mr. Lynn Pereira, Ms. Ekta Kapil, Ms. Priyanka M.P., Mr.
                                                              Chaitanya Kaushik, Mr. Amber Bhushan, Ms. Shivangi
                                                              Sud, Mr. Azhar Alam and Mr. Sankalp Goswami,
                                                              Advocates for impleading applicant.
                                      CORAM:-
                                      HON'BLE MR. JUSTICE SANJEEV SACHDEVA
                                                                       JUDGMENT
SANJEEV SACHDEVA, J.
1. Petitioner - Antrix Corporation Limited (hereinafter referred to Signing Date:29.08.2022
15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
as „Antrix) by this petition under Section 34 of the Arbitration and Conciliation Act, 1996
(hereinafter referred to as the Act) seeks setting aside of the Arbitral award dated 14.09.2015 passedAntrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

by the Arbitral Tribunal constituted by the International Chamber of Commerce allowing the claim
of the Respondent - Devas Multimedia Private Limited (hereinafter referred to as „Devas).
2. Antrix sought winding up of Devas under Section 271(c) read with Section 272(1)(e) of the
Companies Act, 2013 before the National Company Law Tribunal (hereinafter referred to as
„NCLT) alleging that Devas was formed for a fraudulent and unlawful purpose and its affairs had
been conducted in a fraudulent manner. On 19.01.2021, a Provisional Liquidator was appointed by
the NCLT and by final order dated 25.05.2021 NCLT allowed winding up of Devas.
3. The order of winding up was challenged by Devas and Devas Employees Mauritius Private
Limited (hereinafter referred to as „DEMPL) before the National Company Law Appellate Tribunal
(hereinafter referred to as „NCLAT). NCLAT by its order dated 08.09.2021 dismissed both the
appeals. Thereafter the orders were assailed before the Supreme Court of India and the Supreme
Court of India by its judgment dated 17.01.2022, dismissed the appeals.
Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
4. Since the order of winding up of Devas has been upheld until the Supreme Court of India, Devas
is represented in these proceedings by the Official Liquidator.
5. IA. 4940 of 2021 has been filed by Devas Employees Mauritius Pvt. Ltd. (DEMPL) seeking
impleadment in these proceedings alleging that the official liquidator is not acting in the interest of
Devas necessitating DEMPL to seek impleadment to protect the interest of Devas.
6. Mr. N Venkataraman learned Additional Solicitor General and Mr. Maninder Singh learned
Senior Advocate appearing for Antrix and the official liquidator respectively denied that the official
liquidator was not acting in the interest of Devas, however they without prejudice did not oppose the
impleadment of DEMPL.
7. Accordingly, DEMPL were permitted to oppose the petition. Mr. Suhail Dutt, learned Senior
Advocate appeared for DEMPL and made detailed submissions spread over several days and has
also referred to various documents filed along with their applications and other pleadings and has
also filed written submission and compilation to oppose the petition.
8. By the Impugned award dated 14.09.2015, the Arbitral Tribunal has held that the termination of
the Contract on the part of Antrix Signing Date:29.08.2022 15:28:39 This file is digitally signed by
PS to HMJ Sanjeev Sachdeva.
amounted to wrongful repudiation of the contract and accordingly Article 7(b) of the contract did
not limit Devas entitlement to alleged damages that it suffered by reason of Antrixs repudiation of
the Devas Agreement. The Tribunal thus directed Antrix to pay US$ 562.2 million to Devas besides
interest.Antrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

9. Though largely the submissions of the Parties focused on the findings returned by the National
Company Law Tribunal, National Company Law Appellate Tribunal and the Supreme Court on the
question of Fraud on the part of Devas, as the impugned award has been challenged by filing
objections under section 34 of the Act, and further the question of fraud allegedly committed by
Devas is intrinsically intertwined with the factual matrix and finding returned by the Arbitral
Tribunal, the objections raised have also been considered on merits.
10. Antrix is a Central Government Public Sector Enterprise and Government Company
incorporated under the Companies Act 1956 and is engaged, inter alia, in the business of marketing
and sale of products and services of Indian Space Research Organisation ("ISRO") to national and
international customers.
11. Devas is a limited liability company incorporated on 17.12.2004 under the Companies Act 1956.
The initial subscribers to the Memorandum of Association of the Respondent were Mr. D. Signing
Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
Venugopal holding 9000 shares and Mr. M. Umesh holding 1000 shares and its authorized share
capital at the time of its incorporation was Rs. 11,50,000/-.
12. Subject contract leading to these proceedings was entered into between Antrix and Devas on
28.01.2005 (hereinafter referred to as the „Contract) for the Lease of Space Segment Capacity on
ISRO/Antrix S-band Spacecraft. It provided for the lease to Devas of transponders on satellite
GSAT-6, referred to in the Contract as Primary Satellite 1 or PS1. It also contained an option for
Devas to lease transponders on a second satellite, GSAT-6A, referred to in the Contract as Primary
Satellite 2 or PS2.
13. The Contract was executed between Antrix and Devas only and neither the Department of Space-
nor ISRO nor any other governmental agency was a party to the Contract.
14. The Contract refers to and defines "Governmental or Regulatory Authority" in sub-article (16) to
Annexure I as "any Government, State, or Central, municipality, local authority, town, village, court,
tribunal, arbitrator, authority, agency, commission, official or other instrumentality of India," and
defines "Regulatory Approval in sub-article (37) to Annexure I as "any and all approvals, licenses, or
permissions from Governmental or Regulatory Authorities."
Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
15. The recitals on the Contract inter alia stipulated as under:
"WHEREAS Indian Space Research Organization (ISRO), under Department of
Space, Government of India (DOS), is a pioneer in the satellite industry with a
portfolio of satellite products and services, international experience in satellite
manufacturing and launch program management expertise, and satellite network
expertise.Antrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

WHEREAS ANTRIX is a marketing arm of Department of Space and is the entity through which
ISRO engages in commercial activities.
WHEREAS, DEVAS is developing a platform capable of delivering multimedia and information
services via satellite and terrestrial systems to mobile receivers, tailored to the needs of various
market segments.
WHEREAS, DEVAS has requested from ANTRIX space segment capacity for the purpose of offering
a S-DMB service, a new digital multimedia and Information service, including but not limited to
audio and video content and information and interactive services, across India that will be delivered
via satellite and terrestrial systems via fixed, portable, and mobile receivers including mobile
phones, mobile video/audio receivers for vehicles, etc. ("Devas Services").
WHEREAS, ANTRIX has agreed to the request of DEVAS and has decided to make available to
DEVAS, on a lease basis, part of a space segment capacity on Primary Satellite 1 ("PS1") and an
option to gain additional capacity on Primary Satellite 2 ("PS2") to be manufactured for similar
services without any immediate backup (unless otherwise specified herein) In the S-Band, Signing
Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
for such purpose under appropriate terms and conditions.
WHEREAS ANTRIX and DEVAS understand and accept that they will collaborate to build, launch
and operate Satellite(s) and the Devas Services, and recognize that enabling the Devas Services and
activities related thereto requires execution of interdependent technical and business activities."
16. The Lease period stipulated was 12 years, which was extendable by a further period of 12 years.
17. Article 3 of the Contract pertaining to Period of Lease and Terms & Conditions inter alia
stipulated as under:
                                             "a.       ........
                                             c.     ANTRIX shall be responsible for obtaining all
necessary Governmental and Regulatory Approvals relating to orbital slot and frequency clearances,
and funding for the satellite to facilitate DEVAS services. Further, ANTRIX shall provide
appropriate technical assistance to DEVAS on a best effort basis for obtaining required operating
licenses and Regulatory Approvals from various ministries so as to deliver DEVAS services via
satellite and terrestrial networks. However the cost of obtaining such approvals shall be borne by
DEVAS. .......
e. The Parties agree and confirm that a part of PS1, as mutually agreed in writing, such agreement by
DEVAS not to be unreasonably withheld, shall be used by ISRO Signing Date:29.08.2022 15:28:39
This file is digitally signed by PS to HMJ Sanjeev Sachdeva.Antrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

for its own purposes, provided such usage does not interfere or compete in any way with the DEVAS
Services.
.......
j. ANTRIX agrees; that to the best possible extent, it will lease to DEVAS Additional Satellite
Capacity above and beyond PS2, and spares and frequencies associated to the Additional Satellite
Capacity to enhance Devas Services features based upon mutually agreed terms and conditions of a
lease arrangement which will be negotiated and signed by the Parties at least three years prior to the
actual requirement date of the fresh lease services, provided that ANTRIX shall obtain all necessary
Governmental and Regulatory Approvals relating to orbital resources, frequency clearance,
investment feasibility and funding for the satellite including but not limited to ITU (international
Telecommunication Union) coordinated orbital slot, frequency allocation and related approvals for
all matters covered in Article 3 (c). Further, if ANTRIX cannot fulfill the needs of DEVAS for
Additional Satellite Capacity, DEVAS may seek the support of ANTRIX to procure the services from
a third-party on such terms which are mutually agreeable to Parties and ANTRIX shall, either by
itself or through ISRO, make best efforts to support DEVAS in this regard.
......."
18. Article 7 of the Contract refers to Termination of the Contract and reads as under:
"Article 7. Termination Signing Date:29.08.2022 15:28:39 This file is digitally signed
by PS to HMJ Sanjeev Sachdeva.
a. Termination for convenience by DEVAS DEVAS may terminate this Agreement in
the event DEVAS is unable to get and retain the Regulatory Approvals required to
provide the Devas Services on or before the completion of the Pre Shipment Review
of PS1. in the event of such termination, DEVAS shall forfeit the Upfront Capacity
Reservation Fees made to ANTRIX and any service or other taxes paid by DEVAS and
those outstanding to be paid to ANTRIX till such date. Upon such termination,
neither Party shall have any further obligation to the other Party under this
Agreement.
b. Termination by DEVAS for fault of ANTRIX DEVAS may terminate this Agreement
at any time if ANTRIX is in material breach of any provisions of this Agreement and
ANTRIX has failed to cure the breach within three months after receiving notice from
DEVAS setting out the nature of breach and reasons for considering the same as
material breach, in such event, ANTRIX shall immediately reimburse DEVAS all the
Upfront Capacity Reservation Fees and corresponding taxes if applicable, received by
ANTRIX till that date. Upon such termination, neither Party shall have any further
obligation to the other Party under this Agreement nor be liable to pay any sum as
compensation or damages (by whatever name called).Antrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

c. Termination for convenience by ANTRIX ANTRIX may terminate this Agreement
in the event ANTRIX is unable to obtain the necessary frequency and orbital slot
coordination required for operating PS1 on or before the completion of the Pre
Shipment Review of Signing Date:29.08.2022 15:28:39 This file is digitally signed by
PS to HMJ Sanjeev Sachdeva.
the PS1. In the event of such termination, ANTRIX shall immediately reimburse
DEVAS all the Upfront Capacity Reservation Fees and corresponding service taxes
received by ANTRIX till that date. Upon such termination, neither Party shall have
any further obligation to the other Party under this Agreement nor be liable to pay
any sum as compensation or damages (by whatever name called).
d. Termination by ANTRIX for fault of DEVAS ANTRIX may terminate this
Agreement at any time if:
i DEVAS is in material breach of any provisions of this Agreement and DEVAS has
failed to cure the breach within three months after receiving notice from ANTRIX
regarding such breach or, ii. Non payment of (a) the Lease Fees and other charges
(such as spectrum monitoring charges) by DEVAS for a continued period of twelve
(12) months, or if such accumulated delays from recurrent non payments exceed 60
(sixty) months, whichever occurs earlier or, (b) Upfront Capacity Reservation Fees,
already due iii. In the event that;
a. A liquidator trustee or a bankruptcy receiver or the like is appointed by a
competent court and such appointment remains un-stayed or un-vacated for a period
of 90 (ninety) days after the date of Signing Date:29.08.2022 15:28:39 This file is
digitally signed by PS to HMJ Sanjeev Sachdeva.
such order by a competent court in respect of DEVAS, or b. If a receiver or manager is
appointed by a competent court in respect of all or a substantial part of the assets of
DEVAS and such appointment remains un-stayed or un-vacated for a period of 90
(ninety)days after the date of such appointment, or c. if all or a substantial part of the
assets of DEVAS have been finally confiscated by action of any Governmental
Authority, against which no appeal or judicial redress lies.
It is expressly agreed that ANTRIX shall have no right to terminate this Agreement if
DEVAS enters into any scheme or arrangement with its creditors, a corporate re-
organization or restructuring of its debt and liabilities as long as DEVAS continues to
make the Annual Lease Payments to ANTRIX.
In the event of such termination, DEVAS shall forfeit the Upfront Capacity
Reservation Fees made to ANTRIX and DEVAS shall be liable to pay any outstanding
dues to be paid to ANTRIX by DEVAS. Upon such termination, neither Party shall
have any further obligation to the other Party under this Agreement nor be liable toAntrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

pay any sum as compensation or damages (by whatever name called).
e. Termination under Special Circumstances Signing Date:29.08.2022 15:28:39 This
file is digitally signed by PS to HMJ Sanjeev Sachdeva.
In the event of two successive Launch Failures of PS1 by ANTRIX, DEVAS shall have
the option, exercisable in its sole discretion, to (a) either terminate this Agreement,
In which event ANTRIX agrees to Immediately reimburse DEVAS all the Upfront
Capacity Reservation Fees for PS1 received by ANTRIX till that date, and after that,
neither Party shall have any further obligation to the other Party under this
Agreement, or (b) forego the refund of the Upfront Capacity Reservation Fees and
service taxes and request ANTRIX to launch a satellite within 24 months of the
exercise of this option, based on mutually agreed-upon terms.
f. General Provisions Termination of this Agreement for any reason whatsoever, shall
not extinguish the rights and obligations of Parties under clauses related to
Arbitration (Article 20), Confidentiality (Article 18) and obligations related to
refund/payment of monies that have accrued before termination, and they shall
survive termination and or expiry of this Agreement for a further period of 5 (five)
years or fulfillment of these terms whichever is later."
19. Article 11 of the Contract relates to Force Majeure conditions and reads as under:
"Article 11. Force Majeure a. Neither of the Parties hereto shall be liable for any
failure or delay in performance of its obligations hereunder if such failure or delay is
due to Force Majeure as defined in this Article, provided that notice thereof is given
to the other Party within Signing Date:29.08.2022 15:28:39 This file is digitally
signed by PS to HMJ Sanjeev Sachdeva.
seven (7) calendar days after such event has occurred.
b. For the purposes of this Agreement, "Force Majeure Event"" shall include any
event, condition or circumstance that is beyond the reasonable control of the party
affected (the "Affected Party") and that, despite ail efforts of the Affected Party to
prevent it or mitigate its effects (including the implementation of a business
continuation plan), such event, condition or circumstance prevents the performance
by such Affected Party of its obligations hereunder. The following events may be
considered Force Majeure Events under the Agreement: (i) explosion and fire; (ii)
flood, earthquake, storm, or other natural calamity or act of God; (iii) strike or other
labor dispute; (iv) war, insurrection, civil commotion or riot; (v) acts of or failure to
act by any governmental authority acting in its sovereign capacity; (vi) changes in law
and regulation, (vii) National emergencies, (ix) Launch Failure. c. If an Affected Party
is rendered unable, wholly or in part, by a Force Majeure Event, to carry out some or
all of its obligations under the Agreement, then, during the continuance of suchAntrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

inability, the obligation of such Affected Party to perform the obligations so affected
shall be suspended.
d. The Affected Party shall give written notice of the Force Majeure Event to the other
party (the "Unaffected Party") as soon as practicable after such event occurs, and not
later than 7 days after such event, which notice shall include information Signing
Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev
Sachdeva.
with respect to the nature, cause and date of commencement of the occurrence(s),
and the anticipated scope and duration of the delay. Upon the conclusion of a Force
Majeure Event, the Affected Party shall, with all reasonable dispatch, take all
necessary and effective steps to resume the obligation(s)previously suspended.
e. Notwithstanding the foregoing, an Affected Party shall not be excused under this
Article for (1) any non-performance of its obligations under the Agreement having a
greater scope or longer period than is justified by the Force Majeure Event, or (2) the
performance, of obligations that arose prior to the Force Majeure Event. Nothing
contained herein shall be construed as requiring an Affected Party to settle any strike,
lockout or other labor dispute in which it may be involved.
f. Notwithstanding anything contained herein, in the event of Launch Failure of PS1
or PS2, the articles related to re-launch guarantee in Article 3 (d), and termination
under special circumstances in Article 7 shall apply and take precedence over the
terms contained herein.
g. In the event of failure or delay in the performance of this Agreement arising out of
an event of Force Majeure which lasts longer than 90 (ninety) days, both parties shall
discuss the further course of action on a mutually agreeable basis. However, such
action could include termination at the option of Unaffected Party if total delays
exceed 12 (twelve) months, it is hereby expressly agreed by the parties that no
financial or other liability shall Signing Date:29.08.2022 15:28:39 This file is digitally
signed by PS to HMJ Sanjeev Sachdeva.
arise on termination under this clause as far as the affected party is concerned."
20. Another clause relied upon by the Arbitral Tribunal in the impugned award is Article 13 dealing
with Indemnities, which reads as under:
"Article 13. Indemnities a. Either of the Parties (ANTRIX or DEVAS) shall indemnify,
defend and hold harmless the other Party, its officers, directors, employees, agents,
consultants from and against any loss. damages, liabilities, expenses, claims, actions,
charges, costs, interests, and penalties suffered by the indemnified Party together
with the attorneys fees, arising from the fault of the indemnifying Party b. it isAntrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

further agreed that DEVAS shall indemnify ANTRIX for the following i Libel, slander,
invasion of privacy, or infringement of copyright or cyber law arising from the use of
the leased capacity;
ii. infringements of third-party patents or intellectual Property rights arising from a)
combining with, or used in connection with the Leased Capacity, apparatus, satellite,
systems of the DEVAS, its users, customers, contractors, lessees, agents or assignees
where ANTRIX exercises no control; b) use of the Leased Capacity in a manner not
contemplated by ANTRIX and over which the ANTRIX exercises no control;
Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev
Sachdeva.
iii. Violation of any applicable laws or regulations of any country or damage to any
third party arising from the use of the Leased Capacity.;
iv. Any act or omission of DEVAS, its users, customers, contractors, lessees, agents,
assignees or employees in connection with the Leased Capacity.
c. ANTRIX shall indemnify DEVAS and hold harmless from any loss, damage,
liability or expenses arising from the following:
i. ANTRIXs exercising use. control or operation of the PS1 and PS2 spacecrafts or
from any use by ANTRIXs users, customers, contractors, agents, assignees,
employees, or lessees other than DEVAS;
ii. Infringements of third-party patents or Intellectual Property rights arising from,
combining with, or used in connection with ANTRIXs design, manufacture, launch
and operations of the PS1 or PS2 satellites where DEVAS exercises no control.
d. Each Party undertakes to notify the other Party in writing of any matter or thing of
which it becomes aware which is or may be a material breach of, or materially
inconsistent with, any of its warranties and representations.
e. The right of either Party under this clause shall be in addition to the right to
damages or any other rights available at common law or equity In respect of any
breach of the warranties, representations and undertakings of the other Party.
Provided however, that Signing Date:29.08.2022 15:28:39 This file is digitally signed
by PS to HMJ Sanjeev Sachdeva.
no right or claim of any nature whatsoever shall arise by virtue of or under this
clause, for matters specifically provided for elsewhere in this agreement including
matters relating to termination of this agreement."Antrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

21. Article 19 stipulates that the Governing Law is the Law of India and provides that the Agreement
and the rights and responsibilities of the Parties hereunder, shall be subject to and construed in
accordance with the Laws of India.
22. The Arbitration agreement between the parties is contained in Article 20 of the Contract, which
reads as under:
"Article 20. Arbitration a. In the event of there being any dispute or difference
between the Parties hereto as to any clause or provision of this Agreement or as to the
interpretation thereof or as to any account or valuation or as to the rights, liabilities,
acts, omissions of any Party hereto arising under or by virtue of these presents or
otherwise in any way relating to this Agreement such dispute or difference shall be
referred to the senior management of both Parties to resolve within three (3) weeks
falling which It will be referred to an Arbital Tribunal comprising of three arbitrators,
one to be appointed by each party (i.e. DEVAS and ANTRIX) and the arbitrators so
appointed will appoint the third arbitrator. b. The seat of Arbitration shall be at NEW
DELHI in India.
Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev
Sachdeva.
c. The Arbitration proceedings shall be held in accordance with the rules and
procedures of the ICC (International Chamber of Commerce) or UNCITRAL.
d. The Arbitration Tribunal shall reach and render a decision or award in writing
(concurred in by a majority of the members of the Arbital Tribunal with respect to the
appropriate award to be rendered or remedy to be granted pursuant to the dispute,
(including the amount that any indemnifying Party is required to pay to the
indemnified Party in respect of a claim filed by the indemnified Party).
e. To the extent practicable all decisions of the board of Arbitration shall be rendered
no more than 30 (thirty) days following commencement of proceedings with respect
thereto. The Arbital Tribunal shall realize its decision on award into writing and
cause the same to be delivered to the Parties.
f. Any decision or award made by the board of Arbitration shall be final, binding and
conclusive on the Parties and entitled to be enforced to the fullest extent permitted by
Laws and entered in any court of competent jurisdiction.
g. Each Party to any Arbitration shall bear its own costs or expenses in relation
thereto, including but not limited to such Partys attorneys fees, if any, and the
expenses and fees of the member of the Arbital Tribunal appointed by such party,
provided, however, that the expenses and fees of the third member of the Arbital
Tribunal and any other expenses of the Arbital Tribunal not capable of beingAntrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

attributed to any one member shall be borne in equal parts by the Parties."
Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
23. Another Article of the contract which has though been overlooked by the Arbitral Tribunal but is
important for the present purpose is Article 25 and it reads as under:
"Article 25. Full Agreement This Agreement constitutes the full understanding and
agreement of the Parties concerning the subject matter hereof, and any prior oral or
written agreements and understandings of the Parties concerning the subject matter
of this Agreement are hereby superseded and terminated by this agreement. However
it is made clear here by ANTRIX and agreed by the Parties that the Agreement shall
not be binding on DEVAS or ANTRIX until and unless ANTRIX receives all the
requisite governmental and other regulatory approvals. Including those referred to in
this Agreement."
24. As per the contract executed on 28.01.2005, Antrix was to build, launch and operate two
satellites and lease spectrum capacity on those satellites to Devas, Which Devas planned to use to
provide digital multimedia broadcasting services across India. In return, Devas agreed to pay to
Antrix Upfront Capacity Reservation Fees (hereinafter referred to as UCRF) of US$ 20 million per
satellite, and lease fees of US$ 9 million to US$ 11.25 million per annum. The lease term was twelve
years, with a right of renewal at reasonable lease fees for a further twelve years.
25. On 21.06.2006, Devas made the payment of the first instalment Signing Date:29.08.2022
15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
of UCRF for PS1 of approximately US$ 7 million. On 18.06.2007 Devas made another payment of
approximately US$ 7 million as the UCRF for PS2.
26. In February 2011, the Cabinet Committee on Security took the decision to deny orbital slot in
S-band to Antrix for any commercial activities and to annul the Contract. Pursuant, to the decision
of the Cabinet Committee on Security, on 23.02.2011, the Department Of Space directed the
Petitioner to notify the Respondent of the decision of the Government of India regarding the
termination of the Contract.
27. Antrix notified Devas on 25.02.2011 that the Contract was terminated inter alia citing Article 11
and Article 7(c) of the Contract. Post the termination by letter dated 25.02.2011, Antrix by its letter
dated 15.04.2011 tendered the UCRF that had been received from Devas. Devas refused to accept the
termination and instead claimed specific performance of the contract and in the alternative claimed
damages to the tune of US$ 1.6 billion.
28. Antrix proposed a meeting of the senior management in terms of Article 20(a) of the Contract.
However Devas instead of agreeing to the same filed a request for Arbitration dated 29.06.2011 with
the International Court of Arbitration of the International Chamber of Commerce (ICC Court)Antrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

relying upon the ICC rules. Devas also nominated Mr. V.V. Veedar as its nominee arbitrator to the
Arbitral Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev
Sachdeva.
Tribunal.
29. Antrix disputed the applicability of ICC rules and contending that Devas had unilaterally
invoked ICC rules, it invoked UNCITRAL rules and nominated Mrs. Justice Sujata V. Manohar as its
nominee arbitrator and called upon Devas to nominate its arbitrator within 30 days of receipt of the
request. Antrix also informed the secretariat of the ICC court stating that it had nominated its
arbitrator in terms of Article 20 of the Contract. However the International Chamber of Commerce
declined to accept the same.
30. Antrix accordingly approached the Supreme Court of India by way of a petition under section
11(4) read with 11(10) of the Act for a direction to Devas to nominate its arbitrator as per UNCITRAL
Rules.
31. In the meantime the ICC disregarding the nomination of Mrs. Justice Sujata V. Manohar by
Antrix, appointed Dr. Justice A.S. Anand as a co-arbitrator on behalf of Antrix. The two arbitrators
informed the ICC that pending the proceedings before the Supreme Court of India, they would not
be in a position to appoint a presiding arbitrator.
32. Devas opposed the extension of time till the conclusion of proceedings before the Supreme Court
and requested ICC to appoint a presiding arbitrator, which the ICC did on 10.11.2011 by appointing
Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
Dr. Micheal Pryles. It may be noticed that the two arbitrators did not have any disagreement upon
the presiding arbitrator but only wanted to await the decision of the Supreme Court as such the
nomination of the presiding arbitrator by the ICC was also not warranted.
33. The Supreme Court of India by its judgment dated 10.05.2013 dismissed the petition filed under
section 11 of the Act holding that once an Arbitral Tribunal was constituted, an application under
section 11 of the Act would not lie and the remedy of the party would be to challenge the constitution
in appropriate proceedings but not by way of an application under section 11(6) of the Act.
34. Before the Arbitral Tribunal, Devas contended that Antrix was not entitled to terminate the
agreement under Article 7(c). It contended that Antrix was able to - and did - obtain the necessary
frequency and orbital slot coordination required for operating PS1, so Article 7(c) could not apply.
35. Devas further contended that Antrix was not entitled to rely on Article 11 (Force Majeure) as the
decision of the CCS to annul the agreement was not an "act of or failure to act by any governmental
authority acting in its sovereign capacity" within the meaning of Article 11(b). It was contended that
the CCS decision was brought about by, and is otherwise attributable to Antrixs Own or its
parents actions.Antrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
36. It further submitted that Antrix instigated the alleged Force Majeure Event, and thus it was not
beyond the reasonable control of Antrix within the meaning of Article 11(b). It also contended that
Antrix did not make all efforts to prevent it or mitigate its effects as required by Article 11(b). It
lastly contended that Article 11 permitted, the Unaffected Party (Devas) to terminate the agreement
in light of Force Majeure Events, not the Affected Party (Antrix).
37. Antrix on the other hand contended that even if it was not entitled to terminate the agreement
pursuant to Articles 7(c) or 11 of the contract, the decision of the CCS rendered the agreement
impossible to perform and therefore void under section 56 of the Indian Contracts Act.
38. The tribunal held that Antrix was not entitled to terminate the Contract under Article 11 of the
Contract and also that Section 56 of the Contract Act did not apply and so it did not render the
contract void. Consequently it held that the letter of Antrix dated 25.02.2011 notifying Devas that
the Contract was terminated inter alia citing Article 11 and Article 7(c) of the Contract was wrongful
repudiation of the Contract.
39. It further held that the limitation of liability clauses can apply to repudiatory breaches even if
they do not refer to repudiation expressly. However it held that the parties intention was to ensure
Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
that they did not terminate the agreement in the event of any breach of, or disputes concerning the
agreement. Rather, the parties were to make all attempts to resolve their differences and ensure that
the agreement remained on foot. It held that construing Article 7(b) so that it permitted Antrix to
refuse to perform the agreement at will without discussion or negotiations with Devas, and without
incurring any liability for Devas loss or damage, would be entirely contrary to that intention.
40. The Tribunal has recorded that in reaching the above conclusion about the intention of the
parties with regard to their understanding of Article 7(b), it has not relied upon any pre- contractual
negotiations.
41. The Tribunal has relied upon Article 9.1 of the IBA Rules ([t]he Arbitral Tribunal shall determine
the admissibility. relevance, materiality, and weight of evidence), to disregard any evidence on pre-
contractual negotiations. Relying upon the said Article, Tribunal has held that in its view
pre-contractual negotiations are generally an unreliable guide to the meaning of a contract and
should not be given any weight as they lend parties desires and negotiating positions, not their
concluded agreement following necessary compromises.
42. The Tribunal has further held that even if it had placed weight on evidence of pre-contractual
negotiations, it would have reached the Signing Date:29.08.2022 15:28:39 This file is digitally
signed by PS to HMJ Sanjeev Sachdeva.Antrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

same conclusion. Tribunal held that the its conclusion regarding the intended operation of Article
7(b), suggests that Antrix persuaded Devas that, if Antrix committed a material breach, Devas
should not be entitled to both an indemnity (if the agreement remained on foot) and substantial
liquidated damages (if Devas chose to terminate rather than perform the agreement), it suggests
that the compromise that was reached was that Devas would forfeit its right to compensation if, but
only if, when faced with the option of either performing the agreement or terminating it.
43. The finding returned is a complete perversity, the Tribunal has committed a patent illegality in
not appreciating that the IBA Rules on Taking of Evidence are applicable only in case of
International Arbitration and that also with the consent of parties. Subject arbitration proceedings
are domestic arbitration between two Indian parties and not International Arbitration proceedings
and as such said rules are not applicable and the evidence could not have been excluded.
44. Even otherwise, the Tribunal has not appreciated the true import of Article 9 of IBA Rules which
reads as under:
"Article 9 Admissibility and Assessment of Evidence
1. The Arbitral Tribunal shall determine the admissibility, relevance, materiality and
weight of evidence.
Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev
Sachdeva.
2. The Arbitral Tribunal shall, at the request of a Party or on its own motion, exclude
from evidence or production any Document, statement, oral testimony or inspection,
in whole or in part, for any of the following reasons:
(a) lack of sufficient relevance to the case or materiality to its outcome;
(b) legal impediment or privilege under the legal or ethical rules determined by the
Arbitral Tribunal to be applicable (see Article 9.4 below);
(c) unreasonable burden to produce the requested evidence;
(d) loss or destruction of the Document that has been shown with reasonable
likelihood to have occurred;
(e) grounds of commercial or technical confidentiality that the Arbitral Tribunal
determines to be compelling;
(f) grounds of special political or institutional sensitivity (including evidence that has
been classified as secret by a government or a public international institution) that
the Arbitral Tribunal determines to be compelling; orAntrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

(g) considerations of procedural economy, proportionality, fairness or equality of the
Parties that the Arbitral Tribunal determines to be compelling.
Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
3. The Arbitral Tribunal may, at the request of a Party or on its own motion, exclude evidence
obtained illegally.
4. ........."
45. Tribunal has not recorded any finding that the evidence of pre- contractual negotiations was
covered by any of the conditions or circumstances stipulated in Article 9(2) and 9(3) that permit
exclusion of the evidence and further it has not recorded that there was any request from Devas that
said evidence was liable to be excluded. On the other hand the pre-contractual evidence was not
disputed by Devas.
46. At this juncture it may be relevant to examine as to what was the evidence that has been
excluded by the Tribunal from consideration incorrectly.
47. As per Antrix, Devas on 12.09.2004, sent an initial term sheet to ISRO, hoping at that time that
ISRO would be a party to the contract.
48. Devas had proposed as under:
"In the event that ISRO terminates the Definitive Agreement for any other reason
[other than non-payment of fees by Devas] following signature of Definitive
Agreements and prior to Devas raising its institutional financing, ISRO shall refund
to Devas all the amounts Signing Date:29.08.2022 15:28:39 This file is digitally
signed by PS to HMJ Sanjeev Sachdeva.
paid by Devas to ISRO for any reason whatsoever, plus liquidated damages of INR
460 million for investment in the business and related losses including but not
limited to investments, capital raising costs, lost business opportunities, reputation
loss, penalties, development costs, mobile receiver and terrestrial repeater
development, infrastructure costs, severances, and vendor and dealer negotiation
costs. In the event that ISRO terminates the Definitive Agreement for any other
reason following signature of Definitive Agreements and after Devas has raised its
first Institutional round of funding, ISRO shall refund to Devas all the amounts paid
by Devas to ISRO for any reason whatsoever, plus, liquidated damages of INR 6.9
billion for investment in the business and related losses including but not limited to,
investments, capital raising costs, lost business opportunities, reputation loss,
penalties, development costs, mobile receiver and terrestrial repeater development,
infrastructure costs, severances, and vendor and dealer negotiation costs."Antrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

49. The Initial Term sheet was not agreed upon and thereafter on 20.09.2004, Devas delivered a
second draft „Binding Term Sheet. At this juncture Devas was informed that Antrix would be the
contracting party and not ISRO. Devas continued to propose the high liquidated damages.
50. From the Term Sheets proposed it was evident that it was within the knowledge and
contemplation of Devas that it had to obtain relevant licenses and approvals (including telecom
approvals), without Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ
Sanjeev Sachdeva.
which it could not carry out its proposed multimedia business via satellite or terrestrially in India.
51. The Terms sheets proposing high liquidated damages were rejected by ISRO by communication
dated 14.09.2004 and 20.09.2004, stating inter alia that the term sheet was "extremely one sided
and highly demanding" and that the contracting party would be Antrix, not ISRO.
52. After rejection of the Terms sheets proposed by Devas, it did not propose any further Term
Sheet, but on 06.12.2004 in addition to the agreed upon Article 7 proposed that "in the case of
material breach, in addition to termination and refund of fees, the terminating party reserves the
customary rights and remedies provided by Indian law against the defaulting party.". Thereby
dispensing with the liquidated damages provisions but sought to preserve the parties remedies for
material breach under Indian contract law.
53. This propose of Devas was also rejected, thereby stipulating that the only consequence of
termination would be the refund of the UCRF as provided in Article 7.
54. The note sheets and the evidence of pre-contractual negotiations clearly show the intention of
the parties. Devas had proposed not once but repeatedly the option of liquidated damages and
damages beyond Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ
Sanjeev Sachdeva.
refund of the UCRF, which was specifically rejected by Antrix and what was finally agreed upon was
refund of UCRF.
55. The Tribunal thus clearly misdirected itself in rejecting the evidence of pre-contractual
negotiations. In arriving at its interpretation of Article 7 the Tribunal incorrectly excluded from
consideration the evidence of pre-contractual negotiations. Said interpretation is clearly contrary to
the intention of the parties as is evident from the evidence that has been wrongly excluded by the
Tribunal.
56. Tribunal has held Antrix to liable on the ground that it committed a material breach of the
Agreement. Tribunal has committed a patent illegality as the finding returned is contrary to several
findings returned by the Tribunal itself in this very award.Antrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

57. On the one hand the Tribunal holds that the decision of the Cabinet Committee on Security
(CCS) to annul the contract was an act of a governmental authority acting in a sovereign capacity
and thus amounted to a Force Majeure event as contemplated by the contract, however, goes on to
hold that Antrix is liable for wrongful termination.
58. At this juncture it would be necessary to refer to a brief overview of the international regulation
of radio frequencies and the Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to
HMJ Sanjeev Sachdeva.
spectrum that was sought to be leased to Devas and the rationale behind the CCS decision to annul
the contract.
59. As noticed in the impugned Award, there are a limited number of available radio frequencies in
the world, which are known by names such as C, extended C band, Ku. and S-band. As radio
frequencies do not stop at national boundaries, governments have sought to regulate their allocation
through the International Telecommunications Union (ITU), an agency of the United Nations.
60. The ITU is responsible for allocating available spectrum amongst its member States. Once it has
allocated spectrum to a State, that State is then free to distribute the spectrum in accordance with its
national laws.
61. By the early 1970s, ITU had allocated the use of part of the S- band radio frequency in India to
the Government of India and Government of India allocated the right to use S-band in India to the
Department of Space.
62. India had been allocated a total of 190 MHz of capacity by ITU in the portion of the S-band
encompassing frequencies between 2500 MHz and 2690 MHz.
63. Pursuant to its national planning and to satisfy its national requirements, India, internally,
allocated the 190 MHz that had been Signing Date:29.08.2022 15:28:39 This file is digitally signed
by PS to HMJ Sanjeev Sachdeva.
identified by the ITU. It allocated 110 MHz; (in frequencies 2500 - 2555 MHz for uplink, i.e.,
earth-to-space transmissions, and 2635 - 2690 MHz for downlink, i.e., space-to-earth
transmissions) for mobile satellite services (MSS), which are services that permit two way
communications. India allocated the remainder, in frequencies 2555- 2635 MHz, for downlink only
and only for broadcast satellite, services (BSS, i.e., the transmission of one-way signals from the
satellite to earth to multiple recipients, all of which can receive the signals provided that they have
the necessary antenna).
64. From the outset of Indias space program, the S-MSS frequencies were utilised solely for
non-commercial, national strategic and societal purposes, including, for example, military
communications and educational and medical interactions. The S - BSS band has been used only for
non-commercial national interest purposes, including at the outset by the national televisionAntrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

corporation, Doordarshan / Prasar Bharati, the national radio corporation. All India Radio, national
weather forecasting and national emergency warnings and communications.
65. In the early 2000s, 40 MHz of the S-MSS capacity (frequency ranges 2535-2555 MHz and
2635-2655 MHz) were assigned by the Government for use in the terrestrial telecommunications
industry, Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev
Sachdeva.
leaving 80 MHz of S-BSS and 70 MHz of S-MSS capacity for satellite services.
66. Subject Contract provided for the lease of five C x S transponders and five S x C transponders on
each of the two satellites. The five downlink transponders on each satellite consumed a total of 30
MHz of S-BSS spectrum. Thus, the Contract provided for the lease of 75% of Indias S-BSS
allocation (30 MHz for each satellite, for a total of 60 MHz of Indias total of 80 MHz of S-BSS) and
10 MHz of the S-MSS allocated for satellite use.
67. Owing to the unique nature of the S-band spectrum where its frequencies have low attenuation
i.e. the signal does not fade and it can also be sent and received by small units, such as mobile
phones and laptop computers, without requiring the antenna on such units to be pointed precisely
at the satellite Indias military and paramilitary agencies also had demands for S-band capacity for
non-commercial purposes.
68. In May 2003, ISRO launched a satellite for military purposes to utilise 20 MHz segment of
S-MSS capacity. The military, however, was looking for higher performance and capacity and
demanded from ISRO a communication system/with greater capacity (including increased data
rates and the ability to service a larger number of terminals).
Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
69. This was followed by a demand in April 2004, by the military for a dedicated satellite for Naval
use and the Naval Communications were most intricately complex, because of four distinct
participants viz. ships, submarines, aircraft and shore authorities, all of which needed to
communicate with each other in real time. This requested satellite, using 8 MHz of S-band capacity,
was launched in August 2013.
70. In October 2005, a Note by a senior military officer outlined the importance of relying on space
technology for defence, particularly starting in 2008 when a new plan would enter in place. This
Note projected the bandwidth requirements of the Army, Navy and Air Force through 2010, 2015
and 2020. With respect to the S-band, the projected needs were for 86 MHz by 2010,151 MHz by
2015 and 208 MHz by 2020.
71. In February 2006, military leaders met with the Department of Space to address the projected
S-band capacity required for the Defence Space Vision through 2020. The total BW contemplated
for S-band was 86 MHz - 151 MHz - 208 MHz for short, medium & long term respectively.Antrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

72. In March 2007, the Ministry of Defence advised the Department of Space of the particularly
critical requirements of the Army for sufficient S-MSS bandwidth to support the exponential Signing
Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
growth in the required mobile briefcase terminals, stating that 60 MHz would be needed by 2010,
an additional 15 MHz would be required by 2015 and an additional 45 MHz would be required by
2029.
73. In August 2007, an expert committee on S-band was constituted to assure adequate access in the
national interest as opposed to commercial usages. In September 2007, a report issued by the
Expert Committee on Spectrum and Satellite Uses of Frequency Band 2.5 to 2.69 GHz (S-band) by
Defence Services stated that Satellite services in S-band could not coexist with the terrestrial
services and if the spectrum was not safeguarded against the bid by the commercial operators in
India, said spectrum would not be available for any future utilization for the military applications.
74. Several meetings and task force was constituted to examine the said issue leading to the Joint
Communications Electronics Staff of the HQ Integrated Defence Staff of the Ministry of Defence
reiterating the requirement of the S-band satellite bandwidth for the Army, Navy and Air Force up
to year 2022 as totalling 120 MHz.
75. These discussions regarding the strategic requirements for S - band capacity within the agencies
charged with national security and defence eventually led to the decision to terminate the Contract
on grounds of national interest and security.
Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
76. Detailed review of the capacity requirements for strategic purposes made it clear that the
national security requirements far exceeded, Indias S-band capacity. In addition to the 8 MHz of S-
band that were to be utilised by the satellite for the Navy that was ordered in 2004 and launched in
August 2013, by the end of 2009 17.5 MHz in S-band was identified as required for-meeting
immediate requirements of the Armed Forces; Another 40 MHz of S-band during the five-year
period from 2012 to 2017 (the 12th plan period); Another 50 MHz of S-band during the subsequent
five-year period (the 13th plan period from 2017-2022) besides meeting the Requirements from
internal security agencies, including the Border Security Force, the Central Industrial Security
Force, the Central Reserve Police Force, the Coast Guard and the Police for meeting their secured
communications needs and the capacity for the train- tracking requirements of the Indian Railways.
77. As per Antrix, in November 2009, Mr. A. Vijay Anand, the Joint Secretary of the Department of
Space, who was also its Chief Vigilance Officer, learned of possible irregularities relating to the
Contract and initiated a preliminary, internal review of certain of the allegations inter alia that "the
minutes of a 6 January 2009 meeting of a review committee of the Technical Advisory Committee
("TAG") of the Indian Satellite Coordination Committee ("ICC") relating to the experimental licence
requested by Devas had been altered in a Signing Date:29.08.2022 15:28:39 This file is digitally
signed by PS to HMJ Sanjeev Sachdeva.Antrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

manner that inter alia eliminated certain comments that had been made at the meeting by the
representatives of the Wireless Planning and Coordination Wing of the Department of
Telecommunications ("WPC"), headed by the Wireless Advisor to the Government of India, from
which Devas would have been required to seek its operating licence and frequency allocation."
78. It is contended that Providers of terrestrial telecommunications services had been demanding
the redeployment of S-band allocated for satellite services. However, the S-BSS frequencies had
been designated for space-to-earth broadcasting only and were not authorised for terrestrial
transmission, as the WPC representatives observed at the meeting. This meant that the Respondent
Devas itself would not be permitted to use the S-BSS frequencies for terrestrial transmission under
existing policy, even though this was precisely its objective.
79. The disclosure of potential irregularities and the information developed by the preliminary
internal investigation led to the establishment by the Department of Space of a single man
committee, Dr. B. N. Suresh, a former member of the Space Commission.
80. In his Report on GSAT-6, that was delivered to Dr. Radhakrishnan, the Secretary of the
Department of Space, on 07.06.2010, Dr. Suresh noted that only 10% of the capacity of the Signing
Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
transponders to be leased to the Respondent under the Contract would be available for ISRO, which
would bring in certain limitations on the availability of spectrum for any essential demands in the
future.
81. Dr. Radhakrishnan directed that the Suresh Report be examined inter alia by the Satellite
Communications & Navigation Program Office.
82. Following the receipt of the Suresh Report, the Department of Space consulted the Ministry of
law and justice and the Department-of Telecommunications.
83. By opinion dated 18.06.2010, the Ministry of Law and Justice stated that Satellites, referred to
in the agreement, are no doubt the property of the Central Government and Central Government
under its sovereign functions is duty bound to take care of its strategic needs in respect of various
forces like BSF, CISF, CRPF, RPF etc. any commercial activity cannot override to sovereign function.
The Central Government/ISRO is not duty bound to provide orbit slot to Antrix for commercial
activities, especially when there is strategic requirements. When the Central Government/ISRO
denies the orbit slot to Antrix in exercise of its sovereign power and function, such event may fall
under the category of Force Measure as contemplated in Article 11.
Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
84. The Ministry of Law and Justice further opined that the Central Government (Department of
Space), in exercise of its sovereign power and function, if so desire and feel appropriate, may take a
policy decision to the effect that due to the needs of strategic requirements, the Central Govt/ISROAntrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

would not be able to provide orbit slot in S band for operating PS1 to the ANTRIX for commercial
activities. In that event, ANTRIX in terms of Article 7 (c) read with Article 11, of the agreement may
terminate the agreement and inform M/s DEVAS accordingly. However on such termination
ANTRIX shall be required to reimburse DEVAS all the Upfront Capacity Reservation Fees and
corresponding service taxes received by ANTRIX till that date."
85. The Department of Telecommunications in its memorandum dated 06.07.2010 stated that "The
agreement between DOS and ANTRIX indicates that M/s Devas is allowed to use part of frequency
bands 2555- 2635 MHz and 2500-2535 & 2655-2690 MHz whereas DOS sought the ITU
coordination for MSS to be used for strategic operations. The spectrum planned by DOS for strategic
use is not to be shared with commercial applications as in the case of M/s Devas Multimedia."
86. The Department of Space presented the matter to the Space Commission for its consideration.
The Space Commission, which formulates the policies and oversees the implementation of the
Indian Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev
Sachdeva.
space programme to promote the development and application of space science and technology for
the socio-economic benefit of the country, was then comprised of: (i) the Secretary of the
Department of Space; (ii) the Minister of State, Prime Ministers Office; (iii) the Cabinet Secretary;
(iv) the Principal Secretary to the Prime Minister;
(v) the National Security Advisor; (vi) the Principal Scientific Advisor to the Government of India;
(vii) the Secretary, Department of Economic Affairs; (viii) the Director, ISRO Satellite Centre; (ix)
Finance Member, Space Commission; and (x) a Professor of Aerospace Engineering.
87. The Minutes dated 02.07.2010 of the Space Commission inter alia state:
"Focusing on the issue. Chairman stated that ISRO holds, in S band spectrum, 80
MHz in BSS and 70 MHz in MSS. The Antrix-Devas lease agreement on GSAT-6 and
6A would take away 70 MHz of the total S band spectrum available.
Shri Shivshankar Menon, NSA [National Security Advisor] stated that S band
spectrum is crucial for several strategic and societal services. The Integrated Space
Cell of IDS [Integrated Defence Staff], Ministry of Defence have projected a need for
17.5 MHz in S band for meeting the immediate requirements of Armed Forces,
another 40 MHz during the 12th plan period and an additional 50 MHz during the
13th plan period. Armed Forces have also projected the need to build S band satellite
capacity ... for national security related mobile Signing Date:29.08.2022 15:28:39
This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
communications. There are further demands for S band transponders from internal
security agencies viz., BSF, CISF, CRPF, Coast Guard and Police for meeting their
secured communication needs. Indian Railways have also projected S bandAntrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

requirements for train-tracking. Commission noted that, in view of these emerging
requirements, there is an imminent need to preserve the S band spectrum for vital
strategic and societal applications.
..........
It was noted that Space spectrum is a vital national resource and it is of utmost
importance to preserve it for emerging national applications for Strategic uses and
societal applications. Given the limited availability of S band spectrum, meeting the
strategic and societal needs is of higher priority than commercial/ entertainment
sectors."
88. The Space Commission concluded that the Department of Space may take necessary actions and
instruct Antrix to annul the Antrix Devas contract. Thereafter an opinion was taken from the
Additional Solicitor General.
89. Consistent with the Additional Solicitor Generals opinion, and in accordance with Rule 4 of the
Transaction of Business Rules of the Government of India, a note was placed before the Cabinet
Committee on Security to for decision.
Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
90. The Cabinet Committee on Security, comprised of the Prime Minister, the Minister of Defence,
the Minister of Home Affairs, the Minister of External Affairs and the Minister of Finance and is the
highest authority within India for matters relating to internal and external security and defence. As
per Antrix it is the appropriate governmental body to take a policy decision regarding use of S-band
for strategic needs.
91. In February 2011, the Cabinet Committee on Security took the decision to deny orbital slot in
S-band to Antrix for any commercial activities and to annul the Contract. The report of the Cabinet
Committee on Securitys decision stated as under;
"Taking note of the fact that Government policies with regard to allocation of
spectrum have undergone a change in the last few years and there has been an
increased demand for allocation of spectrum for national needs, including for the
needs of defence, para-military forces, railways and other public utility services as
well as for societal needs, and having regard to the needs of the countrys strategic
requirements, the Government will not be able to provide orbit slot in S band to
Antrix for commercial activities, including for those which are the subject matter of
existing contractual obligations for S band.
In the light of this policy of not providing orbit slot in S Band to Antrix for
commercial activities, the Agreement for the lease of space segment capacity on
ISRO/Antrix S-Band spacecraft by Devas Multimedia Pvt. Ltd. entered SigningAntrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev
Sachdeva.
into between Antrix Corporation and Devas Multimedia Pvt. Ltd. on 28th January,
2005 shall be annulled forthwith."
92. In accordance with the decision of the Cabinet Committee on Security, the Department of Space,
on 23.02.2011, directed Antrix to notify Devas of the decision of the Government of India regarding
termination of the Contract.
93. Antrix, accordingly, on 25.02.2011 notified Devas that the Contract was terminated inter alia
citing Article 11 and Article 7(c) of the Contract and thereafter tendered the UCRF paid by Devas till
that date.
94. It is submitted by Antrix that on 27.08.2015, after reconfiguration of the GSAT-6 satellite for
military use, the satellite was launched and is now operating in S-band, dedicated to the military. It
is further contended that the decision of the Cabinet Committee on Security on the use of the
S-band, remains in effect even today and there has been no change in the policy of not providing
orbital slot in S-band for commercial use and of reserving S-band for military use.
95. Devas contended before the Tribunal that Antrix did not have the right to terminate the Contract
pursuant to Article 7(c) of the Contract.
Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
96. Article 7(c) stipulates that Antrix may terminate the Agreement in the event Antrix is unable to
obtain the necessary frequency and orbital slot coordination required for operating PS1. As per
Devas Antrix was able to and did obtain the necessary frequency and orbital slot coordination
required for operating PS1.
97. The Tribunal has held that Antrix was not required to apply for frequency and orbital slot
clearance from the Cabinet Committee on Security (CCS) and thus it could not rely upon the CCS
decision alone in order to terminate the agreement pursuant to Article 7(c). T
98. he Tribunal further held that even if the CCS decision had the effect of annulling any necessary
clearance or approval that Antrix had obtained, that would not be sufficient to enliven Article 7(c) as
what was required was „inability to obtain a relevant clearance and not „inability to retain a
clearance.
99. Once again a patent illegality has been committed by the Tribunal as this finding is complete
contrary to the other finding returned by the Tribunal and as such cannot be accepted. There is no
dispute to the material placed by Antrix with regard to the decision of the Department of Space as
well as the Cabinet Committee on Security.Antrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
100. The Tribunal has also noted that the Cabinet Committee on Security in its decision taken in
February 2011 decided that "the Government will not be able to provide orbit slot in S band to
Antrix for commercial activities".
101. This direction of the Cabinet Committee on Security clearly shows that Antrix did not have the
orbital slot coordination. There is no counter by Devas to the decision of the Cabinet Committee on
Security. This clearly contradicts the reasoning of the Tribunal when it holds that Antrix could not
resort to Article 7(c) as it did not cover „inability to retain a clearance.
102. It may further by noticed that this finding of the Tribunal is contradicted by the finding
returned by it on the question as to "was there any „Force Majeure Event as defined in Article 11 of
the Devas Agreement?"
103. The Tribunal has returned a finding that the Cabinet Committee on Securities decision to
annul the agreement was an act of governmental authority acting in its sovereign capacity for the
purpose of Article 11(b) of the Contract.
104. However, after holding that the decision of the Cabinet Committee on Security was an act of a
government authority acting in its sovereign capacity and covered under Article 11(b), it holds that
Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
Antrix cannot rely upon it because as per the Tribunal it was brought about by Antrixs own actions.
105. The reasoning of the Tribunal is self contradictory and as such also the award suffers from
patent illegality on the face of it.
106. On the one hand the Tribunal rejected the contention of Devas to disregard Antrixs distinct
legal entity merely because it was the governments marketing arm or performed commercial
activities for government benefit and it also rejected the contention that Antrix itself instigated the
Force Majeure Event. However, on the other hand holds the CCS decision was beyond Antrixs
control once it was made but it could have prevented the CCS from receiving a proposal to annul the
Contract.
107. The Tribunal holds that if Dr Radhakrishanan had, from the time that he was appointed
Chairman of Antrix, and acting in his capacity as Chairman of Antrix, done everything in his power
to ensure that the agreement remained on foot, he would not have taken any of-the steps that led to
the CCS being asked to approve the annulment of the agreement. As a result, those steps would not
have occurred.
108. This is contradictory to the very stand of Devas and the finding returned by the Tribunal that
when Dr. Radhakrishanan obtained the Signing Date:29.08.2022 15:28:39 This file is digitally
signed by PS to HMJ Sanjeev Sachdeva.Antrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

opinion of the Ministry of Law Justice, he was not acting in his capacity as Chairman of Antrix but
was acting in his capacity as Secretary of the Department of Space and/or Chairman of ISRO or the
Space Commission.
109. The Tribunal has returned a perverse finding that "Further, since Dr Radhakrishnan (acting in
his capacity as Chairman of Antrix) could have prevented the CCS from being asked to annul the
agreement, Antrix could have effectively prevented the CCS from making that decision, which means
that the CCS decision was not beyond Antrixs reasonable control."
110. On the one hand the Tribunal holds that Dr. Radhakrishnan was not acting in his capacity as
Chairman of Antrix and was acting in his capacity as Secretary of the Department of Space and/or
Chairman of ISRO or the Space Commission on the other holds that he could have prevented CCS
from taking the decision to annul the contract if he had acted in his capacity as Chairman of Antrix.
111. What the Tribunal is holding is that Dr. Radhakrishanan should have held back sensitive
material pertaining to the security of the state from the CCS. As noticed hereinabove the Cabinet
Committee on Security, comprised of the Prime Minister, the Minister of Defence, the Minister of
Home Affairs, the Minister of External Affairs and the Signing Date:29.08.2022 15:28:39 This file is
digitally signed by PS to HMJ Sanjeev Sachdeva.
Minister of Finance and is the highest authority within India for matters relating to internal and
external security and defence.
112. The decision of the CCS is premised on the fact that there has been an increased demand for
allocation of spectrum for national needs, including for the needs of defence, para-military forces,
railways and other public utility services as well as for societal needs, and having regard to the needs
of the countrys strategic requirements. This decision has been recognised by the Tribunal as a
decision taken by a government authority acting in its sovereign capacity.
113. Returning these erroneous perverse findings, the Tribunal further goes on to hold that the
termination on the part of Antrix amounts to a repudiatory breach on its part.
114. Repudiatory breach presupposes a breach on the part of one party. Breach of the Contract
would arise when one party by its conduct commits a fundamental breach of the contract. To
establish breach, it must be first established that a party is able to perform its obligations under the
contract but is refusing to do so. Breach cannot be held to be committed if the party is prevented
from performing its obligations on account of factors beyond its control.
115. The Supreme Court of India in HPA International v. Bhagwandas Fateh Chand Daswani, (2004)
6 SCC 537 referred to the Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to
HMJ Sanjeev Sachdeva.
observations of Lord Reid in the House of Lords decision in Suisse Atlantique [Suisse Atlantique
Société DArmement Maritime S.A. v. N.V. Rotterdamsche Kolen Centrale, (1966) 2 All ER 61 :Antrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

(1967) 1 AC 361 (HL)]: (All ER pp. 70 I - 71 A) "I think that it would be open to the
arbitrators to find that the respondents had committed a fundamental or repudiatory
breach. One way of looking at the matter would be to ask whether the party in breach
has by his breach produced a situation fundamentally different from anything which
the parties could as reasonable men have contemplated when the contract was made.
Then one would have to ask not only what had already happened but also what was
likely to happen in future. And there the fact that the breach was deliberate might be
of great importance."
116. As noticed from Article 7(c) of the Contract parties had in their contemplation that Antrix had
to obtain the orbital slot coordination and the CCS decided not to grant the orbital slot coordination
to Antrix. Tribunal has held that the decision of the CCS in declining the grant of orbital slot to
Antrix was a decision of a governmental authority in exercise of its sovereign function and
amounted to a Force Majeure event and covered under article 11(b). Thus it could not have held that
the alleged breach on the part of Antrix was deliberate.
Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
117. Further, the award suffers from patent illegality as the Tribunal had overlooked the provisions
of Article 25 of the Contract that stipulates that the Agreement shall not be binding on DEVAS or
ANTRIX until and unless ANTRIX receives all the requisite governmental and other regulatory
approvals. Including those referred to in this Agreement. Admittedly. Antrix did not receive the
orbital slot in S-band, which was a prerequisite for the provision of the Devas services.
118. During the pendency of these proceedings Antrix moved an application seeking to amend the
petition and to incorporate certain subsequent events and to take additional grounds. Said
application was opposed by DEMPL on the ground that said application was filed after the expiry of
the statutory period for filing objections under section 34 of the Act.
119. Mr. N. Venkataraman, Learned Additional Solicitor General appearing for Antrix restricted his
submissions and placed reliance upon the Judgments passed by the National Company Law
Tribunal dated 25.05.2021, National Company Law Appellate Tribunal dated 08.09.2021 and the
Supreme Court of India dated 17.01.2022. He submitted that this court can take judicial notice of
the Judgments. Further, principles of res judicata and issue estopple are also relied upon in support
of the said contention.
Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
120. Under Section 57 of the Evidence Act, 1872, Courts have to take judicial notice of all laws in
force in the territory of India. The Judgment of the Supreme Court of India has the force of law in
terms of Article 141 of the Constitution of India.
121. As noticed hereinabove, Antrix sought winding up of Devas under Section 271(c) read with
Section 272(1)(e) of the Companies Act, 2013 before the NCLT alleging that Devas was formed for aAntrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

fraudulent and unlawful purpose and its affairs had been conducted in a fraudulent manner.
122. NCLT by its judgment dated 25.05.2021 while allowing the petition seeking winding up of
Devas specifically noticed the fraudulent activities on the part of Devas.
123. NCLT held that the incorporation of Devas itself was with fraudulent intention to grab
prestigious contract in question from Antrix in connivance and collusion with the then officials of
Antrix.
124. It noticed that Devas was incorporated on 17th December, 2004 and was able to obtain the
Contract on 28th January, 2005 in less than 45 days from the date of its inception. NCLT held that it
is a matter of fundamental economics, rather common sense that in order to obtain a prestigious,
sophisticated contract like the contract in question, the Signing Date:29.08.2022 15:28:39 This file
is digitally signed by PS to HMJ Sanjeev Sachdeva.
concerned Company should possess adequate experience and infrastructure in the field for a
considerable period of time.
125. NCLT noticed that it was not in dispute that Devas, at the time of entering into the contract, did
not possess the minimum experience even to qualify to participate in such a contract, much less
obtain it.
126. NCLT held that it had falsely contended that it has experienced Scientists/Technical experts to
get sophisticated technology as were required to provide in terms of Contract in question. NCLT was
of the view that same was possible only with direct collusion and connivance with the then officials
of Antrix.
127. NCLT noticed that Union of India came to know about the fraud only in the year 2016, when
the CBI investigated the issue and thereafter initiated various proceedings by invoking various
provisions of Indian Penal Code, Prevention of Money Laundering Act, Foreign Exchange
Management Act etc., against Devas, its officials, and the then officials of Antrix.
128. NCLT held that there is a long history of fraud and fraudulent activities committed by Devas
and its Management before and after its incorporation. It held that Devas brought Rs. 589 crores
into India, without doing any worthwhile service/business in India and has Signing
Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
siphoned off/diverted that money out of the Country except less than Rs. 100 Cr. under various
heads in India.
129. It also noticed that World Space India Private Ltd, which was alleged to be subsidiary of Devas,
as some of its Directors were working in that Company to render required technical service to Devas,
was incorporated on 05.06.1998. However, its name was struck off from Registrar of Companies as
it had failed to file the balance sheet and Annual returns for the year 2007 - 08.Antrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

130. NCLT further held that even the idea to incorporate Devas was with fraudulent intentions
coupled with malafide objects to enter into Agreement with Antrix with no responsibility at all. It
held that such a prestigious agreement with Government Owned Company was got signed by a clerk,
paying remuneration for the same. It held that the Agreement itself would become void ab-initio
and would not create any legal rights, much civil rights to Devas.
131. It held that the unlawful object of Devas was to bring foreign funds into India and then siphon
off the same by diverting those funds to foreign countries, into dubious accounts. Further, it did not
have any commercial antecedent to enter into such prestigious.
132. NCLT had also referred to the statement of financial position and working results of Devas from
2010-11 to 2018-19. It has noticed Signing Date:29.08.2022 15:28:39 This file is digitally signed by
PS to HMJ Sanjeev Sachdeva.
that as per Balance Sheets and Annual Reports filed with Registrar of Companies, Karnataka,
revenue (sale of services) for the years 2011 to 2014 are a mere Rs. 79,115/-, Rs. 58,429/-, RS.
36,489/- and Rs. 7,566/- respectively and nil for the years 2015 to 2019. Its fixed assets were
negligible and totally nil for the years 2018 - 19.
133. Both Devas and DEMPL impugned the Judgment dated 13.11.2020 of the NCLT before the
NCLAT. Both the members of the Bench of NCLAT dismissed the appeals but rendered separate
concurrent judgments both dated 08.09.2021.
134. The Judicial Member, Mr. Justice M. Venugopal in his judgement dated 08.09.2021, held that
the Agreement dated 28.01.2005 entered into between Devas and Antrix is mired with controversy.
135. It is noticed that the Agreement was signed by an „Article Clerk Mr. Gururaj of a „Chartered
Accountant who admittedly received a token amount for signing the Agreement on behalf of Devas.
Said Mr. Gururaj was not an authorised officer of the Company as required under Section 54 of the
Companies Act, 1956 and it is held that the said act is an „illegal and act of „trickery.
136. Mr. Justice M. Venugopal in his judgement dated 08.09.2021 held that admittedly, the
approval obtained by Devas from the Foreign Signing Date:29.08.2022 15:28:39 This file is digitally
signed by PS to HMJ Sanjeev Sachdeva.
Investment Promotion Board (FIPB) was only for „ISP Services and the „Department of
Telecommunication had only issued an „ISP Licence and therefore the Investments of the
overseas shareholders could not be utilised for payment of the UCRF for the proposed „S- Band
transponder, in breach of „FIPB approval and the „Department of Telecommunication Licence.
137. Further, it is held that out of Rs. 579 Crores of Foreign Investment amounts of Rs.
76,19,04,563/- share subscription / investment in „Devas America Inc (subsidiary of Devas) and
Rs.180,77,58,989/- were laundered out of the country under the garb of „Service Fee towards
business support services.Antrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

138. In between 2006 - October 2010, Devas, in the absence of Agreement had paid nearly Rs.40
Crores when the Agreement with the US Subsidiary was entered into only in October 2010. A sum of
Rs.256,96,63,544/- was sent out of India into the United States of America amounting to an extent
of Rs.230,11,14,734/- (Towards legal fees to American Firms) a total of Rs.487,07,78,278/- was
migrated into the US Entities thereby taking the same out of India, etc.
139. It is held that the money trail had violated „FIPB Policies, „FIMA and „PMLA. In short, the
investments of Rs.579/- Crores were collected by Devas mentioning the Devas Agreement dated
28.01.2005 and not for „Internet Services. Apart from that, Devas Signing Date:29.08.2022
15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
was not competent to render „Hybrid Services such as „Devas Services. Moreover, no technology
whatsoever was developed/made/owned/leased by the „Appellant and this claim was untrue.
140. An independent but concurrent opinion was authored by the other member of the NCLAT, Mr.
V.P. Singh, Member (T). Mr. V.P. Singh in his judgment inter alia held Devas could not have
delivered Devas Services in India due to the lack of policy framework and licensing regime for a new
service like Devas Services.
141. He further held that Devas did not own the technology nor had the right to use any such
technology to deliver the Devas Services. It is noticed that Devas had admitted that none of the
hybrid technologies that existed prior to 28.01.2005 could deliver the Devas Services.
142. Devas conceded before the NCLAT that the design of DMR and CID was at a conceptual level
and were to be developed at a future date. It was also not disputed that DMR and CID were portions
of the Devas Device and not the Devas Device itself. It was held that even in 2021 and especially
during 2005-2011, Devas did not develop the Devas Device.
Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
143. It is further held that on 28.01.2005, when the Agreement was signed, none of the procedures
prescribed by the SATCOM Policy were followed or complied with and the Agreement was signed in
complete contravention to the SATCOM Policy.
144. The NCLAT further noticed a stark contradiction between the Note for the Space Commission
and the Note for the Cabinet. The expression employed in the note for the Space Commission was „a
service provider and the expression employed in the Cabinet is was „several firm expressions of
interest by service providers.
145. NCLT noticed that from a single service provider before the Space Commission, it had been
fraudulently misrepresented that it was no longer a single service provider. Still, many others are
showing several firm expressions of interest. It was an undisputed fact that 97% of the capacity in
the GSAT-6/INSAT-4E satellite had been allotted to Devas fraudulently when this Cabinet Note was
prepared. This fact was concealed and suppressed in the note for the Cabinet.Antrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

146. NCLAT further noticed that, when the Cabinet Note prepared by DoS was forwarded for the
approval of the Union Cabinet, the Union Cabinet was under the pretext that other service providers
were showing several firm expressions of interest, which was factually false. Thus NCLAT held that
the Cabinet Note prepared by DoS suffered from suppression of material facts and fraudulent
Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
misrepresentations and same could not confer any benefit on Devas under the agreement dated
28.01.2005.
147. An ex-director of Devas on behalf of Devas and DEMPL, both filed appeals before the Supreme
Court of India impugning the Judgment of the NCLAT.
148. Supreme Court of India by its Judgment dated 17.01.2022 dismissed both the appeals.
149. Supreme Court rejected the contention of Devas that Antrix was estopped from raising the plea
of fraud as it has not terminated the agreement on the ground of fraud and had also not set up fraud
as a defence before the Arbitral Tribunal.
150. The Supreme Court on the plea of estoppels held as under:
"9.8 But the question is as to whether all the above would lead to an inference of
estoppel against Antrix. The fact that the Agreement dated 28.01.2005 was not
terminated on the ground of fraud, through the letter dated 25.02.2011, cannot take
the appellants anywhere. The earliest First Information Report for the offences under
Section 420 read with Section 120B of the IPC was filed by the CBI only on
16.03.2015. The officers of Antrix as well as officials of the Government were also
implicated in the FIR for offences under the Prevention of Corruption act, 1988.
Therefore, the appellants cannot set up a plea of estoppel on the ground that the
termination of the Agreement in the year 2011 was not on Signing Date:29.08.2022
15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
the ground of fraud, when the discovery of fraud itself was many years later.
9.9 For the very same reason, the failure of Antrix to plead fraud in the ICC
arbitration proceedings, cannot also operate as estoppel. The arbitral proceedings
commenced in the year 2013 and the award itself was passed on 14.09.2015. Antrix
cannot be expected to plead fraud in the arbitral proceedings, even before the
discovery of fraud.
9.10 The Chartered Accountants/Auditors are not experts either in Criminal Law or
in the technology that formed the subject matter of the Agreement between Antrix
and Devas. The statement of Chartered Accountants are always qualified with certain
riders such as "according to the information and explanations given to us in the
course of our audit" or "to the best of our knowledge and belief and according to theAntrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

information and explanations given to us".
9.11 In fact, the Companies (Auditors Report) Order, 2015 which was superseded by another order
in 2016 was issued by the Central Government in exercise of the power conferred by Section 143(11)
of the Companies Act, 2013. Section 143(12) obliges the Auditor to report to the Central
Government, if he has reason to believe that an offence of fraud of a particular dimension was being
committed in the company by its officers or employees. Subsection (13) of Section 143 also provides
immunity to the Auditors for furnishing a report to the Central Government, if it is done in good
faith. Subsection (12) & (13) of Section 143 read as follows:
****** Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ
Sanjeev Sachdeva.
9.12 If the auditors of a company fail to make a report in terms of Section 143(12),
despite having knowledge about the fraud, they may become liable for penal
consequences under Section 448 read with Section 447 of the Companies Act, 2013.
But the failure of the auditors to make a report as required by Section 143(12) or as
required by the order issued under Section 143(11), cannot operate as estoppel
against the company. The auditors report can neither be taken as gospel truth nor
act as estoppel against the company. The statement in the auditors report, is as per
the information given to them or as per the information culled out to the best of their
ability.
9.13 The reliance placed upon Section 19 of the Indian Contract Act, 1872 to raise the
plea of estoppel may not wholly be correct. Section 19 of the Indian Contract Act,
deals with only one type of fraud namely, a fraud perpetrated on a party to secure his
consent to an agreement. Section 19 begins with the words "when consent to an
agreement is caused by coercion, fraud.....". Frauds other than those used to induce
the consent of a party to an agreement, are not covered by Section 19. In fact, the
definition of fraud under Section 17 is also confined only to certain acts committed by
a party to a contract. There are cases where a party may perpetrate a fraud either
upon non-contracting parties or upon the Government or even upon the courts. The
principle that fraud vitiates all solemn acts, will itself be rendered nugatory, if the
understanding of fraud is confined only to the realm of contract. 9.14 In the case on
hand, the fraud alleged by Antrix is not solely on the ground that their consent to the
Agreement dated 28.01.2005 was vitiated by fraud. What Signing Date:29.08.2022
15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
is alleged in the petition for winding up are, (i) formation of the company for fraudulent or unlawful
purpose; (ii) fraud in the conduct of the affairs of the company; and
(iii) fraud on the part of the persons who were involved in the formation and/or in the management
of affairs of the company. The fraud relatable to the agreement, is only one facet of the whole
scheme of things. Therefore, we have to go beyond section 19 of the Contract Act. 9.15 In fact, theAntrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

Explanation (i) under Section 447 of the companies Act, 2013 also defines fraud, but for the
purposes of Section 447. What is covered by Section 271(c) of the Companies Act, 2013 is a fraud
that goes beyond what lies in the realm of contract or in the realm of the penal provisions of the
Companies Act, 2013. Hence the contention that Antrix was estopped from pleading fraud, was
rightly rejected by the Tribunal and we see no reason to taken a different view."
151. The plea of estopple on the ground that same was not raised by Antrix either at the time of
termination of the contract or as a defence before the Arbitral Tribunal has been specifically rejected
by the Supreme Court.
152. With regard to the plea that erroneous and perverse findings of fraud have been returned by the
NCLT and NCLAT, the Supreme Court culled out the findings recorded by the NCLT and NCLAT as
under:
"12.4 On the basis of the pleadings, the documents produced and the submissions
made, NCLT recorded the following findings namely, (i) that the incorporation of
Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev
Sachdeva.
Devas was with fraudulent intention to grab the prestigious contract in question, in
connivance and collusion with the then officials of Antrix; (ii) that it is not in dispute
that at the time of entering into the contract, Devas did not have the technology,
infrastructure or experience to perform their obligations under the Agreement; (iii)
that one of the subscribers to the Memorandum of Association of the company in
liquidation was an Auditor by name Shri M. Umesh, whose Article Clerk by name
Gururaj was the one signed the Agreement; (iv) that the Executive Director of Antrix
who signed the Agreement of behalf of Antrix is one of accused in the criminal cases;
(v) that the incorporation of Devas was with fraudulent motive and unlawful object,
to bring money into India and divert it by dubious methods; (vi) that even after the
termination of the Agreement, Devas was not carrying on any business operations;
(vii) that the objective of Devas was hardly to do any business except grabbing
Primary Satellite I (PSI) and Primary Satellite II (PSII), and that therefore the
requirements of Section 271(c) stand satisfied.
12.5 The order of the Appellate Tribunal is in two parts; the first authored by Member (Judicial),
and the second authored by Member (Technical). The Member (Judicial) noted, (i) that the
company in liquidation failed to establish either the existence of technology or the ownership of
intellectual property rights over the stated technology; (ii) that even according to the affidavit of Shri
M. G. Chandrashekar, Devas had ample time to develop Devas Technology, meaning thereby that its
nonexistence at that time was admitted; (iii) that the company did not have a single approval,
permission or licence to render Devas services utilising Devas technology; (iv) that the approval of
the Space Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev
Sachdeva.Antrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

Commission for building a satellite for Devas, was secured only after finalisation of commercial
terms but without apprising the Space Commission of the same; (v) that even in the cabinet note,
prepared by the Department of Space on 17.11.2005 a full picture was not recorded; (vi) that there
was a contravention of the SATCOM Policy; (vii) that though the original minutes of the meeting
required Devas to secure a spectrum licence from Wireless Planning Committee (WPC), after
appearing before the apex committee with requisite technical details, the minutes of the meetings
were manipulated later as though the company was exempted from the requirement; (viii) that after
objections about the manipulations, the original minutes of the meeting came to be restored, on
20.11.2009, but this happened only after the grant of experimental licence on 07.05.2009; (ix) that
in any case the experimental licence was to establish Wireless Telegraph Station in India under the
India Telegraph Act, 1885, without which experimental trials could not have been conducted; (x)
that Devas obtained IPTV licence as part of ISP licence, which has nothing to do with what was
offered as DEVAS services; (xi) that the agreement dated 28.01.2005 made no reference of IPTV;
(xii) that undeniably, Devas services cannot be provided with ISP licences; (xiii) that after bringing
an amount of Rs 579 crores into India, a major portion was taken out of India; (xiv) that the only
business activity carried on by Devas was to provide ISP services in a particular locality in Bangalore
for a few residents and that too for a short duration, which made Devas earn a revenue of Rs.
80,000/; (xv) that the diversion of Rs. 489 crores and Rs. 58 crores for non ISP purposes is violative
of ISP licence, which comes squarely within the ambit of Section 271(c); (xvi) that Signing
Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
Devas fraudulently approached FIPB through the ISP route to avoid scrutiny by Department of
Space; (xvii) that the investors of Devas actually became shareholders and they also had their
nominees on the Board of Devas; (xviii) that therefore these persons were also guilty of the conduct
of the affairs of Devas in the manner stated; (xix) that the Share Subscription Agreement dated
06.03.2006 entered into with the investors contains a recital as though appropriate licences have
been validly issued or assigned to the company, though in fact the only licence namely ISP licence
was obtained much later on 02.05.2008 and (xx) that therefore the formation of the company and
the conduct of the affairs of the company were fraudulent and the persons concerned therewith were
also guilty of fraud.
12.6 In his independent but concurrent opinion the Member (Technical) of NCLAT classified the
items of fraud into eight categories. He first found that the company was formed and the Agreement
was entered into with the stated object of providing a bouquet of services, which were nonexistent.
The second category of fraud dealt with by the Member (Technical) related to the misrepresentation
in the Agreement. The third category of fraud concerned the violation of SATCOM Policy. The fourth
category was actually an extension of the third category which related to SATCOM Policy. The fifth
category was about suppression and misrepresentation in obtaining the approval of the cabinet. The
sixth category of fraud revolved around the ISP licence dated 02.05.2008, of which IPTV licence was
a part, but which had nothing to do with Devas Services. The seventh category related to the
fraudulent manner in which experimental licence was obtained and the eighth category related to
FIPB approvals and money trail. The Signing Date:29.08.2022 15:28:39 This file is digitally signed
by PS to HMJ Sanjeev Sachdeva.Antrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

Member (Technical) found the formation of company, the conduct of the affairs of the company and
those persons concerned in the formation and conduct of management of its affairs to be guilty of
fraud."
153. The Supreme Court thereafter held that though the appeal was an appeal under section 423 of
the Companies Act, 2013 and was only on a question of law and two forums namely NCLT and
NCLAT had recorded concurrent findings on facts, it was not open to the court to re-appreciate the
evidence but as the senior counsel for Devas had sought to project the case as one of perversity in
the finding recorded by both the tribunals, it held that there was no perversity in the finding
recorded by both the Tribunals and said findings were borne out by documents, which as noticed by
the Supreme Court, had not been challenged as fabricated or inadmissible.
154. The Supreme Court thereafter decided to go a little deeper to find out whether there was any
perversity in the findings recorded by the Tribunals and whether such findings could not have been
reached by any reasonable standards.
155. The Supreme Court thereafter held as under:
"12.8 The following undisputed facts emerge from the documents placed before the
Tribunal. The authenticity of these documents were never in question or denied:
(i) An agreement of a huge magnitude, for leasing out five numbers of C X S
transponders each of 8.1 Signing Date:29.08.2022 15:28:39 This file is digitally
signed by PS to HMJ Sanjeev Sachdeva.
MHz capacity and five numbers of S X C transponders each of 2.7 MHz capacity on the Primary
SatelliteI (PSI), was surprisingly and shockingly entered into by Antrix with Devas, without same
being preceded by any auction/tender process. It appears from the letter dated 27.09.2004 sent by
DEVAS LLC, USA to Shri K.R. Sridhara Murty, Executive Director of Antrix with copies to Dr. G.
Madhavan Nair, Chairman, ISRO and others that Shri Ramachandran Viswanathan, met the then
Chairman of ISRO and other officials in Bangalore in April 2003 and they met once again in
Washington D.C. during the visit of the then Chairman of ISRO. These meetings, which were not
preceded by any invitation to the public for any Expression of Interest, culminated in a
Memorandum of Understanding dated 28.07.2003. Though it is not clear where the MoU was
signed, there are indications that it was signed overseas;
(ii) It must be noted here that a one man Committee comprising of Dr. B.N. Suresh, former Member
of the Space Commission and Director of Indian Institute of Space Science and Technology, was
constituted on 8.12.2009, long after the commencement of the commercial relationship, to look
comprehensively into all aspects of the contract, both commercial and technical. According to the
Report submitted by him in May 2010, it was Forge Advisors, USA which made a presentation in
March 2003, on technology aspects of digital multimedia services to Antrix/ISRO, followed by a
presentation in May-2003 Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to
HMJ Sanjeev Sachdeva.Antrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

purportedly to the top management of Antrix/ ISRO. The MoU was signed thereafter;
(iii) But the documents filed by the appellants themselves show that a power point presentation was
made by Forge LLC on 22.03.2004, proposing an Indian joint venture to launch what came to be
known as DEVAS (which perhaps ultimately turned out to be ASURAS). It was claimed in the said
proposal that DEVAS platform will be capable of delivering multimedia and information services via
satellite to mobile devices tailored to the needs of various market segments such as consumer
segment, commercial segment and social segment. This presentation dated 22.03.2004 was
followed by a proposal dated 15.04.2004, about which we have made a brief mention in paragraph
3.4 above. This proposal obliged ISRO/Antrix to invest in one operational S-band Satellite with a
ground space segment to be leased to a joint venture between Forge and Antrix. What was to be
reserved for the joint venture was 97% of the space. The consideration receivable by ISRO/ Antrix
upon such a lease, was to be US $ 11 million annually for a period of 15 years. At least at this stage
the proposal to invest in an operational S-band satellite and the lease of nearly the entire space of
such satellite to a joint venture, should have come to the public domain, to see, (a) if the technology
existed; and (b) if the proposal was commercially viable. But it was not done;
(iv) On 14.05.2004, a Committee headed by one Dr. K.N. Shankara, Director, Space Applications
Centre was constituted purportedly to examine the Signing Date:29.08.2022 15:28:39 This file is
digitally signed by PS to HMJ Sanjeev Sachdeva.
technical feasibility, risk management including possibilities of alternate uses of space segment,
financial and market aspects and time schedule. According to the Report submitted by this
Committee, DEVAS was conceived as a new national service expected to be launched by the end of
2006 that would deliver video, multimedia and information services via high powered satellite to
mobile receivers in vehicles and mobile phones across India. The catch here lies in the fact that
while it was possible to deliver some of these services via terrestrial mode, it was not possible at that
point of time to provide this bouquet of services via satellite. Even today satellite phones are beyond
the reach of a common man. Mobile receivers or devices which can simply receive audio and video
content are different from mobile phones, which are capable of providing a two way communication.
The technology for providing the services through mobile phones was not in existence at that time,
which is why the proposal made by Forge Advisors included an expectation that such a service may
be launched by the end of 2006. It was with this expectation/promise that an Agreement was
entered into on 28.01.2005 but this so-called new national service was never launched as promised
in 2006. The launch of the services was not linked to the provision of a S-band satellite by Antrix, at
least at the time when negotiations took place;
(v) Admittedly, FIPB (Foreign Investment Promotion Board) approvals taken by Devas during the
period May-2006 to September-2009 were on the basis of the ISP (Internet Service Provider)
license Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev
Sachdeva.
secured from the Department of Telecommunications on 02.05.2008 and IPTV (Internet Protocol
Television) services license obtained on 31.03.2009;Antrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

(vi) Therefore, the finding of the Tribunal, (a) that a public largesse was doled out in favour of
Devas, in contravention of the public policy in India; (b) that Devas enticed Antrix/ISRO to enter
into an MoU followed by an Agreement by promising to provide something that was not in existence
at that time and which did not come into existence even later; (c) that the licenses and approvals
were for completely different services; and (d) that the services offered were not within the scope of
SATCOM Policy etc. are actually borne out by records;
(vii) There is no denial of the fact that Devas offered a bouquet of services known as (a) Devas
Services through a device called (b) Devas device in a hybrid mode of transmission, which is a
combination of satellite and terrestrial transmissions, and which is called (c) Devas Technology but
none of which existed at the relevant point of time or even thereafter;
(viii) Devas did not even hold necessary intellectual property rights in this regard though they
claimed to have applied;
(ix) That the formation of the company, namely, Devas Multimedia Private Limited was for a
fraudulent and unlawful purpose is borne out by the fact that the company was incorporated in
December-2004, Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ
Sanjeev Sachdeva.
as a result of preliminary meetings held at Bangalore in March-2003 and in USA in May-
2003, followed by the signing of the MoU on 28.07.2003, the presentation made on 22.03.2004 and
the discussions held thereafter. The ground work was clearly done during the period from
March-2003 to December-2004 before the company was formally incorporated. Immediately after
incorporation, the Agreement dated 28.01.2005 was signed. Therefore, the first ingredient of
Section 271(c) of the Companies Act, 2013, namely, the formation of the company for a fraudulent
and unlawful purpose was clearly made out;
(x) The kind of licenses obtained such as ISP and IPTV licenses and the object for which FIPB
approvals were taken but showcased as those sufficient for fulfilling the obligations under the
Agreement dated 28.01.2005 demonstrated that the affairs of the company were conducted in a
fraudulent manner. This is fortified by the fact that a total amount of Rs.579 crores was brought in,
but almost 85% of the said amount was siphoned out of India, partly towards establishment of a
subsidiary in the US, partly towards business support services and partly towards litigation
expenses. We do not know if the amount of Rs.233 crores taken out of India towards litigation
services, also became a part of the investment in a more productive venture, namely, arbitration.
The manner in which a misleading note was put to the cabinet and the manner in which the minutes
of the meeting of TAG subcommittee were manipulated, highlighted by the Tribunal, also shows that
the Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
affairs of the company were conducted in a fraudulent manner. Thus, the second limb of Section
271(c), namely, the conduct of the affairs of the company in a fraudulent manner, also stood
established.Antrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

(xi) SATCOM Policy perceived telecommunication and broadcasting services to be independent of
each other and also mutually exclusive. Therefore, a combination of both was not permitted by law.
It is especially so since no deliberation took place with the Ministry of Information and
Broadcasting. Moreover, unless ICC allocates space segment, to a private player, the same becomes
unlawful. This is why the conduct of the affairs of the company became unlawful;
(xii) That the officials of the Department of Space and Antrix were in collusion and that it was a case
of fence eating the crop (and also allowing others to eat the crop), by joining hands with third
parties, is borne out by the fact that the Note of the 104th Space Commission did not contain a
reference to the Agreement. The Cabinet Note dated 17.11.2005 prepared after ten months of signing
of the Agreement, did not make a mention about Devas or the Agreement, but proceeded on the
basis as though ISRO received several Expressions of Interest. These materials show the complicity
of the officials to allow Devas to have unjust enrichment;
(xiii) It is on record that the minutes of the meeting of the Sub Committee dated 06.01.2009 were
manipulated and the experimental licence was Signing Date:29.08.2022 15:28:39 This file is
digitally signed by PS to HMJ Sanjeev Sachdeva.
granted on 07.05.2009. Only thereafter, the original minutes were restored on 20.11.2009 and that
too after protest.
(xiv) Admittedly, every one of the investors procured shares of the company in liquidation and each
shareholder had a representative in the board of directors. Since the board controlled the company,
the directors were guilty of the conduct of the affairs of the company in a fraudulent manner. Since
each shareholder had a representative in the board, the shareholders had to take the blame for the
misdeeds of the directors;
(xv) Additionally, the shareholders were fully aware of the fact that the application for approval
dated 02.02.2006 to the FIPB was for ISP services. But they entered into a Share Subscription
Agreement on 06.03.2006 for Devas services. The Share Subscription Agreement discloses that they
were aware of the false statements contained in the Agreement dated 28.01.2005. Therefore, the
shareholders, who now want to reap the fruits of a tree, fraudulently planted and unlawfully
nurtured, cannot feign ignorance and escape the allegations of fraud.
12.9 An argument was advanced by the learned senior counsel for the appellants, on the basis of a
statement contained in the order of NCLAT that the allegations are prima facie made out, that a
company cannot be ordered to be wound up on the basis of prima facie findings. The standard of
proof required for winding up of a company cannot be prima facie.
Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
12.10 But we do not think that the appellants can take advantage of the use of an inappropriate
expression by NCLAT. The detailed findings recorded by the Tribunal show that they are final and
not prima facie. Merely because NCLAT used an erroneous expression those findings cannot becomeAntrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

prima facie."
156. Supreme Court not only declined to interfere with the concurrent findings of fraud recorded by
the NCLT and NCLAT but reaffirmed the same and further held that there was no perversity in the
same and said finding were borne out from the undisputed record and documents.
157. The Supreme Court further negated the contention on behalf of Devas that it was a lis between
two private parties and held that "The space segment in the satellite proposed to be launched by the
Government of India, is the property of the Government of India. In fact, the shareholders have
secured two awards against the Republic of India under BIT. Therefore, it is neither a lis between
two private parties nor a private lis between a private party and a public authority. It is a case of
fraud of a huge magnitude which cannot be brushed under the carpet, as a private lis."
158. Another contention raised on behalf of Devas that the actual motive behind Antrix seeking the
winding up of Devas, is to deprive Devas of the benefits of an unanimous award passed by the ICC
Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
Arbitral tribunal presided over by a former Chief Justice of India and the two BIT awards and that
such attempts on the part of a corporate entity wholly owned by the Government of India would
send a wrong message to international investors, was negated by the Supreme Court by holding as
under:
"13.5 We do not find any merit in the above submission. If as a matter of fact, fraud
as projected by Antrix, stands established, the motive behind the victim of fraud,
coming up with a petition for winding up, is of no relevance. If the seeds of the
commercial relationship between Antrix and Devas were a product of fraud
perpetrated by Devas, every part of the plant that grew out of those seeds, such as the
Agreement, the disputes, arbitral awards etc., are all infected with the poison of
fraud. A product of fraud is in conflict with the public policy of any country including
India. The basic notions of morality and justice are always in conflict with fraud and
hence the motive behind the action brought by the victim of fraud can never stand as
an impediment. 13.6 We do not know if the action of Antrix in seeking the winding up
of Devas may send a wrong message, to the community of investors. But allowing
Devas and its shareholders to reap the benefits of their fraudulent action, may
nevertheless send another wrong message namely that by adopting fraudulent means
and by bringing into India an investment in a sum of INR 579 crores, the investors
can hope to get tens of thousands of crores of rupees, even after siphoning off INR
488 crores."
(underlining supplied) Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ
Sanjeev Sachdeva.
159. After affirming the concurrent finding of fraud the Supreme Court has held that if the seeds of
the commercial relationship between Antrix and Devas were a product of fraud perpetrated byAntrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

Devas, every part of the plant that grew out of those seeds, such as the Agreement, the disputes,
arbitral awards etc., are all infected with the poison of fraud. A product of fraud is in conflict with
the public policy of any country including India. The basic notions of morality and justice are always
in conflict with fraud. Further, allowing Devas and its shareholders to reap the benefits of their
fraudulent action, would send another wrong message namely that by adopting fraudulent means
and by bringing into India an investment in a sum of INR 579 crores, the investors can hope to get
tens of thousands of crores of rupees, even after siphoning off INR 488 crores.
160. The Judgments of the NCLT, NCLAT and the Supreme Court are inter party and as such the
finding returned therein would operate as res judicata. Since the Judgments are admissible and
court is bound to take judicial notice of the same, Antrix does not need to refer to the applications
filed by it seeking to amend the objections filed under section 34 of the Act.
161. Mr. Venkataraman, Learned Additional Solicitor General has relied upon on the Judgments of
the NCLT, NCLAT and the Supreme Court to address the issue of fraud played by Devas.
Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
162. Since the issue of fraud is established by the said Judgments and would also operate as res -
judicata between the parties, the submission on behalf of DEMPL that Antrix cannot be permitted to
amend the objections under section 34 of the Act as the application has been filed beyond the
statutory period is of no consequence.
163. Accordingly, the judgments in the case of (i) P. Radha Bai & Others vs. P Ashok Kumar & Anr.
(2019) 13 SCC 445; (ii) Bhaven Construction vs. Executive Engineer, Sardar Sarovar Narmada
Nigam Limited (2022) 1 SCC 75 and (iii) State of Maharashtra vs. Hindustan Construction Company
Limited (2010) 4 SCC 518 relied upon by Mr. Suhail Dutt learned Senior Counsel for DEMPL on the
question of delay in seeking amendment of the objections are not applicable to the facts of the
present case.
164. The Supreme Court of India in Delhi Airport Metro Express (P) Ltd. v. DMRC, (2022) 1 SCC 131
examined the scope of judicial interference with the arbitral awards and held as under:
"27. For a better understanding of the role ascribed to Courts in reviewing arbitral
awards while considering applications filed under Section 34 of the 1996 Act, it would
be relevant to refer to a judgment of this Court in Ssangyong Engg. & Construction
Co. Ltd. v. NHAI [Ssangyong Engg. & Construction Co. Ltd. v. NHAI, (2019) 15 SCC
131 : (2020) 2 SCC (Civ) 213] wherein R.F. Nariman, J. has in clear terms delineated
the limited area for judicial interference, Signing Date:29.08.2022 15:28:39 This file
is digitally signed by PS to HMJ Sanjeev Sachdeva.
taking into account the amendments brought about by the 2015 Amendment Act. The
relevant passages of the judgment in Ssangyong [Ssangyong Engg. & Construction
Co. Ltd. v. NHAI, (2019) 15 SCC 131 :Antrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

(2020) 2 SCC (Civ) 213] are noted as under : (SCC pp.
169-71, paras 34-41) „34. What is clear, therefore, is that the expression "public policy of India",
whether contained in Section 34 or in Section 48, would now mean the "fundamental policy of
Indian law" as explained in paras 18 and 27 of Associate Builders [Associate Builders v. DDA, (2015)
3 SCC 49 : (2015) 2 SCC (Civ) 204] i.e. the fundamental policy of Indian law would be relegated to
"Renusagar" understanding of this expression. This would necessarily mean that Western Geco
[ONGC v. Western Geco International Ltd., (2014) 9 SCC 263 : (2014) 5 SCC (Civ) 12] expansion has
been done away with. In short, Western Geco [ONGC v. Western Geco International Ltd., (2014) 9
SCC 263 :
(2014) 5 SCC (Civ) 12] , as explained in paras 28 and 29 of Associate Builders
[Associate Builders v. DDA, (2015) 3 SCC 49 : (2015) 2 SCC (Civ) 204] , would no
longer obtain, as under the guise of interfering with an award on the ground that the
arbitrator has not adopted a judicial approach, the Courts intervention would be on
the merits of the award, which cannot be permitted post amendment. However,
insofar as principles of natural justice are concerned, as contained in Sections 18 and
34(2)(a)(iii) of the 1996 Act, these continue to be grounds of challenge of an award,
as is contained in para 30 of Associate Signing Date:29.08.2022 15:28:39 This file is
digitally signed by PS to HMJ Sanjeev Sachdeva.
Builders [Associate Builders v. DDA, (2015) 3 SCC 49 : (2015) 2 SCC (Civ) 204] .
35. It is important to notice that the ground for interference insofar as it concerns "interest of India"
has since been deleted, and therefore, no longer obtains. Equally, the ground for interference on the
basis that the award is in conflict with justice or morality is now to be understood as a conflict with
the "most basic notions of morality or justice". This again would be in line with paras 36 to 39 of
Associate Builders [Associate Builders v. DDA, (2015) 3 SCC 49 : (2015) 2 SCC (Civ) 204] , as it is
only such arbitral awards that shock the conscience of the court that can be set aside on this ground.
36. Thus, it is clear that public policy of India is now constricted to mean firstly, that a domestic
award is contrary to the fundamental policy of Indian law, as understood in paras 18 and 27 of
Associate Builders [Associate Builders v. DDA, (2015) 3 SCC 49 : (2015) 2 SCC (Civ) 204] , or
secondly, that such award is against basic notions of justice or morality as understood in paras 36 to
39 of Associate Builders [Associate Builders v. DDA, (2015) 3 SCC 49 : (2015) 2 SCC (Civ) 204] .
Explanation 2 to Section 34(2)(b)(ii) and Explanation 2 to Section 48(2)(b)(ii) was added by the
Amendment Act only so that Western Geco [ONGC v. Western Geco International Ltd., (2014) 9
SCC 263 : (2014) 5 SCC (Civ) 12] , as understood in Associate Builders [Associate Builders v. DDA,
(2015) 3 SCC 49 : (2015) 2 SCC Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS
to HMJ Sanjeev Sachdeva.
(Civ) 204] , and paras 28 and 29 in particular, is now done away with.Antrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

37. Insofar as domestic awards made in India are concerned, an additional ground is now available
under sub-section (2-A), added by the Amendment Act, 2015, to Section 34. Here, there must be
patent illegality appearing on the face of the award, which refers to such illegality as goes to the root
of the matter but which does not amount to mere erroneous application of the law. In short, what is
not subsumed within "the fundamental policy of Indian law", namely, the contravention of a statute
not linked to public policy or public interest, cannot be brought in by the backdoor when it comes to
setting aside an award on the ground of patent illegality.
38. Secondly, it is also made clear that reappreciation of evidence, which is what an appellate court
is permitted to do, cannot be permitted under the ground of patent illegality appearing on the face of
the award.
39. To elucidate, para 42.1 of Associate Builders [Associate Builders v. DDA, (2015) 3 SCC 49 :
(2015) 2 SCC (Civ) 204] , namely, a mere contravention of the substantive law of India, by itself, is
no longer a ground available to set aside an arbitral award. Para 42.2 of Associate Builders
[Associate Builders v. DDA, (2015) 3 SCC 49 : (2015) 2 SCC (Civ) 204] , however, would remain, for
if an arbitrator gives no reasons for an award and contravenes Section 31(3) of the Signing
Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
1996 Act, that would certainly amount to a patent illegality on the face of the award.
40. The change made in Section 28(3) by the Amendment Act really follows what is stated in paras
42.3 to 45 in Associate Builders [Associate Builders v. DDA, (2015) 3 SCC 49 : (2015) 2 SCC (Civ)
204] , namely, that the construction of the terms of a contract is primarily for an arbitrator to
decide, unless the arbitrator construes the contract in a manner that no fair-minded or reasonable
person would; in short, that the arbitrators view is not even a possible view to take. Also, if the
arbitrator wanders outside the contract and deals with matters not allotted to him, he commits an
error of jurisdiction. This ground of challenge will now fall within the new ground added under
Section 34(2-A).
41. What is important to note is that a decision which is perverse, as understood in paras 31 and 32
of Associate Builders [Associate Builders v. DDA, (2015) 3 SCC 49 : (2015) 2 SCC (Civ) 204] , while
no longer being a ground for challenge under "public policy of India", would certainly amount to a
patent illegality appearing on the face of the award. Thus, a finding based on no evidence at all or an
award which ignores vital evidence in arriving at its decision would be perverse and liable to be set
aside on the ground of patent illegality. Additionally, a finding based on documents taken behind
the back of the parties by the arbitrator would also qualify as a decision based on no evidence
inasmuch as such decision is not based on evidence led by the parties, and Signing Date:29.08.2022
15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
therefore, would also have to be characterised as perverse.
28. This Court has in several other judgments interpreted Section 34 of the 1996 Act to stress on the
restraint to be shown by Courts while examining the validity of the arbitral awards. The limitedAntrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

grounds available to Courts for annulment of arbitral awards are well known to legally trained
minds. However, the difficulty arises in applying the well-established principles for interference to
the facts of each case that come up before the Courts. There is a disturbing tendency of Courts
setting aside arbitral awards, after dissecting and reassessing factual aspects of the cases to come to
a conclusion that the award needs intervention and thereafter, dubbing the award to be vitiated by
either perversity or patent illegality, apart from the other grounds available for annulment of the
award. This approach would lead to corrosion of the object of the 1996 Act and the endeavours made
to preserve this object, which is minimal judicial interference with arbitral awards. That apart,
several judicial pronouncements of this Court would become a dead letter if arbitral awards are set
aside by categorising them as perverse or patently illegal without appreciating the contours of the
said expressions.
29. Patent illegality should be illegality which goes to the root of the matter. In other words, every
error of law committed by the Arbitral Tribunal would not fall within the expression "patent
illegality". Likewise, erroneous application of law cannot be categorised as patent Signing
Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
illegality. In addition, contravention of law not linked to public policy or public interest is beyond
the scope of the expression "patent illegality". What is prohibited is for Courts to reappreciate
evidence to conclude that the award suffers from patent illegality appearing on the face of the award,
as Courts do not sit in appeal against the arbitral award. The permissible grounds for interference
with a domestic award under Section 34(2- A) on the ground of patent illegality is when the
arbitrator takes a view which is not even a possible one, or interprets a clause in the contract in such
a manner which no fair-minded or reasonable person would, or if the arbitrator commits an error of
jurisdiction by wandering outside the contract and dealing with matters not allotted to them. An
arbitral award stating no reasons for its findings would make itself susceptible to challenge on this
account. The conclusions of the arbitrator which are based on no evidence or have been arrived at by
ignoring vital evidence are perverse and can be set aside on the ground of patent illegality. Also,
consideration of documents which are not supplied to the other party is a facet of perversity falling
within the expression "patent illegality".
30. Section 34(2)(b) refers to the other grounds on which a court can set aside an arbitral award. If a
dispute which is not capable of settlement by arbitration is the subject-matter of the award or if the
award is in conflict with public policy of India, the award is liable to be set aside. Explanation (1),
amended by the 2015 Amendment Act, clarified the expression "public policy Signing
Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
of India" and its connotations for the purposes of reviewing arbitral awards. It has been made clear
that an award would be in conflict with public policy of India only when it is induced or affected by
fraud or corruption or is in violation of Section 75 or Section 81 of the 1996 Act, if it is in
contravention with the fundamental policy of Indian law or if it is in conflict with the most basic
notions of morality or justice.Antrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

31. In Ssangyong [Ssangyong Engg. & Construction Co. Ltd. v. NHAI, (2019) 15 SCC 131 : (2020) 2
SCC (Civ) 213] , this Court held that the meaning of the expression "fundamental policy of Indian
law" would be in accordance with the understanding of this Court in Renusagar Power Co. Ltd. v.
General Electric Co. [Renusagar Power Co. Ltd. v. General Electric Co., 1994 Supp (1) SCC 644] . In
Renusagar [Renusagar Power Co. Ltd. v. General Electric Co., 1994 Supp (1) SCC 644] , this Court
observed that violation of the Foreign Exchange Regulation Act, 1973, a statute enacted for the
"national economic interest", and disregarding the superior Courts in India would be antithetical to
the fundamental policy of Indian law. Contravention of a statute not linked to public policy or public
interest cannot be a ground to set at naught an arbitral award as being discordant with the
fundamental policy of Indian law and neither can it be brought within the confines of "patent
illegality" as discussed above. In other words, contravention of a statute only if it is linked to public
policy or public interest is cause for setting aside the award as being at odds with the fundamental
Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
policy of Indian law. If an arbitral award shocks the conscience of the court, it can be set aside as
being in conflict with the most basic notions of justice. The ground of morality in this context has
been interpreted by this Court to encompass awards involving elements of sexual morality, such as
prostitution, or awards seeking to validate agreements which are not illegal but would not be
enforced given the prevailing mores of the day. [Ssangyong Engg. & Construction Co. Ltd. v. NHAI,
(2019) 15 SCC 131 : (2020) 2 SCC (Civ) 213]"
165. Supreme Court in Delhi Airport Metro Express (P) Ltd.(supra) has held that the
grounds for setting aside an Arbitral Award are limited. If a domestic award is
contrary to the fundamental policy of Indian law, and if there is a patent illegality in
the award an award may be set aside. However, Patent illegality should be illegality
which goes to the root of the matter and every error of law committed by the Arbitral
Tribunal would not fall within the expression of "patent illegality". Similarly,
erroneous application of law cannot be categorised as patent illegality. A
contravention of law not linked to public policy or public interest is beyond the scope
of the expression "patent illegality".
166. It is further held that it is impermissible for the Courts to reappreciate evidence to conclude
that the award suffers from patent illegality appearing on the face of the award, as Courts do not sit
in Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
appeal against the arbitral award. However, if an arbitrator takes a view which is not even a possible
one, or interprets a clause in the contract in such a manner which no fair-minded or reasonable
person would, or if the arbitrator commits an error of jurisdiction by wandering outside the contract
and dealing with matters not allotted to them or basing the conclusions on no evidence or
conclusions have been arrived at by ignoring vital evidence are perverse and can be set aside on the
ground of patent illegality.
167. Contravention with the fundamental policy of Indian law or being in conflict with the most
basic notions of morality or justice or contrary to national economic interest and disregarding theAntrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

superior Courts in India would be antithetical to the fundamental policy of Indian law.
168. As noticed above the Arbitral Tribunal has incorrectly excluded the evidence pertaining to the
pre-contractual negotiations which it could not have and has thus committed a patent illegality in
the award.
169. Further, as noticed hereinabove, the Arbitral Tribunal has committed patent illegality in the
award as findings on some issues are contradicted by the findings on other issues and are also
contradicted by the reasoning given to reach the said conclusions.
Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
170. Additionally, findings on fraud returned by the Supreme Court by its Judgment dated
17.01.2022 clearly establish that award contravenes the fundamental policy of Indian law being in
conflict with the most basic notions of justice and is also contrary to the national economic interest
having also violated the „FIPB Policies and the provisions of „FIMA and „PMLA and thus
antithetical to the fundamental policy of Indian law.
171. The Supreme Court by its judgment dated 17.01.2022 has held that the very seeds of the
commercial relationship between Antrix and Devas were a product of fraud perpetrated by Devas
and thus every part of the plant that grew out of those seeds, such as the Agreement, the disputes,
arbitral awards etc., are all infected with the poison of fraud.
172. It has held that a product of fraud is in conflict with the public policy of any country including
India. The basic notions of morality and justice are always in conflict with fraud and that allowing
Devas and its shareholders to reap the benefits of their fraudulent action, would send another wrong
message namely that by adopting fraudulent means and by bringing into India an investment in a
sum of INR 579 crores, the investors can hope to get tens of thousands of crores of rupees, even after
siphoning off INR 488 crores.
Signing Date:29.08.2022 15:28:39 This file is digitally signed by PS to HMJ Sanjeev Sachdeva.
173. In view of the above, the objections filed by the Petitioner under Section 34 of the Act are
allowed and it is held that the Impugned award dated 14.09.2015 suffers from patent illegalities and
fraud and is in conflict with the Public Policy of India. The Petition is accordingly allowed and the
impugned award dated 14.09.2015 is set aside.
174. Pending applications are also disposed of accordingly.
175. Copy of the order be uploaded on the High Court website and be also forwarded to learned
counsels for the parties through email by the Court Master.
SANJEEV SACHDEVA, J AUGUST 29, 2022 HJ Signing Date:29.08.2022 15:28:39 This file is
digitally signed by PS to HMJ Sanjeev Sachdeva.Antrix Corporation Ltd. vs Devas Multimedia Private Limited on 29 August, 2022

