A.P. Pollution Control Board vs Prof.M.V.Nayudu (Retd.) &
Others on 27 January, 1999
Equivalent citations: AIR 1999 SUPREME COURT 812, 1999 (2) SCC 718, 1999
AIR SCW 434, 2000 (5) COM LJ 229 SC, 1999 (1) SCALE 140, 1999 (1) LRI 185,
1999 (1) ADSC 397, 1999 (1) UJ (SC) 426, 1999 UJ(SC) 1 426, (1999) 1 JT 162
(SC), (1999) 10 SUPREME 195, (1999) 1 RECCIVR 570, (1999) 1 SCALE 140
Author: M.Jagannadha Rao
Bench: S.B. Majmudar, M.Jagannadha Rao
           PETITIONER:
A.P. POLLUTION CONTROL BOARD
        Vs.
RESPONDENT:
PROF.M.V.NAYUDU (RETD.) & OTHERS
DATE OF JUDGMENT:       27/01/1999
BENCH:
S.B. Majmudar. & M. Jagannadha.,
JUDGMENT:
M.JAGANNADHA RAO,J.
Leave granted in all the special leave petitions. It is said:
"The basic insight of ecology is that all living things exist in interrelated systems;
nothing exists in isolation. The world system is weblike; to pluck one strand is to
cause all to vibrate; whatever happens to one part has ramifications for all the rest.
Our actions are not individual but social; they reverberate throughout the whole
ecosystem". [Science Action Coalition by A.Fritsch, Environmental Ethics: Choices
for Concerned Citizens 3-4 (1980)]. (1988) Vol.12 Harv.Env.L.Rev. at 313)."
Four of these appeals which arise out of SLP(C) No.10317-10320 of 1998 were filed against the
judgment of the Andhra Pradesh High Court dated 1.5.1998 in four writ petitions, namely, W.P. No.
17832 of 1997 and three other connected writ petitions. All the appeals were filed by the A.P.
Pollution Control Board. Three of the above writ petitions were filed as public interest cases byA.P. Pollution Control Board vs Prof.M.V.Nayudu (Retd.) & Others on 27 January, 1999

certain persons and the fourth writ petition was filed by the Gram Panchayat, Peddaspur.
The fifth Civil Appeal which arises out of SLP(C) No.13380 of 1998 was filed against the judgment in
W.P. No.16969 of 1997 by the Society for Preservation of Environment & Quality of Life, (for short
`SPEQL') represented by Sri P.Janardan Reddi, the petitioner in the said writ petition. The High
Court dismissed all these writ petitions.
The sixth Civil appeal which arises out of SLP(C) No.10330 of 1998 was filed by A.P.Pollution
Control Board against the order dated 1.5.1998 in Writ Petition No.11803 of 1998. The said writ
petition was filed by M/s Surana Oils and Derivatives (India) Ltd. (hereinafter called the
`respondent company', for implementation of the directions given by the appellate authority under
the Water (Prevention of Pollution) Act, 1974 (hereinafter called the `Water Act, 1974') in favour of
the company.
In other words, the A.P. Pollution Board is the appellant in five appeals and the SPEQL is appellant
in one of the appeals.
According to the Pollution Control Board, under the notification No. J.20011/15/88-iA, Ministry of
Environment & Forests, Government of India dated 27.9.1988, `vegetable oils including solved
extracted oils' (Item No.37) was listed in the `RED' hazardous category. The Pollution Board
contends that Notification No. J.120012/38/86 1A, Ministry of Environment & Forests of
Government of India dated 1.2.1989, prohibits the location of the industry of the type proposed to be
established by the respondent company, which will fall under categorisation at No.11 same category
of industry in Doon Valley.
On 31.3.1994, based on an Interim Report of the Expert Committee constituted by the Hyderabad
Metropolitan Water Supply and Sewerage Board, the Municipal Administration and Urban
Development, Government of Andhra Pradesh issued GOMs 192 dated 31.3.1994 prohibited various
types of development within 10 k.m. radius of the two lakes, Himayat Sagar & Osman Sagar, in
order to monitor the quality of water in these reservoirs which supply water to the twin cities of
Hyderabad and Secunderabad.
In January 1995, the respondent company was incorporated as a public limited company with the
object of setting up an industry for production of B.S.S. Castor oil derivatives such as Hydrogenated
Castor Oil, 12-Hydroxy Stearic Acid, Dehydrated Castor Oil, Methylated 12-HSA, D.Co., Fatty Acids
with by products - like Glycerine, Spent Bleaching Earth and Carbon and Spent Nickel Catalyst.
Thereafter the industry applied to the Ministry of Industries, Government of India for letter of
intent under the Industries (Development Regulation) Act, 1951.
The respondent Company purchased 12 acres of land on 26.9.1995 in Peddashpur village,
Shamshabad Mandal. The Company also applied for consent for establishment of the industry
through the single window clearance committee of the Commissionerate of Industries, Government
of Andhra Pradesh, in November, 1995. On 28.11.1995, the Government of Andhra Pradesh, wrote to
the Ministry of Industry, Government of India as follows:A.P. Pollution Control Board vs Prof.M.V.Nayudu (Retd.) & Others on 27 January, 1999

"The State Government recommends the aplication of the unit for grant of letter of
intent for the manufacture of B.S.S. Grade Castor Oil in relaxation of locational
restriction subject to NOC from A.P.Pollution Control Board, prior to taking
implementation steps."
On 9.1.1996, the Government of India issued letter of intent for manufacture of B.S.S. grade Castor
Oil (15,000 tons per annum) and Glycerine (600 tons per annum). The issuance of licence was
subject to various conditions, inter-alia, as follows:
"(a) you shall obtain a confirmation from the State Director of Industries that the site
of the project has been approved from the environmental angle by the competent
State authority.
(b) you shall obtain a certificate from the concerned State Pollution Control Board to
the effect that the measures envisaged for pollution control and the equipment
proposed to be installed meet their requirements."
Therefore, the respondent company had to obtain NOC from the A.P. Pollution Control Board.
According to the A.P. Pollution Control Board (the appellant), the respondent company could not
have commenced civil works and construction of its factory, without obtaining the clearance of the
A.P.Pollution Control Board - as the relaxation by government from location restriction as stated in
their letter dated 28.11.1995, was subject to such clearance. On 8.3.1996, on receipt of the 2nd
Interim Report of the Expert Committee of the Hyderabad Metropolitan Water Supply and
Sewerage Board, the Municipal Administration and Urban Development Department issued GO
No.111 on 8.3.1996 reiterating the 10 k.m. prohibition as contained in the GO 192 dated 31.3.1994
but making some concessions in favour of residential development.
In the pre-scrutiny stage on 24.5.1996 by the Single Window Clearance Committee, which the
company's representative attended, the application of the industry was rejected by the A.P. Pollution
Control Board since the proposed site fell within 10 k.m. and such a location was not permissible as
per GOMs 111 dated 8.3.96. On 31.5.1994, the Gram Panchayat approved plans for establishing
factory.
On 31.3.1996, the Commissionerate of Industries, rejected the location and directed alternative site
to be selected. On 7.9.1996, the Dt.Collector granted permission for conversion of the site (i.e. within
10 k.m.) to be used for non- agricultural purposes.
On 7.4.1997, the company applied to the A.P. Pollution Control Board, seeking clearance to set- up
the unit under section 25 of the Water Act. It may be noted that in the said application, the
Company listed the following as by-products of its processes:
"Glycerine, spent bleaching earth and carbon and spent nickel catalysts."A.P. Pollution Control Board vs Prof.M.V.Nayudu (Retd.) & Others on 27 January, 1999

According to the AP Pollution Board the products manufactured by this industry would lead to the
following sources of pollution:
"(a) Nickel (solid waste) which is heavy- metal and also a hazardous waste under
Hazardous Waste (Management and Handling) Rules, 1989.
(b) There is a potention of discharge or run off from the factory combined joining oil
and other waste products.
(c) Emission of Sulpher Dioxide and oxide of nitrogen.
It was at that juncture that the company secured from the Government of A.P. by GOMs 153 dated
3.7.1997 exemption from the operation of GOMs 111 of 8.3.1996 which prescribed the 10 k.m. rule
from the Osman Sagar and Himayat Sagar Lakes.
In regard to grant of NOC by the A.P. Pollution Board, the said Board by letter dated 30.7.1997
rejected the application dated 7.4.1997 for consent, stating "(1) The unit is a polluting industry and
falls under the red category of polluting industry under section S.No.11 of the classification of
industries adopted by MOEF, GOI and opined that it would not be desirable to locate such industry
in the catchment area of Himayatsagar in view of the GOMs No.111 dated 8.3.1996.
(2) The proposal to set up this unit was rejected at the pre-scrutiny level during the meeting of
CDCC/DIPC held on 24.5.1996 in view of the State Government Order No.111 dated 8.3.1996."
Aggrieved by the above letter of rejection, the respondent company appealed under section 28 of the
Water Act. Before the appellate authority, the industry, filed an affidavit of Prof. M.Santappa
Scientific Officer to the Tamil Nadu Pollution Control Board in support of its contentions. The
appellate authority under section 28 of the Water Act, 1974 (Justice M.Ranga Reddy, (retd.)) by
order dated 5.1.1998 allowed the appeal of the Company. Before the appellate authority, as already
stated, an affidavit was filed by Prof. M.Shantappa, a retired scientist and technologist (at that time,
Scientific Advisor for T.N. Pollution Control Board) stating that the respondent had adopted the
latest eco-friendly technology using all the safeguards regarding pollution. The appellate authority
stated that Dr.Siddhu, formerly Scientific to the Government of India and who acted as Director
General, Council of Scientific and Industrial Research (CSIR) and who was the Chairman of the
Board of Directors of this Company also filed an affidavit. The Managing Director of the respondent
company filed an affidavit explaining the details of the technology employed in the erection of the
plant. Prof. M.Shantappa in his report stated that the company has used the technology obtained
from the Indian Institute of Chemical Technology of (IICT), Hyderabad which is a premier institute
and that he would not think of a better institute in the country for transfer of technology. The said
Institute has issued a certificate that this industry will not discharge any acidic effluents and the
solid wastes which are the by -products are saleable and they will be collected in M.S. drums by
mechanical process and sold. The report of Dr. Shantappa also showed that none of the by-products
would fall on the ground of the factory premises. He also stated that all the conditions which were
proposed to be imposed by the Technical Committee on the company at its meeting held on 16.7.97A.P. Pollution Control Board vs Prof.M.V.Nayudu (Retd.) & Others on 27 January, 1999

have been complied with. On the basis of these reports, the appellate authority stated that this
industry "is not a polluting industry". It further held that the notification dated 1.2.1989 of the
Ministry of Environment & Forests, Government of India, whereby industries manufacturing
Hydrogenated Vegetable oils were categorised as "red category"
industries, did not apply to the catchment areas of Himayat Sagar and Osman Sagar
lakes and that notification was applicable only to the Doon Valley of UP and Dahanu
in Maharashtra. The appellate authority accordingly directed the AP Pollution control
Board to give its consent for establishment of the factory on such conditions the
Board may deem fit as per GOMs 153 dated 3.7.1997 (as amended by GO 181 dated
7.8.1997). Before the above order dated 5.1.98 was passed by the appellate authority,
some of these public interest cases had already been filed. After the 5.1.98 order of
the appellate authority, a direction was sought in the public interest case
W.P.No.2215 of 1996 that the order dated 5.1.1998 passed by the appellate authority
was arbitrary and contrary to interim orders passed by the High Court in W.P. 17832,
16969 and 16881 of 1997. The respondent company, in its turn filed WP No.11803 of
1998 for directing the A.P. Pollution Control Board to give its consent, as a
consequence to the order of the appellate authority dated 5.1.1998. As stated earlier,
the A.P. Pollution Control Board contends that the categorisation of industries into
red, green and orange had already been made prior to the notification of 1.2.1989 by
Office Memorandum of the Ministry of Environment & Forests, Government of India
dated 27.9.1988 and that in that notification also "Vegetable oils including solvent
extracted oils" (Item No.7) and `Vanaspati Hydrogenated Vegetable oils for
industrial purposes (Item 37)" were also included in the red category. It also
contends that the company could not have started civil works unless NOC was given
by the Board. The Division Bench of the High Court in its judgment dated 1.5.1998,
held that the writ petitioners who filed the public interest cases could not be said to
be having no locus standi to file the writ petitions. The High Court observed that
while the Technical Committee of the A.P. Pollution Control Board had, some time
before its refusal, suggested certain safeguards to be followed by the company, the
Board could not have suddenly refused the consent and that this showed double
standards. The High Court referred to the order of the Appellate authority under
Section 28 of the Water Act dated 5.1.98 and the report of Dr.Sidhu, to the effect that
even if hazardous waste was a by-product, the same could be controlled if the
safeguards mentioned in the Hazardous Wastes (Management and Handling) Rules,
1989 were followed and in particular those in Rules 5,6 and 11, were taken. The Rules
made under Manufacture, Storage and Import of Hazardous Chemical (MSIHC)
Rules 1989 also permit industrial actively provided the safeguards mentioned therein
are taken. The Chemical Accidents (Emergency Planning, Preparedness and
Response) Rules 1991 supplement the MSIHC Rules, 1989 on accident preparedness
and envisage a 4-tier crisis management system in the country. Therefore, merely
because an industry produced hazardous substances, the consent could not be
refused. It was stated that as the matter was highly technical, interference was not
called for, as "rightly" contended by the learned counsel for the respondent company.A.P. Pollution Control Board vs Prof.M.V.Nayudu (Retd.) & Others on 27 January, 1999

The High Court could not sit in appeal over the order of the appellate authority. For
the above reasons, the High Court dismissed the three public interest cases, and the
writ petitions filed by the Gram Panchayat. The High Court allowed the writ petition
filed by the respondent industry and directed grant of consent by the A.P. Pollution
Control Board subject to such conditions as might be imposed by the Board. It is
against the said judgment that the A.P. Pollution Control Board has filed the five
appeals. One appeal is filed by SPEQL. In these appeals, we have heard the
preliminary submission of Shri R.N.Trivedi, learned Additional Solicitor General for
the A.P. Pollution Control Board, Shri M.N.Rao, learned senior counsel for the
respondent company, and Sri P.S.Narasimha for the appellant in the appeal arising
out of SLP (C) No.13380 of 1998 and others. It will be noticed that various issues
arise in these appeals concerning the validity of the orders passed by the A.P.
Pollution Control Board dated 30.7.97, the correctness of the order dated 5.1.98 of
the Appellate Authority under Section 28 of the Water Act, the validity of GOMs
No.153 dated 3.7.97 by which Government of A.P. granted exemption for the
operation of the 10 k.m. rule in GOMs 111 dated 8.3.1996. Questions also arise
regarding the alleged breach of the provisions of the Act, Rules or notification issued
by the Central Government and the standards prescribed under the Water Act or
rules or notifications. Question also arises whether the "appellate" authority could
have said that as it was a highly technical matter, no interference was called for. We
are just now not going into all these aspects but are confining ourselves to the issues
on the technological side. In matters regarding industrial pollution and in particular,
in relation to the alleged breach of the provisions of the Water (Prevention and
Control of Pollution) Act, 1974, its rules or notifications issued thereunder, serious
issues involving pollution and related technology have been arising in appeals under
Article 136 and in writ petitions under Article 32 of the Constitution of India filed in
this Court and also in writ petitions before High Courts under Article 226. The cases
involve the correctness of opinions on technological aspects expressed by the
Pollution Control Boards or other bodies whose opinions are placed before the
Courts. In such a situation, considerable difficulty is experienced by this Court or the
High Courts in adjudicating upon the correctness of the technological and scientific
opinions presented to the Courts or in regard to the efficacy of the technology
proposed to be adopted by the industry or in regard to the need for alternative
technology or modifications as suggested by the Pollution Control Board or other
bodies. The present case illustrates such problems. It has become, therefore,
necessary to refer to certain aspects of environmental law already decided by this
Court and also to go into the above scientific problems, at some length and find
solutions for the same. Environment Courts/Tribunals - problems of complex
technology:
The difficulty faced by environmental courts in dealing with highly technological or
scientific data appears to be a global phenomenon.A.P. Pollution Control Board vs Prof.M.V.Nayudu (Retd.) & Others on 27 January, 1999

Lord Woolf, in his Garner lecture to UKELA, on the theme "Are the Judiciary
Environmentally Myopic?"
(See 1992 J.Envtl. Law Vol.4, No.1, P1) commented upon the problem of increasing specialisation in
environmental law and on the difficulty of the Courts, in their present form, moving beyond their
traditional role of detached "Wednesbury" review. He pointed out the need for a Court or Tribunal
"having a general responsibility for overseeing and enforcing the safeguards provided for the
protection of the environment ....... The Tribunal could be granted a wider discretion to determine
its procedure so that it was able to bring to bear its specialist experience of environmental issues in
the most effective way"
Lord Woolf pointed out the need for "a multi- faceted, multi-skilled body which
would combine the services provided by existing Courts, Tribunals and Inspectors in
the environmental field. It would be a `one stop shop', which should lead to faster,
cheaper and the more effective resolution of disputes in the environmental area. It
would avoid increasing the load on already over burdened lay institutions by trying to
compel them to resolve issues with which they are not designed to deal. It could be a
forum in which the Judges could play a different role. A role which enabled them not
to examine environmental problems with limited vision. It could however be based
on our existing experience, combining the skills of the existing inspectorate, the Land
Tribunal and other administrative bodies. It could be an exciting project"
According to Lord Woolf, "while environmental law is now clearly a permanent feature of the legal
scene, it still lacks clear boundaries." It might be `preferable that the boundaries are left to be
established by Judicial decision as the law developed. After all, the great strength of the English Law
has been its pragmatic approach". Further, where urgent decisions are required, there are often no
easy options for preserving the status quo pending the resolution of the dispute. If the project is
allowed to go ahead, there may be irreperable damage to the environment; if it is stopped, there may
be irreperable damage to an important economic interest. (See Environment Enforcement: The
need for a specialised court - by Robert Cranworth QC (Jour of Planning & Environment, 1992 p.798
at 806). Robert Cranworth advocates the constitution of a unified tribunal with a simple procedure
which looks to the need of customers, which takes the form of a Court or an expert panel, the
allocation of a procedure adopted to the needs of each case - which would operate at two levels - first
tier by a single Judge or technical person and a review by a panel of experts presided over by a High
Court Judge - and not limited to `Wednesbury' grounds. In the USA the position is not different. It
is accepted that when the adversary process yields conflicting testimony on complicated and
unfamiliar issues and the participants cannot fully understand the nature of the dispute, Courts may
not be competent to make reasoned and principled decisions. Concern over this problem led the
Carnegie Commission of Science & Technology (1993) and the Government to undertake a study of
the problems of science and technology in Judicial decision making. In the introduction to its final
report, the Commission concluded:
"The Courts' ability to handle complex science-rich cases has recently been called into
- question, with widespread allegations that the Judicial system is increasingly unableA.P. Pollution Control Board vs Prof.M.V.Nayudu (Retd.) & Others on 27 January, 1999

to manage and adjudicate science and technology (S&T) issues. Critics have objected
that Judges cannot make appropriate decisions because they lack technical training,
that the Jurors do not comprehend the complexity of the evidence they are supposed
to analyze, and that the expert witnesses on whom the system relies are merceneries
whose biased testimony frequently produces erroneous and inconsistent
determinations. If these claims go unanswered, or are not dealt with, confidence in
the Judiciary will be undermined as the public becomes convinced that the Courts as
now constituted are incapable of correctly resolving some of the more pressing legal
issues of our day."
The uncertain nature of scientific opinions:
In the environment field, the uncertainity of scientific opinions has created serious
problems for the Courts. In regard to the different goals of Science and the law in the
ascertainment of truth, the U.S. Supreme Court observed in Daubert vs. Merrel Dow
Pharmaceuticals Inc. (1993) 113 S.Ct 2786, as follows:
"......there are important differences between the quest for truth in the Court- room
and the quest for truth in the laboratory. Scientific conclusions are subject to
perpetual revision. Law, on the other hand, must resolve disputes finally and
quickly." It has also been stated by Brian Wynne in `Uncertainity and Environmental
Learning, (2. Global Envtl.Change 111) (1992):
"Uncertainity, resulting from inadequate data, ignorance and indeterminacy, is an
inherent part of science."
Uncertainity becomes a problem when scientific knowledge is institutionalised in policy making or
used as a basis for decision-making by agencies and courts. Scientists may refine, modify or discard
variables or models when more information is available; however, agencies and Courts must make
choices based on existing scientific knowledge. In addition, agency decision making evidence is
generally presented in a scientific form that cannot be easily tested. Therefore, inadequacies in the
record due to uncertainity or insufficient knowledge may not be properly considered. (The Status of
the Precautionary Principle in Australia : by Charmian Barton (Vol.22) (1998) (Harv. Envtt. Law
Review p.509 at pp510-511).
The inadequacies of science result from identification of adverse effects of a hazard and then
working backwards to find the causes. Secondly, clinical tests are performed, particularly where
toxins are involved, on animals and not on humans, that is to say, are based on animals studies or
short-term cell testing. Thirdly conclusions based on epidemiological studies are flawed by the
scientist's inability to control or even accurately assess past exposure of the subjects. Moreover,
these studies do not permit the scientist to isolate the effects of the substance of concern. The
latency period of many carcinogens and other toxins exacerbates problems of later interpretation.
The timing between exposure and observable effect creates intolerable delays before regulation
occurs. (See Scientific Uncertainity in Protective Environmental Decision making - by Alyson C.A.P. Pollution Control Board vs Prof.M.V.Nayudu (Retd.) & Others on 27 January, 1999

Flournay (Vol.15) 1991 Harv. Envtt. Law Review p.327 at 333-335).
It is the above uncertainity of science in the environmental context, that has led International
Conferences to formulate new legal theories and rules of evidence. We shall presently refer to them.
The Precautionary Principle and the new Burden of Proof - The Vellore Case:
The `uncertainity' of scientific proof and its changing frontiers from time to time has
led to great changes in environmental concepts during the period between the
Stockholm Conference of 1972 and the Rio Conference of 1992. In Vellore Citizens'
Welfare Forum vs. Union of India and Others [1996 (5) SCC 647], a three Judge
Bench of this Court referred to these changes, to the `precautionary principle' and
the new concept of `burden of proof' in environmental matters. Kuldip Singh, J. after
referring to the principles evolved in various international Conferences and to the
concept of `Sustainable Development', stated that the Precautionary Principle, the
Polluter-Pays Principle and the special concept of Onus of Proof have now emerged
and govern the law in our country too, as is clear from Articles 47, 48-A and 51-A(g)
of our Constitution and that, in fact, in the various environmental statutes, such as
the Water Act, 1974 and other statutes, including the Environment (Protection) Act,
1986, these concepts are already implied. The learned Judge declared that these
principles have now become part of our law. The relevant observations in the Vellore
Case in this behalf read as follows:
"In view of the above-mentioned constitutional and statutory provisions we have no
hesitation in holding that the Precautionary Principle and the Polluter Pays Principle
are part of the environmental law of the country."
The Court observed that even otherwise the above- said principles are accepted as part of the
Customary International Law and hence there should be no difficulty in accepting them as part of
our domestic law. In fact on the facts of the case before this Court, it was directed that the authority
to be appointed under section 3(3) of the Environment (Protection) Act, 1986 "shall implement the
`Precautionary Principle' and the `Polluter Pays Principle'."
The learned Judges also observed that the new concept which places the Burden of Proof on the
Developer or Industralist who is proposing to alter the status quo, has also become part of our
environmental law.
The Vellore judgment has referred to these principles briefly but, in our view, it is necessary to
explain their meaning in more detail, so that Courts and tribunals or environmental authorioties can
properly apply the said principles in the matters which come before them.
The Precautionary Principle replaces the Assimilative Capacity Principle:A.P. Pollution Control Board vs Prof.M.V.Nayudu (Retd.) & Others on 27 January, 1999

A basic shift in the approach to environmental protection occured initially between
1972 and 1982. Earlier the Concept was based on the `assimilative capacity' rule as
revealed from Principle 6 of the Stockholm Declaration of the U.N.Conference on
Human Environment, 1972. The said principle assumed that science could provide
policy-makers- with the information and means necessary to avoid encroaching upon
the capacity of the environment to assimilate impacts and it presumed that relevant
technical expertise would be available when environmental harm was predicted and
there would be sufficient time to act in order to avoid such harm. But in the 11th
Principle of the U.N. General Assembly Resolution on World Charter for Nature,
1982, the emphasis shifted to the `Precautionary Principle', and this was reiterated in
the Rio Conference of 1992 in its Principle 15 which reads as follows:
"Principle 15: In order to protect the environment, the precautionary approach shall
be widely applied by States according to their capabilities. Where there are threats of
serious or irreversible damage; lack of full scientific certainity shall not be used as a
reason for proposing cost-effective measures to prevent environmental degradation."
In regard to the cause for the emergence of this principle, Charmian Barton, in the article earlier
referred to in Vol.22, Harv. Envtt. L.Rev. (1998) p.509 at (p.547) says:
"There is nothing to prevent decision makers from assessing the record and
concluding there is inadequate information on which to reach a determination. If it is
not possible to make a decision with "some" confidence, then it makes sense to err on
the side of caution and prevent activities that may cause serious or irreverable harm.
An informed decision can be made at a later stage when additional data is available
or resources permit further research. To ensure that greater caution is taken in
environmental management, implementation of the principle through Judicial and
legislative means is necessary."
In other words, inadequacies of science is the real basis that has led to the Precautionary Principle of
1982. It is based on the theory that it is better to err on the side of caution and prevent
environmental harm which may indeed become irreversible. The principle of precaution involves
the anticipation of environmental harm and taking measures to avoid it or to choose the least
environmentally harmful activity. It is based on Scientific uncertainity. Environmental protection
should not only aim at protecting health, property and economic interest but also protect the
environment for its own sake. Precautionary duties must not only be triggered by the suspicion of
concrete danger but also by (justified) concern or risk potential. The precautionary principle was
recommended by the UNEP Governing Council (1989). The Bomako Convention also lowered the
threshold at which scientific evidence might require action by not referring to "serious" or
"irreversible" as adjectives qualifying harm. However, summing up the legal status of the
precautionary principle, one commentator characterised the principle as still "evolving" for though
it is accepted as part of the international customary law, "the consequences of its application in any
potential situation will be influenced by the circumstances of each case". (See * First Report of
Dr.Sreenivasa Rao Pemmaraju, Special -Rapporteur, International Law Commission dated 3.4.1998A.P. Pollution Control Board vs Prof.M.V.Nayudu (Retd.) & Others on 27 January, 1999

paras 61 to 72). The Special Burden of Proof in Environmental cases: We shall next elaborate the
new concept of burden of proof referred to in the Vellore case at p.658 (1996 (5) SCC 647). In that
case, Kuldip Singh, J. stated as follows:
"The `onus of proof' is on the actor or the developer/industralist to show that his
action is environmentally benign."
--------------------------------------------------- * Joint Secretary and Legal Adviser, Ministry of External
Affairs, New Delhi. It is to be noticed that while the inadequacies of science have led to the
`precautionary principle', the said `precautionary principle' in its turn, has led to the special
principle of burden of proof in environmental cases where burden as to the absence of injurious
effect of the actions proposed, - is placed on those who want to change the status quo (Wynne,
Uncertainity and Environmental Learning, 2 Global Envtl. Change 111 (1992) at p.123). This is often
termed as a reversal of the burden of proof, because otherwise in environmental cases, those
opposing the change would be compelled to shoulder the evidentiary burden, a procedure which is
not fair. Therefore, it is necessary that the party attempting to preserve the status quo by
maintaining a less- polluted state should not carry the burden of proof and the party who wants to
alter it, must bear this burden. (See James M.Olson, Shifting the Burden of Proof, 20 Envtl. Law
p.891 at 898 (1990)). (Quoted in Vol.22 (1998) Harv. Env.Law Review p.509 at 519, 550). The
precautionary principle suggests that where there is an identifiable risk of serious or irreversible
harm, including, for example, extinction of species, widespread toxic pollution in major threats to
essential ecological processes, it may be appropriate to place the burden of proof on the person or
entity proposing the activity that is potentially harmful to the environment. (See Report of
Dr.Sreenivasa Rao Pemmaraju, Special Rapporteur, International Law Commission, dated 3.4.1998,
para 61). It is also explained that if the environmental risks being run by regulatory inaction are in
some way "uncertain but non- negligible", then regulatory action is justified. This will lead to the
question as to what is the `non-negligible risk'. In such a situation, the burden of proof is to be
placed on those attempting to alter the status quo. They are to discharge this burden by showiung
the absence of a `reasonable ecological or medical concern'. That is the required standard of proof.
The result would be that if insufficient evidence is presented by them to alleviate concern about the
level of uncertainity, then the presumption should operate in favour of environmental protection.
Such a presumption has been applied in Ashburton Acclimatisation Society vs. Federated Farmers
of New Zealand [1988 (1) NZLR 78]. The required standard now is that the risk of harm to the
environment or to human health is to be decided in public interest, according to a `reasonable
persons' test. (See Precautionary Principle in Australia by Charmian Barton) (Vol.22) (1998) Harv.
Env. L.Rev. 509 at 549).
Brief Survey of Judicial and technical inputs in environmental appellate authorities/tribunals:
We propose to briefly examine the deficiencies in the Judicial and technical inputs in
the appellate system under some of our existing environmental laws. Different
statutes in our country relating to environment provide appeals to appellate
authorities. But most of them still fall short of a combination of judicial and scientific
needs. For example, the qualifications of the persons to be appointed as appellateA.P. Pollution Control Board vs Prof.M.V.Nayudu (Retd.) & Others on 27 January, 1999

authorities under section 28 of the Water (Prevention and Control of Polloution) Act,
1974, section 31 of the Air (Prevention and Control of Pollution) Act, 1981, under Rule
12 of the Hazardous Wastes (Management and Handling) Rules, 1989 are not clearly
spelled out. While the appellate authority under section 28 in Andhra Pradesh as per
the notification of the Andhra Pradesh Government is a retired High Court Judge and
there is nobody on his panel to help him in technical matters, the same authority as
per the notification in Delhi is the Financial Commissioner (see notification dated
18.2.1992) resulting in there being in NCT neither a regular judicial member nor a
technical one. Again, under the National Environmental Tribunal Act, 1995, which
has power to award compensation for death or injury to any person (other than
workmen), the said Tribunal under section 10 no doubt consists of a Chairman who
could be a Judge or retired Judge of the Supreme or High Court and a Technical
Member. But section 10(1)(b) read with section 10(2)(b) or (c) permits a Secretary to
Government or Additional Secretary who has been a Vice-Chairman for 2 years to be
appointed as Chairman. We are citing the above as instances of the grave
inadequacies.
Principle of Good Governance : Need for modification of our statutes, rules and notifications by
including adequate Judicial & Scientific inputs:
Good Governance is an accepted principle of international and domestic law. It
comprises of the rule of law, effective State institutions, transparency and
accountability in public affairs, respect for human rights and the meaningful
participation of citizens - (including scientists)
- in the political processes of their countries and in decisions affecting their lives.
(Report of the Secretary General on the work of the Organization,Official records of
the UN General Assembly, 52 session, Suppl. I (A/52/1) (para
22)). It includes the need for the State to take the necessary `legislative,
administrative and other actions' to implement the duty of prevention of
environmental harm, as noted in Article 7 of the draft approved by the Working
Group of the International Law Commission in 1996. (See Report of Dr.Sreenivasa
Rao Pemmaraju, Special Rapporteur of the International Law Commission dated
3.4.1998 on `Prevention of transboundary damage from hazardous activities') (paras
103, 104). Of paramount importance, in the establishment of environmental Courts,
Authorities and Tribunals is the need for providing adequate Judicial and scientific
inputs rather than leave complicated disputes regarding environmental pollution to
officers drawn only from the Executive.
It appears to us from what has been stated earlier that things are not quite satisfactory and there is
an urgent need to make appropriate amendments so as to ensure that at all times, the appellate
authorities or tribunals consist of Judicial and also Technical personnel well versed in
environmental laws. Such defects in the constitution of these bodies can certainly undermine theA.P. Pollution Control Board vs Prof.M.V.Nayudu (Retd.) & Others on 27 January, 1999

very purpose of those legislations. We have already referred to the extreme complexity of the
scientific or technology issues that arise in environmental matters. Nor, as pointed out by Lord
Woolf and Robert Cranworth should the appellate bodies be restricted to Wednesbury limitations.
The Land and Environment Court of New South Wales in Australia, established in 1980, could be
the ideal. It is a superior Court of record and is composed of four Judges and nine technical and
conciliation assessors. Its jurisdiction combines appeal, judicial review and enforcement functions.
Such a composition in our opinion is necessary and ideal in environmental matters.
In fact, such an environmental Court was envisaged by this Court atleast in two judgments. As long
back as 1986, Bhagwati,CJ in M.C.Mehta vs. Union of India and Shriram Foods & Fertilizers Case [
1986 (2) SCC 176 (at page 202)] observed:
"We would also suggest to the Government of India that since cases involving issues
of environmental pollution, ecological destructions and conflicts over national
resources are increasingly coming up for adjudication and these cases involve
assessment and evolution of scientific and technical data, it might be desirable to set
up Environmental Courts on the regional basis with one professional Judge and two
experts drawn from the Ecological Sciences Research Group keeping in view the
nature of the case and the expertise required for its adjudication. There would of
course be a right of appeal to this Court from the decision of the Environment Court."
In other words, this Court not only contemplated a combination of a Judge and Technical Experts
but also an appeal to the Supreme Court from the Environmental Court.
Similarly, in the Vellore Case [1996 (5) SCC 647], while criticising the inaction on the part of
Government of India in the appointment of an authority under section 3(3) of the
Environment(Protection) Act, 1996. Kuldip Singh, J. observed that the Central Government should
constitute an authority under section 3(3):
"headed by a retired Judge of the High court and it may have other members -
preferably with expertise in the field of pollution control and environmental
protection - to be appointed by the Central Government."
We have tried to find out the result of the said directions. We have noticed that pursuant to the
observations of this Court in Vellore Case, certain notifications have been issued by including a High
Court Judge in the said authority. In the notification So.671(E) dated 30.9.1996 issued by the
Government of India for the State of Tamil Nadu under section 3(3) of the 1986 Act, appointing a
`Loss of Ecology (Prevention and Payment of Compensation) authority, it is stated that it shall be
manned by a retired High Court Judge and other technical members who would frame a scheme or
schemes in consultation with NEERI etc. It could deal with all industries including tanning
industries. A similar notification So. 704 E dated 9.10.1996 was issued for the `Environmental
Impact Assessment Authority' for the NCT including a High Court Judge. Notification datedA.P. Pollution Control Board vs Prof.M.V.Nayudu (Retd.) & Others on 27 January, 1999

6.2.1997 (No.88E) under section 3(3) of the 1986 Act dealing with shrimp industry, of course,
includes a retired High Court Judge and technical persons. As stated earlier, the Government of
India should, in our opinion, bring about appropriate amendments in the environmental statutes,
Rules and notification to ensure that in all environmental Courts, Tribunals and appellate
authorities there is always a Judge of the rank of a High Court Judge or a Supreme Court Judge, -
sitting or retired - and Scientist or group of Scientists of high ranking and experience so as to help a
proper and fair adjudication of disputes relating to .pl68 environment and pollution. There is also
an immediate need that in all the States and Union Territories, the appellate authorities under
section 28 of the Water (Prevention of Pollution) Act, 1974 and section 31 of the Air (Prevention of
Pollution) Act, 1981 or other rules there is always a Judge of the High Court, sitting or retired and a
Scientist or group of Scientists of high ranking and experience, to help in the adjudication of
disputes relating to environment and pollution. An amendment to existing notifications under these
Acts can be made for the present. There is also need for amending the notifications issued under
Rule 12 of the Hazardous Wastes (Management & Handling) Rules, 1989. What we have said applies
to all other such Rules or notifications issued either by the Central Government or the State
Governments. We request the Central and State Governments to take notice of these
recommendations and take appropriate action urgently. We finally come to the appellate authority
under the National Environment Appellate Authority Act, 1997. In our view it comes very near to the
ideals set by this Court. Under that statute, the appellate authority is to consist of a sitting or retired
Supreme Court Judge or a sitting or retired Chief Justice of a High Court and a Vice-Chairman who
has been an administrator of high rank with expertise in technical aspects of problems relating to
environment; and .pl65 Technical Members, not exceeding three, who have professional knowledge
or practical experience in the areas pertaining to conservation, environmental management, land or
planning and development. Appeals to this appellate authority are to be preferred by persons
aggrieved by an order granting environmental clearance in the areas in which any industries,
operations or processes etc. are to be carried or carried subject to safeguards. As stated above and
we reiterate that there is need to see that in the appellate authority under the Water (Prevention of
Pollution) Act, 1974, the Air (Prevention of Pollution) Act, and the appellate authority under Rule 12
of the Hazardous Wastes (Management & Handling) Rules, 1989, under the notification issued
under section 3(3) of the Environment (Protection) Act, 1986 for National Capital Territory and
under section 10 of the National Environment Tribunal Act, 1995 and other appellate bodies, there
are invariably Judicial and Technical Members included. This Court has also observed in M.C.Mehta
vs. Union of India and Shriram Foods & Fertilizers Case [ 1986 (2) SCC 176] (at 262) that there
should be a right of regular appeal to the Supreme Court, i.e. an appeal incorporated in the relevent
statutes. This is a matter for the Governments concerned to consider urgently, by appropriate
legislation whether plenary or subordinate or by amending the notifications.
The duty of the present generation towards posterity : Principle of Inter-generational Equity: Rights
of the Future against the Present:
The principle of Inter-generational equity is of recent origin. The 1972 Stockholm
Declaration refers to it in principles 1 and 2. In this context, the environment is
viewed more as a resource basis for the survival of the present and future
generations. .lm10 .rm55 Principle 1 states:A.P. Pollution Control Board vs Prof.M.V.Nayudu (Retd.) & Others on 27 January, 1999

"Man has the fundamental right to freedom, equality and adequate conditions of life,
in an environment of quality that permits a life of dignity and well-being, and he
bears a solemn responsibility to protect and improve the environment for present
and future generations........"
Principle 2:
"The natural resources of the earth, including the air, water, lands, flora and fauna
and especially representative samples of natural ecosystems, must be safeguarded for
the benefit of present and future generations through careful planning or
management, as appropriate."
Several international conventions and treaties have recognised the above principles and in fact
several imaginative proposals have been submitted including -the locus standi of individuals or
groups to take out actions as representatives of future generations, or appointing Ombudsman to
take care of the rights of the future against the present (proposals of Sands & Brown Weiss referred
to by Dr.Sreenivasa Rao Pemmaraju, Special Rapporteur, paras 97, 98 of his report).
Whether the Supreme Court while dealing with environmental matters under Article 32 or Article
136 or High Courts under Article 226 can make reference to the National Environmental Appellate
Authority under the 1997 Act for investigation and opinion:
In a large number of matters coming up before this Court either under Article 32 or
under Article 136 and also before the High Courts under Article 226, complex issues
relating to environment and pollution, science and technology have been arising and
in some cases, this Court has been finding sufficient difficulty in providing adequate
solutions to meet the requirements of public interest, environmental protection,
elimination of pollution and sustained development. In some cases this Court has
been referring matters to professional or technical bodies. The monitoring of a case
as it progresses before the professional body and the consideration of objections
raised by affected parties to the opinion given by these professional technical bodies
have again been creating complex problems. Further these matters sometime require
day to day hearing which, having regard to other workload of this Court, (- a factor
mentioned by Lord Woolf) it is not always possible to give urgent decisions. In such a
situation, this Court has been feeling the need for an alternative procedure which can
be expeditious and scientifically adequate. Question is whether, in such a situation,
involving grave public interest, this Court could seek the help of other statutory
bodies which have an adequate combination of both Judicial and technical expertise
in environmental matters, like the Appellate Authority under the National
Environmental Appellate Authority Act, 1997? A similar question arose in Paramjit
Kaur vs. State of Punjab [1998 (5) SCALE 219 = 1998 (6) J.T.338], decided by this
Court on 10.9.1998.A.P. Pollution Control Board vs Prof.M.V.Nayudu (Retd.) & Others on 27 January, 1999

In that case, initially, W.Petitions (Crl.) No.447 and 497 of 1995 were filed under Article 32 of the
Constitution of India alleging flagrant violations of human rights in the State of Punjab as disclosed
by a CBI report submitted to this Court. This Court felt the need to have these allegations
investigated by an independent body. This Court then passed an order on 12.12.1996 requesting the
National Human Rights Commission to examine the matter. The said Commission is headed by a
retired Chief Justice of India and other expert Members. After the matter went before the said
Commission, various objections were raised as to its jurisdiction. It was also contended that if these
issues were to be otherwise inquired into by the Commission upon a complaint, they would have
stood time barred. These objections were rejected by the Commission by an elaborate order on
4.8.1997 holding that once the Supreme Court referred the matters to the Commission, it was acting
sui Juris, that its services could be utilised by the Supreme Court treating the Commission as an
instrumentality or agency of the Supreme Court, that the period of limitation under the Protection
of Human Rights Act, 1993 would not apply, that in spite of the reference to the Commission, the
Supreme Court would continue to have seisin of the case and any determination by the Commission,
wherever necessary or appropriate, would be subject to the approval of the Supreme Court. Not
satisfied with the above order of the Commission, the Union of India filed clarification application
Crl.M.P. No.6674 of 1997 etc. This Court then passed the order aforementioned in Paramjit Kaur vs.
State of Punjab [1998 (5) SCALE 219 = 1998 (6) J.T. 332 (SC)] on 12.12.1998 accepting the reasons
given by the Commission in rejecting the objections. In that context, this Court held that (i) the
Commission was an expert body consisting of experts in the field (ii) if this Court could exercise
certain powers under Article 32, it could also request the expert body to investigate or look into the
allegations, unfettered by any limitations in the Protection of Human Rights Act, 1993, (iii) that by
so referring the matters to the Commission, this Court was not conferring any new jurisdiction on
the Commission, and (iv) that the Commission would be acting only in aid of this Court. In our view,
the above procedure in Paramjit Kaur vs. State of Punjab is equally applicable in the case before us
for the following reasons. Environmental concerns arising in this Court under Article 32 or under
Article 136 or under Article 226 in the High Courts are, in our view, of equal importance as Human
Rights concerns. In fact both are to be traced to Article 21 which deals with fundamental right to life
and liberty. While environmental aspects concern `life', human rights aspects concern `liberty'. In
our view, in the context of emerging jurisprudence relating to environmental matters, - as it is the
case in matters relating to human rights, - it is the duty of this Court to render Justice by taking all
aspects into consideration. With a view to ensure that there is neither danger to environment nor to
ecology and at the same time ensuring sustainable development, this Court in our view, can refer
scientific and technical aspects for investigation and opinion to expert bodies such as the Appellate
Authority under the National Environmental Appellate Authority Act, 1997. The said authority
comprises of a retired Judge of the Supreme Court and Members having technical expertise in
environmental matters whose investigation, analysis of facts and opinion on objections raised by
parties, could give adequate help to this Court or the High Courts and also the needed reassurance.
Any opinions rendered by the said authority would of course be subject to the approval of this Court.
On the analogy of Paramjit Kaur's Case, such a procedure, in our opinion, is perfectly within the
bounds of the law. Such a procedure, in our view, can be adopted in matters arising in this Court
under Article 32 or under Article 136 or arising before the High Courts under Article 226 of the
Constitution of India.A.P. Pollution Control Board vs Prof.M.V.Nayudu (Retd.) & Others on 27 January, 1999

The order of reference:
After the above view was expressed to counsel on both sides, certain draft issues were
prepared for reference. There was some argument that some of the draft issues could
not be referred to the Commission while some others required modification. After
hearing arguments, parties on both sides agreed for reference of the following issues
to the Appellate Authority under the National Environmental Appellate Authority
Act, 1997.
We shall now set out these issues. They are: (a) Is the respondent industry a
hazardous one and what is its pollution potentiality, taking into account, the nature
of the product, the effluents and its location?
(b) Whether the operation of the industry is likely to affect the sensitive catchment
area resulting in pollution of the Himayat Sagar and Osman Sagar lakes supplying
drinking water to the twin cities of Hyderabad and Secunderabad?
We may add that it shall be open to the authority to inspect the premises of the factory, call for
documents from the parties or any other body or authority or from the Government of Andhra
Pradesh or Union Government and to examine witnesses, if need be. The Authority shall also have
all powers for obtaining data or technical advice as it may deem necessary from any source. It shall
give an opportunity to the parties or their counsel to file objections and lead such oral evidence or
produce such documentary evidence as they may deem fit and shall also give a hearing to the
appellant or its counsel to make submissions.
A question has been raised by the respondent industry that it may be permitted to make trial runs
for atleast three months so that the results of pollution, could be monitored and analysed. This was
opposed by the appellant and the private respondent. We have not thought it fit to go into this
question and we have informed counsel that this issue could also be left to the said Authority to
decide because we do not know whether any such trial runs would affect the environment or cause
pollution. On this aspect also, it shall be open to the authority to take a decision after hearing the
parties. Parties have requested that the authority may be required to give its opinion as early as
possible. We are of the view that the Authority could be requested to give its opinion within a period
of three months from the date of receipt of this order. We, therefore, refer the above issues to the
above-said Appellate Authority for its opinion and request the Authority to give its opinion, as far as
possible, within the period above-mentioned. If the Authority feels any further clarifications or
directions are necessary from this Court, it will be open to it to seek such clarifications or directions
from this Court. The Company shall make available photo copies of the paper books filed in this
Court or other papers filed in the High Court or before the authority under section 28 of the Water
Act, 1974, for the use of the Appellate Authority. The Registry shall communicate a copy of this order
to the Appellate Authority under the National Environmental Appellate Authority Act, 1997. Matter
may be listed before us after three months, as part-heard. Ordered accordingly. In the context of
recommendations made for amendment of the environmental laws and rules by the Central
Government and notifications issued by the Central and State Governments, we direct copies of thisA.P. Pollution Control Board vs Prof.M.V.Nayudu (Retd.) & Others on 27 January, 1999

judgment to be communicated to the Secretary, Environment & Forests (Government of India), New
Delhi, to the Secretaries of Environment & Forests in all State Governments and Union Territories,
and to the Central Pollution Control Board, New Delhi. We further direct the Central Pollution
Control Board to communicate a copy of this judgment to all State Pollution Control Boards and
other authorities dealing with environment, pollution, ecology and forest and wildlife. The State
Governments shall also take steps to communicate this judgment to their respective State Pollution
Control Boards and other authorities dealing with the above subjects - so that appropriate action can
be taken expeditiously as indicated in this judgment.A.P. Pollution Control Board vs Prof.M.V.Nayudu (Retd.) & Others on 27 January, 1999

