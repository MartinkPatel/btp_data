Alaknanda Hydro Power Co.Ltd vs Anuj Joshi & Ors on 13
August, 2013
Equivalent citations: AIRONLINE 2013 SC 491
Author: K.S. Radhakrishnan
Bench: Dipak Misra, K.S. Radhakrishnan
                                                                             REPORTABLE
                        IN THE SUPREME COURT OF INDIA
                        CIVIL APPELLATE JURISDICTION
                       CIVIL APPEAL NO. 6736  OF 2013@
                 (SPECIAL LEAVE PETITION (C) NO.362 OF 2012)
ALAKNANDA HYDRO POWER CO. LTD.             ……APPELLANT
                                   Versus
ANUJ JOSHI & ORS.                               …….RESPONDENTS
      WITH
                     Civil Appeal Nos.6746-6747  of 2013
                (Arising out of SLP(C) No.5849-5850 of 2012)
                                     and
                        T.C. (C) No.55 to 57 of 2013
                               J U D G M E N T
K.S. Radhakrishnan, J.
Leave granted.
2. Srinagar Hydro Electric Project (SHEP) located in Tehri / Pauri Garhwal district of Uttar Pradesh
was a project envisaged by the then Uttar Pradesh State Electricity Board (UPSEB) on river
Alaknanda, which was basically run-of-the-river scheme.
3. The Techno-Economic approval of the scheme was granted for 200 MW by the Central Electricity
Authority (CEA), a competent authority exercising powers under Section 29 of the Electricity
(Supply) Act, 1948, in its meeting held on 6.11.1982, subject to the environmental clearance from the
Ministry of Environment. SHEP was later segregated from twenty two other Ganga Valley projects.
A separate Environment Impact Assessment (EIA) was made on the SHEP on 9.2.1985. No adverse
affect had been noticed on environment in that assessment on setting up of the Project. On theAlaknanda Hydro Power Co.Ltd vs Anuj Joshi & Ors on 13 August, 2013

contrary, it was felt that such a scheme would add to the richness of the scenic beauty by creation of
beautiful lakes attracting more tourists and also meet the energy requirements of the State and
could be completed within a short span of five years. Dhari Devi Temple, it was noticed, was likely to
be submerged in water, therefore was also considered while considering the Environmental Impact
Assessment (EIA). It was suggested that temple would be raised and created with a pleasing
architecture suiting the surroundings.
4. The Ministry of Environment and Forest (MoEF) granted Environmental Clearance for the
project to UPSEB vide its letter dated 03.05.1985 subject to certain safeguards. The project involved
diversion of forest land to the extent of 338.38 hectares which was cleared by the Forest Department
vide proceeding No. 8-227/86-PC dated 15th April, 1987, in accordance with Section 2 of the Forest
(Conservation) Act, 1980. The Project involved construction of concrete gravity dam affording a
gross storage of 8 Mcum water conductor system designed for 660 cumecs and a power house with
an installation of six units of 55 MW each. UPSEB later carried out a detailed study and submitted a
report stating that taking into consideration the peaking capacity, the installed capacity of the
project would be increased from 200 MW to 330 MW. CEA approved and granted the
Techno-economic clearance in the enhanced capacity of 330 MW vide its letter dated 18.12.1987.
Planning Commission vide its letter dated 29.01.1988 accorded the investment approval. UPSEB
started the work but due to the paucity of funds the project could not make any effective progress.
5. The Government of India, in the meanwhile, had liberalized the policy to encourage private
participation in power development. Consequently, the UP Government following the above
mentioned policy decided to invite private investment in the development of energy sector especially
with regard to the Srinagar Hydro Electric Project. Consequently, the State Government had entered
into a Memorandum of Understanding (MOU) with M/s Duncan Industries Ltd. on 27th August,
1994 for development of the project and in terms of the MOU, M/s Duncan Industries Ltd. had
established a generating company ‘Duncan North Hydro Power Co. Ltd.’. The project was an
ongoing project and most of the infrastructure required for the execution of the project had already
been arranged by the State Government. The Department of Energy and Government of Uttar
Pradesh then wrote to the MoEF by letter dated 04.09.1997 to transfer the environmental clearance
earlier granted to the UPSEB to the Duncans so that the safeguards against environmental
degradation while clearing the project might be implemented by the Duncans.
6. M/s Duncan submitted a revised EIA report and DPR to the MoEF on 25.01.1996 and it was also
conveyed that the project of the enhanced capacity of 330 MW had to be transferred to the Duncans.
MoEF following the letters dated 25.01.1996 and 18.06.1998 on the subject transferred
environmental clearance to Duncans for 330 MW on 27.07.1999 subject to the condition that the
conditions stipulated in the environmental clearance already granted and any other conditions, if
stipulated in future for protection of the environment would be fulfilled by Duncans. CEA also
issued the Techno Economic clearance for implementation of the Project vide it letter dated
14.06.2000 to Duncans.
7. The Duncans had also given up the project after carrying out some work and in its place came the
appellant - Alaknanda Hydro Power Company Ltd. (AHPCL). Request was then made to the MoEFAlaknanda Hydro Power Co.Ltd vs Anuj Joshi & Ors on 13 August, 2013

by AHPCL for transfer of the environmental clearance granted to 330 MW Srinagar Hydro Electric
Project in its favour. Request was favourably considered by the MoEF and vide communication
J-12011/6/96/ IA-I dated 27th March 2006 MoEF transferred the environmental clearance in
favour of AHPCL stating that it was with the approval of the competent authority.
8. First respondent along with few others filed Writ Petition (PIL) No. 137/2009 before the High
Court of Uttarakhand at Nainital to quash the above mentioned order and sought a CBI inquiry
relating to the enhanced capacity of 330 MW mentioned in the letters dated 27.07.1999 and
27.03.2006. Direction was also sought for against AHPCL to stop the construction of the Hydro
Power Project and also for other consequential reliefs. Writ Petition was disposed of on 19.04.2011
with a direction to AHPCL to approach the MoEF for a specific decision as to the clearance for
increased capacity of generation and increased height of the dam. The MoEF was directed to take a
decision within a period of three months. Court, however, noticed that the clearance had already
been given by the MoEF in the year 1985 which stood transferred in favour of AHPCL for
construction of the dam for generation of 200 MW of electricity and 63 metre height of the dam.
The Court also ordered that the construction of dam for the said height and for generation capacity
of 200 MW would not be stopped but the construction beyond that limit could be proceeded only
after clearance is sought from the MoEF.
9. MoEF as directed by the High Court considered the entire matter afresh and rendered a specific
decision dated 03.08.2011clarifying that transfer letter dated 27.03.2006 in favour of AHPCL was
for 330 MW. The operative portion reads as follows:-
“The matter has been reviewed by the Ministry and it is to clarify that while
transferring the environment clearance dated 3rd May, 1985 of the Project in the
name of Uttar Pradesh State Electricity Board (UPSEB) to M/s. Duncans North
Hydro Power Company Limited vide this Ministry’s letter No. 12011/6/96-IA-I dated
27.7.1999 (copy enclosed), the Ministry had reviewed that increased capacity from
200 MW (4X50 MW) to 330 MW (5X66 MW) and associated parameters like change
in dam height from 73m to 90m from the deepest foundation and FRL from EL
604.0m to 605.5m. The Ministry also noted that there was a change in the
submergence from 300 ha to 324.074 ha, however Forest land remained the same i.e.
338.36 ha dated 15th April, 1987 which will be the final Forest Land for the Project.
Therefore, the final parameters for the project are as follows:-
i) Submergence area – 324.074 ha
ii) Forest land for diversion – 338.86 ha
iii) Capacity – 330 MW (4X82.5 MW)
iv) Dam height from the deepest foundation – 90 m
v) Dam height for the river bed level – 66 mAlaknanda Hydro Power Co.Ltd vs Anuj Joshi & Ors on 13 August, 2013

vi) FRL – EL 605.5 m
vii) MDDL – EL 603.0 m
viii) Dam top Road level – 611.0 m In view of the above, I am directed to clarify that
the transfer of environment clearance from DHPCL to Alaknanda Hydro Power
Company Limited (AHPCL) vide this Ministry’s letter No. J-12011/6/96-IA_I dated
27th March, 2006 is of 330 MW capacity with the above mentioned parameters. The
Ministry has further noted the change in the units from 6X55 MW to 4X82.5MW, as
approved by CEA.
This has approval of the Competent Authority.”
10. MoEF though clarified the position as directed by the High Court, the first respondent herein
along with one Dr. Bharat Jhunjhunwala preferred Writ Petition (PIL) No. 68 of 2011 before the
High Court of Uttarakhand at Nainital on 09.08.2011 challenging the order dated 03.08.2011.
11. Writ Petition was disposed of by the High Court directing AHPCL to place the documents
mentioned in Schedule IV to the Notification dated 27.01.1994 before MoEF and the Ministry was
directed to take steps to hold a public hearing as envisaged in the Notification. Further, it was also
ordered that the notice should mention that the public hearing would be given at Dhari Devi Temple
premises and that the Commissioner, Pauri Garhwal to be present at the public hearing. Further,
Court also noticed that the construction work had progressed to a great extent and at no stage, there
was any objection to the construction of the project having a capacity of 200 MW and, therefore, did
not stop the construction, however, it was made clear that the same would be subject to the decision
taken by the MoEF.
12. AHPCL, aggrieved by the above mentioned judgment, has preferred this appeal by raising the
core issue with regard to the applicability of EIA Notification dated 27.01.1994 in a case where the
project had been granted environmental clearance for 200 MW on 3.05.1985 and thereafter for 330
MW by the MoEF on 15.4.1987 and approved by CEA on 18.12.1987, followed by the sanction
accorded by the Planning Commission on 29.1.1988.
13. Respondents 1 and 2 in Civil Appeal arising out of SLP (Civil) No. 362 of 2012 also filed SLP
(Civil) Nos. 5849-5850 of 2012 challenging the order of the High Court dated 3.11.2011 and the
order dated 5.12.2011 passed on the review petition contending that the finding recorded by the
High Court that they had not questioned the environmental clearance for 200 MW, was incorrect.
They also wanted the stoppage of the project till the procedure laid in the EIA Notification 2006 is
complied with including the holding of a public hearing.
14. Mr. M.L. Lahoty, learned counsel appearing for the appellant – AHPCL submitted that EIA
Notification dated 27.01.1994 (as submitted upto 07.07.2004) would operate only prospectively and
that too only to those projects which are either ‘new’ or ‘expansion or modernisation’ of the existing
project is proposed after 1994 Notification. Learned counsel made reference to the judgment of thisAlaknanda Hydro Power Co.Ltd vs Anuj Joshi & Ors on 13 August, 2013

Court in Narmada Bachao Andolan v. Union of India and Others (2000) 10 SCC 664 and submitted
that the Notification would operate only prospectively. Learned counsel pointed out that public
hearing was expressly excluded by para 4 of the Explanatory Note to the Notification in respect of
projects like Srinagar Hydro Project where neither large displacement is involved nor is there severe
environment ramification. Further, it was also pointed out that the expansion of the project from
200 MW to 330 MW was granted in the year 1987 prior to the notification and even the original EIA
of 1994 would not apply. Further, it was also pointed out that Amendment Act 77 of 2004 was
incorporated simultaneously with the explanation along with two Entries Nos. 31 and 32 to bring
within its purview the “new construction projects” and “new industrial estates”. Learned counsel
pointed out so far as the Hydro Projects are concerned, they are not covered by the said two newly
introduced Entries as from the very inception of 1994 notification, Hydro Power Projects are
covered by Rule 2 of Schedule 1 and therefore the explanation so inserted also has no application.
Consequently, the concept of ‘plinth level’ is also not applicable as it goes with the applicability of
the Explanation.
15. Learned counsel also pointed out that the environmental clearance even otherwise was issued in
the light of the specific decision of MoEF dated 03.08.2011 clarifying that the transfer letter of
27.3.2006 in favour of AHPCL was for 330 MW. Learned counsel in support of his contention made
reference to the judgment of this Court in Lafarge Umiam Mining (P) Ltd. v. Union of India, (2011) 7
SCC 338. Learned counsel also pointed out that the project in question was conceptualized more
than three decades back. As on date the project stands almost completed and more than Rs.4000
cores had been invested and therefore, there is no question of holding a public hearing at this stage.
Further, it was also pointed out that State Government had ascertained views of the local
inhabitants, public representatives, Gram Panchayat, Shopkeepers, Temple Pujaris, Trust, devotees
etc. and it was considering their views, the MoEF granted environmental clearance and also forest
clearance for the project.
16. MoEF in the counter affidavit filed on 25.7.2012 stated that the project in question was granted
environment clearance in the year 1985 and hence it would not come under the purview of EIA
Notification of 1994 or EIA Notification of 2006 which replaced the EIA Notification of 1994.
Further, it was stated that the construction of project was already in an advance stage and hence
public hearing would be an empty formality, since the purpose of public hearing is to know the
concerns of the affected people and to incorporate their concerns appropriately into the
Environment Management Plan (EMP) for the project and it is after incorporation of the concerns
and revising/modifying the EMP, the final EMP would be submitted to the MoEF for granting
environmental clearance to the project. MoEF has, therefore, taken the stand that since
environmental clearance to the project had already been granted in the year 1985 prior to the
coming into force of the Environmental (Protection) Act, 1986 and the EIA Notification of 1994, no
public hearing was necessitated.
17. Shri Lahoty also pointed out that so far as the issue of Dhari Devi temple is concerned, the Joint
Committee had endorsed and recommended that upliftment of the temple adhering to the INTACH
plan is the best option and has found wide acceptability amongst Temple Samiti, Pujari, local
inhabitants as well as local statutory authorities. Elaborate arguments were also addressed by theAlaknanda Hydro Power Co.Ltd vs Anuj Joshi & Ors on 13 August, 2013

learned counsel on muck Management and submitted and that they had substantially complied with
the proposed directions under Section 5 of the Environmental Protection Act. Arguments were also
addressed on the Catchment Area Treatment Plan and submitted that an amount of Rs.22.30 crores
was deposited with the Forest Department way back in 2007-09. Further, it was also pointed out
that the AHPCL had spent about 40 crores for rehabilitation and resettlement of the affected people
in the catchment area. For Greenbelt Development, it was pointed out that an amount of Rs.2.30
crore was made available to the State of Uttarakhand by AHPCL. Learned counsel, therefore,
submitted that the respondents are unnecessarily creating hurdle in the completion of the project
and litigation is not in public interest but for advancing the private interest of the respondents.
18. We may indicate while going through the averments made in the writ petition as well as the
impugned judgment and the pleadings of the parties, it is seen that the question that was primarily
raised before the High Court was with regard to the necessity of a public hearing and also whether
the sanction had been accorded to construct the project with the capacity of 330 MW. This Court in
Narmada Bachao Andolan case (supra) has held that the 1994 Notification applies only
prospectively, in any view so far as this case is concerned the environmental clearance cannot be an
issue in view of the specific stand taken by MoEF and the orders dated 03.08.2011 passed by MoEF
which can also be considered as an ex post facto approval. SHEP, it may be noted, is an ongoing
project for which environmental clearance was granted as early as in the year 1985 and forest
clearance in the year 1987. Further, about 95 % of the work is already over and nearly Rs.4,000
crores has been spent. If public hearing is found necessary then the same should have held before
granting environmental clearance. The purpose of public hearing, it may be noted, is to know the
concerns of the affected people and to incorporate their concerns appropriately into the EMP and it
is after incorporation of the concerns and revision/modifying plan, the final EMP would be
submitted to the MoEF for granting environmental clearance. Environmental clearance, in the
instant case, had been granted in the year 1985 and the project is an ongoing project which is now
nearing completion and, therefore, no purpose would be achieved by way of a public hearing at this
stage. We also notice from the various Committees’ reports and the report dated 3.5.2013 that they
had met the temple trustees, priests and residents of the locality, they had not raised any objection
for not holding a public hearing. Further, the State of Uttarakhand has also never canvassed for a
public hearing nor any complaint was received by the temple authorities or the worshippers raised
any complaint of not holding any public hearing there. We, therefore, set aside the direction given
by the High Court directing the MoEF to hold a public hearing.
19. We find that a new dimension has been added to this litigation by initiating certain proceedings
by group of litigants before the National Green Tribunal, New Delhi. MoEF also, on 30.06.2011, in
exercise of powers conferred under Section 5 of the Environment (Protection) Act, 1986 passed a
stop work order directing AHPCL to attend certain environmental issues which included (i)
mounting Dhari Devi temple at a higher elevation as per the Plan prepared by INTACH (ii) maintain
and manage muck at the various muck disposal sites by providing retention wall, slopes, compacting
and terracing etc. (iii) develop greenbelt (iv) Catchment Area Treatment (v) undertaking Supana
Query restoration (vi) maintain minimum environmental flow etc.Alaknanda Hydro Power Co.Ltd vs Anuj Joshi & Ors on 13 August, 2013

20. The second respondent and few others then approached NGT vide Appeal No. 9 of 2011 praying
for some rigours orders against AHPCL. The appeal was, however, disposed of by NGT directing
MoEF to take a final decision within a period of eight weeks. No decision was taken by the MoEF
within the time granted by the NGT which led AHPCL filing M.A. No. 103/2012 before the NGT to
revoke Section 5 directions and allow AHPCL to continue the construction work of the project.
21. The Tribunal (NGT) disposed of the application on 07.08.2012 expressing its anguish for not
disposing of the matter within the time granted by it. The AHPCL submitted that in spite of the fact
that it had complied with all the requirements stipulated in the notice dated 30.06.2011,
unnecessarily the project was held up causing huge financial loss to it. AHPCL also sought a
direction to transfer all the cases from NGT to this court to be heard along with the appeal.
Consequently, all those related matters were transferred to this case Court and were heard along
with these appeals.
22. We asked the Secretary, MoEF, when the matter came for hearing, as to whether the conditions
stipulated in its order dated 30.06.2011 had been complied with by the project proponent.
Committee headed by Dr. B.P. Das was constituted by MoEF to examine whether the project
proponent had complied with the conditions stipulated in the environmental clearance granted in
May 1985 as well as Order dated 30.06.2011 and the copy of the Das Committee report of August
2012 has been made available.
23. Reference was also made to the B.K. Chaturvedi Committee Interim Report, as well as the final
report, with regard to the environmental flow of Alakhnanda, Bhaghirthi and other tributaries of
Ganga which has also made some reference to this project as well. After noticing Das Committee
Report and after hearing learned counsel on either side, this Court thought it appropriate to
constitute a joint team consisting of officials of MoEF as well as State Government so as to conduct
an on the spot inspection of the project area in question and to examine whether the project
proponent had complied with all the conditions stipulated in the environmental clearance of May
1985 as well as Order dated 30.06.2011 of the MoEF, which also referred to the issue of the
protection of Dhari Devi Temple. The joint team was directed to give an opportunity of hearing to
second respondent as well. We have taken such a course to give a quietus and finality to the various
issues which are long standing.
24. The Joint Team consisted of Professor R. Ramesh National Centre Coastal Zone Institute,
Chennai, Mr. Gambhir Singh, Chief Conservator of Forests, Garwhal, Prof. R. Sakthivakivel,
International Water Management Institute, Mr. Lalit Kapur, Director, MoEF and Dr. Arun Kumar,
CSO, AHEC, IIT Roorkee as a Chairman of the Committee. This 5-members Committee visited the
project site including MUCK disposal sites on May 1st and 2nd 2013 and heard the second
respondent as well as the AHPCL. The Committee also visited Dhari Devi temple site and met
trustees, priests and few residents of village Dhari. The Committee also visited the catchment area.
The Committee examined as to whether the AHPCL had complied with the conditions stipulated in
the environmental clearance of May 1985 and also the conditions stipulated in forest clearance of
April, 1987. The Committee also examined whether the AHPCL had complied with the conditions
communicated under Section 5 of Environment (Protection) Act 1986 vide letter dated 30.06.2011,Alaknanda Hydro Power Co.Ltd vs Anuj Joshi & Ors on 13 August, 2013

also issues with regard to Dhari Devi Temple. The Committees, after considering all those aspects,
submitted its report on 03.05.2013. The operative portion of the same reads as follows:
“2. Compliance of Conditions stipulated In Environmental Clearance of May, 1985.
1. Fuel Wood should be provided to the construction stage so as to prevent
indiscriminate falling of trees in the neigbouring areas.
The budgeted estimate should therefore, be suitably augmented.
The AHPCL has informed that they have made arrangements through their contractor to supply
cooking gas for all the workers of the project. Nearly three to four hundred cylinders are used by the
workers of all contractors for cooking requirements. In case of non-availability of gas, kerosene is
used on limited occasions. No fuel wood is used for cooking or any other purpose. In case of any
exigency wood is purchased from authorized Government/Forest departments by the contractor.
2.Critically eroded areas in the catchment should be identified for undertaking time bound soil
conservation program in the first phase, concurrently with the construction works. The catchment
area treatment plans be worked out expeditiously.
Uttarakhand Forest Department has provided a status on the CAT plan and green belt matter and is
placed at Annexure – 2.
Uttarakhand Forest Department is executing the CAT plan through its four Divisions viz.
Narendranagar, Rudraprayag, Garhwal and Civil - Soyam Pauri Forest Division. The proposed
outlay of CAT plan for five year period was Rs.22.03 crores deposited by the AHPCL in three
instalments (last in April 2009) to the Nodal Officer who in turn transferred this amount to the
CAMPA fund with Govt. of India. In 2010, the funds were transferred to the CAMPA society of
Uttarakhand Govt. for execution of proposed works.
To bring uniformity and for providing directions for finalization of CAT plans in participatory mode,
PCCF Uttarakhand vide letter No. 238/PA and Kha-2023/13-2(2) dated 25 March 2011 issued
guidelines for implementation of CAT plans in participatory mode. Overall framework for reviewing
CAT plans was approved by steering committee of UK CAMPA in its 3rd meeting on 16th May 2011.
Further, the PCCF vide office Memo NO. 174/13-2(2) dated 03.08.2011 issued preliminary
guidelines with respect to creation of a Project Management Unit (PMU) for implementation of the
CAT Plan. The funds for CAT plan are being allocated as per original proposal. However,
micro-plans are being prepared in participatory mode by the respective Divisions of the Forest
department following the Procurement Rules, 2008.
In pursuance to the above mentioned facts preparatory phase for the CAT plan execution was
started in 2011-12 during which identification of sites, consultations with village communities,
preparation of micro-plans by PRA method and awareness campaigns were carried out. In 2012-13,
nursery raising, advance soil works were carried out together with preparatory activities. Total 133Alaknanda Hydro Power Co.Ltd vs Anuj Joshi & Ors on 13 August, 2013

villages have been identified for the CAT plan and Division wise distribution of which is
Narendranagar Forest Division – 40 villages, Rudraprayag Forest Division – 41 villages, Garhwal
Forest Division – 21 villages and Civil-Soyam Pauri Forest Division – 31 villages. Out of the 133
villages micro-plans have been prepared for 76 villages and division wise status of preparation of
micro-plans in Rudraprayag Forest Division – 34 villages, Garhwal Forest Division – 21 villages and
Civil Soyam Pauri Forest Division – 31 villages. During the financial year 2012-13, implementation
of micro plans was started in 10 villages and during current financial year approximately 60 villages
are being taken up for this purpose.
Nursery activities have been selected at Division level. The actual requirement of the plants is
expected to be known on completion of all micro-plans. Based on estimates saplings are already
being raised in nurseries as Narendranagar Forest Division – 1.5 lacs saplings, Rudraprayag Forest
Division – 5.4 saplings, Garhwal Forest Division – 1.0 saplings and Civil-Soyam Pauri Forest
Division – 1.3 saplings. Through these nurseries afforestation is being taken up through micro
planning of the planned villages in the catchment.
A total sum of Rs.46.22 lacs has been spent so far by the department during the financial years
2011-12 and 2012-13 under the budget provided by the project.
Further from other sources of funding i.e. 13th Finance Commission and FDA etc. the forest
department of Uttarakhand has treated 882 Ha area as well as constructed 81 check dams and 10
water ponds in the catchment of the project.
3. Afforestation should be undertaken on a large scale in the project area and a 50m wide green belt
created around the periphery of the reservoir.
For afforestation the response has been same as above in 2.
Compensatory afforestation as the Indian Forest Conservation Act (1980) was completed in an area
of 347 ha in district Lalitpur of Uttar Pradesh (the then combined State) after the forest clearance
accorded in the year 1987.
Based on the estimates provided by Forest department in June 2012 for a sum of Rs.652.49 lacs to
be implemented in six years, AHPCL has deposited first year budget of Rs.203.6 lacs with the state
forest department for creating Green Belt around the rim of the reservoir of Srinagar HEP in August
2012.
The state forest department is expecting the Srinagar hydropower project to be commissioned in
Dec. 2013/Jan.2014 and only after filling the reservoir, they intend to assess the requirement of site
above the submerged area, the selection of species, the type of soil works etc. and creating the Green
Belt accordingly. Therefore they intend to start the green belt activities only after works of water
reservoir are completed and is filled. The work in the private land shall be taken up for green belt
development through participatory approach with the land owners.Alaknanda Hydro Power Co.Ltd vs Anuj Joshi & Ors on 13 August, 2013

4. Geo-morphological studies be undertaken in the catchment to formulate plans for the stability of
slopes on reservoir periphery through engineering and biological measures.
Geological Survey of India (GSI) has been appointed as the agency for carrying out the
Geo-morphological Studies. Total 9 villages have been identified. These are Dungripanth, Sendri,
Dhari, Kaliyasour, Gandasu, Farasu, Mehargon, Paparasuand and Maliyasu. The studies for 7
villages are completed. Recommendations received for 5 villages namely Dungripanth, Sendri,
Dhari, Kaliyasour, Gandasu and implemented by the AHPCL. As informed by AHPCL, the
recommendations for the displacement of the houses in the rim area of the reservoir have been
complied with. The balance reports are expected to be received from GSI soon.
Measures comprises of engineering and biological aspects in green belt area are being implemented
by state forest department.
5. A monitoring committee should be constituted, in consultation with the Department of
Environmental to oversee the effective implementation of the suggested safeguards.
The AHPCL has been submitting the half yearly compliance reports to the Regional Office of MoEF,
Lucknow. The Regional Office also visited the project site from time to time. The committees of Dr.
BP Das in June 2011, Dr. J.K. Sharma in June 2012, Dr. BP Das in Aug 2012 appointed by MoEF
and Shri ADN Rao in Dec.2012 appointed by NGT have visited the project site and submitted the
reports.
The committee is of the opinion that AHPCL should monitor the project during construction and
post construction for various parameters of water quality, aquatic biodiversity, landslides in the rim
area, inflow and outflow, impacts on water tables and springs and submit the reports to the State
Government and MoEF regularly.
There should a monitoring mechanism at the state level which should have the data for practicing
adaptive management and such monitoring may be carried out in association with project affective
society.
3. Compliance of conditions stipulated in Forest Clearance (FC) of April, 1987.
1. Legal status of land will remain unchanged.
No change has been reported.
2. Compensatory afforestation will be raised over and equivalent non forest land.
Compensatory afforestation as per the Indian Forest Conservation Act (1980) was completed in an
area of 347 ha in district Lalitpur of Uttar Pradesh (the then combined State) after the forest
clearance accorded in the year 1987.Alaknanda Hydro Power Co.Ltd vs Anuj Joshi & Ors on 13 August, 2013

3. The oustees will be rehabilitated as per plan submitted in the state government.
Since there were no human oustees in the submergence area no rehabilitation plan was prepared by
the State government. However, Geological Survey of India (GSI) was appointed by AHPCL for
carrying out the Geo-morphological Studies for 9 villages identified as Dungripanth, Sendri, Dhari,
Kaliyasour, Gandasu, Farasu, Mehargon, Paparasu and Maliyasu. As informed by AHPCL, the
recommendations for the displacement of the houses in the rim area of the reservoir have been
complied with for the recommendation received from GSI so far. The balance reports are expected
to be received from GSI soon.
Dhari Devi temple coming under the submergence area has been reported separately.
4. The project authority will establish fuel wood depots and the fuel wood be provided to
construction labor and staff free of cost, or its cost deducted from the salaries and wages to be paid
to the staff and labor.
The AHPCL has informed that they have made arrangements with the local gas supplier to supply
cooking gas for all the workers of the project. Nearly three to four hundred cylinders are used by the
workers of all contractors for cooking requirements. In case of non- availability of gas, kerosene is
used on limited occasions. No fuel wood is used for cooking or any other purpose. In case of any
exigency wood is purchased from authorized Government/Forest departments by the contractor.
4. Compliance of conditions communicated under Section 5 of EP (Act) 1986 vide letter dated
30.06.2011.
1. To preserve the religious sanctity and character of the Dhari Devi Temple, a modified plan will be
prepared in collaboration with INTACH, a Conservation Architect, the local Temple Samity and the
representative of GSI. The Plan should, inter alia, examine how part of rock on which the platform
of the deity has been constructed, along with the rock that formed its backdrop, shall be mounted at
a higher elevation in such a way that it maintains contact with the base rock from which it is raised.
2. Only after modified Plan as specified above has been prepared, the construction shall be resumed
at Dhari Devi Temple.
As reported by AHPCL a modified Temple Plan was prepared in collaboration with INTACH,
Temple Samithi and Geological Survey of India and submitted to MoEF on 12.09.2011 and further
intimated to MoEF on 09.02.2012 for continuation of works as per provisions of para 14(ii) of
Section 5 notice.
Earlier committees which visited sites during 16-17th June, 2012 and 29-30th August, 2012 and B.K.
Chaturvedi Committee report April 2013, have all recommended construction of temple works as
per INTACH scheme. The committee visited the temple site and found the work of raising the
platform was in advance stage of construction with certain changes made by temple priest and
trustees.Alaknanda Hydro Power Co.Ltd vs Anuj Joshi & Ors on 13 August, 2013

3. The muck slope at the edge of the river shall be adequately protected by a retaining wall of at least
1-2 m height to be 1m above HFL corresponding to a flood of 2500 to 3000m3/sec in the river.
4. The existing slope of the muck disposed off is around 40-45o and shall be flattened to 35o. The
walls shall be constructed partially upto a maximum of 2m height and need to be completed to the
top with surface protection before July 2011 when monsoon precipitation becomes intense. This is
considered expedient to prevent sloughing, sliding of the critically steep much slope and to arrest
flow of the muck into the river. The wall shall be constructive over a length of almost 1 km stretch at
three major sites i.e. the dam, desilting basin and power house. This would lead to adequate
environmental protection.
5. Muck shall be compacted and Terraces shall be formed where so ever possible.
As per plan approved by the State forest department there are 10 muck disposal sites in the project
area out of which only sites 8 & 9 are permanent and others are temporary meant only for
construction duration. A total volume of 66.1 lacs cubic meter of muck was estimated, out of which
16.79 lacs cubic meter of muck has been utilized for back filling purpose. Further 12.5 lacs cubic
meter is contemplated to be utilized from muck site 6, 7 and 10 for back filling. 37.62 lacs cubic
meter is planned to be left over at site 3 (2.01 lacs cubic meter), 4(4.22 lacs cubic meter), 6(4.96 lacs
cubic meter), 7(2.39 lacs cubic meter), 8(8.8 lacs cubic meter), 9(12.48 lacs cubic meter) and 10(2.77
lacs cubic meter) for land shaping and grading. Total muck utilization as on date as informed by
AHPCL is estimated to be about 44%.
A review of water quality parameters (Temperature, pH, Dissolved Oxygen, Biological Oxygen
Demand) provided by the State Pollution Control Board, Uttarakhand for the year 2011-12 and
2012-13 measured in Alaknanda at Rudraprayag i.e. upstream of Srinagar project and in Alaknanda
at Deoprayag i.e. downstream of Srinagar project indicates that there is negligible difference in the
water quality parameters due to project construction activity.
Slope dressing and toe walls are constructed/being repaired at temporary sites. Some construction
material is stored on site No.6 and the same is planned to be removed after completion of words.
Soil from site No.4 is planned to be removed before monsoon, 2013 as the batching plant has been
removed now. Soil from site no.7 is being removed now. Slope dressing, Terracing, Toe walls would
be completed in location nos. 8 and 9 where much disposal is going to be permanent.
Angles of muck disposal sites 4,6,7,8 & 9 were got measured by AHPCL and are reported as follows:
4 – 21o/25o, 18o/33o, site 6 – 28o/29o, 32o/32o, site 7 – 33o/29o, 37o/36o/27o, site 8 – 31o,32o,
site 9 – 35o/36o/35o/37o, 35o/32o.
Slopes of muck disposal areas (angle of repose) are given as 45o at para 18(3) page no.16 of Report
on “Muck Disposable and Management of Srinagar project” by IIT, Roorkee, November 2008.
However MoEF letter has suggested flattening the slopes up to 35o. The slopes measured and
reported by AHPCL appear to be in order.Alaknanda Hydro Power Co.Ltd vs Anuj Joshi & Ors on 13 August, 2013

Earthen cofferdam in front of power house is planned to be removed after completion of power
house for joining the water from powerhouse to river through tail water channel and soil to be
utilized for back filling and landscaping. This cofferdam was synonymously referred to as Muck
disposal site no. 10 at Power house location in the section 5 notice dt. 30.06.2011. Disposal Location
no. 10 is well behind the power house coffer dam and has no contact with river water.
All the toe walls which got damaged at the muck disposal sites during monsoon, should be repaired
by AHPCL especially for those sites where muck is being stored permanently.
The photographs of all muck disposal sites of different time along with approved muck disposal plan
by AHPCL is placed at Annexure – 3.
6. Appropriate protection by plantation and gabions should be put only after slopes are flattened to
35o, protected by retaining walls of desired height. Thereafter, appropriate soil cover of 1m shall be
provided to raise plantation for slope protection.
7. Muck disposal site wise restoration plan with the targets shall be submitted immediately to the
MoEF.
In view of the ongoing removal of the muck from sites and construction activity the plantation is
expected to be taken up thereafter.
8. Green Belt development to be undertaken simultaneously along with project construction.
Based on the estimates provided by Forest department in June 2012 for a sum of Rs.652.49 lacs for
implementation in six years, AHPCL has deposited first year budget of Rs. 203.6 lacs with the state
forest department for creating Green Belt around the rim of the reservoir of Srinagar HEP in August
2012.
The state forest department is expecting the Srinagar hydropower project to be commissioned in
Dec 2013/Jan 2014 and only after filling the reservoir, the forest department intend to assess the
requirement of sites above the submerged area, the selection of species, the type of soil words etc.
and creating the Green belt accordingly. Therefore they intend to start the green belt activities only
after works of water reservoir are completed and is filled. The private land shall also be taken up for
green belt development through participatory approach with the land owners.
9. For expediting Geo-morphological studies by Geological Survey of India (GSI) and
implementation of recommendations before Dam gets operational. AHPCL shall pursue with GSI
and take up the mitigation measures immediately.
Geological Survey of India (GSI) has been appointed as the agency for carrying out the
Geo-morphological Studies. Total 9 villages have been identified. These are Dungripanth, Sendri,
Dhari, Kaliyasour, Gandasu, Farasu, Mehargon, Paparasu and Maliyasu. The studies for 7 villages
are completed. Recommendations received for 5 villages namely Dungripanth, Sendri, DhariAlaknanda Hydro Power Co.Ltd vs Anuj Joshi & Ors on 13 August, 2013

Kaliyasour, Gandasu and implemented by the AHPCL. As informed by AHPCL, the
recommendations for the relocation of the houses in the rim area of the reservoir have been
complied with. The balance reports are expected to be received from GSI soon.
Village: Dungripanth Recommendation of GSI with status House of Sri Hari Sankar Singh is to be
relocated – Complied. The area falling between +605.90 and 611.00 both Dungripanth and Dikholi
villages may be monitored from safety view point immediately after impounding of reservoir – Shall
be monitored accordingly House of C.S. Bahuguna needs to be relocated to a safe place – Complied.
Village : Sendri Recommendation of GSI with status 4 houses located close to the outer edge of the
ridge need to be relocated to a safer place – Complied Village – Dhari Houses and land upto EL
+616.00 sshall have to be displaced/acquired – Complied Village: Kaliyasour There would not be
major threat from the reservoir to the stability of slopes where main settlement is located – No
action is to be taken Village Gandasu Suitable remedial measures for slopes at specific locations are
being recommended – Action may be initiated after receipt of recommendations Village: Farasu
Studies conducted, report yet to be submitted.
Village Mehargon Studies conducted, report yet to be submitted.
10. The Restoration work for Supana Quarry shall be undertaken simultaneously, leaving the part
which is being used for storage of building material.
Committee observed from the site visit that storage of the building material has been almost
removed and vacated site is being filled with muck.
11. AHPCL shall maintain a minimum environmental flow as will be decided by the Ministry on the
basis of Study of IIT Roorkee on the Cumulative Impact Assessment on Alaknanda and Bhaghirathi
Basin.
As per the approved Environmental Management Plan of the project, AHPCL is required to release a
minimum of 5 cumecs of water from the Dam through out the year in the river section of water.
Ministry of Environment and Forest constituted an Inter-Ministerial Group (IMG) headed by Shri
B.K. Chaturvedi to consider the issue related to hydropower projects and environmental flows in
June 2012. The committee has submitted its report in April 2013 after considering the report from
IIT Roorkee, Wildlife Institute of India and others as available.
The MoEF is expected to take a decision on this and convey to the project proponent at appropriate
time for compliance.
12. Requisite clearances shall be sought by AHPCL for Alaknanda River Front Development Scheme
before proceeding further on this scheme.Alaknanda Hydro Power Co.Ltd vs Anuj Joshi & Ors on 13 August, 2013

13. AHPCL shall submit a detailed Action Plan on the above mentioned directions with time targets
along with a Bank Guarantee of Rs.1 crore in favour of the State Pollution Control Board,
Uttarakhand. The Bank Guarantee shall be forfeited in case of non compliance by AHPCL.
AHPCL informed that the proposed scheme is not a part of approved EMP/EC of the project. This
was an additional proposal from AHPCL. However, neither proposal nor word has been taken up so
far.
A Bank Guarantee of Rs.1 core was submitted through Uttarakhand on July, 2011.
5. TOR II: The Committee will also submit a full and complete picture of the project at present.
AHPCL has provided the statement of physical and financial progress of various work of the
Srinagar project as on March 31, 2013 and is given at Annexure 4. The summary of the same is as
below:
Civil Works: diversion tunnel, coffer dams, dam and spillway, head race tunnel,
forebay tank and byepass channel, bridges on the channel, penstock, power house
building, switchyard are 100% completed. The cross drainage works of Munjh Kot
nallah are 93% completed.
Hydro mechanical works: dam and spillway, head race tunnel, forebay and byepass
and draft tube are 100% completed.
Electro-mechanical works: 3 units are 100% completed whereas unit 4 is under
progress.
6.TORIII: In the context of Dhari Devi Temple, which is coming under submergence of the
reservoir, the Committee will suggest best possible option regarding how to protect the Dhari Devi
Temple without disturbance at its present location.
In the recent time there have been several committees who have gone through the issue of the
submergence of Dhari Devi temple and a numbers of alternative to prevent the submergence of the
Dhari Devi Temple were studied. These are as follows:
a) Architectural Heritage Division of Indian National Trust for Art and Cultural
Heritage (INTACH) has prepared a plan in consultation with Dhari Devi Temple
Trust, Geological survey of India and AHPCL in Sept 2011.
b) Dr. B.P. Das Committee Aug 2012 recommended that “In view of the compelling
Technical, Social, Religious and Sentimental Reasons narrated in para 4.2, the
feasibility of constructing a dry well structure to protect the rock mound in situ and
“Maa Dhari Devi Idol” in its existing position is not feasible. The team therefore
recommends for continuation of works of restoration of the temple as per INTACHAlaknanda Hydro Power Co.Ltd vs Anuj Joshi & Ors on 13 August, 2013

proposal”.
c) B.K. Chaturvedi Inter Ministerial Group (IMG) appointed sequel to the third
meeting of National Ganga River Basin Authority (NGRBA) in April 2012 submitted
its report in Sept 2012 where the IMG has recommended that best solution for saving
the temple appears to be accepting the recommendation of two member committee
comprising of Chairman Central Water Commission and Chairman Central
Electricity Authority represented by its Member (Hydro). The two member
committee examined the following option:
i) Construction of an enclosure bund around temple and surrounding ghat and access
road upto the level of 611m on the banks.
ii) Construction of an concrete well of about 30 meter diameter and 18 meter height
around the temple.
iii) Relocation of the temple to a safe location on the left bank of the river.
iv) Raising the temple above the highest flood level at its current location and to install the idol at
higher elevation at the same spot with access to the temple through a pedestrian bridge from the left
bank.
v) Construction of 30km long power channel and diversion dam in the upstream of existing dam.
Keeping in view the limitations and infeasibility of implementing the first three options the
committee recommended the fourth option i.e. “Raising the temple above the highest flood level at
its current location and to install the idol at higher elevation at the same spot with access to the
temple through a pedestrian bridge from the left bank.” This committee visited the Dhari Devi
temple on May 02, 2012 and interacted with trustees, priests of the Dhari Devi temple and few
residents of village Dhari who were In favour of raising the temple above the highest water level. In
fact the committee observed that the elevated platform of temple is in advance stage of construction
and the preparations are under way for shifting the deities to the elevated location. The trustee,
priests and resident who the committee interacted are of the opinion of early completion of the
temple at the elevated location.
Dr. B. Jhunjhunwala expressed apprehensions against moving the Dhari Devi temple to a higher
elevation, as it is against the “Rights of Worship”. He proposed the option of Construction of 30 km
long power channel and diversion dam in the upstream of existing dam.
7. TOR IV: The committee will gather evidence through photography/videography The photographs
taken during site visit are available at annexure – 5
8. TOR V: The Committee will give personal hearing to Shri Bharat Jhunjhunwala accompanied by
his wife & representatives of the project proponent i.e. AHPCL who will place their views andAlaknanda Hydro Power Co.Ltd vs Anuj Joshi & Ors on 13 August, 2013

records if any, before the said Committee.
The committee gave personal hearing to Shri Bharat Jhunjhunwala accompanied by his wife as well
as project proponent (AHEC) on May 01, 2013 and heard patiently. The points raised by Shri Bharat
Jhunjhunwala are addressed as below:
a. Sale of power outside the area The project clearances were accorded in the year
1985 and 1987 during the period of undivided Uttar Pradesh. The power purchase
agreement of the project is with Uttar Pradesh Govt. utility and free power @ 12% of
power generated shall be available to Uttarakhand Government and is in line with the
Uttar Pradesh state re-organization Act 2000.
b. Conditions attached to Environmental Clearance 1985 Not in the purview of the
committee. He may request to the MoEF for the safe.
c. CAT Plan The status on the CAT plan has been given above under the EC and FC
clearance.
d. Compensatory afforestation The status on the afforestation has been given above
under the FC clearance.
e. Green Belt The status on the green belt has been given above under the EC and FC
clearance.
f. Geo morphological studies The status on these studies and resettlement of the
likely to be affected persons has been given above.
g. Dhari Devi Temple The response is given under TOR 3 h. Muck Disposal The status
of muck disposal sites is elaborated above along with annexure 3 of photographs of
all 10 locations.
i. Stop work order As informed by AHPCL that in view of NGT order of M.A. No.
103/2012 in Appeal No. 9 of 2011 dated Aug 07, 2012 they are continuing the
construction of work.
Committee also heard AHPCL through a power point presentation. The AHPCL
requested the committee that their project may be allowed to be commissioned as
earliest as possible.
9. RECOMMENDATIONS:
The committee after verifying the conditions and progress of the work at site and
hearing of Dr. B. Jhunjhunwala along with his wife and project proponent AHPCL
and interaction with others in the project area recommends following:Alaknanda Hydro Power Co.Ltd vs Anuj Joshi & Ors on 13 August, 2013

1. The muck disposal restoration may be done at the earliest. The necessary covering
with top soil, plantation and toe wall for the permanent disposable site no. 8 & 9 be
carried out at the earliest.
2. The catchment area treatment plan and green belt plan being executed by State
Forest department be expedited.
3. An effective monitoring mechanism at the state level which should have the data
for practicing adaptive management be created and such monitoring may be carried
out in association with project affective society.
4. As the project is in close proximity to habitations having several national and state
institutions/organization, the ongoing construction activities may be completed at
the earliest.”
25. Report is now being questioned by the MoEF, in spite of the fact, that they
constituted the joint team which included the Director, MoEF as its representative.
MoEF, in their written submission, raised an objection with regard to the proposal to
shift Dhari Devi temple to a higher place which according to the MoEF would wound
the religious feeling of large sections of Hindus. The MoEF felt that the project
proponents plan to lift the temple up on column and preserve it under guidance of
INTACH which could not possibly be a viable solution in view of the recent judgment
of this Court in Orissa Mining Corporation v. MoEF [(2013) 6 SCC 476] which says
that the religious faith, customs and practices of tribals have to be preserved and
protected. MoEF in its affidavit dated 6.5.2013 also took that position. The Principal
Secretary and State of Uttarakhand filed their response on 10.05.2013 with respect to
the affidavit filed by the MoEF on 06.05.2013 and the Report submitted by the Joint
Team. Forest Department of Uttarakhand also filed their note indicating their stand.
Detailed written submission has also been filed by the second respondent on
10.05.2013 with regard to the non-compliance of various directions given by the MoEF in its notice
dated 30.06.2011 by AHPCL.
26. Dr. B. Jhunjhunwala - party in person submitted that the High Court was right in directing a
public hearing following the 1994 Notification, the necessity of the same, according to him, has been
highlighted by this Court in G. Sundarrajan v. Union of India and Others, the judgment of which is
reported in (2013) 6 SCC 620. Dr. Jhunjhunwala has also highlighted the necessity of keeping Dhari
Devi temple on the spot at its present location. Dr. Jhunjhunwala further submitted that Right to
Worship stands at a higher pedestal than Right to Life under Article 21 and any disturbance of the
temple would violate the Right to Worship at Dhari Devi temple without any hindrance as
guaranteed under Article 25 of the Constitution of India. Dr. Jhunjhunwala also suggested that the
temple could be saved by making a canal instead of reservoir at the impugned project and the sacred
rock in situ by constructing a dry well of sufficient height and diameter around it and providing
pilgrim access to it by building an approach road.Alaknanda Hydro Power Co.Ltd vs Anuj Joshi & Ors on 13 August, 2013

27. We have gone through the affidavits filed by the State of Uttarakhand and we find they have
wholeheartedly accepted the B.P. Das Committee Report and the report dated 3.5.2013 submitted by
the Joint Team and also the B.K. Chaturvedi interim report dated September 2012. When this Court
constituted the Committee on 25.4.2013, this Court directed the inclusion of the State Government
representative as well, so that the State Government can express its views on various issues
including the issue relating to Dhari Devi temple. State Government in their affidavit, it may be
noted, have not questioned the suggestions made by the Committee in its report dated 3.5.2013.
Consequently, we have to take it that the State Government has no objection whatsoever with regard
to the suggestion made by the joint Committee in its report dated 03.05.2013 i.e. raising the temple
above the highest flood level at its current location and to install the idol at higher elevation at the
same spot with access to the temple through a pedestrian bridge from the left bank. The Committee
specifically stated in the report that they had visited Dhari Devi temple site and met trustees, priests
of the temple and few residents of village Dhari and no objection was raised either by the trustees or
priests of the temple on the suggestion made by the joint team in the report dated 03.05.2013.
INTACH Report:
28. We also find that the Architectural Heritage Division of Indian National Trust for Art and
Cultural Heritage (INTACH) has prepared a plan in consultation with Dhari Devi temple trust,
Geological Survey of India and AHPCL and which was submitted to the MoEF on 12.9.2011, which
has been accepted by all the subsequent Committees appointed.
Dr. B.P. Das Committee Report
29. MoEF in compliance with the order passed by this Court in SLP 362 and 5849 of 2012 in Writ
Petition No. 68 of 2008 dated 27.07.2012 constituted B.P. Das Committee vide his Order dated
17.08.2012 to verify whether AHPCL has complied with the conditions of the environmental
clearance granted in May 1985 and directions of the order issued under Section 5 of Environmental
(Protection) Act, 1986 dated 30.06.2011 and to examine the feasibility of well option of Dhari Devi
Temple.
30. We have already referred to in detail the steps taken by AHPCL to comply with the
environmental clearance granted in 1985 and the conditions stipulated in the MoEF Order dated
30.06.2011, which has also been noted by the Joint Team constituted on the basis of the directions
of this Court. B.P. Das Committee has elaborately examined the issue regarding restoration of Dhari
Devi Temple in Paras 4.0, 4.1, 4.2, 5.2.1, 6.0 of its report of August 2012 and ultimately came to the
conclusion that the proposal made by INTACH be accepted. The paragraphs mentioned above are
extracted hereunder for easy reference:
“4.0 Restoration of Dhari Devi Temple The Team visited the temple premises and
surroundings on 29th August 2012. Discussions were held with the officials of
AHPCL, office bearer of Aadhyashakti Maa Dhari Pujari Nyas, Shri V.P. Pandey,
President along with Shri Vivek Pandey, Secretary and a Pujari namely Shri Manish
Pandey. A number of local people and people representing differentAlaknanda Hydro Power Co.Ltd vs Anuj Joshi & Ors on 13 August, 2013

organizations/groups were present during the discussions. The following emerged as
a result of discussions and interactions.
4.1 Upliftment scheme for Dhari Devi temple prepared in collaboration with INTACH
• In accordance with the directions issued by MoEF vide dated 30.06.2011; the
project proponent had got a restoration plan for Dhari Devi Temple prepared by
INTACH. The construction, as per this plan, had already begun. Fourteen pillars out
of eighteen have been erected upto 10-15 meters of heights. No Temple work was in
progress on the day of site visit.
• In addition to main Deity ie Maa Dhari Devi, the Plan contains provision for installation of other
deities namely; Hanuman, Shiva, Havan Room, Prayer Hall, Mother rooms (2nos), office room and
adequate space for passage and congregation of devotees. A total plan area of 544 sq. Mtr. Has been
envisaged in the design of the temple at 611 meter Elevation and at 614 meter Elevation, as per the
scheme formulated by INTACH.
• The Group explained to the Temple Samity about the concept and design of Kudala Sangam
Temple in Karnataka where a well structure has been built to house a Samadhi. There was vehement
opposition from the Temple Samiti and the people gathered in an around the temple to this concept.
All the assembled people expressed that confinement of deity in a well is totally unacceptable to
them. The Temple Samiti explained that Maa Dhari Devi is presently facing a village called Dhari
Village and offering its blessing to the villagers and thus, protecting them from the perils and penury
of different sorts. Under no circumstances the deity should be hidden and kept in the well which will
cause obstruction to Maa Dhari Devi from viewing Dhari village. It was explained by them that the
top of the sanctum sanctorium shall have to be kept open to sky and therefore, a well structure will
pose many a problems.
• It was learnt from the Temple Samiti that Maa Dhari Devi is not part of the base rock. It is placed
on a marble/tiled platform on the rock. The President of Temple Samiti also informed that about
20-22 years back, the deity had once lifted from its earlier position.
• The Temple Samiti expressed their anguish and resentment at the prolonged delay in completing
the temple in its new form as per the INTACH design. They, along with the local people also
informed that they might execute the remaining work through Kar Seva if an early decision in their
favour is not forthcoming. They stated that they were fed up in facing Committees after Committees
on this issue.
• The Temple Samiti as well as local people expressed the view that in case of Kudala Sangam in
Karnataka State, a Samadhi has been housed in the well. They opined that there is no parity of
reasoning and therefore, these two are not comparable. Thus, the concept of well structure of Kudala
Sangam is not for a temple and the same cannot be considered appropriate for adoption in case of
Dhari Devi Temple. They further informed that the temple rehabilitation plan prepared by INTACH
is in conformity with temple architecture prevalent in Northern Part of India. They further informed
that the temple plan was approved by the State Govt. Of Uttarakhand during year 2009.Alaknanda Hydro Power Co.Ltd vs Anuj Joshi & Ors on 13 August, 2013

• The people also raised security, safety issues and difficulty in movement of devotees as the
congregation would be much more in case of Maa Dhari Devi temple than Kudala Sangam. The
entry and exit access for a well structure would be through spiral stairs along the stenning wall
which are disadvantageous and accident prone.
4.2 On the feasibility of “Protecting the sacred rock in situ by constructing a dry-well of sufficient
height and diameter around it and providing pilgrims access to it by building an approach way and a
stair case on the inner wall of the dry-well.” The team considered the following two alternative
options:
i) To protect the “Maa Dhari Devi idol” along with the sacred rock mound (Shila) by
constructing a bigger diameter dry well.
ii) To protect the rock mound (Shila) by constructing a smaller diameter dry-well in
conjunction with the “Maa Dhari Devi Idol” upliftment scheme prepared in
collaboration with the INTACH.
For the reasons and constraints mentioned below the team is of the view that both the proposals are
not feasible.
• A plan area of 544 sq. Meter has been worked out and provisioned for the temple complex. For a
circular structure such as dry well, this will entail a Bigger diameter (exceeding 50 meter) in order to
accommodate staircases, space for deities and other associated facilities. This has been examined by
Tata Consulting Engineers also, on behalf of the AHPCL. In view of very large diameter, the dry well
structure would encroach into the river where its width is already narrow. The construction of
dry-well structure will therefore, need temporary diversion of river water requiring structures like
cofferdam etc. Fresh EIA study and EC for river diversion arrangements may be required and
thereby delaying the temple construction/rehabilitation work and impounding of the reservoir.
• The concept of a “Small Dry-well” of around 15m in diameter is not feasible as four columns (out of
eighteen) enclosing an area of 10mX15m around the deity planned from structural consideration
that emerges out of INTACH restoration plan, will be fully interfering with the 15m well. This dry
well from consideration of structural safety to resist uplift of 17m (anticipated HFL of 609.5 at the
temple due to backwater rise minus base level of 593 m) will need a solid reinforced concrete (RC)
raft of 20 to 22m diameter, which would mean shattering and removing the entire rock mound
below the deity by the action of Drilling and Blasting. Even an annular raft will interfere with the
central four columns and shatter the sacred rock during blasting operations. This will defeat the very
purpose of protecting it.
• During field visit, neither the puja samiti / the head priest nor the large number of devotees
gathered there expressed their desire to go down to the lower level of the rock mound, once Maa
Dhari Devi is installed at EL 614.00 and all other deities will be installed to complete the religious
paraphernalia. The Puja Samity and the people at large expressed that they would feel hurt and
anguished if the lower rock is encircled by a large well barring an open exposure.Alaknanda Hydro Power Co.Ltd vs Anuj Joshi & Ors on 13 August, 2013

• The size and nature of sub-structure and its foundation of the well will depend on the geological
strata and formation of river bed which will govern the actual quantum of work for erecting the
structure. Detailed sub-soil study will be necessary for this.
• Safety arrangements covering a number of aspects have to be provided such as for emergency
evacuation, fire hazards etc. in case a well option is though of. It will also impede future expansion
of the temple premises which may be essential to cater for the increasing number of devotees
visiting the temple.
• As the top of the well would have to be kept open, the well will be subjected to heavy rain and
occasional cloud burst that may endanger the safety of deity and devotees. In addition, poor
ventilation and stampede like situation cannot be ruled out. In the net, the well structure will hinder
smooth “darshan” and movement of devotees.
• Structurally, the well will be subjected to huge uplift pressure making the well unsafe and unstable.
This will also entail huge thickness of wall and heavy founding rafts and thus, making construction
complicated as drilling, blasting and grouting of rocks will be a necessity.
• The devotees strongly object to any concept of well and expressed that confinement of Deity Maa
Dhari Devi in a well is totally unacceptable to them. The devotees strongly fell that under no
circumstances the Deity Maa Dhari Devi should be hidden and kept in a well. They desire that Maa
Dhari Devi should continue to face the Dhari village and offer blessings to the villagers and thus
protect them from perils and penury of all sorts.
• The well structure will go against the local aesthetic and cultural heritage as prevalent in the
region.
In view of the compelling Technical, social, religious, and sentimental reasons, the scheme of
constructing a big/small dry well structure to protect “Dhari Devi Idol” and the surrounding sacred
rock mound in its existing position is not feasible.
5.2.1 Dhari Devi Temple Rehabilitation Scheme (submission of modified plan for construction
commencement) There has been adequate compliance by the Project Proponent and they have
proceeded as per advice / directions given vide MoEF letter dated 30.06.2011. The project
proponent has also informed the MoEF in February, 2012 about their program to resume the works
as per modified temple restoration plan that has been prepared in collaboration with INTACH, a
Conservation Architect, involving local Temple Samity and a representative of GSI. The AHPCL
informed the MoEF about resumption of works on the Temple restoration accordingly.
6.0 Conclusion on Dhari Devi Temple Restoration Proposal.
The group is of the view that the architecture of temple in southern part of India and in Northern
part of India is altogether different. The INTACH proposal takes care of the people’s acceptability of
the temple in terms of design, plan, facade and overall architecture of the temple.Alaknanda Hydro Power Co.Ltd vs Anuj Joshi & Ors on 13 August, 2013

The project proponent has gone ahead with the construction of the uplifting proposal of the temple
in compliance with the directions given under Section 5 of EP (Act), 1986 on 30.06.2011. They have
followed the directions/ advice given under relevant paras of the order of the MoEF.
In addition to the engineering and construction related impediments in building a well structure
which will encroach into the main course of the river where it is narrow. There has been tangible
progress in the construction of the temple as per restoration plan prepared by INTACH and which
has got the acceptance of the Temple Samiti and the local citizen.
The Group does not consider it appropriate to thrust an option against the faith, belief, expectation
of the local people/stakeholders and which is contrary to cultural heritage of the region. It merits
mention that they are totally opposed and appeared contemptuous to the very concept of a well
structure for housing the deity.
A portion of the base rock is planned to be cut and placed at new location to form the Deity’s
backdrop. The Group noted that the Temple Samiti and others are in accordance with the overall
plan of restoration of Dhari Devi Temple as suggested by INTACH.
The Group also apprehends public unrest, agitation leading to law and order problem in the event of
thrusting upon them the option of well structure and other action causing prolonged delay in
putting the temple restoration issue, in accordance with INTACH plan in rest.” B.K. Chaturvedi
Committee Report
31. MoEF constituted an inter-ministerial group (IMG) under the Chairmanship of Shri B.K.
Chaturvedi, Member, Planning Commission on 15th June, 2012 to review and consider certain
issues related to environmental flows, environmental impact of the hydro-power projects in the
upper reaches of river Ganga and its tributaries such as Bhagirathi and Alaknanda. MoEF also vide
its office memorandum dated 20.7.2012 requested the Chaturvedi Committee to review the
cumulative impact on flow of river as also the social impacts of the relocation of Dhari Devi Temple
situated upstream of the project. A two-Member Committee consisting of Chairman, Central
Electricity Authority and Chairman, Central Water Commission, both of them are members of the
IMG, was constituted to consider the issue with regard to Dhari Devi Temple and to make
suggestions. The interim report dated 07.09.2012 (Volume II) of the two-Member Committee on
Dhari Devi Temple reads as follows:
12.3 Construction of Dhari Devi Temple on raised platform • The proposed structure
of Dhari Devi temple on a raised platform on concrete columns above HFL (at El.
+614 m) has been designed by IIT Roorkee and has got necessary clearance /
permission of the State Government.
• During the visit, discussions were held with several local people and priest of the temple. All the
people met with the Committee were found very positive towards the construction of Dhari Devi
temple on a raised platform. There was no objection on raising the temple at higher elevation and so
the project works can go on, it was felt by them.Alaknanda Hydro Power Co.Ltd vs Anuj Joshi & Ors on 13 August, 2013

• The construction of Dhari Devi temple on raised platform would cost to the Developer of Rs.9.0
crore only.
• It has been reported by the local residents that this temple has submerged earlier at several times
during high floods. Even on 3rd August, 2012 the water level reached up to the floor level of the
temple (+593 m) and lower part of the temple was filled with silt and floating debris, as it may seen
in the following photograph taken during visit.
• Even if, the dam would not have been constructed, there is always a possibility of submergence of
the temple during high flash floods.
13. Recommendations of the Two Member Committee Based on above findings, the
recommendations of the TMC are as under:
• Considering the significant progress of the project, the Section 5 may be withdrawn
by MoEF at the earliest so that the project works are resumed at site keeping in view
the national interest of hydro power sector, benefits of local people, project specific
local area development, feelings/views of project affected people, etc. otherwise it
would be an end to hydro power development in Uttarakhand as well as in the
country.
• Since an expenditure of over three thousand crore rupees have already been
incurred on the project, any delay in commissioning would add to heavy burden of
interest during the construction (IDC) and escalate the cost of the project and would
make the tariff chargeable to consumers completely unviable.
• During the discussion with villagers, it was observed that barring few individuals,
everyone is anxious to see completion of the project as early as possible. They are in
favour of construction of Dhari Devi temple on raised platform above HFL at the
earliest.
• Discussions were held with the officers of UJVNL and they were also keen in
completion of this project in view of the power shortages in Uttarakhand. The
Government of Uttarakhand would get 12% free power from the project on its
commissioning.
14. Conclusion • The idea of construction of a 30km power channel in lieu of existing dam cannot be
accepted at this stage on account of (i) geological and geotechnical investigations not done, (ii)
enormous cost of the power channel and new diversion dam, (iii) issue of forest clearance and land
acquisition, (iv) minimum 5 years of construction time, (v) very high tariff to be paid by the
purchaser.
• The Dhari Devi temple is not included in the protected monuments of Archaelogical Survey of
India and it is a local temple to be worshipped by nearby villagers only. All the local villagers and theAlaknanda Hydro Power Co.Ltd vs Anuj Joshi & Ors on 13 August, 2013

priest of the temple are in agreement with the project authorities to raise the temple on RCC
structure above HFL.
• Option of providing a well surrounding the temple is neither practical nor acceptable to locals.
32. Final Report was submitted by B.K. Chaturvedi Committee on April 2013 (Vol 1) before MoEF,
inter alia, reiterating its interim report on Dhari Devi Temple. Das Committee, Chaturvedi and Joint
Team constituted on the basis of direction of this Court have, therefore, fully endorsed the views
made by INTACH on Dhari Devi Temple. We find no reason to differ from the views expressed by
the expert committee, which was submitted hearing all the affected parties, including the Trustees of
the Temple, devotees, Pujaris etc. Committee reports to that extent stand accepted.
33. We are also not impressed by the argument that by accepting the suggestions of all the expert
committees to raise the temple as such to a higher place, would wound the religious feelings of the
devotes or violate the rights guaranteed under Article 25 of the Constitution. Sacred rock on which
the temple exits is still kept intact and only the height of the temple increased so that the temple
would not be submerged in the water. In Orissa Mining Corporation v. MoEF, this Court was
examining the rights of Schedule Tribes and the Traditional Forest Dwellers under the Forest Rights
Act, 2006 in the light of Articles 25 and 26 of the Constitution. This Court held that those articles
guarantee the right to practice and proposals not only in matters of faith or beliefs, but all rituals
and observation. We are of the view that none of the rights of the devotees of Dhari Devi Temple has
been affected by raising the level of the temple, which remains attached to the Sacred Rock.
34. MoEF proceedings dated 30.06.2011, Report of the Das Committee as well as the Joint Team
dated 3.5.2013 refer to the issue of muck management and disposal, catchment treatment area plan
and green belt and also the safety of the Dam.
Safety of the Dam
35. Dam safety and security is a matter of paramount importance, failure of which can cause serious
environmental disaster and loss of human life and property. Proper surveillance, inspection,
operation and maintenance of dams is essential to ensure for safe functioning of the Dams. The
Central Water Commission (CWC) is a premier technical organisation of India in the field of water
resources. The Commission is also entrusted with the general responsibilities of initiating,
coordinating and furthering, in consultation with the State Governments concerned, schemes for
control, conservation and utilisation of water resources throughout the country for the purpose of
flood control, irrigation, drinking water supply and water power development. Safety of dams, in our
country, is the principal concern of the State Government. The State Government has also to carry
out investigation, planning, design, construction and operation. AHPCL says, so far as SHEP is
concerned, engineering and technical parameters of the dam are clearly narrated in the detailed
project report which, in turn, are assessed by CEA in consultation with the CEC and GSI. The norms
and regulations laid down by the concerned authorities, and whether those are strictly followed or
not, have to be assessed and monitored by the Nodal Agency, CEA/Ministry of Power as well as the
GSI.Alaknanda Hydro Power Co.Ltd vs Anuj Joshi & Ors on 13 August, 2013

Safety and security of the people
36. Safety and security of the people are of paramount importance when a hydro electric project is
being set up and it is vital to have in place all safety standards in which public can have full
confidence to safeguard them against risks which they fear and to avoid serious long term or
irreversible environmental consequences. The question as to whether the recent calamities occurred
at Uttrakhand on 16.6.2013 and, thereafter, due to cloud burst, Chorabari Lake burst due to
unprecedented rain and consequent flooding of Alaknanda river etc. has affected the safety of SHEP
has also to be probed by the MoEF, State of Uttarakhand and Dam Safety Authority etc. Muck
Management and Disposal
37. Construction of SHEP involving excavation of earth and rock has generated large quantum and
with the objective to protect the disposal areas from further soil erosion and develop the
surrounding areas in harmony with the environment, the muck disposal plan is formulated. Muck
disposal plan gives quantification of muck, identifies location and activities wherein muck is
generated, during excavation and blasting operation and quantifies muck generated from the
activities with relevance to disposal areas. The Das Committee visited the project site and submitted
a status report on 29-30 August, 2012 which has dealt with muck disposal, details of which have
already been dealt with in the earlier part of the Judgment. Report of the Joint Committee dated
03.05.2013 also refers to the AHPCL’s action plan regarding muck management and disposal and
recommended that remaining work, particularly, of the permanent site No.8 and 9 be carried out at
the earliest. AHPCL has given the details of the work carried out for muck disposal. Failure of
removal of muck from the project site may also cost flooding of the project areas, causing
destruction to the environment and to the life of property of the people. MoEF and State
Government and all other statutory authorities would see AHPCL takes proper action and steps for
muck management and disposal.
Catchment Area Treatment (CAT)
38. CAT is required to be carried out by the project developer along with R & R and greenbelt
activities, primarily to mitigate the adverse environmental impact created by the project
construction. CAT is also resorted to reduce the inflow of silt and prevent sedimentation of
reservoirs. CAT management involves steps to arrest soil erosion, rehabilitation of degraded forest
areas through afforestation, controlling landslide and rockfalls through civil engineering measures
and long time maintenance of afforestation areas. Silt inflows in river water not only result in
reduction in storage capacity of dams, but also lead to increased wear and tear of turbines.
Therefore, CAT is of crucial importance with regard to hydro electric projects. CAT plan has been
prepared by the Uttrakhand Forest Department and the Project Proponent has paid the estimated
amount of Rs.22.30 crores to the State Forest Department towards implementation of CAT Plan.
39. We may, in this connection, refer to the brief note submitted by the AHPCL wherein they have
referred to landslide which occurred in the catchment area of dam Manari Bhali Stage-I in August
1978 blockading the Bhagirathi River with a dam of muck, about 40 KM upstream of dam. This dam
of muck breached on its over after 12 hours and the monsoon water accumulated during this periodAlaknanda Hydro Power Co.Ltd vs Anuj Joshi & Ors on 13 August, 2013

gushed out in form of a wall of water about 20 meter high. The flood receded after a few hours, but
the dam did not suffer any damage. It was pointed that during this flash flood period boulders up to
250 tonnes in weight had hit and rolled over the dam. The discharge in the river had risen to 4500
Cum per sec. Further it was also pointed out that in August 2012, partly constructed Srinagar Dam
also faced similar type of flood. This time due to cloud bursts and breaching of coffer dams in the
project upstreams, the water level at the Dam rose by 17 meters, but after the flood receded, no
damage to the dam was noticed. The discharge in the river had risen to 6500 Cum per sec. AHPCL,
therefore, maintains the stand that the structure of the dam is strong enough to bear the pressure
not less than 6500 Cum per sec of water discharge.
40. The Principal Secretary of Forest Department, Government of Uttarakhand submitted in a short
affidavit dated 10.05.2013, explaining the steps they have taken. The primary responsibility is on the
Forest Department to carry out effectively the CAT Plan. Proper steps would be taken by the
concerned authorities, if not already taken. MoEF, State Government and all other authorities will
see the same is fully implemented at the earliest, so also the recommendations made by the Joint
Team with regard to CAT.
Green Belt Development
41. AHPCL, it is seen, has deposited first year budget of Rs.203.6 lakhs to the State Forest
Department for green belt rim of the reservoir in August 2012. Although green belt area is
earmarked the technical documents based on the maximum flood level in the reservoir, the rim of
the reservoir, could only be determined and developed after reservoir is impounded. Proper steps
would be taken by the Forest Department of Uttarakhand to carry out the green belt development
area in question. The MoEF, the State Government etc. would see that the proper steps would be
taken by all the authorities including the AHPCL to give effect to the directions given by the Joint
Team.
42. Going through the reports of Das Committee, Chaturvedi Committee as well as the Joint Team
and after perusing the affidavits filed by the parties, we find no reason to hold up the project which
is almost nearing completion. MoEF, AHPCL, Government of Uttarakhand, Forest Department
would take immediate steps to comply with all the recommendations made by Joint Team in the
report dated 03.05.2013 and also oversee whether AHPCL is complying with those directions as
well.
43. Under such circumstances, the Appeal in SLP (C) No. 362/2012 would stand allowed and the
judgment of the High Court stands set aside. Consequently the SLP (C) Nos. 5849-5850 of 2012
would stand dismissed. All the Transferred matters from NGT are also disposed of as above.
Court’s concern
44. We are, however, very much concerned with the mushrooming of large number of hydroelectric
projects in the State of Uttarakhand and its impact on Alaknanda and Bhagirathi river basins.
Various studies also indicate that in the upper-Ganga area, including Bhagirathi and AlaknandaAlaknanda Hydro Power Co.Ltd vs Anuj Joshi & Ors on 13 August, 2013

rivers and their tributaries, there are large and small hydro power dams. The cumulative impact of
those project components like dams, tunnels, blasting, power-house, muck disposal, mining,
deforestation etc. on eco-system, is yet to be scientifically examined. MoEF undertook two studies in
the recent past:
i) Assessment of Cumulative Impact of Hydropower Projects in Alaknanda and
Bhagirathi Basins which was entrusted by National River Conservation Directorate
(NRCD) of MoEF to the Alternate Hydro Energy Centre (AHEC), IIT Roorkee vide
proceedings dated July 14, 2010.
ii) MoEF also vide their proceedings dated 23rd July, 2010 authorized Wild Life
Institute of India (WII), Dehradun to make an assessment on cumulative impacts of
“Hydroelectric Projects on Aquatic and Terrestrial Biodiversity in Alaknanda and
Bhagirathi Basins, Uttarakhand.
45. AHEC submitted their report to MoEF in December 2011 and WII finalized its report in
December 2012. AHEC made some recommendations on Geology, seismology, soil erosion,
sedimentation etc. Some of the major recommendations of the study covered the aquatic
biodiversity profile, critically important fish habitats including recommendation on Fish
Conservation Reserve at Nayar River and Bal-Ganga, Tehri Reservoir Complex. WII made
recommendations on impact on aquatic biodiversity and their habitats, terrestrial component of
biodiversity and details about these in the river basins. Recommendations were also made covering
environmental flows, conservation, reserve, strategic option of regulating impact of hydropower
projects of different categories and impact on aquatic biodiversity and terrestrial biodiversity in the
above mentioned basins.
46. We have gone through the Reports and, prima facie, we are of the view that the AHEC Report
has not made any indepth study on the cumulative impact of all project components like
construction of dam, tunnels, blasting, power-house, Muck disposal, mining, deforestation etc. by
the various projects in question and its consequences on Alaknanda as well as Bhagirathi river
basins so also on Ganga which is a pristine river. WII in its Report in Chapter VIII states as follows:
“Para 8.3.2 Present and future scenario The scenario building for assessing impacts on biodiversity
values portrays very distinctively the present and futuristic trends of the impact significance of
hydropower developments in all the sub- basins in the larger landscape represented by the
Alaknanda and Bhagirathi basins.
It becomes apparent that because of the fact that many of the projects are already in stage of
operation and construction, the reversibility in significance of impacts on terrestrial biodiversity is
not possible in sub-basins. Decline in biodiversity values of Bhagirathi II sub-basin have
significantly been compounded by Tehri dam.
The scenarios provide adequate understanding to make decisions with respect to applying exclusion
approach across the two basins for securing key biodiversity sites (such as critically importantAlaknanda Hydro Power Co.Ltd vs Anuj Joshi & Ors on 13 August, 2013

habitats) and prevent adverse impacts on designated protected areas. Based on five different
scenarios that have been presented the most acceptable option suggests that the decision with
respect to 24 proposed Hydro Electric Projects may be reviewed.”
47. WII report also states that out of total 39 proposed projects, 24 projects have been found to be
significantly impacting biodiversity in the two sub-basins and the combined footprint of all 24
projects have been considered for their potential to impact areas with biodiversity values, both
aquatic and terrestrial, critically important habitat of rare, endangered and threatened species of
flora and fauna and IWPA projected species.
48. B.K. Chaturvedi Committee, after referring to both the Reports, in Chapter III (Volume I, April
2013) stated as follows:
“3.66 The River Ganga has over a period of years suffered environmental degradation
due to various factors. It will be important to maintain pristine river in some river
segments of Alaknanda and Bhagirathi. It accordingly recommends that six rivers,
including Nayar, Bal Ganga, Rishi Ganga, Assi Ganga, Dhauli Ganga (upper reaches),
Birahi Ganga and Bhyunder Ganga, should be kept in pristine form and
developments along with measures for environment up gradation should be taken up.
Specifically, it is proposed that (a) Nayar River and the Ganges stretch between
Devprayag and Rishikesh and (b) Balganga – Tehri Reservoir complex may be
declared as Fish Conservation Reserve as these two stretches are comparatively less
disturbed and have critically important habitats for long-term survival of Himalayan
fishes basin. Further, no new power projects should be taken up in the above six river
basins. In the IMG’s assessment, this will mean about 400 MW of Power being not
available to the State.
3.67 Pending a longer term perspective on the Ganga Basin Management Plan,
following policy needs to be followed to implement the hydro power projects on the
River Ganga on Bhagirathi and Alaknanda basins:
(i) No new hydropower projects be taken up beyond 69 projects already identified
(Annex-VIA-VID).
(ii) New hydropower projects may be permitted to be constructed with limitations as
in Paras 3.52-3.54 above and giving priority to those projects already under
construction.
iii) New hydropower projects which are still under investigation or under
development are not being proposed for implementation. However, two such projects
can be considered and a view taken after technical assessment by the CEA.
Based on the above, projects at Annex-VID may need a review and decision till after long term
Ganga basin study by IIT Consortium. 3.70 The River Ganga has been a pristine River. Over a periodAlaknanda Hydro Power Co.Ltd vs Anuj Joshi & Ors on 13 August, 2013

of years, it has been used for irrigation, drinking water and other purposes. The efforts to keep it in
the pristine form have been minimal. The IMG felt that it will be necessary to take measures for
ensuring that several parts of it which have so far not been impacted continue to be in the pristine
form. Secondly, it consider necessary to take measures on pollution, particularly in the upper
reaches and the two basins of Bhagirathi and Alaknanda. The IMG, therefore, recommends that six
rivers, including Nayar, Bal Ganga River, Rishi Ganga, Assi Ganga, Dhauli Ganga (upper reaches),
Birahi Ganga and Bhyunder Ganga rivers should be kept in pristine form no further hydropower
developments should take place in this region. Further, environment upgradation should be taken
up in these sub- basins extensively.”
49. In the Executive Summary of Chaturvedi Report, on the question of ‘Environmental Impact of
Projects’, reads as follows:
17. Development of new hydropower projects has impact on environment, ecology,
biodiversity, both terrestrial & aquatic and economic and social life. 69 hydropower
projects with a capacity of 9,020.30 MW are proposed in Bhagirathi and Alaknanda
basins. This includes 17 projects which are operational with a capacity of 2,295.2
MW. In addition, 26 projects with a capacity of 3,261.3 MW (including 600 MW
Lohari Nagpala hydropower project, work on which has been suspended by
Government decision) which were under construction, 11 projects with a capacity of
2,350 MW CEA/TEC clearances and 16 projects with a capacity of 1,673.8 MW under
development.
4.18 The implementation of the above 69 hydropower projects has extensive
implications for other needs of this society and the river itself. It is noticed that the
implementation of all the above projects will lead to 81% of River Bhagirathi and 65%
of River Alaknanda getting affected. Also there are a large number of projects which
have very small distances between them leaving little space for river to regenerate
and revive.
50. The above mentioned Reports would indicate the adverse impact of the various hydroelectric
power projects on the ecology and environment of Alaknanda and Bhagirathi river basins. The
cumulative impact of the various projects in place and which are under construction on the river
basins have not been properly examined or assessed, which requires a detailed technical and
scientific study.
51. We are also deeply concerned with the recent tragedy, which has affected the Char Dham area of
Uttarakhand. Wadia Institute of Himalayan Geology (WIG) recorded 350mm of rain on June 15-16,
2013. Snowfall ahead of the cloudburst also has contributed to the floods resulting in the burst on
the banks of Chorabari lake near Kedarnath, leading to large scale calamity leading to loss of human
lives and property. The adverse effect of the existing projects, projects under construction and
proposed, on the environment and ecology calls for a detailed scientific study. Proper Disaster
Management Plan, it is seen, is also not in place, resulting in loss of lives and property. In view of
the above mentioned circumstances, we are inclined to give following directions:Alaknanda Hydro Power Co.Ltd vs Anuj Joshi & Ors on 13 August, 2013

1) We direct the MoEF as well as State of Uttarakhand not to grant any further
environmental clearance or forest clearance for any hydroelectric power project in
the State of Uttarakhand, until further orders.
2) MoEF is directed to constitute an Expert Body consisting of representatives of the
State Government, WII, Central Electricity Authority, Central Water Commission and
other expert bodies to make a detailed study as to whether Hydroelectric Power
Projects existing and under construction have contributed to the environmental
degradation, if so, to what extent and also whether it has contributed to the present
tragedy occurred at Uttarakhand in the month of June 2013.
3) MoEF is directed to examine, as noticed by WII in its report, as to whether the
proposed 24 projects are causing significant impact on the biodiversity of Alaknanda
and Bhagirath River basins.
4) The Disaster Management Authority, Uttarakhand would submit a Report to this
Court as to whether they had any Disaster Management Plan is in place in the State of
Uttarakhand and how effective that plan was for combating the present
unprecedented tragedy at Uttarakhand.
52. Reports would be submitted within a period of three months. Communicate the order to the
Central and State Disaster Management Authority, Uttarakhand.
53. In view of above, civil appeals and transferred cases are disposed of.
……………………………..J. (K.S. Radhakrishnan) ……………………………..J. (Dipak Misra) New Delhi,
August 13, 2013 | | |Alaknanda Hydro Power Co.Ltd vs Anuj Joshi & Ors on 13 August, 2013

