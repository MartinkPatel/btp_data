D.Selvi vs State Rep. By Its on 2 June, 2023
Author: M.Sundar
Bench: M.Sundar
                                                                                H.C.P.No.2293 of 2022
                                  IN THE HIGH COURT OF JUDICATURE AT MADRAS
                                                DATED: 02.06.2023
                                                        Coram
                                    THE HONOURABLE MR.JUSTICE M.SUNDAR
                                                    and
                                   THE HONOURABLE MR.JUSTICE R.SAKTHIVEL
                                              H.C.P.No.2293 of 2022
                  D.Selvi                                                           .. Petitioner
                                                         Vs.
                  1.State rep. By its
                    Home Secretary to the Government of Tamil Nadu,
                    Home, Prohibition and Excise Department,
                   Fort St. George, Chennai -600 009.
                  2.The Commissioner of Police,
                    Tambaram City, Tambaram.
                  3.The Inspector of Police,
                    T-10 Manimangalam Police Station,
                    Kanchipuram District.
                  4.The Superintendent of Prison,
                    Central Prison, Puzhal.                                    ..   Respondents
                            Petition filed under Article 226 of the Constitution of India praying
                  for issuance of a writ of habeas corpus to call for the records relating to
                  the order of detention passed by the second respondent dated
                  15.09.2022 in BCDFGISSSV No.142/2022 against the petitioner's son
                  the detenu Thiru.Vigneswaran @ Vicky, male, aged about 22 years, son
                  of Damodaran, who is confined at Central Prison, Puzhal and set asideD.Selvi vs State Rep. By Its on 2 June, 2023

https://www.mhc.tn.gov.in/judis
                  1/9
                                                                                    H.C.P.No.2293 of 2022
                  the same and direct the respondents to produce the detenu before this
                  Court and set him at liberty.
                            For Petitioner             :       Mr.T.Perinbanathan
                            For Respondents            :       Mr.R.Muniyapparaj
                                                               Additional Public Prosecutor
                                                               assisted by
                                                               Mr.M.Sylvester John
                                                            ORDER
[Order of the Court was made by M.SUNDAR, J.] Captioned 'Habeas Corpus Petition' [hereinafter
'HCP' for the sake of convenience and brevity] has been filed by mother of the detenu assailing
'detention order dated 15.09.2022 bearing reference BCDFGISSSV No.142/2022' [hereinafter
'impugned detention order' for the sake of convenience]. To be noted, the third respondent is the
sponsoring authority and the second respondent is the detaining authority as impugned detention
order has been made by the second respondent.
2. Impugned detention order has been made under 'The Tamil Nadu Prevention of Dangerous
Activities of Bootleggers, Cyber law offenders, Drug-offenders, Forest-offenders, Goondas, Immoral
traffic offenders, Sand-offenders, Sexual-offenders, Slum-grabbers and Video Pirates Act, 1982
(Tamil Nadu Act No.14 of 1982)' [hereinafter 'Act 14 https://www.mhc.tn.gov.in/judis of 1982' for
the sake of convenience and clarity] on the premise that the detenu is a 'Goonda' within the meaning
of Section 2(f) of Act 14 of 1982.
3. There is no adverse case. The ground case which is the sole substratum of the impugned detention
order is Crime No.265 of 2022 on the file of T-10, Manimangalam Police Station for alleged offences
under Sections 294(b), 341 and 302 of 'The Indian Penal Code (45 of 1860)' [hereinafter 'IPC' for the
sake of convenience and clarity]. Owing to the nature of the challenge to the impugned detention
order, it is not necessary to delve into the factual matrix or be detained further by facts.
4. Mr.T.Perinbanathan, learned counsel on record for petitioner and Mr.R.Muniyapparaj, learned
Additional Public Prosecutor assisted by Mr.M.Sylvester John learned counsel for all respondents
are before us.
5. In the hearing, learned counsel for the petitioner submitted that the co-accused in the ground
case was clamped with similar preventive detention order and similar preventive detention order
was assailed in H.C.P.No.2160 of 2022. The said HCP was allowed by this Court in and by an orderD.Selvi vs State Rep. By Its on 2 June, 2023

dated 18.04.2023, which reads as follows:
https://www.mhc.tn.gov.in/judis 'Captioned 'Habeas Corpus Petition' [hereinafter
'HCP' for the sake of convenience and brevity] has been filed by mother of the detenu
assailing 'detention order dated 15.09.2022 bearing reference BCDFGISSSV
No.145/2022' [hereinafter 'impugned detention order' for the sake of convenience].
To be noted, the fourth respondent is the sponsoring authority and the second
respondent is the detaining authority as impugned detention order has been made by
the second respondent.
2. Impugned detention order has been made under 'The Tamil Nadu Prevention of
Dangerous Activities of Bootleggers, Cyber law offenders, Drug-offenders,
Forest-offenders, Goondas, Immoral traffic offenders, Sand-offenders,
Sexual-offenders, Slum-grabbers and Video Pirates Act, 1982 (Tamil Nadu Act No.14
of 1982)' [hereinafter 'Act 14 of 1982' for the sake of convenience and clarity] on the
premise that the detenu is a 'Goonda' within the meaning of Section 2(f) of Act 14 of
1982.
3. There is no adverse case. The ground case which is the sole substratum of the
impugned detention order is Crime No.265 of 2022 on the file of T-10,
Manimangalam Police Station for alleged offences under Sections 294(b), 341 and
302 of 'The Indian Penal Code (45 of 1860)' [hereinafter 'IPC' for the sake of
convenience and clarity]. Owing to the nature of the challenge to the impugned
detention order, it is not necessary to delve into the factual matrix or be detained
further by facts.
4. Mr.R.Balakrishnan, learned counsel representing the counsel on record for
petitioner and Mr.R.Muniyapparaj, learned Additional Public Prosecutor assisted by
Mr.M.Sylvester John learned counsel for all respondents are before us.
https://www.mhc.tn.gov.in/judis
5. Learned counsel for petitioner predicated his campaign against the impugned detention order on
one short point and that is, in the Arrest Intimation Form it is recorded that the arrest of the detenu
was informed to his mother one Tmt.Muthulakshmi through her mobile bearing No.8608057690 by
way of SMS. He further submitted that this would not be a proper communication of arrest, more
so, there is no statement recorded from the said Tmt.Muthulakshmi to confirm as to whether she
received the arrest intimation, thereby hampered the right of the detenu to make an effective
representation.
6. The learned Additional Public Prosecutor submitted that the petitioner has not made any such
representation now putforth before this Court. Hence, the above contention may not be considered.D.Selvi vs State Rep. By Its on 2 June, 2023

7. The Hon'ble Division Bench of this Court in the case of “Akilandeswari Vs. State, rep. by Secretary
to Government, Home, Prohibition and Excise Department, Chennai-600009, reported in 2008 (3)
MLJ (Crl.) 744”, held as follows:
“5. Though the learned Additional Public Prosecutor has made an attempt to justify
by stating that the family members were intimated through telegrams, he has not
placed any material to satisfy this Court as to whether any telegram was sent and the
same was acknowledged either by the family members or relatives of the detenu. A
right of intimation to the relatives or family members of the detenu encompasses
itself the fundamental right guaranteed under Article 22(5) of the Constitution of
India to make a representation to the Detaining Authority or the State Government,
as the case may be. In the event the arrest is not intimated, the detenu would not be
in a position to make any such representation and in that context, failure on the part
of the Detaining Authority would amount to deprivation of
https://www.mhc.tn.gov.in/judis the right of the detenu to make an effective
representation guaranteed under Article 22(5) of the Constitution of India. On the
facts of this case, a specific averment has been made that the intimation was not
given. We also find that the said averment has not been controverted in the Counter
Affidavit. Though the learned Additional Public Prosecutor submitted that the family
members of the detenu were informed of the arrest through telegram, there are no
materials placed before us to substantiate the said contention. Further, the copy of
the telegram has also not been furnished to the detenu. In the absence of the same,
we are unable to accept the contention of the learned Additional Public Prosecutor
that the family members or the relatives of the detenu were informed of the arrest.
Under these circumstances, the detention order is vitiated.”
8. Following Akilandeswari Case (cited supra), this Court in the case of “Ganesh @ Lingesan Vs.
State of Tamil Nadu and another reported in 2012 (3) MWN (Cr.) 315 DB”, in paragraph No.10, held
as follows:
“10. “No man shall be deprived of his life and liberty except by procedure established
by law” has been guaranteed in Article 21 of the Constitution of India. His right to be
informed of the arrest is his basic human right. Curtailment of his personal freedom
in pursuance of a preventive detention law though has the constitutional sanction
(see Article 22(3)(b) of the Constitution of India), it is conditioned by many
constraints, one of which is a chance for him to make representation as against his
detention. (see Article 22(5) of the Constitution of India). If his arrest is not informed
to his dear and near ones, who could make representation as against the detention
order on his behalf, he cannot exercise the right given to him under Article 22(5) of
the Constitution of India. In this constitutional https://www.mhc.tn.gov.in/judis
perspective, the argument of the Respondent that by non-supply of a copy of the
telegram informing his arrest no prejudice is caused to the detenu is too big a pill to
gulp.”D.Selvi vs State Rep. By Its on 2 June, 2023

9. In this case, the arrest intimation is through Short Message Service (SMS). The reason given is
not acceptable, proper intimation has to be given to the detenu and the detenu must know the
reason for his arrest. Further, right of the detenu to make an effective representation qua the
preventive detention order is a Constitutional safeguard ingrained in Clause (5) of Article 22 of the
Constitution of India. In the light of the narrative thus far, this Constitutional safeguard is
hampered. The sequitur is, the impugned preventive detention order deserves to be dislodged.
10. Ergo, the sequitur is, captioned HCP is allowed and the detention order dated 15.09.2022
bearing reference BCDFGISSSV No.145/2022 made by the second respondent is set aside and the
detenu Thiru.Dilli Babu @ Smart Dilli Babu, aged 21 years, son of Thiru.Ravikumar is directed to be
set at liberty forthwith unless required in connection with any other case. There shall be no order as
to costs. '
6. Learned counsel for the petitioner submits that the points on which aforementioned HCP was
allowed are available in the captioned HCP also. This means that the impugned preventive detention
order in the captioned HCP also deserves to be dislodged.
https://www.mhc.tn.gov.in/judis
7. Ergo, the sequitur is, captioned HCP is allowed. Impugned detention order dated 15.09.2022
bearing reference BCDFGISSSV No.142/2022 made by the second respondent is set aside and the
detenu Thiru.Vigneswaran @ Vicky, aged 22 years, S/o.Thiru.Damodaran, is directed to be set at
liberty forthwith, if not required in connection with any other case / cases. There shall be no order
as to costs.
(M.S.,J.) (R.S.V.,J.) 02.06.2023 Index : Yes Neutral Citation : Yes mmi P.S: Registry to forthwith
communicate this order to Jail authorities in Central Prison, Puzhal, Chennai.
To
1.The Home Secretary to the Government of Tamil Nadu, Home, Prohibition and Excise
Department, Fort St. George, Chennai -600 009.
2.The Commissioner of Police, Tambaram City, Tambaram.
3.The Inspector of Police, T-10 Manimangalam Police Station, Kanchipuram District.
4.The Superintendent of Prison, Central Prison, Puzhal.
5.The Public Prosecutor High Court, Madras.
https://www.mhc.tn.gov.in/judis M.SUNDAR, J., and R.SAKTHIVEL, J., mmi 02.06.2023
https://www.mhc.tn.gov.in/judisD.Selvi vs State Rep. By Its on 2 June, 2023

