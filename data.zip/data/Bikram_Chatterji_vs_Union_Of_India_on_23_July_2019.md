Bikram Chatterji vs Union Of India on 23 July, 2019
Equivalent citations: AIRONLINE 2019 SC 2195, (2019) 9 SCALE 588
Author: Arun Mishra
Bench: Uday Umesh Lalit, Arun Mishra
                                             1
                                                                  REPORTABLE
                             IN THE SUPREME COURT OF INDIA
                         CIVIL ORIGINAL/ APPELLATE JURISDICTION
                              WRIT PETITION (C) NO.940/2017
                   BIKRAM CHATTERJI & ORS.                    ..PETITIONER(S)
                                           VERSUS
                   UNION OF INDIA & ORS.                      ..RESPONDENT(S)
                              WRIT PETITION (C) NO.947/2017
                              WRIT PETITION (C) NO.971/2017
                              WRIT PETITION (C) NO.942/2017
                         SPECIAL LEAVE PETITION (C) NO.1879/2018
                              WRIT PETITION (C) NO.1041/2017
                              WRIT PETITION (C) NO.1018/2017
                              WRIT PETITION (C) NO.1116/2017
                              WRIT PETITION (C) NO.1144/2017
                              WRIT PETITION (C) NO.1156/2017
                              WRIT PETITION (C) NO.1206/2017
                               WRIT PETITION (C) NO.8/2018
                              WRIT PETITION (C) NO.1242/2017
                               WRIT PETITION (C) NO.58/2018
                               WRIT PETITION (C) NO.21/2018Bikram Chatterji vs Union Of India on 23 July, 2019

Signature Not Verified
                               WRIT PETITION (C) NO.52/2018
Digitally signed by
JAYANT KUMAR ARORA
Date: 2019.07.23
15:58:43 IST
Reason:
                               WRIT PETITION (C) NO.91/2018
                               WRIT PETITION (C) NO.56/2018
              2
 WRIT PETITION (C) NO.57/2018
 WRIT PETITION (C) NO.74/2018
WRIT PETITION (C) NO.134/2018
WRIT PETITION (C) NO.131/2018
WRIT PETITION (C) NO.160/2018
WRIT PETITION (C) NO.164/2018
WRIT PETITION (C) NO.182/2018
WRIT PETITION (C) NO.199/2018
WRIT PETITION (C) NO.226/2018
WRIT PETITION (C) NO.245/2018
WRIT PETITION (C) NO.281/2018
WRIT PETITION (C) NO.306/2018
WRIT PETITION (C) NO.298/2018
WRIT PETITION (C) NO.246/2018
WRIT PETITION (C) NO.267/2018
WRIT PETITION (C) NO.288/2018
WRIT PETITION (C) NO.460/2018Bikram Chatterji vs Union Of India on 23 July, 2019

WRIT PETITION (C) NO.353/2018
WRIT PETITION (C) NO.378/2018
WRIT PETITION (C) NO.742/2018
WRIT PETITION (C) NO.829/2018
     SMC (CRL.) NO.4/2018
WRIT PETITION (C) NO.1397/2018
                                      3
                             JUDGMENT
Arun Mishra, J.
1. These writ petitions pertain to the projects of various companies of Amrapali Group in the Noida
and Greater Noida.
2. It is submitted on behalf of the petitioners that in 2011 in Noida and Greater Noida various real
estate projects for housing were started. In the various projects, the Amrapali Group of Companies
proposed to construct approximately 42,000 flats. Various brochures were published and it was
assured that the delivery of possession shall be made in 36 months and other world-class amenities
were also promised.
3. Various home buyers booked their apartments during the period 2010-2014. The buyers signed
the Standard Form of Allotment-cum-Flat Buyers Agreement and even after payment of 40 to 100
percent of total consideration, they are faced with the threat of forfeiture of huge booking amount.
The agreement contained specific terms as to interest. Under Clause 14 of the agreement, the builder
authorised itself to finance loan from any financial institution by way of
mortgage/charge/securitization of receivable of the land and flats and the allottees will have no
objection in this regard. Clause 15 also authorised the builder to keep full authority over the flat
depriving the allottees of any lien or interest despite payment of entire amount thereof.
4. The builder under Clause 19(a) was obliged to complete the flats of M/s. Amrapali Centurion Park
Private Limited within 30 months from the date of commencement of excavation/signing of the
agreement, which may vary for plus/minus 6 months. Under Clause 19(c), builder fixed a paltry sum
of Rs.5 per square feet super area per month for the period of delay, which would include any/all
damages, compensation, claims for delayed possession.
5. The buyers invested their life savings and some of them had obtained the loan from the Bank.
Most of the buyers have made the payment to the extent of 50 percent to 100 percent abiding by the
payment schedule. The dreams of the buyers of obtaining house were given serious jolts when M/s.
Amrapali Silicon City Private Limited and M/s. Amrapali Centurian Park Private Limited,
respondent Nos.3 and 4 herein respectively were found in serious breach of their obligation to
deliver the flats within 36 months. They did not pay the amount either to the Noida or GreaterBikram Chatterji vs Union Of India on 23 July, 2019

Noida Authority and also to the Banks. Several revised dates of possession were fixed unilaterally,
but they failed to deliver the flats. The Amrapali Group has failed to comply with its obligation under
the subvention scheme, the tenure of which was approved by the bank/financial institution. The
builder had failed to comply with the abovementioned scheme as the buyer making the payment of
EMIs to the banks, thereby causing a double loss. Some of the consumers approached the National
Consumer Dispute Redressal Commission (for short, ‘the NCDRC') by filing Consumer Complaint
No.213 of 2017 under Section 12(1)(c) of the Consumer Protection Act, 1986.
6. The Bank of Baroda had filed Company Petition No. (IB)- 121(PB)/2017 before the National
Company Law Tribunal (for short, ‘the NCLT’) under Section 7 of the Insolvency and Bankruptcy
Code, 2016 for triggering the Corporate Insolvency Resolution Process in the matter of M/s.
Amrapali Silicon City Private Limited, respondent No.3. The NCLT appointed the Interim
Resolution Professional (in short, the ‘I.R.P'). Moratorium was also declared thereby restricting the
institution of any suits against the corporate debtor including execution of any judgment, decree or
order; transferring, encumbering, alienating or disposing of by the corporate debtor any of its assets
or any legal interest therein; and any action to foreclose, recover or enforce any security interest
created by the corporate debtor in respect of its property under the Securitisation and
Reconstruction of Financial Assets and Enforcement of Security Interest Act, 2002 (for short ‘the
SARFAESI Act'). The order of NCLT has a direct bearing on the home buyers of M/s. Amrapali
Centurian Park Private Limited, respondent no.4, which is virtually owned by M/s. Amrapali Silicon
City Private Limited with 98.84 percent shareholding. Both the companies are run by the almost
same set of Directors including Mr. Anil Kumar Sharma and Mr. Shiv Priya. Thus, in order to secure
the interest of home buyers, in the instant petitions under Article 32, a plethora of intervention
applications have been filed.
7. It is submitted on behalf of petitioners that home buyers have put their lives at stake by paying
their lifetime savings and hard-earned money in the purchase of flats. As such, they cannot be
categorised as ordinary financial creditors to rank pretty low in the order of priority under Section
53. Corporate builder heavily counts upon the home buyers as stakeholders to sustain in the market.
Section 53 of the Insolvency and Bankruptcy Code, 2016 is irrational and violates the rights of the
home buyers guaranteed under Article 21 as by subjecting the home buyers to the liquidation
proceedings of discriminatory nature. The very survival of home buyers has been seriously
jeopardised. Not only they are going to lose the entire money with accrued interest, but they also
become financially crippled for all time to come even close to the dream of a new home, let alone
purchase it. There is no equal protection under the Insolvency and Bankruptcy Code, 2016. The
moratorium imposed by NCLT directly affecting not only the home buyers of M/s.Amrapali
Centurion Park Private Limited, but also similarly situated lakhs of home buyers in various other
projects. They cannot be deprived of their legal rights. Similar plight has been averred by the other
buyers in the other several projects.
8. The matter projects the issue of larger public interest. The real estate business has developed and
it mainly survived by the money invested by the buyer for the purchase of the house. They have the
right to obtain houses. The facts of the instant case project that Noida and Greater Noida haveBikram Chatterji vs Union Of India on 23 July, 2019

allotted huge plots to the builders by charging a sum of approximately 10 percent and in most of the
cases, thereafter no money has been paid. The large number of projects which have come up not
only in Noida and Greater Noida, but most of them have not been completed by the
builders/promoters and they have siphoned buyers' money in large scale. No action has been taken
by the Noida and Greater Noida Authorities against builders for cancellation of leases due to
violation to fulfil their obligation. Bankers have financed to builder certain loan on the condition to
invest in the projects, but they have also permitted the money to be used as for other purposes as
apparent from the report of the Forensic Audit in the instant case which had been submitted by
Auditors - Mr. Pawan Kumar Aggarwal and Mr. Ravinder Bhatia. The facts which are projected in
the Forensic Auditor Report speaks for itself.
9. Before we consider the Forensic Audit, it would be appropriate to refer to certain orders which
were passed from time to time by this Court. This Court on the application filed by petitioner -
Bikram Chatterji, passed an order on 22.11.2017, directing builder to deposit 10 percent of the dues
to Noida Authorities. This Court also directed that the phase in respect of which Occupancy
Certificate and No Objection Certificate, if granted, the possession of flats shall be handed over to
the respective flat buyers. Liberty was granted to flat owners to complete the finishing work.
Thereafter, an order was passed on 31.1.2018, requesting the builder to deposit amount as ordered
on 17.11.2017. It was also pointed that in several places firefighting devices were not installed though
the places were occupied by thousands of families of Phase-I of Silicon City of Amrapali in Sector 76,
Noida. Directions were issued to do the needful. We also directed to submit the proposal within one
week with respect to all the projects, which were incomplete. On 22.2.2018, the following order was
passed by this Court:
“Applications for impleadment(s) is/are allowed to the extent of intervention only.
IN W.P.Nos.160,91,164 of 2018 AND D. NO. 6636 OF 2018 Issue notice on the
petition as well as on the prayer for interim relief returnable within two weeks.
Dasti, in addition, is also permitted.
IN W.P.(C) Nos. 942/2017 AND 8 OF 2018 Heard learned senior counsel for the
parties.
Pursuant to the order passed on 21.02.2018, Mr. Ranjit Kumar, learned senior
counsel assisted by Mr. Gaurav Bhatia and Alok Aggarwal, appearing on behalf of the
promoters of Amrapali Group has produced a compilation ‘A’ before this court on
behalf of the said promotors disclosing the particulars of the on-going projects, stages
of the work vis-a-vis the towers involved, the likely time to complete the remaining
works and the cost of construction therefor.
Mr. Ranjit Kumar, learned senior counsel, has in particular drawn the attention of
this court at pages 4 & 5 of the compilation ‘A' which deal with 19 towers as
mentioned therein of Amrapali Leisure Valley Developers Pvt. Ltd. (Leisure Park). InBikram Chatterji vs Union Of India on 23 July, 2019

the chart, on these two pages of the compilation amongst others the number of units,
saleable area, the proposed/likely time to complete the finishing work, the total
balance amount payable by the home buyers and the total expenditure to be incurred
in completing the work, have been indicated. As this chart reveals the likely time to
complete the work and to deliver possession in accordance with the law, ranges from
3 to 15 months. According to the respondent, an amount of Rs.87.28 crores is
required to complete the finishing works in fairness as mentioned therein.
When enquired by this court as to the guarantee for the implementation of the
arrangements proposed for all practical purposes, Mr. Ranjit Kumar, on instructions,
has submitted that to ensure that the works are completed by the time as proposed 12
developers in addition to the Galaxy group have given their letters to collaborate with
the respondent promoters for the said purposes as testified by the documents
available in compilation ‘B’.
Learned counsel appearing for the home buyers, however, have expressed some
reservation contending that the arrangements as proposed do not inspire confidence
in view of the past experience and have pleaded that unless the 13 developers who
undertake to collaborate with promotors of Amrapali Group are tied down with
necessary conditions, the very executability of the project would be doubtful. To this
Mr. Ranjit Kumar, learned senior counsel has urged that adequate undertakings
would be given by the promoters of Amrapali Group as well as the other developers.
Having regard to the rival submissions made and the attendant facts and
circumstances and also considering the predominant interest of the home buyers, we
are of the view that it would be in the fitness of things to permit the promotors of
Amrapali Group to immediately start the finishing work as proposed in the units of
the towers as listed at pages 4 & 5 of Compilation ‘A' on the basis of the arrangements
as proposed.
In order to examine the bonafide of the proposal and the progress of the works that
would be achieved, list these matters on 27th March at 2 P.M. By then the promotors
of Amrapali Group would furnish to this court complete details of the proposals in all
respects made by the collaborators/developers and ensure completion of the
projects/finishing work as indicated in chart.
We part with the belief that the respondents-developers would be true to their
assurances to this court and also to the home buyers. Needless to say that all
promotors of Amrapali Group shall furnish their undertaking by 7th March 2018.
Further orders in this regard, as considered necessary, would be passed on the next
date i.e. on 27.03.2018.
In response to the prayer made on behalf of the developers that the insolvency proceedings before
the NCLT ought to be stayed, we on this stage leave the parties to make the appropriate prayer asBikram Chatterji vs Union Of India on 23 July, 2019

advised before the said Forum.”
10. Keeping in view the predominant interest of the home buyers, vide above order we directed the
Amrapali Group to complete the projects and the finishing work as assured, but it was not done as
apprehended by the home-buyers. This Court vide order dated 15.3.2018, directed to submit a joint
proposal with respect to providing project wise information of the stages of various building.
Thereafter, on 27.3.2018, learned senior counsel appearing for Amrapali Group stated that they are
ready to undertake the completion of the projects of Amrapali Group and we requested the I.R.P. of
Amrapali Group not to proceed any further, in view of the assurances given by the Amrapali Group
to undertake works. This Court on 10.5.2018 has passed an order for installation of lifts in the
Towers and also to make certain lifts functional. We also asked the promoters/ developers to submit
the statement of the total price of the flats, the total amount paid to the builder by the flat buyers,
the total amount spent by the builder on the construction and how the remaining part of the money
paid by buyers has been utilised. It also transpired from documents that money had been
transferred to certain other companies, thus, this Court has asked for the details of the composition
of the transferee company including the names of the Director and for what purpose money was
transferred and how it is to be retrieved and how projects are to be completed.
11. On 17.5.2018, this Court passed the following order:
“1. Heard learned counsel for the parties.
2. Pursuant to our request made to the learned counsel, they have sat together and a
joint statement has been filed for containing the proposal for completion of the
various projects. A joint meeting had been conducted between the lawyers
representing the buyers and builder of Amrapali Group and the representatives of
Greater Noida and Noida. The proposals are in the form of four baskets with
independent timelines and the co-developers had been chosen to undertake the
completion of the projects and remaining work at the site. The independent
proposals given by Amrapali along with the proposed co-developer had been placed
before the concerned lawyers representing the flat owners in those projects and
lawyers of Noida and the representatives of Greater Noida and broad consensus has
been reached.
3. The following are the basket-wise proposals:
FIRST BASKET I. SAPHIRE – PHASE-I IN NOIDA :
In relation to Saphire Phase-I, consisting of 1033 units, the time given is of 10+2
months for completion of the project.
II. SAPHIRE-PHASE-II :Bikram Chatterji vs Union Of India on 23 July, 2019

It consists of 1308 units and the time sought for completion of the project is 12 to 15
months.
The promoter of the Saphire Phase I & II projects is M/s. Amrapali Saphire
Developers Pvt. Ltd. The developer chosen by the promoter is M/s. Galaxy
Dreamhome Developers Pvt. Ltd. With respect to Saphire Phase II project, as agreed
to by the promoter, the relevant agreements entered into with co-developers to be
placed within one week. The documents shall be filed afresh, even if the same had
been filed earlier, duly supported by an affidavit. Let the undertaking of concerned
promoter/co-developer be also placed on record within seven days.
III. LEISURE PARK :
This project comprises of 2993 units. There are three categories of this project,
namely:
i) The first category comprises of the following 19 towers with 1665 units and the time
limit of 15 months is fixed :
1. E1 2. E2 3. E3 4&5. E4 (Two Towers)
6. B2 7. B3 8. B4 9. B5
10. A1 11. A2 12. A3 13. A4
14. A5 15. A6 16. F1 17. F2
18. F3 19. F4
ii) The second category comprises of 3 towers, i.e., towers C1, C2, and F5. There are
411 units and time limit, as agreed to for completion is up to 22 (twenty-two) months.
(iii) The third category (River view) comprises of 7 towers, i.e., D1 to D7. There are 917 units in this
category and time, as agreed to for completion is 29 (twenty-nine) months.
The co-developer of the first basket is M/s. Galaxy Dreamhome Developers Pvt. Ltd.
SECOND BASKET PRINCELY ESTATE :
The promoter of the project is M/s. Amrapali Princely Estates Pvt. Ltd. There are
1919 units. Out of these, minor work is required to be carried out in 1600 units,
possession of which have already been handed over to buyers and some work remains
in three other towers, being towers N, O and P, which comprise 319 units. Time
agreed for completion of same is 12 months and it has been proposed that M/s.Bikram Chatterji vs Union Of India on 23 July, 2019

Kanodia Business Pvt. Ltd. will be the co- developer.
It is also agreed to that as there is no water tank, no lift in three towers, i.e., N, O & P,
the work of water tank and lifts in these towers shall be completed within six months
from today.
As the inhabitants are already occupying certain portion up to the fifth floor, let
arrangements be made, as agreed to, for water tank on a priority basis. Adequate
provision for electricity connection shall also be made within three months from
today.
We defer the order with respect to Amrapali Silicon project, as agreed to.
THIRD BASKET Amrapali-the promoter has proposed certain projects in category-A,
namely, Zodiac, Platinum, Titanium and Eden Park in this basket.
The promoter of the Zodiac is M/s. Amrapali Zodiac Developers Pvt. Ltd., whereas
the promoter of Platinum and Titanium is M/s. Ultra Home Construction Pvt. Ltd.
and of Eden Park, the promoter is Amrapali Eden Park Developers Pvt. Ltd. The
following agreement has been reached with respect to the aforesaid category ‘A’
projects :
A.1. ZODIAC :
Zodiac comprises of 2230 units. It is agreed that the work in the said units shall be
completed within 12 months. The co-developer is M/s. India Infoline Limited (IIFL)
& M/s. Galaxy Dreamhome Developers Pvt. Ltd.
A.2. PLATINUM & TITANIUM :
(a) Platinum comprises of 888 units, and (b) Titanium comprises of 54 units. The
work in the said units shall be completed within 7 months. The codeveloper being
M/s. IIFL or M/s. Galaxy Dreamhome Developers Pvt. Ltd.
Let the requisite undertaking by the concerned promoter and co- developer be filed within seven
days in this Court. A.3. EDEN PARK :
Eden Park comprises of 316 units. The work shall be completed within 7 months. The
co-developer is M/s. Galaxy Dreamhome Developers Pvt. Ltd.
Let the promoter and co-developer to file a requisite undertaking within 7 days from
today.
CATEGORY B PROJECTS :Bikram Chatterji vs Union Of India on 23 July, 2019

The following are category ‘B’ projects :
B.1. CENTURIAN :
A. CENTURIAN PARK:
Centurian Park comprises of low rise 600 units. The work shall be completed within
10 months.
B. TERRACE HOMES :
Terrace Homes comprises of 3481 units. The work shall be completed within 21
months.
C. TROPICAL :
Tropical comprises of 1240 units. The work shall be completed within 30 months.
D. O-2 Valley :
O-2 Valley comprises of 800 units. The work shall be completed within 12 months.
The proposed promoter is M/s. Amrapali Centurian Park Pvt. Ltd. and co-developer
is M/s. IIFL.
It appears that earlier M/s. Sahi Developers Pvt. Ltd. was appointed as co-developer
under a Joint Development Agreement. There is some interse dispute with respect to
the work undertaken by the said codeveloper and the promoter. Be that as it may.
The co- developer M/s. Sahi Developers Pvt. Ltd. to file the details of the investment
made by it in the projects. Let the promoter also file a reply to the same and
appropriate orders would be passed by this Court with respect to the interest of M/s.
Sahi Developers Pvt. Ltd. However, we permit the new codeveloper M/s. IIFL to be
appointed for the said project so that owing to the interse dispute between the
promoter and co-developer, the project may not be delayed.
B.2. GOLF HOME :
This project consists of two parts : (i) Golf Homes; and (ii) Kingswood.
(i) Golf Homes :
Golf Homes consists of 4210 units. The work shall be completed within the period of
6 months to 22 months and possession shall be handed over as soon as the project is
completed.Bikram Chatterji vs Union Of India on 23 July, 2019

(ii) Kingswood :
Kingswood comprises of 1596 units. The work shall be completed within nine months
to 22 (twenty-two) months.
The promoter of Golf Homes and Kingswood projects is M/s. Amrapali Smart City
Developers Pvt. Ltd. and the co-developer is M/s. IIFL.
B.3. TECH PARK :
Tech Park project is located in Greater Noida. The promoter is M/s. Ultra Home
Construction Pvt. Ltd. and the co-developer is M/s. IIFL The work shall be completed
within the time limit of 18-24 months.
PROJECT COSMOS KOCHI :
In COSMOS KOCHI, the project at Kochi, the time limit for completion is fixed from
9 to 18 months. The promoter of the Vananchal ‘Kochi', the project is M/s. Ultra
Home Constructions Pvt. Ltd.
In VANANCHAL CITY, Ranchi project also, the promoter is M/s. Ultra Home
Constructions Pvt. Ltd.
The co-developer for both the Vananchal projects is M/s. IIFL.
FOURTH BASKET I. DREAM VALLEY :
The promoter of Dream Valley is Amrapali Dream Valley Pvt. Ltd.
This project comprises of Dream Valley Villa and Enchante, with respect to which
proposal has been filed.
a) Dream Valley (Villa): This project comprises of 379 units. The work shall be
completed within 6-15 months in a phase-wise manner.
b) Dream Valley-2 (High Rise): This project comprises of 8302 units.
The work shall be completed within 9-35 months.
c) Enchante: This project comprises of 1508 units. The work shall be completed in a phase-wise
manner within 42 months. The co-developer is M/s. Galaxy Dreamhome Developers Pvt. Ltd.
Requisite undertaking by the promoter and the co-developer shall be filed within seven days.
II. LEISURE VALLEY :Bikram Chatterji vs Union Of India on 23 July, 2019

a) Leisure Valley Villas – which comprises of 887 units, the work shall be completed
within 6-15 months.
b) Verona Heights & Jaura Heights – comprise of 4964 units and the work shall be
completed within 42 months.
c) Adarsh Awas Yojna - comprises of 1904 units and the work shall be completed
within 30 to 42 months.
The promoter of the projects is M/s. Amrapali Leisure Valley Pvt. Ltd. and the co-developer is M/s.
Galaxy Dreamhome Developers Pvt. Ltd.
III. HEARTBEAT CITY 1 & 2 :
a) In a Heartbeat City-1 project, the number of units is 759 plus shops. The time limit
is 10-18 months; and
b) In a Heartbeat City-2 project, the number of units is 1217 plus shops. The time
limit is from January 2020 to December 2020.
The promoters of these projects are M/s. Pebble Prolease Pvt. Ltd. and M/s. Three Platinum Softech
Pvt. Ltd. The co-developer is M/s. Galaxy Dreamhome Developers Pvt. Ltd.
The aforesaid period wherever fixed includes the period of mobilization and reflects the outer limit.
Let undertaking of promoter and developer be filed within seven days with respect to all the
projects.
4. It is apparent from the admission made by the promoter that the money to the extent of Rs.2765
crores, out of the six projects in question, has been transmitted to other projects. Though we were
inclined to direct the promoter to deposit the said amount in this Court, we are not doing this at this
juncture, because of the singular reason that the various promoters of the projects have shown their
willingness to complete these projects by engaging the services of the co-developer. It is made clear
that co-developer is the agent of the promoter. No right or interest shall accrue to the co- developer
and liability towards the buyer shall remain with the promoter.
5. At this stage, we deem it appropriate to direct that an escrow account has to be opened. The said
account has to be opened in the UCO Bank, Supreme Court Branch, situated in the premises itself.
At this juncture, we deem it appropriate to direct the promoters to deposit a sum of Rs.250/- crores
(Rupees Two Hundred Fifty Crores) in the said escrow account, and money shall be deposited on or
before 15th June 2018.
6. A proposal has also been submitted on behalf of the promoters of the aforesaid projects to sell
some of the unencumbered property, details of which have been given at page 28 of the affidavit
dated 16.5.2018. Out of the aforesaid proposal, we find that the properties mentioned at serialBikram Chatterji vs Union Of India on 23 July, 2019

numbers 11 and 15 are of high value. The unlaunched part of M/s. Amrapali Leisure Valley Pvt. Ltd.,
land of project is in Greater Noida, is held on the basis of the leasehold interest from the Greater
Noida Industrial Authority, the realizable value is shown to be is Rs.917.29 crores (Rupees Nine
Hundred Seventeen Crores Twenty Nine Lakhs). There is no bank loan but however, there appear to
be some dues to the Greater Noida Authority on this particular property. The distress sale value is
shown at Rs.491 crores (Rupees Four Hundred Ninety-One Crores). The property mentioned at
serial number 15 is a part of the unlaunched property of Amrapali Centurion Park (Commercial)
held on a leasehold basis from the Greater Noida Industrial Authority and its distress value is
Rs.246 crores (Rupees Two Hundred Forty- Six Crores).
7. There are some other commercial properties, which are in the form of hotels and other
commercial properties comprising of malls, etc. and those can also be sold for completion of
projects. As and when a concrete proposal is submitted before us for sale, the same shall be
considered and appropriate orders would be passed in this regard. However, the amount of Rs.250
crores (Rupees Two Hundred Fifty Crores) has to be deposited by 15th of June, 2018 without fail, in
the escrow account to be opened with the UCO Bank of this Court.
8. There are certain outstanding dues of the buyers. It would be open to the buyers to deposit the
said amount in the said escrow account. However, as soon as the projects are completed, we propose
to give them reasonable time to deposit the outstanding dues. As soon as the promoter and
co-developer are in a position to hand over the possession, the buyers shall have to deposit the
outstanding amount in the escrow account to be opened in the UCO Bank, within three months time
from the date of issuance of offer of possession.
9. We also propose to form a Committee to submit periodical reports of the progress of the
construction, to this Court, consisting of the following members:
i. Architect of the developer;
ii. Structural Engineer of the developer;
iii. Chartered Accountant appointed by the developer; as well as – iv. Architect of
buyers v. Structural Engineer of buyers vi. Chartered Accountant appointed by the
buyers and apart from the above members, we appoint Mr. M.L. Lahoty, learned
Advocate, as a member of the said Committee, so as to coordinate the effective
functioning and to submit an appropriate periodical report in this Court. We appoint
one nominee each of Greater Noida and Noida Authority, to be the member of said
Committee.
10. There are certain unsold units in the various projects that have to be firstly adjusted by making
swapping as agreed to, after that the remaining available units may also be permitted to be sold. In
this regard, a proposal would be submitted as and when swapping process is completed and the
details of property to be sold and amount of offer by the prospective buyers, be indicated by this
Court. The proposal will be submitted for consideration so that appropriate orders may be passed byBikram Chatterji vs Union Of India on 23 July, 2019

this Court. Let the Committee constituted by us also to supervise the swapping part.
11. Eight weeks’ time is granted to the buyers for the purpose of applying for swapping and decision
shall be taken within 15 days from the date of application for the purpose of swapping is filed before
the promoters. In case there is any difficulty in swapping, the Committee is authorized to take care
of the grievances and to guide the promoters as well as the buyers.
12. As there are certain dues of Noida and Greater Noida Authorities and that of the secured
creditors and operational/unsecured creditors, let the proposal be submitted by the promoters in
this regard, on or before 07.07.2018. We also place on record that approximately a sum of
Rs.4,300-4,900/- crores will be required for completion of the various projects as pointed out by
promoters.
13. There are certain ‘C’ category projects. With respect to those projects also, as they are not taken
care of during swapping or there may be certain buyers not willing for swapping or certain amount
may be required to be refunded to the buyers, who are not intending to purchase now and not opting
for swapping or/and is not feasible, to take up those projects. The promoter shall also file its
proposal with respect to such buyers who want their money to be refunded. Let that proposal be also
filed after swapping is done indicating therein as to how many persons require to refund the money.
The buyers in ‘C' category projects only who are intending to obtain a refund, may also submit their
proposal to the concerned promoter in the meantime, within one month from today.
14. The promoters with respect to Silicon Valley have applied for connection for electricity,
sewerage, and water, as per the order passed by this Court on 10.5.2018. The aforesaid order is
carried out punctually. The promoters of Silicon Valley has undertaken to make the payment of dues
onwards.
15. The joint statement that has been filed has been signed in the Court by the learned counsel for
the promoters as well as by learned counsel for the authorities and the flat buyers, is placed on
record and made part of this order as “Annexure-A”.
16. The aforesaid Committee constituted by us is also requested to evaluate the work undertaken by
M/s. Sahi Developers Pvt. Ltd. so far and submit a report in the 1 st week of July 2018.
17. Let nominations be made by the developers, flat buyers and authorities within seven days from
today, under intimation to this Court.
18. The matter has been heard in part and requires a further hearing. List on 18.7.2018 at 2.00 p.m.
19. It is agreed to, that with respect to essential amenities, the order passed by this Court on
10.5.2018 shall also apply to Silicon City Phase I project and in case inhabitants are there in some
towers, the same shall apply to Silicon City Phase-II project also.” The aforesaid order was passed on
the basis of the joint proposal, which was in the form of four baskets with independent timelines,
submitted in this Court.Bikram Chatterji vs Union Of India on 23 July, 2019

12. It was also mentioned in paragraph 4 of the above order that admission has been made by the
promoters/builders that the money to the extent of Rs.2,765 crores, out of six projects has been
transferred to other projects. Though we were inclined to direct the promoter to deposit the said
amount in this Court, we refrained from directing as the willingness to complete the projects was
shown by engaging services of co-developers and builder assured that it would undertake the work.
It was proposed to sell certain unencumbered properties of Amrapali Group for payment of these
projects, however, this Court directed to deposit an amount of Rs.250 crores in the escrow account
to be opened in the UCO Bank, Supreme Court Branch on or before 15.6.2018. This order was again
not complied with and the work was not undertaken and inability was shown to deposit the amount
in the escrow account as ordered. When the case was listed on 18.7.2018 in this Court, learned
counsel appearing on behalf of promoters was to place progress report, but in order to wriggle out of
the compliance of order, totally a different stand was taken in this Court and it was stated that a
notice dated 13.7.2018 has been issued by the Ministry of Housing and Urban Affairs, which was
placed on record, indicating that a High- Level Committee has been created by the Government of
U.P. to redress the issues of home buyers and the affected parties of incomplete/stalled house
projects in the Noida/ Greater Noida/Yamuna Expressway under the Chairmanship of Secretary,
Ministry of Housing and Urban Affairs. It was submitted on behalf of Amrapali Group that a
meeting was held today and prayed that something concrete is likely to happen within ten days. We
deferred the hearing up to 1.8.2018. However, at the same time, we directed the builder to file the
accounts with effect from 1.4.2008 till date under the certificate of Chartered Accountant and also a
list of all assets in a sealed cover in this Court. As a matter of fact, there was no compliance of the
order dated 17.5.2018 of this Court, but the totally indifferent stand was taken so as to wriggle out of
their obligation under said order was passed by this Court on the basis of the joint statement.
13. This Court has passed an order on 1.8.2018, wherein it was observed that in order to scuttle the
hearing in this Court, it was stated that the meeting was held on the very same day. The order
passed by this Court on 17.5.2018 to deposit Rs.250 crores had not been complied with. There was
also an admission made by Amrapali Group that there was a diversion of more than Rs.2,765 crores
from six projects. This Court observed that money could not have been diverted. That would prima
facie tantamount to a criminal breach of trust. We directed that the individual bank accounts of the
Directors of all the 40 companies be frozen and ordered attachment of the properties in the
individual names of Directors and also put a restriction on the alienation of the properties in the
names of individual Directors etc. Following order was passed by this Court:
"1. On 17.5.2018, we have passed a detailed order in these cases after hearing learned
counsel for the parties for several days. We need not reiterate the directions,
statements, representations made to this Court and the orders which we have passed.
Order dated 17.5.2018 is clear in this regard. As per the order passed by this Court,
certain obligations were imposed and certain directions were issued which were to be
complied with by the group of companies as well as the co-promoters, etc., as
mentioned in the aforesaid order. The compliance has not been reported an effort
was made to wriggle out of order passed on 17.5.2018.Bikram Chatterji vs Union Of India on 23 July, 2019

2. When the matter was taken up on 18.7.2018, compliance of the order was not
reported and on the other hand, a letter dated 13.7.2018 signed by Mr. Akhil Saxena,
Deputy Secretary to the Government of India, was placed on record. The letter is
extracted hereunder :
"No.D.17024...sic Government of India Ministry of Housing and Urban Affairs
Nirman Bhawan, New Delhi Dated July 13, 2018 Meeting Notice Subject: Meeting to
discuss the issues of homebuyers and affected parties of Noida/Greater
Noida/Yamuna Expressway scheduled to be held on 18.07.2018 at 11:00 A.M. - 1.00
P.M. - regarding.
The undersigned is directed to state that a High-Level Committee has been
constituted by the Government of UP to redress the issues of homebuyers and
affected parties of incomplete/stalled housing projects in the Noida/Greater Noida/
Yamuna Expressway under the Chairmanship of Secretary, Ministry of Housing and
Urban Affairs.
2. In this regard the Chairman of the Committee and Secretary MoUHUA will hold a
meeting with the developers/promoters (Amrapali Group Jaypee Infratech Limited,
Three C Group of Companies and Unitech Limited) on 18 July, 2018 at 11:00 A.M. -
1:00 PM in Room No.123-C, Conference Room, 1st Floor, Nirman Bhawan, New
Delhi. You are requested to kindly make it convenient to attend the meeting
personally. You may also bring the details of the housing projects promoted by your
company along with your specific plans as to how earliest you can deliver the
flats/houses to the home buyers who have made payments towards the same to your
company.
3. A line in confirmation on email, housingministry@gmail.com will be highly
appreciated.
Sd/-
(Akhil Saxena) Deputy Secretary to the Govt. of India Tel No.23062280 To
1. Shri Shiv Priya, ED, Amrapali Group, C-56/40 Sector-62, Noida-2301307.
2. Shri Nirmal Singh, Three C Group of Companies, Tech Boulevard Central Block,
Plot No.6, Sector 127, Noida-201307.
3. Shri Manoj Gaur, Jaypee Infratech Limited, Sector 128, Noida-201304 (U.P.),
India.
4. Dr. Ramesh Chandra, Chairman, Unitech Limited, 6, Community Centre, Saket,
New Delhi-110017.Bikram Chatterji vs Union Of India on 23 July, 2019

Copy to :
1. Sr.PPS to Secretary, Ministry of Housing and Urban Affairs.
2. PPS to Additional Secretary (Housing), Ministry of Housing and Urban Affairs.
3. PS to Economic Adviser (Housing), Ministry of Housing and Urban Affairs.
4. Deputy Secretary (Housing), MoHUA Sd/-
(Anil Saxena) Deputy Secretary to the Govt. of India Tel. No.23062280"
3. In order to scuttle the hearing in this Court on 18.7.2018 on which the case was listed, it was
reported to us that meeting was held on that very day which was presided over by the Secretary,
Ministry of Housing, who is the Chairperson of the Committee and Secretary MoUHUA. Thereafter,
pursuant to the said meeting it was stated today that NBCC India Limited, a Government of India
enterprise, has invited "Expression of Interest" for joint development in real estate with respect to
the development of residential and commercial real estate projects in Delhi and NCR region,
inclusive of the Amrapali Group for which we have already passed orders on 17.5.2018.
4. In case the Committee constituted by the Government of Uttar Pradesh wanted to take up the
matter of Amrapali Group in view of the order dated 17.5.2018, it was necessary for them to seek the
express permission from this Court, as this Court was in seisin of the matters, before transacting any
business in this regard. But that has not been done and when the order of this Court stands, it was
not at all appropriate or permissible to take up the matter by the Committee and intermeddle with
the order passed by this Court when the matter is pending in this Court. The action has a clear effect
on rendering order passed by this Court ineffective. In the circumstances, we deem it appropriate to
direct the presence of the Secretary to the Ministry of Housing and Urban Affairs and the Chairman
of the NBCC India Limited and to file their affidavit in this Court and produce entire record so as to
show how they have convened the meeting and acted in the manner in the matter pending in this
Court, without permission of this Court before dealing with the matter of Amrapali Group. Let them
be present before this Court tomorrow, i.e., on 2.8.2018, at 2.00 p.m. to explain their stand.
5. Mr. Anil Kumar Sharma, Chairman and Managing Director (CMD) of Amrapali Group of
Companies were personally present in this Court. He has stated that there are 40 companies in the
Amrapali Group of Companies. They are as follows:
1. Ultra Home Pvt. Ltd.
2. Amrapali Silicon City Pvt. Ltd.
3. Amrapali Zodiac Developer Pvt. Ltd.
4. Amrapali Sapphire Developer Pvt. Ltd.Bikram Chatterji vs Union Of India on 23 July, 2019

5. Amrapali Princely Estate Pvt. Ltd.
6. Amrapali Eden Park Developer Pvt. Ltd.
7. Amrapali Smart City Developer Pvt. Ltd.
8. Amrapali Smart City Pvt. Ltd.
9. Amrapali Leisure Valley Pvt. Ltd.
10. Amrapali Leisure Valley Developer Pvt. Ltd.
11. Amrapali Centurian Park Pvt. Ltd.
12. Amrapali Dream Valley Pvt. Ltd.
13. Amrapali Homes Project Pvt. Ltd.
14. Hi-Tech City Developer Pvt. Ltd.
15. Sangam Coloniger Pvt. Ltd.
16. Shalimar Coloniger Pvt. Ltd.
17. Amrapali Infrastructure Pvt. Ltd.
18. Amrapali Aerocity Pvt. Ltd.
19. Amrapali Mahi Developer Pvt. Ltd.
20. Amrapali Buddha Developer Pvt. Ltd.
21. Amrapali Hospitality Pvt. Ltd.
22. Amrapali Biotech Pvt. Ltd.
23. Amrapali Health Care Pvt. Ltd.
24. Amrapali Hospitality Pvt. Ltd.
25. Amrapali Power & Cement Pvt. Ltd.
26. Stunning Construction Co. Pvt. Ltd.Bikram Chatterji vs Union Of India on 23 July, 2019

27. Kapila Build Home Pvt. Ltd.
28. Gaurisuta Infrastructure Pvt. Ltd.
29. Gaurisuta Infra Solution Pvt. Ltd.
30. MSB Software Pvt. Ltd.
31. MVG Techno Consultant Pvt. Ltd.
32. Noida Text Fab Pvt. Ltd.
33. Navodya Properties Pvt. Ltd.
34. AHS Joint Venture
35. Amrapali Homes
36. Amrapali Grand
37. HIMS Pvt. Ltd.
38. Amrapali Spring Valley Pvt. Ltd.
39. Amrapali Patel Platinum
40. Amrapali Media Vision Pvt. Ltd.
6. The order passed by this Court of depositing 250 crores of rupees has not complied. There is an
admission already made by Amrapali Group that there was a diversion of more than 2765 crores of
rupees from six projects to other projects. In the circumstances, we direct the Bank accounts of all
the aforesaid 40 companies be frozen forthwith. We forthwith attach the entire immovable
properties of these 40 group of companies. They shall not be entitled to deal with the same in any
manner whatsoever without the express permission of this Court.
7. There was a diversion of the funds, prima facie it is apparent that when the money was paid by the
buyers for the purpose of investment in the particular project, it could not have been diverted. That
would prima facie tantamount to a criminal breach of trust. We are not expressing any final opinion
in this regard at this moment. However, at the same time, we propose to take a call on this after
hearing the parties on this aspect. However, so as to further ascertain the extent of internal and
external diversion from all the projects. The names of all the Chartered Accountants of all the
aforesaid 40 companies be disclosed to us and their reports from 2008 till today be placed on record
by tomorrow.Bikram Chatterji vs Union Of India on 23 July, 2019

8. The individual Bank accounts of the Directors of all the 40 companies are also freezed and they
shall not be entitled to operate the same with immediate effect. Let details of all Bank accounts be
furnished by tomorrow of companies and their Directors and of personal accounts of Directors. The
properties in the individual names of the Directors are also attached and the same shall not be
disposed of or alienated in any manner without the express order of this Court.
9. Let the matter be listed tomorrow, i.e., on 2.8.2018 at 2.00 p.m. Mr. Anil Kumar Sharma, Mr.
Shiv Priya and Mr. Ajay Kumar of Amrapali group of companies to remain personally present in this
Court tomorrow, along with the aforesaid officials.”
14. It was stated by Secretary, Ministry of Housing and Urban Affairs that he was not aware of the
order passed by this Court on 17.5.2018, appointing promoters and time frame and stated that he
never intended to violate the order passed by this Court. On 2.8.2018, we have recalled the order
dated 17.5.2018, considering the dubious and unfair conduct of the Amrapali Group of Companies
and on each and every day they have been shifting their stand. Earlier, they have filed affidavits
making certain representations and now want to wriggle out of it. Following order was passed on
2.8.2018, recalling the order dated 17.5.2018:
"1. Pursuant to the order passed yesterday, i.e., on 1.8.2018, Mr. Durga Shankar
Mishra, Secretary, Ministry of Housing and Urban Affairs, has stated that a
Committee has been constituted by the Government of Uttar Pradesh under his
chairmanship to look into the problems of three lakhs home buyers of Noida, Greater
Noida, and Yamuna Expressway. The Committee has been constituted so as to take a
policy decision so as to solve the problems of the home buyers. On 25.6.2018, the first
meeting of the then Chief Executive Officers (CEOs) of the Noida and Greater Noida,
real estate representatives, etc. was held and thereafter, second meeting was held on
10.7.2018, which was attended by 32 persons, inter alia including certain
representatives of the Flat Owners Welfare Association, Joint General Manager,
ICICI Bank, AGM of the Bank of Baroda, General Manager of HDFC Bank and
Chairman of CREDAI had also attended the meeting. Thereafter, no meeting of the
Committee has been held. However, a discussion with the Chairman of
representatives of the four builders, i.e., Amrapali Group, Jaypee Infratech Ltd.,
Three C Group and Unitech Limited was held on 18.7.2018, along with details of the
housing projects promoted by their companies and with the specific plans as to how
earliest they could deliver the flats/houses to the home buyers who have made
payments towards their companies. It was also stated by the Secretary that he was
not aware that this Court has passed an order on 17.5.2018 appointing promoters etc.
and the time frame within which the projects have to be completed. He has also
stated that he never intended to violate the orders passed by this Court. The
statement made by Mr. Mishra is placed on record.
2. It was also submitted that NBCC issued advertisement on 30.7.2018 and the
Chairman of the NBCC has informed us that the said advertisement was not issued
specifically for Amrapali Group of companies. Similar advertisements have beenBikram Chatterji vs Union Of India on 23 July, 2019

issued earlier too. However, it was stated by the Chairman that they are ready to
undertake the Amrapali Group projects and to complete them, after making the
detailed study of the stage and investment which is required to be made in the
projects that are incomplete.
3. Pursuant to the directions issued by the Court, Amrapali Group has placed on
record the account numbers and other details of 38 of Amrapali Group of companies
only, but not that of the personal accounts and the accounts in names of its Directors,
as per the order passed by this Court on 1.8.2018. They have furnished the details of
38 companies out of 40. They are contained in Annexures marked as X-1 and X-2.
4. We direct the Registry to apprise the concerned Banks along with the text of the
order and the account numbers so furnished. Let the copy of the order be sent to the
Banks for its due compliance.
5. It was stated that the personal Bank accounts in the names of the Directors of
aforesaid 40 companies are in the process of compilation and that the account
numbers shall be furnished to this Court by Monday, i.e., 6th August 2018. On the
account number being furnished, the Registry is directed to intimate the order to the
said Banks also regarding the order passed by this Court on 1.8.2018.
6. Two applications, i.e., I.A.Nos.82917/2018 and 92775/2018 in
W.P.(C)No.942/2017 have been filed by the Amrapali Silicon City Flat Owners
Welfare Society and Heartbeat City for modification of order dated 17.5.2018. It was
also pointed out that one of co- developer, IIFL, has backed out, thus, it was not
possible to comply with the order dated 17.5.2018 and same requires modification.
The sum of Rs.250 crores has also not been deposited. An application has been filed
so as to waive that requirement also. When we see the conduct of the promoter on the
various stages, it is apparent that on 18.7.2018 on behalf of the promoter it was stated
before us that the Committee has been constituted by the Government of Uttar
Pradesh under the Chairmanship of the Secretary, Ministry of Housing & Urban
Affairs, as such we should wait for the outcome of same. Yesterday, i.e., on 1.8.2018 it
was stated before us that NBCC is now considering to take over the entire project of
Amrapali Group as it has issued an advertisement for the purpose and as such the
Court should stay in our hands. In the circumstances, it is apparent that the Amrapali
Group does not intend to abide by order dated 17.5.2018 and its conduct is dubious.
Thus, we have no hesitation in recalling the order dated 17.5.2018 permitting
Amrapali Group to complete the projects. We hereby recall the order entrusting the
project to the Amrapali Group of companies for completion, along with
co-promoters, and we place it on record that the conduct of Amrapali Group of
companies is wholly unfair and on each and every date they have been shifting their
stand before us and it was absolutely improper on their part to do so. They have
violated our order also. They have earlier filed affidavits making certain
representations and now want to wriggle out of that. Be that as it may. We recall theBikram Chatterji vs Union Of India on 23 July, 2019

order dated 17.5.2018 under the aforesaid circumstances.
7. In the circumstances, as the Chairman of the NBCC is present before us and has
shown willingness to undertake the projects, the matter cannot be left at that. Let the
NBCC complete the projects, let it undertake the study and work out the details.
Though the time of 45 days was prayed, considering the urgency of the matter, we
grant 30 days' time, as the people are deprived of basic necessities of life, and they
are residing in some incomplete buildings. We appreciate the gesture of the
Chairman of NBCC, who has assured us to complete the projects as may be directed
and to submit a proposal in this Court within 30 days. Let a proposal be submitted in
30 days before us.
8. In the circumstances, we direct the promoters and also request Mr. M.L. Lahoty
and two other representatives to be nominated by home buyers to assist and submit
the details and all requisite documents to the Chairman, NBCC as also to the
Chairman of the Committee. Noida authority and Greater Noida authority shall also
furnish to them all the documents which are in their possession. Let promoter, Noida
authority, Greater Noida authority and buyers furnish all the documents/pleadings
they have submitted to this Court, within three days from today.
9. We also place on record the appreciation to the offer made by the Chairman,
NBCC, and also by Mr. Mishra, Chairman of the Committee. Let them make an
endeavour to form policy and to solve problems of other groups of companies also.
However, the matters are pending in the Court, they have to appraise this Court of
their proposals and only thereafter to take steps in this regard.
10. Mr. Anil Mittal, the Chartered Accountant of Anil Ajay & Company, who is the
statutory auditor for most of the companies, is present in the Court. Similarly, Mr.
Ravi Kapoor, the Chartered Accountant of Serva Associates is also present in the
Court. It is pointed out that the information furnished by them is contained on page 6
and 7 of the compilation Annexure X-1. It is stated by Mr. Anil Mittal that his
engagement as statutory auditor has begun in the year 2008 and continued up to
2015. He was the auditor from 2008 and has also stated before us that after 2015 no
papers have been given to him. It was stated by Mr. Gaurav Bhatia, learned counsel,
that at present S.N. Dhawan & Company is doing the audit of the Company.
11. Since we find that various documents have been placed on record indicating
transfer/diversion of the fund by the Amrapali Group itself, the Amrapali Group has
admitted that out of the six projects, there was transfer/diversion of Rs.2765 crores.
Though it was submitted that the amount was transferred to other projects, in our
opinion, this was clearly diversion of funds. The amount given by the home buyers for
the completion of their projects/houses could not have been diverted before the
completion of the projects. We request the auditors to find out how much money has
been so transmitted/diverted to other projects and how it has been used. LetBikram Chatterji vs Union Of India on 23 July, 2019

projectwise information of all projects be furnished. The Amrapali Group of
Companies shall furnish the requisite information and documents and shall
cooperate with the statutory auditors. Let the auditor certify how much money has
been diverted from which project and how it has been used in other projects,
including the projects of Heartbeat city. The internal auditor is requested to assist
Mr. Anil Mittal in this regard.
12. It was stated before us that the bank accounts of Amrapali Healthcare Pvt. Ltd.
have also been frozen and it is necessary to run the hospital to keep the accounts
operational. Considering the fact that the hospital requires money on a day-to-day
basis, we order de-freezing of account of Amrapali Healthcare Pvt. Ltd. only.
However, at the same time, we direct that let the details of the bank account(s) of it
be placed before us right from 2008 till date. Interim order dated 1.8.2018 to
continue unless otherwise ordered.
13. For the purpose of assessing the proposal to be submitted by the NBCC and to
pass requisite orders in this regard, we fix the hearing on 4.9.2018 at 2.00 p.m. Let
the aforesaid reports be submitted by Mr. Anil Mittal and Mr. Ravi Kapoor,
Chartered Accounts before 4.9.2018.
For further order of other IAs. and arrangement of funds to be provided to NBCC and
regarding furnishing of accounts, let matters be listed on 8.8.2018 at 2.00 p.m.
Personal presence of Secretary, Housing and Urban Affairs and Chairman, NBCC, is
dispensed with.”
15. There are various order sheets indicating how the wrong and incomplete
information had been submitted on behalf of Directors of Amrapali Group of
Companies.
16. The National Building Construction Corporation Ltd. had been appointed by this
Court to complete the construction vide order dated 12.9.2018.
17. Vide order dated 8.8.2018, this Court had directed the Directors of various
companies including the Managing Directors to file affidavits regarding immovable
properties and moveable properties and their valuation. We had earlier asked the
statutory auditors of Amrapali group of companies to conduct the audit. However, it
was pointed out on 4.9.2018 that there was the necessity of appointing independent
auditors so as to conduct a forensic audit. On 6.9.2018 this Court directed the
forensic audit. Following order was passed on 4.9.2018 :
"We have heard learned counsel for the parties. A proposal has been submitted by the
NBCC in the booklet form. Let it be placed on record along with an affidavit of a
responsible officer of the NBCC. Let a copy of the same be circulated to the learned
counsel appearing for the parties.Bikram Chatterji vs Union Of India on 23 July, 2019

Let Amrapali Group of Companies file a response to the NBCC’s proposal for
completion of the project.
We have heard Sh. Gaurav Bhatia about the property which can be sold. He has
attracted our attention to the affidavit of Shri Anil Kumar Sharma in terms of the
Court’s order 10.5.2018 filed with respect to I.A. No. 7366 of 2018 in W.P. No. 942 of
2017.
He has submitted that Saleable Area Commercial is described at page 20 of the
affidavit. The value is given as per the development model, not the Distress Sale
Value. Let Distress Sale Value be also stated on affidavit and with respect to the fact
that what are the encumbrances and also the dues of Noida/Greater Noida
Authorities as against the property as mentioned at page 20 of the affidavit.
He has also attracted our attention to the list of encumbered property on page 27 of
the affidavit and list of unencumbered property on page 28.
Let affidavit be filed specifically stating with respect to the nature and extent of
encumbrances with respect to encumbered property and how much is the amount
due and what are the documents executed.
With respect to list of the unencumbered property also mentioned at page 28 there
are certain dues of Noida/Greater Noida Authority that may be clearly specified and
let affidavit also specifically state that these properties are otherwise unencumbered
properties. Affidavit in detail be filed in this regard too.
With respect to the audit, the accounts for three years have not been made available
to statutory Auditor as pointed out by Mr. Anil Mittal of Anil Ajay & Co., appointed
by this Court.
Mr. Maninder Singh learned senior counsel has urged that there is the necessity of
appointing independent auditors so as to conduct a forensic audit. He has prayed for
time to suggest the names in this regard. It was also pointed out by the learned
counsel appearing for the Bank of Baroda that certain audit exercise has been
undertaken on behalf of the Bank of Baroda with respect to the transaction entered
into with Bank of Baroda which was the subject matter of other proceedings. Let the
names of Auditor be suggested so as to conduct a deep and pervasive forensic audit of
the Amrapali Group of Companies.
Suggestions be made on the next date of hearing.
Mr. Shyam Diwan and Mr. Siddharth Luthra learned senior counsel have pressed I.A.
Nos. 124711-124712 of 2018 and I.A. No. 36562 of 2018. These I.As are to be
considered after forensic Audit is concluded and a report is received.Bikram Chatterji vs Union Of India on 23 July, 2019

List on 6th September 2018."
18. This Court appointed Mr. Ravi Bhatia of M/s. Bhatia & Co. and Mr. Pawan Kumar Aggarwal of
M/s. Sharp & Tannan Company to conduct the forensic audit, which was ordered to be conducted
with effect from the year 2008 till date, to be completed within two months. On 12.9.2018, a list of
properties was submitted which was to be sold by the Debt Recovery Tribunal, Delhi, (DRT) and the
details of properties, title deeds and maps were to be submitted to the DRT. This Court directed
statutory Auditor, Mr. Anil Mittal, to hand over the original records of Amrapali group of companies
vide order dated 12.9.2018. This Court also directed remaining records from 2008 till date, be
handed over within 10 days. Amrapali group of companies were also directed to hand over the
documents required by the forensic auditors. The matter was taken up by this Court on 26.9.2018.
Considering the non-cooperation of the Directors, the following order was passed by this Court on
26.9.2018 :
“Heard the learned counsel for the parties.
It was pointed out by Mr. M.L.Lahoty, learned senior counsel that there are certain
existing Directors, namely, Mr. Anurag Sanghai, Mr.Vinay Vishal and Mr.Sankalp
Shukla, particulars of their properties, etc. have not been filed as ordered by this
Court and there are several other existing or former directors whose names have not
been disclosed. Let the names of all the directors be disclosed without remiss before
the next date fixed along with details of asset etc. as already ordered by this Court.
It was also pointed out by Mr. Lahoty in I.A. No.116688/2018 that ‘O’ 2 valley
particulars have not been disclosed by the group of companies. Let reply to the said
I.A be filed by the Amrapali Group of companies and details of ‘O’ 2 Valley be also
disclosed.
It was also pointed out that DRT has initiated the proceedings and has directed the
production of the original documents, sanctioned plans and other relevant
documents available with Amrapali Group of Companies. It was also submitted that
valuation has also been ordered. We direct the Amrapali Group of companies and the
Directors viz. Mr. Anil Kumar Sharma, Ms. Shiv Priya, and Mr.Ajay Kumar to submit
Maps clearly delineating an unencumbered portion of their properties and other
details which have been asked by the DRT. Let them be present before the DRT on
each and every date until and unless it is specifically dispensed with by the DRT. Let
the order of DRT be complied with by the Amrapali Group of the company before
4.10.2018.
With respect to the handing over the documents by the Statutory Auditors as well as
by the Amrapali Group of companies, we note it regrettably that order passed by this
Court has been violated and the documents have not been handed over in spite of
clear and categorical direction to hand over the documents to forensic auditors
within ten days. However, it was pointed out by Mr. Gaurav Bhatia, learned counselBikram Chatterji vs Union Of India on 23 July, 2019

that statutory auditors are going to hand over the document, etc. w.e.f. 2008 to 2015
by tomorrow to the forensic auditors. Let all the necessary documents which may be
in possession of Amrapali Group of companies in addition to statutory auditors be
also handed over from 2008-2015 and also all the papers of Amrapali Group of
companies 2015-2018 by tomorrow. We make it clear that the documents with
respect to 2015- 2018 shall be handed over by the Amrapali Group companies along
with all the original documents necessary to do audit shall be handed over to the
forensic auditors by tomorrow. Let account books in whatever status they are, at
present, be also handed over.
We request the forensic auditors to send their representative on the next date of
hearing to apprise us of compliance of this order.
Before IRB certain proceedings are pending for recovery of dues and inter alia, there
are dues of Bank of Maharashtra, etc also as pointed out including that of Bank of
Baroda.
Let the details of all the outstanding dues of secured and unsecured creditors
project-wise and in total be submitted in this Court in a tabular form. Let total
outstanding dues be stated, including that of Noida and Greater Noida authorities
supported by affidavit.
Mr. Anoop Kumar Mittal, Chairman of the NBCC and Ms. Pinky Anand, ASG are
present. It was pointed out on behalf of the NBCC that detailed project report has to
be prepared of Group A Project within 30 days and Group B and C Projects within 60
days. It was also pointed out that tenders may be permitted to be floated by NBCC
Group A and B projects. The NBCC is permitted to float the tenders and also to go
ahead with the preparation of the DPRs and also to submit detailed proposals, terms,
and conditions in this Court as prayed by them. Existing architects of Amrapali
Group of Companies to ensure cooperation with the NBCC. Non-cooperation shall be
viewed seriously by this Court.
Let DRT go ahead with the process of finding out the encumbrances. We also permit
the Bank of Maharashtra and all other such creditors who may have a charge on the
unencumbered property to state their claim before DRT.
Let reply be filed in IA No.139255/2018, 117300/2018,95140/2018, 135446/2018,
138400/2018.
All applications for impleadments to the extent of intervention are allowed.
List on 9.10.2018.”Bikram Chatterji vs Union Of India on 23 July, 2019

19. On 9.10.2018 when despite the orders dated 12.9.2018 and 26.9.2018, orders were not complied
with, records were not handed over and there was utter violation of orders passed by this Court, we
directed the Police to seize all the documents and to hand them over to the Forensic Auditors from
the possession of 46 companies and their Directors. We directed all the Directors to surrender their
passports and hand them over to the Police. The observations made by this Court were being
misused by Amrapali group of companies, "No coercive action will be taken by any authority with
respect to the building where completion is going on under the order passed by this Court". As
observed on 27.3.2018, we clarified that the observations did not deal with any police investigation
in any criminal case or in FIR which may have been registered with the Delhi Police, EOW, to make
investigation in any case which is required to be made. Police was free to make an investigation. On
10.10.2018 this Court directed the concerned police officers to seal all the seven premises situated at
Noida and Greater Noida. On 11.10.2018 certain directions were issued so as to facilitate the forensic
audit. After audit work was over for the day, on a prayer made by learned counsel on behalf of the
three Directors of Amrapali group of companies, they were permitted to stay overnight in Hotel Park
Ascent but they shall not be allowed any access to the mobile phone or the facility of
telecommunication without permission in writing of the police. This Court also directed issuance of
a formal notice on the suo moto contempt.
20. On 24.10.2018 the forensic auditors were present. They have disclosed as to diversion of funds
of more than Rs.100 crores to a firm known as GauriSuta Infrastructures Pvt. Ltd. in which Ashish
Jain and Vivek Mittal were the Directors. They are stated to be the relatives of the Statutory
Auditors. We directed the personal presence of Chander Wadhwa, CFO of Amrapali group of
companies on the next date. On 26.10.2018 the Forensic Auditors submitted an interim report. It
was pointed out that the tally data of 23 companies, reserves and surplus figures as appearing in the
tally data does not reconcile with the reserves and surplus as appearing in the last signed financials.
The difference has also been pointed out in a tabular form. There were several advances,
investments, utilisations, advances made to suppliers and payments made to Mr. Anil Sharma and
Mr. Shiv Priya, Directors of the company for professional charges, etc. It was also pointed out that in
spite of repeated reminders, groupings have not been supplied. Grouping is a process to indicate the
process between the stage of trial balance, balance sheet, and profit and loss account. All files had
not been handed over and Mr. Anil Mittal, the Statutory Auditor had sent one file late in the
evening. This Court ordered that in case documents were not handed over, the same shall be viewed
seriously and the incumbents punished suitably. The last opportunity was granted to hand over the
requisite documents to the Forensic Auditors. We directed Statutory Auditors to comply with the
requisition made by the Forensic Auditors. It was also noted by this Court that a sum of Rs.242.38
crores had been handed over to Gaurisuta Infrastructure Private Ltd., Vidhyashree Buildcon Private
Ltd., Mannat Buildcraft Private Ltd. This Court observed in para 5 thus :
“5. It has also been pointed out by Shri Pawan K. Aggarwal in his report that so far
with respect to four companies, namely, Gaurisuta Infrastructure Pvt. Ltd.,
Vidhyashree Buildcon Pvt. Ltd., Mannat Buildcraft Pvt. Ltd. And Jhamb Finance &
Leasing Pvt. Ltd., only it has been noticed that a sum of Rs.242.38 crores has been
handed over to them and in most of these firms Shri Ashish Jain and Shri Vivek
Mittal are the Directors. Beside, it was stated before us by Shri Anil Mittal, statutoryBikram Chatterji vs Union Of India on 23 July, 2019

auditor, that his nephew- Vivek Mittal joined as a Director on the request made by
Shri Chander Wadhwa, CFO, to create a company and he has in turn asked Shri
Ashish Jain, an employee of his client, to join as another Directory of at least 10
companies, created at the request of the CFO and Amrapali Group of Companies. It is
a shocking state of affairs that the statutory auditor himself was responsible for the
creation of companies in an aforesaid manner. Shri Anil Mittal has also stated before
us that he was aware that the money was flowing to the said companies through bank
statements. However, on a specific query made by this Court to him, he has admitted
that this fact of flow of money was not reflected in the audit report, which was signed
by him in the audited Balance Sheet, in spite of knowing the fact that money has
flown out of the accounts of the Amrapali Group of Companies to aforesaid
companies."
About the creation of companies consisting of his nephew as Director on the request
made by Mr. Chander Wadhwa, CFO for asking Ashish Jain, an employee of his
client, to join as another Director. The Company agreed at the request of the CFO and
Amrapali group of companies.
21. Since the CFO did not reply to the questions put by the Forensic Auditors to him, his conduct has
been noted by this Court thus:
"6. We regretfully also note the conduct of the CFO, who is personally present before
us today. His questions and answers have been placed on record by Shri Pavan K.
Aggarwal, Forensic Auditor, along with his report and today we find that Shri
Chander Wadhwa has contradicted his version which he had made to the Forensic
Auditor. He has apologized for making wrong statements to the Forensic Auditor and
has assured us that in future he will render all cooperation to the Forensic Auditors
rightly, honestly and diligently. He has admitted today that there was appointment
order as CFO and there was an authorization in writing issued to him for dealing with
the banks. He has virtually contradicted the entire statement which he had made and
has feigned ignorance to the Forensic Auditors. Be that as it may. We give him the
last opportunity to come out clean and live up to the reputation of a profession of a
Chartered Accountant. Let him cooperate with the Forensic Auditors, supply entire
information correctly, truly and diligently. In case any remiss is found, it is made
clear not only to him but also to the statutory/internal auditors that we will be
compelled to take appropriate action as against them in the aforesaid factual
situation, including the one for the professional misconduct."
22. It was further pointed out by the forensic auditors that there were 23 more groups of companies
to whom money had been diverted and these companies had been created by Amrapali group of
companies. This Court directed disclosure of these companies in the order dated 26.10.2018 thus:
"7. Shri Pavan K. Aggarwal has also pointed out to us that there are 23 groups of
companies to whom the money has been diverted and these companies have beenBikram Chatterji vs Union Of India on 23 July, 2019

created. Let the names of the companies be disclosed to the Amrapali Group of
Companies and we direct the police to seize all the documents of these 23 companies
to which money has been diverted and be handed over to the Forensic Auditors.
9. We also direct the Directors of other 23 companies, which have been identified so
far by the Forensic Auditors, to file their detailed affidavits in this Court, disclosing
the amount received by them, dates of receipt, for what purpose and how it is utilized
and invested by them.”
23. We had also directed Mr. Chander Wadhwa, CFO to file affidavit pointing out appointment
order, authorisation, authority to sign any voucher and his entire role in the organisation thus:
"13. Let Shri Chander Wadhwa, CFO, file his affidavit in this Court placing the
appointment order; authorization made to him from time to time; his authorization
letters; details of attendance, if any, at the Board meetings; authority to sign any
voucher; and his entire role which he has performed in the organization. Besides, it
was also stated by Shri Chander Wadhwa, CFO, that he was one of the Directors of
the Amrapali Development UK Ltd. and Saffron LLP, Delhi. Let the details of the
Articles of Association of these companies be placed on record and the present
composition of the Directors and the entire transactions be disclosed on affidavit,
along with the documents of these companies and returns, if any, which have been
filed, be also handed over to the Forensic Auditors and affidavit be filed in this Court
in this regard.
14. It was also stated by Shri Chander Wadhwa that his nephew is one of the
Directors in M/s. Rinku Computech, one of the shareholders of the Amrapali Biotech
India Pvt. Ltd. His disclosure on affidavit be also made by Shri Chander Wadhwa."
24. We also issued other directions to ensure that laptops and computers were made available to
forensic auditors. On 31.10.2018 this Court noted that certain transactions of Amrapali group to
Zodiac/J.P. Morgan, Mauritius/Singapore by the creation of various companies. We directed the
bank statement of J.P. Morgan from 2008 till date to be filed. With respect to the money received
from the Indian companies and in particular from Amrapali group of companies, all monetary
transactions of J.P. Morgan, Mauritius and Singapore with Amrapali group of companies be
disclosed with details on affidavit. We directed the Amrapali group of companies/statutory auditors
as well as Anil Mittal, Ravi Kapoor and S.N. Dhawan and CFO to disclose the names of all the
companies in which their family members or acquaintance were included as Director and all the
transactions inter alia family members and relatives. It was also pointed out by Mr. Chander
Wadhwa, CFO that though his salary was Rs.15,000 per month, a car worth Rs.43 lakhs was given to
him by the company in lieu of his services. It was also pointed out that an amount of Rs.2 crores has
been paid on account of Chander Wadhwa’s tax liability by Amrapali group of companies. Further
directions were also issued to make the disclosures. This Court has noted the conduct of
non-compliance of the order vide order dated 13.11.2018 thus:Bikram Chatterji vs Union Of India on 23 July, 2019

“4. This Court has drawn suo moto contempt on 12.10.2018 and that is listed on
20.11.2018. In spite of the aforesaid observation made in the order dated 26.10.2018,
still there is gross disobedience of the directions issued by this Court and in the
affidavit filed in compliance of the order dated 26.10.2018, the various disclosures as
ordered have not been made. Besides that, there is a failure to hand over to the
forensic auditors, the relevant material as pointed out by them.
5. The names of all the related companies have also not been disclosed with which the
transactions have taken place. No such statement has been made categorically in
terms of the order passed by this Court on 31.10.2018 and absolutely vague
averments have been made. This tantamount to deliberate noncompliance of the
orders of this Court despite several opportunities having been granted.
7. An affidavit has also been filed by Mr. Anil Sharma of Amrapali Group of
Companies in which names of the companies which were ordered to be disclosed
have not been disclosed and no statement has been made as ordered on 31.10.2018. It
is a gross violation of the orders passed by this Court. There are certain averments in
the affidavit which shows that certain properties have been sub-leased, out of Dream
Valley, Centurian Park, Amrapali Leisure Valley. The subleases have been created.
Full disclosures have not been made as to subleasing since earlier affidavits were
contrary to it, it was shown as unencumbered property. we direct the Directors of
Amrapali Group of Companies to disclose entire transaction and relevant documents
as well as Greater Noida Authorities to file the documents about sub-leases, who is
holding the land as on today, its considerations, how it has been used, how much
consideration was received and where the amount is lying, and the sub-lease deeds be
also placed on record. We order that there shall not be any further alienation of the
sub-leased property by anyone.
8. Statements of various bank accounts have also not been furnished besides other
particulars. Learned counsel has again surprisingly prayed for three weeks’ further
time to furnish the details though sufficient time had been given. No direction is
being complied with. The Directors are filing the affidavit on each and every date
making improvement as the forensic audit progresses. They are not making full
disclosures and concealing the facts and have not mentioned in the affidavit what
they are ordered to do. It is clear that they are obstructing the course of justice to the
best of their ability. This state of affairs cannot be continued any further. For
non-compliance of the directions issued from time to time, we have already drawn
suo moto contempt and as subsequent orders have also been violated. For the
purpose of taking the contempt proceedings to further logical end, before this Court
passes any further order, we give an opportunity to the Amrapali Group of
Companies and Directors to furnish their reply as to why they should not be punished
for the contempt and the violation of the order passed by this Court from time to time
by November 19, 2018. The case will be taken up for considering non-Bikram Chatterji vs Union Of India on 23 July, 2019

compliance of the order and for filing the wrong affidavits before this Court, on 20.11.2018 along
with the suo moto contempt that has been registered vide order dated 12.10.2018.
9. We have two affidavits. One of Anil Mittal and another of Chander Wadhwa. Both are passing
liability on each other for creating certain additional companies. None want to own the
responsibility. We require Amrapali Group of Companies and their Directors to file a reply to the
affidavit, filed by their CFO Chander Wadhwa and Anil Mittal. Let the copies of affidavits of Chander
Wadhwa and Anil Mittal be furnished to the Advocate on Record, Amrapali Group of Companies.
Let para-wise and point-wise reply be submitted as to what has transpired in the Court, as recorded
in order-sheets, including what they have stated in their affidavits.
12. It was also pointed out that Computech Pvt Ltd. is in possession of a substantial amount. The
forensic auditors are in the process of examining the details. However, at this juncture pursuant to
findings of forensic auditors, it was pointed out by Mr. Vikas Singh, learned counsel appearing on
behalf of Chander Wadhwa, CFO that a sum of Rs.7.58 crore from Rinku Computech Private
Limited and Rs.4.1 crore is lying with Chander Wadhwa, said amount is out of the transactions with
the Amrapali Group of Companies. He has volunteered to deposit the amount within three weeks
from today. Let it be deposited in the account opened with the Registrar of this court, within three
weeks.
14. From the forensic auditors' report, it is prima facie clear that Amrapali Healthcare Private
Limited, as pointed out in Annexure 11 is created out of funds belonging to the Amrapali group. That
is extracted hereunder:
Annexure-11 Amrapali Healthcare Private Limited (As per Audited financials
2015-16) Details of Asset (Figures in crore) Sl. No. Asset Book value Address
1. Land 0.53 Amrapali Hospital P2, NH-34 Omega 1, Greater Noida, Uttar
Pradesh-201310
2. Building 4.43 Amrapali Hospital P2, NH-34 Omega 1, Greater Noida, Uttar
Pradesh-201310 Date of transaction Area (sq. meters)-
Constructed area-
Sl. No. Shareholder’ % holding No. of shares Name
1. Ultra Home 99.89 % 93,85,260 Constructions Private Limited
2. Swapnil 0.03 % 2500 Shikha
3. Suvash 0.08% 7500 Chandra Kumar Total 100 % 93,95,260 * In FY 2016-17 the shares of Ultra
Homes Construction Pvt. Ltd. are transferred in the name of Gaurisuta Infrastructure Pvt. Ltd.Bikram Chatterji vs Union Of India on 23 July, 2019

Details of Inter Corporate Deposits                     (figures in crore)
     Sl. No.   Name of company        Amount
     1.        Ultra Home             5.36
               Construction
               Private Limited
     2.        Others                 0.32
List of Present Directors
     Sl. No.   Name                        Begin Date
     1.        Swapnil Shikha              27/11/2012
     2.        Suvash Chandra              27/11/2012
               Kumar
It has also been pointed out that this hospital is, in fact, owned to the extent of 99.89 percent by
Ultra Home Constructions Pvt Ltd. and funding has been made by the said company. It is one of the
companies out of the Amrapali Group of Companies involved in the case. Thus, it is apparent that
this property has to be sold as it has been purchased out of money of buyers, in order to make
available the money for the construction of the buildings.
17. It is a case where we find ourselves in a situation that the money of Greater Noida and Noida
Authorities has not been paid, buyers have also been duped. Other financial institutions have not
been paid. Construction has not been completed. Money paid by buyers has been diverted for the
creation of various companies and assets have been created. All these assets are accountable and
have to be sold as it is not the independent investment made by these directors. It is a patent and
blatant fraud which appears to have been played, the way in which the money has been transacted
and creation of companies has taken place in connivance with the CFO, statutory auditors. It was
also pointed out that there are various related companies in which money has been transferred. We
restrain all monetary transactions out of bank accounts or any kind of alienation of the property
held by the related group of companies where the money has been siphoned and has been used for
the creation of the assets. Any transfer made in any manner shall be illegal, void and inoperative.
20. It is also necessary in order to find out the actual amount invested in building activities, out of
the funds collected. It also appears that certain companies were created only for the purpose of
purchasing raw materials. Whether actual transactions of purchase have taken place is required to
be ascertained. Let all the vouchers of the purchase, Bills, orders, etc., which are in possession of
Amrapali Group of Companies and the estimates of various raw materials for each and every
building without which construction of a building is not possible to be undertaken to be positively
handed over to the forensic auditors within a week. We also request the forensic auditors to propose
how the actual valuation of the buildings constructed so far by the Amrapali Group of Companies on
the spot can be made so as to ascertain the actual investments made and extent of diversion. Let the
estimate and quantities of the bills be also furnished by Amrapali Group to the forensic auditors
along with the names of all the suppliers and mode of payment. They may also collect
information/documents from suppliers."Bikram Chatterji vs Union Of India on 23 July, 2019

Certain directions were also issued to DRT to make the valuation to sell the property. Other facts
were also noted.
25. On 20.11.2018 this Court had noted non-compliance of various orders passed by this Court from
time to time. Various sub-leases had also been created. We issued the directions vide order dated
20.11.2018 as under:
"3. It appears that various sub-lessees have been created. It was informed to us by the
learned senior counsel appearing on behalf of the Amrapali Group of Companies that
certain structures have been raised by the sub-lessees. We have asked them to
disclose all the information on affidavit, but the order still remains uncomplied.
Various directions in this regard have been issued in paragraph 7 of the order dated
13.11.2018. There are various other directions issued time to time also and
compliance thereof is still wanting, though time fixed is over.
4. In the circumstances, we give one last opportunity to the Amrapali Group of
Companies, particularly to all the Directors of the company and also those who have
filed a reply in the Suo Motu Contempt. They have to file their further affidavits in
compliance with the aforesaid directions as to what they have done and to make the
disclosure as envisaged in various orders.” We had also directed that any
non-cooperation with the Forensic Auditors shall be viewed seriously. Statements of
accounts of banks were also ordered to be issued by the banks. In order dated
5.12.2018 this Court observed that let the Amrapali group of companies and their
Directors Mr. Chander Wadhwa, CFO and Mr. Anil Mittal to explain as to why
criminal action be not initiated against them on the basis of affidavits, various
documents and the statements made in this Court on various dates and why their
conduct as projected in the case be not reported to the ICAI to inquire. We directed
the production of details of immovable properties as well as the movables etc. This
Court also noted that DRT has pointed out that there was non-cooperation and
non-compliance on the part of Amrapali group of companies. It was also pointed out
to this Court that certain buyers/companies who have booked the flats by making
payment of a paltry amount for the purchase of several flats/plots, did not appear to
be genuine buyers. We have directed the Forensic Auditors to look into this issue. We
also directed all the Directors of companies, their relatives, family members,
Mr.Chander Wadhwa, CFO and statutory auditors who were in receipt of money of
home buyers, to deposit the same in this Court. The last opportunity was given to do
so.
26. On 12.12.2018 in para 4 we have observed thus:
"4. Pursuant to our order dated 05.12.2018, Mr. Adhikari Devi Prasad, Mr. Bhuvan
Pant, Mr. Prasanna Kumar Rout, Mr. Jagannath Sharma, Mr. Tarun Kumar Sharma,
and Mr. Sunil Kumar and also Mr. Anil Sharma, Director, Amrapali Group of
Companies are present in the Court. We generally asked them how the accounts forBikram Chatterji vs Union Of India on 23 July, 2019

the period 2015 to 2018 were prepared by them and submitted in the Court. They
have stated that it was based on tally data which was given to them. In addition,
Mr.Prasanna Kumar Rout, who worked as an Accountant with Amrapali Sapphire,
stated that he made the entries up to August 2018 in the tally data on the basis of the
documents/vouchers which were made available to him. Mr.Jagannath Sharma, who
is a Chartered Accountant and partner in L.D.R. Company stated that they have
prepared the balance sheet on the basis of the tally data provided to them for the
years 2015 to 2018. However, when cross-checked with the Forensic Auditors, the
Court was informed that the data from 2015 to 2018 has not been made available
fully to them. It was also pointed out that there should be supporting
documents/material to make these entries other than the Bank statement when these
statements have been prepared that should also be clarified by Amrapali Group and
supplied to the Forensic Auditors.” We also directed details of unsold apartments and
flats of the projects to be submitted in this Court. It was also pointed out that the
methodology has been adopted by creating sub-leases as a mode of siphoning off the
amount of the buyers. This Court noted the following facts and issued the requisite
directions:
“8. Mr. Lahoty, the learned counsel, also pointed out that the methodology which has
been adopted for creating the subleases was, by and large, a mode of siphoning the
amount. He has given the following details as Annexure E, which is extracted below:-
“CREATION OF SUB-LEASES I. Amrapali Centurian Park: (Current Status: 228646
Sq. Mts.) As per the lease deed, Lessor here is Greater Noida Authority
1. Lessee here is Amrapali Centurian Park Pvt Ltd (Total Area – 2,72,916 Sq Mts)
2. Sub- Lessee of Amrapali Centurian Park here are:
o Hawelia Builders Pvt. Ltd (Hawelia Valenova Park – 14920 Sq Mts) o DSD Homes
Pvt Ltd (Novena Green – 14760 Sq Mts) • In DSD Homes, Mr. Nishant Mukul
(brother in law of Chairman Mr. Anil Sharma) Ex-Director of Amrapali Group was
also a director. o Elegant Infracon Pvt Ltd (Elegant Villa Phase I, III, & IV - 14590 Sq
Mts) • In the Elegant Infracon following are consortium partners with shareholding:
Vidhyashree Buildcon Pvt Ltd (26%) Nishant Creation Pvt Ltd (19%) Anjali Buildcon
Pvt Ltd (20%) Agrawal Associates (Promoters) Ltd (5%) Elegant Infracon Pvt Ltd
(19%) Stunning Construction Pvt Ltd (11%) • Vidhyashree Buildcon is one of the
companies as mentioned in an order dated 26.10.2018 page 13, point 5, to whom sum
of Rs.242.38 crores has been handed over. Mr. Pankaj Jain (current director of
Amrapali Group) was also a director in Vidhyashree Buildcon Pvt Ltd.
• Sushma Bajaj & Kulbhushan Bajaj (Current directors of Amrapali Group) are also
directors in Nishant Creation Pvt Ltd.Bikram Chatterji vs Union Of India on 23 July, 2019

• Mukesh Kumar Roy (DIN: 2175661) who is presently director of Amrapali Group (listed in 46
companies LA Residentia) is also director of Anjali Buildcon.
• In Anjali Buildcon Mr. Sanjiv Kumar (DIN: 03136323) is also one of the directors, who is the
director of New Tech La Palacia to whom Shri Balaji Hi-Tech Construction Pvt Ltd (A sublessee of
Amrapali Dream Valley) has further transferred the sub-lease of said project. • Stunning
construction is one of the Amrapali Group Company listed in 46 companies.
• Rs 46 Crs (Approx) amount which is to be paid by sublessee/s II. Amrapali Dream Valley: (Current
Status: 260307) As per the lease deed, Lessor here is Greater Noida Authority.
1. Lessee here is Amrapali Dream Valley Pvt Ltd (Total Area – 354298 Sq Mts)
2. Sub- Lessee of Amrapali Dream Valley Pvt Ltd here are:
o M/s Shri Balaji Hi-Tech Construction Pvt Ltd (Total Are – 12479 Sq Mts) o M/s
K.V. Developers Pvt Ltd (Total Area – 19986 Sq Mts) o M/s J.M. Housing Ltd (Total
Area – 33537 Sq Mts) o M/s Samridhi Reality Homes Pvt Ltd (Total Area – 27989) o
Sum Total Area is 93991 Sq Mts • Shri Balaji Hi-Tech Construction Pvt Ltd one of
Amrapali Group company (Sr.53 Page 2913 of an affidavit by Mr. Anil Sharma as
Affidavit Submitted in terms of order dated 26.09.2018, 31.10.2018. submitted on
12.11.2018, where Mr. Ajay Kumar & Mr. Mukesh Kumar Roy were directors.
• Shri Balaji Hi-Tech Construction Pvt Ltd has further transferred the sub-lease to a new company
namely New Tech La Palacia Pvt. Ltd, which has applied for a revised sanction plan dated
21.01.2013 and it's not yet approved. (page 18 of GNOIDA affidavit) • In New Tech La Palacia
Mr.Sanjiv Kumar (DIN: 03136323) is a director who is also a director of Anjali Buildcon (one of the
shareholders of Elegant Infracon Pvt. Ltd. who is sub-lessee of Amrapali Centurian Park. • Rs. 91.89
Crs (Approx) amount which is to be paid by sublessee/s III. Leisure Valley: (Current Status:
396124.20 Sq. Mts As per the lease deed, Lessor here is Greater Noida Authority.
1. Lessee here is Amrapali Leisure Valley Pvt Ltd (Total Area – 419519.20 Sq. Mts.)
2. Sub- Lessee of Amrapali Leisure Valley Pvt Ltd here are:
a. M/s Start Landcraft Pvt. Ltd. (Total Are – 23395 Sq Mts) Rs.3.2 Crs. (Approx)
amount which is to be paid by sublessee/s”
9. We have directed Mr. Anil Sharma, Director of Amrapali Group of Companies and
other Directors to explain the sub-leases and place the documents regarding the
creation of subleases on record. Mr. Anil Sharma stated before us that approximately
a sum of Rs.66 Crores has been received by the creation of these sub-leases and that
amount has been accounted for in the accounts of concerned Amrapali Group of
Companies. With respect to the money utilization in an aforesaid manner,Bikram Chatterji vs Union Of India on 23 July, 2019

companies, names of Directors, relationship and activity made by sub-
lessee so far, let details be filed on an affidavit. We also request the Forensic Auditors to look into
this aspect and submit a report before us on the next date of hearing along with other aspects
mentioned in the above-quoted details filed on behalf of the flat buyers."
27. The directions were also issued to DRT to make a further valuation of Tech Park (Hotel) in
Greater Noida. On 25.1.2019 we issued certain directions. On 11.2.2019 we directed M/s. J.P.
Morgan to disclose the names of the investors and beneficiaries who invested in the Mauritius Fund
which had invested in Amrapali INR Rs.85 crores. On 14.2.2019, dues were pointed out against
individuals and Directors also. Against Directors there was a report of loans and advances to the
extent of Rs.161.51 crores as noted in the order. We issued certain directions with respect to M/s.
Golf Link City Projects Private Ltd. as well as M/s. Royal Golf Link City Projects Pvt. Ltd. We
directed Mr. Anil Kumar Sharma to deposit an amount; whereas the non-compliance made by
Amrapali was also pointed out by the buyers which had been noted. As inability was expressed on
behalf of M/s. J.P. Morgan to explain valuation report dated 23.10.2013 submitted by Mr. Sudit K.
Parikh & Co., Chartered Accountants, they were ordered to explain the valuation report on the basis
of which Rs.140 crores had been withdrawn by M/s. J.P. Morgan. It was also pointed out in this
connection that the shares of Amrapali Zodiac were ultimately purchased for Rs.140 crores by M/s.
Neelkanth and M/s. Rudraksha Forensic auditors pointed out that two persons namely Chandan
Kumar, is a peon of Mr. Anil Mittal, statutory auditor and was working in his office and one is Vivek
Mittal, nephew of Mr. Anil Mittal, who was doing petty jobs of sub-contractors, getting a monthly
income of Rs.15,000. They were stated to be Directors in the companies, i.e., M/s. Neelkanth and
Rudraksha. They were not having any capacity to give Rs.140 crores to M/s. J.P. Morgan. This Court
has noted the facts thus:
“As inability was expressed on behalf of M/s. J.P. Morgan as well as other counsel to
explain the report dated 23.10.2013 submitted by Mr. Sudit K. Parikh & Co.,
Chartered Accountants. In the circumstances, so as to find out the basis of the
valuation, it is necessary to call Mr. Sudit K. Parikh [Address : Ballard House, 2nd
Floor, Adi Marzban Path, Ballard Pier, Fort, Mumbai – 400 001] to explain the
valuation report on the basis of which Rs. 140 crores had been withdrawn by M/s.
J.P. Morgan. Let the Registry send a communication to Mr. Sudit K. Parikh to appear
before this Court on the next date of hearing.
It was pointed out that shares of Amrapali Zodiac were ultimately purchased for
Rs.140 crores by M/s Neelkanth and M/s Rudraksha. It is pointed out by forensic
auditors that there are two persons, namely, Chandan Kumar, who is a peon of Mr.
Anil Mittal, Statutory Auditor, and working in his office and another one is Vivek
Mittal, who is the nephew of Mr. Anil Mittal, and is doing petty jobs of sub-
contractors and having a monthly income of Rs.15,000/-. It is stated by the learned
counsel appearing on behalf of M/s J.P. Morgan that in one company, Chandan
Kumar and Atul Mittal were Directors. M/s Neelkanth and M/s Rudraksha are the
private limited companies in which the abovementioned persons are named asBikram Chatterji vs Union Of India on 23 July, 2019

Directors. They are not having the capacity to give an amount of Rs,140 Crores to be
paid to M/s J.P. Morgan.
This is a serious kind of fraud apparent from the aforesaid facts. On being asked, Mr.
Anil Kumar Sharma has shown reluctance to disclose about Atul Mittal, who was the
Director of M/s Rudraksha along with Chandan Kumar. It is apparent that it was not
a fair transaction of sale. That fact is required to be gone into. Let Mr. Anil Mittal and
Directors of Amrapali Zodiac and Mr. Anil Sharma explain the situation by filing
their personal affidavits from where the money came to be paid to M/s J.P. Morgan,
who managed the money and how the companies were framed and for what
purpose."
28. On 28.2.2019, this Court considered IA No.35430/2019 filed by Deputy
Commissioner of Police, EOW, Delhi Police, seeking permission to take into custody
various Directors namely Anil Kumar Sharma, Shiv Priya, and Ajay Kumar. This
Court has passed the following order:
This application has been filed by the Deputy Commissioner of Police, Economic
Offences Wing, Delhi Police, seeking permission to arrest and take into custody
various Directors, namely, Anil Kumar Sharma, Shiv Priya, and Ajay Kumar. They are
presently in the custody of Noida Police vide our order dated 11.10.2018. We make it
clear that the Delhi Police is free to arrest/take into custody any or all the other
Directors of Amrapali group of companies. Any order passed by this Court, in this
case, shall not come in their way to do so.
Let the Police investigate the entire gamut of the scenario of the various projects, as
projected in this case and various orders passed and investigate the entire matter.
Prima facie, we find that the case requires serious investigation in the facts projected
by the Directors, CFO, and the statutory auditors.
The Police are directed to investigate the role of Mr. Anil Mittal, Statutory Auditor,
and Mr. Chander Wadhwa, CFO as well. The Police may interrogate them and find
out their criminality, if any, in the matter.
Let various order sheets of this Court as well as the affidavits of Mr. Chander
Wadhwa and Mr.Anil Mittal and Directors of Amrapali Group of Companies
indicating the operational methods of diversion of funds and creation of companies
be also furnished to the Deputy Commissioner forthwith.
The application is allowed.” This Court also issued other directions with respect to
the persons who were called by the Forensic Auditors but did not report. Other
directions were also issued.Bikram Chatterji vs Union Of India on 23 July, 2019

29. On 9.4.2019 we requested the parties to address this Court how to protect the
interests of the buyers so that they can get a clear title after completion of the
projects. In view of the dues of Noida and Greater Noida authorities and other
secured creditors, such as banks, etc. how to work out equities in the circumstances
and requested the parties to address this Court. Amrapali group of companies to
address how much investment they have made in the project and what they have
done with the money of the buyers and to inform us as to diversion of the money of
home-buyers, how to secure it and why they should not be suitably dealt with in
accordance with law for what they have done. In view of the aforesaid facts projected
in various affidavits of the Directors and the interim report of forensic auditors. This
Court listed the case for hearing on various issues. We have heard Forensic Auditors,
Mr. Krishnan Venugopal, learned senior counsel and Mr. M.L. Lahoty, learned
counsel, on 30.4.2019. Thereafter, we further heard the matter on 1.5.2019. They
concluded the arguments. Mr. C.A. Sundaram learned senior counsel was also heard
and the learned counsel on behalf of Bank of Maharashtra and Bank of Baroda as well
as Ms. Geeta Luthra and Mr. Gaurav Bhatia, learned senior counsel on behalf of
Amrapali group. On 2.5.2019 and on 8.5.2019 certain directions were issued. On
10.5.2019 arguments were further heard and the case was reserved for orders.
SUBMISSIONS
30. Mr. M.L. Lahoty, learned counsel appearing on behalf of 49,575 home buyers submitted that
under section 8 of the Real Estate Regulation and Development Act, 2016 (for short, ‘the RERA’)
and also in view of the provisions contained in sections 13 and 14 of the U.P. Industrial Area
Development Act, 1976 (for short, ‘the Industrial Development Act’), the lease deeds granted by
Noida and Greater Noida authorities were ordered to be cancelled. In the lease deed also, there is a
specific stipulation as to cancellation clause in case of cancellation and imposing penalty and for
such other actions against the builder in case of default. Home buyers further submitted that after
payment of first 10% of the lease premium, Amrapali Group has not paid any of the 20 half-yearly
instalments from 2010 onwards. The Noida and Greater Noida authorities have been liberal, and
not taking any stringent action against Amrapali Group which had been mandated by virtue of the
provisions contained in the lease deed. The dues of Noida and Greater Noida authorities cannot be
treated at par with the dues of home buyers. Home buyers further submitted that so far as the dues
of the banks are concerned, they are not placed on any better footing and Forensic Auditors in their
report have stated that but for the connivance of the bank officials, the act of money siphoning on
such large scale would not have taken place. Banks have failed to monitor utilisation of the
borrowed funds and they acted as mute spectators to the diversion of funds by Amrapali Group of
Companies, its Directors and officials. Mr. Lahoty, on behalf of home buyers further submitted that
the Reserve Bank of India has issued Master Circulars from time to time since 2014 onwards as to
the obligations of the Banks and specifically directed that banks must necessarily monitor the ‘end
use' of the loans granted by them and call for periodical reports thereof. In the case of diversion and
siphoning of loan funds, banks must invariably take action against defaulters. Reliance has been
placed on RBI's Master Circulars of July 2009, 2014 and 2015. In case after the cancellation of the
leases, they are not able to construct, they may enter into an arrangement with any reputed builderBikram Chatterji vs Union Of India on 23 July, 2019

like NBCC or L&T, etc. A roadmap thereof need be drawn to be monitored by a Monitoring
Committee which duly represents the interest of the home buyers, may also be directed to be
constituted which will not only oversee the work but also oversee the construction activities and also
submit a report to this Court so that the needs of the home-buyers are finally achieved. A further
audit of connected companies may be ordered. Bank accounts with Bank of Baroda are
operationalised towards maintenance and electricity as families are residing in 21 Towers have been
regularly depositing the electricity and other dues in their accounts which have become defunct after
the discharge of IRP vide order dated 8.8.2018 passed by this Court. The amount be utilised for
pending bills from August to October 2018 towards electricity and maintenance services by
nominating a Joint Signatory in place of IRP.
31. Mr. Krishnan Venugopal, learned senior counsel appearing for home- buyers has urged that
there is the distinction between mortgage and charge as a mortgage involves the transfer of interest,
whereas, in case of a charge, there is no transfer of interest. He has further urged that non-
production of relevant documents despite the court order, leads to a presumption of an adverse
inference. As Amrapali Group has failed to comply with the court's order, an adverse inference may
be drawn against them. He has also pressed into service public trust doctrine and submitted that the
State or the public authority which holds the property for the public or which has been assigned the
duty of grant of largesse, etc. acts as a trustee, and therefore, has to act fairly and reasonably,
promote public good and public interest. Public trust doctrine is a part of the law of the land. The
doctrine is a facet of Article 21 of the Constitution. The action has to be bona fide. Public property
cannot be transferred to private property in case it affects the public interest. General welfare and
common good are to be kept in view by the public authorities exercising public power and
discharging public duty.
32. Mr. Krishnan Venugopal, learned senior counsel further urged that in view of the findings
recorded by the Forensic Auditors, section 8 of the RERA has to be invoked. He further submitted
that even though Amrapali was defaulting on payments of lease rents, authorities continued to allot
further plots to them. The first lease had been granted on 1.5.2007 and the last on 30.7.2010.
Despite default, they continued to issue permission to mortgage/NOCs for that purpose between
24.12.2009 and 27.2.2013, in spite of the fact that there was no payment of premium and advance
annual lease rent up to date. The authorities have acted in breach of clause 7 of the conditions of the
lease deed, they failed to monitor the progress of the project to protect the interest of the public.
33. In reference to banks, Mr. Venugopal submitted that banks were giving loans to finance
Amrapali, in spite of the fact that they were diverted to other accounts and not utilised for
construction. Banks do not even have effective mortgages because of NOCs. clearly, state that they
would become effective only when Amrapali makes up to date payment of the premium and advance
annual lease rent, and under the conditional NOCs., the banks were required to obtain confirmation
from the authorities as to payment of premium and lease money for the mortgage to become
effective. The banks have not handed over copies of mortgage deeds despite orders. Moreover, the
banks have a second charge after all dues of the Noida and Greater Noida authorities are realised.
The authority's ownership rights over the plots are paramount. The public sector banks are also
subject to public trust doctrine to the extent that they are custodians of public funds and areBikram Chatterji vs Union Of India on 23 July, 2019

beneficiaries of the Banking Companies (Acquisition and Transfer of Undertaking) Act, 1970 and
Banking Companies (Acquisition and Transfer of Undertaking) Act, 1980 passed in pursuance of the
Directive Principles under Article 39(b) and (c) of the Constitution. The facts demonstrate the
collusion between Amrapali Authorities and the banks. The home buyers who invested their
hard-earned money, cannot be cheated and deprived of their money as well as their houses.
Authorities cannot seek to recover any additional amount from the home buyers. They must be
directed to complete the construction by realising only the remaining dues from home buyers under
their agreements with Amrapali, by selling off unsold inventory of flats, etc. available with it and by
selling off excess land allotted to Amrapali. The Committees of home buyers must be set up for each
project to monitor the quality and progress of the construction as well as the costs involved so as to
ensure that contractors do not engage in fraud or inflate construction costs in the course of
completing the projects.
34. On behalf of the home buyers Association, it was submitted that by promoters of the real estate
sector in India from 2008-2009, home buyers have been promised the houses of which they have
been deprived of on a large scale in spite of the fact that they have paid a substantial amount of
money. Construction has not progressed and money has been diverted elsewhere. There is a charge
of the money of the home buyers must be treated as the highest priority. They have paid towards
dues of Authorities also which amount has been diverted. Banks and authorities have failed to
discharge their duties. Banks have granted loans to the projects in some cases which were not
sanctioned even on the date of grant of loan. For example, Phase III of Amrapali Adarsh Awas
Yojana Project. Banks have released the complete payment amounts to the builder without the
construction having been reached even 10 to 20%. As such lending was not permissible. The current
scenario is that the construction of the various projects is stalled and the home buyers are without
any hope of the promised homes. Certain incumbents who have taken loan are compelled to repay
the loan and money has been siphoned out. As such appropriate relief be granted to home buyers in
view of the facts found in the report of the Forensic Auditors.
35. On behalf of the home buyers, reliance has been placed on the provisions contained in section
4(5) of the U.P. Apartments (Promotion of Construction, Ownership, and Maintenance) Act, 2010
(for short, the ‘U.P. Apartments Act, 2010’). It is provided that the completion of the construction
works of a building as a whole or the completion of an independent block of such building, as the
case may be. The completion certificate can be issued for the blocks which have been completed.
Noida and Greater Noida authorities are not issuing NOC for the reason that payment of land dues
has not been made by the builder, for which authorities are also responsible. The non-payment of
dues by the builder should not come in the way as more than 9000 home buyers are already residing
in the buildings. Most of them have paid the entire amount to the promoter. Others are waiting for
the completion of buildings.
36. On behalf of Noida Authority, learned senior counsel submitted that public trust doctrine is not
attracted to the facts in the instant case as there is no breach of trust. The decision to transfer lease
at 10% was the carefully thought out policy of Noida approved by the State Government. It was
applied uniformly to all and not restricted only to the Amrapali Group. It was submitted that
allotment of group housing plots is made by Noida authority in accordance with the prevailingBikram Chatterji vs Union Of India on 23 July, 2019

policies and rates which have kept changing with times. In 2007, the allottees were required to pay
10% of the total premium of the plot as reservation money, before formal allotment letter was
issued. Then, a further amount of 30% had to be paid within 60 days from the time of allotment.
Thus, 40% premium was required to be paid. Balance 60% had to be paid in eight half-yearly
instalments along with interest.
37. It was further submitted on behalf of the Noida Authority that primarily on account of the global
recession in the world economy, in the year 2008 a decision was taken to revise the rate of allotment
money to 10%. Thus, the total sum of 20% was to be paid before handing over possession. In the
year 2009, the rate of allotment money along with registration money was revised to 10% of the
total premium for the possession to be handed over. However, steps were taken to provide (i) facility
of re-scheduling of payments in case the allottees intended to complete his project as per agreed
policy; (ii) to exit the project; (iii) moratorium of two years on payment of balance premium; (iv)
facility of sub-division of plots of area larger than 10 acres so as to make the larger projects
financially viable.
38. It was also submitted on behalf of Noida Authority that after 2005, a total of 114 plots had been
allotted to various group housing societies. 81 have been handed over the possession on payment of
10% of the total premium. 29 projects, out of these 81, have been completed. Out of other 33 allotted
earlier, 11 had been completed, and 7 have obtained part- completion certificates. Noida Authority,
being a responsible public organisation, has been diligent in pursuing Amrapali Group, it has not
taken the drastic recourse of terminating the lease deed as that would entail demolition of the
existing structures as per the provisions of the lease deed. In terms of the lease, home buyers have
no title or legal rights to possession of the flats they are occupying. As the projects have been
completed to some extent, it would have been unfair to leave the home buyers in the lurch. The
occupancy certificate is issued in accordance with the provisions of the New Okhla Industrial
Development Area Building Regulations, 2010 (for short, ‘the Regulations of 2010’). Clause 20.0 of
the Building Regulations requires the allottee to submit a notice of completion of the building, inter
alia, with a structural safety certificate, NOCs from the Fire Department, Explosives department and
Environment department. No building erected, re-erected, can be occupied in whole or in part
unless occupancy certificate is issued by the CEO of the Authority as per clause 20.1.1 of the
Regulations. The lessee/promoter is entitled to allot the dwelling unit on a sub-lease basis. However,
he has to make the payment of premium of the plot to Noida authority when permission to transfer
built-up flats or part with possession of the whole or any part of the building which has been
constructed is granted. The physical possession of flats can be given to home buyers only after
execution of sub-lease deed and sale deed has also to be registered before actual physical possession
of the flat is handed over as required under the provisions of Registration Act, 1908. The declaration
required to be made under section 12 of the U.P. Apartments Act, 2010 is also to be filed.
39. It was further urged on behalf of the Noida Authority that the Noida Authority had the first
charge including those created in favour of banks and financial institutions. The mortgage could
have been effected in favour of Banks/financial institutions recognised by the RBI, National
Housing Bank, HUDCO, New Delhi and the charge of such institution shall be the second charge on
the dwelling units, thus, being financed. The permission to mortgage shall be effective only onBikram Chatterji vs Union Of India on 23 July, 2019

making full payment of premium and up to date annual lease rent of group housing society. An
intimation shall be given to the Authority about the creation of the charge by way of mortgage. The
mortgage permission shall be granted as per the terms of the lease only on payment of dues of
authorities.
40. It is submitted that it is open to the authority to cancel or terminate the lease. In the case of
misrepresentation, suppression or violation of the conditions of lease and in the case of default and
at the time of cancellation, an amount equivalent to 25% of the total premium of the plot shall have
to be forfeited and possession of plot shall have to be resumed by Noida Authority with structure
thereon. In the instant case, no dues certificate had not been issued by the Noida authority nor any
sub-lease deed has been executed. The possession by various home buyers in respect of constructed
flats is contrary to the provisions of the lease deed. The builder could not have handed over the
possession. Any occupation of flats by the home buyers without compliance of mandatory provision
of occupancy certificate and without payment of statutory dues, both to Noida Authority and to the
Collector of Stamps and without execution of tripartite sub-lease deed may not be termed as legal
and as such which could have resulted in their eventual eviction.
41. It was further submitted on behalf of the Noida Authority that pursuant to order dated
27.11.2017 passed by this Court, on depositing 10% of the dues to issue completion certificate such
NOC could not be issued and the order passed by this Court has not been complied with by
builder/promoter as such possession could not be handed over. In spite of reiterating the aforesaid
direction of this Court on 31.1.2018, it has not been complied with by the promoter/leaseholder. It is
submitted by the Noida Authority that its dues to Amrapali group exceed Rs.2191.38 crores till
30.4.2019. It is in public interest to ensure payment of premium/lease money with penal interest
etc. so that the development of the various projects at Noida is not impeded. Prayer has been made
that in whatever manner practicable and by whatever scheme this Court may think fit and proper,
aforesaid dues of the authority may be secured and ordered to be recovered.
42. On behalf of Greater Noida Industrial Development Authority, it was submitted that its dues
were Rs.3,234.71 crores as on 15.1.2019 in respect of 5 group housing plots of Amrapali group. These
dues inter alia comprise of the amounts payable against the premium plus the penal interest for
default, additional compensation and interest thereon, the lease rent and interest thereon and time
extension charges for each of the five plots. Title in the flats can pass only by way of execution of a
registered instrument. However, before that procedural requirements pointed out on behalf of the
Noida Authority have to be complied with. Once completion certificate is issued, the rights in the flat
will pass on to the flat buyers and then they would contend that the dues of the authority should be
recovered from the builders who have defaulted in making payment and not the flat buyers. On the
basis of that privity of contract, they would contend that the liability to make payment of the
premium and other dues payable to Greater Noida authority, by lessee/builder is between them and
they are not parties to the lease deed.
43. It is further submitted on behalf of Greater Noida Authority that even with regard to the
issuance of completion certificate for a part of the projects, the existing policy is that against the
part-payment received, completion certificate would be issued in the same proportion minus 10%,Bikram Chatterji vs Union Of India on 23 July, 2019

so that the financial interest of the authority is protected. Therefore, sub- lease deeds too would be
executed up to 90% of the proportion in which part-payment has been received. It was further
submitted by the Greater Noida Authority that section 19(10) of RERA also provides for taking over
of physical possession after issuance of completion certificate. The provisions of the U.P.
Apartments Act, 2010 are also similar as well the provisions in the lease deed.
44. It is further submitted on behalf of Greater Noida Authority that FAR admissible is 02.75 only
and not 3.50. The differential FAR of 0.75 is not purchasable. The calculations made by Amrapali
based on FAR of 3.50 is itself wrong. FAR has not yet been purchased by Amrapali group by
depositing the charges and submission of consent of two-thirds of the apartment owners. Under
section 4(2)(1)(D) of RERA, 70% of the amount received from home buyers is to be put in a separate
account to be maintained in a scheduled bank and is to be used towards construction and land cost.
The land dues payable to Greater Noida authority constitute an encumbrance as provided in section
4(1)(b) of the U.P. Apartments Act, 2010. As per section 11(4)(c) of RERA, it is the duty of the
promoters to certify that all dues and charges have been paid. Thus, it follows that money received
from the flat buyers is to be spent on construction and payment of land dues. Therefore, payment of
land dues cannot be denied to it. Land dues are in the nature of public money. Amrapali group is
bound to pay it. The amount is payable in instalments as such same is interest bearing for availing
the facility of payment in instalments as such the land cost payable increases. In case of default,
penal interest follows. There was no order passed by the Allahabad High Court for staying
construction on the leased plots. Amrapali Group was in possession of the allotted land and was
proceeding with the construction. For 4 years, it has prayed for zero periods of interest to which the
group is not entitled. It would lead to unjust enrichment by Amrapali as they have realised dues
from home buyers and have not paid to the Authority. The order passed by the NGT with respect to
Okhla Bird Sanctuary case was not applicable to the land in question. The dues payable to the
authority are recoverable as the arrears of land revenue. The authority has the first charge. The
permission to the mortgage was conditional one, it has not been complied with, in particular,
conditions B, C and D. The mortgage had to be renewed every year and is subject to the payment of
land premium, etc. The Greater Noida authority has written numerous letters to Amrapali group of
companies to make the payment of its dues. In the case of Unitech, yet another Group, the Authority
has cancelled the allotment which was questioned in this Court. As the cancellation of the allotment
in case of Amrapali could have led to greater complications as construction had commenced with
third-party interest created. It would have opened floodgates to litigation. As such cancellation of
lease deeds was not resorted to.
45. Ms. Geeta Luthra and Mr. Gaurav Bhatia, learned senior counsel appearing on behalf of
Amrapali group of companies, have urged that Amrapali group started its activities in the name of
M/s. Ultra Home Construction Pvt. Ltd. in the year 2003 with the purpose of providing low- cost
housing to projects in Indirapuram (Ghaziabad) Noida, Lucknow, Indore, Bhilai, and more than
15,000 flats were handed over by the developers to flat owners in 5 different housing projects in
Indirapuram and Greater Noida. The balance sheets of Amrapali group of companies at 2007-08
shows that it had carried forward the money earned by the company to launch the projects after
2009-10 upon allotment of plots by Noida and Greater Noida authorities in their respective areas.
Immediately after the allotment of land, the work was started and the Allahabad High CourtBikram Chatterji vs Union Of India on 23 July, 2019

quashed acquisition. It had to be stopped as per the order passed by the Allahabad High Court.
When in 2016 Amrapali group again started to infuse capital and manpower, proceedings were
initiated in NCLT by Bank of Baroda as against Amrapali Silicon City Pvt. Ltd. and M/s. Ultra-Home
Constructions Pvt. Ltd. There were legal impediments/force majeure conditions in completing the
projects within the period given in the flat buyer agreement. The Allahabad High Court finally
decided the matter in Gajraj Singh & Ors. v. State of U.P. on 21.10.2011. The Patwari Village issue
was pending before this Court till 2015. On 14.5.2015 this Court finally decided the matter in the
case of Savitri Devi v. State of U.P. It was an order passed by the National Green Tribunal with
respect to Okhla Bird Sanctuary which also hindered the work. Higher compensation was ordered to
be paid by the Allahabad High Court in 2011. The period of litigation ought to have been treated as
zero periods for the purpose of payment of dues by Noida and Greater Noida authorities. Amrapali
Silicon City was affected on account of litigation and land acquisition issues. The work of Leisure
Valley, Dream Valley, and Leisure Park were also affected. There was an issue of the approach road
with the farmers with respect to Sapphire Housing Project. Other projects were also affected due to
farmers' agitation, want of proper roads, etc. The authority was required to give electricity, sewer
and water connections. Proper facilities were not extended timely.
46. It was further submitted on behalf of Amrapali Group that a High- Power Committee has been
constituted by the State of U.P. A sum of Rs. 2,715 crores are to be paid to the authorities including
the interest and purchasable FSI costs. The outstanding of banks is Rs.985 crores. It was submitted
that the projects are viable in case some relief is granted towards land dues of authorities and dues
of the banks. The joint inspection indicated that substantial construction had been carried out. The
cost of construction to complete the launched projects, as per NBCC is Rs.6827 crores; whereas the
cost as per Amrapali group is Rs.5630 crores. Calculation of NBCC is wrong. The projects are
divided into 3 categories: (i) where the allottees were living; (ii) advanced stage of construction; and
(iii) work is at a nascent stage. The amount defaulted by buyers is Rs.511 crores, total receivables
from them are Rs.5,332 crores. The encumbered and unencumbered assets can be sold to complete
the project. The valuation worked out by the DRT comes to Rs.7,353 crores considering the
maximum permissible FAR of 3.50. The order may be passed in respect of amounts due from Raipur
and Bhubaneswar Housing Board which are recoverable from them to deposit in Court. Certain
suggestions have also been made on behalf of Amrapali group for arranging the required funds. That
home buyer may be directed to pay the cost. Unsold inventory of the launched projects on sale
would generate Rs.1,922 crores. In case of any shortfall, there can be a sale of unencumbered assets
of the company. Reputed builders may be engaged for undertaking the construction of the various
projects. Amrapali has spent Rs.10,630 crores as against Rs.11,652 crores received from home
buyers. As per the affidavits dated 16.5.2018 and 3.12.2018, the total cash outflow is Rs.395 crores
utilised by the group in the creation of assets whose current valuation as per DRT is Rs.1200 crores.
The Noida and Greater Noida authorities have partial registration policies as provided in Building
Regulations and the Act and an appropriate Committee may be constituted for supervision.
Amrapali group shall extend all help in the building of the projects.
47. With respect to the report of the Forensic Auditors, it has been submitted that there is no
undervaluation in booking the flats. The value of flats depends upon the situation etc. as the flats
were booked at different times, they have different prices as per the prevailing market. In certainBikram Chatterji vs Union Of India on 23 July, 2019

cases, the customers took possession of various Towers in partially unfinished conditions and
managed the pending work by themselves. In some projects, lifts were installed by the customers'
associations. In some other cases, interiors of the flats were finalised by the customers themselves.
Amrapali group reduced the value of such flats in their books accordingly.
48. With respect to other amounts recoverable from KMPA/relatives/Directors, as per the affidavit
submitted by Shiv Priya on 20.11.2018, Rs.4.3 crores were paid towards his taxes. The same has
been adjusted against the salary due of Rs.4.4 crores from various Amrapali group of companies.
Salary of Rs.1.6 crores is recoverable by Shiv Priya from Amrapali group of companies. As per the
affidavit of Mr. Ajay Kumar, Rs.1.21 crores were paid by the company towards his taxes out of his
outstanding salary up to 31.3.2015. Though his salary for the financial years 2016-18 is still to be
mentioned in the books of accounts on account of his due salary. A sum of Rs.25 lakhs has been paid
by him to Ultra Home Construction Pvt. Ltd.; in addition, a sum of Rs.25 lakhs paid to Yogesh
Chand is duly debited in his ledger and as mentioned in his affidavit.
49. With respect to Amrapali Infrastructure Pvt. Ltd., it was submitted that an advance to Directors
of Rs.113.54 crores was used by the Directors to purchase shares of Ultra Home Construction Pvt.
Ltd. Ideally, the shares should have been issued in the name of Amrapali Infrastructure Pvt. Ltd.
The money moved from Amrapali Infrastructures Pvt. Ltd. to Ultra Home Construction Pvt. Ltd.
Precast Factory’s valuation is Rs.179 crores. Mr. Anil Kumar Sharma has surrendered the shares in
favour of Amrapali Infrastructure Pvt. Ltd. to the extent of INR 73.2 crores. Mr. Shiv Priya has
surrendered the shares in Amrapali Infrastructure Pt. Ltd. during 2018-19 of Rs.35.1 crores.
50. With respect to Amrapali Hospitality Services Pvt. Ltd., it was submitted that the company gave
Rs.6.62 crores to Directors as advances out of which Rs.6.55 crores were given to Mr. Anil Kumar
Sharma and his family. In the financial year 2017-18, Rs.2.25 crores were used by Mr. Anil Kumar
Sharma for payment of housing loan of Jay Pee Green Property. Rs.1.25 crores were deposited with
this Court by way of Demand Draft, Rs.0.85 crores were paid to settle the bank loan of Leisure
Valley Villa and Rs.0.5 crores were transferred for payment of TDS liability of Amrapali hospital.
51. With respect to Hi-Tech City Developers Pvt. Ltd., the Auditor's report indicates that a sum of
Rs.4.24 crores was given as an advance to Mr. Anil Kumar Sharma in 2009-10 which was used by
him for purchasing shares of Ultra Home Construction Pvt. Ltd. Ideally, the shares should have been
issued in the name of Amrapali group of companies. No transfer of money was there. Mr. Anil
Kumar Sharma had surrendered shares in favour of Amrapali Infrastructure Pvt. Ltd., during the
year 2018-19 but this has not been reflected in the books of the company. With respect to cash in
hand, there is no consistency in the report of the auditors. Only Rs.9 crores were available in cash in
various group companies. The entire amount was spent on payment of wages due to various labours
at different times. With respect to other recoverable advanced to various parties amounting to
Rs.234.31 crores, the details are not available in the report. These advances are against genuine
business transactions. There is a possibility that such expenses have not been booked and squared
off.Bikram Chatterji vs Union Of India on 23 July, 2019

52. With respect to the diversion of home buyers amount to the extent of Rs.3,500 crores and bogus
billing of Rs.1500-1600 crores, out of the total amount received from home buyers of Rs.11,652
crores would leave INR 6,652 crores for carrying out the existing construction at sites. The total sum
available for construction purposes comes to Rs.4,352 crores, after deducting the amount of
payment to the authorities and banks of Rs.1,000 crores and Rs.1,300 crores respectively. With
respect to non-genuine purchases from suppliers, though a sum of Rs.554 crores was given to the
income-tax authorities, on appeal the error had been corrected by the income-tax authorities. There
was an error in the report of the forensic auditors. The report of the forensic auditors as to
non-existing companies is also not correct. It is further submitted that Gaurisuta Infrasolution Pvt.
Ltd., which manufactures PVC doors and windows had business transactions with Amrapali group,
payment/advances were made to them. It is a fact that parties are related. It does not mean that all
transactions are dubious. Law does not prevent such transactions. The short term and long-term
loans to third parties were not for diverting loan funds and home buyer funds to group companies.
53. With respect to Auditors’ list of 27 companies formed for the purpose of routing the cash of the
companies, were formed before demonetisation. With respect to J.P. Morgan Property Mauritius
Company-II, Amrapali Zodiac Developers Pvt. Ltd. transferred money to another company to buy-
back stake in J.P. Morgan but did not do it directly as share buy-back rules did not permit such
transactions. It may be maximum violations of the Companies Act but is not a diversion of money.
With respect to FEMA, it is submitted that again it is a violation of ECB guidelines but again it was
not a case of diversion of money. Money was needed for construction, therefore, arrangement with
J.P. Morgan was made.
54. With respect to doubt of Forensic Auditors as to the genuineness of interest paid by Amrapali
Silicon City Pvt. Ltd. to IPFFI and claiming interest @ 17% which is very high, it was submitted that
rate of interest depends upon the money lending transactions and is not illegal or prohibited in law.
55. With respect to charging for professional services and fee by Directors, it was stated that a
person rendering professional services should have a membership of professional bodies and have
some certificate of practice. A lot of companies pay a professional/consulting fee to outsiders to
assist them in their business. Amrapali group has also paid salaries and consultation fees to
Directors as they were providing their expertise and skill. Ultimately prayer had been made to
evolve some mechanism for completion of housing projects.
56. On behalf of Royal Golf Link City Projects Pvt. Ltd., it is submitted that a loan of Rs.50 crores or
Rs.48,52,05,100 was paid by Ultra Home Constructions Pvt. Ltd. to Royal Golf. Interest @ 9%
amounting to Rs.5,83,42,977 has been paid to Ultra Home. Subsequently, the agreement has been
entered into to repay Rs.50,46,78,022 by 31.3.2017 or in lieu thereof 30 Villas have to be allotted by
Royal Golf to Ultra Homes. This Court has attached 30 Villas allotted to Ultra Home. It is ready to
give 30 Villas by 30.4.2021 or to refund the amount of Rs.48,46,78,022 in 4 equal quarterly
instalments in full and final settlement of all claims of Amrapali group.
57. On behalf of Bank of Baroda, it has been submitted that Forensic Auditors have made adverse
comments without any basis. Bank of Baroda had deployed suitable methods to monitor theBikram Chatterji vs Union Of India on 23 July, 2019

utilisation of funds. No diversion of funds was permitted by Bank of Baroda. Monitoring of the loan
was done and before sanction of the loan, the net worth of the promoters/Directors of ASCPL was
ascertained. Bank of Baroda relied upon a letter dated 29.7.2010 from Noida to ASCPL. The term
loan agreement was executed amongst ASCPL, Bank of Baroda, Bank of Maharashtra and Oriental
Bank of Commerce "Consortium" for a term loan of Rs.300 crores. After execution of due
documents and deeds of corporate guarantee issued in favour of Bank of Baroda, corporate
guarantees were submitted by Ultra Homes Construction, Jotindra Steels and Tubes Ltd. along with
Vidhyashree Buildcon. Pvt. Ltd. RoC search report of guarantors was also obtained. NOC of Noida
dated 21.2.2012 for mortgaging the project site to procure a term loan from the consortium was also
obtained. A detailed project report was issued by Solomon Consulting Pvt. Ltd. There was the
appointment of independent lender's Engineer and thereafter accounting was done, post-disbursal
of loan by Bank of Baroda. The money was released on the basis of lenders Engineers advice of
Rs.49 crores out of Rs.55 crores. Thus, there was no lack of due diligence and considering the
progress of construction, steps had been taken by the Bank of Baroda to protect its interests after the
account became NPA. Active steps were taken to recover the amount. The similar mechanism had
been adopted for Amrapali Infrastructure Pvt. Ltd. With respect to Ultra Homes Construction Pvt.
Ltd., also a loan of Rs.75 crores was sanctioned out of which Rs.65.84 crores were disbursed for the
construction and development of an Integrated Information Technology Park, (IT Park), Hotel,
Commercial complex, service apartments and residential complex on Plot No.59, Sector Knowledge
Park-V, Greater Noida, which were executed by Mr. Anil Kumar Sharma, Mr. Ajay Kumar, Mr. Shiv
Priya and Mr. Madan Mohan Sharma. Amrapali Zodiac Developers Pvt. Ltd. was granted a loan of
Rs.75 crores. It was not utilised for payment of the cost of land or for payment of construction cost.
The amount has been repaid and the account has been closed. The money may have been routed
through various suppliers and contractors. The remittance of money is nothing but an example of
due conduct of business. With respect to the release of the corporate guarantee of M/s. Jotindra
Steel and Tubes Pvt. Ltd., it is submitted that they were unable to infuse share capital as required
and seemed unable to do so in the future as well. The shares due to M/s. Jotindra Steel and Tubes
Pvt. Ltd. were also allotted to M/s. Ultra-Homes Construction Pvt. Ltd. Thus, the Bank of Baroda
granted the request for release of the corporate guarantee in favour of M/s. Jotindra Steel and Tubes
Pvt. Ltd. Amrapali group had the right to mortgage the property as per the mortgage deed. There
was no bank charge on the property mortgaged by Amrapali group. As per clause 15 of the mortgage
deed, the buyer shall have no right after paying all amounts. The developer shall continue to have
full authority over the flat unless a registered deed is executed in favour of the allottee. It is also
submitted that the home buyers are not secured creditors. The home buyers were to acquire the
premises on sub-lease basis which was never intended or stated anywhere that a sale would take
place. The allottee shall not have any lien or interest on the flat unless sub-lease deed is executed.
Therefore, they are not secured creditors, they have no right, title or interest or lien on the basis of
allotment from flat buyer agreement. It is further submitted that the agreement does not create any
rights in praesenti with a promise to enter into a future agreement. It does not create any right, title,
interest or claim in the immovable property. In the absence of registration of document under the
Registration Act, no rights are created in the immovable property in question under section 49 of
the Registration Act.Bikram Chatterji vs Union Of India on 23 July, 2019

58. With respect to RERA provisions, it has been submitted by Bank of Baroda that section 11(4) of
RERA deals with the interaction between repayment to secured creditors and rights of allottees.
Sub-section (h) of section 11(4) states that the promoter shall not create a mortgage or charge after
an agreement to sell has been executed. Therefore, the promoter is permitted to create such
mortgage or charge prior to the execution of an agreement to sell. Section 4(2)(1) of RERA requires
the promoter to disclose the prior encumbrance to the real estate authority. Under section 34(b) it is
required to publish and maintain a website of records. Section 19(4)(1) of RERA provides that if the
promoter fails to complete or is unable to give possession of an apartment, plot or building, the
rights of allottees are restricted to receive the compensation from the promoter. The rights of
allottees under section 19 of RERA can be contrasted with the right of the mortgagee who secured
creditors under section 58 of the Transfer of Property Act, 1882. The RERA is restricted to protect
the rights and interests of the allottees from the promoters and developers. RERA recognises and
protects the rights of the lenders and does not in any manner take away any right under the existing
statutes like the T.P. Act, SARFAESI, etc. RERA has not brought any change in the nature of the
rights of home buyers. The Bank is entitled to receive its money along with interest in the event of
failure to repay by builder/ promoter. IN RE: FORENSIC AUDITORS
59. The Forensic Auditors have submitted their report running into eight volumes. It has been
observed that the Amrapali Group was started in 2003 by Mr. Madan Mohan Sharma. Later on, it
was managed by his son Mr. Anil Sharma. He gradually expanded his team and Mr. Shiv Priya, Mr.
Ajay Kumar, Mr. Nishant Mukul, Mr. Chander Wadhwa, Mr. Mohit Gupta, Mr. Adhikari Das, and
others joined in. By 2010, the Amrapali Group was leading real estate development firms, promising
to offer luxury and comfort. In the beginning, the Amrapali Group has constructed and completed
certain projects and earned the goodwill of the general public in the real estate business. The
Amrapali Group used unfair means to promote themselves. It made false promises to lure the public
to invest in its projects, purposefully delayed construction, cheated home-buyers for the title of flats
and trapped home-buyers in rental returns. The Amrapali Group floated several companies. The
public invested their hard earned money in Amrapali projects and the shareholders used these funds
to infuse capital in other companies/entities. Home buyers were cheated by making false
promises/claims for example selling of flats which were not even part of the master plan of projects
or unapproved in the master plan, double booking of the same flat by different customers. The
homebuyers funds were diverted to other companies/directors through payment of professional
fees, by way of booking of bogus bills of Rs.837 crores, by selling flats as undervalued prices in book
and received differential market value in cash, by paying commission and brokerage on bogus
booking of flats and by way of granting inter-corporate deposits of Rs.3,000 crores to related
entities and Rs.500 crores to unrelated entities/trusted partners for ultimately diverting funds to
unapproved uses. SUMMARY OF REPORT OF FORENSIC AUDIT
60. The summary of report submitted by Forensic Auditors in the Court is as under:
1. Brief Introduction Amrapali Group started its operations in the year 2003 in Delhi.
It was started by Mr. Madan Mohan Sharma who managed it for a brief period.Bikram Chatterji vs Union Of India on 23 July, 2019

Thereafter the operations of the Group were managed by his son - Mr. Anil Sharma. Gradually, he
expanded his team and Mr. Shiv Priya, Mr. Ajay Kumar, Mr. Nishant Mukul, Mr. Chander Wadhwa,
Mr. Mohit Gupta, Mr. Adhikari Das and other trusted partners/executives joined in. The Group was
into the business of construction of residential complexes, townships, offices, commercial
complexes. The Group built good reputation in the public and launched several projects in various
cities in India. By 2010, the Group was a leading real estate development firms in India and
particular in North India, promising to offer luxury and comfort in every project that it takes up.
Subsequently, Mr. Mahender Singh Dhoni became brand ambassador of the Group.
To achieve good standing in the eyes of public, the Group used unfair means to promote themselves.
The Group made false promises to lure public to invest in its projects, purposefully delayed
construction, cheated homebuyers over title of flats, trapped homebuyers in rental returns, sold flats
at exorbitantly low prices and recovered market price in cash from them, among other unfair means
adopted by them. The Group floated several companies through its directors, staff, trusted partners
which were incorporated solely to divert homebuyers funds. The Group collaborated with external
parties like JP Morgan in contravention of FEMA and distributed returns along with principal
amount, even though it did not book gains within the business of the company. Similarly, it
collaborated with several other third parties and invested in other projects and built a cycle of
returns in the form of unaccounted cash. The Group treated moneys received from home buyers as
its own capital and used this money for investing in exclusively personal purposes, for example in
constructing Amrapali hospital, hotels, malls, making movies etc. The Group booked bogus
expenses and routed funds to trusted partners. The Group also used homebuyers funds for building
personal properties, investment in mutual funds, expenses in daughter’s wedding, purchase of
luxury cars, watches, building luxurious houses for directors etc. The Promoters diversified to
different verticals i.e. Education, Entertainment (in making movies), FMCG, infrastructure,
Shopping Malls, technology parks, hotel etc. from the diverted Home Buyers funds. The Promoters
didn’t invest any paisa in such verticals and the whole empire was created out of the diversion.
The Promoters created a web of more than 150 companies (Page No. 16-19 Volume I) for routing the
funds and creating assets. About 100 Companies were under the supervision and control of
promoters used mainly for the purpose of diversion of funds. The Directors and Shareholders of
these Companies were benami and were the trusted junior employees of promoters. CFO and the
Statutory Auditors.
It is observed that the Company, i.e. management, CFO, the Statutory Auditors and key managerial
persons deliberately and for reasons best known to them did not prepare the accounts till 31st
March, 2018 or thereafter as nobody wanted to let anybody know where the funds moved from
31.3.2015 onwards. In absence of Book of Accounts, we are constrained to report that the
management deliberately withdrew the Bank Balances for making payments to some person and
brought down the huge bank balance to negligible amount.
The management has diverted the Home Buyers’ funds from one Company to another Company in a
very clever, pre-planned and clandestine manner. The management could not have done this
without the full support of its CFO and the Statutory Auditors. As per the submissions made, manyBikram Chatterji vs Union Of India on 23 July, 2019

companies were controlled by CFO and the Statutory Auditors to which huge funds have been
transferred. It can therefore, be easily said that both CFO and the Statutory Auditor were Master
Mind behind these types of planning for diversion and the misuse of funds. It may be important to
mention here that funds were transferred from one Company to another and to third and to fourth
and so on thereby absolutely confusing any person to find out the real trail where the money has
gone, since there are more than 100 Companies through which these funds have been routed over
the period.
2. HISTORY OF ALLEGATIONS Bank of Baroda and several other banks filed a petition before
NCLT under section 7 of the Code for triggering Corporate Insolvency Resolution process in the
matter of Amrapali Group Companies. Homebuyers filed petition seeking construction and
possession of around 42000 flats booked in Amrapali Group On 6th September 2018, Supreme
Court appointed Mr. P K Aggarwal and Mr. Ravi Bhatia as joint forensic auditors to audit into the
matter. ACCOUNTING PACKAGE The group was using Tally till March, 2015 for all of its group
companies. In April 2015, it introduced Far Vision an ERP which was not implemented properly.
The opening balances were not properly entered. In November 2016, the group left half way Far
vision and started recording partial transaction in tally.
To avoid the traceability, of the transactions, the Promoters and CFO and Adhikari (G.M Accounts)
recorded the financial transactions up to March 2015 in Accounting Package tally, then shifted to
FARVISION from April 2015 and continued till March 2016, and thereafter partially recorded
transaction in tally and a for a few companies in FARVISION and thereafter in tally. This was
intentionally plan. The companies of the group stopped getting the annual accounts prepared and
filing returns to Roc and Income tax.
3. Auditors The Following Firms carried out the Audit of the Group Companies during the period:
     •      Anil Ajay & Co.
     •      BSR & Co.
     •      Deloitte Haskins & Sells
     •      SN Dhawan & Co.
     •      Chander Wadhwa & Associates
     •      Manoj Usha & Co.
     •      Agarwal Seth & Co.
     •      Kumar Chopra & Associates
4.   Non genuine purchases from suppliers
Purchase bills have been accounted for in the books of accounts without receipt of physical goods
and purchase bills have been accounted for of suppliers who do not exist. There was an Income Tax
search and seizure on 9th September, 2010 and 7th August, 2013. During the search held on 7th
August, 2013, it was held by the Income Tax Authorities that purchases are being made from bogus
suppliers without receiving the goods physically. The total amount of purchases from such suppliers
as observed by the Income Tax department amounted to Rs.842.42 Crores approximately..Bikram Chatterji vs Union Of India on 23 July, 2019

In order to confirm the genuineness of these suppliers and a few other suppliers we have sent
written communication/ letters by speed post to them in order to confirm the transactions with the
Amrapali Group of Companies. Most of these letters have been received back with the remarks “No
such firm exists at the specified address”. In addition to above, there is no system of calling
quotations for purchases and there is no internal control with respect to inventory. We have spotted
out further certain non-genuine supplies as per details given below:
(i) M/s B S Promotors There have been sales to M/s B S Promoters amounting to Rs.
21.15 Crores during the period 2013-16 from one Company of Amrapali Group and
the same goods were re-purchased into another Company of Amrapali Group at a
margin of 5% approximately.
These transactions seem to be mere accommodation entries, where all purchase/ sales are recorded
on a single day only. Further, it was also explained that M/s B S Promotors have made the sales
against Bank Letter of Credit which has been discounted by them from their bankers. This seems to
be a case of manipulation with the banks also since there is no movement of goods but entries within
the Amrapali Group only. Further, it is observed the balance outstanding of INR 5.11 Crores due to
the B S Promotors as on 31st March, 2016, has been adjusted against payment made by home buyers
directly to the B S Promotors and by allotting a flat to M/s B S Promotors. However, the authorized
representative of the B S Promotor has refuted this fact vehemently and asserted that it has not
received any payment from the home buyers of the Amrapali Group, nor it has received any flat.
Thus, the flat allotted to B S Promoters on paper needs to be attached and put to sale. Moreover, a
sum of INR 1.06 crores as 5% of the margin earned by M/s B S Promoters needs to be recovered
from him as they have neither received goods nor supplied any good and only acted as Billing agent
for which they need not be claiming INR 1.06 crores as their margin.
(ii) Kanodia Cements While scrutinizing the purchase bills of this supplier it was noted that the slips
of Weigh Bridge in the case of purchase of Bajri trucks show time interval of 4-5 Minutes only. This
doesn’t seem to be possible that a full truck of Bajri takes only 4-5 minutes to enter into the site and
come back on the weigh bridge again with empty truck in 4-5 minutes. No satisfactory explanation
has been furnished by the management regarding this issue. Sample of such instances have been
enclosed below:
                         Net                    Time of    Time of
Challan                                                               Time
        Truck No.        weight Date            Gross      tare
No.                                                                   taken
                         in Kg                  Weight     weight
   6524 HR74A-5331       30,720 2/3/2015        18:31      18:36      5 Min
   6477 HR74A-3499       32,120 2/3/2015        18:34      18:39      5 Min
 6437 HR74A-5331        29,230 23/2/2015 18:08           18:12      4 Min
 6435 HR74A-8194        31,020 23/2/2015 17:55           18:00      5 Min
 6429 HR74A-8194        30,640 22/2/2015 15:50           15:55      5 Min
 6289 HR74A/5331        29,150 17/2/2015 15:08           15:13      5 Min
 6291 HR74A/8194        30,240 17/2/2015 15:00           15:05      5 MinBikram Chatterji vs Union Of India on 23 July, 2019

 6250 HR74-9144         30,710 12/2/2015 18:25           18:30      5 Min
 6176 HR55T/5754        30,090 15/2/2015 15:54           15:58      4 Min
 6265 HR74A-8194        29,490 15/2/2015 15:52           15:56      4 Min
 6179 HR74A-1620        28,270 8/2/2015       16:39      16:43      4 Min
 6261 HR74A-8194        30,930 14/2/2015 17:32           17:36      4 Min
 6220 HR38T-2855        33,780 8/2/2015       15:43      15:48      5 Min
 6227 HR74A-5331        29,290 9/2/2015       15:09      15:13      4 Min
 6172 HR55T-5896        29,640 7/2/2015       16:56      17:00      4 Min
 6210 HR74A-8194        29,560 7/2/2015       16:59      17:02      3 Min
 6169 HR55T 5896        30,910 6/2/2015       15:32      15:36      4 Min
 6170 HR55T 8339        31,270 6/2/2015       15:35      15:37      2 Min
 6263 HR74A 1680        30,090 14/2/2015 19:09           19:13      4 Min
As these bills of Kanodia Cements are prima facie held to be bogus, the entire sum of INR 11.69
Crores booked as purchases from Kanodia Cements should be recovered from them or from the
Management for inflating their purchase by debiting bogus invoices. Bogus expense and cash
surrendered in income tax search Cash has been surrendered by the Amrapali group in the first
Income Tax search conducted on 9th September, 2010. No source of this cash has been explained by
the management.
According to the Balance sheet of Amrapali Sapphire Developers Private Limited examined by us,
cash surrendered is shown as miscellaneous income in the profit and loss account during 2010-11
amounting to Rs.1.39 Crores.
It is further submitted that in the second search conducted by Income tax Authorities on 7th August,
2013, the Amrapali group had surrendered an additional income of Rs.125 crores. Both these facts
clearly depict that Amrapali group was having inflow of unaccounted cash collected from either the
Home Buyers or collected cash from Bogus purchases made or by advancing money to various
parties and taking cash from them.
While scrutinizing the Audited Financial Statements of the Companies for the Financial Year
2013-14, it is observed that no additional income has been shown. There is only jugglery of
accounting transactions where sales have been shown by way of part completion method and the
relevant cost is also debited to this part completion sale by changing the Accounting Method which
was being followed by the Amrapali Group of companies in the earlier years. This method of
accounting was changed for 2 financial years only i.e. for Financial Year 2012-13 and Financial Year
2013-14. This method was changed just to make adjustment in accordance with the letter of
surrender. In fact, there is no surrender of additional income, it only amounts to preponement of
sale being shown in these years instead of it in the later years.
Cash has also been surrendered in the first search conducted on 9th September, 2010 and no source
of this cash has been explained by the management. This clearly explains that there was flow of
un-accounted cash from various sources to the Amrapali Group of Companies. A note was also
stated in the Audited Financial Statements for the financial year 2010-11 as follows:Bikram Chatterji vs Union Of India on 23 July, 2019

“Note 6 (A) During the F.Y. 2010-11 Income Tax Search & Seizure operation
conducted by the Income Tax Department on the company and company has
surrendered a total income of Rs. 13,893,500 i.e. Rs. 10,043,500 for the F.Y. 2009-10
and Rs. 3,850,000 for the F.Y. 2010-11. Accordingly, the total income includes the
above said income.” Thus, it is can be easily inferred that the company has been
regularly taking cash from its various home buyers but not recording these cash
entries in the Books of Accounts. (Volume –I Page No. 205) It is unclear how the
surrender of Rs.125 crore made during the Financial Year 2013-14 has been accepted
by the Income Tax Authorities. In fact, no additional income has been shown on this
search.
Moreover, against the additions relating to Bogus Purchases made in the Assessment
order for the Financial Year 2013-14, the Commissioner of Income Tax (Appeal),
Central Circle has deleted all these additions.
We are informed by the management that no further appeal has been preferred by
the department before the Income tax Appellate Tribunal as they have no idea of the
same so far.
The bills booked and payments made were just accommodation entries. Many of the
parties are not traceable and when we requested the Amrapali Group Management to
produce the persons/entities to ascertain the veracities of the claims, they didn’t
co-operate.
It appears Prima-Facie that the bogus invoices were booked and cash was taken from
these parties. We are of the opinion that if we confront the recipient of the purported
charges then last recipient would flatly deny.
It is pertinent to note that Shri Ajay Kumar Aggarwal of BSBK Group in a statement
recorded under section 132(4) of the Income Tax Act has admitted that he provided
accommodation/bogus bills.
Till the date of writing this report the amount so identified for bogus bills is Rs.837.2
crore. Further, the supplies by Jotindra Steel and Tubes and Mauria Udyog Ltd,
having common directors with Amrapali Group Companies, are prima-facie bogus by
nature and are under examination amounting to Rs.450 crore. (Refer Annexure No. S
4 Page no 2827 Supplementary report).
Land Development Charges A sum of Rs.7.3 crore has been debited to this account on
31st March, 2013 for which the supporting relevant documents are not made
available to us for our verification. This amount needs to be recovered from the
Directors as there is no supporting evidence or voucher and it is just a book entry.Bikram Chatterji vs Union Of India on 23 July, 2019

Total bogus expenses as on date of report have been ascertained to be Rs. 842.42
crore.
Double booking of expense It has been observed that brokerage amounting to Rs 0.25
crore was paid twice; once to HDFC Realty and again to Mr. Alok Ranjan c/o SSS
Enterprises on account of same flat bookings in Amrapali Sapphire Developers
Private Limited during the FY 2019-10. Mr. Sanjay Kumar, proprietor of SSS
Enterprises has already conveyed to GM Finance of Amrapali Group by way of speed
post that fake bill for brokerage has been raised under his name by Mr. Alok Ranjan.
This amount of Rs.0.25 crore should be recovered from Alok Ranjan/ the
Management for booking of double expense. (Volume 1 – Page no 213) Unsupported
Cash Payments The Company has made unusual cash payments by transferring the
cash to the site cash during the financial year 2016-17 by way of vouchers which are
not supported/authenticated by the site cash in charge. It seems that all these entries
have been manipulated to use the cash to decrease the balance as on 08/11/2016
being the date of demonetization. Some instances are as under:
    Financial Year   Particulars                         Amount
    30/04/16         Wages Paid                            2,754,350
    31/05/16         Wages Paid                            2,637,050
    30/06/16         Wages Paid                            2,655,900
    31/07/16         Wages Paid                            2,645,450
    31/08/16         Wages Paid                            2,643,950
    30/09/16         Wages Paid                            2,659,450
    31/10/16         Wages Paid                            2,683,350
    30/11/16         Wages Paid                            1,259,630
    06/06/16         Transferred to site cash            3,000,0000
    12/05/16         Transferred to site cash              4,100,000
The above are only from one company which is tip of the iceberg and actual amounts
may be much higher.
Further cash payments are being made to number of parties amounting to Rs.20,000
or less which are not supported by payee’s receipts on daily basis. Thus, these
payments are not genuine. (Volume I- Page 223) It is observed that the cash balance
available on 8th November 2016 was partly deposited into bank and huge amounts
were not deposited into bank and was used for payments to staff, suppliers, vendors
etc. It is worthwhile to mention that it was not permitted to use Specified Bank Notes
(SBN-500, 1000 denomination Notes) for making payments to these parties.
Further there has been an Income tax Survey on 17/11/2016. We understand Income
Tax Authorities have recorded the statement of Directors and also taken the
Inventory of Cash in hand as on that date. A copy of the statement recorded and
detail of inventory of Cash in hand is not made available to us.Bikram Chatterji vs Union Of India on 23 July, 2019

Gold bar purchased from Yashika Diamonds It has been observed that the Group
Companies purchased Gold bar, other forms of gold worth Rs.5.88 crore. The same
has been booked as festival expenses. This does not seem to be a normal business
transaction but in the nature of personal expenses. Thus, this amount should be
recovered from the management of the company.
5. Negligence and non- monitoring by bankers In view of our detailed report
attached, we wish to submit here that the whole process of transfer of funds from one
Company to another Company to a third Company and so on and so forth on the
same dates would not have been possible without active support by the Bankers.
The Bankers, in our opinion, turned a Blind Eye to the various transfer of funds from one account to
another for reasons best known to them. They didn’t inquire the huge transfer of funds from various
accounts which were being routed every day. Had they been slightly more vigilant to monitor and
control transfer of funds, the Management would have not dared to launder the money from one
Company to another according to their whims and fancies and the Bankers are solely responsible for
the negligence on their part.
Banks did not do any monitoring that whether the funds disbursed were used for approved purposes
or not. The loan sanctioned as term loan were diverted on the very same day of receipt. The land
payment were not paid etc. Bank of Maharashtra – Term Loan has been released by transferring the
amount to the Current account during the financial year 2009-10 to 2012-13. There has been no
monitoring by the bank to ensure the end use of utilization of the funds.
This amount was paid from the Current account for other than business activities of this Company.
It is observed that there was no monitoring done by the officials of Bank of Maharashtra, Andhra
Bank and other banks by releasing of term loan to the Company. Even basic checks as required by
the Bank were forgone and not ensured by the Bank Officials regarding the end utilization of the
term loan funds for the purpose for which they were granted. It seems that the Bank officials
overlooked all these important aspects and granted these loans to them without going into any
technical requirements as relating to release of Term Loan facilities to a borrower. The banks acted
as mute spectator to unapproved diversion which was almost happening evidently in all banking
transactions.
Optionally Convertible Debentures ICICI Prudential Asset Management Company Limited had
given a sum of INR 74 crores approximately on account of debentures issued by Amrapali Sapphire
Developers Private Limited during the financial year 2011-12. These debentures carried interest rate
@ 17% Per annum. There has been a gross non-compliance of Investors cum-shareholders
agreement dated 16th Day of December, 2010 with respect to following:
a. Non appointment of directors b. Non operation of bank account by joint signatory
of investor c. Non utilization of funds as per clause no. 7.5 of Investment cum
Shareholders Agreement dated 16th December, 2010. d. Sale of flats at less than RsBikram Chatterji vs Union Of India on 23 July, 2019

3,420 per square feet of saleable area and many other clauses of this agreement
neither followed nor ensured by the Investor.
It is very clear that a Debenture Subscription Agreement and Investment cum
Shareholders Agreement both dated 16th day December, 2010 were merely sham
documents which were never complied with and both i.e. Amrapali group of
Companies and ICICI Prudential Asset Management Company Limited were in
connivance with each other in diversion of funds for non-specified purposes.
Foreign investment The company has received the sum of Rs. 140 Crores during the
financial year 2012-13 from IPFFI Singapore PTE Limited under Foreign Direct
Investment Scheme. As per FEMA rules this amount was to be invested in Real
Estate construction projects only.
The amount received in Axis Bank of Rs.85 Crores was transferred to Amrapali
Centurian Park Pvt. Ltd. (ACPPL) as under:
     On 7.8.2012         -   Rs.5 Crores
     On 8.8.2012         -   Rs.50 Crores
     On 18.8.2012        -   Rs.30 Crores
                             -------------------
                 Total =     Rs. 85 Crores
                             ------------------
ACPPL on receiving Rs.85 Crores, allotted Equity Shares worth Rs. 85 lakhs to
ASCPL and balance Rs.84.15 Crores were treated as Share Premium Account. There
is no Valuation Report available as to how this share premium of Rs. 84.15 Crores has
been calculated. This transfer of fund by ASCPL to ACPPL is absolutely violative of
FDI Rules and Agreement.
The Second amount received in BOB Escrow Account was transferred from 8.8.2012
to 28.9.2012 on various dates in the Account of BOB, Sansad Marg Branch, and New
Delhi and also used for payment of Term Loan Instalments of OBC and Bank of
Maharashtra for repayment of their Term Loan instalments.
It will therefore, be observed from the above, that the Company (ASCPL) did not use
money for the project for which it was received from IPFII Singapore but transferred
Rs.85 Crores to Amrapali Centurian Park Pvt. Ltd. and Rs.55 Crores to repay Bank
Loan Instalments and Repay the outstanding creditors provided for in the books and
standing in the books. The said payments made by ASCPL are, therefore, in
contravention of FDI norms and rules and for which the money was brought in India.
Moreover, ASCPL has paid interest of Rs.58.81 Crores @ 17% (which is a highly abnormal rate) so
far to IPFII, Singapore during the last 3 years.
-    Year 31.3.2013                      Rs.14.41 Crores PaidBikram Chatterji vs Union Of India on 23 July, 2019

-    Year 31.3.2014                      Rs.22.20 Crores Paid
-    Year 31.3.2015                       Rs.22.20 Crores Paid
                                                       ----------------
                                      Total = Rs.58.81 Crores
                                               ----------------
a) It is very clear that all such violations are being made with the knowledge of the IPFII Singapore
and they are in Connivance with the ASCPL.
b) As per Schedule 4 of the agreement CCD’s (Compulsory Convertible Debenture) were subject to
the following terms and conditions.
1) On expiry of 5 years from the date of allotment, the CCD shell be fully monetarily and
compulsorily converted into class B shares of the company
2) The CCD’s shall be converted into such number of class B shares arrived that by dividing the
aggregate face value of CCD’s by Rs.2,734.30.
But these CCD’s were not converted into class B shares as per agreement but entered into another
agreement to extend the term of CCD’s from 5 years to 7 years. By this way , The fund has continued
to be a creditor otherwise after conversion to equity, it will not be eligible for interest and principal.
Current liabilities not payable Security deposits from contractors and intercorporate deposits
accepted from non group companies are in the nature of unsecured loans. There have been no
business transactions with the company except movement of funds. The list of such liabilities is
under preparation which are not payable.
Inter-corporate deposits accepted by the Group are Non-Interest- bearing unsecured loans. There
are no business transactions with these companies. It is not understood as to why a person will give
interest free loans without any considerations. Thus, we are of the view that these are
accommodation entry only in lieu of consideration given to them indirectly by the management.
Hence, we are of the view that all the aforesaid amounts are not payable.
In our opinion, this is a case of Money Laundering as the generic term of Money Laundering is
defined to describe the process by which Criminals disguise the original ownership and control the
proceeds of the criminal conduct by making such proceeds to have derived from a legitimate source.
Money Laundering is the process of concealing the origin of money obtained illegally by passing it
through a complex sequence of Banking transfers or commercial transactions. The main process is
accounting for the proceeds without raising the suspicion of law enforcement agencies. In the
instant case too, Amrapali Group of Companies have defied all laws to transfer small and big
amounts from one account to another to a third and so on and so forth on a single day with the
connivance of the Bank officials and financial institution officials and thereby Committed act of
Money Laundering on a large scale.Bikram Chatterji vs Union Of India on 23 July, 2019

6. Lands allotted to consortium and flats sold to homebuyers Several companies were formed with
consortium partners which were just dummy companies and were part and parcel of Amrapali
group. To comply with the condition of minimum 3 partners, these companies were created in the
names of office boys and peons. Technically the allotments at the initial stage itself were void
ab-initio. In most of the companies, the amount received from homebuyers was sufficiently more
than the amount spent on construction and for payment of land. Had the promoters paid amount
received from homebuyers to the authorities on time there would not have been any liability of land
dues. Further there was no need to avail any loan from banks, Private equity funds as well as from
investors. The sole objective of taking loan was to divert the funds to other ventures to create assets
in the name of family members, make movies, to satisfy the ambitious desires of family members
and to build hospital. Villas were bought at tourist destinations for fun at the expense of middle
class and low income group peoples abodes. Many parties joined them in the looting of hard earned
money of homebuyers to take their share of the cake in the form of unbelievable return on
investment, profits, land, FSI and flats and facilities at throwaway prices. Bogus expenses were
booked and the promoters were having no fear of the law of the land. They could execute many
transactions of transfer of properties, booking of expenses, funds transfer, even when the petition
was accepted and was pending for disposal before the Honourable Supreme Court. Companies in
which land was allotted to consortium partners are as under:
       •     Amrapali Leisure Valley Pvt Ltd
       •     Amrapali Centurian Park Pvt Ltd
        •       Amrapali Homes
        •       Amrapali Grand
        •       Amrapali Eden Park Developers Pvt Ltd - Iftikar Ahmed and
Rakesh Mahajan jointly hold 49% in the said company
(i) There is no substance in the nature of transactions carried on by the company. The funds are
merely routed from one entity to another for hidden objective.
(ii) Banks were financing not the construction activity but loans and advances to third parties.
(iii) Mr. Rakesh Mahajan and Mr. Ifthikar Khan were grossly involved in the wrongdoings in the
company’s project and equally conspired in the delay and diversion of home buyers funds and they
being 49% shareholders and active directors in the company should be held responsible for the
deficit in completion of the project amounting to Rs.20 crore. Further, Amrapali Infrastructure had
given an advance of Rs.1.5 crore to Nirala Infracity Ajmer Pvt Ltd - a project controlled by Rakesh
Mahajan and Iftikar Ahmed. This amount is recoverable from Nirala Infracity Ajmer Pvt Ltd.
7. Companies created solely for the purpose of routing funds The intention of Amrapali Group was
to divert funds to other projects/income sources in the name of family members of the promoter
and the trusted employees, friends of the promoters as well of the executives, auditors and their
relatives. For this purpose, several companies were incorporated for routing funds. These companiesBikram Chatterji vs Union Of India on 23 July, 2019

did not have any material transaction as per the main object for which they were incorporated and
did not have business since their incorporation. These companies did not have any employees also.
These companies are shell companies used only to route interest free funds from one company to
another. List of such companies identified so far is as under:
a) Jhamb Finance & Leasing Private Limited - The company didn’t have any
operations/income/expenses except for FY 2014-15 and had only movement of funds
from one related party/interested party to the other. It means the company was used
merely for routing the funds and not for doing any business.
Since incorporation, loans (liability) and loans & advances (asset) increased as under, without
booking of any expense/income:
     As on                    Loans (liability)        Loans & advances
                               Amount (RS. )                      (asset)
                                                          Amount (RS. )
     1st April 2014                 83,00,000                1,12,39,917
     1st October 2014            35,33,00,000               34,67,39,917
     31st March 2015            312,93,32,906              313,11,55,392
     31st March 2016            859,77,32,906              863,58,50,776
     31st March 2017            877,57,22,906              883,24,00,776
It is pertinent to note that starting from the FY 2015-16, the loans given and taken increased three
folds without having any corresponding increased on the income and assets side on account of
interest. Whereas starting from FY 2015-16, the employees started leaving the organization and the
construction at sites was at standstill. The directors in the company are having no knowledge or an
iota of idea about the transactions carried out. The company’s operation were under the controlled
and supervision of CFO Chander Wadhwa. Further, it received Rs.18.95 crore from Suspense-
unidentified persons/parties and paid Rs.24.41 crore to Suspense- unidentified persons/parties,
leaving balance payable of Rs.5.46 crore to Suspense- unidentified persons/parties. The said
transactions of Rs.18.95 crore details were not made available to us.
b) Gaurisuta Infrastructure Private Limited – It lent and received funds from several parties without
doing any business. Details of Rs.25 crore received from third parties are as under:
 S.no. Name of party                        Amount        Since date
 1      Ams Powertonic Pvt Ltd              50,00,000     07-05-2012
 2      Anuj Buildcon Pvt Ltd               50,00,000     10-05-2012
 3      Asv Garments Pvt Ltd                50,00,000     07-05-2012
 4      Bij Buildcon Pvt Ltd                50,00,000     10-05-2012Bikram Chatterji vs Union Of India on 23 July, 2019

 5      Carona Infra Projects Pvt. Ltd. 2,20,00,000       Received on
                                                          various dates
                                                          From 16-05-
                                                          2013 to 16-09-
 6      Charuvilla Apartment Behl           8,31,000      08-07-2011
 7      Financial World Pvt. Ltd            57,00,000     11-07-2012
 8      Function Distributors Pvt. Ltd. 50,00,000         03-08-2012
 9      Green Value Agro Farm Pvt.          30,00,000     01-08-2012 &
        Ltd                                               03-08-2012
 10     Infotech India Pvt Ltd              1,00,00,000   03-07-2012
 11     Kabir Enterprises Pvt Ltd           50,00,000     06-06-2012
 12     Ladli Ji Enterprises Pvt Ltd        2,00,00,000   15-05-2012
 13    Leisure Buildcon Pvt Ltd           50,00,000      25-04-2012
 14    M/S Naksha Properties              84,00,000      19-04-2012
       Pvt.Ltd
 15    M/S Shravni Infrastructre          3,20,00,000    Received on
                                                         various dates
                                                         From 19-04-
                                                         2012 to 11-07-
 16    M/S Soulful Heart Solutions        22,00,000      Received on
                                                         various dates
                                                         From 19-04-
                                                         2012 to 17-07-
 17    Ram Rahim Trading Co.              70,00,000      01-08-2012 &
       Limited                                           02-08-2012
 18    Randhir It Solutions Pvt Ltd       50,00,000      07-05-2012
 19    Rayan Garments Pvt Ltd             1,40,00,000    26-04-2012 &
                                                         07-05-2012
 20    R N Sangahi                        24,37,480      11-04-2011 ;
                                                         02-07-2011 &
                                                         18-12-2012
 21    S A Corrugators Pvt Ltd            20,00,000      01-08-2012
 22    Sadbhavana Properties Pvt Ltd 4,00,00,000         08-06-2012
 23    SpbPropcorn Pvt. Ltd.              50,00,000      25-04-2012
 24    Technicare Biomed India Pvt        40,00,000      25-04-2012
       Ltd
 25    Utkarsh Properties Solution        28,00,000      26-04-2012 ;Bikram Chatterji vs Union Of India on 23 July, 2019

                                                         16-09-2014 &
                                                         17-09-
 26    Vendure Agents Pvt Ltd             50,00,000      01-08-2012
 27    Zarf Infra. Development Pvt        1,45,00,000    Received on
       Ltd                                               various dates
                                                         From 26-04-
                                                         2012 to 04-08-
 28    Zoom Building Materials Pvt        1,00,00,000    10-05-2012 &
       Ltd                                               11-05-2012
       TOTAL                              25,08,68,480
The above companies were used for the purpose of money laundering and required a detailed
investigation. Further the amount as shown above is not payable to the party as indicated against.
None of the parties as above has lodged any claim so far therefore it strengthens our charge.
As on 31st March 2017, the company is having interest free loans and advances amounting to Rs.703
crore without any movement with a paid up share capital of merely Rs.0.01 crore and the directors
are employees and junior employees of statutory auditors. The company is used as a conduit in
diverting home buyer funds to Amrapali Healthcare (Noida Hospital) and buying shares in different
group companies from the funds of home buyers. The entire shareholding should be attached and be
made up for sale.
c) Neelkanth Buildcraft Private Limited - It was formed in the year 2013 having a capital of Rs.0.01
crore for the specific purpose of buying shares from JP Morgan. Mr Chandan Kumar, director of
Neelkanth Buildcraft Private Limited is an office boy in the office of Statutory Auditor of Amrapali
Group, Mr Anil Mittal and the other director Mr Vivek Mittal is nephew of Statutory Auditor Mr Anil
Mittal & does small time jobs.
d) Stunning Construction Private Limited – The Company is holding 19.75 % shareholding in LA
Residentia Developers Pvt. Ltd. is a consortium partner in the project since beginning. LA
Residentia project has 3200 flats LA Residentia should surrender either 19.75% of land or 632 flats.
It was formed only for payment of Statutory dues of Amrapali Group of Companies, its directors and
their relatives including senior employees of the Amrapali Group of Companies. The company was
under the direct control of CFO Chander Wadhwa and Company Secretary Pankaj Mehta. The
amount of taxes paid by the company on behalf of promoters, directors, executives and their family
members is Rs.17.43 crore (net) and gross up is Rs.24.9 crore is recoverable from promoters,
directors, executives and their relatives.
e) Kapila Buildhome Private Limited – The company did not undertake any business. A sum of
Rs.392.68 Crores was advanced as loan or advances to the various group Companies. Further, it
accepted non-interest bearing inter corporate deposits from non group companies with whom no
other transactions were undertaken. We are of the view that these are accommodation book entries
only in lieu of consideration given to them indirectly by the management. List is as statedBikram Chatterji vs Union Of India on 23 July, 2019

hereunder:
               Name                  Amount In          Date of
                                        Rs.           Acceptance
 Ample Hotels and Resorts            20,000,000            20/04/12
 Justify Vanijya Private Limited      4,000,000            22/06/12
 Ladli ji Enterprises Private         5,900,000            25/04/12
 Limited
 Madhav Fincap Private Limited        15,000,000            24/04/12
 Pan Realtors Private Limited         100,000,00            23/08/10
 Total                               144,900,00
The above companies were used for the purpose of money laundering and required a detailed
investigation. Further the amount as shown above is not payable to the party as indicated against.
None of the parties (except PAN Realtors that also when we requested them otherwise they were
silent for last 8 Years) as above has lodged any claim so far therefore it strengthens our charge.
f) Rudraksh Infracity Private Limited- Shri Chandan Kumar, an office boy and employee of CA Anil
Mittal, Statutory Auditor and Shri Atul Mittal, relative of CA Anil Mittal were inducted in the board.
The basic purpose of this Company was only for money laundering and was incorporated to receive
Funds from Mannat Buildcraft Private Limited. After receiving money (Rs.25 Cr.) from Mannat
Buildcraft Private Limited, the same was transferred to J.P. Morgan Investments for purchase of
Equity Shares of Amrapali Zodiac Private Limited at an exorbitant price. There are no transactions
before or after these transfers of money and the same have been camouflaged to make it look with
business transactions on the basis of the Valuation Report. It was also observed that there are no
transactions at any date during the period but the bank account has only been used for diversion of
funds.
g) Mannat Buildcraft Private Limited - Shri Pankaj Mehta is Company Secretary of Amrapali group
of Companies and now Partner of Mr. Chander Wadhwa, CFO in Saffron Consultants LLP and Mr.
Ashish Jain who is also Partner of Mr. Chander Wadhwa, CFO in Saffron Consultants LLP, were
inducted in the board. The basic purpose of this Company was only for money laundering (Rs.120
Cr.) and was incorporated to receive Funds from Amrapali Zodiac Developers Private Limited.
The whole racket of money laundering and receiving money from these Companies i.e. Mannat
Buildcraft Private Limited, Rudraksh Infracity Private Limited and Neelkanth Buildcraft private
Limited are the brain child of Mr. Chander Wadhwa, CFO and Anil Mittal, Statutory Auditor of
Amrapali Group of Companies. Both these Companies are controlled by both of these persons and
had been formed only for this Money Laundering Business. There are no transactions before or after
these transfers of money and the same have been camouflaged to make it look with business
transactions on the basis of the Valuation Report.Bikram Chatterji vs Union Of India on 23 July, 2019

h) Amrapali Magadh Developers Pvt Ltd - The company has not carried out principal business
activities. There is no bank account. The purpose of creating the company is not clear. The
shareholders paid the share application money in cash. The company is a dormant company & did
not have any significant transaction.
i) Amrapali Mahi Developers Pvt Ltd - The company received share capital in cash and all the
expenses were paid in cash only. Mr. Mahendra Singh Dhoni, husband of Ms. Sakshi Singh Dhoni
(director of company) was the brand ambassador of Amrapali group and have carried out a number
of transactions with respect to endorsement of Amrapali group’s projects. He entered in agreements
with other group company.
j) Amrapali Spring Valley Pvt Ltd- the company is created for diversion of funds and Rs.186 crore
was diverted from Amrapali Smart City Pvt Ltd to buy shares of Ultra Home Construction Pvt Ltd
and shareholders are promoter directors without doing any investments. Most of the above
companies will qualify to be NBFC, which was reported neither by the management nor by the
statutory auditors (except Jhamb Finance & Leasing Pvt Ltd). It is recommended that RBI shall
investigate the affairs and compliances of the above companies. Amrapali Media Vision Pvt Ltd was
also incorporated with a purpose to route funds for making movies to satisfy the ambitious desires
of directors/family members. Most of the marketing and advertisement business of the group
companies was given to the company with a profit margin on the cost. The group could have done
this advertisement directly. But because there was need to make movies, the funds were diverted to
the company directly in the form of loan as well by availing the services indirectly from these
companies. The Company was freely availing funds of homebuyers from other group Companies in
the form of ICD and spent it on making movies.
Hawthrone Intellect Management Solutions Pvt Ltd –Company was providing Management
Consultancy Services (Recruitment Services) and taking nominal professional fee. In turn, the
Company has incurred more expenses in the last few years on account of Salary, Wages and other
administrative expenses thereby resulting in net loss to the Company which has accumulated to INR
2.33 Crores as on 31.03.2015.
All these entries seem to be in nature of dubious entries and no voucher are available. This amount
of loss of 2.33 Crores needs to be recovered from the Directors as they have wiped of the amount of
the Home Buyers funds diverted as Home Buyers Money to the Company. Apart from the above
companies, there were several companies which were incorporated by employees, auditors of
Amrapali group. Shareholding as well as investment/assets of these companies shall be attached
8. Companies created for building assets The following companies were created by the Group for
building assets from homebuyer funds without contribution of any rupee by promoters and their
relatives. The shareholding is held by the group companies and/or by shell companies and/or the
trusted partners including individuals.
• Ultra Home Construction Pvt Ltd- Shareholders did not bring capital of their own, but used funds
of home buyers in other entities/projects to pay for allotment of shares in UHCPL. Mr. Anil KumarBikram Chatterji vs Union Of India on 23 July, 2019

Sharma was allotted shares at premium for an amount of Rs.22,82,40,810 on 4th Nov 2010 and
Rs.25,84,05,470 on 2nd March 2011 by adjusting receipts from Amrapali Infrastructure Ltd which
further received from Amrapali Sapphire Developers Pvt Ltd, which received from homebuyers. Few
instances are hereunder:
Received in Amrapali Transferred to Transferred to Sapphire Developers Amrapali
Ultra Home Pvt Ltd primarily from Infrastructure Ltd Construction Pvt home buyers
Ltd INR 5.47 crore as on 4th INR 2 crore on 5th INR 2 crore on 5th March 2010
March 2010 March 2010 INR 1.90 crore on 5th INR 2 crore on 8th INR 2 crore on
8th and 6th March 2010 March 2010 March 2010 INR 1.13 crore on 8th INR 2 crore
on 9th INR 2 crore on 9th March 2010 March 2010 March 2010 • Amrapali Homes
Projects Private Limited –It has been observed that Mr. Prem Mishra was given INR
12.40 crore (under several ledgers) for purchase of land since 1st April 2008, out of
which INR 10 crore are still receivable from him. The project was sold by Prem
Mishra to various parties and received amount in his name. We are yet to complete
the audit of Prem Mishra in Indore project. The company transferred funds to and fro
with several parties which do not have any substance. It has several small and big
debit balances as on date. • Amrapali Biotech India Pvt Ltd – Land & Building, Plant
& machinery, a factory at Rajgir (Bihar) • Amrapali Healthcare Pvt Ltd – Hospital at
Noida • Noida Texfab Pvt Ltd – Amrapali International Institute of Hotel
management, Noida • Neelkanth Buildcraft Pvt Ltd – bought shareholding from JP
Morgan in Amrapali Zodiac developers Pvt Ltd. • MVG Techno Consultants Pvt Ltd –
Tower at Noida • Amrapali Infrastructure Pvt Ltd – recast factory at Greater Noida •
Sangam Colonisers Pvt Ltd- The Company has received an amount of Rs.10.51 crore
as advance against plots. However, despite repeated requests we have not been
provided with the complete data base reflecting Number of Plots, Name of the buyers,
Amount of Sale Consideration, Amount Received, Amount Outstanding, Unsold plots
etc. Hence, we are not in the position to comment upon the same. As informed to us
during the course of audit, the remaining portion of the land available with the
Company has been attached by Hon’ble Supreme Court of India and put to auction by
DRT. • Navodaya Properties Pvt Ltd – Building corporate tower 2, Noida • Amrapali
Power & Cement Pvt Ltd – Land from Charu Rai yet to be identified, Land from
UPSIDC yet to be identified. • Amrapali Buddha Developers Private Limited –
Shopping complex cum Mall at Gaya • MSB Software Technology Private Limited –
Tower 1, Noida • Gaurisuta Infrasolution Private Limited –Flats in Amrapali Silicon
City Private Limited, booking of bogus expenditure of Rs.1.07 crore. • Amrapali
Hospitality Services Private Limited- Hotel at Deogarh, Jharkhand • Mums Mega
Food Park Private Limited- FMCG Factory at Buxar, Bihar, Land Building and Plant
& machinery RudrakshInfracity Private Limited - bought shareholding from JP
Morgan in Amrapali Zodiac developers Pvt Ltd.
• MannatBuildcraft Private Limited - bought shareholding from JP Morgan in
Amrapali Zodiac developers Pvt Ltd.Bikram Chatterji vs Union Of India on 23 July, 2019

Serious Observation Our investigation reveals that this company has been used to
perpetuate a fraud enabling JP Morgan Investments to sell its shares of Amrapali
Zodiac Pvt. Ltd. to other Group Companies of Amrapali group namely,
RudrakshInfracity Pvt. Ltd. and Neelkanth Buildcraft Pvt. Ltd. at a valuation
amounting to INR 140 crores which is not justified. This company has been used as a
tool to transfer the money to other Amrapali Group companies. The following
persons seems to be involved in this organized fraud:
i. Amrapali Zodiac Developers Pvt. Ltd.
ii. RudrakshInfracity Pvt. Ltd.
iii. Neelkanth Pvt. Ltd.
     iv.    JP Morgan Investments
      v.    MannatBuildcraft Private Limited
     vi.    HDFC Bank
Chander Wadhwa, Adhikari dash and Anil Mittal incorporated 27 Additional
companies identified so far, which may be many more, and became consortium
partners from the funds of the home buyers. In the process, they appointed peons
and junior employees of auditors office as directors who were totally unaware of the
transactions. These companies were used for depositing cash during demonetisation.
The companies were formed/acquired for routing funds and were not in any
business. These were sham companies whose share capital was mostly subscribed in
cash and the transfer of shares was also in cash leaving no audit trail.
9. Misuse of funds by directors involved in scam The directors and executives colluded with each
other and diverted homebuyers funds. Directors received huge amount of money in the form of
salary as well as professional fee, both together. A person could have been either in whole time
employment of the company or render services as consultant. However, a person cannot enjoy
salary income and earn professional income at the same time and also both cannot be earned at the
same time from same company. But directors of Amrapali group withdrew sums using all possible
ways, be it salary, professional fee, reimbursement of expenses, use of luxury cars or loans and
advances to self/relatives/self controlled entities/trusted partners or booking of bills of self
controlled entities/trusted partners. Further professional fee was booked without any agreement or
proof of service. It had no correlation with the amount of work done by the directors. Professional
fee was booked as per wish and desire of directors and did not have any fair basis. There were
standing instructions to transfer company funds to the individual directors bank accounts when the
balance was reaching to the specified set minimum balance limit.
The Professional fee paid to the directors, relatives of directors, and senior managers was a unique
way of diverting money. Huge amounts were paid without any agreements at the whims and fancies
of the directors and managers. Moreover it was tax free and the tax liability was discharged byBikram Chatterji vs Union Of India on 23 July, 2019

another group company. The whole of professional fee received by the directors (as stated
hereunder) is recoverable from them. (Volume –II, Page no 416-417).
   Name of director                             Professional         fee
                                                received
                                                (as per affidavit)
   Anil Kumar Sharma                                    29,13,23,580
   Shiv Priya                                           26,43,64,571
   Ajay Kumar                                            5,76,90,240
   Suvash Chandra Kumar                                  5,11,21,752
   Amresh Kumar                                            68,11,110
   Total                                               67,13,11,253
Professional fee was under disclosed to the tune of is Rs.33.4 crore (Anil Kumar Sharma 8.75 cr +
Shiv Priya 24.65 cr) in affidavits filed on 3rd Dec 2018 (Volume –II, Page no 414-415). The
Difference was found of from the affidavit file and the tax returns.
It shall be noted that directors did not share company wise receipts in the affidavit and also books of
accounts of directors were not provided. Directors along with their trusted partners and relatives
cheated and did criminal breach of trust with the home buyers. They transferred the funds from the
projects to the companies which were closely held by the directors, their family members and/or by
their trusted associates. The objective was to create assets in the closely held companies and leave
the home buyers on the road. For example, Eklavya Building Solutions Pvt Ltd acquired property in
Goa amounting to is Rs.2 crore through funds received from Amrapali group, 27 other companies
further invested Amrapali funds in Amrapali projects (For example Many Flats in IT Park at Greater
Noida);
The directors spent homebuyers funds on wedding of daughter of director, foreign travels, expensive
watches, jewellery, purchasing luxury cars for use by directors. The homebuyers funds were also
used for investment in mutual funds, creating personal properties , payment of housing loans,
investment in shares & securities. The directors created discreet projects for personal income for
example In the name of Amrapali Hospitality a hotel at Deogarh was constructed out of funds
received from homebuyers without their knowledge of it. They used homebuyers funds in the form
of construction of assets for other projects, examples constructed mall at Muzzafarpur, Bareilly etc,
Hotel at Deogarh, Bareilly, Hospital at Noida etc. Few particulars of diversion of funds received
from Amrapali group are as under:Bikram Chatterji vs Union Of India on 23 July, 2019

By Anil Kumar Sharma Particulars Amount Amount Paid for Housing Loan of Plot no
88, 3,137,000 2057/7 resi Magos Village, Goa Amount Paid for Housing Loan of
Jaypee 3,796,452 Green E-11 Plot, Sector 128, Noida Amount paid for purchasing
shares 59,600,000 Purchased Jewellery 33,921,575 Purchased Car 5,613,572
Investment in LIC and Star Union Daichi – 18,238,326 Insurance Policies Expense
done during wedding of Daughter 13,500,000 Swapnil Shikha Transfer to Surabhee
Advertising Maharani 38,500,000 Bagh Property Transfer to Quality Synthetic
Industries 30,000,000 Limited Surekha Group Transfer to others (Chander
Wadhwa, 18,600,000 Shashank Manohar, etc) transfers to family members
107,310,878 Payment by Stunning Construction Pvt Ltd of 44,510,320 direct tax
Total 376,728,123 By Shiv Priya Advance against property to Gaursons India Ltd
51,00,000 Bathroom products and Marble for home 38,92,668 Furniture 74,76,644
Helicopter services 6,20,000 Watches 19,45,500 Lights, art designing, Bed linen
38,26,290 Jewellery 33,44,475 Quality Synthetic Industries Ltd 1,50,00,000 Cozy
Habitat Builders Pvt Ltd 15,00,000 SN Dubey 10,00,000 Stamp duty for registry of
Jaypee Green Villa 32,50,000 Payment for LIC 3,49,96,654 Investment in mutual
funds 8,86,50,409 Payment of loan for Pearl Gateway Towers 30,84,952 Payment of
loan for Jaguar 23,13,800 Payment of loan from bank of Maharashtra 46,65,200
Total 18,06,66,592 By Ajay Kumar Yogesh Chand 25,00,000 Transferred to Sweep
Account 1,33,00,000 Ozone GSP Infratech 50,00,000 Quality Synthetic Industries
Ltd 40,00,000 Investment in mutual funds 2,25,00,000 Payment of housing loan for
IRS Colony, Abhay Khand, Indirapuram 56,31,000 Payment of housing loan for
Pelican Villa Jaypee Green 37,55,784 Payment for LIC 2,56,53,384 Total 8,23,40,168
Funds transferred from Amrapali group of companies was withdrawn in cash from
personal accounts of directors and diverted to undisclosed people. In case of Anil
Kumar Sharma, it is seen that an amount of is Rs.10.38 crore was withdrawn from
June 2008 to May 2012 within a few days of transfer to bank account of Anil Kumar
Sharma in Bank of Maharashtra. Several times, description of source of receipt or
person to whom payment was made were not clear and such sources or application
could not be identified.
Several companies were incorporated to create assets or to hold investment in the
group companies or outside the group companies having assets. The promoter
directors or their family members became the shareholders in these companies
without investing any paisa. Homebuyer funds were diverted to these companies and
then these companies bought shares from the funds so diverted in the companies
having assets for example Noida hospital in Amrapali Healthcare Pvt Ltd, 5 star hotel
in Ultra Home Construction Pvt Ltd, Institute of hotel management in Noida Texfab
Pvt Ltd etc. Investment from JP Morgan and other funds availed for the purpose of
construction which were not required at all because the funds paid by homebuyer
were in most of the cases were higher than the cost of construction and land
payments, were diverted on the day of receipt itself to the closely held companies and
to the companies created for the sole purpose for using them as a conduit for
diversion and to the suppliers of bogus supplies. It is very surprising that when fundsBikram Chatterji vs Union Of India on 23 July, 2019

were borrowed a high rate of interest was paid ranging from 14 -18% to so called
investors and the same investors were given loans to their group companies without
charging any interest. In such a scenario, the possibility of taking cash in the form of
interest cannot be ruled out.
Directors sold number of flats at low prices as compared to the prices existing on or
near to those dates and on which rates sales were made to other home buyers. It is
further submitted that some of the flats have been sold even at rates as low as is
Rs.1,000 - is Rs.1,400 per square feet which is even lower than the cost of
construction. Possibility of taking cash outside the books of accounts cannot be ruled
out.
Instances of misuse of funds are hereunder:
Anil Kumar Sharma Mr. Anil Kumar Sharma received funds from Amrapali group of
Companies which was used for acquiring personal properties, as stated hereunder:
a. Property located at Plot no 88, 2057/7 Resi magos village Goa- (Housing loan was
paid for this property out of amount received from Group companies) b. Property
located at Jaypee Green E-11 Plot, Sector 128, Noida - (Housing loan was paid for this
property out of amount received from Group companies)
1. Mr. Anil Kumar Sharma purchased shares and securities amounting to is Rs.5.96
crore out of moneys received from Amrapali group Companies.
2. Mr. Anil Kumar Sharma purchased following assets out of amount received from
Amrapali group Companies:
a. Jewelries worth is Rs.3.39 crore b. Car through AMP Motors: is Rs.0.56 crore c.
Life Insurance Policies: is Rs.1.82 crore (based on bank statements available,
although in total amount invested in insurance policies amounted to is Rs.4 crore)
3. Mr. Anil Kumar Sharma made following personal expenses of is Rs.1.35 crore for
wedding of his daughter out of amounts received from Amrapali Group of
Companies:
a. Payment made to Event Management Companies: is Rs.0.90 crore b. Payment
made to hotels: is Rs.0.45 crore
4. Mr. Anil Kumar Sharma made payment of is Rs.8.71 crore to following third
parties out of amounts received from Amrapali Group of Companies:
     a.     Chandan Homes Pvt Ltd: is Rs.10,00,000
     b.     Kalpana Kumari: is Rs.10,00,000
     c.     Sapphire Digital Printers: is Rs.25,00,000Bikram Chatterji vs Union Of India on 23 July, 2019

     d.     Shashank Manohar: is Rs.36,00,000
     e.     Rajesh Malhotra : is Rs.20,00,000
     f.     Manas Nursing Home: is Rs.25,00,000
     g.     Amresh Kumar Anand: is Rs.27,00,000
     h.     Surbhaee Advertising Pvt Ltd: is Rs.3,85,00,000
     i.     Quality Synthetic Industries Limited: is Rs.3,00,00,000
     j.     Chander wadhwa: is Rs.25,00,000
     k.     Mrityunjay Kumar: is Rs.8,00,000
5. Mr. Anil Kumar Sharma made payments of is Rs.10.73 crore to his family members
out of amounts received from Amrapali group of Companies:
a. Deepshikha (Daughter): is Rs.93,50,000 b. Ritik Kumar Sinha (Son in Law): is
Rs.1,40,00,000 c. Swapnil Sikha (Daughter): is Rs.8,39,60,878
6. Mr. Anil Kumar Sharma received RS. 6.55 crore in his bank account from Amrapali
Hospitality during the month of June and July, 2018 for sale of Bareilley mall to
Vaishnavi Vahini Mount Life Hospitality Pvt Ltd. The said amount was immediately
disbursed to family members:
     a.     Self: Rs.4,77,00,000
     b.     Pallavi Mishra (Wife) Rs.60,00,000
     c.     Swapnil Shikha (Daughter) Rs.48,00,000
     d.     Raj Dulari devi (Mother) Rs.52,00,000
     e.     Ranjit Kumar Rs.9,90,000
7. Unexplained cash deposits of Rs.5.73 crore were received by Mr. Anil Kumar
Sharma in his bank accounts from November to December, 2016 i.e during
demonetization period.
8. Mr. Madan Mohan Sharma (Father of Anil Kumar Sharma) received Rs.2 crore
from Amrapali Grand during month November and December, 2007.
9. Unexplained cash deposits of Rs.0.13 crore were received by Mrs. Raj Dulari Devi
(Mother of Anil Kumar Sharma) during from April to July, 2018.
10. Following are the details of lockers held by family members of Anil Kumar
Sharma:
• Pallavi Mishra –
a) in UCO bank account no 1557010000618
b) in HDFC Bank account no 50100162844761 locker no 9250500004564240 • Raj
Dulari Devi in Yes Bank account no 8599300000716, Locker no 11606082018Bikram Chatterji vs Union Of India on 23 July, 2019

11. There are substantial transactions with Amrapali Aadya Trading in his bank
account of IndusInd Bank Account no.100028567700 as per details given below:
Date             Particulars                      Receipts       Payments
16/07/2014       Neft-Amapali Aadya Trading         2,500,000         -
14/08/2014       Neft-Amapali Aadya Trading         1,000,000         -
14/11/2014       Neft-Amapali Aadya Trading         2,500,000         -
21/01/2015       Neft-Amapali Aadya Trading           500,000         -
15/04/2015       RTGS- Amapali Aadya Trading            -          1,000,000
15/04/2015       Neft- Amapali Aadya Trading            -          1,000,000
24/04/2015       RTGS- Amapali Aadya Trading            -          2,000,000
29/04/2015       RTGS- Amapali Aadya Trading            -          1,000,000
06/05/2015       RTGS- Amapali Aadya Trading            -          2,000,000
08/05/2015       RTGS- Amapali Aadya Trading            -          2,000,000
13/05/2015       RTGS- Amapali Aadya Trading            -          2,000,000
27/05/2015       RTGS- Amapali Aadya Trading            -          2,000,000
19/05/2015       RTGS- Amapali Aadya Trading       18,500,000         -
23/06/2015       RTGS- Amapali Aadya Trading            -          1,000,000
30/07/2015       RTGS- Amapali Aadya Trading            -          1,500,000
21/08/2015       RTGS- Amapali Aadya Trading            -          2,000,000
25/08/2015       RTGS- Amapali Aadya Trading            -          2,500,000
27/08/2015       RTGS- Amapali Aadya Trading            -            400,000
27/08/2015       RTGS- Amapali Aadya Trading            -          3,600,000
09/09/2015       RTGS- Amapali Aadya Trading            -          1,500,000
20/08/2016       RTGS- Amapali Aadya Trading        1,500,000         -
Total                                             26,500,000     25,500,000
  •     Note: He has not disclosed his association With Amrapali Aadya Trading in
his various affidavits furnished to the Hon’ble Supreme Court of India.
Shiv Priya
1. Mr. Shiv Priya received funds from Amrapali group of Companies which was used for acquiring
personal properties, as stated hereunder:
a. Property located at L 801, Pearl Gateway Towers, Sector 44, Noida
-(Housing loan was paid for this property out of amount received from Group
companies) b. Vehicle- Jaguar XJ having registration number UP16BA2001- (Loan
was paid out of amount received from Group companies)
2. Mrs. Sonali Suman (Wife of Shiv Priya) made investments in different mutual funds amounting to
Rs.8.86 crore out of amounts received from Amrapali group of Companies.
3. Mr. Shiv Priya purchased following assets out of amounts received from Amrapali group of
companies:Bikram Chatterji vs Union Of India on 23 July, 2019

  a.    Jewelleries: Rs.33,44,475
  b.    Life Insurance Policies Rs.3,49,96,654
  c.    Watches Rs.19,45,500
4. Mr. Shiv Priya made following personal expenses of Rs.2.74 crore out of amounts received from
Amrapali group of companies:
a. Expenditure made for Residential property (Marbles, bathroom products, lights
etc) Rs.56,53,268 b. Helicopter services Rs.6,20,000 c. Art designing Rs.10,00,000
d. Bed Linen, Table linen and art designing Rs.20,36,290 e. Wooden doors and
Furnitures: Rs.74,76,644 f. Payment made for clearing dues of American Express
Credit Card: Rs.1,06,78,273
5. Mr. Shiv Priya made payment of Rs.1.75 crore to following third parties out of amounts received
from Amrapali Group of companies:
a. Quality Synthetic Industries Limited Rs.1,50,00,000 b. Cozy Habitat Builders Pvt
Ltd Rs.15,00,000 c. S N Dubey Rs.10,00,000
6. Unexplained cash deposits of Rs.6 crore were received by Mr. Shiv Priya in his bank accounts
during December, 2016 i.e during demonetization period.
7. Mrs. Sonali Suman (Wife of Shiv Priya) re-paid loan from bank amounting to Rs.0.45 crore out of
amount received from Amrapali group of Companies. It is to be seen what the purpose was for
which the bank granted loan for 6 months for the said amount.
8. Shiv Priya is holding demat account no 1206420001934748 and Sonali Suman is holding demat
account no 1206420001936308 with HDFC bank, of which details have not been provided to us.
9. Mrs Sonali Suman holds mutual funds with HDFC mutual funds Folio no 11707520/73, which
have market value amounting to Rs.0.65 crore as on 28th February 2019.
10. A sum of Rs.0.45 crore was paid by M/s Royal Golf Link City Projects Private Limited to Mr.
Shiv Priya during the financial Year 2016-17 which was not declared by him in the various Affidavits
filed in the Hon’ble Supreme Court.
11. There was an income tax search in the premises of Amrapali Group of Companies and the
residence of the directors in the month of 7th and 8th August, 2013. During this search operation
unaccounted cash was seized from the residence of directors namely Shri Shiv Priya amounting to
Rs 1 Crores. Unexplained jewellery was also seized from the residence of Mr. Shiv Priya amounting
to Rs 0.58 Crores. Thus, it apparently shows that he has unaccounted cash.
Ajay KumarBikram Chatterji vs Union Of India on 23 July, 2019

1. Mr. Ajay Kumar received funds from Amrapali group of Companies which was used for acquiring
personal properties, as stated hereunder:
a. Property located at Plot no: A-014 Savanna Villas, Jaypee Greens Sector-128,
Noida; the property was not disclosed in affidavit submitted on 3rd December, 2018
-(Housing loans was paid for this property out of amount received from Group
companies) b. Property located at IRS colony, Abhay Khand, Indirapuram,
Ghaziabad- Rs.1.38 crore.
c. Property located at Plot No: A-014, Pelican Villa Jaypee Green Noida 201301-
Rs.1.11 crore.
2. Mrs. Seema Kumari (Wife of Ajay Kumar) made investments in different mutual funds amounting
to Rs.2.25 crore out of amounts received from Amrapali group of companies during August to
September, 2018.
3. Mr. Ajay Kumar made investments in Life insurance Policies of Rs.2.59 crore out of amounts
received from Amrapali group of companies.
4. Mr. Ajay Kumar made payment of Rs.1.25 crore to following third parties out of amounts received
from Amrapali Group of Companies:
      a.     Yogesh Chand Rs.25,00,000
      b.     Ozone GSP Infratech Rs.50,00,000
      c.     Quality Synthetic Industries Ltd Rs.50,00,000
5. Mr. Ajay Kumar made investment of Rs.1.12 crore in Ultra Home Construction as Share Capital
out of amounts received from Amrapali group of companies.
6. Mr. Ajay Kumar made payment of direct tax of Rs.0.11 crore out of amounts received from
Amrapali group of companies.
7. Mrs Seema Kumari holds mutual funds with HDFC mutual funds Folio no 14756739/01, which
have market value amounting to Rs.0.48 crore as on 28th February 2019.
8. Bank Statement of Anandi Singh of IndusInd Bank Account no.150019032006 A sum of Rs.1.73
crore has been transferred from Seema Kumari on 09/08/2018.
Further a sum Rs.2.25 crore has been invested in Mutual Funds as per details given below:
       Date            Particulars                 Amount
       16/08/2018      Mirae Asset MF              5,000,000
       16/08/2018      Aditya   Birla  Mutual      5,000,000
                       Fund
       18/08/2018      Kotak Mutual Fund           5,000,000
       11/09/2018      HDFC Mutual Fund            5,000,000Bikram Chatterji vs Union Of India on 23 July, 2019

       12/09/2018      Tata Mutual Fund            2,500,000
       Total                                       22,500,000
Note: This amount can be attached and recovered by encashment of these investments.
Sunil Kumar and Sunita Kumari (wife of Sunil Kumar)
1. While scrutinizing the Accounts of Gaurisuta Infrasolution Private Limited in which Mr. Sunil
Kumar was the Director, it was observed by us that bogus commission of Rs.1.07 crore was booked.
This amount of Rs.1.07 crore should be recovered from Mr. Sunil Kumar.
2. A sum of Rs.0.50 crore has also been paid as Salary to Mrs. Sunita Kumari in M/s Gaurisuta
Infrasolution Private Limited which is not genuine as per detailed report given in the case of M/s
Gaurisuta Infrasolution Private Limited. This Amount of Rs.0.50 crore should also be recovered
from Mrs. Sunita Kumari.
Mr. Sudhir Kumar Choudhary He is director in Amrapali Biotech India Private Limited & Gaurisuta
Infrasolution Private Limited. As per his statement recorded, he was forced to become the director
in first week of august 2018 with effect from 06th July 2018.
We are of the view that this planning has been done by the Amrapali Management after the order of
the Hon’ble Supreme Court to accept the resignation of Mrs. Seema Kumari Wife of Sunil Kumar
from the Directorship and to appoint Mr. Sudhir Kumar Choudhary as the director of the company.
It was further explained by him that he was a mere employee only and by virtue of threat by the
Amrapali Group of Companies, he was forced to become the Director of Amrapali Infrasolution
Private Limited. Apart from above specific points, it shall be noted that we had got access to the
email of the Accounts department of Amrapali Group of Companies with Id accounts@amrapali.in
for a short period after interrogation from an Ex-employee. We could download few instances of
Cash transactions which are enclosed as a sample in Annexure 26-B. The access to this mail was
stopped immediately. We requested the management to give the access to this mail to enquire into
the further such mails related to the cash and other accounting adjustments contained in this Email
Account. But this access was not made available to us.
However, the access had been made available after the orders of the Honorable Supreme Court
dated 28th February, 2019. Now, all the mails relating to receipt of cash from the various home
buyers have been deleted. Thus, the management of the company has tempered with the evidence
which were available earlier. (Page No. 205 Volume-I) Further an amount of Rs.113.5 crore paid by
Amrapali Infrastructure Pvt Ltd to directors is recoverable as on 31st March 2018 and this amount is
on account of shares allotted of Ultra Home Construction Private Limited to the directors without
receiving any money from the directors during the Financial Year 2010-11. This seems to be a
dubious transaction by the directors of the company in manipulating the accounts in this manner by
allotting the shares without actual consideration. These amounts are not disclosed by the Directors
in their Affidavits. Hence, the Affidavits filed by the directors are incorrect to this extent.Bikram Chatterji vs Union Of India on 23 July, 2019

10. Executives who colluded with directors The executives of the Group colluded with the
management to avoid proper recording of transactions in books of accounts. To avoid the
traceability of the transactions, the executives recorded the financial transactions up to March 2015
in Accounting Package tally, then shifted to FARVISION from April 2015 and continued till March
2016, and thereafter partially recorded transaction in tally and a for a few companied in
FARVISION. At the time of switchover, even the opening balances were not properly entered,
thereby leading to a huge difference in the data provided to us. In November 2016, the Group left
Farvision half way and started recording transactions for partial period in tally. The executives
intentionally recorded transactions by switchover of accounting package improperly so that
complete trail could not be established. Subsequently, the companies of the group even stopped
getting the annual accounts prepared and filing returns to ROC and Income tax The Sales and
Marketing head Mohit Gupta, CFO Chandar Wadhwa, Accounts head Adhikari Das, Company
Secretary Pankaj Mehta and the Architect Vaibhav Jain along with their immediate coterie extended
helping hand to the management in planning and execution of the scam.
Mr. Mohit Gupta – Marketing Director He was responsible for the whole marketing department,
Customer Relationship Management of the Amrapali Group and he did not cooperate during the
entire process of forensic audit. It is pertinent to note that till now a list of flat wise possession has
not been provided to us.
At first he did not submit us the customer data inspite of number of reminders. Subsequently, the
customer data submitted was not correct. We found the following–
(i) The inventory of vacant flat submitted by him was incorrect.
(ii) We found 401 flats (Refer Annexure S-5 page 2828-2836 Supplementary report) which were
either lying vacant and were available in inventory because the flat buyers were shifted out of
Amrapali Group to the other project of other builders. Mr. Mohit Gupta also did not disclose the
details of flats booked in the name of various parties without receipt of any amount from them just
by passing journal entry.
(iii) From the above it is clear that it defies the order of Honorable Supreme Court and has violated
the order and is responsible for the gross contempt of the Honorable Court.
Mr. Adhikari Debi Prasad Dash- GM/DGM Accounts It is found that Mr. Adhikari authorized (Refer
Annexure S-6 page 2837-2841 Supplementary report) most of the payments regarding payment of
professional charges, raw materials, contractor dues and other direct/indirect expenses. It is
pertinent to note that he was also involved in diversion of funds from Amrapali group and equally
responsible in the conspiracy of cheating with home buyers and diversion of funds.
He was responsible for the whole accounts department and he did not cooperate during the entire
process of forensic audit. He was authorized to receive payments in cash and was submitting on day
to day basis cash receipt status to Mr. Shiv Priya. After a clearance from him, a possession slip or no
due certificate is issued. He continuously replied that he is not aware of anything and for everythingBikram Chatterji vs Union Of India on 23 July, 2019

there were Chartered Accountants for respective companies. This is not a correct statement and he
contradicted his own statement many times. He was in possession of final accounts of group
companies and did not share with us.
Adhikari Dash also did not disclose the details of flats booked in the name of various parties without
receipt of any amount from them just by passing journal entry.
From the above it is clear that it defies the order of Honorable Supreme Court and has violated the
order and is responsible for the gross contempt of the Honorable Court.
He along with his brother exercised direct control over below companies:
(i) Teks Tech Inspection India Private Limited
(ii) Teks Tech IT Services India Private Limited
(iii) Vinayaka Square Private Limited
(iv) Shri Vinayaka Buildspace Private Limited
(v) Milestone Highrise Private Limited Vinayaka Square Private Limited • The
company has a commercial project named “Beta Plaza” at Greater Noida which
received funds from Teks Tech Inspection India Private Limited (controlled by Mr.
Adhikari), APJ Finmart Private Limited, Opulent Inn Private Limited, Tasty Feast
Private Limited, Opulent Holidays and Travels (P) Limited. The chairman of four
companies CA Pankaj Mittal appeared before us and could not explained the reasons
for giving loans @ 6% p.a. to a real estate project whereas the bank rate on FDR is 7%
and more.
• The company has purchased this land for the project at Greater Noida in FY 2015-16 amounting to
Rs.17.09 crore • Vinayaka Square received Rs 1 crore from Amrapali funds routed through Teks Tech
Inspection India Private Limited and received Rs.2.56 crore from Shri Vinayaka Buildspace Private
Limited. This is a project funded by Amrapali’s Funds and shall be attached. Mr. Chander Wadhwa
CFO Amrapali Group of Companies It has also been observed that a sum of Rs.5 crores was
transferred by M/s Amrapali Homes Project Private Limited to Mr. Amit Wadhwa, nephew of Mr.
Chander Prakash Wadhwa. As per the affidavit filled by Mr. Chander Prakash Wadhwa the said sum
was invested by him in M/s Three Platinum Softech Private Limited. The Heartbeat city projects is
partly owned by three Platinum and Amrapali group has invested in the projects in the name of
Chander Wadhwa.
As per Statement of Mr. Sanjeev Kumar Director of La Residentia Developers Private Limited
recorded by us, he Informed that a sum of Rs.4 crores Approximately, was paid as fees for use of
Amrapali Brand Name to Saffron Propmart Private Limited (This Company is controlled by Mr.
Chander Wadhwa CFO). No Bills have been provided by him. Statutory Auditor CA Anil Mittal andBikram Chatterji vs Union Of India on 23 July, 2019

Shri Chander Wadhwa CFO were in connivance with each other and payments were made by Shri
Anil Mittal to Chander Wadhwa CFO for sharing fees received from Amrapali group for the work
awarded to Anil Mittal Chander Wadhwa is one of the masterminds along with the other promoters
directors behind the whole scam. He facilitated movement of funds by creating a web of companies
within and outside the group. His relatives were made partner investor in LA Residentia and Heart
beat city projects. Funds were invested in Patel Advance JV (Neo Town project Noida) and Euphoria
Sports City.
Furthermore, it is observed that the Company Management as well as Statutory Auditors and CFO
have failed in their duty to follow the Accounting Standards relating to recording the valuation of
Work in Progress as per ICAI guidelines applicable to Real Estate Companies. It is also pointed out
that the CFO has not signed any Audited Financial Statements for reasons best known to them. But
according to the statement recorded by us of various employees and suppliers as well as home
buyers, we are informed that he was the main person handling Finance and every meeting was held
with him only. (page no 209 Volume 1) Mr. Pankaj Mehta –Company Secretary He was responsible
for the secretarial compliances of the companies. He incorporated more than 50 additional
companies to create a cobweb. He was a director in many of these companies and was an important
link in the transfer of funds through various group companies. He was also signatory to the bank
account of Stunning Construction Private Limited. He resigned from the services of the Company in
December, 2016. However even after his resignation, on the instructions of Mr. Chander Wadhwa,
CFO, he continued to operate the Bank Accounts of Stunning Construction Private Limited. After his
resignation in the Amrapali Group, he started working as a partner of Saffron Consultants LLP with
Mr. Chander Wadhwa. Also Mr. Anil Kumar is still working as an employee with Mr. Chander
Wadhwa.
On the instructions of Mr. Chander Wadhwa CFO manipulative entries were recorded for
adjustment of payment dues of Mr. Pankaj Mehta against his Flat No. E-1502, Silicon City, Sector -
76, Noida.
11. Non compliance of statutory obligations
(i) The group companies have not filed annual returns and Audited Financial Statements after 31st
March, 2015. The Registrar of Companies has already disqualified the Directors namely Mr. Anil
Kumar Sharma, Mr. Amresh Kumar, Mr. Shiv Priya, Mr.Ajay Kumar and Mr. Suvash Chandra
Kumar for a period of 5 years from 1/11/2017 to 31/10/2022 u/s 164(2) of The Companies Act, 2013.
(ii) The company has not been regular in payment of TDS and Service tax and has also not filled
relevant returns of TDS/Service tax after 31st March, 2015. There is also no follow up available from
the Concerned departments.
Latest information regarding status of default in respect of TDS/ Service tax is not made available to
us. There may be huge demands outstanding against the company due to non-payment and
non-filing of TDS/Service tax returns.Bikram Chatterji vs Union Of India on 23 July, 2019

(iii) No Statutory records have been maintained by the Amrapali group companies and produced
before us relating to the following:
i. Register of Directors and shareholders ii. Register of related party contracts iii.
Minute book of Director and Shareholders iv. Fixed Assets Register v. Charges
register in respect of loans taken from Banks and others
(iv) Transfer entries are recorded in Inter Corporate Deposit accounts by transferring
the amount from one Amrapali group company to another Amrapali group company
in contravention of section 269SS/269T of The Income Tax Act, 1961.
(v) Depreciation has not been provided on the building in contravention of the
provisions of the Companies Act, 1956, now Companies Act, 2013 in Navodaya
Properties Private Limited.
It is highly surprising that in spite of such glaring discrepancies regarding non-Compliance of
statutory compliances, the Statutory Auditors have not pointed out any such discrepancies in their
Statutory Audit Reports.
There are many other glaring short comings in the Audited Balance Sheet & Financial Statements
a) I – Page 214)
12. Anil Mittal - Statutory Auditor While scrutinizing the affidavit submitted by Shri Anil Mittal Date
12/11/2018 before the Hon’ble court we have noted the following:
a) CA Anil Mittal was paid Rs.0.56 crore (Rs.0.66 crore less Rs.0.10 crore recovered)
during the period 2011 to 2018. These payments have been shown in the nature of
cheques given /credit card payments which have been never been recovered.
b) Statutory Auditor CA Anil Mittal and Shri Chander Wadhwa CFO were in
connivance with each other and these payments have been made by Shri Anil Mittal
to Chander Wadhwa CFO for sharing fees received from Amrapali group for the work
awarded to CA Anil Mittal. CA Anil Mittal blindly signed all the accounts and is
grossly involved along with Mr. Chander Wadhwa in making various manipulation in
the accounts.
c) Audit files handed over by Shri Anil Mittal Statutory Auditor are grossly deficient
and they do not contain the documents which are normally required in the statutory
audit files as per guidelines and directions issued by The Institute of Chartered
Accountants of India.
d) Statutory Auditor CA Anil Mittal has received the payment on account of
professional charges in the name of the companies in which his relatives areBikram Chatterji vs Union Of India on 23 July, 2019

directors. This fact has not been disclosed in audited financial statements.
e) A sum of Rs.52.07 crore was adjusted against the payment due on account of Flat
number P-1203 in Amrapali Princely Estate on account of professional fees due and
to be paid on account of Audit fees.
f) Further a sum of Rs.16.36 crore was also adjusted against the flat number P-1104 in
Amrapali Princely Estate on account of Professional fees due and to be paid on
account of Audit fees.
13. Diversion of homebuyers funds Amrapali Group was engaged in diversion of home buyer funds
from one project to another project, other group companies, directors and senior executives of the
group. There is also a diversion of funds to various suppliers where advances were made without any
further adjustment/ transactions.
There is not only diversion of funds, there is siphoning of funds also by way of booking undervalued
transactions in respect of sale of flats, by way of booking of expenses, and making purchases from
the bogus suppliers/service providers.
In addition to this they adopted fraudulent practices also by way of double booking of flats. There
are also instances of adjustment of amounts payable to suppliers/brokers with the amount due from
the home buyers such trade creditors have denied having any knowledge of such transactions.
We have traces of receiving of Cash from the home buyers/ others as shown by the email of the
accounts department of the Amrapali Group of Companies which is not accounted for in the books
of accounts. There is also allotment of shares without inward movement of funds by making
manipulative entries in the books of accounts. The homebuyers funds were diverted Rs. 5,619.47
crore to other companies/directors:
(i) through payment of professional fee to directors Rs.100.53 crore;
(ii) by way of booking of bogus bills including commission Rs.842.42 crore;
(iii) by selling flats at undervalued prices in books and received differential market
value in cash Rs.321.21 crore; (it is a tip of iceberg)
(iv) by way of granting inter corporate deposits to related entities and unrelated
entities / trusted partners for ultimately diverting funds to unapproved uses.
Summary of diversion of funds is as under:
Name of Company Details of amount diverted (Amount in crores) First Bogus
Expense Advances Undervalued Cash Diversion page no 2827 of recoverable flats
supplementary from third page no 2811 report parties of (Rs.234.21 supplementarBikram Chatterji vs Union Of India on 23 July, 2019

crore plus y report Rs.326 crore Volume IV, page no 1015-
                                                     1019)
ULTRA HOME
CONSTRUCTION
PRIVATE LIMITED          -           333.00             87.68            30.87     0.22
AMRAPALI HOMES
PROJECTS
PRIVATE LIMITED          -              4.41            55.01                 -    0.23
AMRAPALI
PRINCELY
ESTATE PRIVATE
LIMITED             186.99             56.78                 -            6.70     5.02
AMRAPALI
SAPPHIRE
DEVELOPERS
PRIVATELIMITED      113.98             85.45            73.06            76.02     0.11
AMRAPALI
SILICON CITY
PRIVATE LIMITED     391.57             97.87            50.41            73.05     3.58
AMRAPALI EDEN
PARK
DEVELOPERS
PRIVATELIMITED           -             12.67             3.02                 -      2
AMRAPALI
ZODIAC
DEVELOPERS
PRIVATELIMITED      286.00             70.60            28.07             6.75     3.84
AMRAPALI
CENTURIAN PARK
PRIVATE LIMITED     518.78              5.20                 -           43.12     7.45
AMRAPALI DREAM
VALLEY PRIVATE
LIMITED             445.33              5.63             3.23            24.11     8.02
AMRAPALI
LEISURE VALLEY
DEVELOPERS
PRIVATE LIMITED     237.53             26.45            19.67             5.88     0.23
AMRAPALI
LEISURE VALLEY
PRIVATE LIMITED     431.11             16.20            51.62             8.53     9.79
AMRAPALI SMART
CITY
DEVELOPERS
PRIVATELIMITED      538.59             39.27            17.20            18.97    10.79
SANGAM
COLONIZERS
PRIVATE LIMITED          -                 -             0.36                 -    0.15
SHALIMAR
COLONISERS
PRIVATE LIMITED     -       -        -   -     -Bikram Chatterji vs Union Of India on 23 July, 2019

HI-TECH CITY
DEVELOPERS
PRIVATE LIMITED   2.42    1.96    8.91   -   0.46
AMRAPALI
HEALTHCARE
PRIVATE LIMITED     -       -     0.22   -     -
AMRAPALI
HOSPITALITY
SERVICES
PRIVATE LIMITED     -     0.02   13.55   -   0.01
AMRAPALI
INFRASTRUCTUR
E PRIVATE
LIMITED             -    65.61   40.24   -   3.16
MSB SOFTWARE
TECHNOLOGY
PRIVATE
LIMITED.            -       -        -   -   0.70
MUMS MEGA
FOOD PARK
PRIVATE LIMITED     -       --    1.29   -
MVG TECHNO
CONSULTANTS
PRIVATE LIMITED     -       -        -   -   0.13
NAVODAYA
PROPERTIES
PRIVATE LIMITED     -       -        -   -   0.24
NOIDA TEXFAB
PRIVATE LIMITED     -       -        -   -   0.13
AMRAPALI
AEROCITY
PRIVATE LIMITED     -       -     0.01   -
AMRAPALI
BIOTECH INDIA
PRIVATE
LIMITED.            -       -        -   -    1.5
AMRAPALI
BUDDHA
DEVELOPERS
PRIVATELIMITED      -     0.65    0.47   -     -
AMRAPALI
MAGADH
DEVELOPERS
PRIVATELIMITED      -       -        -   -     -
AMRAPALI MAHI
DEVELOPERS
PRIVATE LIMITED     -       -        -   -
AMRAPALI MEDIA
VISION PRIVATE
LIMITED             -       -     4.96   -   9.67
AMRAPALI POWER
AND CEMENTS
PRIVATELIMITED      -       -     0.91   -      -Bikram Chatterji vs Union Of India on 23 July, 2019

AMRAPALI SMART
CITY PRIVATE        -     8.02    0.95   -    0.5
LIMITED
AMRAPALI
SPRING VALLEY
PRIVATE LIMITED              -               -                   -                -       -
HAWTHORNE
INTELLECT
MANAGEMENT
SOLUTIONS
PRIVATE LIMITED              -               -             0.17                   -     0.01
NEELKANTH
BUILDCRAFT
PRIVATE LIMITED              -               -                   -                -       -
GAURISUTA
INFRASTRUCTUR
E PRIVATE
LIMITED                      -               -             0.46                   -     0.02
KAPILA
BUILDHOME
PRIVATE LIMITED              -               -             0.41                   -     0.03
STUNNING
CONSTRUCTIONS
PRIVATE LIMITED              -               -            15.04                   -     0.17
JHAMB FINANCE
AND LEASING
PRIVATELIMITED               -               -             5.93                   -       -
MANNAT
BUILDCRAFT
PRIVATE LIMITED              -               -             0.99                   -     0.20
RUDRAKSH
INFRACITY
PRIVATE LIMITED              -               -                   -                -       -
GAURISUTA
INFRASOLUTION
PRIVATE LIMITED              -               -             1.24                   -     0.01
LA RESIDENTIA
DEVELOPERS
PRIVATE LIMITED              -               -            23.35                   -      0.3
Amrapali Grand               -            3.98            29.17                   -      0.5
AHS Joint Venture            -            0.08            15.81                   -
Amrapali Homes               -            2.86            21.41                   -     0.19
Amrapali Patel
Platinum                     -               -             7.85                27.31      -
Hi Tech City
Developer Pvt Ltd                         7.30
Total                  3,152.30        842.42           582.68                321.31   69.36Bikram Chatterji vs Union Of India on 23 July, 2019

         Particulars                                                 Amount in
                                                                     crores
         Grand Total                                                      4,968.07
         Further Gaurisuta Infrastructure Private Limited gave                25.00
Rs 25 crore advances to various parties as listed on page no 92-93 Volume I Further
in Gaurisuta Infrastructure Private Limited, 89.00 inventory of Rs 89 crore
unidentifiable page no 96 Volume I FDR as on 31st March 2015 page no 175 Volume I
61.97 Professional Fees Paid to Directors 100.53 Taxes paid by Stunning
Construction on behalf of 24.90 promoters and family More than 700 flats given to
so called suppliers 350.00 Total diversion identified 5,619.47
14. J P Morgan Amrapali Zodiac Developers Private Limited has financed this transaction by its own
shares through Group Companies by incorporating new Companies. These transactions enable
Amrapali Zodiac Developers Private Limited to avoid the provisions of The Companies Act, 1956
applicable for buying its own shares. It is also relevant to point out that Shri Anil Mittal at any stage
of time has not reported his interest or disclosed about his relatives of Director and Junior
Employee. Both the directors and shareholders of the company i.e Mr. Atul Mittal (Relative) and
Mr. Chandan Kumar (Junior Employee), are relatives/employee of Anil Mittal, the Statutory
Auditor of the company.
a) Rudraksh Infracity Private Limited- Shri Chandan Kumar, an employee of CA Anil Mittal,
Statutory Auditor and Shri Atul Mittal, relative of CA Anil Mittal were inducted in the board. The
basic purpose of this Company was only for money laundering and was incorporated to receive
Funds from Mannat Buildcraft Private Limited which Company was incorporated by CFO Chander
Wadhwa through his close associates. After receiving money from Mannat Buildcraft Private
Limited, the same was transferred to J.P. Morgan Investments for purchase of Equity Shares of
Amrapali Zodiac Private Limited at an exorbitant price. As per details furnished hereunder, the
Valuation Report was also made to suit to the requirement of J.P. Morgan Investments as the M/s
Sudit K. Parikh & Company, Chartered Accountants were appointed by J.P. Morgan officials for the
said valuation. They have admitted that valuation work was done on the basis of information
provided by J.P. Morgan Investments after applying some basic checks.
The whole racket of money laundering and receiving money from these Companies i.e. Mannat
Buildcraft Private Limited and Rudraksh Infracity Private Limited are the brain child of Mr.
Chander Wadhwa, CFO and Anil Mittal, Statutory Auditor of Amrapali Group of Companies. Both
these Companies are controlled by both of these persons and had been formed only for this Money
Laundering Business. There are no transactions before or after these transfers of money and the
same have been camouflaged to make it look with business transactions on the basis of the
Valuation Report. JP Morgan invested Rs.85 crore in the year 2010 with an understanding to have a
preferential claim on profits called distributable surplus in the ratio of 75% to JP Morgan and 25%
to promoters namely Amrapali Homes Project Private Limited and Ultra Home Construction PrivateBikram Chatterji vs Union Of India on 23 July, 2019

Limited with the following main condition in Shares Subscription Agreement dated 9th September,
2010 amongst Ultra Home Construction Private Limited, Amrapali Homes Project Private Limited,
JP Morgan & Amrapali Zodiac Developers Private Limited The Company shall provide evidence of
the aforesaid investment in the Investee Company to the Investor. (Rs. 60 Cr. in Leisure Valley
Developers) (A) There was a prescribed methodology and procedures defined of computation of Fair
Market Value at the time of the exit to be worked out in the agreement on Page No 51, schedule 6 of
Shareholder’s Agreement, which was not followed at the time of any of the exits. Clause 4.2 (iii) –
The Company shall grant an interest free loan of Rs 85,000,000 (Rupees Eighty Five Million Only)
to UHCPL. Clause 4.2(iv) – The Company shall remit Rs 600,000,000 (Rupees Six Hundred Million
Only) to the Investee Company for subscribing to 0.01% compulsorily convertible Preference shares
of the Investee Company (“Investee Company Shares”) (B) Distribution of profit was agreed
between the Investor i.e., JP Morgan & the Investee i.e., Amrapali Group to share the profits from
the project in the agreed ratio as per clause 7.3 & Clause 7.5.1 Page No 19 of Shareholder’s
Agreement.
(C) Clause 7.1 - The Company agrees and undertakes that it shall, and the Investor and Developers
agree that they shall cause the Company to first utilize the revenues (less the cost of construction of
the project, provision for future consideration cost of the Project, payment of Project Land cost and
interest thereon, annual lease rent payment to New Okhla Industrial Development Authority and
one time land lease cost) towards payment of applicable taxes and payment of interest to the
lenders, if any, in accordance with the provisions of Law.
Clause 7.2 – Post the payment of taxes and interest to the lenders, as aforesaid, the Company shall
make payments of all principal amounts accrued and payable to the lenders, if any, at applicable
seniority. (D) In clause 2.12 of Page No 12 of Shareholder’s agreement it was agreed that the
aggregate advances outstanding from the Amrapali Zodiac developers Private Limited to its affiliates
will not exceed Rs 25 crores excluding Amrapali Infrastructure Private Limited. It was also in the
knowledge of JP Morgan vide clause 2.14 of Page No 12 of Shareholder’s Agreement that advances to
Amrapali Infrastructure Private Limited which was Rs 51 crore on 31st July, 2010 will be restricted
to Rs 15 crore.
(E) Clause No 10.4.3 in page No 21 of Shareholder’s Agreement mentions that no action can be
taken without investor’s approval in relation to 10.4.3(xi) any payments made to related parties. (F)
It was also mentioned in the agreement that statutory auditor and internal auditor cannot be
appointed and removed without the approval of JPMorgan.
(G) The following points indicate very clearly that JP Morgan was having full control on Amrapali
Zodiac Developers Private Limited project and no material decision could have been taken without
JP Morgan approval.
On Page No 60 of Shareholder’s Agreement in Note 1 it was agreed & accepted that any surplus cash
flow from the project will be first utilized for payment of land cost to Noida Authority. Documents to
be submitted by Amrapali Zodiac Developers Private Limited to JP Morgan:Bikram Chatterji vs Union Of India on 23 July, 2019

(i) Monthly progress report signed by director & CFO.
(ii) No delay report in specified format.
JP Morgan insisted that the cost shall be restricted to Rs 425 crore and any additional
cost over and above Rs 425 crore shall be brought in by Amrapali Group promoter.
The additional cost considered was Rs 125 crore to be brought in by promoters.
(H) Zodiac has followed recognition of revenue on the basis of Project Completion Method –
Accounting Standard - 7 (Construction Contracts). As per Project Completion Method as given in
Accounting Standard – 7, the profit cannot be recognized until the project is completed and as per
Clause No 7.3 of Shareholder’s Agreement the distributable amount is the balance amount
representing the aggregate of all profits, after considering the payments referred to in clause 7.1 and
7.2 , including any amounts transferred to the reserves accounts of the Company shall for the
purpose of this clause 7 are referred to as the “Distributable Amount”. (I) From the above it is clear
that in absence of recognition of profit in the agreement there cannot be any distributable amount
for distribution.
(J) It was accepted by Mr Suraj Chhabria of JP Morgan (Apollo) that the money invested by them in
Amrapali Zodiac Developers Private Limited was not utilized in the project. He also accepted that it
was in their knowledge that money invested by them was not going to be utilized in Amrapali Zodiac
Developers Private Limited project and it is contracted that Rs 60 crores to Amrapali Leisure Valley
Developers Private Limited, Rs 8.5 crores to Ultra Home Construction Private Limited be
transferred. (K) JP Morgan was in knowledge of that the Company Amrapali Zodiac Developers
Private Limited has paid the money received from the Home buyers to tthe other Companies of
Amrapali Group. (L) JP Morgan permitted a transfer of Rs 140 crore to Mannat Buildcraft Private
Limited and from Mannat Buildcraft Private Limited to Neelkanth Buildcraft Private Limited and
Rudraksh Infracity Private Limited for buying shares from JP Morgan of Amrapali Zodiac
Developers Private Limited. There were always advances exceeded than the limits specified in
Shareholder’s Agreement but JP Morgan did not ensure bringing back the money from the affiliates
though it was having its board representation in the ratio3:2. JP Morgan did not ensure that the
funds for additional cost were brought in and in valuation it was assumed that additional cost of Rs
125 crores will be brought in by the promoter for the last lag of the construction for its IRR (Internal
Rate of Return) working. (M) JP Morgan was getting return at the rate of more than 20 % on its
investment of Rs 85 crore & was agreeing with Amrapali Zodiac Developers Private Limited to invest
in Amrapali Leisure Valley Developers Private Limited a substantial part of its investment i.e., 60
crore out of Rs 85 crore at the rate 0.01%. It categorically demonstrates that JP Morgan invested Rs
60 crore in Amrapali Leisure Valley Developers Private Limited without complying FEMA (Foreign
Exchange Management Act) for its investment of Rs 60 crore in Amrapali Leisure Valley Developers
Private Limited. It is not out of place to mention that Amrapali Zodiac Developers Private Limited
was a project where home buyers were required to pay on the basis of progress of the construction of
the project. Meaning it was construction linked payment project.Bikram Chatterji vs Union Of India on 23 July, 2019

(N) We found that most of the time customers have paid more than what was spent in the project.
The Amrapali Zodiac Developers Private Limited diverted home buyer’s money & there was no need
of any investment from JP Morgan. It was accepted by Mr Suraj Chhabria that there was no
restriction on the Company to invest the money in the project & it was in his knowledge & the
knowledge of JP Morgan that the money has been diverted, Transferred Valuation (A) The valuation
did not follow the correct methodology of DCF (Discounted Cash Flow). The valuation is without
any sanctity & validity. The valuation was carried out to cause wrongful loss to the homebuyers of
Amrapali Zodiac Developers Private Limited and to give advantage to JPMorgan.
(B) Name of the firm – Sudit K. Parekh & Co.
Chartered Accountants Name of the Partners– I. Mr. Durgaprasad Khatri II. Mr. Tanwir Shirolka
III. Mr. Srikant V Jilla IV. Ms. Deepti K.Ahuja Ms Ahuja, then partner in SKP&Co.Chartered
Accountants informed that JP Morgan, Mumbai office in Andheri/ Santacruise did not allow to take
any of the details/ abstract from the share purchase agreement. It is to note that at the time of exit,
it was predetermined that Zodiac Developers would not pay the lease rent as well as the installment
due to Noida Authorities as clearly explained in the cash flow statement provided by the SKP&Co in
4 no. of valuation certificates from2010- 2015.
 Valuation            No of    Face     Value per   Total amount      Date of FC-    Sold to
Report date          shares   Value      share *                         TRS
9/09/2010           785715    10      1081.8172     85,00,00,00     20/10/2010      JP
                                                                                    Morgan
23/10/201           436508    10       2290.9       99,99,99,26     30/12/2013      Neelkanth
3                                                                                   Buildcraft
                                                                                    Private
                                                                                    Limited
9/09/2014           97000     10       2577.25      24,99,93,20     30/09/2014      Rudraksh
                                                                                    Infracity
                                                                                    Private
                                                                                    Limited
10/04/201           34365     10       2910         10,00,02,10     29/07/2015      Rudraksh
5                                                                                   Infracity
                                                                                    Private
                                                                                    Limited
10/04/201           17180     10       2910         4,99,93,800       6/10/2015     Rudraksh
5                                                                                   Infracity
                                                                                    Private
                                                                                    Limited
              (C)
       Source: Data from Form FC-TRS
From the table above it is clear that valuation exercise was done backwardly. For instances first we
paid Rs 100 crores, then Rs 25 crores, then Rs 10 crores and finally Rs. 5Cr..
EXTRACT from FEMA RULES;Bikram Chatterji vs Union Of India on 23 July, 2019

FEM (Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2000 “4.
Restriction on an Indian entity to issue security to a person resident outside India or to record a
transfer of security from or to such a person in its books.
Save as otherwise provided in the Act or Rules or Regulations made thereunder, an Indian entity
shall not issue any security to a person resident outside India or shall not record in its books any
transfer of security from or to such person: Provided that the Reserve Bank may, on an application
made to it and for sufficient reasons, permit an entity to issue any security to a person resident
outside India or to record in its books transfer of security from or to such person, subject to such
conditions as may be considered necessary.
Transfer of shares or convertible debentures or warrants of an Indian company or units of an
Investment Vehicle] by a person resident outside India (1) Subject to the provisions of
sub-regulation (2), a person resident outside India holding the 2[shares or convertible debentures or
warrants of an Indian company or units of an Investment Vehicle] in accordance with these
Regulations, may transfer the 3[shares or convertible debentures or warrants of an Indian company
or units of an Investment Vehicle] so held by him, in compliance with the conditions specified in the
relevant Schedule of these regulations. Further, subject to minimum lock-in period of one year or
minimum lock-in period as prescribed under Annex-B of Schedule 1 whichever is higher, a person
resident outside India holding the shares or convertible debentures or warrants] of an Indian
company containing an optionality clause in accordance with these Regulations and exercising the
option/right, may exit without any assured return, subject to the following conditions:
(i) In case of listed company, at the 6[market price prevailing on the floor of the
recognized stock exchanges]
(ii) In case of equity shares, preference shares or debentures of unlisted company, at
a price not exceeding that arrived at as per any internationally accepted pricing
methodology for valuation of shares on arm's length basis, duly certified by a
Chartered Accountant or a SEBI registered Merchant Banker. The guiding principle
would be that the non-resident investor is not guaranteed any assured exit price at
the time of making such investment/agreements and shall exit at the price prevailing
at the time of exit, subject to lock-in-period requirement.
(2) (i) A person resident outside India, not being a non-resident Indian or an
overseas corporate body, may transfer by way of sale or gift the shares or convertible
debentures or warrants of an Indian company or units of an Investment Vehicle] held
by him or it to any person resident outside India;
(ii) A non-resident Indian may transfer by way of sale or gift, the shares or
convertible debentures or warrants of an Indian company or units of an Investment
Vehicle] held by him or it to another non-resident Indian only;Bikram Chatterji vs Union Of India on 23 July, 2019

(iii) A person resident outside India holding the 6[shares or convertible debentures
or warrants of an Indian company or units of an Investment Vehicle] in accordance
with these Regulations,
(a) may transfer the same to a person resident in India by way of gift;
(b) may sell the same on a recognized Stock Exchange in India through a register
broker.” In the valuation working, it is shown that all project cost was incurred by
June, 2013. It is only additional cost of Rs 125 crore & marketing cost of Rs 6.85 crore
shown as to be incurred after that. (A) JP Morgan personnel have never met the
buyer. Both the Companies Neelkanth Buildcraft Private Limited & Rudraksh
Infracity Private Limited were formed in the year 2013 having a capital of Rs 0.01
crore each for the specific purpose of buying shares from JP Morgan.
(B) No person from Mauritius travelled to India and no person from India travelled
to Mauritius. Indian people signed the contract in India and Mauritius people signed
the contract in Mauritius. Buyer did not carried out any due diligence nor it
appointed any valuer.
(C) The Sales agreement was drafted by JP Morgan team, buyers are not aware of it.
(D) We spoke to the director of Neelkanth Buildcraft Private Limited & Rudraksh
Infracity Private Limited namely Vivek Mittal & Chandan Kumar. Both of them
refused meeting with any person/entity from JP Morgan. They are not aware of that
any time they have bought these shares.
No substantial fundswere used in the construction of the project. The address of the Company who
purchased share from JP Morgan is the address of Group Statutory Auditor Mr. Anil Mittal. (A) Mr
Chandan Kumar, director in Neelkanth Buildcraft Private Limited & Rudraksh Infracity Private
Limited is an office boy in the office of Statutory Auditor Mr Anil Mittal.
(B) Mr Vivek Mittal, another director in Neelkanth Buildcraft Private Limited is nephew of Statutory
Auditor Mr Anil Mittal & does small timejobs Facts Amrapali Zodiac Developers Pvt Ltd
incorporated on 18th December 2009. As per the Share Subscription Agreement dated 9th
September, 2010, JP Morgan invested 85 crore on 20th October 2010 with an understanding to
have a preferential claim on profits called distributable surplus in the ratio of 75% to JP Morgan and
25% to promoters namely Amrapali Homes Project Private Limited and Ultra Home Construction
Private Limited. The said investment was repatriated to JP Morgan as under:
      •     RS. 100 crore on 30th December 2013;
      •     RS. 25 crore on 30th September 2014;
      •     RS. 10 crore on 29th July 2015; and
      •     RS. 5 crore on 6th October 2015.
FEMABikram Chatterji vs Union Of India on 23 July, 2019

Extracts of Master Circular no.8/2010-11 dated July 01, 2010 on External Commercial Borrowings
and Trade Credits External Commercial Borrowings (‘ECBs’) refer to commercial loans in the form
of bank loans, buyers credit, suppliers credit, securitized instruments (eg floating rate notes and
fixed rate bonds, non convertible, optionally convertible or partially convertible preference shares)
availed of from non-resident lenders with a minimum average maturity of 3 years.
ECB can be accessed under 2 routes
a) Automatic route and
b) Approval route.
A) Under Automatic route • Eligible borrowers can be corporates, including those in the hotel,
hospital, software sectors (registered under the Companies Act 1956) and Infrastructure Finance
companies, Housing Finance companies and Non Banking Finance Companies.
• Recognised lenders can be international banks, suppliers of equipments, foreign collaborators and
foreign equity holders • All in cost ceilings for ECBs under automatic route are:
• Average maturity period 3 to 5 years- 300 basis points over 6 months London
Interbank Offered Rate (‘LIBOR’) • Average maturity period more than 5 years – 500
basis points over 6 months LIBOR • ECBs are eligible for end use for investment for
import of capital goods, industrial sector, infrastructure sector and specified service
sectors. However, proceeds of ECBs should not be used for acquisition of land in any
of these permitted uses. • ECBs are not permitted to be utilized for real estate sector.
B) Under Approval route • Certain ECBs which are not under automatic route are
under approval route.
ECBs are not permitted to be utilized for real estate. However, the term real estate excludes
development of integrated township as defined by the Ministry of Commerce and Industry, DIPP,
SIA (FC Division), Press Note 3 (2002 Series) dated January 4, 2002. As per the said press note,
development of integrated township includes housing, commercial premises, hotels, resorts, city
and regional level urban infrastructure facilities such as roads and bridges, mass rapid transit
systems and manufacture of building materials. Development of land and providing allied
infrastructure will form an integrated part of township’s development.
Hedging required:
Minimum mandatory hedging is required @70% of principal plus interest (both) of
ECB where Minimum Average Maturity Period is less than 5 years. Minimum tenor
should be one (1) year thereafter to be rollover till expiry of ECB Compliance under
FEMA ECB Compliance Borrowers are required to submit a report about signing of
loan agreement with the lender for obtaining Loan Registration Number (LRN)Bikram Chatterji vs Union Of India on 23 July, 2019

within 7 days of the signing it to RBI in form ECB.
Borrowers are required to report monthly about actual ECB transactions through form ECB-2 to AD
Category I bank within 7 days from close of the month.
Companies Act 1956 Amrapali Zodiac Developers Pvt Ltd could not have bought back its own shares
from JP Morgan as a company cannot buy back its own shares as per the provisions of section 77 of
the Companies Act 1956. Section 77 states “(1) No company limited by shares, and no company
limited by guarantee and having a share capital, shall have power to buy its own shares, unless the
consequent reduction of capital is effected and sanctioned in pursuance of sections 100 to 104 or of
section 402.” Even otherwise, as per Section 77A, a company can purchase its own shares from
(i) free reserves; Where a company purchases its own shares out of free reserves, then a sum equal
to the nominal value of the share so purchased shall be transferred to the capital redemption reserve
and details of such transfer shall be disclosed in the balance-sheet or
(ii) securities premium account; or
(iii) proceeds of any shares or other specified securities. A Company cannot buyback its shares or
other specified securities out of the proceeds of an earlier issue of the same kind of shares or
specified securities.
Conditions of Buy Back
(a) The buy-back is authorised by the Articles of association of the Company;
(b) A special resolution has been passed in the general meeting of the company authorising the
buy-back. In the case of a listed company, this approval is required by means of a postal ballot. Also,
the shares for buy back should be free from lock in period/non transferability. The buy back can be
made by a Board resolution If the quantity of buyback is or less than ten percent of the paid up
capital and free reserves;
(c) The buy-back is of less than twenty-five per cent of the total paid- up capital and free reserves of
the company and that the buy-back of equity shares in any financial year shall not exceed
twenty-five per cent of its total paid-up equity capital in that financial year;
(d) The ratio of the debt owed by the company is not more than twice the capital and its free reserves
after such buy-back;
(e) There has been no default in any of the following i. in repayment of deposit or interest payable
thereon, ii. redemption of debentures, or preference shares or iii. payment of dividend, if declared,
to all shareholders within the stipulated time of 30 days from the date of declaration of dividend or
iv. repayment of any term loan or interest payable thereon to any financial institution or bank;Bikram Chatterji vs Union Of India on 23 July, 2019

(f) There has been no default in complying with the provisions of filing of Annual Return, Payment
of Dividend, and form and contents of Annual Accounts;
(g) All the shares or other specified securities for buy-back are fully paid-up;
(h) The buy-back of the shares or other specified securities listed on any recognised stock exchange
shall be in accordance with the regulations made by the Securities and Exchange Board of India in
this behalf; and
(i) The buy-back in respect of shares or other specified securities of private and closely held
companies is in accordance with the guidelines as may be prescribed.
Misrepresentation of facts by investing the funds in the form of private equity in the project namely
Zodiac and then diverting it from there to promoters and the promoters associated companies As
ECBs were not permitted in real estate sector under automatic route, JP Morgan gave the said
borrowings, the nomenclature of equity shares having different return on investment as compared
to other equity shareholders. In fact JP Morgan remitted Rs.60 crore to Amrapali Leisure Valley
Developers Pvt Ltd as ECB without obtaining approval from competent authority. Immediately on
receipt of funds by Amrapali Leisure Valley Developers Pvt Ltd, the funds were transferred to
promoters and associate companies of the group. Had JP Morgan invested in the form of ECB,
following would have been the compliances to be fulfilled by recipient:
a) obtaining Loan Registration Number from RBI;
b) file ECB-2 returns every month to the RBI;
c) withhold tax on interest payment to JP Morgan under section 195 of the ITA. As
per Article 11 of the Avoidance of double taxation agreement between India and
Mauritius tax shall be charged @7.5% of the gross amount of interest.
d) In fact JP Morgan would have to file its income tax return u/s 139 of ITA in India
due to withholding tax on its interest income borrower.
Relevant questions from FAQ issued by RBI with regard to the Foreign Exchange Management
(Transfer or Issue of Security by a Person Resident Outside India) Regulations, 2017 dated
November 7, 2017 as amended from time to time:
“Q.29: What is the concept of downstream investment and Indirect Foreign
Investment?
Answer: Downstream investment is investment made by an Indian entity which has
total foreign investment in it or an Investment Vehicle in the capital instruments or
the capital, as the case may be, of another Indian entity.Bikram Chatterji vs Union Of India on 23 July, 2019

If the investor company has total foreign investment in it and is not owned and not
controlled by resident Indian citizens or is owned or controlled by persons resident
outside India then such investment shall be “Indirect Foreign Investment” for the
investee company.” “Q.41: What is an investment vehicle?
Answer: Investment Vehicle is an entity registered and regulated under relevant
regulations framed by SEBI or any other authority designated for the purpose. For
the purpose of Schedule 8 of FEMA 20(R), an Investment Vehicle is a Real Estate
Investment Trust (REIT) governed by the SEBI (REITs) Regulations, 2014, an
Infrastructure Investment Trust (InvIt) governed by the SEBI (InvIts) Regulations,
2014 and an Alternative Investment Fund (AIF) governed by the SEBI (AIFs)
Regulations, 2012. It does not include a Venture Capital Fund registered under the
erstwhile SEBI (Venture Capital Funds) Regulations, 1996.” SUMMARY- NET
SURPLUS/DEFICIT
1) Amount Realisable from the sale of the unsold inventory and from home buyers
(Residential and commercial) in various projects and its extent.
Net surplus/deficit Total Estimated Cost to Net Refund/ S.No Name of company Receivable Cost
still to Complete Surplus/ Shifitng from Buyers be incurred by NBCC (Deficit) Amrapali Princely 38
- -
1 Estate Pvt.Ltd. (6) 12 - -
70 - -
           Amrapali Leisure            1,887             267           -
                                                                              1,586
    5      Park Pvt.Ltd.                                                                (196)
                                         16                 -          -
    6      Amrapali Grand                                                       -        16
           Amrapali Homes                 7                 -          -
                                                                                -
           Amrapali Dream              1,435                -          -
                                                                              1,657
    9      Valley Pvt Ltd                                                               (222)Bikram Chatterji vs Union Of India on 23 July, 2019

           Amrapali Silicon             558                 -          -
           Amrapali Smart               489                 -          -
   11      Ltd                                                                          (357)
           Amrapali Leisure             309                 -          -
   12      Pvt.Ltd.                                                                     (13)
                                     69                 -             -
     Amrapali Sapphire
13   Developers Pvt Ltd                                                                   (20)
        Group Total                               307                        5,882        (148)
       Refer ANNEXURE XXIII
The unsold Inventory in the various schemes where forensic audit was carried out is to the tune of
Rs 1,958.82crores spread-over in 5,229Flats.
*Unsold inventory of Amrapali Centurian Park Private Limited comprises of three projects namely-
Amrapali Tropical Garden, Amrapali Terrace Homes, O2 Valley.
We have not been provided the inventory details of O2 Valley, the data mentioned here and included
in calculation of surplus/deficit is agreed in discussion with CMD, Amrapali Group.
Unsold units of O2 Valley is 223.
The unsold Inventory in respect of the commercial shop space amounts to Rs.162 crores spread-over
in 5schemes.
*487 units are available in commercial project Tech Park which are yet to be examine. The detailed
list of inventory is attached in ANNEXURE XXII.2.
15. Sale of Flats at lower prices (Under-Valued Transactions) While scrutinizing the record for sale
of flats, we have observed that number of the flats were sold at low prices as compared to the prices
existing on or near to those dates and on which rates sales were made to other home buyers. It is
further submitted that some of the flats have been sold even at rates as low as RS. 1,000 - RS. 1,400
per square feet which is even lower than the cost of construction. No satisfactory explanation hasBikram Chatterji vs Union Of India on 23 July, 2019

been given to us for the same. Possibility of taking cash outside the books of accounts cannot be
ruled out. Total Amount involved in under-valued transaction is enclosed Annexure 26-A (Volume
III Page no 584-586 ) & at Annexure S-7 (Supplementary Report page no 2842-2893). The amount
shown below is the minimum and it may be in the range of 1,000 crore. Since the sample size is
5856 against the total number of more than 42,000 flats.
     S.no.   Name of the company           Number of    Amount (In          Refer Page
                                             Units          Crores)           Number
             Developers Private
             Limited
     Valley Developers                    70            5.88
     Private Limited
 3   *Amrapali Smart City                261           18.97   232 - Point No. 1
     Developers Private
     Limited
 4   *Amrapali Silicon City              468           73.05   257 - Point No. 1
     Private Limited
     Valley Private Limited
 6   #Amrapali Leisure                   122            8.53              2811
     Valley Private Limited                                     (Supplementary
                                                                  Audit Report)
 7   #Ultra Home                         524           30.87              2811
     Construction Private                                       (Supplementary
     Limited                                                      Audit Report)
 8   #Amrapali Centurian                1,912          43.12              2811
     Park Private                                               (Supplementary
     Limited                                                      Audit Report)
 9   #Amrapali Princely                  146            6.70              2811
     Estate Private Limited                                     (Supplementary
                                                                  Audit Report)
10   #Amrapali Zodiac                    107            6.75              2811
     Developers Private                                         (Supplementary
     Limited                                                      Audit Report)
11   #Amrapali Patel                     179           27.31              2811
     Platinum                                                   (Supplementary
                                                                  Audit Report)
                         Total          5,856        321.31
Note: *These calculations are based upon the rates, where the sale consideration of the flat is less by
more than 25% of the average sale price of the project.
# These calculations are based upon the rate of Rs.2000/- per sq. ft. and where flats were sold lesser
than the rate of Rs.2000/- per sq. ft.Bikram Chatterji vs Union Of India on 23 July, 2019

16. Group investment in other projects The group started demerging and delinking the good projects
from the brand name “Amrapali” though these projects were initially launched as Amrapali projects.
The said projects identified till the date of writing of the report are La Residentia, Vinayaka square,
Heartbeat City, O2 Habitat.
La Residentia A big project having more than 3,200 dwelling units was launched in 2010-11 having
an equity shareholding of 19.75% in the name of Stunning Construction Pvt Ltd.
• Stunning Construction Private Limited (‘Stunning’), an Amrapali group company, holds 19.75%
shares in the company. Stunning has been a consortium partner since beginning and land was
allotted by Noida Authorities to the 5 members consortium including Stunning. The project was
launched as an Amrapali group project and was marketed accordingly. As per the discussion with
directors of La Residentia Developers Private Limited, they broke up with Amrapali group in 2017.
2017 is the year when writ petition was filed before the Honorable Supreme Court. It is informed to
us that a marketing agreement was entered into between La Residentia Developers Private Limited
and Amrapali group (name of the company not known) that Amrapali group would market its
project for a consideration of Rs.16 crore. It was informed by Mr. Sanjeev Kumar (director of La
Residentia Developers Private Limited and a very old friend of Mr. Shiv Priya, director, Amrapali
group) that though the agreement was signed but Amrapali group didn’t provide a copy of the
agreement. It proves that Amrapali director were having significant influence on La Residentia
Developers Private Limited that they had an authority even not to give a copy of the agreement to a
person/entity who has signed it. • Out of Rs.16 crore, which were to be paid to Amrapali group as
per the agreement, Rs 4 crore were paid to Saffron Propmart Consultancy Private Limited Owned
and controlled by CFO Chander Wadhwa) under a verbal instruction of Mr. Adikhari, GM/DG
accounts of Amrapali group. It is to be noted that directors of La Residentia Developers Private
Limited were acting and working under the supervision of Mr. Adhikari who was a middle level
management officer. It indicates that the project was conceived by Mr. Anil Kumar Sharma & Mr.
Shiv Priya directors of Amrapali group and Mr. Sanjeev Kumar, Mr. Mukesh Kumar Roy and others
were only a front.
• it is very clear that there was no contribution of funds from the consortium partners whatever
funds contributed by the consortium partners were not only withdrawn within a very short period
but over and above that extra funds were given to them in the name of interest free loans and
advances.
• Amrapali group companies have transferred some of their buyers to the company. We found that
the list of unsold inventory was sent to Mr. Anil Sharma and it was he who decided that the
following buyers from Amrapali group companies be shifted to La Residentia this proves that La
Residentia was under the direct control of Mr. Anil Sharma and Mr. Shiv Priya and is an entity of
Amrapali group. • The company is also using the Brand name/trademark of Amrapali group on its
letterheads.
• The website of the company is following www.amrapali- laresidentia.com.Bikram Chatterji vs Union Of India on 23 July, 2019

• When we open the website of the company, advertisement page was hiding details and it is a
project of Amrapali group.
17. Summary of amounts recoverable standing as debit balances in books of accounts Amrapali
group of companies had several amounts lying in debit balances in the form of advances recoverable
on account of long term loans to third parties, short term loans given to third parties, advances
given for purchase of plots, advances given to creditors for materials/others etc. Amrapali group of
companies were mostly diverting loan funds as well as home buyers funds to directors, key
managerial personnel, relatives, group companies and third parties. They did construction activity
only in part and created a circle for movements of funds vide bogus expenses or hollow transactions.
Funds were given to several parties in the garb of advances against purchase of land or for
purchasing material for construction and booked as sundry creditors with debit balances. However,
in effect such amounts were neither returned nor any expense was booked against them. Such
amounts are as old as 2006-07, which have not been returned or no expense has been booked till
date. Total of such recoverable amounts to Rs.582 crore.
Top 20 of such parties with their balances are stated hereunder:
    Name of the Company/Entity                                     Total
    Jaura Infratech Private Limited                         34,55,00,000
    Mauria Udyog Limited                                    22,24,34,199
    Anil Kumar Sharma                                       16,34,69,224
    Shiv Priya                                              11,53,30,097
    Prem Mishra                                             10,26,03,947
    Vansh Consultants Private Limited                        9,75,00,000
    Apex Infraventure Private Limited                        7,95,05,000
    Rinku Computech Private Limited                          6,69,59,467
    Sapphire Digital Printers                                4,46,83,088
    Heart Beat City Developers Pvt Ltd                       4,29,32,000
    Rubi Creations Private Limited                           4,26,27,790
    Ajay Kumar                                               4,05,40,931
    Star Land Craft Private Limited                          4,01,85,888
    Heartland City Developers Private Limited                4,01,22,762
    Vidhya Shree Buildcon Private Limited                    4,00,00,000
    Sky Tech Buildcon Private Limited                        3,88,53,775
    Skyline Tele Media Services Limited                      3,48,02,771
    Shantinath Enterprises                                   3,24,71,100
    Red Star Tradex P Ltd.                               3,00,00,000
    Mohabbat S/o Abbas                                   2,66,99,000
    Total of top 20 companies/parties               1,64,72,21,039
It can be seen from records that the recoverable are due since long and there are mostly no
movements subsequently either in the form of booking of expenses or receipts. Out of the amounts
recoverable from parties in case of Ultra Home Construction Pvt Ltd, 20 parties having huge
balances recoverable were called for personal interviews. 7 parties appeared and no satisfactoryBikram Chatterji vs Union Of India on 23 July, 2019

explanation was provided (Refer Annexure X.1, Volume IV page no 1015-1019)
18. Assets created out of diverted funds Refer Page no 550 to 557 of Volume II
19. Cars The Company has bought many luxury cars and other cars out of the funds of the
homebuyers.
Many of the cars were transferred in the name of the relatives / employees without passing any
entries in the books of accounts and receiving any money from the transferees.
Moreover, the cars were transferred in the name of the persons who was not associated with the
company which originally bought the cars. We have already reported the matter in the court
hearings and the honourable court has ordered for the sale of the said luxury cars. Out of the above
15 cars only 9 were made available for physical verification.
20. HOMEBUYERS The group constructed and booked/sold residential and commercial units:
a) before launch of the projects;
b) at the launch of the projects; and
c) Continued to book till any inventory was left over in the projects.
The customers booked the flat for:
a) Abode;
b) Investment;
c) barter in advance;
d) adjusting their amounts in respect of work done in same project (creditors of same
projects)
e) adjusting their amounts in respect of work done in other projects (creditors of
other projects)
f) booked in the name of unidentifiable/untraceable persons/entities.
During this procedure, we were informed that the data related to customers was maintained in the
software FAR VISION as well as manually of some of the projects. The Data in such fashion is
intentionally maintained to avoid findings in future the gaps.Bikram Chatterji vs Union Of India on 23 July, 2019

1) It is found that the promoters/directors/senior management of the company were treating the
inventory of the projects as personal asset and started allotting the unsold inventory to various
persons/entities by passing an accounting entry in the Accounting software tally.
2) We found that 14 flats were booked in the name of Mr. Rajesh Viz in the project Amrapali
Centurion Park, Terrace Homes. The customer data in FAR Vision provided, shows only Rs
10,000/- received for each flat from him as a booking amount. We did not find his name in the tally
data of books of accounts of Amrapali Centurion Park Pvt. Ltd. We sent Emails to him to confirm
the same but did not get any satisfactory response from him. He did not come and avoided meeting
us for last 5 months.
3) We found differences in amount shown as per the records i.e. amount received as per Customer
data base sheet extracted from software FAR VISION and the amount actually paid by the customer.
We came to know about the differences in receivable after sending e mails/ speaking over the phone
to the customers. A list of such differences is given on sample basis (Page No. 483)
4) We found the following 2 customers who had been handed over the possession but still appearing
in the Customer database as undelivered. Both have paid less than 50% as per company records.
S.    PROJECT NAME        CUSTOMER         FLAT NO. POSSESSION             POSSESSION
No.                       NAME                      (as per customer)      (as per details
                                                                           provided to us)
1     Amrapali Zodiac     MR. SAMEER       JP-03       Handed over         Not handed over
                          KR. SUNEJA
2     Amrapali Princely   MRS.             FP-01       Handed over         Not handed over
      Estate              MRIGANKA
                          PRABHAT
5) For amount received there is a mismatch in the tally records/ FV accounts and customer data in
software Far Vision. Amount received from a customer with flat no. though shown in customer
database but didn’t account for in the tally. List on sample basis is given (Page No.
486)
6) We found a mismatch that the name of customer is different in accounting package (tally& ERP
FAR Vision) and customer data record in FAR VISION. We were not explained satisfactorily the
reason for the same. (Page No. 489)
7) We found a no. of customers/buyers whose know your customer (KYC) is not available (N/A).For
example PAN, e-mail, phone and address (Page No. 490)
8) The supplier of material and provider of services were unsecured creditors for the amount
claimed by them. There are a number of flats booked against the amount claimed as due. All this
was done in 2015-17. There are flats allotted to parties (unsecured creditors) in different projectsBikram Chatterji vs Union Of India on 23 July, 2019

irrespective of whether any service was provided/ material supplied to the same project or not. We
propose the following order for allotment of flats to the persons/ entity who have booked the flats
subject to the verification of their claim:
(a) For abode;
(b) For investment without interest and payments made by bank;
(c) For investment against barter in advance if services rendered/supplies made to
the same project;
(d) To the creditor if services rendered/supplies made to the same project; and
(e) The last should be the person/ entities who have supplied and services rendered
to the group companies
9) We checked the customer data on the basis of a selected criteria (customers having
two or more than two units& customers not having KYC details) and found that no
money is received against the sale of those units. The units are booked by just passing
a JV. A few examples are shown below. The detailed list of units (project wise) which
we checked is also attached. (ANNEXURE-XV.28 page 2646-2658 vol. VIII) S. No.
Project Name Customer Name Unit No Unit Cost (ex ST) 1 Amrapali Grand
MORPHEUS SECURITY T-7-G2 74,16,700 PVT. LTD 2 Amrapali Grand SANJEEV
KUMAR T-6-G4 94,76,511 3 Amrapali Grand MAHESH KUMAR T-6-G2 84,99,961 4
Amrapali Eden IshwarKhandelwal D-2102 84,28,450 Park 5 Amrapali Eden
AMRENDER KR JHA/ C-G01 1,40,00,000 Park SUNITA JHA 6 Amrapali Eden
MAHESH KUMAR C-G02 70,75,000 Park 7 Amrapali Eden SUSHMA RANI/ VIJAY
NARAYAN C-G03 96,75,859 Park RAI 8 IMT Manesar SAI Glazing 323 82,09,095 9
IMT Manesar NOPS Infrastructure 227 87,76,128 10 IMT Manesar NOPS
Infrastructure 234 1,32,02,500 11 Amrapali village Mrs Pooja KM-1205 31,35,000
There have been instances of duplicate allotment of flats i.e. one flat is allotted to
more than one person and money is received from both the home buyers. Sample
details are given here under. The work relating to duplicate flats allotment is still in
the process of being checked.
                                                            First Buyer                                                 Second Buyer
                                        Date of
S.no.       Name oF Project
                                        Booking &                                                        Date of Booking
                               Flat No. Allotment       Name of Buyer              Amount in Rs.Flat No. & Allotment Name of Buyer           Amount in Rs.
    1 Crystal Homes            T3-2301         09-11-15 Sulochana Karwa               2,500,000 T3-2301          26-05-16 Aayush Soni           2,013,750
    2 Amrapali Princely Estate M-P01           07-11-15 Nilesh Karwa (HUF)            5,000,000 M-P01            15-10-16 Sanjeev Kumar Goel    6,344,460
    3 Amrapali Princely Estate C-P03           07-11-15 Pramod Karwa (HUF)            5,000,000 C-P03            15-10-16 Shalabh Mittal        3,105,635
    4 Amrapali Patel Platenium A-2303          26-03-10 Pramod Karwa (HUF)            2,000,000 A-2303           20-04-12 Manjul Kumar Tyagi    4,826,991
    5 Amrapali Patel Platenium J-2401          26-03-10 Rajeswari Karwa               1,500,000 J-2401               N/A Nissa Hussaini                -
    6 Crystal Homes            T1-2401         09-11-15 Nilesh Karwa (HUF)            2,500,000 T1-2401          13-06-16 Manish Jain           2,030,400Bikram Chatterji vs Union Of India on 23 July, 2019

    7 Crystal Homes            T2-2403         09-11-15 Nilesh Karwa (HUF)            2,500,000 T2-2403          28-07-16 Ajit Pal Singh           312,500
      Silicon City             G1-104          24-03-11 Nilesh Karwa & Seema Karwa    1,250,000 Tower has not been constructed and Fake allotment is been
      Silicon City             G1-204          24-03-11 Nilesh Karwa & Seema Karwa    1,250,000            made to Nilesh Karwa & Seema Karwa
                               Total Amount Received                                 23,500,000                                                18,633,736
Ultra Home Construction Pvt Ltd allotted flats to buyers on false promises and forged
documents. An instance being in the case of Mr. Mohammad Kaif where he was
allotted 3 flats i.e G-2502, G 2501 and LG-1 vide agreements dated 22nd August
2012, 19th September 2012 and 9th January 2013, through their consortium-
Amrapali Patel Platinum and UHCPL received INR 2 crore on assured return basis.
However, subsequently, it came to the knowledge that flats mentioned in the buyer agreement never
existed as 25th floor did not exist in the approved building plan. Further, as per details provided by
Mr. Kaif, as on 31st March 2017, an amount of INR 1,40,00,000 was payable to him, however, as per
books of accounts (in tally data), an amount of INR 1,70,00,000 was payable to him by UHCPL.
Hi Tech City Developers Pvt Ltd has huge amount of Trade Receivables of INR 1.64 crores Whereas ,
the project under this Company i.e. Amrapali Empire has been completed. Most of the flats have
been handed over and registry has been done. We fail to understand as to why the aforesaid amount
is still appearing as recoverable from various home buyers. This implies it was received in cash and
not accounted for. The complete list of all such flat owners along with their sale amount and amount
received is enclosed below:
           UNIT                                                                         Balance
  Sr No                      BUYER NAME                Total Cost     Total Received
           NO.                                                                          Amount
      1   A-1603   Son Pal Sharma/Shashi Sharma           3,135,000      2,380,028        754,972
      2   A-1604   Sunil Kumar Jha                        2,527,000      1,984,673        542,327
      3   A-1803   Sahji Nambiar                          3,160,000      3,027,520        132,480
      4   A-1904   Himanshu Khurana                       2,527,000      2,459,629         67,371
      5    B-301   Suresh Chand Sharma                    3,135,000      3,055,584         79,416
      6   B-1604   Mrs. Niki Rani                         2,460,500      1,974,973        485,527
      7   B-1703   Rahul Ranjan                           2,640,000        485,984      2,154,016
      8   B-1803   Ravi Kant Tyagi (STAFF)                3,193,000      2,992,196        200,804
      9   B-1903   Monika Thakur                          3,696,000      2,000,000      1,696,000
     10   B-1904   Neeraj Soni                            2,527,000      1,903,967        623,033
     11    C-604   Nirmala Devi                           1,750,000      1,261,035        488,965
     12    C-702   Manish Raj Sharma                      1,913,625      1,302,510        611,115
     13    C-905   M. A. Khan                             2,004,750      1,603,951        400,799
     14   C-1604   Bharat Lal Agrahari                    1,900,000      1,624,794        275,206
     15   C-1701   Sanjay Kumar                           2,023,675      1,375,525        648,150
     16   C-1705   Syed Sharique Ali                      2,308,500      2,035,125        273,375
     17   C-1901   Uday Shankar Rai                       2,004,750      1,000,185      1,004,565
     18   C-1902   Suresh Chandra Mandal                  2,004,750      1,414,459        590,291
     19   C-1904   Mrs. Annu (Gulshan Driver)             1,645,000        921,525        723,475
     20   C-2001   Shailendra Kumar                       2,357,800      2,308,500         49,300Bikram Chatterji vs Union Of India on 23 July, 2019

     21   C-2002   Mrs.Nivedita Singh                     2,333,500        871,103      1,462,397
     22   C-2003   Dheerendra Kumar/Shailendra kumar      1,111,500        663,834        447,666
     23   C-2004   Manjari Smrita                         1,148,200      1,111,500         36,700
     24    D-102   Prasanna Kumar Das                     1,900,000      1,861,637         38,363
     25   D-1703   Sri Dhaneswar Dash                     2,308,500      2,172,696        135,804
     26   D-1903   Virendra Kumar                         2,308,500      2,209,508         98,992
     27   D-1904   Randhir Kumar                          1,900,000      1,805,148         94,852
     28   A-303    Manish Kumar                           3,382,500      3,302,347         80,153
     29   B-403    Anupama Tiwari                         3,176,250      2,182,659        993,591
     30   B-1902   Md. Merajul Hasan                      2,527,000      2,191,025        335,975
     31   B-1501   Rajesh Kumar                           3,093,750      2,943,106        150,644
     32   C-1806   Anand Shankar                          1,900,000      1,504,737        395,263
     33   C-1704   Sourabh Shandilya                      2,100,000      1,702,175        397,825
                            Total                        78,103,050     61,633,638     16,469,412
It is worth mentioning here that of the above 33 home buyers most of them are employees/
ex-employees of the Company. The management has done under-valued registry for all these cases.
We are of the view that the management has under-valued these registries to evade the stamp duty
to be paid to the government and has taken the money outside the books from these employees and
these amounts outstanding in the books are only book entries and should be recovered from the
management.
21. Misrepresentation of Facts As per the information provided and the records made available to
us, Flat No C-704 in Amrapali Castle and Flat No D-702 in Amrapali Eden Park were shown as
vacant flats and were provided to NBCC for the purpose of sale. However, we have received letters
from Mr Manoj Kumar and Mr Maneesh Gaur in Amrapali Castle and Amrapali Eden Park
respectively along with many Annexures. (Payment receipts, NOC, possession letter).that the flats
have been booked by them
9) While scrutinizing the customer data, we found a case where the flat is sold at discount. The total
value of the flat is booked as a discount. There may be many more such cases.
Project                Customer Name           Unit No       Area      Unit Cost          Discount
Amrapali               M/S. AMCON              A-002         2525      80,38,484          80,38,484
Leisure                BUILDCON PVT.
Valley           LTD.
We are informed that Mr.Adhikari Debi Prasad Das (GM/DGM Accounts) and Mr. Mohit Gupta
(Director Marketing) were directly responsible for accounting and collection of receivables and
marketing of flats.Bikram Chatterji vs Union Of India on 23 July, 2019

We interviewed both the persons several times. Both kept on changing their stand/answers and did
not cooperate in answering our queries. Their answer to every question was that they are not aware.
They did not provide many documents and the laptops which are in their possession. In spite of
repeated reminders, Mr. Mohit Gupta has not made available the complete data with respect to
home buyers/flat owners.
We found Mr Mohit Gupta and Mr Adhikari Devi Prasad Das directly responsible for all the
wrongdoings in booking of receivables, marketing of the flats and in handing over the possession of
the flats. Utilities like Milk booth, Nursery schools, Senior secondary schools, Nursing homes
allotted to various parties should be cancelled.
LIST OF FLATS (Residential & Commercial) ALLOTED TO BROKERS AND SUPPLIERS 833 Flats
booked (identified till now) in the name of various vendors should be attached and be released at
last till the last home buyers gets his/her flat.If there is a shortfall , then the flats should be treated
as inventory and be sold .
The following flats should be cancelled.
These are the 353 flats booked in the name of various vendors parties without receipt of any sum.
The flats has not been included in inventory and will be available for sale after giving a chance to the
Flat buyer if he/she/it introduce any documents to substantiate the claim. Refer list below:
It has further been observed that, 75 flats adjustments were made between M/s LA
Residentia and Amrapali Group of Companies against the aforesaid Branding
Income. These home buyers have already been allotted flats in M/s LA Residentia.
Hence, the 75 Flats booked by Amrapali Group in various schemes should be treated
as vacant. (Volume-I Page No. 200). The Complete List of all such flat has been
enclosed as Annexure 25-A. (Volume III Page no 582-583)
22. Sureka group Amrapali and Sureka’s have a very long and intricate association
starting officially with the partnership venture ‘Amrapali Homes’ in 2006 wherein
Ultra Home Construction Private Limited and Mauria Udyog Limited is partner and
developed project in name of Amrapali Homes in Indirapuram then Amrapali Grand
wherein Ultra Home Construction Private Limited and Bihariji Ispat Udyog Limited
were partners, though the land was allotted to Bihariji Ispat Udyog Limited.
Initially Amrapali Group ventured like these types of association as he was independently not able to
meet the net worth, turnover and other eligibility criteria for land allotment by Noida authorities.
They then next associated in Sapphire Project wherein Sureka’s family participated as shareholders
and directors in the Company. Every Joint Venture used to have an unexecuted profit sharing and
investment arrangement. Since the company didn’t declared dividend ever, the profits were drawn
by Sureka family in the nature of advances which has majorly been squared off against billing from
Mauria Udyog Limited, Jotindra Steel and their other related companies. Some of the amount is still
lying as advance in the books of accounts of Amrapali Group. In 2012 Amrapali Group invested inBikram Chatterji vs Union Of India on 23 July, 2019

25% stake in Sureka family’s three projects Heart Beat City, Pebbles Prolease, Three Platinum
Softech. Apart from subscribing to share capital, the further investment was made directly as
advance or billing from Amrapali Group to these companies and some through shell companies as
well. Further they did a project in Ultra Home Construction Private Limited with Mozambique. This
project was planned, coordinated and managed by Mr Navneet Sureka in the name of Ultra Home
Construction Private Limited and whatever advance was sanctioned and disbursed by the
Government of Mozambique through EXIM bank to Ultra Home Construction Private Limited was
eventually diverted to Sureka family through billing from Jotindra Steel and Tubes Limited, Mauria
Udyog Limited, etc. A separate bank account of Ultra Home Construction Private Limited was
opened in State Bank of Patiala, Faridabad branch where signatory was Mr Akhil Sureka who used
to operate the account from there. The entire transactions of LC and EXIM bank was routed from
that account. Navneet Sureka visited more in the period of contract finalization to Mozambique
Partner in the following projects:
• Amrapali Sapphire Developers Pvt. Ltd. – 10.52% of shareholding BihariJi Ispat
Udyog Limited • Amrapali Smart City Pvt Ltd – 10% shareholding held by Mauria
Udyog Ltd • Amrapali Homes – 5% - Mauria Udyog Ltd (Rs.20 crore given as an
advance before 2008 and is recoverable) • Amrapali grand – 10% BihariJi Ispat
Udyog Limited –We were informed that the land was allotted in the name of Bihariji
Ispat Udyog Ltd and construction and development work was done by Amrapali
group.
Directors in the following companies • Amrapali Leisure Valley Pvt Ltd – Akhil
Sureka Cheque signatories in the following companies • Amrapali Leisure Valley Pvt
Ltd • Amrapali Dream Valley Pvt Ltd • Amrapali Leisure Valley Developers pvt Ltd •
Amrapali centurian Park Pvt Ltd From the above, it is clear that Sureka group
directors namely Vishnu Sureka, Navneet Sureka and Akhil sureka were promoters in
amrapali group. They were in equal control of affairs with other promoters (Anil
Sharma Shiv Priya, etc.). They not only invested as a promoter heavy amount but also
provided the land allotted to Bihariji Ispat a sureka group company. But the amount
invested was withdrawn in a very short period by other associate companies in the
form of interest, supplies, provision of services etc. it was found out that there were
many other suppliers who never interacted with any of the directors/staff but
supplied material to Amrapali through Akhil and Navneet Sureka. In our opinion,
this was nothing but accommodation bills and a form of withdrawing funds from the
group. None of the employess/ directors of the sureka companies knew that Sureka
group has supplied ,material to Amrapali group. Though sureka group has a policy
and procedure wthat for any item above Rs,. 5,000/- a purchase order would be
issued but it was not followed in the case of supplies to Amrapali. Surprising all the
transactions worth more than 500 crore has been handled single handedly by
Navneet and akhil sureka without involving any of the directors and employees. All
the cheques were also signed by Usreka family and not by any other directors.Bikram Chatterji vs Union Of India on 23 July, 2019

It is pertinent to note that the amount paid for FSI purchased by Suraka group
companies was taken back on the same day by routing through a number of
companies.All such cheques for money laundering were signed by Akhil Sureka
Furthermore, it is found that the amount so paid ie Rs. 80 crore was also received
from suppliers of the Amrapali group. Therefore in our opinion,not only FSi should
be canceled but the amount os Rs. 80 crore is recovereable from them.
They adopted the same methodoly. Formed various business entities, appointed
small time employees the directors in these companies and routed fundsof 100s of
crores and it may be in the range of 1000s crores.. None of the directors were
knowing about any of the business transactions. Further more most of the directors
never attended any board meetings,knew about nature of business the company does,
name of other directors in the company and so on. We are not sure who was teacing
the fraudlent practices to whom, whether Sureka to Amrapali or vice versa.
It was observed Rs.13.44 crore paid to Sureka Public Charitable Trust were
transferred to donation account subsequently. It is submitted that Sureka Public
Charitable Trust is a group institution of Jotindra Steels & Tubes Limited, which is
also under the forensic audit. This should be recovered from the Jotindra Steels &
Tubes Limited.
Sureka group used several companies to route funds from Amrapali group to Sureka
group, an example being in the case of Amrapali Infrastructure Pvt Ltd, where the
company received Rs.3.23 crore from “Synergy Freightways Private Limited” from
26th March 2015 to 30th March 2015. On 31st March 2015 an amount to Rs.4.18
crore was paid to the said party through 16 separate transactions and thereby leading
to a debit balance recoverable from the party amounting to Rs.0.9,5 crore as on 31st
March 2015. This amount should be recovered from the Sureka Group.
It is worthwhile to mention here that M/s Synergy Freightways Private Limited is an
associate Company of M/s Jotindra Steel and Tubes Limited. Further, there are no
business transactions with the said party except routing of funds.
Another example being in the case of Shriv Buildmat Private Limited where one of
the directors is common with MauriaUdyog Limited. On scrutiny of ledger accounts
of Shriv Buildmat, it was observed that during FY 2014-15 and 2015-16, the said
company had almost 100% sales to Amrapali group of companies. It was also
observed that one flat was allotted to Mr. Atul Kumar, Director of ShrivBuildmat
Private Limited in Verona Heights, against the amount due to the said company. This
adjustment is not genuine and the relevant amount should be recovered from Mr.
Atul Kumar or his flat may be attached. As per ledger account advance to Amrapali
for flat, a sum of INR 34.05 lakhs has been shown as recoverable as on 31st March,
2015. There is no name of the Company to which such advance has been given in the
books of the Amrapali Group of Companies. Thus, this amount of INR 34.05 Lakhs isBikram Chatterji vs Union Of India on 23 July, 2019

shown as recoverable is not genuine.
A sum of INR 53.21 Lakhs has been debited to Labour Charges Contractors on account of bill no.
SBPL/Noida/010 dated 13/3/2013 has been recorded in the books of Amrapali Infrastructure
Private Limited on 16/03/2015.
RN Traders During the financial year 2016-17 and 2017-18, a sum of INR 17.63 crores has been
debited to this party and standing recoverable as per Raw Tally Data, till date as per details given
below:
Date         Particulars              Amount in     Remarks
                                      lakhs
30-11-2016   Bank Payment                    0.02   Payment made without any
                                                    narration on the voucher
13-12-2016   Bank Payment                     750   Payment made without any
                                                    narration on the voucher
19-04-2017   Transfer entry through         1,004   Being Amount transfer as
             MauriaUdhyog Limited                   per letter signed by Mr. Anil
                                                    Sharma
19-04-2017   Transfer entry through           960   Being Amount transfer as
             Sarvomme                               per letter signed by Mr. Anil
             Infrastructure Private                 Sharma
             Limited
               Total                    2,714.02
Further, there is no Name, Pan or Address available in the records of M/s RN Traders. It was further
observed that there are no business transactions with M/s RN Traders. It is possible that this
amount of INR 2,714.02 Lakhs has been withdrawn by the management for their own personal use
and should be recovered from the management. BiharijiIspat Udyog Limited being one of the
partners of Amrapali Grand always had negative capital. They withdrew much more than what they
brought into the business. There is no substance in them being called as capital contributors to the
business of Amrapali Grand. As on 1st April 2008 they had withdrawn INR 12 crore and invested a
capital contribution of INR 1.5 crore. As on 31st July 2018, they have debit balance of INR 1.67 crore
and negative capital of INR 30,380. They always withdrew homebuyers funds for misusing for their
own agendas apart from the business.
Out of INR 12 crore given to BihariJiIspat Udyog Limited, they returned INR 6.45 crore through
bank and the balance amount was adjusted against receivables from Ultra Home Construction Pvt
Ltd and against capital contribution by BiharijiIspat Udyog Ltd. Amrapali Grand gave loans and
advances to below parties, which are recoverable as on 31st July 2018 amounting to INR 25.73 crore
as per Tally data.Bikram Chatterji vs Union Of India on 23 July, 2019

S. No. Name of the Amount Date of transaction Company/Person 1 Anil Kumar Sharma
10,03,55,900 20.11.2007 to 25.07.2018 2 Shiv Priya 7,10,50,000 20.04.2007 to 22.09.2010 3
Madan Mohan Sharma 2,01,00,000 20.11.2007 to 5.12.2007 4 Ajay Kumar 2,74,68,000 23.06.2007
to 31.03.2011 5 BiharijiIspat Udyog Limited 1,67,00,000 5.04.2006 to 31.07.2018 6 Amrapali
Homes 54,01,519 15.09.2006 to 07.12.2013 7 SuvashChander Kumar 47,11,000 3.01.2008 to
01.12.2009 8 Shiv Priya –Imprest 35,70,480 1.04.2008 to 24.12.2009 9 Amrapali Zodiac
Developers 19,20,000 27.06.2017 to Private Limited 13.07.2017 10 Jhamb Finance and 19,00,000
5.11.2015 Leasing Private Limited 11 Amresh Kumar 16,86,000 1.04.2007 to 15.09.2008 12 GK
International 10,00,000 21.01.2007 13 Pallavi Mishra 6,07,080 12.07.2018 14 Mohit Gupta
5,80,000 25.06.2007 to 11.04.2008 15 P K Choubey 1,50,000 2.08.2007 16 Amrapali Foundation
1,00,000 24.11.2015 17 Suraj pur Sales & Service 1,00,000 1.11.2010 Total 25,73,99,979 It has been
observed that amounts paid to parties above were mostly routed to Quality Synthetics Pvt Ltd which
primarily belongs Sureka family. For example:
a) Payment of Rs 2,74,68,000/- has been made to Mr Ajay Kumar from 2007-08 to
2010-11 as advance recoverable. Out of this, Rs 77,00,000 was paid by him for
purchase of property located at Jaypee Greens, Noida & Rs 50,00,000 was paid by
him to Quality Synthetics Industries Limited.
b) Payment of Rs 10,03,55,900 has been made to Mr Anil Kumar Sharma from
2007-08 to July, 2018. Out of this, Rs 3,00,00,000 was paid to Quality Synthetics
Industries Limited.
c) Payment of Rs 7,10,50,000 has been made to Mr Shiv Priya from 2007-08 to
September 2010. Out of this, Rs 1,00,00,000 was paid to Quality Synthetics
Industries Limited.
While reviewing the books of accounts of Amrapali Infrastructure Private Limited and M/s Jotindra
Steel and Tubes Limited, it has been observed that Amrapali Infrastructure has made purchases
from M/s Jotindra Steel against Letter of Credit. The letter of credit has been discounted by M/s
Jotindra Steel with the banks. The discounting charges of INR 1.30 Crores have been debited by M/s
Jotindra Steel to M/s Amrapali Infrastructure. We fail to understand the reason for this treatment.
In normal course of business, the supplier is the person who bears the discounting charges in
respect of the transactions as the margin when sold on Letter of Credit are generally higher. This
amount of INR 1.30 Crores on account of discounting charges of Letter of Credit Should be
recovered from M/s Jotindra Steel and Tubes Limited. i. It has also been observed that M/s Jotindra
Steel and Tubes Limited has issued service invoices for erection, shifting and transportation charges
amounting to INR 96 lakhs approximately during the financial year 2014-15 as per details given
below:
                              Name of       Gross                            Nature of the
Date       Bill number        the Party     Amount     Tax       Total       Service
                              Jotindra
           JST/FBD/SG/000 Steels &          5,000,00    618,00             Erection
6/6/2014   1                  Tubes                0         0   5,618,000 ChargesBikram Chatterji vs Union Of India on 23 July, 2019

                              Jotindra
           JST/FBD/SG/000 Steels &          2,532,00                       Transportatio
6/6/2014   2                  Tubes                0    78,239   2,610,239 n Charges
                              Jotindra
12/1/201                      Steels &                                     Transportatio
4          Bill not available Tubes          247,500     7,648     255,148 n Charges
                              Jotindra
12/1/201                      Steels &                                     Transportatio
4          Bill not available Tubes          365,000    11,279     376,279 n Charges
                              Jotindra
                              Steels &                                     Transportatio
2/1/2015   Bill not available Tubes          221,400     6,841     228,241 n Charges
                              Jotindra
                              Steels &                                     Transportatio
2/1/2015   Bill not available Tubes          182,700     5,646     188,346 n Charges
                              Jotindra
3/31/201                      Steels &                                     Transportatio
5          Bill not available Tubes          164,700     5,089     169,789 n Charges
                              Jotindra
3/31/201                      Steels &                                     Transportatio
5          Bill not available Tubes          216,000     6,675     222,675 n Charges
                                                                9,668,71
Further, on scrutiny of the invoices issued by the JSTB it appears that the invoices raised for the
above services are completely different from the invoices issued regularly and are prima facie
non-genuine. Hence, the same should be recovered from JSTB or the Company Management as
both the parties have been partnering in various projects. ii. It is further observed that purchases
amounting to INR 7.09 Crores, INR 59.53 Crores and INR 47.04 Crores has been made from this
party in M/s Amrapali Infrastructure Private Limited during the financial year 2013-14, 2014-15 and
2015-16 respectively. While sample checking of the purchase bills, it was noted that the goods
consignment notes enclosed with the purchase bill are issued by M/s Synergy Freightways Private
Limited which is also a group Company of Jotindra Steel and Tubes Limited. Goods consignment
note enclosed with the purchase bills don’t seem to be genuine in view of the undermentioned
observations:
1. We sent a letter to M/s Synergy Freightways Private Limited as per address on
record which has been received back as undelivered.
2. Statement of Mr. Akhil Sureka, Managing Director of M/s Jotindra Steel and
Tubes Limited was recorded and it was confirmed by him that most of the purchase/
sales transactions are back to back i.e. all such consignments are sent directly from
their supplier to Amrapali Group of Companies. In these circumstances it is not
understood by us that how the consignment notes of M/s Synergy Freightways
Private Limited have been enclosed with most of the purchase bills, if the
transactions were back to back for their supplies.Bikram Chatterji vs Union Of India on 23 July, 2019

3. On scrutiny of the tally data/documents of Amrapali Infrastructure Private Limited
and JST, it has been observed that no freight has been paid to M/s Synergy
Freightways Private Limited either by Amrapali Infrastructure Private Limited or by
JST.
This clearly establishes that all the GRs issued by M/s Synergy Freightways Private Limited are not
genuine. Further, most of the purchase invoices of JST have been shown as sale on the same date
with similar particulars/ quantity by raising the invoice on Amrapali Infrastructure Private Limited.
We are of the view that these sales invoices raised by JST are also not genuine and are mere
accommodation entries only. Sample details of such transactions for 2 days are enclosed below:
Amt. of Sr. Date of Bill Bill (In Date of Time Time No. the bill No. Rs.) the GR GR No.
In Out 1 07.02.2015 698 1,652,641 07.02.2015 698 15:48 18:12 2 07.02.2015 699
1,462,037 07.02.2015 699 16:22 17:31 3 07.02.2015 701 1,136,176 07.02.2015 701
15:52 17:49 4 07.02.2015 703 1,143,610 08.02.2015 703 16:02 12:19 5 07.02.2015 704
1,138,241 08.02.2015 704 10:09 11:57 6 07.02.2015 705 1,138,241 08.02.2015 705
10:54 14:58 7 07.02.2015 706 1,382,740 08.02.2015 706 14:43 18:04 8 08.02.2015
713 892,503 09.02.2015 713 9:20 14:29 9 08.02.2015 715 952,167 09.02.2015 715
14:28 17:23 1 08.02.2015 716 948,647 09.02.2015 716 14:23 17:22 11 08.02.2015 717
890,025 09.02.2015 717 9:45 14:40 12 08.02.2015 718 1,032,512 09.02.2015 718 9:52
14:43 13 08.02.2015 719 368,446 09.02.2015 718 9:52 14:43 14 08.02.2015 720
1,383,566 09.02.2015 720 10:27 16:08 15 08.02.2015 722 1,136,176 09.02.2015 722
10:09 17:11 16 08.02.2015 726 1,087,502 09.02.2015 - - - 17 08.02.2015 727 223,673
09.02.2015 726,727 11:47 17:13 18 08.02.2015 728 1,135,763 09.02.2015 728 14:15
18:50
4. It has been further observed that there have been unaccounted cash transactions
between the Amrapali Group of Companies and JSTB group of Companies as per
documents seized during Income Tax Search in the premises of JSTB Group of
Companies which are not accounted for in the Amrapali Group of Companies.
Complete Copy of the Order of CIT (Appeals) where the observations regarding
unaccounted cash were discussed is enclosed herewith as Annexure 34-C. II. M/s
Mauria Udyog Limited Ghaziabad While scrutinizing the ledger of this party it was
observed as follows:
a) During the month of December 2015 there were 7 purchase invoices from this
party amounting to INR 0.65 Crores all dated 18/12/15.
b) While scrutinizing the data called from M/s Mauria Udyog Limited it was noted
that they have purchased these goods vide 7 purchase invoices dated 17/12/15 for
INR 0.63 Crores.
c) There is no other purchase/Sale by M/s Mauria Udyog Limited.Bikram Chatterji vs Union Of India on 23 July, 2019

d) Similarly, in other months also 100% of the sale is made to Amrapali Group of
Companies. Since M/s Mauria Udyog Limited is a group company of Jotindra Steels
& Tubes Limited, there is very high possibility of accommodation bills being issued
and all their purchases being Non-Genuine amounting to INR 5.28 Crores for
financial year 2015-16.
e) It is further observed that all the payments against these purchases’ bills have been
made by issuing letter of credit. It seems that the Company is getting the LC’s
discounted from the bank against these non-genuine bills.
When we questioned Mr. Navneet Sureka who approached Amrapali group from trust side and who
was approached in Amrapali group. He answered “he is not able to recollect”.
He didn’t cooperate otherwise how it is possible that such a huge amount donated by Amrapali
group companies and he is not able to remember the basic question. We recommend the amount
donated should be recovered from the Sureka group.
We are of the opinion that the supplies and services provided by Jotindra Steel & Tubes Limited (Rs
321 crore) and Mauria Udyog Limited (Rs 128 crore) are prima facie bogus in nature.
1. The 2 directors namely Mr. Akhil Sureka and Mr. Navneet Sureka are equally responsible for
companies having shareholding/capital/profitsharing and should be held responsible for shortfall in
cost of construction and land dues to Noida authorities. (Refer annexure S-11 page 2960
Supplementary report)
2. Mr. Akhil Sureka opened bank account in SBI, Patiala, Faridabad in the name of Amrapali group
companies and became a signatory. Amrapali did not have any base at Faridabad but Akhil sureka
operates from Faridabad.
3. Jotindra Steel and Tubes Limited agreed to buy used construction equipments from Amrapali
Infrastructure Private Limited and paid Rs 8 crore on 13th December, 2016 and immediately
transferred that funds to group companies of Sureka group namely Jotindra Steel and Tubes
Limited and others by routing the funds from Amrapali Infrastructure Private Limited to Ultra
Home Construction Private Limited.
4. The FSI’s bought by Sureka group (details given in Chart D) without making any payment. The
modus operandi was funds were paid from one company and on the same day were transferred to
other Sureka group company by routing in 2-3 Amrapali Group companies. This would not have
been possible without active involvement of Mr. Akhil Sureka, who is bank signatory. We found on
sample basis that the amount of Rs. 80 crore so routed was originally started from Amrapali. The
amount so claimed of Rs 80 crore has been routed through various companies. this amount has
been paid out of Amrapali group against purchases and payment made to various vendors namely
Bhagirathi Tubes (Prop Mr. SHiv Kumar)etc. It was confirmed by supplier that he did not have any
knowledge of any of the transactions and stated that all transactions were carried out in good faithBikram Chatterji vs Union Of India on 23 July, 2019

under the advice & instruction of Mr. Akhil Sureka. He further submitted that he never visited any
of the Amrapali group office, he or his staff including employees has never visited any of the offices
or site of Amrapali group. When questioned on supplies of scaffolding material and steel to and
purchase sales reconciliation of supplies along with purchase orders and sales orders, he confirmed
that it is not available. The amount so paid should be recovered from the SUREKA group
companies. It was further confirmed that funds movement were also on behalf of Akhil Sureka
carried out under good faith.
5. An amount of Rs 55 crore was received from EXIM bank under line of credit for a project was to
be done in Mozambique. The group submitted a bogus bank guarantee for the said advance to
Mozambique client from a bank namely International Trade Bank Limited. Out of the funds of RS
55crore, major amount was transferred to Companies of Sureka group.
On enquiry from the Amrapali Group we came to know that the bank guarantee was made available
by Mr. Navneet Sureka, Managing Director of Mauria Udyog Limited and that no bank exist/existed
by the name International Trade Bank Limited. It was also informed that the project was under
direct control and supervision of Mr. Navneet Sureka. It shows active involvement of Mr. Navneet
Sureka in the project. Mr. Prashant Kumar and Mr. Ram Kumar are the persons who were travelling
to Mozambique and know about the project but we could not get the contact details of these 2
persons
6. Quality Synthetics (Sureka Group) had given a loan to Amrapali Sapphire of RS 3 crore in March,
2009 at the rate of interest of 14% p.a. The company kept on paying to Quality Synthetics when it
was having no funds for construction. The Amrapali Group was giving advances to various
vendors/parties interest free and taking loan from Quality Synthetics, at the rate of 14% p.a. It is
pertinent to note that the said amount of RS 3 crore along with all interest due totaling to RS 3,86
crore was repaid in March, 2018 when there were no funds available for construction of flat and the
case was pending before Honorable Supreme Court. The amount should be recovered immediately.
It is pertinent to note that the company is not doing any business and are used just for the purpose
of money laundering.
7. Sureka group was a promoter and was providing the net worth certificate at the time of allotment
of land to Noida/ Greater Noida authorities. At the time of making payment to the authorities for
land funds were arranged by them.
8. The directors other than the family have come and informed that they were not knowing about
the operations of the company and not attended any board meeting and papers were send to their
residence for signatures.
9. There are many other high value transactions which we are in process of examination.
10. Further to our supplementary report dated 30th April 2019. The directors of four companies of
Sureka Group appeared before us from 9th May 2019 to 18th May 2019, the directors gave their
statement On the basis of interaction in the statement given by them. We found as follows.Bikram Chatterji vs Union Of India on 23 July, 2019

The four companies which bought FSI for the sham companies created for the purpose of money
laundering. Neither the shareholders nor the directors of the companies were aware of any
transactions carried out by these companies. It is worthwhile to note that Mr. Vishnu Sureka, Mr.
Navneet Sureka and Mr. Akhil Sureka were neither the shareholders nor the directors as well didn’t
attend any board meeting including AGM/EGM. However, out of three who were signatory to the
bank in all the companies. Directors were not aware of who have been the signatories. When
questioned . Vishnu, navneet and akhil Sureka could not reply why they were the signatories when
they were neither shareholders, directors, employees.
Mauria Udyog Limited It was submitted in affidavit of Mauria Udyog Limited that Mauria Udyog
Limited is a manufacturer and traders. It is stated that in addition, to manufacturing of LPG
Cylinders, MUL also manufactures world class “Terry Towel” and “Apparels”. Further MUL also
trades internationally & domestically in Steel Products in addition to Ferrous & Non Ferrous metals.
MUL also deals in agro commodities such as soya bean, refined oil & deoiled cake used as fodder for
the cattle feed/poultry industry.(from affidavit of MUL para 5 page 2) We scrutinized the annual
accounts of Mauria Udyog Limited and found that the product that is TMT bars are supplied only to
Amrapali Group companies and a very minuscule quantity to other companies. In the 2010-11, TMT
bar supplied for Rs. 52.97 crore and the payment received Rs 29 crore and that is also a major part
of the payment of Rs 16.5 crore was received in March.
Similarly, in the year 2012-13, supplies were made of TMT bar and the payment was received in the
month of March 2012 just before closing of the year.
Suddenly in the year 2012-13, trend is changed and Ultra Home Construction Pvt Ltd gave an
advance of Rs 33 crore on various dates which was returned subsequently in the month of February
and March. The above transactions are dubious in nature because we scrutinized the supply bills of
Mauria Udyog Limited and found that Mauria Udyog Limited has supplied TMT bars only to
Amrapali group of companies. It is not an item in which Mauria Udyog Limited has dealt with any
other party except a miniscule quantity of 2-3 customers who in turn has also supplied to Amrapali
group. There was no purchase order from Amrapali group to Mauria Udyog Limited even the size of
TMT bar was not mentioned on the invoice of Mauria Udyog Limited. The rate charged by Mauria
Udyog Limited are higher in the range of 15-20% then the market rate for which no satisfactory
explanation was provided to us. In year 2013-14, Ultra Home Construction Pvt Ltd gave Rs 2.45
crore to Mauria Udyog Ltd which was returned on 29th March. It is surprising to find out that in the
year 2014-15 in the month of May and June, Ultra Home Construction Pvt Ltd has accepted LCs
from banks without booking of any purchase of material. The company’s bank account is used for
accommodation bills and Mauria Udyog Ltd was paid an excess of Rs 1.16 crore over and above an
accommodation bill. In the year 2015-16, in the month of May Amrapali group started supplying
TMT bars to Mauria Udyog Ltd, the purpose of supplies of TMT bars by Ultra Home Construction
Pvt Ltd was not explained to us. In the year 2015-16, total supplies are to the extent of Rs 15.79 crore
and in the year 2016- 17 amounting to Rs 5.36 crore. In the year 2015-16, payments were made to
Mauria Udyog Ltd on behalf of Shri Satguru Metalloys Pvt Ltd and Bhagirathi Tubes of Rs 8 crore
and Rs 6.50 crore respectively. We were not explained any reasons for making such payments. It is
pertinent to note that the company is not doing any business and are used just for the purpose ofBikram Chatterji vs Union Of India on 23 July, 2019

money laundering. Shri Narayan Rajkumar Merchants Ltd A group company of Sureka group paid
Rs 1 crore to Amrapali Sapphire Developers Pvt Ltd. The entire amount along with interest payment
of Rs 1.11 crore was paid to Shri Narayan Rajkumar Merchants Ltd, surprisingly Amrapali group
didn’t charge any interest on payments made to Sureka group of companies but it had paid without
fail interest @ 13.45% to Shri Narayan Rajkumar Merchants Ltd. Further an amount of Rs 2 crore
was paid to Shri Narayan Rajkumar Merchants Ltd on 31st March 2018, when the matter was
pending before the Honourable Supreme Court. The amount of Rs 2 crore should immediately be
recovered from Shri Narayan Rajkumar Merchants Ltd and Sureka family.
It is pertinent to note that the company is not doing any business and are used just for the purpose
of money laundering. Conclusion We are of the opinion that this company floated/formed for the
purpose of money laundering and FSI sold to these companies were merely accounting and
adjustment entries done by them transferring funds from one account to another as reported earlier
in our supplementary report. The modus operandi adopted by Sureka family was the same as
adopted by Amrapali Group i.e. they formed the companies, their employees who were paid salaries
in the range of Rs 20,000-Rs 60,000 the shareholders and directors in these companies. It is
pertinent to note that their signatory to the bank are family members. Mr. Navneet Sureka and Mr.
Akhil Sureka used these companies for the purpose of money laundering of funds of Amrapali
Group. The bank guarantee was bogus and we couldn’t find the bank name which issued the bank
guarantee, it appears that there was a criminal conspiracy and the bank was not in existence.
Mr. Navneet Sureka was in full control of Amrapali group companies which is very clear and can be
understood from the transactions of donation. On the instructions of Mr. Navneet Sureka,
GM/DGM accounts Mr. Adhikari was transferring funds to the trust from various group companies
of Amrapali as and when desired by him and instructed by him.
None of the directors ever attended a board meeting it was informed that the directors signed the
paper under the instructions and directions of Mr. Akhil Sureka. The fact was accepted by Mr. Akhil
Sureka. This proves that there was non compliances of holding board meetings and AGM as
required u/s 174 of Companies Act, 2013. Further, the bank signatories to the bank are Mr. Vishnu
Sureka and Mr. Navneet Sureka as an authorized signatory. In what capacity they were the
signatory, they could not explain and it was told by Mr. Akhil Sureka and Mr. Vishnu Sureka that the
directors were having full faith upon them therefore authorized them as bank signatory surprisingly,
directors were not the signatory this is an unique case which is difficult to found in the corporate
history.
When there was a transfer of shares from one shareholder to other in full or part of his/her
shareholding there was no transactions for consideration through banking channels.
23. 27 Additional companies
(i) Funds invested to become the consortium partners by these 27 companies were from the
Amrapali group of companies and these 27 companies were just the face created to comply the
conditions of partners and also keeping in mind to demerge a part of the plot in furtue to theBikram Chatterji vs Union Of India on 23 July, 2019

consortium partners. The funds contributed by these 27 companies were originated and routed from
the Amrapali group companies.
(ii) These companies were managed by CFO Mr. Chander Wadhwa, Company Secretary Mr. Pankaj
Mehta and CA Mr. Anil Mittal. General:
1. The companies were formed for the purpose of acquiring the shares in the 47 group
companies to gain the position of consortium partner, for villa in Goa, immovable
property E/17 Surajkund Noida, D- 151 , Preet Vihar, NewDelhi, First Floor-E-57,
Preet Vihar, New Delhi. for routing the cash during demonetization and booking flats
in IT Park Greater Noida of Ultra Home Construction Private Limited.
The cash on Hand of Rs. 1.98 crore. From these companies is not traceable and is misappropriated
and be recovered from CA Anil Mittal The Directors in these companies are Junior employees of
Anil Mittal Statutory Auditors namely
1. Pankaj Mehta Company Secretary of Amrapali group of Companies
2. Vivek Mittal Nephew of Anil Mittal
3. Chandan Kumar Office boy of Anil Mittal
4. Seema Mittal wife of Anil Mittal
5. Chandar Wadhwa CFO
6. Bushan Sharma
7. Ashish Jain employee of Anil Mittal
8. Amit Wadhwa Nephew of Chandar Wadhwa List of companies are as under:
S.no Name of company Page no
1. Aptara Infrastructure Pvt Ltd
2. Bhavya Housing Projects Private Limited
3. Bushells Developers Private Limited
4. Chintapurni Estates Private Limited 5 DH Education Services Pvt Ltd
6. Earthwell Developers Pvt LtdBikram Chatterji vs Union Of India on 23 July, 2019

7. Eklavya Building Solutions Pvt Ltd
8. Bushells Reality Solution Private Limited
9. Saffron Propmart Consultancy Private Limited
10. GaurisutaBuildhome Private Limited
11. Gaurisuta Real Estate and Developers Private Limited
12. Kamyani Realtors Private lImited
13. Kapila Building Solution Private Limited
14. MahamayaBuildcon Private Limited
15. Rinku Clothing Creation Private Limited
16. RRS Properties Private Limited
17. Spacewell Developers Private Limited
18. StatelinesBuildwell Private Limited
19. Mansarovar Textiles Private Limited
20. Rainbow Cotton Private Limited
21. Kamakshi Buildwell Private Limited
22. Golden Portfolio Consultant Private Limited
23. Double Esh Infrastructure Private Limited
24. Aashirwad Linens Private Limited
25. Aksh Real Estates Private Limited
26. AdhunikBuildtech Private Limited
27. Rinku Computech Private Limited We recommend the forfeiture of the following investment in
the group companies by these 27 companies because the funds invested to become the consortium
partners were from the group companies and these companies were just the front created to comply
the conditions of partners and also keeping in mind to demerge a part of the plot in future to theBikram Chatterji vs Union Of India on 23 July, 2019

consortium partners. The funds contributed by these 27 companies were originated and routed from
the Amrapali group companies.
                                                              Paid-Up Capital
S.    Name of the            No. of      Investment in        Number of     Number of    % of
No.   Company                Shares      which Amrapali       Equity        Preference   Equity
                                         Group Co.            shares of     Shares of    Shares
                                                              respective    respective
                                                              co.           co.
1     Aksh Real Estate Pvt               Amrapali Centurian
      Ltd                    8,20,000    Park Pvt Ltd         36,50,000     8,50,000     22.47%
2     DH Education                       Amrapali Centurian
      Services Pvt Ltd       5,01,500    Park Pvt Ltd         36,50,000     8,50,000     13.74%
3     Mansarovar Textiles                Amrapali Centurian
      Pvt Ltd                3,71,000    Park Pvt Ltd         36,50,000     8,50,000     10.16%
4     Bhavya Housing                     Amrapali Leisure
      Projects Pvt Ltd       1,000       Valley Pvt Ltd       10,000        4,57,334     10.00%
5     Kamayani Realtors                  Amrapali Leisure
      Pvt Ltd                1,000       Valley Pvt Ltd       10,000        4,57,334     10.00%
                                         Amrapali Leisure
6     Chintapurni Estates                Valley Developers
      pvt Ltd                1,000       Pvt Ltd              10,000        6,00,000     10.00%
7     Aashirwad Linens                   Amrapali Dream
      Pvt Ltd                1,500       Valley Pvt Ltd       10,10,000             -    0.15%
8     Rainbow Cotton Pvt                 Amrapali Dream
      Ltd                    1,000       Valley Pvt Ltd       10,10,000             -    0.10%
9     Rinku Clothing                     Amrapali Silicon
      Creation Pvt Ltd       1,429       City Pvt Ltd         10,36,982             -    0.14%
      Double Esh
10    Infrastructure Pvt                 Amrapali Smart
      ltd                    1,000       City Dev. Pvt Ltd    6,91,42,401           -    0.00%
11    Earthwell                          Amrapali Smart
      Developers Pvt Ltd     1,000       City Pvt Ltd         10,000                -    10.00%
                                         Amrapali Smart
                             1,000       City Dev. Pvt Ltd    6,91,42,401           -    0.00%
12    Sapcewell                          Amrapali Smart
      Developers Pvt ltd     1,000       City Pvt Ltd         10,000                -    10.00%
                                         Amrapali Smart
                             1,000       City Dev. Pvt Ltd    6,91,42,401           -    0.00%
13    GaurisutaBuildhome                 Mums Megha Food
      Pvt Ltd                200         Park Ltd             10000                      2.00%Bikram Chatterji vs Union Of India on 23 July, 2019

14    Rinku computech                    Amrapali Biotech
      Pvt Ltd                23,94,000   India Pvt Ltd        1,20,00,000                19.95%
15    Kamakshi Buildwell                 Mums Megha Food
      Private Limited        500         Park Ltd             10000                      5.00%
Rs. 100 of Crores of home buyers funds in active connivance of CFO Chandar Wadhwa and Statutory
Auditors Anill Mittal were routed through
1. Rinku Computech Private Limited Patel Advance JV 8,25,00,000 Case Enterprises Ltd 10,00,000
Manjeet Singh 16,00,000 MSB Software Technologies 2,40,000 Anil Kumar Sharma 9,85,000
Bhushan Sharma 34,00,000 Digital India 19,59,110 KK Shukla 9,00,000 RV Consultant Service
95,00,000 Sundry Advances 26,99,000 Sunita Bhagwani 20,00,000 Saffron Propmart Consultancy
Pvt Ltd 7,10,00,000 TOTAL 17,77,83,110 Date Particulars Transaction Balance 28-03-2018 Balance
as on 28/03/2018 4,06,50,815 Payment to Saffron Propmart 29-05-2018 Less: Consultancy Private
Limited 3,90,00,000 Less: Payment to Preeti Jaiswal 1,50,000 Less: Other Payments 5,90,771
Balance before proceeds 9,10,044 from FDR Receipts From FDR 31-07-2018 Add: Proceeds from
FDR 9,86,19,983 Balance after proceeds from 9,95,30,027 FDR Payments made out of receipts from
FDR Net Payment to Saffron 31-07-2018 Less: Propmart Consultancy 3,20,00,000 Private Limited
01-08-2018 Less: Payment to Vandana 2,00,00,000 Wadhwa 23-10-2018 Less: Payment to Ample
Hotels & 1,00,00,000 Resorts 23-10-2018 Less: Payment to Moral Sales 1,00,00,000 23-10-2018
Less: Payment to Mahalaxmi 1,00,00,000 Enterprises 23-10-2018 Less: Payment to Annex IT
70,00,000 Distributors 23-10-2018 Less: Payment to Anjali Buildcon 1,00,00,000 Other Payments
1,61,904 TOTAL 9,91,61,904 Balance as on 28-10-2018 3,68,123
24. Misuse of Bank Loan funds (Volume II Page No. 426-457) Diversion of loan funds for
unapproved purposes Amrapali group of companies obtained funds primarily from following
sources:
a) Home buyers funds against construction linked progress;
b) In the form of loans (term loan, working capital/cash credit limits) from banks
against construction linked progress; and
c) Homebuyers also availed housing loans from banks for purchasing flats in
Amrapali projects Banks granted loans to Amrapali group under certain terms and
conditions which included utilisation of loan funds for:
a) Payment of cost of land and lease rental to Noida authorities;
b) Payment of construction cost of projects.Bikram Chatterji vs Union Of India on 23 July, 2019

Observation
1. The amounts disbursed were not utilised for payment of cost of land or for payment of lease
rentals or for payment of construction cost. The banks did not monitor utilisation of funds granted
by them. In fact, these funds were diverted as loans to related and/or unrelated entities which was
ultimately utilised in building assets/purposes which were unapproved by the banks. The banks
acted as mute spectator to unapproved diversion which was almost happening evidently in all
banking transactions.
2. While obtaining loan funds, Amrapali group hypothecated land on which project was being
undertaken as well as building under construction as well as material lying at project, leaving
nothing with home buyers for recovery of their payments.
3. It is also observed that the loan funds were routed through several bank accounts of the same
company and thereafter routed to third parties whereby trying to misguide the flow of funds. It
clearly means these transactions had no substance and were made only to mislead.
1. In the case of Amrapali Zodiac Developers Pvt Ltd:
Bank of Baroda (Rs.75 crore), Union Bank of India (Rs.50 crore) and Corporation
Bank (Rs.25 crore) together approved term loan amounting to Rs.150 crore to
develop a group housing project at Sector-126, Noida. These funds were granted
against the aforesaid term loan, the banks secured first charge by way of assignment
or creation of security interest of-
(i) All the rights, title, interest benefits, claims & demands whatsoever of the
borrower in –
(a) permits, approval, clearances, etc. in respect of project being financed.
(b) any letter of credit, guarantee, performance bond, corporate guarantee, bank
guarantee, provided by any party under the project.
(ii) All the receivables, reserves, book debts, bank accounts, including the Escrow
account & all other incomes, present & future pertaining to the projects being
financed.
(iii) All insurance contracts, insurance proceeds.
(iv) Charge on the specific reserve to be created by Ultra Home Construction Private
Limited, the holding company by contributing 10% of their profits to address the
contingent liabilities of their subsidiaries.Bikram Chatterji vs Union Of India on 23 July, 2019

The banks also secured second charge over the land & buildings (First charge is with Noida
Authority). Also hypothecated raw Material, work in progress (pari passu charge over the project
assets). Immediately on receipt, these funds were diverted to several third parties as stated S.No.
Particulars Amount 1 U Tek Sales Corporation 6,97,39,500 2 Taneja Building material Suppliers
4,24,01,000 3 Devki Nandan Trading Co 3,00,00,000 4 Guru Kripa Traders-2 3,00,00,000 5 Shri
Balaji Cement & Hardware 2,89,61,000 6 Investor Clinic Infratech Private Limited 2,00,00,000 7
Mauria Udyog Limited 3,00,00,000 8 Shiva Trders 2,00,00,000 9 Shiv Traders 1,75,00,000 10 Om
Traders 1,35,00,000 11 Lakshmi Steel 1,20,81,351 12 Mahaveer Enterprises 1,00,00,000 13
Sidhivinayak Trading Company 1,00,00,000 14 Rama Trading Company 75,00,000 15 Uday
Enterprises 69,50,500 16 Orient Trading Company 68,96,800 17 Kartikey Enterprises 68,72,600 18
Dayal Traders 68,42,300 19 R.K. Enterprises 67,50,500 20 MahaLuxmi Traders 67,32,500 21
Purnima Steel Syndicate 65,71,972 22 New Payal Traders 64,50,500 23 Shyam Sales Corporation
64,38,700 24 Kishan Steel Corporation 62,53,700 25 Shri Ganesh Trading Company 62,50,500 26
Arhaan Enterprises 62,17,570 27 Gayatri Traders 59,42,500 28 Lakshmi Steels 53,42,600 29 Guru
Kripa Traders 50,00,000 30 Guru Nanak Trading Company 50,00,000 31 R R Enterprises
50,00,000 32 Rohit Steel 50,00,000 33 Shree Ji Trading Company 50,00,000 34 Shri Hari Trading
Company 50,00,000 35 G.S. Enterprises 49,50,500 36 A.B Enterprises 48,16,654 37 Amit Steel
40,00,000 38 Barnala Steel Industries Ltd 36,72,008 39 S.R Steel 34,92,054 40 Kumar Trading
Company 32,45,859 41 Quality Synthetics Private Limited 25,00,000 42 Shri Bankey Bihari Trading
Company 25,00,000 43 Jayem Manufacturing Co Pvt Ltd 23,15,400 44 SBL Construction Private
Limited 22,10,040 45 ANALCO ( INDIA ) PVT LTD 21,86,728 46 Kumar Trading CO 19,53,325 47
BUILD TECH INDUSTRIES 19,06,800 48 M. K TRADERS 16,20,370 49 Shree Ram Plywood
14,79,510 50 ARUNACHAL TIMBER TRADERS PVT LTD 13,98,400 51 Naveen Associates
13,60,217 52 Deepak Mehta & Associates 13,50,000 53 Raj Shree Ispat 10,92,584 DREAM
INTERIORS & DEVELOPERS (P) 54 LTD 10,00,790 55 Aryan Corporate Soloutions Pvt Ltd
10,00,000 56 Astech Marketing Private Limited 6,81,321 57 Jotindra Steel & Tubes Ltd 5,00,250 58
Amrapali Infrastructure Private Limited 2,94,829 TOTAL 51,37,23,732 Few examples of diversion of
funds are as under:
1. Guru Kripa Traders-2 RS. 3 crore was paid as advance to them in October 2010
which remained as it is till January 2011, when expenses for purchase of steel were
booked against the aforementioned advance. Below is the extract of relevant portion
of ledger.
Date Particulars Vch Type Debit Credit Balance 05/10/2010 Bank of Baroda Payment 15000000.00
15000000.00 A/C No - Dr 21580200000079 06/10/2010 Bank of Baroda Payment 5000000.00
20000000.00 A/C No - Dr 21580200000079 15/10/2010 Bank of Baroda Payment 5000000.00
25000000.00 A/C No - Dr 21580200000079 16/10/2010 Bank of Baroda Payment 5000000.00
30000000.00 A/C No - Dr 21580200000079 29/12/2010 STEEL Purchase 1105440.00
28894560.00 U.P Dr 01/01/2011 STEEL Purchase 1137012.00 27757548.00 U.P Dr 01/01/2011
STEEL Purchase 1127296.00 26630252.00 U.P Dr 01/01/2011 STEEL Purchase 1081575.00
25548677.00 U.P Dr 01/01/2011 STEEL Purchase 1114169.00 24434508.00 U.P Dr 02/01/2011
STEEL Purchase 1096914.00 23337594.00 U.P Dr 02/01/2011 STEEL Purchase 1078802.00
22258792.00 U.P Dr 03/01/2011 STEEL Purchase 1091563.00 21167229.00 U.P Dr 03/01/2011Bikram Chatterji vs Union Of India on 23 July, 2019

STEEL Purchase 858603.00 20308626.00 U.P Dr 04/01/2011 STEEL Purchase 1107007.00
19201619.00 U.P Dr 04/01/2011 STEEL Purchase 1084429.00 18117190.00 U.P Dr 05/01/2011
STEEL Purchase 1077003.00 17040187.00 U.P Dr 05/01/2011 STEEL Purchase 1062433.00
15977754.00 U.P Dr 05/01/2011 STEEL Purchase 1054560.00 14923194.00 U.P Dr 06/01/2011
STEEL Purchase 1112498.00 13810696.00 U.P Dr 06/01/2011 STEEL Purchase 1118674.00
12692022.00 U.P Dr 07/01/2011 STEEL Purchase 1034488.00 11657534.00 U.P Dr 07/01/2011
STEEL Purchase 1087996.00 10569538.00 U.P Dr 08/01/2011 STEEL Purchase 1082110.00
9487428.00 U.P Dr 08/01/2011 STEEL Purchase 1054092.00 8433336.00 U.P Dr 09/01/2011
STEEL Purchase 1116534.00 7316802.00 U.P Dr 10/01/2011 STEEL Purchase 1109399.00
6207403.00 U.P Dr 10/01/2011 STEEL Purchase 1073727.00 5133676.00 U.P Dr 10/01/2011
STEEL Purchase 1087996.00 4045680.00 U.P Dr 11/01/2011 STEEL Purchase 1062669.00
2983011.00 U.P Dr 11/01/2011 STEEL Purchase 889730.00 2093281.00 U.P Dr 12/01/2011 STEEL
Purchase 1023600.00 1069681.00 U.P Dr 13/01/2011 STEEL Purchase 1097561.00 27880.00 Cr
U.P 31/03/2012 REBETE & Journal 27880.00 DISCOUNT 30027880.00 30027880.00
2. Shri Balaji Cement & Hardware RS. 2.08 crore was paid as advance to them towards the end of
March 2011 against which expense was booked on 31st March 2011 and continued till 1st week of
April 2011. It was noticed that the same person was selling steel, bricks, cement, rodi sand,
badarpur, which itself is in unorganised sector and is questionable.
Date          Particulars       Vch Type        Debit        Credit         Balance
19/03/2011    Bank of Baroda    Payment         3949500.00                  3949500.00
              A/C No -                                                      Dr
              21580200000079
21/03/2011    Bank of Baroda    Payment         3851500.00                  7801000.00
              A/C No -                                                      Dr
              21580200000079
26/03/2011    Bank of Baroda    Payment         6450500.00                  14251500.00
              A/C No -                                                      Dr
              21580200000079
28/03/2011    Bank of Baroda    Payment         6550800.00                  20802300.00
              A/C No -                                                      Dr
              21580200000079
31/03/2011    BADARPUR          Purchase                     456225.00      20346075.00
                                U.P                                         Dr
31/03/2011    Cement            Purchase                     490875.00      19855200.00
                                U.P                                         Dr
31/03/2011    STEEL             Purchase                     495666.00      19359534.00
                                U.P                                         Dr
31/03/2011    BADARPUR          Purchase                     471345.00      18888189.00
                                U.P                                         Dr
31/03/2011    Cement            Purchase                     496650.00      18391539.00
                                U.P                                         Dr
31/03/2011   STEEL            Purchase                     483946.00   17907593.00
                              U.P                                      Dr
31/03/2011   Cement           Purchase                     505313.00   17402280.00Bikram Chatterji vs Union Of India on 23 July, 2019

                              U.P                                      Dr
31/03/2011   BADARPUR         Purchase                     525945.00   16876335.00
                              U.P                                      Dr
31/03/2011   STEEL            Purchase                     27300.00    16849035.00
                              U.P                                      Dr
31/03/2011   Cement           Purchase                     493763.00   16355272.00
                              U.P                                      Dr
31/03/2011   BADARPUR         Purchase                     476280.00   15878992.00
                              U.P                                      Dr
31/03/2011   STEEL            Purchase                     470905.00   15408087.00
                              U.P                                      Dr
31/03/2011   Cement           Purchase                     502425.00   14905662.00
                              U.P                                      Dr
31/03/2011   BADARPUR         Purchase                     510678.00   14394984.00
                              U.P                                      Dr
31/03/2011   STEEL            Purchase                     469124.00   13925860.00
                              U.P                                      Dr
31/03/2011   Cement           Purchase                     501843.00   13424017.00
                              U.P                                      Dr
31/03/2011   BADARPUR         Purchase                     438375.00   12985642.00
                              U.P                                      Dr
31/03/2011   Cement           Purchase                     750750.00   12234892.00
                              U.P                                      Dr
31/03/2011   BADARPUR         Purchase                     754950.00   11479942.00
                              U.P                                      Dr
31/03/2011   STEEL            Purchase                     766725.00   10713217.00
                              U.P                                      Dr
31/03/2011   Cement           Purchase                     782513.00   9930704.00
                              U.P                                      Dr
31/03/2011   BADARPUR         Purchase                     754320.00   9176384.00
                              U.P                                      Dr
31/03/2011   STEEL            Purchase                     767644.00   8408740.00
                              U.P                                      Dr
31/03/2011   Cement           Purchase                     779625.00   7629115.00
                              U.P                                      Dr
31/03/2011   BADARPUR         Purchase                     778260.00   6850855.00
                              U.P                                      Dr
31/03/2011   Cement           Purchase                     788288.00   6062567.00
                              U.P                                      Dr
01/04/2011   Rodi             Purchase                     884331.00   5178236.00
                              U.P                                      Dr
01/04/2011   Cement           Purchase                     931392.00   4246844.00
                              U.P                                      Dr
01/04/2011   Rodi             Purchase                     882872.00   3363972.00
                              U.P                                      Dr
01/04/2011   Bricks           Purchase                     853965.00   2510007.00
                              U.P                                      Dr
01/04/2011   STEEL            Purchase                     844356.00   1665651.00
                              U.P                                      Dr
02/04/2011   Bank of Baroda   Payment         2310500.00               3976151.00
             A/C No -                                                  Dr
             21580200000079
02/04/2011   Bank of Baroda   Payment         5848200.00               9824351.00Bikram Chatterji vs Union Of India on 23 July, 2019

             A/C No -                                                  Dr
                 21580200000079
  02/04/2011     Cement            Purchase                    935550.00     8888801.00
                                   U.P                                       Dr
  02/04/2011     Sand              Purchase                    839969.00     8048832.00
                                   U.P                                       Dr
  04/04/2011     Bricks            Purchase                    876120.00     7172712.00
                                   U.P                                       Dr
  04/04/2011     Sand              Purchase                    831527.00     6341185.00
                                   U.P                                       Dr
  05/04/2011     STEEL             Purchase                    841333.00     5499852.00
                                   U.P                                       Dr
  05/04/2011     STEEL             Purchase                    849350.00     4650502.00
                                   U.P                                       Dr
  06/04/2011     Bricks            Purchase                    884147.00     3766355.00
                                   U.P                                       Dr
  06/04/2011     Cement            Purchase                    284130.00     3482225.00
                                   U.P                                       Dr
  07/04/2011     Rodi              Purchase                    884321.00     2597904.00
                                   U.P                                       Dr
  07/04/2011     Cement            Purchase                    931392.00     1666512.00
                                   U.P                                       Dr
  12/04/2011     Bricks            Purchase                    872193.00     794319.00
                                   U.P                                       Dr
  12/04/2011     STEEL             Purchase                    853780.00     59461.00 Cr
                                   U.P
  28961000.00                                                  29020461.00
                 Closing Balance   59461.00
  29020461.00                                                  29020461.00
3. Investor Clinic Infratech Private Limited It is evident from the books of accounts that loan funds
were utilized for payment of RS. 2 crore who had invoiced the company for brokerage expense which
is not construction linked payment. Brokerage is an indirect expense, incurred for the sale of flat.
The banks had granted funds for construction activity and not for sale activity. This is clearly
diversion of loan funds to unapproved means.
4. Shiva Traders RS. 2 crore was paid as advance on 9th October 2010 against which subsequently
invoices for purchase of steel were booked in December 2010 only to adjust the balance.
Date            Particulars        Vch Type      Debit           Credit          Balance
09/10/2010      Bank of Baroda     Payment
                A/C No -                         2,00,00,000                     2,00,00,000
                21580200000079
11/12/2010      STEEL              Purchase
                                   U.P                           10,39,959       1,89,60,041Bikram Chatterji vs Union Of India on 23 July, 2019

13/12/2010      STEEL              Purchase
                                   U.P                           10,39,964       1,79,20,077
14/12/2010      STEEL              Purchase
                                   U.P                           8,31,947        1,70,88,130
15/12/2010    STEEL               Purchase
                                  U.P                        12,47,950      1,58,40,180
16/12/2010    STEEL               Purchase                   12,47,945      1,45,92,235
                                  U.P
17/12/2010    STEEL               Purchase
                                  U.P                        14,55,941      1,31,36,294
18/12/2010    STEEL               Purchase
                                  U.P                        12,47,958      1,18,88,336
20/12/2010    STEEL               Purchase
                                  U.P                        10,39,965      1,08,48,371
01/01/2011    STEEL               Purchase
                                  U.P                        8,47,103       1,00,01,268
03/01/2011    STEEL               Purchase
                                  U.P                        10,55,136      89,46,132
04/01/2011    STEEL               Purchase
                                  U.P                        10,51,612      78,94,520
05/01/2011    STEEL               Purchase
                                  U.P                        10,63,874      68,30,646
06/01/2011    STEEL               Purchase
                                  U.P                        10,85,323      57,45,323
07/01/2011    STEEL               Purchase
                                  U.P                        10,48,579      46,96,744
08/01/2011    STEEL               Purchase
                                  U.P                        10,77,182      36,19,562
10/01/2011    STEEL               Purchase
                                  U.P                        10,73,193      25,46,369
11/01/2011    STEEL               Purchase
                                  U.P                        10,79,473      14,66,896
12/01/2011    STEEL               Purchase
                                  U.P                        8,08,790       6,58,106
13/01/2011    STEEL               Purchase
                                  U.P                        6,56,927       1,179
31/03/2011    Short & Excess      Journal
              A/c                                            1,179
20000000.00
                                                             2,00,00,000
        5.     Om Traders
RS. 1.35 crore was paid in September 2010 against which subsequently invoices for purchase of steel
were booked in December 2010 only to adjust the balance.
Date Particulars Vch Type Debit Credit Balance 02/06/2010 BOM-SEC51 A/C Payment 50,00,000
50,00,000 No - 60036386553 03/06/2010 Hardware Item Purchase 8,76,488 41,23,512 U.P
24/06/2010 Hardware Item Purchase 9,20,241 32,03,271 U.P 03/07/2010 Hardware Item PurchaseBikram Chatterji vs Union Of India on 23 July, 2019

7,57,796 24,45,475 U.P 04/07/2010 Hardware Item Purchase 7,56,000 16,89,475 U.P 05/07/2010
Hardware Item Purchase 7,20,421 9,69,054 U.P 10/08/2010 Steel Purchase Purchase 9,77,734
8,680 U.P 14/09/2010 HDFC BANK(L.N) Payment 50,00,000 49,91,320 22/09/2010 BOM-SEC51
A/C Payment 60,00,000 1,09,91,320 No - 60036386553 27/09/2010 Bank of Baroda Payment
85,00,000 1,94,91,320 A/C No -
21580200000079 01/10/2010 Bank of Baroda Payment 50,00,000 2,44,91,320 A/C No -
21580200000079 22/10/2010 BOM-SEC51 A/C Payment 1,50,00,000 3,94,91,320 No -
60036386553 25/10/2010 HDFC BANK(C.P)- Payment 1,00,00,000 4,94,91,320 14018640000045
01/02/2011 Hardware Item Purchase 9,90,150 4,85,01,170 U.P 01/02/2011 Hardware Item
Purchase 9,49,200 4,75,51,970 U.P 01/02/2011 Hardware Item Purchase 9,98,025 4,65,53,945 U.P
01/02/2011 Hardware Item Purchase 9,48,518 4,56,05,427 U.P 01/02/2011 Hardware Item
Purchase 9,18,750 4,46,86,677 U.P 01/02/2011 Hardware Item Purchase 9,06,203 4,37,80,474 U.P
01/02/2011 Hardware Item Purchase 7,80,780 4,29,99,694 U.P 01/02/2011 Hardware Item
Purchase 9,45,000 4,20,54,694 U.P 01/02/2011 Hardware Item Purchase 11,08,275 4,09,46,419
U.P 01/02/2011 Hardware Item Purchase 9,41,850 4,00,04,569 U.P 01/02/2011 Hardware Item
Purchase 12,81,000 3,87,23,569 U.P 01/02/2011 Hardware Item Purchase 9,06,780 3,78,16,789 U.P
01/02/2011 Hardware Item Purchase 9,08,523 3,69,08,266 U.P 01/02/2011 Hardware Item
Purchase 7,38,203 3,61,70,063 U.P 01/02/2011 Hardware Item Purchase 11,24,928 3,50,45,135 U.P
01/02/2011 Hardware Item Purchase 9,70,305 3,40,74,830 U.P 01/02/2011 Hardware Item
Purchase 8,93,550 3,31,81,280 U.P 01/02/2011 Hardware Item Purchase 8,91,030 3,22,90,250 U.P
01/02/2011 Hardware Item Purchase 8,94,548 3,13,95,702 U.P 01/02/2011 Hardware Item
Purchase 8,49,450 3,05,46,252 U.P 01/02/2011 Hardware Item Purchase 9,31,718 2,96,14,534 U.P
01/02/2011 Hardware Item Purchase 9,31,718 2,86,82,816 U.P 01/02/2011 Hardware Item
Purchase 8,80,530 2,78,02,286 U.P 01/02/2011 Hardware Item Purchase 9,63,375 2,68,38,911 U.P
01/02/2011 Hardware Item Purchase 10,62,810 2,57,76,101 U.P 01/02/2011 Hardware & Purchase
9,29,198 2,48,46,903 Sanitary Items U.P 01/02/2011 Hardware Item Purchase 8,13,750 2,40,33,153
U.P 02/02/2011 Hardware Item Purchase 8,56,800 2,31,76,353 U.P 03/02/2011 Hardware &
Purchase 11,98,050 2,19,78,303 Sanitary Items U.P 04/02/2011 Hardware & Purchase 9,85,950
2,09,92,353 Sanitary Items U.P 05/02/2011 Hardware & Purchase 10,58,925 1,99,33,428 Sanitary
Items U.P 06/02/2011 Hardware Item Purchase 9,39,750 1,89,93,678 U.P 07/02/2011 Hardware
Item Purchase 8,04,825 1,81,88,853 U.P 08/02/2011 Hardware Item Purchase 9,50,250
1,72,38,603 U.P 09/02/2011 Hardware Item Purchase 8,80,824 1,63,57,779 U.P 09/02/2011
Hardware & Purchase 8,30,771 1,55,27,008 Sanitary Items U.P 10/02/2011 Hardware & Purchase
7,70,921 1,47,56,087 Sanitary Items U.P 11/02/2011 Hardware & Purchase 7,88,130 1,39,67,957
Sanitary Items U.P 12/02/2011 Hardware Item Purchase 9,03,693 1,30,64,264 U.P 13/02/2011
Hardware Item Purchase 8,31,180 1,22,33,084 U.P 14/02/2011 Hardware Item Purchase 6,44,532
1,15,88,552 U.P 14/02/2011 Hardware Item Purchase 9,58,073 1,06,30,479 U.P 15/02/2011
Hardware Item Purchase 9,56,802 96,73,677 U.P 16/02/2011 Hardware Item Purchase 9,25,344
87,48,333 U.P 17/02/2011 Hardware Item Purchase 9,03,231 78,45,102 U.P 18/02/2011 Hardware
Item Purchase 6,48,732 71,96,370 U.P 18/02/2011 Hardware Item Purchase 8,02,578 63,93,792
U.P 19/02/2011 Hardware Item Purchase 8,49,912 55,43,880 U.P 20/02/2011 Hardware Item
Purchase 9,77,550 45,66,330 U.P 21/02/2011 Hardware Item Purchase 8,68,004 36,98,326 U.PBikram Chatterji vs Union Of India on 23 July, 2019

22/02/2011 Hardware Item Purchase 10,56,930 26,41,396 U.P 23/02/2011 Hardware Item
Purchase 8,29,500 18,11,896 U.P 24/02/2011 Hardware Item Purchase 9,21,413 8,90,483 U.P
25/02/2011 Hardware Item Purchase 8,79,564 10,919 U.P 31/03/2012 REBETE & Journal 10,919
DISCOUNT 54500000.00 5,45,00,000
6. Mauria Udyog Limited RS. 3 crore was diverted to the company on 29th September 2010 and
30th March 2011 for RS. 1 crore & 2 crore respectively as advance and the same was subsequently
booked against purchase of steel in January 2011 and May 2011 only to adjust the balance.
Date          Particulars       Vch Type      Debit         Credit         Balance
29/09/2010    Bank of Baroda    Payment
              A/C No -                        1,00,00,000                 1,00,00,000
              21580200000079
14/01/2011    STEEL             Purchase
                                U.P                         17,43,440     82,56,560
14/01/2011    STEEL             Purchase
                                U.P                         17,87,807     64,68,753
14/01/2011    STEEL             Purchase
                                U.P                         17,77,211     46,91,542
14/01/2011    STEEL             Purchase
                                U.P                         17,81,419     29,10,123
16/01/2011    STEEL             Purchase
                                U.P                         22,16,525     6,93,598
20/01/2011    STEEL             Purchase
                                U.P                         2,96,570      3,97,028
20/01/2011    STEEL             Purchase
                                U.P                         2,97,012      1,00,016
30/03/2011    Bank of Baroda    Payment
              A/C No -                        2,00,00,000                 2,01,00,016
              21580200000079
13/05/2011    STEEL             Purchase
                                U.P                         22,15,039     1,78,84,977
16/05/2011    STEEL              Purchase
                                 U.P                        20,97,410      1,57,87,567
17/05/2011    STEEL              Purchase
                                 U.P                        22,02,653      1,35,84,914
17/05/2011    STEEL              Purchase
                                 U.P                        21,12,682      1,14,72,232
30/05/2011    STEEL              Purchase                   21,09,193      93,63,039
                                 U.P
30/05/2011    STEEL              PurchaseBikram Chatterji vs Union Of India on 23 July, 2019

                                 U.P                        21,72,250      71,90,789
30/05/2011    STEEL              Purchase
                                 U.P                        22,02,076      49,88,713
30/05/2011    STEEL              Purchase
                                 U.P                        20,00,371      29,88,342
31/05/2011    STEEL              Purchase
                                 U.P                        22,91,842      6,96,500
31/05/2011    STEEL              Purchase
                                 U.P                        21,58,699      14,62,199
31/05/2011    STEEL              Purchase
                                 U.P                        23,54,459      38,16,658
22/08/2011    STEEL              Purchase
                                 U.P                        20,90,696      59,07,354
22/08/2011    STEEL              Purchase
                                 U.P                        12,11,312      71,18,666
22/08/2011    STEEL              Purchase
                                 U.P                        19,90,348      91,09,014
22/08/2011    STEEL              Purchase
                                 U.P                        20,68,279      1,11,77,293
22/08/2011    STEEL              Purchase
                                 U.P                        15,67,565      1,27,44,858
22/08/2011    STEEL              Purchase
                                 U.P                        23,08,793      1,50,53,651
22/08/2011    STEEL              Purchase
                                 U.P                        22,68,774      1,73,22,425
22/08/2011    STEEL              Purchase
                                 U.P                        22,56,451      1,95,78,876
01/01/2012    STEEL              Purchase
                                 U.P                        22,46,743      2,18,25,619
01/01/2012    STEEL              Purchase
                                 U.P                        23,01,728      2,41,27,347
01/01/2012    STEEL              Purchase
                                 U.P                        23,25,626      2,64,52,973
01/01/2012    STEEL              Purchase
                                 U.P                        23,49,055      2,88,02,028
3,00,00,000                                                 5,88,02,028
              Closing Balance
                                 2,88,02,028
5,88,02,028                                                 5,88,02,028
1. In the case of Amrapali Princely Estate Pvt Ltd:
Syndicate bank and Bank of India together approved term loan amounting to Rs.100
crore to develop a housing project at Plot no Gh- 02/A, Sector-76, Noida over an area
of 15.15 acres consisting of 19 towers. These funds were granted on 13th April 2013
and 15th May 2013, 6th March 2014 and 28th March 2014 for Rs. 25 crore each time.Bikram Chatterji vs Union Of India on 23 July, 2019

Against the aforesaid term loan, the banks secured first pari passu charge over the
entire project assets of Amrapali Princely Estate Pvt Ltd (including building under
construction & construction material kept at site) & receivable excluding advance
booking money. The banks also secured second pari passu charge (with first charge
on land with Greater Noida Authorities) by way of equitable mortgage on 61300
square metres of the project land at plot no.Gh-02,Sector-76, Noida Immediately on
receipt, these funds were diverted to several third parties as stated hereunder:
S.No.    Particulars                                     Payments
     1   FIXED DEPOSIT BOI                               8,25,00,000
     2   Bhagirathi Tubes B/p                            6,51,80,135
     3   Raj Shree Ispat                                 4,20,00,000
     4   Vrindavan Buildcon Pvt Ltd                      4,00,00,000
     5   Kapila Buildhome Pvt Ltd.                       3,70,00,000
     6   Sameer Builtaid Pvt Ltd.                        3,32,07,919
     7   Gaurisuta Infrastructure Pvt Ltd.               3,00,00,000
     8   Radius Synergies Pvt Ltd                        2,90,00,000
     9   Lakshmi Steels                                  2,87,00,000
   10    Arhaan Enterprises                              2,25,00,000
         Bank of India Loan A/c No-
   11    605965410000120                                 1,70,25,946
   12    GaurisutaBuildhome Pvt Ltd.                     1,40,00,000
   13    SBL Construction P Ltd (Tower C& D)             1,30,77,888
   14    Shri Balaji International                       1,19,58,509
   15    Jaypeeco India                                  1,11,79,965
   16    Lakshmi SteelB/p                                1,00,00,000
   17    Amrapali Sapphire Developers Pvt Ltd            84,22,323
   18    SPS Buildtech Pvt Ltd (Tower-B & K)             84,06,223
   19    Syndicate Bank A/c No-87801010004689            32,00,000
   20    Shriv Build Mat Pvt Ltd.                        20,00,000
   21    Ashtech Marketing Pvt Ltd.Bikram Chatterji vs Union Of India on 23 July, 2019

                                                        16,62,747
   22    GAURISUTA INFRASOLUTION PVT.LTD                10,00,000
   23    AAUSH RAJ                                      7,95,339
   24    Pradhan Projects                               1,02,271
                                             TOTAL      51,29,19,265
(i) Fixed deposit – The Company made a fixed deposit of Rs. 8.25 Crore and out of
which Rs. 3.75cr was outstanding as on 31st March 2015 which we could find if
utilized for business purpose. Rs. 4.50 cr.
was used for repayment of Loan
(ii) Radius Synergies Pvt Ltd – It is seen that RS. 1.55 crore was given as advances since 2013 and
continued giving advances till 2015 to this party. Out of these funds an amount of Rs.1 crore is
outstanding till 31st March 2015. Out of advances for Rs.1.55 crore, expenses were booked only for
Rs.52 lakh for labour charges in 2014. The veracity of the expenses booked is to be examined
(iii) Shriv Build Mat India Pvt – It is seen that Rs.20 Lakh was given as advance in 2014 which has
not returned subsequently and no expense was also booked.
2. In the case of Amrapali Eden Park Developers Pvt Ltd:
Eden Park Developers Pvt Ltd received term loan of RS. 45 crore for development of
project ‘Amrapali Eden Park’ in March 2013 from Corporation Bank to develop a
housing project. Against this, the company mortgaged plot No 27, Block F, Sector-50,
Noida, Gautam Budh Nagar, U.P. Immediately on receipt, these funds were diverted
to several third parties as stated hereunder:
 Name of party                                 Amount (RS. in crore)
 Gaurisuta Infrastructure Private Limited                           2.00
 Siddhi Interiors Private Limited                                   0.40
 Ishaan Housing & Construction                                      1.00
 Ishaan Infotech                                                    1.00
 Ishaan Infraestates India Private Limited                          1.00
 Reinfo Tech Estates Private Limited                                1.00
 Gaurisuta Infrastructure Private Limited                           2.48
 S.R. Steels                                                        0.50
 Tashima Construction Private Limited                               0.50
 Witty One Stop Solution Private Limited                            0.50
 Happy Worker Private Limited                                       0.50
 Spyy Traders Private Limited                                     0.50
 New Tech Shelters Private                                        0.50Bikram Chatterji vs Union Of India on 23 July, 2019

 BOM-CA-60024309220                                               3.00
 Dynamic Realcom Private Limited                                  2.00
 Financial World Private Limited                                  2.00
 Total                                                           18.88
25. OTHER OBSERVATIONS
1.    Cozy Habitat Builders Pvt. Ltd.
It is holding 25% shareholding in Heart Beat City Project Controlled by three
Companies namely Three Platinum, Softtech Pvt. Ltd., Pebbles Prolease Pvt. Ltd. and
baseline Infra Developers Pvt. Ltd. Cozy Habitat Builders Pvt. Ltd. Received Rs.
30,00,000 from Amrapaliand Paid Rs. 15,00,000 to Mr. Shiv Priya. We are therefore
the opinion thatthat Rs. 15,00,000 should be recovered from Cozy Habitat Builders
Pvt. Ltd. and be deposited to the treasury of the Honourable Supreme court.
2. DFC Projects Private Limited The management of DFC Projects Pvt. Ltd. as
informed were providing services to Amrapali Group for arranging funds. We found
that there invoices were paid within a period of 2-3 days from the date of raising the
invoices which raises a doubt whether there were the invoices raised for services
rendered or were adjustments. The properties/flats were booked in the name of DFC
group about which the directors Mr.Pankaj Sharma and Mr.VinayRai showed total
ignorance.
Consequent to the questioning they agreed to surrender the flats. (Refer ANNEXURE XIII.6)
3. Chaudhary ENT Udyog (Supplier of Bricks) As per the copy of the receipts issued by Amrapali
Group of Companies, it has been observed that the party had paid INR 500,000 in cash on 24th
February, 2017 vide receipt number 3074 Dated 24.02.2017 (Copy enclosed) on account of flat
Number T6-G06 that was allotted to the said party in Amrapali Grand on account of outstanding
amounts due from Amrapali Group of Companies. The Company has not recorded the receipt of the
aforesaid amount of INR 500,000 in their books of account.
This shows that this money has been taken away by the Management and hence should be recovered
from them.
It was further informed by the supplier, that Amrapali Group of Companies committed a fraud since
this flat is already sold to Mr. Nikhil Kumar Datta. The party came to know of this on 31st August,
2018, when he received a letter dated 18th August, 2018 from IDBI Bank seeking payment for
overdue amount in the name of Mr. Nikhil Kumar Datta.
This a serious kind of fraud done by the Amrapali Group of Companies. The party has even written a
letter to Police, Uttar Pradesh against the aforesaid fraud. Copy of the said letter to police along with
the letter issued by IDBI Bank to Mr. Nikhil Kumar Datta has been enclosed as Annexure 34-D.Bikram Chatterji vs Union Of India on 23 July, 2019

4. Closing Inventory as per Audited Financial Statement as on 31 March, 2015 st There is no stock
list, valuation certificate or any documentary evidence regarding physical verification with the
company or in the Statutory Auditors file. We are of the view that these are only arbitrary figures
shown in the Audited Financial Statements.
5. Fixed Assets
a) Building Account During the financial year 2013-14 a sum of INR 80.34 crores has been
capitalized to Building A/c by crediting various purchase/expense account as per journal voucher
passed on 31/03/14 as per the copy of the voucher given below.
This entry seems to be a mere adjustment entry since there is no Valuation report on the basis of
which these expenses are capitalized to Building account and no working sheet of the same is
available. We are of the view that this amount has been taken away by the Management of the
Company and this amount should be recovered from them.
6. Royalgolf Link City Projects Private Limited It has been observed that a sum of INR 4 Crores
approximately is recoverable from M/s Royalgolf Link City Projects Private Limited (Royalgolf) in
the books of Amrapali Infrastructure Pvt. Ltd. on account of supply of precast materials.
Mr. Shiv Priya was the Director of this Company from 26.9.2014 (Date of Incorporation of the
company) to 3.4.2017. This Company was formed as SPV for Cozy/Bagadiya Group of Companies
with Mr. Shiv Priya as the Director of Royalgolf launched for project “Hemisphere” . Amrapali
Group of Companies through Ultra Home Construction Private Limited and Amrapali Infrastructure
Pvt. Ltd. had given loan to Royalgolf mainly for purchase of land and its registration thereof. A
dispute arose amongst the Company in six months of its operations and on 1st April, 2015 a Loan
Settlement Agreement was signed between Amrapali Group, Cozy/ Bagadiya Group vide which 30
Villas valuing approximately INR 50.47 cr. were earmarked for Amrapali Group. Amrapali
Infrastructure Pvt. Ltd. (Infra) was the Supplier of Precast Building material and they were to supply
these materials for “Hemisphere” project worth INR 67 crores approximately. However, Infra could
supply only 24% of the contract value and due to difference between Amrapali Group and Royalgolf,
the contract was terminated in June, 2017.
Proceedings under IBC 2016 were initiated by Royalgolf against Infra and they filed a claim for INR
17.50 crores with the IRP appointed by NCLT. The matter is still in dispute at NCLT for the claimed
loan of 17.50 crores lodged by Royalgolf on Amrapali Infra.
7. Hire Charges Received The Group companies had paid hire/erection charges from the various
group companies for example Amrapali Infrastructure received Rs.170.15 crores during the period
2008-15. (Volume II – Page 306) It was further observed that there have been no details regarding
the equipment given on hire to each company and the basis of raising bills on account of hire
charges. It seems that bills for hire charges have been raised on arbitrary basis and there are no
comparative quotations for the same available.Bikram Chatterji vs Union Of India on 23 July, 2019

26. STATUS OF DATA AVAILABILITY There is overlapping in accounting data from April 2016 to
September 2016 and we found that few entries were entered in FARVISION and few in the tally for
the said period.
Due to scarcity of time audit not completed of following companies/entities/persons:
      •    Amrapali Princely Estate Pvt. Ltd.
      •    Jotindra steels & tubes Ltd.
The following companies were carved out by Amrapali Group, which are being audited and a report
on these companies will be submitted.
1) Prem Mishra Indore.
2) O2 Valley Noida
3) Heart beat city projects Noida.
27. M.S. Dhoni It is observed that the Company Amrapali Sapphire Developers Private Limited has
paid a sum of Rs. 6.52 Crores out of the total amount of Rs. 42.22 Crores paid from the Amrapali
group of Companies to Rhiti Sports Management Private Limited during the years 2009 - 2015. This
sum has been paid on account of Agreements executed by Shri Anil Kumar Sharma, CMD for and on
behalf of Amrapali Group of Companies with Rhiti Sports Management Private Limited. There is no
resolution on record authorizing Mr. Anil Kumar Sharma, CMD to enter into an agreement on
behalf of all Amrapali group of Companies. There were various agreements as per details given
below:
a) Endorsement Agreement dated 22nd November, 2009 According to this
agreement Mr. Mahendra Singh Dhoni will make himself available to the Chairmen
for three days along with one representative of Rhiti Sports. There are no documents
held on record for compliance of this condition.
b) According to the Agreement for sponsorship dated 20th March, 2015, Amrapali
Group of Companies got right to advertise as Logo Space at various places in the IPL
2015 for Chennai Super Kings. It is observed that this Agreement is on plain paper
and executed only between Amrapali and Rhiti Sports Management Private Limited
and there are no signatories on behalf of Chennai Super Kings to this Agreement. No
Resolution in favour of Shri Arun Pandey, Signatory of Rhiti Sports Management
Private Limited is attached with the said Agreement.
This clearly shows that these Agreements have just been made for payment of amounts to Rhiti
Sports Management Private Limited Company are Sham Agreements and made just for making
payments to Rhiti Sports Management Private Limited. We feel that Home Buyers money has been
diverted illegally and wrongly to Rhiti Sports Management Private Limited and should be recoveredBikram Chatterji vs Union Of India on 23 July, 2019

from them as the said Agreement in our opinion do not stand the test of Law. Amrapali Mahi
Developers Pvt Ltd • Mr. Mahendra Singh Dhoni, husband of Ms. Sakshi Singh Dhoni (director of
company) was the brand ambassador of Amrapali group and have carried out a number of
transactions with respect to endorsement of Amrapali group’s projects. He has entered in
agreements with other group company. • We are informed verbally that this company was
incorporated for development of a project in Ranchi. An MOU was also entered between the parties
though we were not provided a copy of that. We understand that copy of MOU is available with Mr.
Adhikari.
In Amrapali Sapphire Developers Private Limited a Flat (Flat No – TC- P04) has been booked in the
name of Rhiti Sports Management Private Limited by passing an adjustment entry. However Mr
Sanjay Pandey of Rhiti Sports Management Pvt Ltd denied booking of any such flat. He also
confirmed that neither the company nor any individual has any flat in Amrapli Group. Mr Pandey
confirmed that no due diligence was carried out before accepting the brand endorsement though he
informed that brand value and paying capacity was seen. No Agreement was provided though it was
agreed that it would be provided by 11th March, 2019. Expenses were reimbursed to Rhiti
Entertainment Private Limited a group company, without any agreement.
28. Properties alienated Chart D The group started alienated the properties starting from 2015-16 ,
and many properties were transferred when the case was pending before the Honourable Court with
a criminal mind to alienate the assets. The funds were routed from one account to another and
properties were registered in benami names.
For the assets sold up to 31/3/2015, we didn’t generally find anything in contravention of the details
submitted in affidavit Chart D. We have categorized the Chart-D transactions into following 3
categories:
Category A – The properties attached should be sold off and recover the amount.
Category B – The properties attached should continue to be attached.
Category C- The properties attached should be released off.
Name           of   Name of the        Area            Category   Date     of    Page   no  of
Company        of   party to which                                transfer       supplementary
Amrapali            allotment/sale                                               report
Group               was made
                                       CATEGORY-A
Ultra     Home      SKN Hospitality    1067.50         A          15th March     2791-2796
Construction        Pvt Ltd            sq. mtr.                   2017
Pvt Ltd
Amrapali            Bhuvneshwar        6.52            A          Available      2781
Homes Project       land               AcresBikram Chatterji vs Union Of India on 23 July, 2019

Pvt Ltd
Amrapali            Pradeep Mishra     123171          A          21st August    2779-2780
Homes Project                          sq. ft.                    2017
Pvt Ltd
Amrapali            Sarvome            7108            A          10th   July    2768-2769
Smartc              Housing Pvt Ltd    sq. ft.                    2017
ity Developers
Pvt Ltd
Amrapali            High       Life    8500            A          Available      2770
Dream    Valley     Commercial         sq. ft.
Pvt Ltd
Amrapali            Bihariji           22621           A          10th   July    2767-2768
Smartcity           Developers Pvt     sq. ft.                    2017
Developers    Pvt   Ltd
Ltd
Amrapali            Bihariji    High   31202           A          10th   July    2782-2783
Leisure Valley      Rise Pvt Ltd       sq. ft.                    2017
Pvt Ltd
Amrapali            Bihariji    High   13928           A          10th   July    2782-2783
Leisure Valley      Rise Pvt Ltd       sq. ft.                    2017
Pvt Ltd
Amrapali            Bihariji    High 7020              A          10th   July    2785-2786
Centurian Park      Rise Pvt Ltd     sq. ft.                      2017
Pvt Ltd
Amrapali            Bihariji           22621           A          10th   July    2785-2786
Centurian Park      Properties   Pvt   sq. ft.                    2017
Pvt Ltd             Ltd
Ultra     Home      Shri    Viniyak    6120            A          2nd    April   2790
Construction        Avas Pvt Ltd       sq. ft.                    2014
Pvt Ltd
Amrapali           Sarvome           16500           A   10th   July    2775-2776
Leisure Valley     Housing Pvt Ltd   sq. ft              2017
Developers
Private Limited
                                     CATEGORY-B
Hi-Tech    City    Anita Chandok     4027.31         B   21st   July    2755-2756
Developers Pvt                       sq.                 2016
Ltd                                  yardsBikram Chatterji vs Union Of India on 23 July, 2019

Amrapali           SBL               14500           B   23rd August    2765
Smartcity          Construction      sq. ft.             2016
Developers   Pvt   Pvt Ltd
Ltd
Amrapali           SBL               18450           B   23rd August    2765
Smartcity          Construction      sq. ft.             2016
Developers   Pvt   Pvt Ltd
Ltd
Amrapali           Bhatia            6120            B   Available      2766
Smartcity          Properties        sq. ft.
Developers   Pvt
Ltd
Amrapali           Bhatia            22200           B   6th     May    2777
Leisure Valley     Properties        sq. ft.             2015
Developers Pvt
Ltd
Hi-Tech    City    Sarbjit Leasing   1245.23         B   23rd   July    2756-2758
Developers Pvt     and     Finance   sq.                 2016
Ltd                Company           yards
Amrapali           Vaishnavi        10261            B   13th           2758-2764
Hospitality        Vahini Mount sq. ft.                  November
Services Pvt Ltd   Life Hospitality                      2017
                   Pvt Ltd
Sangam             Anjali            3.13            B   24th   April   2753
Colonizers   Pvt   Consultants       Hectare             2017
Ltd
Amrapali           Dr. J P Sharma    2.1             B   June 2017      2764
Hospitality                          Bigha
Services Pvt Ltd
Amrapali           Ajit Kumar & 11245                B   9th October    2780-2781
Homes Project      Kriti Agarwal sq. ft.                 2017
Pvt Ltd
Amrapali           Deepak Kumar      1560            B   20th August    2784
Leisure Valley                       sq. ft.             2016
Pvt Ltd
Amrapali           Bihariji          16000           B   10th   July    2770-2771
Dream    Valley    Developers Pvt    sq. ft.             2017
Pvt Ltd            Ltd
Amrapali           SBL              6500            B   5th    July     2771-2772
Dream    Valley    Construction     sq. ft.             2017
Pvt Ltd            Pvt LtdBikram Chatterji vs Union Of India on 23 July, 2019

Amrapali           SBL              20640           B   2nd       May   2778
Silicon City Pvt   Construction     sq. ft.             2017
Ltd                Pvt Ltd
Amrapali           Nirala    India 16436            B   15th            2778-2779
Silicon City Pvt   Developers Pvt sq. ft.               October
Ltd                Ltd                                  2015
Amrapali           Mr. Vinay Garg   11000           B   15th            2769
Dream    Valley                     sq. ft.             February
Pvt Ltd                                                 2018
Ultra     Home     V.               82.937          B   18th            2795-2796
Construction       Thiruvenkitam    Cents               January
Pvt Ltd            &     Thushara                       2012
                   Reddy
Amrapali           One              16360           B   25th            2786-2787
Centurian Park     Flameboyant      sq. mtr.            September
Pvt Ltd            Realty Pvt Ltd                       2013
CATEGORY-C
Sangam             Radheshyam     3.28              C   19th      Feb   2754-2755
Colonizers   Pvt   Yadav, Keshav Hectare                2015
Ltd                Yadav,
                   Surender
                   Yadav, Narayan
                   Yadav        &
                   Lakhan Yadav
Amrapali           PSK     Finance 14853            C   15th   July     2782
Leisure Valley     Solution    Pvt sq. ft.              2014
Pvt Ltd            Ltd
Amrapali           Star Land Craft 23395            C   31st   July     2784-2785
Leisure Valley     Pvt Ltd         sq. mtr.             2013
Pvt Ltd
Amrapali           Shri Balaji Hi   12479           C   31st   July     2772-2773
Dream    Valley    Tech             sq. mtr.            2013
Pvt Ltd            Construction
                   Pvt Ltd
Amrapali           K V Developers   19986           C   7th  June       2773
Dream    Valley    Pvt Ltd          sq. mtr.            2013
Pvt Ltd
Amrapali           J M    Housing   33537           C   5th  June       2773-2774
Dream    Valley    Ltd              sq. mtr.            2013
Pvt LtdBikram Chatterji vs Union Of India on 23 July, 2019

Amrapali           Samridhi         27989           C   17th June       2774
Dream    Valley    Realty   Home    sq. mtr.            2013
Pvt Ltd            Pvt Ltd
  Amrapali           Hawelia         14920        C          5th  June       2787-2788
  Centurian Park     Builders    Pvt sq. mtr.                2013
  Pvt Ltd            Ltd
  Amrapali           DSD Homes Pvt    14760       C          20th June       2788
  Centurian Park     Ltd              sq. mtr.               2013
  Pvt Ltd
  Amrapali           Elegant         14590        C          1st  June       2788-2790
  Centurian Park     Infracon    Pvt sq. mtr.                2013
  Pvt Ltd            Ltd
  Amrapali           PSK     Finance 12500        C          15th    April   2766
  Smartcity          Solution    Pvt sq. ft.                 2016
  Developers   Pvt   Ltd
  Ltd
       29. Further Assets To be Attached
• Inventory of plots at Jaipur – of company names Sangam Colonisers Pvt Ltd •
Amrapali Power & Cement Pvt Ltd – Land from Charu Rai yet to be identified, Land
from UPSIDC yet to be identified. • Vinayaka Projects at Greater Noida
30. Statement of cash flow Receipt and Payment Statement (Amount in crores) S.No
Name of the Company Amount Cost of Remarks/Assumptions received Construction
as per taken from Chart-B of latest affidavit of audited promoters financial submitted
statements on 3rd available Dec'18 1 Received from Customers Amrapali Centurian
Park Pvt The group received Rs 11573 Ltd 1050.83 573 Crore from th homebuyers
Amrapali Dream Valley Pvt and spent Only Rs. 7,389 Ltd 1270.5 549 Crore on
construction Amrapali Leisure Valley Pvt including land payment to Ltd 1563.17 594
authorities. It is pertinent to Amrapali Sapphire note it includes borrowing
Developers Pvt Ltd 1186.66 828 cost also. Any amount of Amrapali Silicon City Pvt
Ltd 1468.79 1126 expenditure which was Amrapali Smartcity outstanding is not
considered Developers Pvt Ltd 1230.87 780 in the given tabe and it is Amrapali
Zodiac Developers prepared on the bsia of Pvt Ltd 835.69 566 audited financial
statements Hi Tech City Developers Pvt latest available upto March Ltd 113.18 104.16
2015 except one company for Amrapali Eden Park which it is March 2016. It was
Developers Pvt Ltd 171 175.14 found at any given point of Sangam Colonizer Pvt Ltd
9.58 7.61 time the amount received Amrapali Grand 217 104.98 from homebuyers
was never Amrapali Princely Estate Pvt in short Amrapali Leisure Valley Amrapali
Homes Project Pvt Ultra Home Construction Pvt Sub Total (A) 11573.13 7388.89Bikram Chatterji vs Union Of India on 23 July, 2019

Sales of 2 Property/FSI/Facilities 358.68 As per affidavit The amount paid to bank as
per Chart B of affidavit is 2394 crore. We could not verify the number of amount paid
in absence of details being not available. We worked out the otstanding loan amount
from audited 3 Bank 2712.02 1827 financial statements of 2015.
The amount borrowed in against private equity which has no liabilty of principal and interest and
the investor would recover his its investments by selling the shares on/off market.
                                                            Investment in the form of
                                                            compulsory           convertible
                                                            debenture      and    optionally
                                                            convertible      would     have
                                                            interest liabilty upto date of
                                                            conversion. the debenture
                                                            were note converted on due
                                                            dates . Furthermore the
                                                            amount invested was diverted
                                                            immediately upon receipt to
4   FDI/Financial Institution           520            65   unapproved purposes.
                                                            Number has been taken from
                                                            affidavit and has not been
5   Investors                           300           200   verified by us.
                                                            Number has been taken from
                                                            affidavit and has not been
6   Partner Investment                  150          150    verified by us.
                   Sub Total (B)     4040.7        2242
              Grand Total (A+B)    15613.83      9630.89
                     Difference          5982.94            Short cashflow
1 The above does not include the cash received from customers. 2 * Assumed the figure as given in
the affidavit.
31. Mrs. Manju Rajpal and Mr. Ramesh Rajpal Mrs. Manju Rajpal and Mr. Ramesh Rajpal HUF
each invested Rs 7.5 crore in May 2011 on interest in Amrapali Leisure Valley Private Limited. The
rate of interest is 18%. However he claimed in his submission that it was an investment in
residential property for his staff because he was having a plan to shift his business operations in
Noida. He submitted that he acquired this property for residence of his staff. On reviewing the
return of income of Mrs. Manju Rajpal (Refer annexure S-1 of supplementary report page no. 2823)
and Mr. Ramesh Rajpal we found that amount invested in various units as given below:
1. Mr. Ramesh Rajpal – Unit No A-388 admeasuring 20,200 sq. feet in Amrapali
Leisure Valley Private Limited for RS 7.5 Cr. However, due to company’s inability to
handover the said villa, 8 units were allotted instead. Refer Annexure S-2 of
supplementary report page no. 2824 We found Unit No A-388 in Amrapali Leisure
Valley Private Limited is booked in the name of Mr. Joginder Sharma on 13th
February, 2016 admeasuring area 2525 sq. feet for a value of Rs 1.29 crore. It depicts
very clearly that there was no unit admeasuring an area of 20,200 sq feet and theBikram Chatterji vs Union Of India on 23 July, 2019

amount was invested for a purpose to avail Capital Gain benefits and earn interest on
investment at the rate 18% p.a. It is recommended that the units allotted as per
Annexure S-2 of supplementary report page no. 2824 should be treated as vacant and
be available for sale.
2. Mrs. Manju Rajpal – Unit No A-396 admeasuring 17,675 sq. feet in Amrapali
Leisure Valley Private Limited for RS 7.5 Cr claimed as Long term Capital gain. It is
claimed, due to company’s inability to handover the said villa, 53 units were allotted
instead. Refer Annexure S-3 of supplementary report page no. 2825-2826.
We found Unit No A-396 in Amrapali Leisure Valley Private Limited is booked in the name of Mr.
Satya Vir Srivastava on 14th July, 2014 admeasuring area 2525 sq. feet for a value of Rs 65.5 Lakh. It
depicts very clearly that there was no unit admeasuring an area of 17,675 sq feet and the amount was
invested for a purpose to avail Capital Gain benefits and earn interest on investment at the rate 18%
p.a. It is recommended that the units allotted as per Annexure S-3 of supplementary report page no.
2825-2826 should be treated as vacant and be available for sale.
The amount invested in residential property is claimed as Capital gain. Subsequently in the year
2017, the villas were shifted from Amrapali Leisure Valley Private Limited to Royalgolf Link,
Amrapali Princely Estate Private Limited, Amrapali Zodiac Developers Private Limited, Amrapali
Silicon City Private Limited, Amrapali Dream Valley Private Limited and Amrapali Smart City
Developers Private Limited and the villas numbers are attached. (Refer Annexure 2.2 and Annexure
2.3) For the amount invested of Rs 15 crore, Rs 12.25 crore has been paid to him in the form of
interest at the rate of 18%.
Exotique Exports, an entity of Mr Rajpal, invested Rs 5 crore in 2010 at the interest rate of 18%. It
had been paid Rs 4.55 till February 2016 in the form of interest. It is submitted that 5 units namely
Unit no. 118, 119, 120, 121, 122 were purchased in Amrapali Commercial Complex Cum Corporate
Hub at Plot No. Sector – 2 Manesar, Gurgaon, Haryana for Rs 5Cr however the value of 5 units as
per Builder Buyer Agreement is Rs 3.19 Cr.
32. M/s Surbhaee Advertising Private Limited (Immovable Property-A3A, Maharani Bagh, New
Delhi)
(i) Mr. Paramjit Gandhi, Mr. Gagandeep Gandhi & Ms. Jasmine Gandhi are the directors of the
company M/s Surbhaee Advertising Private Limited.
The shares of M/s Surbhaee Advertising Private Limited were purchased by Mr. Paramjeet Gandhi
& M/s Special Tools Private Limited (a company owned by him & his family) for Rs 1.59 crore for
which no agreement was provided by them.
(ii) It was informed that principal business of the company is Advertising of Projects. However no
income has been earned from its principal business activity or any other source.Bikram Chatterji vs Union Of India on 23 July, 2019

(iii) The company is holding an immovable property at A3A Maharani Bagh, New Delhi
admeasuring approximately 800 sq yards. It is also stated that the family of Mr. Anil Kumar Sharma
is residing in the same house against which no rent deed is agreed between Mr. Anil Kumar Sharma
& Mr. Paramjit Gandhi (Surbhaee Advertising Private Limited)
(iv) When asked to Mr. Paramjit Gandhi who resides in Ghaziabad that why he purchased the
property in New Delhi 4-5 years back, he replied that he wanted to shift to this property.
However the fact is that he has never shifted to Delhi & all the renovation & maintenance work was
overlooked by Mr. Anil Kumar Sharma.
(v) The company has also taken loan of Rs. 25 crores from Aditya Birla Finance Limited in the FY
2016-17 against the hypothecation of the property which was purchased for Rs 1.59 crore. This
indicates the property value was much higher on the date of transfer.
(vi) The company has advanced Rs. 25.88 crores as short term loans & advances to the following
parties-
1. Chandan Homes Private Limited- Rs. 6.89 crores.
2. Inderjeet Arora- Rs. 1.25 crores.
3. Ishwar Steels- Rs. 2.18 crores
4. Jai Kishan Estate Developers Private Limited- Rs. 1.33 crores.
5. Shekri Finance & Investment Private Limited- Rs. 3.10 crores.
6. Shubha Green Private Limited- Rs. 4.77 crores.
7. Special Tools Private Limited- Rs. 3.37 crores.
8. PJ Buildtech Private Limited- Rs. 0.55 crores.
9. Paradise System Private Limited- Rs. 0.52 crores.
10. Jiwan Kumar Arora- Rs. 0.50 crores.
11. Shubhkamna Buildtech Private Limited- Rs. 0.25 crores.
(vii) The company has also received Rs. 2.35 crores & Rs. 3.55 crores from Mr. Ritik Kumar Sinha &
Miss Swapnil Shikha respectively, also directors in M/s Surbhaee Advertising Private Limited in the
FY 2016- 17 out of funds received from Amrapali group of companies enrouted via the account of
Mr. Anil Kumar Sharma.Bikram Chatterji vs Union Of India on 23 July, 2019

(viii) It implies that the property which was bought for Rs 1.59 crore, the amount has been funded
out of Amrapali Group funds routed by Mr. Anil Kumar Sharma who is family member and from
them to Surbhaee Advertising Private Limited. Two of his family members were made director to
have a control on the property of a value of Rs 50 Cr. It further proves that the difference between
the value of property and the price at which it was transferred to Mr. Paramjit Gandhi was paid in
cash out of cash amount received in Amrapali Group by booking of bogus expenditure and selling
the flats undervalued. Opinion Based on the facts stated above, in our opinion the property at A3A
Maharani Bagh, New Delhi is a “Property” belongs to Mr. Anil Kumar Sharma/Amrapali group held
in the name of the company M/s Surbhaee Advertising Private Limited.
33. Facility Sold It is found that the facilities sold under various projects as shown in Chart M of
Affidavit submitted on 3Rd December, 2018 are mere adjustment entries (Refer Annexure S-10 of
supplementary report page no. 2958-2959).
We found that the buyer is not aware of that he has purchased any land for the mentioned facility.
We further found that there is no account in the name of the said buyers in many cases to whom the
facilities were sold. It is recommended that the facilities sold so far should be attached.
34. Mr.Prem Mishra We are of the opinion and also given to understand from various sources that
the group diverted funds in the range of 500-600 crore in Madhya Pradesh projects in particular
Indore. Mr.Prem Mishra has appeared in response to the court notice and he was non-cooperative.
We have also received a communication supporting our views, reproduced below-
“Good Evening Sir, Hope you are doing well, this is regards Amrapali Scam of CMD Anil Sharma, as
per my information CMD has transferred 1 thousand crore to the different Amrapali Townships
project of M.P. through Mr. Prem Mishra. The details of the same on paper is available with me. If
you can arrange some time and allow me to have a detail discussion of the same, that would be
great.Kindly inform me two days prior to the meeting date, as I am from XXXXXX. need to do some
arrangements for the same, its a request.
Waiting for your response.” We could not complete the examination of Mr.Prem Mishra in Indore
project due to paucity of time and request it to be included in the second audit.
35. Heartbeat City Developers Private Limited The project is in the name of 3 companies namely
Pebbles Prolease Private Limited, Three Platinum Softech Private Limited and Baseline
Infradevelopers Private Limited. The project is an Amrapali group’s project which was carved out
from Amrapali Group of companies while case was pending before Honorable Supreme Court.
Funds were invested in the project from Amrapali Group through Mr. Amit Wadhwa, Mr. Amit
Wadhwa was a partner of 25% each in Pebbles Prolease Private Limited and Three Platinum Softech
Private Limited. Amrapali Group launched and advertised the project as Amrapali Group project
and the project was named as Amrapali Heartbeat City Developers Private Limited in the
agreements. Corporate office was having the same address as Amrapali Corporate Tower in Sector
62, Noida. The purpose of carving out the project from Amrapali is not known. It is informed that
Mr. Vaibhav Jain and Mr. Sankalp Shukla are the key managerial persons. In the absence ofBikram Chatterji vs Union Of India on 23 July, 2019

accounting records we could not proceed further on the issue.
35. Summary of recoverable amounts Total recoveries from undermentioned areas:
S. No. Particulars                                                     Amount in Crores
      1 Sale of Flats at lower Prices                                            321.31
      2 Amount receivable from home buyers                                      3,624.65
      3 Amount receivable from buyers of Commercial Area                          89.83
      4 Unsold Inventory
            i) Flats                                                            1,991.69
            ii) Commercial Areas                                                 345.78
      5 Amount recoverable from           KMP’s and their Relatives:
            i)     Professional fee                                              100.53
            ii)    Advances Recoverable                                          152.24
            iii)   Cash in hand                                                   69.36
            iv)    Other recoverable                                             582.68
      6 Diversion of home buyer’s funds                                         3,152.30
      7 Non genuine purchases from suppliers                                     842.42
      8 Recovery from Others                                                      32.69
      9 Unexplained cash deposits/jewellery                                       14.94
                                  Total                                       11,320.42
 1.   Sale of Flats at lower prices
Total amount involved in under-valued transactions in respect of Companies audited by us is
Rs.321.31 Crores as per summary given below:
S.no. Name of the company Number Amount (In Refer Page Number of Units Crores)
1 Amrapali Sapphire 315 76.02 Volume – I Page No. Developers Private Limited 2
Amrapali Leisure Valley Volume – I Page No. Developers Private Limited 70 5.88
222 - Point No. 1 3 Amrapali Smart City 261 18.97 Volume – I Page No. Developers
Private Limited 4 Amrapali Silicon City Private 468 73.05 Volume – I Page No.
Limited 5 Amrapali Dream Valley Private 1,752 24.11 Volume – I Page No. Limited 6
Amrapali Leisure Valley 122 8.53 2811 Private Limited (Supplementary Audit Report)
7 Ultra Home Construction 524 30.87 2811 Private (Supplementary Limited Audit
Report) 8 AmrapaliCenturian Park 1,912 43.12 2811 Private (Supplementary Limited
Audit Report) 9 Amrapali Princely Estate 146 6.70 2811 Private Limited
(Supplementary Audit Report) 10 Amrapali Zodiac Developers 107 6.75 2811 Private
(Supplementary Limited Audit Report) 11 Amrapali Patel Platinum 179 27.31 2811
(Supplementary Audit Report) Total 5,856 321.31
2. Amount Recoverable from Home Buyers A sum of Rs.3624.65 crores is recoverable
from home buyers. Detailed summary is as under:Bikram Chatterji vs Union Of India on 23 July, 2019

    S.no. Name of the company                      Amount       Refer Page
                                                   (In          Number
                                                   Crores)
    1 Amrapali Sapphire                           46.44 Volume – I Page No.
    6 AHS Joint Venture                            3.10 Volume – II Page
    7 Hi Tech City Developers                           Volume – II Page
      Private Limited (Immediately                 2.37 No.283 – Point No. 11
      recoverable)
                                                        Volume II - Section XXII
    8 Ultra Home Construction Private             65.08 (Page No. 563– 568)
      Limited
                                                        Volume II - Section XXII
    9 Amrapali Princely Estate Private            28.17 (Page No. 563 – 568)
      Limited
      Amrapali Zodiac Developers                        Volume II - Section XXII
   10 Private                                     26.56 (Page No. 563 – 568)
      Limited
                                                        Volume II - Section XXII
   11 Amrapali Leisure Valley Private           1470.94 (Page No. 563 – 568)
      Limited
                                                        Volume II - Section XXII
   12 Amrapali Centurian Park Private            240.17 (Page No. 563 – 568)
      Limited
                                                         Volume II - Section XXII
   13 Amrapali Eden Park Private                    4.71 (Page No. 563 – 568)
      Limited
                                                        Volume II - Section XXII
   14 Amrapali Grand                              15.56 (Page No. 563 – 568)
   15 Amrapali Homes Project Pvt. Ltd.                  Volume II - Section
                                                    6.88XXIII (Page No. 569)
Total                                           3624.65
3. Amount recoverable from buyers of Commercial Area A sum of Rs.89.83 crores is
recoverable from buyers of Commercial area. Detailed summary is asunder:
S.no. Name of the company Amount Refer Page No. (In Crores) 1 Amrapali Sapphire
Developers Private 7.14 Volume – I Page 2 Amrapali Leisure Valley Developers
Volume – I Page 3 Amrapali Smart City Developers Private 19.58 Volume – I Page 4Bikram Chatterji vs Union Of India on 23 July, 2019

Amrapali Silicon City Private Limited 2.48 Volume – I Page 5 Amrapali Dream Valley
Private Limited 6.12 Volume – I Page Volume – II Section 6 Ultra Home
Construction Private 38.03 XXII (Page No. 563 – Limited 568) Volume – II Section 7
7Amrapali Princely Estate Private 5.50 XXII (Page No. 563 – Limited 568) Volume –
II Section 8 Amrapali Zodiac Developers Private 2.08 XXII (Page No. 563 – Limited
568) Volume – II Section 9 Amrapali Leisure Valley Private 3.58 XXII (Page No. 563
– Limited 568) Volume – II Section 10 Amrapali Eden Park Private Limited 3.64
XXII (Page No. 563 –
568) Total 89.83
4. Unsold Inventory There is unsold inventory of flats and Commercial areas
amounting to Rs.2337.47Crores approximately as per details given below:
a) Unsold Inventory of Flats S.no Name of the company Number Approxima Page
No. . of Units te in Realizable Reference Residential Value (In Crores) 1 Amrapali
Sapphire Developers Private 14 14.45 Volume – I Page No.39-
Limited Point No. 4a 2 Amrapali Leisure Valley Developers 329 100.67 Volume – I Page No.39-
Private Limited Point No. 4a 3 Amrapali Smart City Developers Private 183 65.29 Volume – I Page
No.39- Limited Point No. 4a 4 Amrapali Silicon City Private Limited 191 154.25 Volume – I Page
No.39- Point No. 4a 5 Amrapali Dream Valley Private Limited 1833 660.91 Volume – I Page No.39-
Point No. 4a 6 Amrapali Leisure Valley Pvt. Ltd.* 1203 412.91 Volume – II Section XXII (Page No.
563 – 568) 7 Amrapali Centurian Park Pvt. Ltd.* 981+2 329.34 Volume – II Section XXII (Page No.
563 – 568) 8 Amrapali Eden Park Developers 4 2.47 Volume – II Section XXII Pvt. Ltd.* (Page No.
563 – 568) 9 Amrapali Princely Estate Pvt. Ltd.* 3 4.54 Volume – II Section XXII (Page No. 563 –
568) 10 Amrapali Zodiac Developers Pvt. Ltd.* 27 41.48 Volume – II Section XXII (Page No. 563 –
568) 11 Ultra Home Construction Pvt. Ltd.* 459 205.38 Volume – II Section XXII (Page No. 563 –
568) Total 5,229 1991.69 *Estimated Realizable value Noida @ Rs 4,500 approximately psf and
Greater Noida @ Rs3,000 approximately psf (Amount in Crores).
     b)    Unsold Inventory of Commercial Area/Shops
S.no. Name of the Company                Unsold            Approxim       Page
                                                           ate            No.
                                         Commercial
                                                           Realizable     refere
                                                           Value (In      nce
                                         Inventory         Crores)
   1 Amrapali Sapphire Developers        1 Shop                  0.71     Volume –
      Private Limited                                                     I Page
                                                                          No.39-
                                                                          Point No.
                                                                          4bBikram Chatterji vs Union Of India on 23 July, 2019

   2 Amrapali Leisure Valley             Nursery                          Volume –
     Developers Private Limited          Schools,                         I Page
                                         NursingHomes            7.00     No.39-
                                                                          Point No.
                                         and MilkBooth                    4b
   3 Amrapali Smart City                 1 Shop                  0.49     Volume –
                                                                          I Page
                                                                          No.39-
                                                                            Point No.
  Developers Private                    1 Nursery School           4.00     4b
  Limited
4 Amrapali Silicon City Private                                             Volume –
                                        Nursery School
  Limited                                                         11.00     I Page
                                        & Milk Booth                        No.39-
                                                                            Point No.
                                                                            4b
5 Amrapali Dream Valley Private         18 Shops,                           Volume –
  Limited                               Nursery                             I Page
                                        Schools,                            No.39-
                                        Nursing Homes                       Point No.
                                        and Senior                          4b
                                        Secondary                 44.47
                                        Schools
6 Amrapali Eden Park                                               1.40     Volume
  Developers Pvt. Ltd.                                 1                    – II
                                                                            Section
                                                                            XXII
                                                                            (Page
                                                                            No.
                                                                            563 –
                                                                            568)
7 AmrapaliCenturian Park Pvt. Ltd.                     17          5.71     Volume
                                                                            – II
                                                                            Section
                                                                            XXII
                                                                            (Page
                                                                            No.
                                                                            563 –
                                                                            568)
8 Ultra Home Construction                      318 + 487         271.00     Volume
  Pvt. Ltd.                                                                 – II
                                                                            Section
                                                                            XXII
                                                                            (Page
                                                                            No.
                                                                            563 –
                                                                            568)
                 Total                                          345.78Bikram Chatterji vs Union Of India on 23 July, 2019

5. Amount recoverable from Key Managerial Persons and their Relatives
a) Professional fees paid to directors Rs.100.53 crore Name of Director Professional Fees (As per
Affidavit) (Under Disclosure in Rs. in Cr. Affidavit)Rs. in Cr.
    Anil Kumar Sharma         29.13                    8.75
    Shiv Priya                26.43                    24.65
    Ajay Kumar                5.76                     -
    Suvash Chandra Kumar      5.11                     -
    Amresh Kumar              0.68                     -
    Total                     67.13                    33.40
      b)   Advances recoverable
A sum of Rs.152.24 crores is recoverable from the Directors on account of their taxes paid, advance
given for purchase of Shares and Other Advances given including their family members. The
companies gave advances which were neither adjusted nor squared off against any future purchases
or services under taken by the companies from the said parties nor were received back by the
companies Stunning Construction Private Limited had made payments of Direct Taxes which were
neither received back by the Company nor adjusted against any services. In other words the said
advances are still standing to the debit (recoverable from these parties) in the books of the
Company. This includes a sum of INR 17.43 Crores paid on behalf of directors, senior employees and
their family members. Please refer executive summary on Page 39 of Volume 1 of Final Report.
Summarized as below:
S.no. Name of the Amount Anil Kumar Shiv Priya Ajay Others company (In Sharma
and and family Kumar Crores) family and family 1 Amrapali Sapphire 0.50 0.02 0.39
0.09 -
Developers Private Limited (Page No. 202-219) 2 Stunning 17.43 6.4 5.57 1.7 3.76 Construction
Private Limited (Page No. 196-201) 3 Amrapali Smart City 0.02 - - - 0.02 Developers Private
Limited (Page No.-
229-244) 4 Amrapali Silicon 0.28 0.05 0.23 - -
City Private Limited (Page No. 255-266) 5 AHS Joint Venture 9.58 6.18 3.12 0.28 -
(Page No.- 273-
278) 6 Amrapali 113.54 73.25 35.15 5.14 -
Infrastructure Private Limited (Page No. 286-306) 7 Sangam Colonizers 0.03 - - - 0.03 Private
Limited (Page No.189-192) 8 Amrapali Hospitality 6.62 6.55 - - 0.07 Services Private Limited (PageBikram Chatterji vs Union Of India on 23 July, 2019

No. 346-350) 9 Hi Tech City 4.24 4.24 - - -
  Developers Private
  Limited (Page No.
  279-285)
                     Total   152.24             96.69           44.46       7.21       3.88
  Recoverable from other KMPs is as under:
      Name of the Party                                   Amount as on
                                                          31stMarch, 2018
      ChanderWadhwa and Family                                           2.55
      Mohit Gupta and Family                                             0.16
      SuvashChander Kumar                                                0.67
      Amresh Kumar                                                       0.17
      NishantMukul                                                       0.12
      Adhikari Devi Prasad and Family                                    0.02
      Anil Mittal and Company (Statutory Auditor)                        0.19
      Total                                                              3.88
   Cash inHand
Cash in hand of various Companies is not physically available nor deposited in the banks and
siphoned by the Directors amounting to Rs.69.36 crores should be recovered from the Directors as
per details given below:
S. no. Name of the Company Amount (In Crores) 1 Stunning Construction Private
Limited 0.17 2 Amrapali Sapphire Developers Private Limited 0.11 3 Amrapali
Leisure Valley Developers Private 0.23 Limited 4 Amrapali Smart City Developers
Private Limited 10.79 5 Amrapali Silicon City Private Limited 3.58 6 Amrapali Dream
Valley Private Limited 8.02 7 Hi-tech City Developers Private Limited 0.46 8
Amrapali Infrastructure Private Limited 3.16 9 Sangam Colonizers Private Limited
0.15 10 Navodaya Properties Private Limited 0.24 11 Hawthorne Intellect
Management Solutions 0.01 Private Limited 12 MSB Software Technology Private
Limited 0.70 14 GaurisutaInfrasolution Private Limited 0.01 17 Amrapali Hospitality
Services Private Limited 0.01 18 KapilaBuildhome Private Limited 0.03 19
MannatBuildcraft Private Limited 0.20 20 Ultra Home Construction Private Limited
0.22 21 AmrapaliCenturian Park Private Limited 7.45 22 Amrapali Eden Park
Developers Private 2.00 Limited 23 Amrapali Grand 0.50 24 Amrapali Homes 0.19
25 Amrapali Homes Projects Private Limited 0.23 26 Amrapali Leisure Valley Private
Limited 9.79 27 Amrapali Media Vision Private Limited 9.67 28 Amrapali Princely
Estate Private Limited 5.02 29 Amrapali Smart City Private Limited 0.50 30
Amrapali Zodiac Developers Private Limited 3.84 31 Gaurisuta Infrastructure Private
Limited 0.02 32 MVG Techno Consultants Private Limited 0.13 33 Noida Texfab
Private Limited 0.13 34 La Residentia Developers Private Limited 0.30 35 AmrapaliBikram Chatterji vs Union Of India on 23 July, 2019

Biotech India Private Limited 1.50 Total 69.36
a) Advance Recoverable from Non-Related Parties Amounts given as advances to
third parties without any business transactions which have not been adjusted along
with the amount received/paid for the Non–Genuine transactions amounts to
Rs.256.22 crores + Rs.326.46 crores and should be recovered from the management
of the Amrapali group of Companies.
The Company has given advances to various parties. The said advances that were given by the
Company were neither adjusted nor squared off against any future purchases or services. No details
regarding Pan, Address and Nature of Advance has been given to us. The actual amount may be
much higher.
S. no. Name of the Company Amount (In Refer Page No. Crores) 1 Amrapali Sapphire Developers
73.06 Volume – I Page Private Limited No.40- Point No.4c 2 Amrapali Leisure Valley Developers
19.67 Volume – I Page No.40- Point No.4c Private Limited 3 Amrapali Smart City Developers 17.20
Volume – I Page Private Limited No.40- Point No.4c 4 Amrapali Silicon City Private Limited 50.41
Volume – I Page No.40- Point No.4c 5 AHS Joint Venture 15.81 Volume – I Page No.40- Point
No.4c 6 Hi-tech City Developers Private 8.91 Volume – I Page Limited No.40- Point No.4c 7
Amrapali Infrastructure Private 40.24 Volume – I Page No.40- Point No.4c Limited 8 Sangam
Colonizers Private Limited 0.36 Volume – I Page No.40- Point No.4c 9 Amrapali Power and Cement
Private 0.91 Volume – I Page Limited No.40- Point No.4c 10 Hawthorne Intellect 0.17 Volume – I
Page Management Solutions No.40- Point No.4c Private Limited 11 Amrapali Aerocity Private
Limited 0.01 Volume – I Page No.40- Point No.4c 12 Amrapali Buddha Developers Private 0.47
Volume – I Page Limited No.40- Point No.4c 13 Gaurisuta Infrasolution Private 1.24 Volume – I
Page Limited No.40- Point No.4c 14 Amrapali Hospitality Services Private 13.55 Volume – I Page
Limited No.40- Point No.4c 15 Kapila Buildhome Private Limited 0.41 Volume – I Page No.40-
Point No.4c 16 Mums Mega Food Park Private 1.29 Volume – I Page Limited No.40- Point No.4c 17
Mannat Buildcraft Private Limited 0.99 Volume – I Page No.40- Point No.4c 18 Amrapali Patel
Platinum 7.85 Volume – I Page No.40- Point No.4c 19 Stunning Constructions Private 0.44 Volume
– I Page Limited No.40- Point No.4c 20 Amrapali Dream Valley Private 3.23 Volume – I Page
Limited No.40- Point No.4c 21 Amrapali Grand 29.17 Annexure X.2 Final Report Volume – IV 22
Amrapali Homes 21.41 Annexure X.2 Final Report Volume – IV 23 La residential Developers Pvt.
Ltd. 23.35 Annexure X.2 Final Report Volume – IV 24 Amrapali Eden Park Developers 3.02
Annexure X.2 Final Pvt. Ltd. Report Volume – IV 25 Gaurisuta Infrastructure Pvt. Ltd. 0.46
Annexure X.2 Final Report Volume – IV 26 Jhamb Finance & Leasing Pvt. 5.93 Annexure X.2 Final
Ltd. Report Volume – IV 27 Ultra Home Construction Pvt. Ltd. 87.68 Annexure X.2 Final Report
Volume – IV 28 Amrapali Homes Project Pvt. Ltd. 55.01 Annexure X.2 Final Report Volume – IV 29
Amrapali Zodiac Developers Pvt. 28.07 Annexure X.2 Final Ltd. Report Volume – IV 30 Amrapali
Smart City Pvt. Ltd. 0.95 Annexure X.2 Final Report Volume – IV 31 Amrapali Leisure Valley Pvt.
Ltd. 51.62 Annexure X.2 Final Report Volume – IV 32 Amrapali Media Vision Pvt. Ltd. 4.96
Annexure X.2 Final Report Volume – IV 33 Amrapali Health care Pvt. Ltd. 0.22 Annexure X.2 Final
Report Volume – IV 34 Stunning Construction Pvt. Ltd. 14.61 Annexure X.2 Final Report Volume –
IV Total 582.68 Advance Construction co Pvt ltd is/was a partner holding 9% in Amrapali PatelBikram Chatterji vs Union Of India on 23 July, 2019

Platinum and 66% in AHS Joint Venture Project with Ultra Home Construction Pvt Ltd. They
overdrew 7.10 crore and 14.81 crore from the respective joint venture totaling to 21.91 crore While
scrutinizing the documents sent by Advance Construction Company Private Limited, detail of capital
contribution of the Advance Construction Company Private Limited as on 1st April, 2008 and
thereafter is as under (as per tally data and confirmed by Advance Construction Company Private
Limited):
Particulars As on 31st As on 31st As on 31st As on 31st March, 2007 March, 2008
March, 2009 March, 2010 Capital Account 3,00,00,000 50,00,000 (6,10,00,000)
(7,10,00,000) Note: The negative figures represent debit/ recoverable balance.
The aforesaid amount of Rs.7.10 crores should be recovered from the said party along
with interest of Rs.7.24 Crores (computed at 12% p.a. simple interest) in view of the
undermentioned observations:
• The clause 12 of MOU dated 11th November, 2006 clearly states that the profit
would be divided amongst the partners in the profit-sharing ratio.
• The Audited Financial Statements of the firm for the financial year 2013-14 reflect
the firms Reserve and Surplus as Rs.35,433 only.
• No other clause in the MOU states regarding payment of Interest on Capital.
• It is not understood that how the said Company has withdrawn Rs.10.10 Crores on
an investment of Rs.3 Crores invested for only a period of 1.5 years from this
partnership firm. No satisfactory explanation has been given to us by the
Management.
Even the ledger account sent by the said Company confirms that they owe Rs.7.10
Crores to this firm as on 31st March, 2018 after which an entry has been passed in the
books of accounts.
As per supplementary partnership cum deed of retirement dated 31st Day of March,
2014, 2 partners namely M/s Patel Engineering Limited and M/s Advance
Construction Company Private Limited have retired from the partnership and M/s
Amrapali Infrastructure Private Limited has joined as a partner with M/s Ultra Home
Construction Private Limited. However, the amount of Rs.7.10 Crores was not
adjusted and was shown as payable to Amrapali Patel Platinum by Advance
Construction Company Private Limited since 2014 till 2018. Further, The Audited
Financial Statements of Amrapali Infrastructure Private Limited for the financial
year 2013-14 and thereafter don’t reflect any investment in Amrapali Patel Platinum.
All the aforesaid facts clearly depict that the aforesaid supplementary partnership
cum deed of retirement, ledger of Amrapali Patel Platinum in the books of AdvanceBikram Chatterji vs Union Of India on 23 July, 2019

Construction Company Private Limited are contradictory and fabricated.
While scrutinizing the Audited financial statements/Tally data detail of capital
contribution of the Advance Construction as on 1st April, 2008 and thereafter is as
under:
            (Amount in    Crores)
Particulars   As on        As on     As on     As on     As on     As on       As on     As on
              31st         31st      31st      31st      31st      31st        31st      31st
              March,       March     March     March     March     March       March     March
              2008         , 2009    , 2010    , 2011    , 2012    , 2013      , 2014    , 2015
Capital            4.22       4.25      4.26      4.32      4.35      4.35        4.30      4.30
Account
Current        (12.56)     (14.82)   (14.82)   (14.82)   (14.82)    (14.82)    (14.82)   (14.82)
Account
Note: The negative figures represent debit/ recoverable balance.
The aforesaid amount of Rs.10.52 crores should be recovered from the said party
along with interest of Rs.17.78 croresupto 31st March 2018 (computed at 12% p.a.
simple interest) in view of the undermentioned observations:
a. It is not understood that how the said Company has withdrawn Rs.14.82 crores on
an investment of Rs.4.30 crores. No satisfactory explanation has been given to us by
the Management.
b. As informed to us by Advance Construction vide their mail dated 6th March, 2019,
the Company had effectively retired from the said partnership and all the project
related responsibilities were handed over to Mr. Sharma, (of Ultra Home) and the
same was evidenced by an MOU dated 17th January, 2006.
This explanation given by Advance Construction is not satisfactory since the
Company is continuing as a partner and the subsequent Audited Financial
Statements have also been signed by Advance Construction as a Partner sharing
profit/ loss. This shows that MOU as referred by Advance Construction is bogus/
legally not enforceable.
c. Further, Partnership firm has been legally dissolved as per dissolution deed dated
2nd Day of April, 2018. This shows that Advance Construction is continuing as a
partner in this firm till this date. It has also been mentioned in the dissolution deed
that the accounts of the firm have been made upto 31st March, 2014 to the mutual
satisfaction of all the parties here to. Even this dissolution deed is dated 2nd April,
2018 doesn’t seem to be genuine in view of the following observations: i. It refers to
the Audited Financial Statements for the financial year 2013-14, whereas the Audited
Financial Statements are available upto financial year 2014-15.Bikram Chatterji vs Union Of India on 23 July, 2019

ii. The deed of dissolution has not been notarized. iii. The Witnesses to this
Dissolution Deed are incomplete in so far, name and address of witness number 1 is
not there and signature of witness number 2 is not there.
iv. There is no copy of the resolution available authorizing Mr. Shiv Priya to sign the
deed of dissolution.
The Company has made cash payments to various parties exceeding INR 20,000 in
contravention to The Income Tax Act 1961, to the tune of INR 45,768,482 in just one
company namely Amrapali Sapphire Developers Pvt Ltd. This is just tip of the iceberg
and actual amount may be much much higher. Most of these payments are not
supported by evidence. It was further observed that neither the Statutory auditor has
mentioned these cash payments exceedingRs.20,000 in his report and nor any
addition has been made by the Income Tax department in framing the Assessments
for the Assessment year 2014-15 vide order dated 31.03.2016.
Financial Year Name of Party Expense Debited Amount 2012-13 Staff Incentive 2,252,720 2014-15
Unity Contractor Labour 1,600,000 charges of Contractor ShailenderaDhwaj (T Z-
2014-15           803)                            -                       1,399,500
2013-14           MV Ayer (TL-506)                -                       1,000,000
                  Other Petty Amounts
                  between 20,000 to 10
                  Lakhs                                                  39,516,262
Total                                                                   45,768,482
  6.   Diversion of home buyer’s funds
Further as per financial statements and the books of accounts scrutinized by us up to 31st March
2015, a sum of Rs.1,588.59 Crores has been diverted to other projects, other group companies,
directors and their relatives and senior employees. As per summary given below:
S.no. Name of the company Amount Refer Page No. (In Crores) 1 Amrapali Sapphire
Developers Private Limited 113.98 Volume – I Page 2 Amrapali Leisure Valley
Developers Private 134.25 Volume – I Page Limited 3 Amrapali Smart City
Developers Private 532.76 Volume – I Page Limited 4 Amrapali Silicon City Private
Limited 347.36 Volume – I Page &8 5 Amrapali Dream Valley Private Limited 457.82
Volume – I Page 6 Hi Tech Developers Private Limited 2.42 Volume – II Page Total
1,588.59
7. Non genuine purchases from suppliers The total amount of non-genuine/ bogus
purchases amounting to Rs.842.42croresapproximately. Details are as follows:
Non genuine purchases from Suppliers (Refer Page No. 2800 Supplementary
Report& Annexure No. S-4) Rs. 837.12 crore Add: Land development charges bookedBikram Chatterji vs Union Of India on 23 July, 2019

without supporting documents Rs. 7.30 crore Total Rs. 842.42 crore
8. Recovery from Others A sum of Rs.32.69 croresis recoverable from others as per
details given below:
Sr. No. Name of the Company Amount Refer Page No. in crores 1 Advance
Constructions Private 25.02 Volume – I Page Limited No.43 2 ATN Infratech Private
Limited 0.70 Volume – I Page No.43 3 AlokRanjan 0.25 Volume – I Page No.43 4
RinkuComputech 1.19 Volume – I Page No.43 5 Casita Propmart Private 0.08
Volume – I Page No.43 Limited 6 Digital India (Controlled by Anil 0.86 Volume – I
Page Mittal) No.43 7 AadhunikBuildtech Private 0.12 Volume – I Page No.43 Limited
8 Kapila Building Solutions Private Volume – I Page 0.05Limited No.43 9 Ozone GSP
Infratech 0.42 Volume – I Page No.43 10 Royalgolf Link City 4.00 Volume – I Page
No.43 Project Private Limited Total 32.69
9. Unexplained cash deposits/jewellery Details are as under:
       Name of person                      Amount/       Refer Page No.
                                           value (in
                                           crore)
       Anil Kumar Sharma (Cash)                 5.73     Volume II - page no
                                                         419, Point no 7
                                                1.50     Volume II - page no
                                                         420, Point no 12
       Raj Dulari (mother of Anil               0.13     Volume II - page no
       Kumar Sharma) (Cash)                              420, Point no 9
       Shiv Priya (cash)                        6.00     Volume II - page no
                                                         422, Point no 6
                                         1.00   Volume II - page no
                                                422, Point no 11
 Shiv Priya (Jewellery)                  0.58   Volume II - page no
                                                422, Point no 11
 Total                                  14.94
10. Balance due to Noida Authority and Greater Noida Authority as per affidavits
submitted by them before Hon’ble Supreme Court of India The Group paid only 1st
installment to Noida and Greater Noida authorities and did not pay in almost all the
cases the installment due, lease rent and interest under one pretext or another. The
Group has not made any provision for additional interest due to delay in payments of
installments. We had issued a letter dated 30th January, 2019 to Noida Authority to
send us the complete information/ documents regarding the amounts due from
Amrapali Group of Companies. But we have not received any such details from the
Noida Authority. In these circumstances balance due to Noida Authority Couldn’t be
verified by us.Bikram Chatterji vs Union Of India on 23 July, 2019

It was further informed to us by the management of Amrapali that Noida and Greater Noida
authorities have submitted three claims before the Honourable Supreme court. We were produced
one of the annexure of the affidavit and the same is reproduced below. We found that Noida/Greater
Noida authority administration was non active for reasons best known to them. Amrapali group
never paid the 2nd installment but Noida and Greater Noida authorities continued to allot large size
land to them without fail. They never bothered to issue even a notice to be pasted at site for the
information of home buyers that the land dues had not been paid so that home buyers could be
cautious and on alert. In spite of non receipt of any installment, lease rent, interest they were very
trumped in giving no objection certificate for the borrowings to Amrapali group from different
sources like JP Morgan, ICICI and Aditya Birla Pvt equity funds and/or various banks.
a)   Noida Authority
      S. no. Name of the Company                              Amount
                                                              (In
                                                              Crores)
      1     Amrapali Sapphire Developers Private                  348.8
            Limited
      2     Eden park Developers Private Limited                  31.7
      3     Amrapali Silicon City Private Limited                537.9
      4     Amrapali Princely Estate Private Limited             149.6
      5     Amrapali Patel Platinum                              115.5
      6     Amrapali Zodiac Developers Private Limited           276.1
                             Total                            1,459.6
             b)   Greater Noida Authority
                    S.no.   Name                                          Amount
                                                                          (In
                                                                          Crores)
                        1 Amrapali Smart City Developers Pvt Ltd           628.06
                        2 Amrapali Leisure Valley Developers Pvt Ltd       255.37
                        3 Amrapali Leisure Valley Pvt Ltd                  914.33
                        4 AmrapaliCenturian Park Pvt Ltd                   569.36
                        5 Amrapali Dream Valley Pvt Ltd                    718.28
                                            Total                         3,085.4
                                        Grand Total                         4,545
                                           (a+b)
             11. Balance payable against Term Loans
                                                                  Date      of         Total   (In
Name of the Company                     Name of the bank          Confirmation         Crores)
                                        Indian Overseas Bank              31-12-2018        16.15
Ultra Home Constructions
Private Limited                         Corporation Bank                    5/2/2019        91.49
Amrapali Smart City Developers Private
Limited                                Corporation Bank                     5/2/2019       143.74Bikram Chatterji vs Union Of India on 23 July, 2019

Amrapali Leisure Valley                Andhra Bank                          5/2/2019        98.04
Developers Private Limited
                                       Bank of Maharashtra                  5/2/2019       179.02
                                       A/c
                                        Andhra Bank                         5/2/2019        13.56
                                        Bank of Maharashtra                 5/2/2019        22.24
Amrapali Silicon City Private Limited   Bank of Maharashtra                 5/2/2019        95.34
                                        Total                                              659.58
Note: Information in respect of bank loans has been given to the extent of availability of
documents.” 61(a). The aforesaid is the summary of report of the Forensic Audit which states that
the Group collaborated with external parties like J.P. Morgan in contravention of FEMA and
distributed returns along with the principal amount, even though it did not book gains within the
business of the company.
(b). The report also reveals various disturbing features that no accounts were prepared from 2015 to
2018 and money was withdrawn out of it and diverted from one company to another. The entire
transactions were not being entered into Tally. The opening balances were not entered properly. In
April 2015, the Amrapali Group introduced Far Vision an ERP, which was also not implemented
properly.
(c). There was no information about purchases from the supplier. During a search in 2013, it was
held by Income Tax Authorities that purchases are being made from bogus suppliers without
receiving the goods physically. Bogus expenses and cash has been surrendered by Amrapali Group
in the income tax search.
(d). The amount shown as developmental charges is not supported by evidence or vouchers. The
total bogus expense has been ascertained to Rs.842.42 crores. An amount of Rs.0.25 crore was paid
to Mr. Alok Ranjan towards brokerage.
(e). The company has also made unusual cash payments in the financial year 2016-2017 by
transferring cash to the Site, but the same is not supported/authenticated by the Site Cash
In-charge. Certain payments have not been found to be genuine.
(f). The Group Companies purchased gold bar worth Rs.5.88 crore, which is a personal expense and
it should be recovered from the management of the company.
(g). The amount disbursed by Banks was not utilised for constructions of projects and the funds of
homebuyers as well as the amount disbursed from the Banks were diverted to unapproved uses,
namely, creation of personal assets of Directors; creation of assets in closely held companies by
Directors along with their partners and relatives; funds were used for personal expenses of
Directors; funds were advanced to unrelated entities for several years without levying interest on
unrealized amount, the recoverable amount from third parties has amounted to Rs.326 crores;
creation of discreet projects for personal income; and construction of assets for other projects.Bikram Chatterji vs Union Of India on 23 July, 2019

(h). There were negligence and non-monitoring by Bankers. There was a transfer of funds from one
company to another company to a third company and so on and so forth on the same dates would
not have been possible without the active support of the Bankers. They turned blind eye to all the
transfers and did not inquire, which were being routed every day. If they had been alive to the
situation, the Management would not have dared to launder the money from one company to
another according to their whims and fancies and the Bankers are solely responsible for the
negligence on their part. The Bankers did not do any monitoring. The Bank of Maharashtra and
Andhra Bank also failed to do the monitoring. Even the basic checks were foregone. The Banks acted
as a mute spectator to unapproved diversion which was happening evidently in all banking
transactions. Even, Noida and Greater Noida Authorities were grossly negligent in reviewing and
monitoring the progress of projects and did not take any action for non-payment of land dues and
continued to allot land to Amrapali Group for the reasons best known to them.
(i). The Directors along with trust partners discreetly divided the projects into two parts:
(i) Projects in which home buyers funds were received and funds were diverted from
these projects;
(ii) Projects to which home funds were diverted. These projects were subsequently
separated/demerged from Amrapali Group, e.g., Heartbeat City, La Residentia,
Vinayaka Square.
(j). Several dummy companies were formed in the names of office boys and peons.
Technically, the allotments at the initial stage were void ab-
initio. The amount received by the Companies from home-buyers was more than the amount spent
on construction and for payment of the land. The sole objective of taking a loan was to divert the
funds to other ventures to create assets in the name of family members and to make movies. Villas
were bought at tourist destination for fun at the expenses of the middle class and low-income group
people.
(k). Several companies were created solely for the purpose of routing funds. These companies did
not have any material transaction as per the main object for which they were incorporated and did
not have a business since their incorporation.
62. As is apparent from the report, several companies were created only to route the funds and
transactions consisting of office boys, persons with no income and dummy companies in which
family members and relatives were inducted as members only for few transactions, which are as
under:
(1) Jhamb Finance & Leasing Private Limited.
It was under the control of Mr. Chander Wadhwa, CFO. It has advanced loans amounting to Rs.875
crores to related and unrelated entities, which are recoverable.Bikram Chatterji vs Union Of India on 23 July, 2019

(2) Gaurisuta Infrastructure Private Limited It was also created for diverted funds.
(3) Neelkanth Buildcraft Private Limited Similarly it was formed for the purpose of buying shares
from J.P. Morgan at exorbitant rates, consisiting of office boys and relatives of Mr. Anil Mittal,
Statutory Auditor.
(4) Stunning Construction Private Limited As per findings of the Forensic Auditors, they should
either surrender 19.75 percent of land or 632 flats.
(5) Kapila Buildhome Private Limited It financed a sum of Rs.392.68 crores. It accepted
non-interest bearing inter-corporate deposits from non-group companies, which was used for
money laundering.
(6) Rudraksha Infracity Private Limited It was consisting of office boys and relative of Anil Mittal,
Statutory Auditor, which was created to receive money from Mannat Buildcraft Private Limited and
to transfer it to J.P. Morgan Investments by purchasing it at exorbitant rates and for no other
transaction.
(7) Mannat Buidcraft Private Limited It was created for money laundering of Rs.120 crores, only for
few transactions.
(8) Amrapali Magadh Developers Private Limited It did not carry out any principal business activity.
The purpose of its creation is not clear. The shareholders paid the share application money in cash.
(9) Amrapali Mahi Developers Private Limited It received share capital in cash and all the expenses
were paid in cash.
(10) Amrapali Spring Valley Private Limited It was created for the purpose of routing and diversion
of funds amounting to Rs.186 crores has been found.
(11) Amrapali Media Vision Private Limited It was created making movies. There was no necessity of
creation of this company for advertising. It was created to divert funds to make movies. Rhiti
Management Private Limited was paid Rs.24 crores for professional charges and advertisement
expenses etc. (12) Hawthrone Intellect Management Solutions Private Limited It had paid up capital
of Rs.1 lakh and incurred losses of Rs.2.33 crores. The expenses are inflated to wipe off the various
loans and advances received from sister concerns. The entries have found to be dubious and the
amount of loss of Rs.2.33 crores to be recovered from the Directors as it was wiping off the amount
of the homebuyers. (13) Amrapali Smart City Private Limited It is stated in the report that plot
allotted to Amrapali Smart City Private Limited was cancelled, therefore, money receivable from
Greater Noida is Rs.18.35 crores.
(14) Amrapali Biotech India Private Limited It was created for routing funds. The ICD's are either
from the group companies or received from outside the group companies through adjustment
entries.Bikram Chatterji vs Union Of India on 23 July, 2019

(15) Amrapali Healthcare Private Limited It formed the property by funds of Ultra Home
Construction Private Limited created from home buyers’ funds. It deserves to be sold. (16) Amrapali
Centurian Park Private Limited The Forensic Auditors have found bogus booking of expenditure and
certain adjustments against bogus billings of River Sand for an amount of Rs.3.60 crores.
(17) Amrapali Leisure Valley Private Limited Mr. Akhil Kumar Surekha became the Director and
thereafter most diversions of funds took place through the current account. The funds of the
company were transferred to and fro with companies in which Surekha family had control. FSI was
sold without taking approval from Great Noida Authority. The money received from Bihari High
Rise Private Limited was diverted to Jotindra Steel & Tubes Limited and Ozone GSP Infratech by
routing it through Ultra Home Construction Private Limited. Bihariji High Rise Private Limited,
Jotindra Steel & Tubes Limited and Mauria Udyog Limited are owned by Surekha family. There was
bogus booking of expenditure since March 2018 also of Rs.2.86 crores and other bogus entries of
huge amounts.
(18) Amrapali Homes It has been found that Mauria Udyog Limited has to pay Rs.20 crores and the
same be recovered.
(19) La Residentia Developers Private Limited The consortium of five members was created, which
was controlled by Amrapali Group. The shareholders and directors were just acting faces for
outsiders. There was diversion of funds since beginning of the project itself. The company purchased
raw material from Amrapali Infrastructure Private Limited amounting to Rs.67.45 lakhs, but not
even a single penny was paid since then. The loan amount of Rs. 49 crores were taken. On the other
hand, there was withdrawal by Directors and advances given to the related parties and entities.
Amrapali Group transferred some of their buyers to La Residentia Developers Private Limited and
the payment for the same was received by Amrapali Group. They were reflected as customers in the
customer data of Amrapali Group. The company is using the brand name/trademark of Amrapali
Group on its letterheads. (20) Amrapali Homes Projects Limited Mr. Prem Mishra was given
Rs.12.40 crores for purchase of land since 1st April 2008, out of which Rs.10 crores are still
receivable from him. Rs.55.87 crores are recoverable amounts and out of which Rs.20.75 crores
pertain to advances against land which has not been charged to cost of construction.
(21) Ultra Home Construction Private Limited The flats were allotted on false promises, forged
documents and certain allotted flats did not exist in the approved building plan. Shareholders used
the money of home buyers for allotment of shares in the company. The records of certain lands
purchased by the company disappeared, the details of which have been given. The company has
advances recoverable amounting to Rs.111 crores. (22) Amrapali Grand Bihariji Ispat Udyog Limited
always had negative capital. Loans and advances amounting to Rs.25.73 crores have been diverted.
The other diversions have also been noticed in the report. (23) Amrapali Eden Park Developers
Private Limited There is no substance in the nature of transactions of the company. It was for
routing funds form one entity to another to hidden objective. Banks loans were diverted as advances
to third parties. The funds were diverted for purposes other than development.Bikram Chatterji vs Union Of India on 23 July, 2019

63. Several companies were created for building assets. There was no compliance of the statutory
obligations by the companies. The annual returns and audited financial statements have not been
filed after 31.3.2015. The Registrar of Companies has disqualified the Directors, namely, Mr. Anil
Kumar Sharma, Mr. Amresh Kumar, Mr. Shiv Priya, Mr. Ajay Kumar and Mr. Suvash Chandra
Kumar for a period of 5 years under Section 164(2) of the Companies Act, 2013. The Company has
not been regular in payment of TDS and service tax and has also not filed relevant returns after
31.3.2015. Mr. Anil Mittal, CA (Statutory Auditor) and Mr. Chander Wadhwa, CFO were in
connivance with each other. Mr. Anil Mittal, CA blindly signed the accounts and along with Mr.
Chander Wadhwa, CFO is grossly involved in making manipulation in the accounts. He has received
payment on account of professional charges in the name of companies in which his relatives were
Directors and this fact has not been disclosed in the audited financial statement. A sum of Rs.52.07
crore was adjusted on account of professional fees due and to be paid on account of audit fees.
Further, a sum of Rs.16.36 crore was adjusted against a flat in Amrapali Princely Estate on account
of audit fees. They incorporated 27 additional companies identified. They were shell companies,
whose share capital was mostly subscribed in cash and the transfer of shares was also in cash leaving
no audit trail. The home-buyers funds to the extent of Rs.5,619.47 crores have been diverted. There
was diversion of funds to various suppliers, fake purchases and advances without any adjustment.
Siphoning off funds had also taken place by way of booking under-valued transactions in respect of
the sale of flats. The Forensic Auditors have also traces of receiving cash from home-buyers, which is
not accounted for in the books of accounts. The home-buyers funds were diverted to the tune of
Rs.5,619.47 crores to the other companies through (i) payment of professional fee to Directors for
Rs.100.53 crores; (ii) bogus billing for Rs.842.42 crores; (iii) under-valuing of flats to the tune of
Rs.321.21 crores; (iv) brokerage was paid against flats which were not sold by the company; and (v)
inter-corporate deposits were given to related entities.
64. In J.P. Morgan, had also been found to routing money and in violation of FEMA by the Forensic
Auditors. As pointed out, the equity shares were purchased at an exorbitant price to suit the
requirements of J.P. Morgan. Sudit K. Parikh & Co., Chartered Accountants and the Auditors made
the valuation on the basis of information provided by J.P. Morgan Investments. Amrapali Zodiac
Developers Pvt. Ltd. has diverted home buyers fund and there was no need for any investment from
J.P. Morgan. It was in the knowledge of Mr. Suraj Chhabria and also in the knowledge of J.P.
Morgan that money had been diverted.
65. Rule 4 of FEMA Rules has been referred by the Forensic Auditors pointing out that External
Commerical Borrowings (ECB) can be accessed under two routes namely Automatic Route and
Approval Route. Under Automatic Route, the ECB is not permitted to be utilized for real estate
sector, whereas under Approval Route the ECB are not permitted to be utilized for real estate. Rs.60
crores were remitted to Amrapali Leisure Vally Developers Pvt. Ltd. by J.P. Morgan without
obtaining approval from the competent authority so as to make investment in the form of ECB. It is
necessary to comply with the following :
(a) obtaining Loan Registration Number from R.B.I.;
(b) file ECB-2 returns every month to the R.B.I.;Bikram Chatterji vs Union Of India on 23 July, 2019

(c) withhold tax on interest payment to J.P. Morgan under Section 195 of the Income
Tax Act. As per Article 11 of the Avoidance of Double Taxation Agreement between
India and Mauritius, the tax shall be charged @ 7.5 percent of the gross amount of
interest;
(d) J.P. Morgan would have to file its income tax return under Section 139 of the Income Tax Act in
India due to withholding tax on its interest income borrower.
66. The Forensic Auditors have also reported duplicate allotment of flats. They have provided the
details of flats. Flats were alloted (residential and commercial) to the brokers and suppliers of which
list has been given. Utilities like Milk Booth, nursery schools, senior secondary schools, nursing
homes alloted to various parties should be cancelled.
67. With respect to Sureka Group, it is pointed out in the Forensic Audit Report that they have been
a partner in various projects and were authorised cheque signatories in various companies. It is
observed that Rs.13.44 crores were paid to Surekha Public Charitable Trust, which is a group
institution of Jotindra Steel and Tubes Limited, which amount should be recovered from Jotindra
Steel & Tubes Limited. An amount of Rs.9,506,120 should also be recovered from Surekha Group.
Funds were routed through Synergy Freightways Pvt. Ltd. Mr. Atul Kumar was alloted a flat which
was not by way of adjustment. The amount should be recovered or his flat may be attached.
68. With respect to R.N. Traders, an amount of Rs.2,714.02 lakhs have been withdrawn by the
management for the purpose of their own use and should be recovered from the management. There
is a billing of Rs.5.28 crores for the financial year 2015-16 in the name of Mauria Udyog Limited.
Forfeiture of the investments has also been suggested in the group companies named by the
Forensic Auditors.
CONSIDERATION OF SUBMISSIONS
69. In the instant matter, the question of larger public importance is involved. It is a shocking and
surprising state of affairs that such large- scale cheating has taken place and middle and poor class
home buyers have been duped and deprived of their hard-earned money and lifetime savings and
some of them had taken a loan from the bank and they are not getting houses. Bank has made
payment to the builder, owners have the liability of making payment of amount with interest, home
buyers are still waiting for their dream houses to be completed. This is not only with respect to the
Amrapali builders that projects have not been completed as reflected in the affidavits of Noida and
Greater Noida Authorities. More than 70% of the projects have not been completed which were
initiated way-back in the year 2008-09 and were supposed to be completed within 3 years. By the
Amrapali Group, the buyers' money which has been obtained has not been invested in the
construction activities, rather it has been diverted to a great extent. Money obtained from the banks
has also not been invested in the projects and has been diverted elsewhere to acquire other assets.
70. There are huge liabilities of Noida and Greater Noida Authorities and though builders were
asked way back on 17.11.2017 to deposit 10% of the amount with the Noida and Greater NoidaBikram Chatterji vs Union Of India on 23 July, 2019

authorities, that order was repeated again on 18.1.2018 but still that has not been complied with.
Thereafter on the basis of joint note, this Court directed Amrapali group of companies to complete
the projects but the order was not complied with. Various wrong representations were made in this
Court. Developers backed out and an application was filed to waive the condition of deposit of
Rs.250 crores to start work by the Amrapali group that shows that its action was mala fide and it
never intended to complete various projects as rightly found by the forensic auditors and that their
intention was to divert the funds and this they had done at a large scale as is borne out from their
report.
71. The question involved in the case is whether the builders and promoters can be permitted to
usurp and divert the money of home buyers and home buyers can be left in the lurch as a silent
spectator. As per the Noida and Greater Noida authorities, in case the lease-deed is snapped, the
entire constructed buildings shall have to be demolished within 3 months. As per the bankers, they
have a charge on the property as the land has been mortgaged to them and until and unless their
amount is paid, the builder will have no right on the property which has been constructed by their
money, and the buyers have also to wait for the satisfaction of the dues.
72. In our opinion, if the real estate business has to survive in India, it has to be answerable to the
public and has necessarily to uphold the trust reposed in builders/promoters. They have been paid
huge amounts not only by the home buyers but also, they have to pay a huge amount for the public
land given to them on lease by Noida and Greater Noida Authorities for construction of houses. The
land has been given to them by the authorities on a concessional basis by making payment of 10%
amount at the time of allotment. The builders have to be accountable to public/home buyers as well
as the authorities and bankers. It is a matter relating to housing needs dealing with shelter place,
such an activity is of the public importance as the real estate sector plays a pivotal role in the
fulfilment of needs of housing infrastructure.
IN RE: PUBLIC TRUST DOCTRINE
73. The public trust doctrine imposes on the State and its functionaries a mandate to take
affirmative action for effective management, and the citizens are empowered to question its
ineffectiveness. The land of the farmers had been acquired for the purpose of housing and
infrastructure needs by the State Government and handed over to the concerned authorities for
construction. They are bound to ensure that builders act in accordance with the objective behind the
acquisition of land and the conditions on which allotment had been made. It was a duty of
concerned officials; they are not only enjoined to ensure that the rights of the home buyers are
protected but also the interests of the authorities; and bankers. The public authorities are
duty-bound to observe that the leased property is not frittered away along with the money of the
home buyers. Affirmative action was clearly enjoined upon them not only under the statutory
provisions of various enactments but also under the public trust doctrine that has evolved over the
years by this Court. In Noida Entrepreneurs Association v. Noida & Ors. (2011) 6 SCC 508, this
Court has observed:Bikram Chatterji vs Union Of India on 23 July, 2019

"38. The State or the public authority which holds the property for the public or
which has been assigned the duty of grant of largesse, etc. acts as a trustee and,
therefore, has to act fairly and reasonably. Every holder of a public office by virtue of
which he acts on behalf of the State or public body is ultimately accountable to the
people in whom the sovereignty vests. As such, all powers so vested in him are meant
to be exercised for public good and promoting the public interest. Every holder of a
public office is a trustee.
*** *** ***
40. The Public Trust Doctrine is a part of the law of the land. The doctrine has grown
from Article 21 of the Constitution. In essence, the action/order of the State or State
instrumentality would stand vitiated if it lacks bona fides, as it would only be a case
of colorable exercise of power. The Rule of Law is the foundation of a democratic
society. (Vide Erusian Equipment & Chemicals Ltd. v. State of W.B., AIR 1975 SC
266, Ramana Dayaram Shetty v. International Airport Authority of India, AIR 1979
SC 1628, Haji T.M. Hassan Rawther v. Kerala Financial Corpn., AIR 1988 SC 157,
Shrilekha Vidyarthi v. State of U.P., AIR 1991 SC 537; and M.I. Builders (P) Ltd. v.
Radhey Shyam Sahu, AIR 1999 SC 2468).
*** *** ***
41. Power vested by the State in a Public Authority should be viewed as a trust
coupled with duty to be exercised in larger public and social interest. Power is to be
exercised strictly adhering to the statutory provisions and fact-situation of a case.
"Public Authorities cannot play fast and loose with the powers vested in them". A
decision taken in an arbitrary manner contradicts the principle of legitimate
expectation. An Authority is under a legal obligation to exercise the power reasonably
and in good faith to effectuate the purpose for which power stood conferred. In this
context, "in good faith" means "for legitimate reasons". It must be exercised bona fide
for the purpose and for none other. (Vide Commr. of Police v. Gordhandas Bhanji,
AIR 1952 SC 16, Sirsi Municipality v. Ceceila Kom Francis Tellis, AIR 1973 SC 855,
State of Punjab v. Gurdial Singh, AIR 1980 SC 319, Collector (District Magistrate) v.
Raja Ram Jaiswal, AIR 1985 SC 1622, Delhi Admn. v. Manohar Lal, (2002) 7 SCC 222
and N.D. Jayal v. Union of India, AIR 2004 SC 867)."
74. In Natural Resources Allocation, In re, Special Reference No.1 of 2012, (2012) 10 SCC 1, the
Court observed:
“172. The judgment in LDA v. M.K. Gupta, (1994) 1 SCC 243, brings out the
foundational principle of executive governance. The said foundational principle is
based on the realization that sovereignty vests in the people. The judgment,
therefore, records that every limb of the constitutional machinery is obliged to be
people oriented. The fundamental principle brought out by the judgment is, that aBikram Chatterji vs Union Of India on 23 July, 2019

public authority exercising public power discharges a public duty, and therefore, has
to sub-serve general welfare and common good. All power should be exercised for the
sake of society. The issue which was the subject matter of consideration, and has been
noticed along with the citation, was decided by concluding that compensation shall
be payable by the State (or its instrumentality) where inappropriate deprivation on
account of improper exercise of discretion has resulted in a loss, compensation is
payable by the State (or its instrumentality). But where the public functionary
exercises his discretion capriciously, or for considerations which are malafide, the
public functionary himself must shoulder the burden of compensation held as
payable. The reason for shifting the onus to the public functionary deserves notice.
This Court felt, that when a court directs payment of damages or compensation
against the State, the ultimate sufferer is the common man because it is tax-payers
money out of which damages and costs are paid."
75. In Association of Unified Tele Services Providers & Ors. v. Union of India & Ors. (2014) 6 SCC
110, the Court observed:
"4. We have indicated, the worth of spectrum to impress upon the fact that the State
actions and actions of its agencies/ instrumentalities/ licensees must be for the public
good to achieve the object for which it exists, the object being to serve public good by
resorting to fair and reasonable methods. State is also bound to protect the resources
for the enjoyment of general public rather than permit their use for purely
commercial purposes. Public trust doctrine, it is well established, puts an implicit
embargo on the right of the State to transfer public properties to private party if such
transfer affects public interest. Further, it mandates affirmative State action for
effective management of natural resources and empowers the citizens to question
ineffective management."
76. In the instant case, it is apparent that there are colossal dues of Noida and Greater Noida
Authorities. The dues of Noida Authorities as on 30.4.2019 are Rs.2191.38 crores and dues of
Greater Noida authority are stated to be Rs.3234.71 crores as on 15.1.2019. Thus, the total dues of
Noida and Greater Noida authorities are more than Rs.5426.09 crores; by now more than Rs.5500
crores. Payments were made to Noida authorities in 2010 and some amount in 2013; in-between or
thereafter, except one or two payments no other amount has been paid. There were several defaults
in making the payment of the premium amount, lease money, even the money payable to the
farmers as compensation for land acquisition has not been paid by the builders, as is apparent from
the account statement filed on behalf of the Noida authority. Though the builder has realised from
home buyers the amount payable to authorities of Noida and Greater Noida as a component of the
price payable by them.
77. Once the Noida and Greater Noida Authorities knew very well that there were defaults, they
could not have allotted further land to the Amrapali group without insisting for payment of its dues.
Secondly, it was not open to the authorities to permit the sub-leases of plot of land executed by
builders, thereby allowing the leaseholder to earn a huge amount without making payment of theBikram Chatterji vs Union Of India on 23 July, 2019

amount due to them. The officials of the authorities have acted in clear breach of public trust. They
have permitted the defaulting leaseholders to earn the amount by sub-leasing its land of which dues
had not been cleared. Thus, apparently, the officials of the authorities acted clearly in collusion with
the builders and overlooked the interest of the Authorities and home buyers while permitting the
sub-leases of plot of land to be granted. It passes comprehension how the officials of the authorities
could have permitted such sub-leases in the factual scenario of the case when even the basic
obligation to raise the construction was not being fulfilled by the builders and they were not paying
the dues of premium, lease money etc. The action of the officials of the authorities has the effect of
causing unjust enrichment of builder from the land held by the concerned authorities. It was wholly
an illegal exercise permitted.
78. We are of the considered opinion that the officials of the Noida and Greater Noida authorities
have acted clearly in a breach of public trust and apart from that, they have failed to act as per the
statutory mandate, the regulations and the terms of the lease deed. The transfer of the plot by the
lessee was only on fulfilment of certain conditions. The dues of lessor towards the cost of land were
to be cleared in accordance with the schedule of payment. Following provision is contained in lease
deed dated 3.8.2010 entered into between Greater Noida Industrial Development Authority and
M/s. Amrapali Leisure Valley Developers Pvt. Ltd. The relevant provision with respect to the
transfer of the plot is extracted hereunder:
“TRANSFER OF PLOT . Without obtaining the completion certificate the Lessee shall
have the right to sub-divide the allotted plot into suitable smaller plots as per
planning norms and to transfer the same to the interested parties up to 30.0.2010, or
as decided by the Lessor, with the prior approval of LESSOR on payment of transfer
charges @ 2% of allotment rate. However, the area of each of such sub-divided plots
should not be less than 20,000 sq. mtrs. However, the individual flat/plot will be
transferable with prior approval of the LESSOR as per the following conditions:-
(i) The dues of LESSOR towards the cost of the land shall be paid in accordance with
the payment schedule specified in the Lease Deed before executing of sub-lease deed
of the flat.
(ii) The lease deed has been executed.
(iii) Transfer of flat will be allowed only after obtaining completion certificate for the
respective phase by the Lessee.
(iv) The sub-Lessee undertakes to put to use the premises for the residential use only.
(v) The Lessee has obtained building occupancy certificate from the Building
Cell/Planning Department, GREATER NOIDA.
(vi) First sale/transfer of a flat/plot to an allottee shall be through a Sub-lease/Lease
Deed to be executed on the request of the Lessee to the LESSOR in writing.Bikram Chatterji vs Union Of India on 23 July, 2019

(vii) No transfer charges will be payable in case of the first sale, including the built-up
premises on the sub-divided plot(s) as described above. However, on a subsequent
sale, transfer charges shall be applicable on the prevailing rates as fixed by the
LESSOR.
(viii) Rs. 1000/- shall be paid as processing fee in each case of transfer of flat in
addition to transfer charges.” (emphasis supplied)
79. In the lease deed, the schedule of payment was fixed. Two years was the period of the
moratorium and thereafter payment was to be made on expiry of 23.10.2012, onwards up to
23.4.2020. In case of default in depositing the amount, the interest @ 15% compounded half yearly
shall be leviable. With respect to the extension of time, it is provided that in exceptional
circumstances, time to deposit for payment of balance due amount may be extended by the CEO for
15% interest compounded half yearly. The extension of time, in any case, cannot be allowed for more
than 60 days for each instalment to be deposited, subject to a maximum of 3 such extensions during
the entire payment schedule. The provision relating to the extension of time is extracted hereunder:
“A. EXTENSION OF TIME
1. In exceptional circumstances, the time of deposit for the payment of balance due
amount may be extended by the Chief Executive Officer of the Lessor.
2. However, in such cases of time extension, interest @ 15% per annum compounded
half yearly shall be charged on the outstanding amount for such extended period.
3. Extension of time, in any case, shall not be allowed for more than 60 days for each
instalment to be deposited, subject to maximum of three (3) such extensions during
the entire payment schedule.
4. For the purpose of arriving at the due date, the date of issuance of allotment letter
will be reckoned as the date of allotment.”
80. The lease was granted for a term of 90 years. It is specifically provided in lease
deed condition No.(ii)(c) that the lessee shall use the allotted plot for construction of
group housing/flats/plots. Condition No.(ii)(c)(iii) deals with the part transfer of the
plot. It lays down normally the permission for part-transfer of the plot shall not be
granted under any circumstances. The lessee shall not be entitled to complete the
transaction for sale, transfer, assign or otherwise part with possession of the whole or
any part of the building constructed thereon before making payment according to the
schedule specified in the lease deed of the plot to the lessor. Relevant condition
No.2(c)(iii) is extracted hereunder:
"(c) The Lessee shall use the allotted plot for construction of Group
Housing/flats/plots. However, the Lessee shall be entitled to allot the dwelling unitsBikram Chatterji vs Union Of India on 23 July, 2019

on a sub-lease basis to its allottee and also provide space for facilities like Roads,
Parks, etc. as per their requirements, convenience with the allotted plot, fulfilling
requirements or building bye-laws and prevailing and under mentioned terms and
conditions to the Lessor. Further transfer/sublease shall be governed by the transfer
policy of the Lessor.
i) Such allottee/sub Lessee should be a citizen of India and competent to contract.
ii) Husband/wife and their dependent children will not be separately eligible for the
purpose of allotment and shall be treated as single entity.
iii) Normally, the permission for the part transfer of plot shall not be granted under
any circumstances. The Lessee shall not be entitled to complete transaction for sale,
transfer, assign or otherwise part with possession of the whole or any part of the
building constructed thereon before making payment according to the schedule
specified in the lease deed of the plot to the Lessor.
However, after making payment of premium of the plot to the Lessor as per schedule specified in the
lease deed, permission for transfer of built-up flats or to part with possession of the whole or any
part of the building constructed on the Group Housing Plot, shall be granted and subject to payment
of transfer charges as per policy prevailing at the time of granting such permission of transfer.
However, the Lessor reserves the right to reject any transfer application without assigning any
reason. The Lessee will also be required to pay transfer charges as per the policy prevailing at the
time of such permission of transfer. The permission to transfer the part of the built-up space will be
granted subject to execution of tripartite sub-lease deed which shall be executed in a form and
format as prescribed by the lessor. On the fulfilment of the following conditions: -
a) The lease deed of the plot has been executed and the Lessee has made the payment
according to the schedule specified in the lease deed of the plot, interest and one-time
lease rent. Permission of sub-
lease deed shall be granted phase wise on payment of full premium (with interest up to the date of
deposit) of the plot of that phase.
b) Every sale done by the Lessee shall have to be registered before the physical possession of the
property is handed over.
c) The Lessee has obtained building occupancy certificate from the Planning Department, Greater
Noida.
d) The Lessee shall submit list of individual allottees of flats within 6 months from the date of
obtaining occupancy certificate.Bikram Chatterji vs Union Of India on 23 July, 2019

e) The Lessee shall have to execute sublease in favour of the individual allottees for the developed
flats/plots in the form and format as prescribed by the LESSOR.
f) The Sub-Lessee undertakes to put to use the premises for the residential use only.” (emphasis
supplied)
81. In view of the aforesaid clause, by way of sub-lease of the plot, the transfer of plots could not
have been made by the lessee. The lessee was required to start construction within 12 months from
the date of possession. The date of execution of lease deed shall be treated as the date of possession.
The lessee shall be required to complete the construction of minimum 15% of the total FAR of the
allotted plot as per the approved layout plan and get occupancy/completion certificate within 3
years from the date of execution of the lease deed. Cancellation of lease deed is also provided in the
case of violation of directions, or rules, regulations or in case of the default on the part of the lessee
for breach or violation of terms and conditions of the registration/allotment/lease and/or
non-deposit of allotment amount. In the case of cancellation, if the plot is occupied by the lessee, an
amount equivalent to 25% of the total premium of the plot shall be forfeited and possession of the
plot will be resumed by the lessor with structure thereon, if any, and the lessee will have no right to
claim compensation thereof. The provision relating in lease deed as to its cancellation is extracted
hereunder:
“CANCELLATION OF LEASE DEED In addition to the other specific clauses relating
to cancellation, the Lessor, as the case may be, will be free to exercise its right of
cancellation of the lease in the case of:-
1. Allotment being obtained through misrepresentation/suppression of material facts,
misstatement and/or fraud.
2. Any violation of directions issued or rules and regulation framed by Lessor or by
any other statutory body.
3. Default on the part of the Lessee for breach/violation of terms and conditions of
registration/allotment/lease and/or non-deposit of allotment amount.
4. If at the same time of cancellation, the plot is occupied by the Lessee thereon, the
amount equivalent to 25% of the total premium of the plot shall be forfeited and
possession of the plot will be resumed by the Lessor with structure thereon, if any,
and the Lessee will have no right to claim compensation thereof. The balance, if any,
shall be refunded without any interest. The forfeited amount shall not exceed the
deposited amount with the Lessor and no separate notice shall be given in this
regard.
5. If the allotment is cancelled on the ground mention in sub-clause 1 above, then the
entire amount deposited by the lessee till the date of cancellation shall be forfeited by
the Lessor and no claim whatsoever shall be entertained in this regard.”Bikram Chatterji vs Union Of India on 23 July, 2019

82. As provided by clause 6, the lease deed/allotment shall be governed by the provisions of the U.P.
Industrial Area Development Act, 1976 and by the rules and/or regulations made or directions
issued under the Act. Clause 7 requires the lessor to monitor the implementation of the project. The
applicants who do not have a firm commitment to implement the project within the time limits
prescribed are advised not to avail the allotment. In larger public interest the lessor under clause 13
is also given a right to take back possession of the land/building by making payment at the
prevailing rate. Condition Nos.6, 7 and 13 are extracted hereunder:
“6. The Lease Deed/allotment will be governed by the provisions of the U.P.
Industrial Area Development Act, 1976 (U.P. Act No.6 of 1976) and by the rules
and/or regulations made or directions issues, under this Act.
7. The Lessor will monitor the implementation of the project.
Applicants who do not have a firm commitment to implement the project within the time limits
prescribed are advised not to avail the allotment.
13. The Lessor in larger public interest may take back the possession of the land/building by making
payment at the prevailing rate.” (emphasis supplied) Thus, it is apparent that the officials of the
concerned authorities have not discharged their duty in accordance with the trust enjoined upon
them under aforesaid terms and conditions of lease deed, thus, by their inaction, enabled cheating of
the home buyers at a large scale. They were well aware of what was happening on the spot.
IN RE: MORTGAGE
83. With respect to the creation of mortgage deed in favour of bankers etc., Noida Authority has
submitted that every mortgage permission is granted by the Noida Authority to the individual
company of Amrapali group wherein a provision is made that Noida Authority has first
charge/priority over all other charges including those created in favour of banks and financial
institutions. The conditions on which permission to mortgage had been granted are as under:
“This is to inform you that Noida shall have no objection for the purpose of financing
his investment in the project on Group Housing Plot No.001, Sector 119, Noida in
favour of Nationalised Banks/Financial Institutions/HUDCO, New Delhi or to issue
NOC to mortgage the said land to facilitate the housing loans of the final loans of the
final purchasers subject to such terms and conditions as may be decided by the
Authority at the time of granting the permission. This permission is being granted
subject to the condition that in the mortgage deed, following clauses will be
included:-
(i) That the financial institution in whose favour mortgage permission is required
should be recognised by the Reserve Bank of India/National Housing Bank/HUDCO
New Delhi. Noida shall have the first charge towards the pending payment in respect
of plot/flat allotted/lease rent/taxes or any other charges as informed or levied by theBikram Chatterji vs Union Of India on 23 July, 2019

Authority on the plot and the banks/financial institutions/HUDCO New Delhi, shall
have the second charge on the dwelling units thus being financed.
(ii) The mortgage permission shall be effective on making full payment of premium
and up to date annual lease rent of group housing plot and after execution of
sub-lease deed in favour of allottee of the dwelling unit and the allottee/sub-lessee
shall be governed by the terms and conditions of allotment/lease deed of the plot to
be executed and sub-lease deed to be executed in favour of the allottee sub-lessee. In
the event of sale/transfer of flat, transfer charges at the rate prevailing at the time of
transfer shall be payable to Noida.
(iii) Each allottee/sub-lessee of the dwelling units shall have to intimate Noida of the
creation of the mortgage in favour of bank/financial institutions/employer and the
bank/financial institution/employee of the allottee shall also keep Noida informed
about the dwelling units thus financed.
(iv) It is further to inform you that in the case of cancellation of lease, Noida
Authority will give 30 days’ notice to nationalised Banks/financial
institutions/HUDCO, New Delhi prior to exercising its right of re-entry on the
premises.” (emphasis supplied)
84. The permissions to mortgage containing aforesaid clauses have been placed on record along
with affidavit dated 22.11.2018. It is apparent from the second condition, subject to which
permission to mortgage shall be effective on making full payment of the premium and up to date
annual lease rent of group housing plot and after execution of the sub-lease deed in favour of the
allottee of the dwelling unit, the allottee/sub-lessee shall be governed by the terms and conditions of
allotment/lease deed of the plot to be executed and sub-lease deed to be executed in favour of the
allottee/sub-lessee. Since at no point of time, payment of premium due had been made and up to
date annual lease rent had not been paid, no mortgage could have been created in favour of the bank
in view of specific condition No.2 extracted above. Thus, when the conditional permission granted
by the authority was furnished to the bank for obtaining the loan by promoters/builders, it was
incumbent upon Bank officials to ascertain from the concerned authorities that the premium due
under the leases has been paid and lease rent due up to date has also been paid. In order to create a
mortgage, it was necessary to obtain clear NOC in order to create effective mortgage deed. As that
has not been done so far, no mortgage in the eye of law has been created in favour of the bank. It
was not open to the bankers to mortgage the land in view of the conditional permission to create
mortgage, the mortgage created in violation of condition cannot be said to be effective in accordance
with law as the land was owned by the concerned authorities and the lessees had right to mortgage
only subject to fulfilment of conditions imposed by the lessor/authorities.
85. On behalf of Noida and Greater Noida authorities, it was pointed out that they had taken steps
reminding the lessees to pay dues by issuing notices w.e.f. 2007 to 2017. In our opinion, in spite of
no payment made by lessees, failure to take action, makes their position further worse. As no
effective action had been taken and officials have permitted wilfully contumacious violations ofBikram Chatterji vs Union Of India on 23 July, 2019

conditions of the lease. Right under their nose and to their knowledge serious kind of fraud had
been taking place and officials have clearly connived with builders. In spite of construction activity
lying stand still for years together dues not being paid. As a matter of fact, issuance of conditional
NOC was with ulterior motive, there was no reason to issue such a conditional permission, subject to
which mortgage could have been made. They could not have issued any conditional permission for
creation of a mortgage also without payment of amount due, permission has been issued obviously
for being misused, in collusion with the officials of the bank and Authorities. It was incumbent upon
the concerned authorities not to issue such an NOC for a mortgage and it was incumbent upon the
bank officials in order to create a valid mortgage to ascertain from the Noida and Greater Noida
Authorities that the condition imposed by them as condition precedent to create a mortgage had
been fulfilled and to obtain clear NOC. But that is how in illegal manner the public money is
obtained from banks for the purpose of construction activity and then it was not used for that
purpose, as found in the forensic audit report in which it is rightly pointed out that there was a
diversion of money. The amount of loan advanced by banks was not used for the purpose it had been
obtained for a particular project and it was diverted to other companies. It was happening not only
under the nose of Noida and Greater Noida authorities, but was directly in the knowledge and
connivance of the bankers as day-to-day transactions in the bank accounts were pointing out that
the money was being siphoned and diverted for other purposes routinely, not being utilised for the
purpose it was given. Thus, all of them have helped in perpetuating the fraud on the home buyers by
Amrapali group of companies, its various Directors, officials and others who have been specified in
minute details in the forensic audit reports. The case also indicates that not only the banks have
failed to ensure that mortgage was effected in accordance with the law, but also they have failed to
check whether money was in fact, required for the projects and was used for purpose it was lent. By
the collusion, the money paid by home buyers to builders which included money payable to the
Authorities could be diverted, had the deposit made by home buyers been unutilised, money due
under lease would have been paid to authorities before the creation of the mortgage. Money
borrowed from bank, in fact, was not required for completion of these projects as the money paid by
the buyers was enough for that purpose, but that was also diverted and the money obtained from the
banks was also not utilised for the purpose it was taken and it was well within the knowledge of the
bankers and Authorities that the funds were being diverted, but they remained mute spectators.
DIVERSION OF FUNDS
86. It has been observed in extensive detail in the forensic audit report that the Bank of Baroda,
Syndicate Bank, Bank of India, Corporation Bank did not monitor utilisation of funds and acted as a
mute spectator to diversion which was almost happening evidently in all banking transactions. In
the case of Amrapali Zodiac Developers, Bank of Baroda has advanced an amount which was
diverted immediately on receipt. The details have been given in the forensic auditors' report
extracted above. There was no amount due as on the date of the transfer. In the case of Amrapali
Princely Estate Pvt. Ltd., the details have been given with respect to the Syndicate Bank and Bank of
India as to how immediately on receipt, the funds were diverted to several parties. In the case of
Amrapali Eden Park Developers Pvt. Ltd., there was a receipt from the Corporation Bank, and
similar is the position. Immediately the funds were diverted to the third parties as detailed in the
forensic report. Details of diversion of loan funds have been given in a tabular form in Section XII
from pages 426 to 457 of the report. The submissions which have been raised on behalf of Bank ofBikram Chatterji vs Union Of India on 23 July, 2019

Baroda that due observance of norms was observed before sanctioning the loan, before disbursal
and an independent Lenders' Engineer had been appointed in order to monitor the contract.
Monitoring was done during and post disbursal of loan by Bank of Baroda. As a matter of fact, the
bank has not been able to show what steps it has taken to stop the diversion of funds to third parties
on the same date of disbursal of the amount. The aforesaid stand of the Bank is falsified by the
Forensic Auditors’ report.
87. The transactions of Amrapali Zodiac Developers Pvt. Ltd. with J.P. Morgan were clearly in order
to avoid the provisions of the Companies Act. It is apparent that Mr. Anil Mittal, Statutory Auditor,
did not report his interest and disclosed about his relatives and junior employee as Director and
shareholders. Mr. Chandan Kumar was a junior employee and Mr. Atul Mittal was his relative. Thus,
it is apparent that Rudraksha Infracity Pvt. Ltd. was created for money laundering as aforesaid two
Directors and shareholders had no income, Rudraksha Infracity Pvt. Ltd. was incorporated to
receive funds from Mannat Buildcraft which was also created by Mr. Chander Wadhwa, CFO
through his close associates. After receiving money from Mannat Buildcraft Pvt. Ltd., the same was
transferred to J.P. Morgan Investments for purchasing equity shares of Amrapali Zodiac Pvt. Ltd. at
an exorbitant price. There was no transaction before or after these transfers of monies in the
aforesaid dummy companies. To suit the requirement of J.P. Morgan Investments, in entirety
incorrect valuation report was prepared by M/s. Sudit K. Parikh & Co., Chartered Accountants. The
methodology and procedures defined of computation of fair market value were not followed at the
time of exit. J.P. Morgan was having full control on Amrapali Zodiac Developers and no action could
have taken as per clause 10.4.3 without investors' approval. The profit cannot be recognised until
the project is completed. Thus, there cannot be any distributable amount as profit for distribution to
J.P. Morgan. It has also been found by the Forensic Auditors that J.P. Morgan was in the knowledge
of the fact that Amrapali Zodiac Developers had paid the money received to other companies of
Amrapali group. Advances exceeded the limits specified in the shareholders’ agreement, but J.P.
Morgan did not ensure bringing back the money. It was accepted by Mr. Suraj Chhabria that it was
in his knowledge and that of J.P. Morgan that the money has been diverted from shareholder’s
agreement and share subscription agreement. The valuation of the shares did not follow the correct
methodology of discounted cash flow as detailed out by the forensic auditors. The valuation exercise
was done backwardly in order to inflate the value of share to siphon out the money of home buyers
through J.P. Morgan.
88. The FEMA rules prohibited the kind of transactions which were entered into with J.P. Morgan.
Rule 4 of FEMA has been clearly violated. Master Circular No.8/2010-2011 of July 1, 2010, dealing
with external commercial borrowings and trade credits clearly provides that external commercial
borrowings are not permitted to be utilised for real estate business under the automatic route. The
term real estate excludes the development of the integrated township. It was not a case of
development of the integrated township. Even if it is taken to be a case of integrated township as
submitted on behalf of J.P. Morgan, then also for approval route, hedging is required as pointed out
by the Forensic Auditors in their report and borrowers had to submit their report about the signing
of loan agreement with the lender for obtaining Loan Registration Number. In case J.P. Morgan had
invested in the form of ECB, following would have been the requirements: (i) obtaining Loan
Registration Number from the RBI; (ii) file ECB-2 returns every month to the RBI, (iii) to pay tax onBikram Chatterji vs Union Of India on 23 July, 2019

interest payment to J.P. Morgan; and (iv) to file income tax return. We are in agreement with the
findings of the forensic auditors in this regard. It is clear that it was a methodology adopted by the
group to siphon out the funds of the home buyers in violation of the FEMA rules and the
notifications and by the creation of dubious companies for which appropriate action is warranted by
the concerned authorities.
89. The report of Forensic Audit also indicates that the Company has received a sum of Rs.140
crores during the financial year 2012-13 from IPFFI Singapore PTE Limited under Foreign Direct
Investment Scheme. As per FEMA Rules, this amount was to be invested in real estate construction
projects only.
90. The IPFFI Singapore PTE Limited which was incorporated on 20.5.2011, entered into a Share
Subscription Agreement with ASCPL on 23.8.2012 and paid a sum of Rs.140 crores to ASCPL in the
following manner on 7.8.2012:
(a) INR 85 crores received in Axis Bank, Indirapuram Branch on 7.8.2012.
(b) INR 55 crores received in BOB Escrow Account on 7.8.2012. Thus, a total sum of Rs.140 crores
was received in Axis Bank. The amount was received in Axis Bank of INR 85 crores was transferred
to Amrapali Centurian Park Pvt. Ltd. in three proportion. On 7.8.2012, Rs.5 crores were transferred.
On 8.8.2012, an amount of Rs.50 crores was transferred and on 18.8.2012, Rs.30 crores were
transferred. The ACPPL on receiving Rs.85 crores allotted equity shares worth INR 85 lakhs to
ASCPL and balance INR 84.15 crores were treated as share premium account. There is no valuation
report available as to how the share premium of INR 84.15 crores had been calculated. This transfer
of fund by ASCPL to ACPPL is termed as absolutely violative of FDI Rules and agreement. With
respect to Rs.55 crores routed from IPFFI Singapore in the Escrow Account of Bank of Baroda,
Escrow Account was transferred from 8.8.2012 to 28.9.2012 in the account of Bank of Baroda and
used for payment of term loan instalments of OBC and Bank of Maharashtra for repayment of their
term loan instalment. This money was not meant for payment of term loan instalment as per FDI
Rules. It was to be used in the construction.
91. The ASCPL did not use the money for the project which was received from IPFII Singapore but
transferred Rs.85 crores to ACPPL and Rs.55 crores to repay bank loan instalments and repay the
outstanding creditors provided for in the books and standing in the books. The said payments have
rightly been held by Auditors to be in contravention of the FDI norms and rules and for which the
money was brought in India.
92. From 2013 to 2015, ASCPL has paid interest of Rs.58.81 crores @ 17 percent, which is a highly
abnormal rate. A sum of Rs.14.41 crores was paid on 31.3.2013. Likewise, on 31.3.2014, Rs.22.20
crores were paid and on 31.3.2015, another amount of Rs.22.20 crores was paid. The violations were
made with the knowledge of the IPFII Singapore and they were in connivance with the ASCPL.
93. The stand of the Bank of Baroda that they have independently appointed Lender’s Engineer is of
no avail. There was negligence on the part of Bank of Baroda and merely proceeding before theBikram Chatterji vs Union Of India on 23 July, 2019

Court in 2017 to recover the amount is not going to serve the purpose. More so, in view of the
finding of the Forensic Audit that there was no necessity of obtaining the loan from the Bankers as
Amrapali Group had sufficient money from the home buyers, which has also been diverted and has
not been utilised in the construction activities. Other assets have been created with the help of the
same and the borrowings have been used in order to siphon off the money by making payment of
some unusual amount not only to J.P. Morgan, but also to IPFII Singapore in violation of the FEMA
Rules and FDI Rules as found by the Auditors in the respective cases.
94. It was submitted that the Bank of Baroda has obtained the deed of corporate guarantee inter alia
from Ultra Homes Construction Ltd, Rinku Clothing Creations Pvt. Ltd., Jotindra Steels and Tube
Limited and Vidyashree Buildcon Pvt. Ltd. RoC search report and CA certificate had also been
obtained. Lender's Legal Counsel Report dated 2.3.2012 verifying the validity and enforceability of
financing documents and creation of securing on assets of ASCPL is also on record. Jotindra Steels
and Tubes Limited issued a corporate guarantee, it was absolutely improper for the Bank of Baroda
to discharge the bank guarantee without payment of amount in view of the fact that Jotindra Steels
and Tubes Limited was not ready to subscribe to the capital was no ground for Bank of Baroda to
discharge Jotindra Steels and Tubes Limited. Once guarantee has been given and in view of the
finding recorded by the Forensic Auditors as to the nature of bid by the Jotindra Steels and Tubes
Limited and other persons, it is apparent that action was illegal.
95. The leases had been granted by Noida and Greater Noida Authorities subject to the provisions
contained in U.P. Industrial Area Development Act, 1976. Section 13 of the U.P. Industrial Area
Development Act, 1976 deals with imposition of penalty and mode of recovery of arrears, which
states that where any transferee makes any default in the payment of any consideration money or
instalment thereof or any other amount due on account of the transfer of any site or building by the
Authority or any rent due to the Authority in respect of any lease or where any transferee or occupier
makes any default in payment of any amount of fee or tax levied under the Act, in addition to the
amount of arrears, a further sum not exceeding that amount shall be recovered from the transferee
or occupier by way of penalty. Under Section 13-A, any amount payable to the Authority under
Section 13 shall constitute a charge over the property and may be recovered as arrears of land
revenue or by attachment and sale of property in the manner provided under the provisions of Uttar
Pradesh Municipal Corporations Act, 1959 (Act no.2 of 1959). Section 14 provides for the
resumption of any site or building and forfeiture of whole or any part of the money if any paid in
respect thereof.
“14. (1) In the case of non-payment of consideration money or any instalment thereof on account of
the transfer by the Authority or any site or building or in case of any breach of any condition of such
transfer or breach of any rules or regulations made under this Act, the Chief Executive Officer may
resume the site or building so transferred and may further forfeit the whole or any part of the money
if any paid in respect thereof.
(2) Where the Chief Executive Officer order resumption of any site or building under sub-section (1)
the Collector may, on his requisition, cause possession thereof to be delivered to him and may for
that purpose use or cause to be used such force as may be necessary.”Bikram Chatterji vs Union Of India on 23 July, 2019

96. The Authorities have failed to take action under the aforesaid provisions. The Authorities have
also failed to perform the statutory duty cast upon them to take prompt action. Merely filing of the
case against Unitech Builders by way of petition in this Court did not furnish any grounds to the
Authorities to remain silent spectator on the perpetration of fraud committed on the home buyers
by Amrapali Group of Companies. Public trust doctrine requires an affirmative action, which was
envisaged not only statutorily but under the Scheme also. They were required to ensure that projects
were completed within the stipulated period, otherwise, the very purpose of the grant would stand
frustrated and colossal loss of public money. Amrapali Group did not pay even the amount due to be
paid to the landowners on the part of land acquisition, it did not pay premium annual lease amount
interest to Authorities. They have violated every condition, but still, Authorities were bent upon to
condone everything. This reflects absolute dereliction of duty cast upon the Authorities.
97. The Noida and Greater Noida Authorities and the Bankers have permitted diversion of funds of
home-buyers and the possession of other assets by Amrapali Group. The buyers' money had been
diverted, which was meant for construction on payment of dues of Authorities in case they were paid
timely by the Amrapali Group to the Authorities and to the Banks substantively liability would have
been cleared. But by their inaction and rather conniving, the buyers were cheated by the Amrapali
Group. Authorities did not object when mortgages were effected in favour of Banks in violation of
conditions. Bankers could not have violated conditions. Now, whatever complete/incomplete
structures are there, the Authorities are claiming that buyers have no right and they have the first
charge on the structure as they have to recover the amount, only thereafter if anything is left out,
can be paid to the buyers. In case the submission is accepted, it would amount to playing further
fraud upon the fraud. It was incumbent upon the Authorities as well as the Banks to prevent the
fraud. Now, if Banks, as well as the Authorities, are permitted to recover the amount from the
home-buyers' investment, in that case, it would be equally unjust and would be against the
conscience of the law and nothing would be left for buyers not even a brick and the structures have
come up by investing their money. Law never permits unjust gain based upon fraud. The principle
“fraud vitiates” is clearly attracted and such a transaction would become unenforceable and would
be against the public trust doctrine. Real estate business can never prosper in case of breach of trust,
bankers, Authorities in connivance and the builders are permitted to take away the innocent
home-buyers' money without being accountable to their action/inaction. From tomorrow huge
money will be collected from home buyers by the builder, banks would act in connivance and the
Authorities sleep in slumber, permitting diversion of money of buyers/bankers, etc., and the
home-buyers will be paying the dues of all concerned without investment of a penny by builder and
rather they are diverting the money of the home-buyers in connivance with Authorities and Bankers
and they are left without dream homes. If that is a factual scenario, no Court can permit such fraud
to be perpetrated. Since “fraud vitiates”, the bounden duty of the Court is to act as parens patria not
only to save the home-buyers but also to ensure that they are not cheated.
98. Authorities and Bankers have not acted in furtherance of public interest and failed to perform
duties enjoined upon them. The kind of fraud that has taken place not only in Amrapali Group of
Companies but at large as more than 70 percent of the various projects have not come up, is
alarming to the Courts to take affirmative steps with the direction to prevent such frauds, restore the
money of home-buyers and to punish incumbents responsible for such act. At the same time toBikram Chatterji vs Union Of India on 23 July, 2019

ensure that buildings are completed. It cannot be denied that lifetime savings of home- buyers have
been invested for purchase of a house with the faith and trust they have given the money. The
scheme of the Government is to promote the real estate for which land had been acquired, even poor
farmers have not been paid the compensation. The land allotted at throw away prices of 10%, the
allotment premium has not been paid and in an illegal manner plots have been allotted on huge
amount by builders is another fraud in collusion with Authorities.
99. How buyers get their houses and can be suitably compensated for the delay that has taken place
in the matter and they are left at the juncture where the builder has diverted the funds for the last
several years and no construction activities have taken place. For several years, no accounts were
maintained from 2015 till date and a lot of money had been withdrawn from the Banks. The orders
passed by this Court on 22.11.2017 to deposit 10 percent of the amount was not complied with by the
Amrapali Group. Thereafter again on 17.5.2018, this Court permitted them to carry forward the
project, but they did not do so and were not ready to deposit the amount of Rs.250 crores to show
their bona fide to undertake construction activity and efforts had been made to wriggle out of
assurances on which basis this Court had passed the orders.
100. On behalf of Authorities provisions contained in Section 13 of the Uttar Pradesh Apartment
(Promotion of Construction, Ownership, and Maintenance) Act, 2010 has been pressed into service.
It is submitted that transfer cannot be made in favour of home-buyer without executing the Transfer
Deed. As per Section 5 of Act of 2010, flat buyers become entitled to ownership and possession of
the Apartment and undivided interest in the common areas as specified in the deed of the
Apartment. It is further submitted that tripartite sub-lease deed has to be entered into in order to
transfer ownership to the home-buyers, consisting of Authorities, builders and home-buyers and
before that is done, it is necessary for builder to obtain the completion certificate on fulfilment of
certain conditions. The main objection raised by the counsel is with respect to the issuance of
completion certificate is default of the payment of amount with interest to be made under lease and
relating to fire safety. It is also pointed out that completion certificate is necessary to be issued, the
issuance of the same would depend upon payment of the dues and the Authorities, later on, will
have no mechanism to recover the dues, once registered conveyance deed is executed in favour of
home-buyers. According to Authorities, the buyers may contend that they have paid the entire
consideration to the builder, who has defaulted in making the payment for the flat and the privity of
making the payment is between the concerned Authorities and the builder. It is also submitted on
behalf of Authorities that in part completion also, the certificate can be issued against the part
payment received, however, the completion certificate would be issued in the same proportion
minus 10 percent so that financial interest of the Authorities is protected. Sub-lease deed would be
executed as per the present policy up to 90 percent of the proportion in which part payment has
been received.
101. In our opinion, in the ordinary course, there cannot be any dispute with respect to the aforesaid
propositions. However, in the instant case, the facts indicate that 9000 families are residing for the
last several years out of the sheer necessity of shelter place and they have not been provided with
electricity connections and other facilities due to non-issuance of occupancy certificate by the
concerned authorities. Most of them have paid the entire amount to the builders. The amountBikram Chatterji vs Union Of India on 23 July, 2019

outstanding as against home buyers have to be used in completion of building. The payment to be
made to concerned Authorities had also been collected by the builder from home buyers as
component of price of flat, but has not been deposited with the concerned Authorities and the home
buyers’ money had been diverted, which was more than the dues of the Authorities and the Banks
taken together. Had timely action been taken by them no amount could have been diverted and the
position would have been different as it stands today. However, since we have attached various
other properties where home buyers’ money has been invested, the rights of the Authorities as well
as bankers to get the money recovered from the other properties of the builder Amrapali
Group/Directors and where they have invested money and belonging to the guarantors in the
various transactions. However, at the same time for want of payment to Authorities and Bankers by
the builder under these facts and circumstances, it would be absolutely improper for the Authorities
to deny issuance of occupancy or completion certificate, especially on the ground of non-payment of
dues. As per the interim orders, we have ensured that fire safety devices are fitted in buildings at
appropriate places wherever necessary and in case it is lacking at any place we have to ensure that
they are fitted and there are no other violations pointed out in the construction so far made. Thus,
the concerned Authorities have to issue occupancy certificate as well as completion certificate with
respect to the projects in which home buyers residing without insisting for the payment of their
dues. This Court has to monitor the payment of the dues to the Authorities as well as the Bankers,
from guarantors and other proprietors. The innocent buyers cannot be made to suffer for no fault on
their part.
102. Once Authorities have allowed 9000 home-buyers to occupy the premises without terminating
the lease on the ground that occupation is illegal. Obviously, builders have put them in possession,
they are not the encroachers and they have invested their valuable saving and have no other shelter
place to live. They cannot be deprived of their houses and cannot be left without basic necessities of
life like water, electricity, etc. The concerned Authorities are responsible to provide electricity,
water, and all other basic amenities to buyers as they have the right to occupy the premises. In the
peculiar facts of the case, we have directed the Authorities to provide basic necessities forthwith. We
also direct the Central Government and Government of Uttar Pradesh to ensure that everything is
done to protect the interest of the home-buyers obviously without obliging the builders. Wherever
we seek any favour for home- buyers, we see that defrauding parties i.e., promoters/builders are
further obliged by making certain concessions by the Government that would amount to
perpetrating further fraud and unjust enrichment of builder. The case poses challenge to the law
enforcement agencies to act in tandem to book such culprits.
103. When there are defaults galore, creation of fake and dummy companies in an unbridled
manner, it passes comprehension that how the Statutory Auditor has failed to discharge the duty
cast upon him and the officials of the Amrapali Group also shared hard earned money of home-
buyers in an illegal manner by siphoning it off. Directors had obtained salaries without doing
anything. Money is diverted and siphoned off in other projects. Office junior employees, peons and
relatives etc. were inducted as Directors just to defraud the home-buyers of their money and to
siphon it out. Without material being supplied, a large amount of money had been paid by way of
forge purchases as a method to divert money even through authorised signatories and the
Companies of the relatives, family members and relations of the Directors and Guarantors also. InBikram Chatterji vs Union Of India on 23 July, 2019

the case fraud is to such large extent, it is difficult to capsulise the facts in a narrow compass, for
that when we see the report and good job done by the Forensic Auditors to unearthed the fraud.
They have gone into minute details forensically and done their job extremely well, due to which
serious kind of fraud has been unearthed with the involvement of so many persons as referred to by
them. We direct the concerned Authorities to look into the violation of the FEMA and FDI norms as
projected by the Forensic Auditors in their report and to submit progress report in this Court. IN
RE: RERA
104. The Bill was passed in the Rajya Sabha on 10.3.2016 and in the Lok Sabha on 15.3.2016. The
Bill intended to standardise business practices and transactions in the real estate sector. It intends
to ensure consumer protection. It intends to regulate transaction related to both residential and
commercial projects. The Statement of Objects and Reasons are as under:
“STATEMENT OF OBJECTS AND REASONS The real estate sector plays a catalytic
role in fulfilling the need and demand for housing and infrastructure in the country.
While this sector as grown significantly in recent years, it has been largely
unregulated, with absence of professionalism and standardisation and lack of
adequate consumer protection. Though the Consumer Protection Act, 1986 is
available as a forum to the buyers in the real estate market, the recourse is only
curative and is not adequate to address all the concerns of buyers and promoters in
that sector. The lack of standardisation has been a constraint to the healthy and
orderly growth of industry. Therefore, the need for regulating the sector has been
emphasised in various forums.
2. In view of the above, it becomes necessary to have a Central legislation, namely,
the Real Estate (Regulation and Development) Bill, 2013 in the interests of effective
consumer protection, uniformity, and standardisation of business practices and
transactions in the real estate sector. The proposed Bill provides for the
establishment of the Real Estate Regulatory Authority (the Authority) for regulation
and promotion of real estate sector and to ensure sale of plot, apartment or building,
as the case may be, in an efficient and transparent manner and to protect the interest
of consumers in real estate sector and establish the Real Estate Appellate Tribunal to
hear appeals from the decisions, directions or orders of the Authority.
3. The proposed Bill will ensure greater accountability towards consumers, and
significantly reduce frauds and delays as also the current high transaction costs. It
attempts to balance the interests of consumers and promoters by imposing certain
responsibilities on both. It seeks to establish symmetry of information between the
promoter and purchaser, transparency of contractual conditions, set minimum
standards of accountability and a fast-track dispute resolution mechanism. The
proposed Bill will induct professionalism and standardisation in the sector, thus
paving the way for accelerated growth and investments in the long run.Bikram Chatterji vs Union Of India on 23 July, 2019

4. The Real Estate (Regulation and Development) Bill, 2013 inter alia provides for the
following, namely:-
(a) to impose an obligation upon the promoter not to book, sell or offer for sale, or
invite persons to purchase any plot, apartment or building, as the case may be, in any
real estate project without registering the real estate project with the Authority;
(b) to make the registration of real estate project compulsory in case where the area
of land proposed to be developed exceed one thousand square meters or number of
apartments proposed to be developed exceed twelve;
(c) to impose an obligation upon the real estate agent not to facilitate sale or purchase
of any plot, apartment or building, as the case may be, without registering himself
with the Authority;
(d) to impose liability upon the promoter to pay such compensation to the allottees,
in the manner as provided under the proposed legislation, in case if he fails to
discharge any obligations imposed on him under the proposed legislation;
(e) to establish an Authority to be known as the Real Estate Regulatory Authority by
the appropriate Government, to exercise the powers conferred on it and to perform
the functions assigned to it under the proposed legislation;
(f) the functions of the Authority shall, inter alia, include – (i) to render advice to the
appropriate Government in matters relating to the development of real estate sector;
(ii) to publish and maintain a website of records of all real estate projects for which
registration has been given, with such details as may be prescribed; (iii) to ensure
compliance of the obligation cast upon the promoters, the allottees and the real estate
agents under the proposed legislation;
(g) to establish an Advisory Council by the Central Government to advice and
recommend the Central Government on – (i) matters concerning the implementation
of the proposed legislation; (ii) major questions of policy;
(iii) protection of consumer interest; (iv) growth and development of the real estate
sector;
(h) to establish the Real Estate Appellate Tribunal by the appropriate Government to
hear appeals from the direction, decision or order of the Authority or the adjudicating
officer;
(i) to appoint an adjudicating officer by the Authority for adjudging compensation
under sections 12, 14 and 16 of the proposed legislation;Bikram Chatterji vs Union Of India on 23 July, 2019

(j) to make provision for punishment and penalties for contravention of the
provisions of the proposed legislation and for non-compliance of orders of Authority
or Appellate Tribunal;
(k) to empower the appropriate Government to supersede the Authority on certain
circumstances specified in the proposed legislation;
(l) to empower the appropriate Government to issue directions to the Authority and
obtain reports and returns from it.
(5) The Notes on clauses explain in detail the various provisions contained in the Real
Estate (Regulation and Development) Bill, 2013.
(6) The Bill seeks to achieve the above objectives.”
105. It is apparent from the aims and objectives that Act ensures greater accountability towards
consumers and significantly reduce fraud and delays. Accountability standards have been laid down
where duties cast upon promotors as well as the effort has been made to make consumer also
responsible.
106. Before coming to the rival submission with respect to RERA, we deem it appropriate to note
certain provisions. Common areas have been defined under Section 2(n). The apartment has been
defined under Section 2(e). Section 2(k) defines carpet area, whereas Section 2(q) defines
completion certificate. Completion certificate to mean that certificate issued by competent authority
certifying that the project has been developed according to the sanctioned plan, layout plan and
specifications as approved by the competent authority. Occupancy certificate has been defined in
Section 2(zf) which states that certificate issued by the competent authority permitting occupation
of any building which has provision for civic infrastructures such as water, sanitation, and
electricity. Section 2(zk) defines promoter as a person who constructs or causes to be constructed an
independent building or a building consisting of apartments or converts an existing building for the
purpose of selling to other persons; a person who develops land into a project; any development
authority or any other public body; an apex State level co-operative housing society etc.; any other
person who acts himself as a builder, coloniser, contractor, developer, estate developer or by any
other name; and such other person who constructed any building or apartment for sale to general
public.
107. It is provided under Section 3 that no promoter shall advertise, market, book, sell or offer for
sale any plot, apartment or building in any real estate project or part of it without registration with
the Real Estate Regulatory Authority established under the Act. The provisions of the Act have also
been made applicable to the ongoing projects on the date of commencement of the Act and for which
completion certificate has not been issued, the promoter shall make an application to the Authority
for registration of said project within three months from the date of commencement of the Act.Bikram Chatterji vs Union Of India on 23 July, 2019

The projects of Amrapali Group have registration under the RERA is an admitted fact. The
provisions of the RERA are applicable is also not in dispute.
108. Section 4 requires the application to be filed with specified documents for the purpose of
registration. As per Section 4(2)(l)(D), 70 percent of the amount realised for the real estate project
from the allottees, from time to time, shall be deposited in a separate account to be maintained in a
scheduled bank to cover the cost of construction and the land cost and shall be used only for that
purpose and the promotor shall withdraw only to the proportion of the percentage of completion of
the project. The accounts have to be audited in every six months and chartered accountant has to
certify that amounts collected for a particular project have been utilised for that project and the
withdrawal has been in compliance with the proportion of the percentage of the completion of the
project. The provisions of Section 4(2)(l)(D) is extracted hereunder:
“4. Application for registration of real estate projects.- (1)** (2) The promoter shall
enclose the following documents along with the application referred to in sub-section
(1), namely: —
(l) a declaration, supported by an affidavit, which shall be signed by the promoter or
any person authorised by the promoter, stating:-
(A)** (B)** (C)** (D) that seventy per cent of the amounts realised for the real estate
project from the allottees, from time to time, shall be deposited in a separate account
to be maintained in a scheduled bank to cover the cost of construction and the land
cost and shall be used only for that purpose:
Provided that the promoter shall withdraw the amounts from the separate account, to
cover the cost of the project, in proportion to the percentage of completion of the
project:
Provided further that the amounts from the separate account shall be withdrawn by
the promoter after it is certified by an engineer, an architect and a chartered
accountant in practice that the withdrawal is in proportion to the percentage of
completion of the project:
Provided also that the promoter shall get his accounts audited within six months after
the end of every financial year by a chartered accountant in practice, and shall
produce a statement of accounts duly certified and signed by such chartered
accountant and it shall be verified during the audit that the amounts collected for a
particular project have been utilised for that project and the withdrawal has been in
compliance with the proportion to the percentage of completion of the project.
Explanation.- For the purpose of this clause, the term "schedule bank" means a bank
included in the Second Schedule to the Reserve Bank of India Act, 1934 (2 of 1934);”Bikram Chatterji vs Union Of India on 23 July, 2019

109. When we consider the provisions in the instant case, it was necessary to deposit the amount in
the account. In the year 2015, the RERA was in contemplation and certain provisions came into
force on 1.5.2016 and some more Sections i.e., 3 to 19, 40, 59 to 70 and 79 and 80 came into force
with effect from 1.5.2017.
110. A blatant violation of the provisions of RERA has been done by the Amrapali Group. Since
RERA contemplates timely completion of projects once registration has been granted under Section
5 and extension of registration under Section 6, it is only in the event of force majeure in case there
is no default on the part of the promoter, registration can be extended in aggregate for the period
not exceeding one year. Force majeure shall mean a case of war, flood, drought, fire, cyclone,
earthquake or any other calamity caused by nature. The registration granted under Section 5 is valid
for a period declared by the promoter. Section 7 provides that the Authority may on receipt of a
complaint or suo motu or on the recommendation of the competent authority revoke the
registration granted under Section 5 in case promoter makes default in doing anything required by
or under the Act or the rules or the regulation made thereunder; the promoter violates any of the
terms of approval given by the competent authority; the promoter is involved in any kind of unfair
practice or irregularities. It is also independently provided that in case the promoter indulges in any
fraudulent practices, the registration can be revoked. Upon revocation of the registration, the
promoter shall be debarred from accessing the website in relation to that project under Section
7(4)(a). Under Section 7(4)(b), the Authority shall facilitate the remaining development works to be
carried out in accordance with provisions of Section 8. Provisions of Section 7 is extracted
hereunder:
“7. Revocation of registration. - (1) The Authority may, on receipt of a complaint or
suo motu in this behalf or on the recommendation of the competent authority, revoke
the registration granted under section 5, after being satisfied that—
(a) the promoter makes default in doing anything required by or under this Act or the
rules or the regulations made thereunder;
(b) the promoter violates any of the terms or conditions of the approval given by the
competent authority;
(c) the promoter is involved in any kind of unfair practice or irregularities.
Explanation.— For the purposes of this clause, the term "unfair practice means" a practice which,
for the purpose of promoting the sale or development of any real estate project adopts any unfair
method or unfair or deceptive practice including any of the following practices, namely:— (A) the
practice of making any statement, whether in writing or the visible representation which,—
(i) falsely represents that the services are of a particular standard or grade;
(ii) represents that the promoter has approval or affiliation which such promoter does not have;Bikram Chatterji vs Union Of India on 23 July, 2019

(iii) makes a false or misleading representation concerning the services;
(B) the promoter permits the publication of any advertisement or prospectus whether in any
newspaper or otherwise of services that are not intended to be offered;
(d) the promoter indulges in any fraudulent practices. (2) The registration granted to the promoter
under section 5 shall not be revoked unless the Authority has given to the promoter not less than
thirty days notice, in writing, stating the grounds on which it is proposed to revoke the registration,
and has considered any cause shown by the promoter within the period of that notice against the
proposed revocation.
(3) The Authority may, instead of revoking the registration under sub-section (1), permit it to
remain in force subject to such further terms and conditions as it thinks fit to impose in the interest
of the allottees, and any such terms and conditions so imposed shall be binding upon the promoter.
(4) The Authority, upon the revocation of the registration,—
(a) shall debar the promoter from accessing its website in relation to that project and specify his
name in the list of defaulters and display his photograph on its website and also inform the other
Real Estate Regulatory Authority in other States and Union territories about such revocation or
registration;
(b) shall facilitate the remaining development works to be carried out in accordance with the
provisions of section 8;
(c) shall direct the bank holding the project back account, specified under subclause (D) of clause (I)
of sub-section (2) of section 4, to freeze the account, and thereafter take such further necessary
actions, including consequent de-freezing of the said account, towards facilitating the remaining
development works in accordance with the provisions of section 8;
(d) may, to protect the interest of allottees or in the public interest, issue such directions as it may
deem necessary.”
111. It is clear that RERA intends for completion of the project in case any fraud is committed by the
promoter and the activity is not completed, the home-buyers cannot be left in lurch, allowing the
prayer on behalf of Bankers as well as by the Authorities would amount to unfair treatment of home
buyers in the facts of this case. It is too late for them to submit that home buyer has no rights in the
teeth of the provisions contained in the RERA, which intends to prevent fraud.
112. Once registration lapses on non-completion of project within the time stipulated or it is revoked
the consequence ensue as enumerated in Section 8 of RERA, the Authority is enjoined upon the duty
to consult with the appropriate Government to take such action as it may deem including the
carrying out of the remaining development works by competent authority or by the association of
allottees or any other manner as may be determined by the Authority. The development work has toBikram Chatterji vs Union Of India on 23 July, 2019

be completed and cannot be left in between. Section 8 reads thus;
“8. Obligation of Authority consequent upon lapse of or on revocation of registration.- Upon lapse of
the registration or on revocation of the registration under this Act, the Authority, may consult the
appropriate Government to take such action as it may deem fit including the carrying out of the
remaining development works by competent authority or by the association of allottees or in any
other manner, as may be determined by the Authority:
Provided that no direction, decision or order of the Authority under this section shall
take effect until the expiry of the period of appeal provided under the provisions of
this Act:
Provided further that in case of revocation of registration of a project under this Act,
the association of allottees shall have the first right of refusal for carrying out of the
remaining development works.”
113. Functions and duties of the promoter are specified in Section 11. As per the
provisions of this Section, the promoter shall be responsible to obtain the completion
certificate or the occupancy certificate. He shall also be responsible for providing and
maintaining the essential services on reasonable charges, till taking over of the
maintenance by the association of the allottees. The promoter shall enable the
formation of an association or society or co-operative society or federation of
allottees. He shall pay all outgoings until he transfers the physical possession to the
allottee. After he has executed an agreement for sale for any apartment, plot or
building, he may not mortgage or create a charge on such an apartment, plot or
building and if any such mortgage or charge is made or created then notwithstanding
anything contained in any other law for the time being in force, it shall not affect the
right and interest of the allottee. It is clearly provided under Section 11(4)(h), which
is extracted hereunder:
“11. Functions and duties of promoter.-
(4) The promoter shall—
(h) after he executes an agreement for sale for any apartment, plot or building, as the
case may be, not mortgage or create a charge on such apartment, plot or building, as
the case may be, and if any such mortgage or charge is made or created then
notwithstanding anything contained in any other law for the time being in force, it
shall not affect the right and interest of the allottee who has taken or agreed to take
such apartment, plot or building, as the case may be;”
114. It is clear that is the duty of the promoter to abide by the time schedule of the
completion of the project of the allottee. The time of completion of the project is fixed
from the date of the agreement. Though the RERA has come into force after theBikram Chatterji vs Union Of India on 23 July, 2019

mortgage had been created, the intendment of RERA is that after the execution of the
agreement no such mortgage or charge should be created.
115. Section 14 provides adherence to sanctioned plans and project specifications by
the promoter. Section 15 deals with the obligations of the promoter in case of transfer
of a real estate project to a third party. The promoter shall not transfer or assign his
majority rights and liabilities to a third party without obtaining the prior written
consent of two-thirds allottees and without the prior written approval of the
Authority. Section 16 deals with obligations of promoter regarding the insurance of
real estate project. Section 17 provides for the transfer of title. It is incumbent upon
the promoter to execute a registered conveyance deed in favour of the allottee along
with undivided proportionate title in the common areas to the association of the
allottees or the competent authority and the possession of the plot, apartment or
building, as the case may be, shall be handed over to the allottees and the common
areas to the association of the allottees or the competent authority, as the case may
be. Section 17(1) is extracted hereunder:
"17. Transfer of title.- (1) The promoter shall execute a registered conveyance deed in
favour of the allottee along with the undivided proportionate title in the common
areas to the association of the allottees or the competent authority, as the case may
be, and hand over the physical possession of the plot, apartment of building, as the
case may be, to the allottees and the common areas to the association of the allottees
or the competent authority, as the case may be, in a real estate project, and the other
title documents pertaining thereto within specified period as per sanctioned plans as
provided under the local laws:
Provided that, in the absence of any local law, conveyance deed in favour of the
allottee or the association of the allottees or the competent authority, as the case may
be, under this section shall be carried out by the promoter within three months from
date of issue of occupancy certificate.”
116. It is apparent that after the transfer of conveyance deed, the title vests in the
allottee and of the common area in the association of the allottees or the competent
authority as the case may be. No title remains with the promoter.
117. Section 18 deals with the return of amount and compensation. In case promoter
fails to complete or is unable to give possession of an apartment, plot or building, he
shall be liable on demand to the allottees.
In case the allottee wants to withdraw from the project, without prejudice to any
other remedy available, the promoter has to return the amount received in respect of
that apartment, plot, building with interest in this behalf including compensation in
the manner as provided under the Act.Bikram Chatterji vs Union Of India on 23 July, 2019

118. The rights and liabilities of allottees are provided in Section 19, which is
reproduced hereunder:
“19. Rights and duties of allottees.- (1) The allottee shall be entitled to obtain the
information relating to sanctioned plans, layout plans along with the specifications,
approved by the competent authority and such other information as provided in this
Act or the rules and regulations made thereunder or the agreement for sale signed
with the promoter.
(2) The allottee shall be entitled to know stage-wise time schedule of completion of
the project, including the provisions for water, sanitation, electricity and other
amenities and services as agreed to between the promoter and the allottee in
accordance with the terms and conditions of the agreement for sale.
(3) The allottee shall be entitled to claim the possession of apartment, plot or
building, as the case may be, and the association of allottees shall be entitled to claim
the possession of the common areas, as per the declaration given by the promoter
under sub-
clause (C) of clause (I) of sub-section (2) of section 4. (4) The allottee shall be entitled to claim the
refund of amount paid along with interest at such rate as may be prescribed and compensation in
the manner as provided under this Act, from the promoter, if the promoter fails to comply or is
unable to give possession of the apartment, plot or building, as the case may be, in accordance with
the terms of agreement for sale or due to discontinuance of his business as a developer on account of
suspension or revocation of his registration under the provisions of this Act or the rules or
regulations made thereunder. (5) The allottee shall be entitled to have the necessary documents and
plans, including that of common areas, after handing over the physical possession of the apartment
or plot or building as the case may be, by the promoter.
(6) Every allottee, who has entered into an agreement for sale to take an apartment, plot or building
as the case may be, under section 13, shall be responsible to make necessary payments in the
manner and within the time as specified in the said agreement for sale and shall pay at the proper
time and place, the share of the registration charges, municipal taxes, water and electricity charges,
maintenance charges, ground rent, and other charges, if any. (7) The allottee shall be liable to pay
interest, at such rate as may be prescribed, for any delay in payment towards any amount or charges
to be paid under sub-section (6).
(8) The obligations of the allottee under sub-section (6) and the liability towards interest under
sub-section (7) may be reduced when mutually agreed to between the promoter and such allottee.
(9) Every allottee of the apartment, plot or building as the case may be, shall participate towards the
formation of an association or society or cooperative society of the allottees, or a federation of the
same.Bikram Chatterji vs Union Of India on 23 July, 2019

(10) Every allottee shall take physical possession of the apartment, plot or building as the case may
be, within a period of two months of the occupancy certificate issued for the said apartment, plot or
building, as the case may be.
(11) Every allottee shall participate towards registration of the conveyance deed of the apartment,
plot or building, as the case may be, as provided under sub-section (1) of section 17 of this Act.”
119. Certain rights and duties as well as the liabilities to pay interest in case of default on the part of
allottees are also provided in the provisions contained in Section 19. Chapter V provides for Real
Estate Regulatory Authority, whereas Chapter VI deals with the Central Advisory Council. The
provisions relating to Real Estate Appellate Tribunal are provided in Chapter VII. Chapter VIII
contains provisions relating to offences, penalties, and adjudication and Chapter IX deals with
finance, accounts, audits, and reports.
120. It is apparent that RERA intends protection of home-buyers and aims at completion of the
buildings. The buildings have to be completed, for that, we are required to pass orders. We have
already assigned the task to NBCC for completion of buildings as the promoters/builders have failed
to complete the building within the time fixed and the time which could have been extended. Now,
more than 10 years have passed and buyers were given the assurances that they would get flats
within three years period by the promoter/builder. The maximum time fixed in RERA has also
expired and extension could not have been beyond 1 year.
121. It is clear that common areas as provided under Section 17 have to be ultimately handed over to
the Association of Allottees or the Competent Authority as the case may be. Thus, any sub-lease,
alienation or transfer affected by the promoter of the common areas as defined in the RERA and
otherwise reserved under the plan shall be void and inoperative.
122. As the basic obligations have not been complied with by the promoters, they cannot also be
entitled to FAR. It was pointed out on behalf of Authorities that permissible FAR is 2.75, whereas it
has been wrongly mentioned and worked out at 3.50 by the Amrapali Group. In the instant case, we
find that there is serious kind of fraud by the promotors as such they cannot be said to be entitled to
avail the FAR to utilise it or to alienate and more so when they have failed to complete the projects
and pay the dues.
123. It is also apparent from the provisions of the Act of 1976 as well as RERA and also the case set
up by the Authorities that partial occupation certificate can also be issued. The completion
certificate can be issued partially also as per the provisions of Uttar Pradesh Apartment (Promotion
of Construction, Ownership, and Maintenance) Act, 2010. The main obstacle is said to be
non-deposit of the amount which may be ordered to be paid, for that we may clarify in the peculiar
facts and circumstances of the case, it has to be secured and recovered by way of selling other
attached properties and the one, which have been created out of the diverted funds of the
home-buyers and property of guarantors etc. The banks' borrowings have to be taken care of in a
similar manner. The money payable to the Authorities had been diverted and huge amount of
buyers’ money had not been invested in the projects neither any part of the money of bankBikram Chatterji vs Union Of India on 23 July, 2019

borrowings, in fact, were spent in the construction as found by the Forensic Auditors. The
promoters are held accountable for the diversion of the money paid by the buyers as component of
price of flats even on account of payment to Authorities.
124. There appears to be non-issuance of the completion certificate, whereas the buildings are being
occupied, we direct issue of completion certificate. This Court has to monitor the payment of dues of
the Authorities and Banks and that outstanding are not going to create hurdle in the execution of the
registered document/conveyance deed in favour of home buyers. It has to be executed by the
concerned Authorities as well as by the Court Receiver and by the home buyers. The amount which
is due on the part of home buyers has to be deposited in the account, which has been opened, in the
UCO Bank by this Court. It has to be utilised firstly for the purpose of completion of the buildings
and for providing other facilities and the home buyers of incomplete projects also have to deposit
the outstanding amount on their part in the aforesaid account opened in the UCO Bank and out of
that amount, it has to be disbursed as per the orders to be passed by this Court for the purpose of
construction and outstanding if any, shall be used for the purpose of payment of compensation to
home buyers for the period of delay as per the agreement or as may be determined ultimately and
other dues.
125. With respect to percentage of profit of NBCC, we fix it at 8 percent. As it is a Government
Undertaking, NBCC has to ensure that DPR is prepared reasonably and the work to be completed as
expeditiously as possible.
126. Learned senior counsel on behalf of Bank of Baroda submitted that Amrapali Group as per the
conditions of the lease deed executed by the Noida Authority had the right to mortgage the land with
the prior permission of the authority for raising loans for the purpose of financing investment in the
project. No doubt the lease deed contained a stipulation as to mortgage with prior permission but no
clear-cut permission had been obtained from Noida authority. Noida authority has clearly stated as
rider that until and unless the entire due premium is paid along with lease money due, no mortgage
can be effected. The stand of the authority is clear that without payment of land dues no mortgage
could be effected. Thus, in fact in the eye of the law no mortgage could be created as there was no
permission to mortgage unless the dues were paid and thus the bank could not have mortgaged the
property before clearance of the dues of the Noida Authority, and secondly, the mortgage was
permissible for the purpose of financing the investment in the project. As a matter of fact, when this
was the stipulation, it was the banker's duty to ensure that money made available was invested in
the project.
127. The Forensic Auditors’ report makes it apparent that Bankers have failed to ensure and oversee
that the money was invested in the projects. It was diverted elsewhere as rightly found by the
Forensic Auditors. Thus, no charge can be said to have been created by bank loans on the projects as
the money, in fact, it has not been used in the projects as such home buyers cannot be saddled with
liability and also the projects. Even what was paid by the home buyers, had not been used in the
projects and stands diverted. There was, in fact, no necessity for raising the loans from the bank.
The money borrowed from banks was used to create other assets worth thousands of crores. Thus,
the banks can realise their money from those assets and from guarantors and not from theBikram Chatterji vs Union Of India on 23 July, 2019

investment of home buyers, not from the buildings in which loans granted by banks have not been
invested, which have been erected partially or some are at the nascent stage, for which hard-earned
money has been paid by the home buyers. Home buyers are not direct party to the bank loan, thus it
was the duty of the bankers and Noida authorities, if they wanted to impose their charge, to ensure
that no fraud takes place and money is invested in the projects for the purpose for which it has been
taken not only the money paid by the home buyers but obtained from the banks and due to be paid
to Noida authorities, is not usurped illegally by promoter/builder. Though it was realised as part of
the component of the price of flat from the home buyers, by the promoters/builders its illegal
diversion was permitted by Amrapali Group in connivance with the officers of the authorities and
the bank. Thus, the very condition of investment in the project by bankers, subject to which the
mortgage was permissible, had been violated. Thus, it cannot be said that any charge of the banks
has been created on the projects. The charge would be on the property which has been
purchased/created by dubious methods. It would be inequitable to fasten the charge against the
investment made by the home buyers whereas they have not been benefited and rather have been
cheated by the promoters for which bankers, as well as authorities, have to share the blame. We
cannot perpetuate another fraud on the innocent home buyers in facts of the case of fastening
liability of amounts payable to Authorities and Bankers.
128. Learned senior counsel on behalf of the Bank of Baroda, also submitted that the home buyers
are not secured creditors, as such they have no right over secured creditors. While making the
aforesaid submissions the provisions of RERA have been ignored. Though they may not be a secured
creditor, they have a right to be treated in accordance with the law, fairly and they cannot be
subjected to a fraudulent action by the promoters, that too in connivance with the bankers and
officials of the Noida and Greater Noida authorities. Even otherwise, in such a situation the court
has to come to their rescue and protect their interests, and it is the duty of the court to ensure that
buyers get flats and development work is completed as intended under the RERA and the flats are
handed over to home buyers after completion. In case the fraud is permitted to be perpetrated on
the home buyers, the very purpose of enactment of RERA would stand defeated.
129. No doubt about it as submitted on behalf of Amrapali group of companies, that the provisions
of RERA are for protecting the interests of promoters also. No doubt about it that the RERA intends
to protect the interests of the promoters and home buyers both. However, in the instant case, we
have given the opportunity to the promoters to deposit the 10% of the amount in December 2017
and January 2018 but orders have met with non-compliance with all impunity. Thereafter on the
assurance of the Amrapali Group that it would undertake the construction work and a joint plan was
submitted after great wastage of time and energy and then order dated 17.5.2018 was passed that
was also not complied with. It was passed on a condition that a sum of Rs.250 crores to be deposited
which was also not deposited by the Amrapali group to show its bona fide. The Group never
intended right from the beginning to complete the construction work, has been rightly observed by
Forensic Auditors. Thereafter, we have assigned the work to the NBCC. But at the same time, the
effort has been made by Amrapali Group/ its Directors to sell the property which has been created
by diversion of home buyers’ funds. Incorrect facts have been stated and suppressions have been
made in various affidavits filed in this Court that the certain properties are not encumbered. Various
applications are being filed one after the other by the encumbered holders with respect to severalBikram Chatterji vs Union Of India on 23 July, 2019

properties that they have the charge over the said property.
130. That apart, several attached properties have been put to sale by DRT under the orders of this
Court. In most of the cases, no buyers have turned up and/or the price offered by forming a cartel
are too low. The property cannot be sold at throw away price. For example, in the case of a hospital
situated at Noida, the very group of doctors wanted to purchase, it who are running it, at a paltry
sum by forming a cartel. Aforesaid is one of the examples of cartel formation that is how Amrapali
group is instrumental in not allowing the properties to be sold. There appears to be some invisible
hand holding buyers out and even the bankers are not coming up to finance the purchasers, is the
genuine grievance pointed out at the Bar. Be that as it may. Entire gamut of facts indicates the
contumacious conduct of Amrapali Group, proper and correct disclosures on oath have not been
made, even encumbrances are not being specified clearly in spite of repeated orders passed by us.
They have sold several valuable properties during pendency of petitions as pointed out by the
Forensic Audit Report. In the aforesaid circumstances, the submission raised on behalf of Amrapali
group that under the provisions of the RERA their interest should be protected. In our opinion,
considering the serious kind of fraud unearthed on the forensic audit, formation of dummy
companies, violation of norms of foreign investment, violation of FEMA, siphoning off the money of
home buyers, making payment of dividend without profits and a methodology had been devised of
valuing the shares on an unreasonable higher basis so as to siphon out the money of the home
buyers to J.P. Morgan etc. The creation of a large number of assets with the help of money of the
home buyers. The Forensic Audit unfolds the true story of Amrapali Group. Right from 2015, no
construction activity has taken place. Account books had not been maintained and money has been
transferred continuously. No audit was made. Money was taken out from banks, and fake purchases
have been made. Thus, they are not at all entitled for any indulgence under the provisions of the
RERA. In view of their unholy conduct, defying description, their contumacious fraudulent conduct
totally disentitles them and they are required to be dealt with as sternly as possible so as to make it
exemplary one that such fraudulent actions do not recur in future, in real estate business in India.
We are not a country in which Courts will permit such action and permit a person to go scot-free.
131. The agreement initially executed in favour of home buyers to purchase flats may not create any
right in the property in praesenti, it will be only on the execution of the registered document that
title is going to be perfected, but investment in project is only of home buyers. In this case, as they
have paid money invested in projects, it is for the courts to do complete justice between the parties
and to protect the investment so made and interests of home buyers and to ensure that they get the
perfect title and the fruits of their hard earned money and lifetime savings invested in the projects.
132. On behalf of Bank of Baroda, learned senior counsel submitted that the agreement of
promoter/builder with home buyers is unregistered as such, no right has been created in the
immovable property in view of the provisions contained in section 49 of the Registration Act. The
submission ignores and overlooks the provisions of RERA which intends to prevent such frauds on
home buyers and ensure completion of projects and that of the agreement between promoters and
buyers. There are various rights under the agreement as well as under the RERA. The agreement
entered into at the time of allotment is the basis of the investment in the projects made by home
buyers, it cannot be said to be a scrap of paper. It is their valuable investment which is required toBikram Chatterji vs Union Of India on 23 July, 2019

be protected and cannot be permitted to be taken away by builder or secured creditors in an illegal
manner. The provisions of section 17 of the Registration Act no doubt provide that a document of
title requires compulsory registration, no doubt registered document has to be executed that also
has to be taken care of by the Court so as to protect the interest of home buyers.
133. Learned senior counsel appearing on behalf of the Bank of Baroda urged that by virtue of the
provisions contained in section 11(4)(g) of the RERA Act, it is the duty of the promoter to pay all
outgoings until he transfers the physical possession of the real estate project to the allottee or the
association of allottees, which he has collected from the allottees, for the payment of outgoings,
including the land cost, ground rent, municipal or other legal taxes, charges for water or electricity,
maintenance charges, including the mortgage loan and interest on mortgages or other
encumbrances and such other liabilities payable to competent authorities, banks and financial
institutions, which are related to the project. The two expressions of the provisions of Section
11(4)(g) are significant. Firstly, which the promoter has collected from the allottees. Secondly "which
are related to the project". In the instant case dues of the Noida/Greater Noida authorities have
been collected from the allottees by the promoters but the authorities have permitted diversion of
said amount by not taking any action in view of the chronic default right from the beginning.
Though they knew that the promoter had booked the flats, even the permission to grant sub-lease of
the plot had been granted in totally illegal manner without payment of dues of premium and lease
rent etc. Conditional permission to the mortgage was issued without payment of the premium lease
money etc. so as to perpetuate the fraud being done by the promoters. The mortgage created ought
to have been objected in view of the conditions subject to which it could have been done. Obviously,
it was done by Amrapali Group in connivance with officials of Authorities including the bankers.
Thus when the authorities have themselves permitted fraudulent action money has been diverted,
which has been paid by home buyers for payment to Authorities also, as premium was component of
price and as bankers have also permitted diversion of loan amount, mostly on same day, it cannot be
said in the facts of the case, that any amount of the bankers or that of authorities remains invested
in the project. The sine qua non is the expression "which are related to the project" would mean that
that amount recoverable from the allottee is the one which has been invested in the project. A third
person can be held liable for the money payable to secured creditors in case it has been invested in
the project, in case it has not been spent in constructions, same cannot be permitted to be realised
from the project/home buyers, the investment of home buyers cannot be frittered away and to
fasten liability upon the innocent buyers/allottees in that event would tantamount to perpetrating
yet another fraud on them. Accountability, as per law, has to be fastened on promoters/builders and
all concerned. It would amount to total deprivation of money of home buyers without any fault on
their part or legal liability. It would amount to fastening liability upon them once over again by
misuse of the process of law. The factual matrix unfolded on forensic audit indicates serious kind of
fraud that has taken place which would shut the enforcement of liability clause as against the home
buyers. The provisions of the first and second charge cannot come to the rescue of
Authorities/Bankers. Under Section 11(4)(g) the promoter has to pay all outgoings which he has
collected from the allottees, the payment of outgoings includes land cost, ground rent, charges for
water or electricity, maintenance charges etc. As per the proviso to Section 11(4)(g), the promoter
shall continue to be liable, even after the transfer of the property, to pay such outgoings and penal
charges, if any, to the authorities. Outgoings which have been collected by the promoter can be andBikram Chatterji vs Union Of India on 23 July, 2019

have to be recovered in the facts and circumstance of the case from them as intended by section
11(4)(g) of RERA.
134. Learned senior counsel on behalf of the Bank of Baroda submitted that the provisions of section
11(4)(h) of RERA provides that the promoter, after he executes an agreement for sale for any
apartment, plot or building, cannot mortgage or create a charge on such an apartment, plot or
building, as the case may be, and if any such mortgage or charge is made or created then it shall not
affect the right and interest of the allottee who has taken or agreed to take such apartment, plot or
building, as the case may be. The provision has a non-obstante clause. As the provision has given an
overriding effect by non-obstante clause, the provision is no help to the banks as the agreement had
been by promoters with home buyers entered into earlier in point of time to the creation of the
mortgage. There could not have been any mortgage created subsequently and even if validly created,
it would not affect the right and interest of the allottee as intended by RERA. Thus, the right and
interest of the allottee are safeguarded by virtue of the provisions contained in section 11(4)(h). As
the project was pending, the provision intends to confer a right on the allottee and save the allottees
and also their interests from such liability. Even if the provision is held not applicable on the ground
that RERA came into force later, since there was no valid mortgage as held by us, it was incapable of
affecting the right or interest of the allottee. Had it been ensured that the money due to Noida and
Greater Noida authorities was paid by the promoters to the authorities, the fraud of siphoning of
money would not have taken place to the extent it has been done. Moreover, the money borrowed
from banks has not been invested in the projects. In fact, projects required no funding. It would be
iniquitous to charge the allottees with the bankers' money. Thus, in the peculiar facts and
circumstances of the case, we hold that rights or interests of the allottees are not at all affected by
the mortgage created by the bankers or by the dues of the Noida or Greater Noida authorities.
135. On behalf of the Bank of Baroda, Shri Maninder Singh learned senior counsel has submitted
that section 4(2)(1) of the RERA requires the promoter to disclose the prior encumbrance.
Therefore, the RERA contemplates the creation of encumbrance even before the project is registered
and such a plot can be offered to allottees. Basically, a declaration is required under section
4(2)(l)(A) that the land is free from all encumbrances or as the case may be, details of the
encumbrances, if any, on such land, should be disclosed. The intention is that the allottee should
know about the encumbrance if any. The provision does not espouse the cause of the bank in any
manner whatsoever.
136. On the strength of the provision of section 19(4) of RERA, learned senior counsel has submitted
that the allottee should be entitled to claim the refund and compensation, if the promoter fails to
comply or is unable to give possession of the apartment, plot or building in accordance with the
terms of the agreement for sale or due to discontinuance of his business as a developer on account of
suspension or revocation of his registration under the provision of the RERA or the rules and
regulations made thereunder. He submitted that the right of the allottees is restricted to only
receiving the compensation from the promoters. We wholly disagree with the submission. It is made
in oblivion of the provisions of Section 8 of the RERA which provides for completion of the
development projects by the competent authority or by the association of allottees or in any other
manner, as may be determined and the association of allottees shall have the first right of refusal forBikram Chatterji vs Union Of India on 23 July, 2019

carrying out the remaining development work is the wholesome provision contained in the second
proviso to section 8. To claim compensation is at the option of the allottee if the allottee wants to go
out. That is an additional right, not the only right conferred under the RERA. He cannot be left in
lurch but is entitled to claim the refund if he so desires. It is his option to claim the refund along
with interest and compensation which is to be determined under the RERA. The rights of the
allottees are not restricted to only receiving the compensation as submitted. The submission is too
tenuous to be accepted.
137. A submission has also been raised that the RERA recognises and protects interests of the
lenders and does not in any manner take away rights under any of the existing statutes such as T.P.
Act, Debt Recovery Tribunal Act, SARFAESI Act. It is apparent from a perusal of RERA, which is a
special Act, that certain rights have been created in favour of the buyers. The provisions of RERA
have to prevail. When we come to the question of protection of rights of buyers even if RERA had
not been enacted, under aforesaid laws in the facts of the case, a different view could not have been
taken. However, there is no dispute that the bankers would have the right to recover their dues from
whom and in what manner is the question which we have already answered. The provisions of
RERA are beneficial to the home buyers and are intended to insulate them from fraudulent action,
ensures completion of the building and it is the duty of the court to protect and ensure the home
buyers’ interest and at the same time to hold them responsible for the duties enjoined upon them
under the said statute. We are not absolving the home buyers from the discharge of their liability if
any. At the same time, they have the right of enforcement of their right for compensation due to
undue delay in completion of the project.
138. It was submitted by learned senior counsel on behalf of the Greater Noida authority that title
has to pass in home buyers by way of registered document as provided in section 17(1)(b) of the
Registration Act and section 13 of the U.P. Apartments Act, 2010 and also the provisions of the lease
deed. The deed of transfer will be a tripartite sub-lease deed. Completion certificate has to be
obtained, for that it has to be applied for. Dues of the authorities have to be paid before a completion
certificate is issued. The charge of Noida and Greater Noida authority has priority over other
charges. None of the aforesaid submissions impress us so as to defeat the rights of home buyers. We
have already dealt with that the dues have to be recovered in accordance with law from the
properties which have been created by the funds which have been diverted and the property of the
directors etc. In order to do complete justice between the parties so that the faith of public is not
shaken in the real estate sector and such frauds are prevented in the future. We cannot permit the
authorities in the facts and circumstances of the case to deal with the rights of the home buyers in
arbitrary and in an unjust manner.
139. In case the authorities are making allotment of plots at a paltry sum of 10% and giving the
builders 8 years period to make payment of premium with a moratorium of 2 years then the period
runs to 10 years and the project is to be completed within 3 years. It is clear that the authorities have
to be very vigilant for securing their interests otherwise in every case even if the promoter has
completed the project and realised the charges from the home buyers and has not deposited the
amount due to the authorities, in case no action is taken by the Authorities, can it be taken after 10
years against home buyers. The question arises whether innocent home buyers would have to payBikram Chatterji vs Union Of India on 23 July, 2019

the amount to authorities which they have already paid to promoters as part of the component of
cost of flats or plots as the case may be, whether they are to be saddled once over again with the
liability to pay, though the amount paid by them has been illegally usurped and diverted elsewhere
and not paid to the authorities and they have acted in connivance of officials. The authorities have to
be vigilant in such cases and not to tolerate the default. They have to blame themselves for their
inaction and have to wait for the realisation of dues by sale of other properties and as against
guarantors etc. The projects have to be completed as mandated by Section 8 of RERA
140. It was submitted that the authorities on cancellation of the lease have to forfeit 25% of the
amount and have to resume the lands along with the structure. It cannot be done in view of the
provisions of RERA, particularly in view of the provisions of section 8 and other beneficial
provisions contained in the said Act. Under section 14 of the Act of 1976, there can be forfeiture of
the entire amount also, in case of breach of condition or breach of rules, etc. by the promoters/
builders. Be that as it may. We hold and direct no action under any provisions derogatory to the
interest of home buyers can be taken either by the authorities or the bankers in the peculiar facts
and circumstances of the case, that is to say, that no part of the building can be demolished.
Buildings have to come up and completed even the ones which are at the nascent stage as mandated
by RERA. No doubt about it that in case of failure to pay the dues the onus of payment of land dues
has to be passed on to the buyers on pro-rata basis but in the instant case they have already paid the
substantial amounts, huge amount has been permitted to be diverted by the authorities and bankers
as such they have to wait for recovery and cannot act in a manner further detrimental to the
interests of the home buyers.
141. On behalf of Amrapali group, learned senior counsel submitted that there were force majeure
conditions in completing the projects. There were legal impediments in the completion of projects
within the period given in the flat-buyers agreement during the period from 2011-15. The
submission is baseless. It is apparent that the Full Bench of the High Court though held that the
land acquisition was vitiated but still it was upheld. The High Court did not quash it for the reason
that development has taken place. Higher compensation was ordered to be paid. That order was
affirmed by this Court in 2015 in Savitri Devi v. State of U.P. (2015) 7 SCC 21. There was no interim
stay granted by the High Court on construction work, is made clear by the Noida and Greater Noida
authorities. There was no room to entertain any doubt as to the fact whether for a particular village
the acquisition had been quashed. There was no quashing of land acquisition and moreover, there
was no stay. Only higher compensation was ordered to be paid. There was no force majeure
condition or any legal impediment as such the period from 2011 to 2015 cannot be treated as a
moratorium period vis-à-vis the dues of Noida and Greater Noida authorities. The submission made
as to the farmers' agitation etc. is too vague and 30% of the projects have come up; whereas 70%
have not yet come up, out of the projects in Noida and Greater Noida alone. It goes to indicate how
at large-scale middle-class home buyers have been defrauded of their hard-earned money, taken
away by the affluents and the officials in connivance with each other. Law has to book all of them.
We are hopeful that law will spread its tentacular octave to catch all culprits responsible for such
kind of fraud causing deprivation to home buyers. It is shocking and surprising that so many
projects have remained incomplete. Several lakhs of home buyers have been cheated. As if there is
no machinery of law left to take care of such situation and no fear left with the promoters/buildersBikram Chatterji vs Union Of India on 23 July, 2019

that such acts are not perceivable in a civilised society. Accountability is must on the part of
everybody, every institution and in every activity. We fail to understand the standard of observance
of the duties by public authorities has gone so down that such frauds take place openly, blatantly,
and whatever legal rights exist only on papers and people can be cheated on such wide scale openly,
brazenly and with the knowledge of all concerned. There is duty enjoined under the RERA, there has
to be a Central Advisory Council as well as the role of the State Government is not ousted in order to
protect against such frauds. We direct the Central Government and the State Government to take
appropriate steps on the time-bound basis to do the needful, all other such cases where the projects
have remained incomplete and home buyers have been cheated in an aforesaid manner, it should be
ensured that they are provided houses. The home buyers cannot be made to suffer when we are
governed by law and have protective machinery. Question is of will power to extend the clutches of
law to do the needful. We hope and trust that hope and expectation of home buyers are not going to
be belied.
142. We are not impressed by the submission that Amrapali Group had taken the lands and had paid
a part of dues and has invested a certain amount. The statement of the expenditure of the money of
the home buyers, in the construction activity that has been filed in the Court, is not supported by
documents and is prima facie a scrap of paper. We have called the concerned incumbents who have
prepared it and cross-checked from them and we are satisfied that the statement filed on the
expenditure of Rs.10,000 crores is nothing but a scrap of paper not supported by the books of
account, supporting documents. It has to be outrightly rejected as there is an attempt made on
siphoning off, apparent from the report of the Forensic Auditors also.
143. In his affidavit, Anil Kumar Sharma has given details of companies from which funds were
transferred to the extent of Rs.2,996.20 crores to different group companies, mainly from following
nine companies:
CHART “E” DETAILS OF MAJOR COMPANIES FROM WHERE FUNDS WERE
TRANSFERRED IN THE FORM OF ICD AND SHARE CAPITAL AS PER BALANCE
SHEET TILL 2015 Consolidated Amount Transferred from Amrapali Group till 31st
March S. No. Name of Companies Net amount Transmitted/ Transferred from these
companies of Amrapali Group of Companies (A) Amount in Cr, 1 Amrapali Smart
City Dev. Pvt. Ltd. 538.59 2 Amrapali Centurian Park Pvt. Ltd. 518.78 3 Amrapali
Dream Valley Pvt. Ltd. 445.33 4 Amrapali Leisure Valley Pvt. Ltd. 431.11 5 Amrapali
Silicon City Pvt. Ltd. 391.57 6 Amrapali Leisure Valley Dev. Pvt. 237.53 Ltd.
     7       Amrapali Zodiac Dev. Pvt. Ltd.            224.47
     8      Amrapali Princely Estate Pvt. Ltd.         186.99
     9      Amrapali Sapphire Dev. Pvt. Ltd.            21.84
                       Grand Total                    2,996.20Bikram Chatterji vs Union Of India on 23 July, 2019

The diversion of huge amount has been rightly detected on Forensic Audit.
144. Learned senior counsel appearing on behalf of Amrapali Group also submitted that the
under-valued transactions have been found of INR 321.31 crores which is incorrect. The Forensic
Auditors have given the details in their report along with reasons, we agree with them and have no
hesitation to reject the submission.
145. As to other amounts with respect to advances which are recoverable, the explanation that there
is a surrender of shares by Mr. Shiv Priya, etc. is not supported by books of accounts. There is no
basis to contend so. No proper explanation has been given on behalf of Amrapali Group. Shares
were purchased by Mr. Anil Kumar Sharma in his own name. It was clearly an advance. It was not
purchased in the name of the company but in the individual's name. There was cash in hand and
other recoverable also, no proper explanation has been offered. Cash in hand has to be deposited
back as it belongs to home buyers. The finding as to the diversion of home buyers' funds is based on
the figures worked on the basis of minute accounting as reflected in the auditors' report. There is no
proper answer to each and every entry which have been gone into by the Auditors. General and
broad submissions have been made which are flimsy and have no legs to stand. Thus, the objections
are rejected. The professional fee could not have been realised by the Directors. They were not the
employees. They have not rendered any professional services. They along with other employees,
statutory auditors, CFO, etc. have formed a cartel to defraud the home buyers for siphoning off their
money. Dummy companies were created in the names of peons, boys of office, the relation of
statutory auditor, CFO, etc. and several companies were created only for the purpose of few
transactions. The fact discloses how the fraud has been perpetrated upon the home buyers which
defies description which could not have been unearthed except by skilful exercise done by the
Forensic Auditors. Thus, we have no word to specify the extent of fraud played. Least said is better
as to the entire gamut of the facts and entire scenario of the case.
146. It is apparent from the report of the forensic audit submitted by Forensic Auditors that there is
a serious kind of fraud played upon the buyers in active connivance with the officials of the Noida
and Greater Noida Authorities and that of the banks. The money of the home buyers has been
diverted. The Directors diverted the money by the creation of dummy companies, realizing
professional fees, creating bogus bills, selling flats at undervalue price, payment of excessive
brokerage, etc. They have obtained investment from J.P. Morgan in violation of FEMA and FDI
norms. The shares were overvalued for making payment to J.P. Morgan. It was adopted as a device
for siphoning off the money of the home buyers to foreign countries. In view of the huge money
collected from the buyers and comparable investments made in the projects, there was no necessity
to obtain a loan from banks. The amount so obtained was not used in the projects. The mortgage
deeds in favour of the banks were not permissible due to non-payment of dues of the Noida and
Greater Noida Authorities. The Noida and Greater Noida Authorities issued conditional NOCs. to
create mortgages subject to payment of dues which were not paid. They issued such NOCs in
collusion with builders. It was incumbent upon the bankers also to obtain clear unconditional NOCs.
which were not obtained and to ensure that the dues were paid to Noida and Greater Noida
authorities. They permitted diversion of money immediately after sanctioning of the loan and also in
day to day transactions of Amrapali group of companies.Bikram Chatterji vs Union Of India on 23 July, 2019

147. No accounts were prepared w.e.f. the years 2015-2018 and money withdrawn was diverted
during the said period. The Statutory Auditor, Mr.Mittal failed in duty and was part of fraudulent
activities as found in the Forensic Report. The money obtained from banks was diverted to
unapproved uses such as for the creation of personal assets of Directors, creation of assets in closely
held companies by the Directors along with their partners and relatives, for personal expenses of
Directors, to give advances without carrying interest for several years. There was total non-
monitoring by the bankers. The money laundering was resorted to by Amrapali Group/ Directors.
The Noida and Greater Noida Authorities were grossly negligent in reviewing and monitoring the
progress of the projects and in collusion with leaseholders failed to take action concerning non-
payment of dues and illegally permitted the group to sub-lease the land without payment of dues.
Bogus allotments of flats were made. There were other irregularities galore.
148. Because of their failure to fulfil the obligations towards the buyers and the serious kind of fraud
which has been played by them upon the home buyers, the registration of Amrapali group of
companies under the Real Estate Regulation and Development Act, 2016 deserves to be cancelled.
149. Because of the gross violations of the conditions of lease deeds executed by the Noida and
Greater Noida Authorities in favour of Amrapali group of companies with respect to various
projects, are liable to be cancelled and the rights thereupon shall vest in the Court Receiver.
150. There was no valid mortgage created in favour of Banks and there was a huge diversion of
money paid by homebuyers which were more than required for payment of dues of the Noida/
Greater Noida Authorities and banks. The buyers have paid the dues of Noida and Greater Noida
authorities as a component of the price for flats. Thus, the premium and other dues payable under
the lease deeds to the Noida and Greater Noida Authorities, cannot be recovered from the home
buyers or the projects in question. The dues as may be ordered shall be recovered by sale of other
properties which have been created by the diversion of funds and have been attached by this Court.
The banks have also failed to ensure that the money was used in the projects. As found in the
forensic audit, there was no necessity of obtaining loans from the banks and it has not been used for
the purpose it was obtained. The Authorities and Bankers have violated the doctrine of public trust
and their officials, unfortunately, acted in collusion with builders. The dues of the banks are also to
be recovered from the other attached properties as observed by us.
151. The criminal cases have also been registered by the police, we propose to monitor the progress
of the investigation. For violations of FEMA and FDI norms, we direct the Enforcement Directorate
to make investigation in accordance with the law and submit reports quarterly to this Court. Money
laundering aspect is also to be looked into by concerned authorities.
152. It has been found in the Forensic Audit Report that there are several recoverable from various
companies as well as from individuals, Directors and other incumbents. We direct that as per the
findings recorded by the Forensic Auditors, the money be deposited in this Court on a time-bound
basis and other needful be done as observed by the Auditors. As we have approved the report, let the
concerned companies/ Directors/ individuals take steps in compliance with the observations and
findings made by Auditors to refund the amount and or to do needful as suggested within oneBikram Chatterji vs Union Of India on 23 July, 2019

month.
153. We have also found that non-payment of dues of the Noida and Greater Noida Authorities and
the banks cannot come in the way of occupation of flats by home buyers as money of home buyers
has been diverted due to the inaction of Officials of Noida/ Greater Noida Authorities. They cannot
sell the buildings or demolish them nor can enforce the charge against homebuyers/ leased land/
projects in the facts of the case. Similarly, the banks cannot recover money from projects as it has
not been invested in projects. Homebuyers money has been diverted fraudulently, thus, fraud
cannot be perpetuated against them by selling the flats and depriving them of hard-earned money
and savings of entire life. They cannot be cheated once over again by sale of the projects raised by
their funds. The Noida and Greater Noida Authorities have to issue the Completion/ Part
Completion Certificate, as the case may be, to execute tripartite agreement and registered deeds in
favour of the buyers on part- completion or completion of the buildings, as the case may be or where
the inhabitants are residing, within a period of one month.
154. Resultantly, we order as follows:
(i) The registration of Amrapali Group of Companies under RERA shall stand
cancelled;
(ii) The various lease deeds granted in favour of Amrapali Group of Companies by
Noida and Greater Noida Authorities for projects in question stand cancelled and
rights henceforth, to vest in Court Receiver;
(iii) We hold that Noida and Greater Noida Authorities shall have no right to sell the
flats of the home buyers or the land leased out for the realization of their dues. Their
dues shall have to be recovered from the sale of other properties which have been
attached. The direction holds good for the recovery of the dues of the various Banks
also.
(iv) We have appointed the NBCC to complete the various projects and hand over the
possession to the buyers. The percentage of commission of NBCC is fixed at 8
percent.
(v) The home buyers are directed to deposit the outstanding amount under the
Agreement entered with the promoters within 3 months from today in the Bank
account opened in UCO Bank in the Branch of this Court. The amount deposited by
them shall be invested in the fixed deposit to be disbursed under the order of this
Court on phase-wise completion of the projects/work by the NBCC.
(vi) In view of the finding recorded by the Forensic Auditors and fraud unearthed, indicating prima
facie violation of the FEMA and other fraudulent activities, money laundering, we direct
Enforcement Directorate and concerned authorities to investigate and fix liability on persons
responsible for such violation and submit the progress report in the Court and let the police alsoBikram Chatterji vs Union Of India on 23 July, 2019

submit the report of the investigation made by them so far.
(vii) We direct the Institute of Chartered Accountants of India to initiate the appropriate
disciplinary action against Mr. Anil Mittal, CA for his conduct as reflected in various transactions
and the findings recorded in the order and his overall conduct as found on Forensic Audit. Let
appropriate proceedings are initiated and concluded as early as possible within 6 months and a
report of action taken to be submitted to this Court.
(viii) We direct various Companies/ Directors and other incumbents in whose hands money of the
home buyers is available as per the report of Forensic Auditors, to deposit the same in the Court
within one month from today and to do the needful in the manner as observed. The last opportunity
of one month is granted to deposit the amount and to do the needful failing which appropriate
action shall be taken against them.
(ix) Concerned Ministry of Central Government, as well as the State Government and the Secretary
of Housing and Urban Development, are directed to ensure that appropriate action is taken as
against leaseholders concerning such similar projects at Noida and Greater Noida and other places
in various States, where projects have not been completed. They are further directed to ensure that
projects are completed in a time-bound manner as contemplated in RERA and home buyers are not
defrauded.
(x) We appoint Shri R. Venkataramani, learned Senior Advocate, as the Court Receiver. The right of
the lessee shall vest in the Court Receiver and he shall execute through authorized person on his
behalf, the tripartite agreement and do all other acts as may be necessary and also to ensure that
title is passed on to home buyers and possession is handed over to them.
(xi) We also direct Noida and Greater Noida Authorities to execute the tripartite agreement within
one month concerning the projects where homebuyers are residing and issue completion certificate
notwithstanding that the dues are to be recovered under this order by the sale of the other attached
properties. Registered conveyance deed shall also be executed in favour of homebuyers, they are to
be placed in the possession and they shall continue to do so in future on completion of projects or in
part as the case may be. We direct the Noida and Greater Noida Authorities to take appropriate
action to do the needful in the matter. The Water Works Department of the concerned area and the
Electricity Supplier are directed to provide the connections for water and electricity to home buyers
forthwith.
155. Let the cases be listed for further hearing before us on 9.8.2019.
………………….…..J. (Arun Mishra) …………………..….J. (Uday Umesh Lalit) July 23, 2019;
New Delhi.Bikram Chatterji vs Union Of India on 23 July, 2019

