Ashok Leland Ltd vs State Of Tamil Nadu And Anr on 7 January,
2004
Equivalent citations: AIR 2004 SUPREME COURT 2836, 2004 AIR SCW 1001,
2004 (1) SCALE 224, 2004 (1) ACE 219, 2004 (3) SCC 1, 2004 (1) ALL CJ 787,
2004 (2) SLT 5, (2004) 134 STC 473, (2004) 182 TAXATION 193, (2004) 56
KANTLJ(TRIB) 337, (2004) 5 SUPREME 115, (2004) 1 SCALE 224, (2004) 14
INDLD 189, 2004 ALL CJ 1 787, (2004) 1 JT 289 (SC)
Author: S.B. Sinha
Bench: V.N. Khare, S.B. Sinha, A.R. Lakshmanan
           CASE NO.:
Appeal (civil)  976-979 of 2001
PETITIONER:
ASHOK LELAND  LTD.
RESPONDENT:
STATE OF TAMIL NADU AND ANR.
DATE OF JUDGMENT: 07/01/2004
BENCH:
V.N. KHARE. CJ & S.B. SINHA & A.R. LAKSHMANAN
JUDGMENT:
JUDGMENT 2004(1) SCR 306 S.B. Sinha, J.
1. Leave granted in S.L.P. (Civil) No. 5579 of 2001.
2. Interpretation of Section 6A of the Central Sales Tax Act, 1956 is involved in these appeals and the
writ petition. The appeals arise out of judgments and orders dated 12.3.1999 passed by the Tamil
Nadu Sales Tax Appellate Tribunal in T.A. Nos. 353, 456 and 457 of 1997 and 47 of 1998; dated
13.11.2000 in STA No. 459 of 1999; dated 14.11.1997 in Appeal No. 383 of 1996; and dated 2.12.1997
in Tax Case (Revision) No. 1096 of 1990 passed by the High Court of Madras.
3. The writ petition under Article 32 was filed by the Petitioner inter alia for declaring that Section
9(2) of the Central Sales Tax Act, 1956 designating the authorities of the movement State to
adjudicate upon the situs of sales and character of a transaction in the course of an inter- State sale,
whether as falling under Section 3 or under Section 4 of the Central Sales Tax Act, 1956, is arbitrary,
unworkable and ultra vires Articles 14, 19(1)(g) and Chapter XIII of the Constitution of India, inAshok Leland Ltd vs State Of Tamil Nadu And Anr on 7 January, 2004

matters involving elements of transactions taking place in more than one State.
BACKGROUND FACTS:
Civil Appeal No. 976-979 of 2001
4. The appellants herein are engaged in manufacture of commercial vehicles. They have their
factories at Bhandara in the State of Maharashtra and Alwar in the State of Rajasthan for
manufacture of popular models of passenger chassis. They are, inter alia, registered under Tamil
Nadu General Sales Tax Act, 1959 (hereinafter called for the sake of brevity as "the State Act") as
also the Central Sales Tax Act, 1956 (hereinafter referred to as "the Central Act". They are registered
as dealers in the Office of Assistant Commissioner (Central Assessment Circle-III), the third
respondent herein, under both the Acts.
5. Indisputably, the appellants have several regional offices throughout the country wherewith
Regional Sales Offices are attached for the purpose of receiving, warehousing and selling the
vehicles produced by the appellants. The appellants contend that they transfer both goods vehicle
and passenger chassis to their different Regional Sales Offices for marketing the products which in
turn are registered under the Sales Tax laws governing the State in Question. The stock of vehicles
are transferred to the Regional Sales Offices under the cover of stock transfer invoices, excise gate
pass, and entrusted to the transport contractors for movement and delivery thereof where upon
transfer of such vehicles local sales tax are collected and paid by the different Regional Sales Offices.
The appellants herein upon transfer of such purported stocks of vehicles filled up forms in terms of
Section 6A of the Central Act, the original whereof having been filed before the assessing authority
of the State of Tamil Nadu, an enquiry was made and/or caused to be made pursuant whereto and in
furtherance whereof the claim of the appellants to the effect that by reason of such transactions
transfer of stock of goods had taken effect as contra-distinguished from inter-State sale was
accepted. On or about 29.11.1990, the assessing authority upon completion of the order of original
assessment under the Central Act allowed transfer of stocks of the motor vehicle chassis and other
automobile parts to the branches stating:
"The dealers have got 26 branch sales depots in other States. They have dispatched
their, products - chassis, spare parts etc., to their own sales depots in other States for
sales and the goods involved in the stock transfer have moved from Tamil Nadu to
other State as "stock transfer", i.e., the movement was occasioned by reason of
branch transfer and not by reason of sale. The dispatches are supported by stock
transfer invoices, transport details and Form F. These records have been verified with
the exemption claimed."
6. An order of assessment for the year 1987-88 dated 28.8.1991 was passed finding:
"The dealers have filed detailed statement of stock transfer of vehicles to their outside
State Regional Sales Offices and Spares to their warehouses. The statement was
verified in detail with reference to Form "F" declaration filed by them andAshok Leland Ltd vs State Of Tamil Nadu And Anr on 7 January, 2004

dispatching documents. The dealers have also filed completed assessment orders of
their Regional Sales Offices in other States. Their claim was examined in length and
found to be in order. The Form "F" filed by them are accepted and the exemption
granted."
[Underlining is mine for emphasis)
7. The assessing authority despite the said findings issued notices directing the appellants to show
cause as to why the order dated 29.11.1990 should not be revised and the stock of vehicles allegedly
transferred to the Regional Sales Offices so far as the same related to the State Transport
Undertakings are concerned should not be taxed as inter-State sales taxable in Tamil Nadu.
8. The appellants filed their show cause inter alia Questioning the jurisdiction of the assessing
authority to reopen the assessment inter alia on the ground that the issues stood determined in
terms of the provisions of Sub-section (2) of Section 6A of the Central Act relying or on the basis of
the declarations made by the appellants in terms of Form F. However, the reassessment proceeding
was completed relying upon the provisions contained in Section 16 of the State Act read with Section
9(2) of the Central Act as also in terms of the decision of this Court in Sahney Steel & Press Works
Ltd. v. CTO, : AIR1985SC1754 . Consequent to the said order the sales of the Regional Sales Offices
in relation to the deliveries made to the State Transport Undertakings of other States were
reassessed. Penalty for non- disclosure of the turnover as taxable sales in terms of Section 16(2) of
the State Act read with Section 9(2) of the Central Act was also imposed. Similar show cause notices
were issued in relation to other assessment years also.
9. A writ petition was filed by the appellants before the Madras High Court questioning the said
orders inter alia contending that having regard to the provisions contained in Section 6A of the
Central Act and further having regard to the fact that the appellants had paid tax to the other States
the orders impugned therein were illegal. The States wherein the local sales tax had been paid in
terms of the respective State Acts, namely, State of Kerala, Karnataka, Andhra Pradesh,
Maharashtra and Gujarat, were impleaded as parties therein and they in turn also questioned the
jurisdiction of the authorities of the State of Tamil Nadu to enquire about the transactions carried
out by the appellants. A question was also raised that the Madras High Court had no jurisdiction to
grant any relief touching the orders of assessment completed under the respective State law.
Upholding the jurisdiction of Tamil Nadu authorities to reopen an assessment completed despite
acceptance of declaration in Form F, the Madras High Court by a judgment and order dated
13.6.1996 dismissed the said writ application inter alia holding that they had no jurisdiction to grant
any relief. Thereafter the reassessment was completed and penalty was imposed.
JUDGMENT OF THIS COURT :
10. The matter came up for consideration before this Court in Ashok Leyland v. Union of India and
Ors. since reported in : [1997]2SCR224 at the instance of the appellant herein; and upon referring to
the decisions rendered in Balabhagas Hulaschand v. State of Orissa : [1976]2SCR939 , Izhar Ahmad
Khan v. Union of India : AIR1962SC1052 . Sodhi Transport Co. v. State of U.P. : [1986]1SCR939 andAshok Leland Ltd vs State Of Tamil Nadu And Anr on 7 January, 2004

several others, this Court by a judgment dated 20.2.1997 held:
(a) Section 6A does not create conclusive presumption as contended on behalf of the
assessee.
(b) An order of assessing authority accepting Form F, whether passed during the
assessment or at any point earlier thereto, forms part and parcel of the order of
assessment.
(c) Its amenability to the power of reopening and revision depends upon the
provisions of the concerned sales tax enactments by virtue of the operation of Section
9(2) of the Central Act.
(d) It is not possible to accept that an order under Section 6A(2) has an independent
existence.
(e) An order refusing to accept Form F may or may not be appealable independently
depending upon the provisions of the State sales tax enactments, but it is certainly
capable of being questioned if an appeal is preferred against the order of assessment.
(f) If orders accepting Form F are sought to be reopened, it can be done as part of
reopening of assessment or may be done independently, which would depend upon
the language of the relevant provisions of the concerned State Acts.
(g) It is permissible to reopen an assessment accepting Form F as true without, even
though such a reassessment necessarily leads to revision/ modification of the
assessment order.
(h) If the reopening is confined to the order accepting Form F as true, the enquiry
shall be confined to the matters relevant thereto. In that case, it was noticed that the
assessments were sought to be reopened only in respect of the turnover relating to
sales of vehicles to State Transport Undertakings and not turnover relating to persons
other than State Transport Undertakings.
(i) In the facts of the case, the question as to whether the power had been exercised
validly or not did not call for consideration. If the assessing authority decided against
the appellants, it would foe open to the assessee to file appeal (s) directly before the
Tribunal (in order to shorten the litigation and in the interest of justice). If and when
the Tribunal decides against the appellants, it shall be open to the appellants to
approach the Supreme Court.
11. Having said so, this Court noticed the anomalous situation created by reason of the absence of a
proper mechanism to adjudicate the question as to whether a particular transaction is an inter-State
sale or a local sale in the presence of an assessee and the relevant States concerned and the need forAshok Leland Ltd vs State Of Tamil Nadu And Anr on 7 January, 2004

the Parliament to intervene and provide for a suitable mechanism.
12. The Court appreciated the difficulties to be faced by the appellant having regard to the fact that it
had paid tax to the other State Governments. This Court further noticed the contention of the
appellant that the attitude adopted by the sales tax authorities in Tamil Nadu is not conducive of
judicial conduct as they are pre-determined to treat the transactions as inter-State sale and levy tax
thereon ignoring the fact and correct legal situation, but did not express any opinion on the
correctness or otherwise of the said submissions. It, however, felt the necessity of evolving a central
mechanism which would decide once for all questions of this nature. Elucidating certain instances, it
was opined that although the assessment proceedings before certain States had become final, this
Court in exercise of its jurisdiction under Article 32 or 136 or 142 of the Constitution of India may
issue appropriate directions, whereupon the following directions were issued :
"22...Let the Tamil Nadu assessing authorities first decide the matters before them.
Thereafter, if the order's are against the appellant, we permit the appellant to file the
appeal(s) directly before the Tribunal. If the Tribunal decides in favour of the
appellant, no further question would arise. But if it decides against the appellant, to
wit, if it holds that the sale of vehicles to the STUs of various States are inter-State
sales and if it is found that those very transactions have also been taxed as intra-State
sales under the State sales tax enactments of another State, that would be the stage
for considering the advisability of giving appropriate directions of the nature
contemplated above by this Court - that is, of course, if by that time, no Central
mechanism to meet such a situation comes into existence.
23. In the interest of inter-State trade and commerce, the suggestion for creation of a
Central mechanism to decide such disputes - which are really in the nature of inter -
State disputes - may be well worth considering; every dealer affected may not be in a
position to approach this Court for appropriate directions. It is for the Government of
India to consider this aspect and take necessary decision in that behalf."
SUBSEQUENT PROCEEDINGS :
13. Pursuant to or in furtherance of the said directions an order of reassessment was passed for the
years 1988-89 imposing tax on the sales of the appellants to the State Transport Undertakings at the
respective Regional Sales Offices by an order dated 12.12.1997. It, however, appears that when
companies similarly situated, as for example, Indicarb Limited approached the State Appellate
Tribunal, it refused to entertain an appeal there against holding that the direction of this Court in
Ashok Leyland (supra) was confined to the fact of that case. The Special Leave Petitions having been
filed by the assesses, this Court in Civil Appeal No. 14406-14408 of 1997 by an order dated 17.3.1998
held:
"As these special leave petitions and writ petitions involve important questions
involving conflict between States' sales tax assessment proceedings and the Central
sales tax assessment proceedings regarding the alleged very same sale transactionsAshok Leland Ltd vs State Of Tamil Nadu And Anr on 7 January, 2004

and as the problem is of a recurring nature and as a decision of a Bench of two Judges
of this Court in Ashok Leyland Ltd. v. Union of India and Ors. : [1997]2SCR224 , has
to be applied with suitable modifications, if required, it would be appropriate that
these matters are heard by a Bench of three learned Judges. In the meantime, the
Union of India who is one of the respondents in these proceedings, may have to be
heard with a view to suggest a modus operandi to resolve this conundrum. We,
therefore, request the learned Attorney General to appear for respondent No. 2
Union of India for assisting the court in these proceedings.
The office may obtain orders from Hon'ble the Chief Justice for placing these matters
before an appropriate Bench of three learned Judges."
14. Notices, pursuant to the said directions, were issued to the concerned States. Thereafter, even for
the subsequent periods also the Appellate Tribunal upheld the order passed in Indicarb Limited
which are also the subject matter of challenge before us.
PARLIAMENTARY INTERVENTION :
15. We may notice that having regard to the several orders passed in the connected matter, the
Parliament enacted Central Sales Tax (Amendment) Act, 2001 and Finance Act, 2002. Suggestions,
as regards certain provisions of the said Acts, however, having been mooted at the Bar, the matter is
said to be receiving fresh consideration at the hands of the Central Government.
16. It is also not in dispute that by enacting Central Sales Tax (Amendment) Act, 2001 by Central Act
20 of 2002, which came into force from 11th May, 2002, Section 2(g) of the Act has been substituted
by a new sub- section by which the definition of sale has been widened to include the deemed sales
defined by Article 366(29-A) of the Constitution to enable the levy of Central Sales Tax inter alia on
the transactions involving transfer of property in the goods involved in the execution of works
contract or transfer of the right to use the goods so that now even these transactions are open to levy
by two different States either as inter-State transaction, or intra-State transaction. Section 6A of the
Central Act was also amended insofar as in Sub-section (1) thereof the following words have been
inserted:
"If the dealer fails to furnish such declaration, then, the movement of such goods
shall be deemed, for all purposes of this Act, to have been occasioned as a result of
sale."
17. The appellants filed applications in these appeals, seeking leave to raise additional grounds in the
light of the said amendment.
SUBMISSIONS:
18. Mr. K. Parasaran, learned senior counsel appearing on behalf of the appellants would inter alia
submit that the ratio arrived at by this Court in Ashok Leyland (supra) requires a fresh look insofarAshok Leland Ltd vs State Of Tamil Nadu And Anr on 7 January, 2004

as by reason of Sub- section (2) of Section 6A of the Central Act, the statute provided for conclusive
evidence as regards the nature of transaction and as the orders passed thereunder attained finality,
the same could not have been reopened on any ground whatsoever. Drawing our attention to the
history of legislation as also the case laws leading to incorporation of Article 286, enactment of the
Central Act as also amendments made in Article 269 of the Constitution of India, the learned
counsel would submit that once by reason of the Central Act in terms of the determination made by
the statutory authorities thereunder, certain transactions by creating a legal fiction were kept
outside the purview of the Central Act, the assessing authorities cannot exercise their purported
jurisdiction of reopening an order of assessment under Section 16(2) of the State Act or Section 9(2)
of the Central Act. Formulation of principles for determining when a sale or purchase of
consignment of goods takes place in the course of inter-state trade or commerce being within the
exclusive domain of the Parliament having regard to Clause (3) of Article 269 of the Constitution of
India, Mr. Parasaran, would contend; statutory authorities created under the State Act could not
exercise any jurisdiction contrary to or inconsistent therewith.
19. The learned counsel would submit that the word "determination" signifies expression of opinion
which ends a controversy or a dispute by some authority to whom it is submitted under a valid law.
20. Mr. Parasaran would contend that in terms of Section 6A of the Central Act, as it then stood, the
assessee had two options, namely, to file Form F or subjected himself to an assessment proceeding.
If the assessee opts to file a declaration in terms of Form F, whereupon an order is passed holding
an enquiry by the assessing authority; the same being conclusive in nature, no proceeding for
reopening the same would be permissible in law. Reliance in this connection has been placed on
Izhar Ahmed Khan (supra), Balabhagas Hulaschand (supra) and Mahant Dharam Das etc. v. The
State of Punjab and Ors. : [1975]3SCR160 .
21. The learned counsel would argue that the expressions "for the purpose of the Act" would imply
"for the purpose of all the provisions of the Act"
and, thus, once an order is passed under Sub-section (2) of Section 6A of the Central
Act, Section 9(2) thereof will have also no application whatsoever. Reliance in this
behalf has been placed by Mr. Parasaran on M.K. Kochu Devassy v. State of Kerala :
1979CriLJ147 .
22. Mr. Parasaran would urge that while exercising the option, it is mandatory for the assessee to
supply all information(s) which are required in terms of Form F and once compliance of statutory
requirements are made, the adjudication thereupon shall become final and binding. He in support
of the said contention placed reliance on Shrisht Dhawan v. Shaw Brothers :
AIR1992SC1555 .
23. According to the learned counsel, such a provision has been inserted so as to emphasise the
necessity of expeditious determination as regard a transaction involving transfer of goods in terms
whereof different States claim themselves to be entitled to levy different rates of taxes under theAshok Leland Ltd vs State Of Tamil Nadu And Anr on 7 January, 2004

respective State Acts. If with a view to give effect thereto, no appeal has been provided, the same
would not invalidate the law. In other words, argument of Mr. Parasaran is that Section 6A has been
granted a higher status than the proceeding of assessment under the general law.
24. Mr. B. Sen, the learned senior counsel appearing on behalf of the State of West Bengal while
supporting the submission of Mr. Parasaran would further argue that the Central Act being relatable
to Article 286 of the Constitution of India as also Entry 97 of List I of the Seventh Schedule of the
Constitution, a presumption must be drawn that the purpose thereof was to take the taxing power of
the State taken away and, thus, in relation to such transactions the State cannot levy any tax. It is
evident that order of such nature passed by the assessing authorities of the State of Tamil Nadu
would not only affect the assesses but also other States as well and once it is held that the burden of
proof has been discharged by the assessee, such transactions must be held to have taken place
outside the purview of the Central Act.
25. Mr. A.K. Ganguli, the learned senior counsel appearing on behalf of the respondents, per contra,
would contend that the question as regard the conclusiveness or otherwise of an order under
Sub-section (2) of Section 6A of the Act shall operate as res judicata, keeping in view the fact that
the said issue has already been determined by this Court in Ashok Leyland (supra) and, thus, binds
the parties herein. The learned counsel would contend that Section 6A of the Act cannot be given a
higher status than the State Act or Section 9(2) of the Central Act inasmuch as an order passed in
terms of Sub-section (2) thereof is passed merely in aid of assessment and in that view of the matter
if an order of assessment can be appealed against or subjected to a reopening proceeding, the same
legal provisions must be held to be applicable also in relation to an order passed under Sub-section
(2) of Section 6A.
26. Mr. Ganguli has drawn our attention to the findings of the Tribunal to the effect that raids were
conducted by the authorities and that the appellant herein had escaped proper assessment by taking
recourse to suppressio veri and suggestio falsi. According to the learned counsel, as fresh materials
had been discovered, a reasoned show cause notice was issued and pursuant thereto and in
furtherance thereof, the impugned orders had been passed, and in that view of the matter no case
has been made out for interference therewith.
STATUTORY PROVISIONS:
27. 'Sale' has been defined in Tamil Nadu General Sales Act, 1959 as:
"2(n) "Sale" with all its grammatical variations and cognate expressions means every
transfer of the property in goods (other than by way of a mortgage, hypothecation,
charge or pledge) by one person to another in the course of business for cash,
deferred payment or other valuable consideration and includes -
(i) a transfer otherwise than in pursuance of a contract, of property in any goods for
"cash, deferred payment or other valuable consideration;Ashok Leland Ltd vs State Of Tamil Nadu And Anr on 7 January, 2004

(ii) a transfer of property in goods (whether as goods or in some other form) involved
in the execution of a works contract:..."
28. 'Turnover' in the said Act has been defined as under:
"2(r) "turnover" means the aggregate amount for which goods are brought or sold, or
delivered or supplied or otherwise disposed of in any of the ways referred to in Clause
(n), by a dealer either directly or through another, on his own account or on account
of others whether for cash or for deferred payment or other valuation consideration,
provided that the proceeds of the sale by a person of agricultural or horticultural
produce, other than tea and rubber (natural rubber latex and all varieties and grades
of raw rubber), grown within the State by himself or on any land in which he has an
interest whether as owner, usufructuary mortgagee, tenant or otherwise, shall be
excluded from his turnover ;"
29. Section 12 of the said Act provides for the procedure to be followed by the assessing authority in
terms whereof the dealer is required to file the prescribed return relating to his turnover submitted
in the prescribed manner within the period prescribed therefore. The Act provides for self-
assessment subject of course to the exceptions contained in Clause (b) of Sub-section (1) of Section
12. The errors contained in the return can, however, be corrected. A dealer making self-assessment
is required to make true and correct statements of fact. In the event, the dealer does not file a return
within the prescribed period and the return is found to be incorrect: in addition to the tax assessed,
the assessing authority may direct it to pay the amount of penalty levied in terms of Sub-section (3)
of Section 12.
30. Section 16 provides for assessment of escaped turnover which reads thus:
"16. Assessment of escaped turnover. -
(1)(a) Where, for any reason, the whole or any part of the turnover of business of a
dealer has escaped assessment to tax, the assessing authority may, subject to the
provisions of Sub-section (2), at any time within a period of five years from the date
of order of the final assessment by the assessing authority to determine to the best of
its judgment the turnover which has escaped assessment and assess the tax payable
on such turnover after making such enquiry as it may consider necessary and after
giving the dealer a reasonable opportunity to show cause against such assessment.
(b) where, for any reason, the whole or any part of the turnover of business of a
dealer has been assessed at a rate lower than the rate at which it is assessable, the
assessing authority may, at any time within period of five years from the date of order
of the final assessment by the assessing authority reassess the tax due after making
such enquiry as it may consider necessary and after giving the dealer a reasonable
opportunity to show cause against such re-assessment."Ashok Leland Ltd vs State Of Tamil Nadu And Anr on 7 January, 2004

31. In case of willful non-disclosure of assessable turnover by the dealer while passing an order of
reassessment, penalty can also be imposed. Sub- section (3) of Section 16 provides for the manner in
which limitation is to be computed. Section 31 of the Act provides for appeal.
32. The relevant provisions of the Central Sales Tax Act, 1956 are as under
:
2(b) "dealer" means any person who carries on (whether regularly or otherwise) the
business of buying, selling, supplying or distributing goods, directly or indirectly, for
cash or for deferred payment, or for commission remuneration or other valuable
consideration, and includes--
(i) a local authority, a body corporate, a company, any co-operative society or other
society, club, firm, Hindu undivided family or other association of persons which
carries on such business;
(ii) a factor, broker, commission agent, del credere agent, or any other mercantile
agent, by whatever name called, and whether of the same description as hereinbefore
mentioned or not, who carries on the business of buying, selling, supplying or
distributing, goods belonging to any principal whether disclosed or not; and
(iii) an auctioneer who carries on the business of selling or auctioning goods
belonging to any principal, whether disclosed or not and whether the offer of the
intending purchaser is accepted by him or by the principal or nominee of the
principal.
Explanation 1.--Every person who acts as an agent, in any State, of a dealer residing outside that
State and buys, sells, supplies, or distributes, goods in the State or acts on behalf of such dealer as -
(i) a mercantile agent as defined in the Sale of Goods Act, 1930 (3 of 1930), or
(ii) an agent for handling of goods or documents of title relating to goods, or
(iii) an agent for the collection or the payment of the sale price of goods or as a guarantor for such
collection or payment and every local branch or office in a State of a firm registered outside that
State or a company or other body corporate, the principal office or headquarters whereof is outside
that State, shall be deemed to be a dealer for the purposes of this Act.
Explanation 2.-- A Government which, whether or not in the course of business, buy, sells, supplies
or distributes, goods, directly or otherwise, for cash or for deferred payment or for commission,
remuneration or other valuable consideration, shall except in relation to any sale, supply or
distribution of surplus, unserviceable or old stores or materials or waste products or obsolete or
discarded machinery or parts or accessories thereof, be deemed to be a dealer for the purposes ofAshok Leland Ltd vs State Of Tamil Nadu And Anr on 7 January, 2004

this Act;
(g) "sale", with its grammatical variations and cognate expressions, means any transfer of property
in goods by one person to another for cash or for deferred payment or for any other valuable
consideration, and includes,-
(i) a transfer, otherwise than in pursuance of a contract, of property in any goods for cash, deferred
payment or other valuable consideration;
(ii) a transfer of property in goods (whether as goods or in some other form) involved in the
execution of a works contract;
(iii) a delivery of goods on hire-purchase or any system of payment by instalments;
(iv) a transfer of the right to use any goods for any purpose (whether or not for a specified period)
for cash, deferred payment or other valuable consideration;
(v) a supply of goods by any unincorporated association or body of persons to a member thereof for
cash, deferred payment or other valuable consideration;
(vi) a supply, by way of or as part of any service or in any other manner whatsoever, of goods, being
food or any other article for human consumption or any drink (whether or not intoxicating), where
such supply or service, is for cash, deferred payment or other valuable consideration, but does not
include a mortgage or hypothecation of or a charge or pledge on goods;
(j) "turnover" used in relation to any dealer liable to tax under this Act means the aggregate of the
sale prices received and receivable by him in respect of sales of any goods in the course of inter-State
trade or commerce made during any prescribed period and determined in accordance with the
provisions of this Act and the rules made thereunder;
6. Liability to tax on inter-State sales.-(1) Subject to the other provisions contained in this Act, every
dealer shall, with effect from such date as the Central Government may, by notification in the
Official Gazette, appoint, not being earlier than thirty days from the date of such notification, be
liable to pay tax under this Act on all sales of goods other than electrical energy effected by him in
the course of inter-State trade or commerce during any year on and from the date so notified:
Provided that a dealer shall not be liable to pay tax under this Act on any sale of
goods which, in accordance with the provisions of Sub-section (3) of Section 5 is a
sale in the course of export of those goods out of the territory of India.
(1A) A dealer shall be liable to pay tax under this Act on a sale of any goods effected
by him in the course of inter-State trade or commerce notwithstanding that no tax
would have been leviable (whether on the seller or the purchaser) under the sales tax
law of the appropriate State if that sale had taken place inside that State.Ashok Leland Ltd vs State Of Tamil Nadu And Anr on 7 January, 2004

(2) Notwithstanding anything contained in Sub-section (1) or Sub-section (1A), where
a sale of any goods in the course of inter-State trade or commerce has either
occasioned the movement of such goods form one State to another or has been
effected by a transfer of documents of title to such goods during their movement from
one State to another, any subsequent sale during such movement effected by a
transfer of documents of title to such goods,--
(a) to the Government, or
(b) to a registered dealer other than the Government, if the goods are of the
description referred to in Sub-section (3) of Section 8, shall be exempt from tax
under this Act.
6A. Burden of proof, etc., in case of transfer of goods claimed otherwise than by way of sale. - (1)
Where any dealer claims that he is not liable to pay tax under this Act, in respect of any goods, on
the ground that the movement of such goods from one State of another was occasioned by reason of
transfer of such goods by him to any other place of his business or to his agent or principal, as the
case may be, and not by reason of sale, the burden of proving that the movement of those goods was
so occasioned shall be on that dealer and for this purpose he may furnish to the assessing authority,
within the prescribed time or within such further time as that authority may, for sufficient cause,
permit, a declaration, duly filled and signed by the principal officer of the other place of business, or
his agent or principal, as the case may be, containing the prescribed particulars in the prescribed
form obtained from the prescribed authority, along with the evidence of dispatch of such goods.
(2) If the assessing authority is satisfied after making such inquiry as he may deem necessary that
the particulars contained in the declaration furnished by a dealer under Sub-section (1) are true he
may, at the time of, or at any time before, the assessment of the tax payable by the dealer under this
Act, make an order to that effect and thereupon the movement of goods to which the declaration
relates shall be deemed for the purpose of this Act to have been occasioned otherwise than as a
result of sale.
Explanation.--In this section, "assessing authority", in relation to dealer, means the authority for the
time being competent to assess the tax payable by the dealer under this Act. "
33. It may be noticed that by reason of Section 151 by Act No. 20 of 2002 the
following has been added in Sub-section (1) of Section 6A after the words "dispatch of
such goods":
"and if the dealer fails to furnish such declaration, then, the movement of such goods
shall be deemed for all purposes of this Act to have been occasioned as a result of
sale."
Section 9 of the said Act reads as under:Ashok Leland Ltd vs State Of Tamil Nadu And Anr on 7 January, 2004

"9. Levy and collection of tax and penalties.--(1) The tax payable by any dealer under
this Act on sales of goods effected by him in the course of inter-State trade or
commerce, whether such sales fall within Clause (a) or Clause (b) of Section 3, shall
be levied by the Government of India and the tax so levied shall be collected by that
Government in accordance with the provision of Sub-section (2), in the State from
which the movement of the goods commenced:
Provided that, in the case of a sale of goods during their movement from one State to
another, being a sale subsequent to the first sale in respect of the same goods and
being also a sale which does not fall within Sub- section (2) of Section 6, the tax shall
be levied and collected--
(a) where such subsequent sale has been effected by a registered dealer, in the State
from which the registered dealer obtained or, as the case may be, could have
obtained, the form prescribed for the purposes of Clause (a) of Sub-section (4) of
Section 8 in connection with the purchase of such goods;
and
(b) where such subsequent sale has been effected by an unregistered dealer in the State from which
such subsequent sale has been effected.] (2) Subject to the other provisions of this Act and the rules
made thereunder, the authorities for the time being empowered to assess, re- assess, collect and
enforce payment of any tax under the general sales tax law of the appropriate State shall, on behalf
of the Government of India, assess re-assess, collect and enforce payment of tax, including any
interest or penalty, payable by a dealer under this Act as if the tax or interest or penalty payable by
such a dealer under this Act is a tax or interest or penalty payable under the general sales tax law of
the State; and for this purpose they may exercise all or any of the powers they have under the
general sales tax law of the State; and the provisions of such law, including provisions relating to
returns. provisional assessment, advance payment of tax, registration of the transferee of any
business, imposition of the tax liability of a person carrying on business on the transferee of or
successor to, such business, transfer of liability of any firm of Hindu undivided family to pay tax in
the event of the dissolution of such firm or partition of such family, recovery of tax from third
parties, appeals, reviews, revisions, references, refunds, rebates, penalties, charging or payment of
interest, compounding of offences and treatment of documents furnished by a dealer as confidential,
shall apply accordingly.
34. Form 'F' which is relevant for the purpose of the case reads thus :
"ORIGINAL THE CENTRAL SALES TAX (REGISTRATION AND TURNOVER)
RULES, 1957 FORM F [Form of declaration to be issued by the transferee] [See Rule
12(5)] Serial No...................................
Name of the issuing State ................Ashok Leland Ltd vs State Of Tamil Nadu And Anr on 7 January, 2004

Office of issue...........................
Date of issue.............................
Name and address of the person to whom issued along with his Registration
Certificate No....................................... Date from which registration is
valid....................................
Seal of Issuing Authority To.................................(Transferor) Registration Certificate
No. of the Transferor......................... Certified that the goods transferred to me/us as
per details below have been received and duly account for.
Description of the goods sent. ..................... Quantity or weight................................
Value of the goods ............................ Number and date of invoice [or challan or any
other documents under which goods were sent.] Name of Railway Steamer or Ferry
Station or Air Port or Post Office or Road Transport Company's Office from where the
goods were dispatched................................ No. and Date of Railway Receipt or Postal
Receipt or Goods Receipt with trip sheet of lorry or any other documents indicating
the means of transport. ...............
Date on which delivery was taken by the transferee............
The above statements are true to the best of my knowledge and belief.
(Signature) (Name of the person signing the declaration) *(Status of the person
signing the declaration in relation to the transferee) *(Status of the person signing
the declaration in relation to the transferor) Date..........
*Strike out whichever is not applicable (Note - To be furnished to the assessing
authority in accordance with the rules framed under Section 13(4)
(e).)"
35. Having noticed the relevant provisions of the statute, we may notice the following constitutional
provisions:
"245. Extent of laws made by Parliament and by the Legislatures of States.
-- (1) Subject to the provisions of this Constitution, Parliament may make laws for the
whole or any part of the territory of India, and the Legislature of a State may make
laws for the whole or any part of the State.
(2) No law made by Parliament shall be deemed to be invalid on the ground that it
would have extra-territorial operationAshok Leland Ltd vs State Of Tamil Nadu And Anr on 7 January, 2004

268. Duties levied by the Union but States. -- (1) Such stamp duties and such duties
of excise on medicinal and toilet preparations as are mentioned in the Union List
shall be levied by the Government of India but shall be collected--
(a) in the case where such duties are leviable within any Union territory, by the
Government of India, and
(b) in other cases, by the States within which such duties are respectively leviable.
(2) The proceeds in any financial year of any such duty leviable within any State shall
not form part of the Consolidated Fund of India, but shall be assigned to that State.
269. Taxes levied and collected by the Union but assigned to the States.-(1) Taxes on
the sale or purchase of goods and taxes on the consignment of goods shall be levied
and collected by the Government of India but shall be assigned and shall be deemed
to have been assigned to the States on or after the 1st day of April, 1996 in the
manner provided in Clause (2).
Explanation.--For the purposes of this clause,-
(a) the expression "taxes on the sale or purchase of goods" shall mean taxes on sale or purchase of
goods other than newspapers, where such sale or purchase takes place in the course of inter-State
trade or commerce;
(b) the expression "taxes on the consignment of goods" shall mean taxes on the consignment of
goods (whether the consignment is to the person making it or to any other person), where such
consignment takes place in the course of inter-State trade or commerce.
(2) The net proceeds in any financial year of any such tax, except in so far as those proceeds
represent proceeds attributable to Union territories, shall not form part of the Consolidated Fund of
India, but shall be assigned to the States within which that tax is leviable in that year, and shall be
distributed among those States in accordance with such principles of distribution as may be
formulated by Parliament by law.
(3) Parliament may by law formulate principles for determining when a sale or purchase of, or
consignment of, goods takes place in the course of inter-State trade or commerce."
36. Article 286 as it stood prior to 6th Amendment Act, 1956 reads thus:
"286. Restrictions as to imposition of tax on the sate or purchase of goods. --
(1) No law of a State shall impose, or authorise imposition of a tax on the sale or
purchase of goods where such sale or purchase takes place --Ashok Leland Ltd vs State Of Tamil Nadu And Anr on 7 January, 2004

(a) outside the State; or
(b) in the course of import of goods into, or export of goods out of, the territory of
India.
Explanation: For the purposes of Sub-clause (a) a sale or purchase shall be deemed to have taken
place in the State in which the goods have actually been delivered as a direct result of such sale or
purchase for the purpose of consumption in that State, notwithstanding the fact that under the
general law relating to sale of goods the property in the goods has by reason of such sale or purchase
passed in another State.
(2) Except in so far as Parliament may by law otherwise provide, no law of a State shall impose, or
authorize the imposition of, a tax on sale or purchase of any goods where such sale or purchase takes
place in the course of inter-State trade or commerce:
Provided that the President may by order direct that any tax on the sale or purchase
of goods which was being lawfully levied by the Government of any State immediately
before the commencement of this Constitution shall, notwithstanding that the
imposition of such tax is contrary to the provisions of this clause continue to be levied
until thirty first day of March, 1951.
(3) No law made by the Legislature of a State imposing, or authorizing the imposition
of a tax on the sale or purchase of any such goods as have been declared by
Parliament by law to be essential for life of the community shall have effect unless it
has been reserved for the consideration of the President and has received his assent."
37. Paragraph 16 of Second Report of the Law Commission of India states:
"16. The question whether on the analogy of the principles adopted in connection
with sales or purchase in the source of import or export, a sale effected by the transfer
of documents during the movement of goods from one State to another should be
regarded as an inter-State sale or purchase has received our careful consideration.
We are of the view that such sales or purchases should be regarded as inter-State
transactions. It was suggested that if the rate of inter-State tax happened to be lower
than the rate of tax levied by the State on intra-State transaction the adoption of this
principle might lead to attempts by dealers to evade the higher tax of the State by
giving intra-State transactions the appearance of inter-State transactions by the
creation of fictitious records showing the movement of the goods from one State into
another. We are not inclined to attach much importance to this suggestion as in any
case the sale or purchase will not escape taxation altogether and it is unlikely that
dealers would resort to such attempts in order to save the difference between the
inter-State and the intra-State tax. Moreover, if this principle is not applied
considerable administrative and other difficulties will arise. We are, therefore, of the
view that sales and purchases effected by a transfer of documents during theAshok Leland Ltd vs State Of Tamil Nadu And Anr on 7 January, 2004

movements of goods from one State to another should be regarded as inter-State
transactions."
38. Thereafter the following Bill was introduced pursuant thereto:
"In Clause 2, it is proposed to add a new entry 92A in the Union List placing taxes on
inter-State sales and purchases within the exclusive legislative and executive power of
the Union, and to make entry 54 of the State List "subject to the provisions" of this
new entry.
In Clause 3, it is proposed to add these taxes to the list given in Clause (1) of Article
269, so that, although they will be levied and collected in accordance with an Act of
Parliament, they will not form part of the Consolidated Fund of India, but will accrue
to the States themselves in accordance with such principles of distribution as may be
formulated by Parliament by law. A further provision is proposed in Article 269
expressly empowering Parliament to formulate by law principles for determining
when a sale or purchase of goods takes place in the course of inter-State trade or
commerce.
It is proposed in Clause 4 to omit from Clause (1) of Article 286 the explanation which has given rise
to a great deal of legal controversy and practical difficulty. In view of the centralization of inter-State
sales tax proposed in Clause 2 of this Bill, Clause (2) of Article 286 in its present form will cease to
be appropriate. In its place it is proposed to insert a provision empowering Parliament to formulate
principles for determining when a sale or purchase of goods takes place (a) outside a State, or (b) in
the course of import of the goods into the territory of India, or (c) in the course of export of the
goods out of the territory of India.
It is further proposed to replace Clause (3) of Article 286 by a new clause on the lines recommended
by the Taxation Enquiry Commission. Under this revised clause Parliament will have the power to
declare by law the goods which are of special importance in inter-State trade or commerce and also
to specify the restrictions and conditions to which any State law (whether made before or after the
Parliamentary law) will be subject in regard to the system of levy, rates and other incidents of the tax
on the sales or purchase of those goods."
39. Pursuant to or in furtherance of the Report of the Law Commission of India, Article 286 was
amended. Article 286(3) now reads as under:
"(3) Any law of a State shall, in so far as it imposes, or authorises the imposition of,--
(a) a tax on the sale or purchase of goods declared by Parliament by law to be of
special importance in inter-State trade or commerce; or
(b) a tax on the sale or purchase of goods, being a tax of the nature referred to in
Sub-clause (b), Sub-clause (c) or Sub-clause (d) of Clause (29A) of Article 366, beAshok Leland Ltd vs State Of Tamil Nadu And Anr on 7 January, 2004

subject to such restrictions and conditions in regard to the system of levy, rates and
other incidents of the tax as Parliament may by law specify."
40. The history of legislation as also constitutional amendments in relation to inter-State movement
of goods has been noticed in State of A.P. etc. v. National Thermal Power Corporation Ltd. and
Others etc. : [2002] 3SCR278 and as such it may not be necessary to reiterate the same once over
again.
SECTION 6A OF THE CENTRAL ACT:
41. Prior to amendment of Section 6A of the Central Act, filing of Form F was optional. The dealer
was, thus, entitled either to file such form or not to file the same. Only because such form is not
filed, the same would not mean that the dealer was prohibited from raising a plea that no stock of
transfer from his Head Office to Regional Offices or Regional Sales Offices has taken place. It was
entitled to plead that by reason of such transactions which are intra-organisation, sale was not
occasioned by movement of goods. The question which was required to be posed and answered by
the assessing authority was, thus, required to be confined only to the fact as to whether any sale has
(SIC) by movement of goods or not. In other words, an (SIC) to the concept of inter-State sale
invoking the provisions of the Central Act would be when such movement of goods was by way of
transfer of stock in terms whereof no tax under the Central Act was payable. Indisputably
determination of such a question at the hands of the assessing authority was required for arriving at
a finding of fact as to whether the Central Sales Tax or the local sales tax would become payable. The
States, where manufacturing of goods takes place in case involving such nature of transaction,
presumably would like to invoke the provisions of the Central Sales Tax as in terms of Article 270 of
the Constitution of India despite the fact that the Central Sales Tax is payable to the Central
Government, the amount is invariably passed on to the State concerned. On the other hand, the
purchaser when it is a public sector undertaking, would like to see that the purchase and sale takes
place within the State so as to entitle the concerned State to collect the local sales tax, a rate
therefore would normally be higher. There, thus, exists conflict in interest of the States particularly
having regard to the financial crunches faced by them.
42. Having regard to the Statement of Objects and Reasons of the Central Sales Tax Act vis-a-vis the
recommendations made by the Law Commission, as referred to hereinbefore, it would appear that
the Parliament with a view to bring in expediency in such a matter so that the dispute can be
determined as expeditiously as possible amended Section 6A. Section 6 of the Act provides for
liability to tax on inter-State sales in terms whereof every dealer is liable to pay tax thereunder on
sales effected by him in the course of inter-State trade or commerce subject to the exception
contained in the proviso appended thereto. Such tax would be leviable notwithstanding the fact that
no tax is leviable either on seller or the purchaser under the State tax laws of the appropriate State if
that sale had taken place inside the State.
43. The liability to tax on inter-State sale as contained in Section 6 is expressly made subject to the
other provisions contained in the Act. Sub- Section (2) of Section 9, on the other hand, which is a
procedural provision starts with the words "subject to the other provisions of this Act and the rulesAshok Leland Ltd vs State Of Tamil Nadu And Anr on 7 January, 2004

made thereunder". Section 6A provides for exception as regard the burden of proof in the event a
claim is made that transfer of goods had taken place otherwise than by way of sale. Indisputably, the
burden would be on the dealer to show that the movement of goods had occasioned not by reason of
any transaction involving sale of goods but by reason of transfer of such goods to any other place of
his business or to his agent or principal, as the case may be. For the purpose of discharge of such
burden of proof, the dealer is required to furnish to the assessing authority within the prescribed
time a declaration duly filled and signed by the principal officer of the other place of business or his
agent or principal. Such declaration would contain the prescribed particulars in the prescribed form
obtained from the prescribed authority. Along with such declaration, the dealer is required to
furnish the evidence of such dispatch of goods by reason of Act 20 of 2002. In the event, if it fails to
furnish such declaration, by reason of legal fiction, such movement of goods would be deemed for all
purposes of the said Act to have occasioned as a result of sale. Such declaration indisputably is to be
filed in Form F. The said form is to be filled in triplicate. The prescribed authority of the transferee
State supplies the said form. The original of the said form is to be filed with the transferor State and
the duplicate thereof is to be filed before the authorities of the transferee State whereas the
counterfoil is to be preserved by the person where the agent or principal of the place of business of
the company is situated.
44. When the dealer furnishes the original of Form F to its assessing authority, an enquiry is
required to be held. Such enquiry is held by the assessing authority himself. He may pass an order
on such declaration before the assessment or along with the assessment. Once an order in terms of
Sub-Section 2 of Section 6A of Central Act is passed, the transactions involved therein would go out
of the purview of the Central Act. In other words, in relation to such transactions, a finding is
arrived at that they are not subjected to the provisions of the Central Sales Tax. It is not in dispute
thereunder no appeal is provided there against.
45. In Chunni Lal Parshadi Lal v. Commissioner of Sales Tax. UP : [1986] 1SCR891 :
"23. It means that a sale of any of the goods specified in Sub-section (1) to a
registered dealer who has purchased them or to any unregistered dealer, shall for the
purpose of this section, be deemed to be a sale to the consumer unless the purchasing
dealer purchases the said goods for resale in the same condition. It merely
strengthens the provisions of Sub- section (2) of Section 3-AA i.e. unless the dealer
proves otherwise, every sale shall, for the purpose of Sub-section (1), be presumed to
be to a consumer. The combined effect of Sub-sections (1), (2) and (3), of Section
3-AA of the Act is that tax would be payable if the goods in question i.e. cotton yarn,
in this case, are sold to a dealer for consumption. Unless the dealer proves otherwise
every sale by a dealer shall for the purpose of Sub-section (1) be presumed to be a sale
to a consumer. A sale of any of the goods mentioned in Sub-section (1) to a registered
dealer who does not purchase them for resale in the same condition, without
processing or sale to unregistered dealer shall be deemed to be a sale to the
consumer. Therefore, a registered dealer has to prove that a sale to another registered
dealer or an unregistered dealer is not for consumption. In order to facilitate the
working of the Act, by Rule 12-A a method of proving has been provided that the saleAshok Leland Ltd vs State Of Tamil Nadu And Anr on 7 January, 2004

is not a sale to the consumer. The reading of the rule along with relevant provisions of
the Act leads to the conclusion that Rule 12-A method, -furnishing of certificate in the
form and with the particulars - is one of- the methods of proving that sale by a
registered dealer is not for consumption. Neither the rule nor the provision of the
section suggests that this is the only method. If a dealer can prove by any other way
than the way contemplated by Rule 12-A then he is not so precluded. For the rule to
say otherwise would be exceeding the provision of the section. The purpose for the
making of the rule would however, be frustrated if after the dealer proves in the
manner indicated in Rule 12-A he has to prove again how the purchasing dealer has
dealt with the goods after he obtains the certificate from a registered dealer. That
would make the working of the Act and Rule unworkable.
24. There is no dispute that in this case certificates as mentioned in Rule 12-A were
furnished.
25. The questions involved in this case are whether by furnishing certificate in Form
III-A and the details of such certificate given in Form IV, the selling dealer got
exemption and Rule 12-A created an irrebuttable presumption i.e. that no further
evidence is required in this matter to prove that the goods were sold to a dealer for
resale in the same condition and not to be consumed by the purchasing dealer."
46. By reason of Sub-Section (2) of Section 6A, a legal fiction has been created for the purpose of the
said Act to the effect that transaction has occasioned otherwise than as a result of sale.
47. On an analysis of the aforementioned provisions, therefore, the following propositions of law
emerge:
(i) The initial burden of proof is on the dealer to show that the movement has
occasioned by reason of transfer of such goods which is otherwise than by reason of
sale. The assessee may file a declaration. On a declaration so filed an inquiry is to be
made by the assessing authority for the purpose of passing an order on arriving at a
satisfaction that movement of goods has occasioned otherwise than as a result of sale.
(ii) Whenever such an order is passed, a legal fiction is created.
48. Legal fiction, as is well-known, must be given its full effect.
49. In the rules of evidence, there exist several presumptions. These presumptions may be
rebuttable or irrebuttable. Irrebuttable presumptions are referred to as conclusive presumptions as
they stand as conclusive proof of certain facts and are open to challenge only on very meagre
grounds. Under the Indian Evidence Act, Sections 41, 112 and 133 deal with conclusive
presumptions. Even in other enactments, like the Indian Companies Act, 1956, such provisions
exist.Ashok Leland Ltd vs State Of Tamil Nadu And Anr on 7 January, 2004

50. In the case at hand it is necessary to determine whether Section 6A of the Central Sales Tax Act
sets up a conclusive presumption.
"Presumptions may be looked upon as the bats of law, flitting in the twilight, but
disappearing in the sunshine of facts."
51. This metaphor used by Cochran, J. in Stumpf v. Mantgomery (1924) 101 OKL 256. pithily states
the law.
52. However, the rule of conclusive proof stands on a different footing. Once it is held, as we do, that
Section 6A of the Central Act provides for a conclusive proof, except on a limited ground, reopening
of assessment would not be permissible.
RULE OF CONCLUSIVE PRESUMPTION : SOME CASE LAWS:
53. In several cases validity of rules of conclusive presumptions have been upheld.
54. However, in Ashok Leyland (supra), it was held:
"Section 6A does not create a conclusive presumption and that an order accepting
Form F, whether passed during the assessment or at any point earlier thereto, is
ultimately a part and parcel of the order of assessment. Its amenity to power of
re-opening and revision depends upon the provisions of the concerned State sales tax
enactment by virtue of Section 9(2)."
55. We do not think that the aforesaid view is correct.
56. In Re Eric Holmes Ltd. (1965) 2 All ER 333, it was held, "that the giving of the certificate by the
Registrar is conclusive that the document creating the charge was properly registered, even if in fact
it was not properly registered."
57. A discussion may also ensue as to whether a conclusive presumption is one of substantive or of
procedural law. This was discussed in Izhar Ahmad Khan (supra) and was held to be part of the
latter and not the former as it found place in the Indian Evidence Act (among other reasons). The
decision runs as follows:
"It was not correct to say that Rule 3 of Schedule III of the Citizenship Rules, 1956,
which made it obligatory on the authority to infer the acquisition of foreign
citizenship from the fact of obtaining a passport from a foreign country was not a rule
of evidence but a rule of substantive law.
Like the rules of rebuttable presumption, which was undoubtedly a rule of evidence.
The function of an irrebuttable presumption was also to help the judicial mind in
appreciating the existence of facts with this difference that while the former was openAshok Leland Ltd vs State Of Tamil Nadu And Anr on 7 January, 2004

to rebuttal, the latter was placed beyond rebuttal. So considered a rule of irrebuttable
presumption could not be said to fall to fall outside the law of. evidence.
That such a rule might in some cases lead to hardship and injustice was not a relevant
consideration in judging its constitutional validity.
The real test whether a rule of irrebuttable presumption was one of evidence was
inherent relevancy. If the fact from the proof of which the presumption was required
to be drawn was inherently relevant in proving it, the rule was one of evidence, no
matter whether the presumption prescribed was rebuttable or irrebuttable.
The expression 'rules of evidence' in Section 9(2) must be construed in the light of its
legislative history. Ever since the passing of the Evidence Act a conclusive
presumption has been a part of the law of evidence. It is well settled that the scope of
power to legislate on a topic had to be determined by the denotation of that topic
obtaining in legislative practice."
58. However, in the minority opinion it was observed, "A rule of conclusive presumption made with
a view to affect specified substantive right was a rule of substantive law and did not cease to be so
because it rested on a fact which was relevant to it. The test was not one of relevancy but whether it
was intended to affect a specified substantive right or provide a method of proof."
59. The said principle has been reiterated by this Court in M. Venugopal v. Divisional Manager, Life
Insurance Corporation of India, Machilipatnam, A.P. and Another : (1994)ILLJ597SC stating:
"In the case at hand, a statutory authority that had jurisdiction to pass such an order
has passed the order. In addition there is no provision for appeal, which goes to show
that this is part of the substantive law and not procedural law. This order is
conclusive for all purposes, as the above two stated elements clearly go out to show.
No appeal has been provided for depicting the will of the legislature to make the
order of such authority final."
60. In The Municipal Board, Hapur v. Raghuvendra Kripal and Ors. : [1966] 1SCR650 this Court
stated:
"...The provision making the notification conclusive evidence of the proper
imposition of the tax is conceived in the best interest of compliance of the provisions
of the Boards and not to facilitate their breach. It cannot, therefore, be said that there
is excessive delegation."
61. In State of Madras v. Radio and Electricals Ltd. : AIR1967SC234 , it has been held that
satisfaction once reached in absence of any provision, review of such an order is not permissible.
62. In Balabhagas Hulaschand (supra) : [1976]2SCR939 , this Court has given an example.Ashok Leland Ltd vs State Of Tamil Nadu And Anr on 7 January, 2004

"Case No. II - A who is a dealer in State X agrees to sell goods to B but he books the
goods from State X to State Y in his own name, and his agent in State Y receives the
goods on behalf of A, Thereafter the goods are delivered to B in State Y and if B
accepts them a sale takes place. It will be seen that in this case the movement of
goods is neither in pursuance of the agreement to sell nor is the movement
occasioned by the sale. The seller himself takes the goods to State Y and sells the
goods there. This is, therefore, purely an internal sale which takes place in State Y
and falls beyond the purview of Section 3(a) of the Central Sales Tax Act not being an
inter-State sale.
63. In C.P.K. Trading Co. v. Additional Sales Tax officer, III Circle Mattancherry , the law is stated in
the following terms:
"...A plain reading of Section 6A(2) of the Central Sales Tax Act points out that in
cases where the dealer exercises the option of furnishing the declaration (F forms),
the only further requirement is that the assessing authority should be satisfied, after
making such enquiry, as he may deem necessary, that the particulars contained in the
declaration furnished by the dealer are "true". The scope or frontiers of enquiry, by
the assessing authority under Section 6A(2) of the Central Sales Tax Act is limited to
this extent, namely, to verify whether the particulars contained in the declaration (F
forms) furnished by the dealer are "true". It means, the assessing authority can
conduct an enquiry to find out whether the particulars in the declaration furnished
are correct, or dependable, or in accord with facts or accurate or genuine. That alone
is the scope of the enquiry contemplated by Section 6A(2) of the Act. On the
conclusion of such an enquiry, he should record a definite finding, one way or the
other. As to what should be the nature of the enquiry, that can be conducted by the
assessing authority under Section 6A(2) of the Act, is certainly for him to decide. It is
his duty to verify and satisfy himself that the particulars contained in the declaration
furnished by the dealer are "true". As a quasi-judicial authority, the assessing
authority should act fairly, and reasonably in the matter. During the course of the
enquiry, under Section 6A(2) of the Act, it is open to him to require the dealer to
produce relevant documents or other papers or materials which are germane or
relevant, to find whether the particulars contained in the declaration (F forms) are
"true". It is not possible to specify the documents or other materials or papers that
may be required, to be furnished in all situations and in all cases. It depends upon the
facts and circumstances of each case.
The power vested in the officer is a wide discretionary power, to find, whether the particulars
contained in the declaration (F forms) are "true". It is not possible or practicable to lay down the
exact documents or materials that may be required in all the cases, by the assessing authority, to
come to a proper and just finding as required by Section 6A(2) of the Act."
64. Thus from the above, we can conclude that the order of an authority under Section 6A is
conclusive for all practical purposes.Ashok Leland Ltd vs State Of Tamil Nadu And Anr on 7 January, 2004

LEGAL FICTION :
65. The question that arises is whether a legal fiction can be applied to determine whether a
particular interstate transaction amounted to an interstate sale or a mere transfer of stock. Legal
fictions have been applied in a number of cases.
66. In Gannon Dunkerley and Co. v. State of Rajasthan, : (1993)1SCC364 , it was held that, "Sections
3, 4, and 5 (of the Central Sales Tax Act) were applicable to such contracts containing two separate
agreements, these provisions would apply to a contract which, though single and indivisible, by legal
fiction introduced by the 46th Amendment has been altered into a contract which is divisible into
one for sale of goods and other for labour and services. Such a deemed sale has all the incidents of a
sale of goods involved in the execution of a works contract where the contract is divisible into one
for sale of goods and the other for supply of labour and services. Sections 14 and 15 of the Central
Sales Tax Act would also be applicable to the deemed sales resulting from transfer of property in
goods involved in the execution of a works contract. The absence of any amendment in the
definition of sale contained in Section 2(g) of the Central Sales Tax Act, 1956 so as to include
transfer of property in goods involved in execution of a works contract, therefore, does not in any
way affect the applicability of Sections 3, 4, and 5 and Sections 14 and 15 of the Central Sales Tax to
such transfers.
67. In State of Bombay v. Pandurang : 1953CriLJ1049 it was held, "When a statute enacts that
something shall be deemed to have been done, which in fact and truth was not done, the court is
entitled and bound to ascertain for what purposes and between what persons the statutory fiction is
to be resorted to and full effect must be given to the statutory fiction and it should be carried, to its
logical conclusion. "
68. A legal fiction can be utilised in several ways wherein the word 'deemed' is used. However, the
mere use of the word 'deemed' is not in itself sufficient to set up a legal fiction as was held in
Consolidated Coffee Ltd. v. Coffee Board, : (1995)1SCC312 , stating that, "the word 'deemed' is used
a great deal in modern legislation in different senses and it is not that a deeming provision is every
time made for the purposes of creating a fiction. A deeming provision might be made to include
what is obvious or what is uncertain or to impose for the purpose of a statute an artificial
construction of a word of phrase that would not otherwise prevail, but in each case it would be a
question as to with what object the legislature has made such a deeming provision."
69. The Court went further to quote the position taken in St. Aubyn v. Attorney General (1951) 2 All
ER 473 wherein Lord Radcliffe observed thus, "The word 'deemed' is used a great deal in modern
legislation. Sometimes it is used to impose for the purposes of a statute an artificial construction of a
word or phrase that would not otherwise prevail. Sometimes it is used to put beyond doubt a
particular construction that might otherwise be uncertain. Sometimes it is used to give a
comprehensive description that includes what is obvious, what is uncertain and what is, in the
ordinary sense impossible."Ashok Leland Ltd vs State Of Tamil Nadu And Anr on 7 January, 2004

70. In Bhavnagar University v. Palitana Sugar Mill (P) Ltd. : AIR2003SC511 it was stated that the
purpose and object of creating a legal fiction in the statute is well known. But when a legal fiction is
created it must be given its full effect. It was held in East End Dwellings Co. Ltd. v. Finsbury
Borough Council (1951) 2 All ER 587:
"If you are bidden to treat an imaginary state of affairs as real, you must surely,
unless prohibited from doing so, also imagine as real the consequences and incidents
which, if the putative state of affairs had in fact existed, must inevitably have flowed
from or acco7mpanied it. One of these in this case is emancipation from the 1939
level of rents. The statute says that you must imagine a certain state of affairs; it does
not say that having done so, you must cause or permit your imagination to boggle
when it comes to the inevitable corollaries of that state of affairs. "
[See also ITW Signode India Ltd. v. Collector of Central Excise - :
2003ECR783(SC)
71. These decisions, therefore, show that whenever a legal fiction is created by a statute, the same
shall be given full effect.
INTERPRETATION OF SECTION 6A OF THE CENTRAL ACT :
72. A statute, as is well-known, must be interpreted having regard to the text and context thereof.
Mischief Rule may also be applied in a given case.
73. While construing a statute, the object of the Act must be taken into consideration. (See Killick
Nixon Ltd. v. Deputy Commissioner of Income Tax : [2002]258ITR627(SC)
74. Section 6A of the Act although provides for a burden of proof, the same has to be read in the
context of Section 6 of the said Act. Section 6 provides for liability to pay tax on inter-State sales.
Any transaction which does not fall within the definition of 'sale' would not be exigible to tax, the
burden whereof would evidently be on the assessee. We have noticed hereinbefore that whereas
prior to the amendment in Sub-section (1) of Section 6A the dealer had ah option of filing a
declaration in Form-F; after such amendment, he does not have such option, insofar as in terms of
the amended provision, if the dealer fails and/or neglects to file such a declaration, the transaction
would be deemed to be ah inter-State sale. It is to be noticed that for the aforementioned purpose
also, the Parliament advisedly used the expression 'deemed'. If the expression 'deemed' is
interpreted differently, an incongruity would ensue.
75. In absence of any indication that the Parliament while enacting Sub- section (2) of Section 6A
did not intend to make the deeming provisions to be a conclusive fact as regard occasion of the
transaction having taken place otherwise than as a result of sale, it would have dealt with the matter
differently.Ashok Leland Ltd vs State Of Tamil Nadu And Anr on 7 January, 2004

76. Section 6A(2) of the Act uses the following expressions which are important : (1) 'thereupon'; (2)
'for the purpose of this Act'; (3) 'the movement of goods to which the declaration related shall be
deemed for the purpose of this Act to have been occasioned otherwise than as a result of sale'.
77. Each of them must be given its proper meaning.
78. A statute for the purpose of its interpretation must be read in its entirety. It is to be given a
purposive construction. Applying Heydon's rule, it must be held that the amendment was
necessitated not only to make the dealer to file such a declaration imperatively but also to see that
such movement of goods becomes inter-State sale by raising a legal fiction, as 'having been
occasioned in course of a inter-State sale'. In other words, if such a declaration is filed and on an
inquiry made pursuant to or in furtherance of the particulars furnished are found to be correct by
the assessing authority, the result thereof which is evidenced by the expression 'thereupon' shall in
view of the legal fiction created would be a transaction otherwise than as a result of an inter-State
sale. Furthermore, once such a legal fiction is drawn, the same would continue to have its effect not
only while making an order of assessment in terms of the State Act but also for the purpose of
invoking the power of reopening of assessment contained in Section 9(2) of the Central Act as well
as Section 16 of the State Act.
[See Indian Handicrafts Emporium and Ors. v. Union of India and Ors. :
AIR2003SC3240 , Ameer Trading Corporation Ltd. v. Shapoorji Data Processing Ltd.
: AIR2004SC355 .
OUR ANALYSIS :
79. In the case at hand it has to be determined whether the sale in question is an interstate one. If
through the means of a legal fiction it is determined that this is not an interstate sale, then it
amounts to a transfer of stock. This finding is made by a statutory authority who has the jurisdiction
to do so and there is no provision for appeal. Therefore, the order made by such authority is
conclusive in that it cannot be reopened on the basis that there had been a mere error of judgment.
It also cannot be re-opened under another statute, for examples, the Sales Tax Act of the State
concerned, when the order had been made under the Central Act. Section 9(2) of the Act is subject
to the other provisions of the Act which would include Sub-section (2) of Section 6A of the Act.
"Subject to" is an expression whereby limitation is expressed. The order is conclusive for all
purposes. It can only be re-opened on a small set of grounds such as fraud, misrepresentation,
collusion etc.
80. It is also to be borne in mind that no presumption when movement of goods has taken place in
the course of inter-State sales may be raised in the case of standard goods but the same is not
conclusive. It is only one the factors which is required to be taken into consideration along with
others. In a case, however, where the purchaser places order on the manufacturer for manufacturing
goods which would be as per his specifications, a presumption that agreement to sell has been
entered into may be raised.Ashok Leland Ltd vs State Of Tamil Nadu And Anr on 7 January, 2004

81. The purport and object of Section 6A of this Act need not detain us for long as the same has been
considered at some details recently in 20th Century Finance Corporation Ltd. and Anr. v. State of
Maharashtra :
AIR2000SC2436 stating:
"While examining the power of State Legislatures under Entry 54 of List II in the
earlier part of this judgment, we have noticed that the situs of the sale or purchase is
wholly immaterial as regards the inter-State trade or commerce, as held in Bengal
Immunity Co. Ltd. case : [1955]2SCR603 . Further, the State Legislature cannot by
law, treat sales outside the State and sales in the course of import as "sales within the
State" by fixing the situs of sales within its State in the definition of sale, as it is
within the exclusive domain of the appropriate legislature, i.e., Parliament to fix the
location of sale by creating legal fiction or otherwise."
82. In Mahant Dharam Das (supra), it has been held that the object of the Act is to get rid of
protracted litigation. The same is also required to be borne in mind while interpreting the relevant
provisions of the Central and the State Acts.
83. There cannot be any doubt or dispute that while defining sale, the situs of sale can be fixed by
the Parliament which having regard to Article 286 is within its exclusive domain and in the context
of Article 269(3) having regard to the following factors:
(i) Place where agreement of sale is concluded;
(ii) Passing of property in the goods;
(iii) Where the parties to the contract reside; and
(iv) Goods are located or manufactured.
84. Once the situs of sale either by way of legal fiction or otherwise is determined, the State
Legislature will be denuded of its power to fix another situs having regard to the fact that the
Parliament alone has the exclusive jurisdiction therefore. A sale may have several elements and all
of them need not necessarily take place in one State and in that view of the matter a presumption
had to be provided for by a deeming provision as a logical corollary of the principles laid down by a
law of Parliament.
85. It has not been disputed before us that all the requisite particulars are to be stated in Form F.
Once a determination is made that such statements are correct, the curtain is drawn keeping in view
the expression "thereupon". The said word is of great significance and must be given its full effect.
86. In Words and Phrases, Permanent Edition, Volume 41A, 'thereupon' is defined as:Ashok Leland Ltd vs State Of Tamil Nadu And Anr on 7 January, 2004

"Thereupon" has at least two meanings and may mean either immediately or without
delay or lapse of time. It has been defined as meaning upon this or that and is used
for the purpose of referring to a cause or, condition precedent. It is also frequently
used to denote a following or consequence of preceding events and when considered
in statutory interpretation it is often construed to refer to a succession of events in
the order or sequence of their performance rather than as an adverb of time. State ex
rel. Warnick v. Wilson, 178 P. 2d 277, 282, 162 Kan. 507."
87. The expression "For the purpose of this Act", unless the context otherwise requires would mean
"all the purposes" thereof.
88. In H.L. Sud, Income Tax Officer, Companies Circle 1 (1), Bombay v. Tata Engineering and
Locomotive Co. Ltd. : [1969]71ITR457(SC) , this Court held:
"The expression "for all purposes", used in Section 43 only indicates that when an
appointment is made for a particular assessment year it is stood for all purposes as
far as that assessment is concerned i.e., for all purposes for imposing tax liability,
determining the quantum of the liability and for recovering it. The expression does
not extend the liability to any other assessment excepting the liability for the
assessment year for which the appointment is made. "
89. The expression "for the purpose of the said Act" must also be given effect to. The same would
ordinarily mean "for the purpose of all the provisions of the said Act".
90. In M.K. Kochu Devassy v. State of Kerala etc. : 1979CriLJ147 , it is stated:
13. We find ourselves wholly unable to accept any of the contentions. The terms of
Section 2 of the 1947 Act as substituted by Section 3 of the Kerala Act are absolutely
clear and unambiguous and when they lay down that the expression "public servant"
shall have a particular meaning for the purposes of the Act, that meaning must be
given to the expression wherever it occurs in the Act. "For the purposes of the Act"
surely means for the purposes of all and not only some of the provisions of the Act. If
the intention was to limit the applicability of the definition of the expression "public
servant" as contended, the language sed would not have been "for the purposes of the
Act" but something like "for the purposes of the Act insofar as they relate to the
offences under Sections 161 to 165 of the Indian Penal Code".
91. In Shrisht Dhawan (supra), the law is stated in the following terms:
"Thus a tenant cannot wait for the entire period of lease and then raise objection to
execution on fraud or collusion unless he is able to establish that it was not known to
him and he came to know of it, for the first time only at the time of execution. In
other words the Controller shall not be justified in entertaining an objection in
execution unless the tenant establishes, affirmatively, that he was not aware of fraudAshok Leland Ltd vs State Of Tamil Nadu And Anr on 7 January, 2004

before expiry of the period of lease. To the following extent, therefore, the law on
procedural aspect should be taken as settled.
(1) Any objection to the validity of sanction should be raised prior to, expiry of the
lease.
(2) The objection should be made immediately on becoming aware of fraud, collusion
etc. (3) A tenant may be permitted to raise objection after expiry of lease in
exceptional circumstances only.
(4) Burden to prove fraud or collusion is on the person alleging it."
92. It was further observed :
"...An action is mindless when it is thoughtless or without any care or caution. In law
it is passing of an order without any regard to the provision of law. If the section
requires the authority to pass an order on inquiry or on being satisfied of existence or
non-existence of a fact then the duty cast is higher and an order which is passed
without due regard to duty to investigate then the order may be mindless..."
93. Furthermore, the expression 'subject to' must be given effect to.
94. In Black's Law Dictionary, Fifth Edition at page 1278 the expression 'Subject to" has been
defined as under :
"Liable, subordinate, subservient, inferior, obedient to; governed or affected by;
provided that; provided, answerable for. Homan v. Employers Reinsurance
Corporation, 345 Mo. 650, 136 S.W. 2d 289, 302"
95. The word "Determination" must also be given its full effect to, which pre-supposes application of
mind and expression of the conclusion. It connotes the official determination and not a mere
opinion of finding.
96. In Law Lexicon by P. Ramanatha Aiyar, Second Edition, it is stated:
"Determination or order. The expression "determination" signifies an effective
expression of opinion which ends a controversy or a dispute by some authority to
whom it is submitted under a valid law for disposal. The expression "order" must
have also a similar meaning, except that it need not operate to end the dispute,
Determination or order must be judicial or quasi-judicial. Jaswant Sugar Mills v.
Lakshmi Chand, : (1963)ILLJ524SC . [Constitution of India Article 136]"
97. In Black's Law Dictionary, 6th Edition, it is stated:Ashok Leland Ltd vs State Of Tamil Nadu And Anr on 7 January, 2004

"A "determination" is a "final judgment" for purposes of appeal when the trial court
has completed its adjudication of the rights of the parties in the action. Thomas Van
Dyken Joint Venture v. Van Dyken, 90 Wis. 236, 279 N.W. 2d 459, 463"
98. It is not in dispute that the principles for determination as to what would cause a inter-state sale
or intra-state sale is to be laid down in terms of the provisions of a Parliamentary Act having regard
to the express provisions contained, in Clause (3) of Article 269 and Clause (3) of Article 286 of the
Constitution. What principles can be deduced by reason of such a legal fiction has been stated by
this Court in Consolidated Coffee Ltd. (supra) in the following terms:
"A 'principle' means a general guiding rule, and does not include specific directions,
which vary according to the subject-matter per Shearman, J., in M'Creagh v.
Frearson (1922 WN 37.
Similarly in WORDS AND PHRASES, Permanent Edition, Vol. 33-A at page 327 it is
explained that "principle means a general law or rule adopted or professed as a guide
to action. "In other words, as opposed to any specific direction governing any
particular or specific instance, transaction or situation a principle, would be a guiding
rule applicable generally to cases or class of cases. Looked at from this angle it will be
clear that Sub-section (3) of Section 5 formulates a principle inasmuch as it lays
down a general guiding rule applicable to all penultimate sales that satisfy the two
conditions specified therein and not any specific direction governing any particular or
specific transaction of a penultimate sale. In other words the content of the provision
shows that it lays down a principle."
99. It was opined :
"Two things become clear from this Statement; first, Mohd. Serajuddin decision :
AIR1975SC1564 is specifically referred to as necessitating the amendment and
secondly, penultimate sales made by small and medium scale manufacturers to an
export canalising agency or private export house to enable the latter to export those
goods in compliance with existing contracts or orders are regarded as inextricably
connected with the export of the goods and hence, earmarked for conferal of the
benefit of the exemption. But here again, 'existing contract' with whom is not
clarified. In other words, on this crucial point the Statement is silent and does not
throw light on whether the existing contract should be with a foreign buyer or will
include any agreement with a local party containing a covenant to export. Therefore,
the question will again depend upon proper construction and as we have said above,
in the matter of construction the two aspects as discussed earlier show that by
necessary implication 'the agreement' spoken of by Section 5(3) refers to the
agreement with a foreign buyer."
100. In terms of Clause (3) of Article 269, inter-state sale is contrasted from local sale.Ashok Leland Ltd vs State Of Tamil Nadu And Anr on 7 January, 2004

101. An order passed by the statutory authority who has jurisdiction therefore, the same would
amount to a part of substantive and not procedural law. In addition to this there is no provision for
appeal. Thus, it is only in the limited cases of fraud, mis-representation etc. that reassessment can
be directed and not if there had been a mere error of judgment.
102. If it is not an inter-State sale provided through a legal fiction, then it amounts to transfer of
stock and this is a finding which has been arrived at by a statutory authority where for there does
not exist any provision for appeal. Therefore, it cannot be reopened on the premise that there was a
mere error of judgment or change in opinion.
103. Once it is held that such determination of an issue having regard to legal fiction created in
terms of Sub-section (2) of Section 6A is conclusive, it must a fortiorari follow that the same is
binding.
104. The particulars required to be furnished in Form F clearly manifest that the proof required is as
to whether the goods were factually transferred to the assessee himself or his branch office or his
agent and not to any third party. Any other enquiry is beyond the realm of the assessing authority.
105. It is true that this Court in Ashok Leyland (supra) upon consideration of the matter holding
that no statutory conclusiveness had been attached by reason of a legal fiction in terms of
Sub-section (2) of Section 6A. This Court opined:
"After all Section 6A is also one of the provisions of this Act. There is no reason to
elevate it to a higher status than the rest of the provisions"
.
106. With utmost respect, therein the Court did not take into consideration that the provisions of
Section 6A having been provided by way of exclusionary clause subject to the satisfaction of the
conditions precedent contained therein, and, thus, the same stand at an elevated stage over charging
Section 6 of the Act. The assessing authority while passing an order is required to take into
consideration the jurisdictional fact. Once it is found, having been conferred with a plenary power to
determine its own jurisdiction, that he did not have any jurisdiction under the Act, the opinion of
the assessing authority attains finality. What would be a jurisdictional fact has been noticed by this
Court in Shrisht Dhawan (supra) in the following terms:
"19... A Jurisdictional fact is one on existence or non-existence of which depends
assumption or refusal to assume jurisdiction by a court, tribunal or an authority. In
Back's Legal Dictionary it is explained as a fact, which must exist before a court can
properly assume jurisdiction of a particular case. Mistake of fact in relation to
jurisdiction is an error of jurisdictional fact. No statutory authority or tribunal can
assume jurisdiction in respect of subject matter which the statute does not confer on
it and if by deciding erroneously the fact on which jurisdiction depends the court or
tribunal exercises the jurisdiction then the order is vitiated. Error of jurisdictionalAshok Leland Ltd vs State Of Tamil Nadu And Anr on 7 January, 2004

fact renders the order ultra vires and bad... "
107. In South India Corporation (P) Ltd. v. Secretary. Board of Revenue :
[1964]4SCR280 , this Court has held that special provisions shall prevail over the
general provisions.
108. It is further trite that an administrative authority or a quasi- judicial authority while
adjudicating upon a lis is obligated to pose and answer a right question so as to enable it to arrive at
a conclusion as to whether he has jurisdiction in the matter or not. By reason of a legal fiction which
becomes attracted in terms of determination made thereunder, the provisions of the Central Act
shall stand excluded..
109. In A.V. Fernandez v. the State of Kerala : [1957]1SCR837 , this Court observed:
"There is a broad distinction between the provisions contained in the statute in
regard to the exemptions of tax or refund or rebate of tax on the one hand and in
regard to the non-liability to tax or non-imposition of tax on the other. In the former
case, but for the provisions as regards the exemptions or refund or rebate of tax, the
sales or purchases would have to be included in the gross turnover of the dealer
because they are prima facie liable to tax and the only thing which the dealer is
entitled to in respect thereof is the deduction from the gross turnover in order to
arrive at the net turnover on which the tax can be imposed. In the latter case, the
sales or purchases are exempted from taxation altogether. The Legislature cannot
enact a law imposing or authorising the imposition of a tax thereupon and they are
not liable to any such imposition of tax. If they are thus not liable to tax, no tax can be
levied or imposed on them and they do not come within the purview of the Act at all.
The very fact of their non-liability to tax is sufficient to exclude them from the
calculation of the gross turnover as well as the net turnover on which sales tax can be
levied or imposed. "
110. In Sahney Steel (supra) whereupon reliance has placed by the assessing authority, a contention
was raised that the registered office and the branch office were separately registered as dealers
under the sales tax law and transaction effected by the branch office should not be identified with
transactions effected by the registered office, Pathak, J., as the learned Chief Justice-then was,
observed :
"..We are unable to agree. Even if, as in the present case, the buyer places an order
with the branch office and the branch office communicates the terms and
specifications of the orders to the registered office and the branch office itself is
concerned with the sales dispatching, billing and receiving of the sale price, the
conclusion must be that the order placed by the buyer is an order placed with the
Company and for the purpose of fulfilling that order the manufactured goods
commence their journey from the registered office within the State of AndhraAshok Leland Ltd vs State Of Tamil Nadu And Anr on 7 January, 2004

Pradesh to the branch office outside the State for delivery of the goods to the buyer..."
111. The Court in the facts of that case held that the movement from the head office to the branch
office was for the purpose of delivery to the branch office, thereafter to the buyer through the branch
office. The branch office merely acted as a conduit through which the goods passed on their way to
the buyer. It is, however, relevant to note that the Court noticed :
"...It would have been a different matter if the particular goods had been dispatched
by the registered office at Hyderabad to the branch office outside the State for sale in
the open market and without reference to any order placed by the buyer. In such a
case if the goods are purchased from the branch office, it is not a sale under which the
goods commenced their movement from Hyderabad. It is a sale where the goods
moved merely from the branch office to the buyer..."
112. The purpose of verification of the declaration made in Form F, therefore, is as to whether the
branch office acted merely as a conduit or the transaction took place independent to the agreement
to sell entered into by and between the buyer and the registered office or the office of the company
situated outside the State. The said decision therefore, does not run counter to our reading of the
said provision. Furthermore, the question which has been, raised before us had not been raised
therein.
113. We, therefore, are of the opinion that the observations made by this Court in Ashok leyland
(supra) to the effect that an order passed under Sub-Section (2) of Section 6A can be subject matter
of reopening of a proceeding under Section 16 of the State Act was not correct.
114. However, we may hasten to add that the same would not mean that even wherein such an order
has been obtained by commission of fraud, collusion, misrepresentation or suppression of material
facts or giving or furnishing false particulars, the order being vitiated in law would not come within
the purview of the aforementioned principle.
115. An order of assessment is albeit passed under the State Act. But once it is held that the
concerned State Act as also the Central Act is not applicable, as a consequence whereof sales tax
would be payable under another State Act, it is doubtful as to whether the power to reopen the
proceedings under the State Act or the Central Act would be attracted. There does not exist any
power in the statute to rectify a mistake. In that view of the matter, mere change in the opinion of
the assessing authority or to have a re-look at the matter would not confer any jurisdiction upon him
to get the proceedings reopened. Discovery of a new material although may be a ground but that
itself may not be a ground for reopening the proceedings unless and until it is found that by reason
of such discovery, a jurisdictional error has been committed. In other words, when an order passed
in terms of Sub-Section (2) of Section 6A is found to be illegal or void ab initio or otherwise
voidable, the assessing authority derives jurisdiction to direct reopening of the proceedings and not
otherwise.
116. In Shrisht Dhawan (supra) this Court has held:Ashok Leland Ltd vs State Of Tamil Nadu And Anr on 7 January, 2004

"20. Fraud and collusion vitiate even the most solemn proceedings in any civilised
system of jurisprudence. It is a concept descriptive of human conduct. Michael Levi
likes a fraudster to Milton's sorcerer, Compus who exulted in his ability to, 'wing me
into the easy-hearted man and trap him into snares'. It has been defined as an act of
trickery or deceit. In Webster's Third New International Dictionary fraud in equity
has been defined as an act or omission to act or concealment by which one person
obtains an advantage against conscience over another or which equity or public
policy forbids as being prejudicial to another. In Black's Legal Dictionary, fraud is
defined as an intentional perversion of truth for the purpose of inducing another in
reliance upon it to part with some valuable thing belonging to him or surrender a
legal right; a false representation of a matter of fact whether by words of by conduct,
by false or misleading allegations, or by concealment of that which should have been
disclosed, which deceives and is intended to deceive another so that he shall act upon
it to his legal injury. In Concise Oxford Dictionary, it has been defined as criminal
deception, use of false representation to gain unjust advantage; dishonest artifice or
trick. According to Halsbury's Laws of England, a representation is deemed to have
been false, and therefore a misrepresentation, if it was at the material date false in
substance and in fact. Section 17 of the Contract Act defines fraud as act committed
by a party to a contract with intent to deceive another. From dictionary meaning or
even otherwise fraud arises out of deliberate active role of representator about a fact
which he knows to be untrue yet he succeeds in misleading the represented by
making him believe it to be true. The representation to become fraudulent must be of
the fact with knowledge that it was false. In a leading English Case (Derry v. Peek
(1886-90) All ER 1) what constitutes fraud was described thus: (ARR ER p. 22 B-C):
Fraud is proved when it is shown that a false representation has been made
(i) knowingly, or (ii) without belief in its truth, or (iii) recklessly, careless whether it
be true or false."
117. This aspect of the matter has been considered recently by this Court in Roshan Deen v. Preeti
Lal : (2002)ILLJ465SC , Smt. Anita v. R. Rambilas : AIR2003AP32 , Ram Preeti Yadav v. U.P.
Board of High School and Intermediate Education and Ors. : AIR2003SC4268 and Ram Chandra
Singh v. Savitri Devi and Ors. : (2003)8SCC319
118. Suppression of a material document would also amount to a fraud on the Court. (See
Gowrishankar and Anr. v. Joshi Amba Shankar Family Trust and Ors. : [1996]2SCR949 and S.P.
Chengalvaraya Naidu (Dead) By.... .LRs. v. Jagannath (Dead) by Lrs. and Ors. : AIR1994SC853 .
119. There is no law that only because no appeal is provided the order would not attain finality. (See
Commissioner of Income Tax, Bombay v. Amritlal Bhogilal & Co. : [1958]34ITR130(SC)
RES-JUDICATA:Ashok Leland Ltd vs State Of Tamil Nadu And Anr on 7 January, 2004

120. The principle of res judicata is a procedural provision. A jurisdictional question if wrongly
decided would not attract the principle of res judicata. When an order is passed without jurisdiction,
the same becomes a nullity. When an order is a nullity, it cannot be supported by invoking the
procedural principles like, estoppel, waiver or res judicata. This question has since been considered
in Sri Ramnik Vallabhdas Madhvani and Ors. v. Taraben Pravinlal Madhvani : (2004)1SCC497
wherein this Court observed in the following terms :
"So far as the question of rate of interest is concerned, it may be noticed that the High
Court itself found that the rate of interest should have been determined at 6%. The
principles of res judicata which according to the High Court would operate in the
case, in our opinion, is not applicable. Principles of res-judicata is a procedural
provision. The same has no application where there is inherent lack of jurisdiction.
In Chief Justice of A.P. and Anr. v. L.V.A. Dikshitulu and Ors. etc. :
[1979]1SCR26 , the law is stated in the following terms:
"23. As against the above, Shri Vepa Sarathy appearing for the respective first
respondent in C.A. 2826 of 1977, and in C.A. 278 of 1978 submitted that when his
client filed a writ petition (No. 58908 of 1976) under Article 226 of the Constitution
in the High Court for impugning the order of his compulsory retirement passed by
the Chief Justice, he had served, in accordance with Rule 5 of the Andhra Pradesh
High Court (Original Side) Rule, notice on the Chief Justice and the Government
Pleader, and, in consequence, at the preliminary hearing of the writ petition before
the Division Bench, the Government, Pleader appeared on behalf of all the
respondents including the Chief Justice, and raised a preliminary objection that the
writ petition was not maintainable in view of Clause 6 of the Andhra Pradesh
Administrative Tribunal Order made by the President under Article 371D which had
taken away that jurisdiction of the High Court and vested the same in Administrative
Tribunal. This objection was accepted by the High Court, and as a result, the writ
petition was dismissed in limine.
In these circumstances - proceeds the argument - the appellant is now precluded on principles of res
judicata and estoppel from taking up the position, that the Tribunal's order is without jurisdiction.
But, when Shri Sarathi's attention was invited to the fact that no notice was actually served on the
Chief Justice and that the Government Pleader who had raised this objection, had not been
instructed by the Chief Justice or the High Court to put in appearance on their behalf, the counsel
did not pursue this contention further. Moreover, this is a pure question of law depending upon the
interpretation of Article 371D. If the argument. holds good, it will make the decision of the Tribunal
as having been given by an authority suffering from inherent lack of jurisdiction. Such a decision
cannot be sustained merely by the doctrine of res judicata or estoppel as urged in the case."
In Dwarka Prasad Agarwal (D) By LRs. and Anr. v. B.D. Agarwal and Ors. :Ashok Leland Ltd vs State Of Tamil Nadu And Anr on 7 January, 2004

AIR2003SC2686 , it is stated:
"It is now well-settled that an order passed by a court without jurisdiction is a nullity.
Any order passed or action taken pursuant thereto or in furtherance thereof would
also be nullities. In the instant case, as the High Court did not have any jurisdiction
to record the compromise for the reasons stated hereinbefore and in particular as no
writ was required to be issued having regard to the fact that public law remedy could
not have been resorted to, the impugned orders must be held to be illegal and without
jurisdiction and are liable to be set aside. All orders and actions taken pursuant to or
in furtherance thereof must also be declared wholly illegal and without jurisdiction
and consequently are liable to be set aside. They are declared as such. " "
121. In a case where an ordinance promulgated by the President of India which had been rendered
invalid by a judgment of the High Court, the question as to whether an enactment of the Parliament
would be barred was negatived in a recent decision of this Court in Dharam Dutt and Ors. v. Union
of India and Ors. : AIR2004SC1295 . Pointing out that the High Court did not consider the
constitutional questions in the right perspective, this Court observed:
"The doctrine of Separation of Powers and the constitutional convention of the three
organs of the State, having regard and respect for each other, is enough answer to the
plea raised on behalf of the petitioners founded on the doctrine of Separation of
Powers. We cannot strike down a legislation which we have on an independent
scrutiny held to be within the legislative competence of the enacting legislature
merely because the legislature has re-enacted the same legal provisions into an Act
which, ten years before, were incorporated in an ordinance and were found to be
unconstitutional in an erroneous judgment of the High Court and before the error
could be corrected in appeal the Ordinance itself lapsed."
CONCLUSION:
122. For the reasons stated hereinbefore, we are of the opinion that the Appellants would be entitled
to move the High Court for ventilating their grievances, However, if the Central Government creates
a new forum, it would be open to them to approach the same.
123. We may now consider the fact of the connected matters:
124. In W.P. (C) No. 195 of 1999 merely a show cause notice has been issued in relation to three
assessment years beginning from 1989-1990. This writ petition covers the period 1989-1990, to
1995-1996. In relation to period 1990-1991, 1991-1992 and 1992-1993 reopening proceedings had
been initiated. A fresh cause of action has arisen in relation to the other assessment years.
125. Having regard to the fact that the question as to whether the finding arrived at by the STAT
would attract the exceptions carved out hereinbefore mainly would revolve round the question as to
whether determination in terms of Sub-section (2) of Section 6A of the Act has been obtained byAshok Leland Ltd vs State Of Tamil Nadu And Anr on 7 January, 2004

playing fraud or suppression of record or not requires a detailed examination. Indisputably, the
appellant/ writ petitioner would be entitled to move the High Court in accordance with law.
CIVIL APPEAL @ SLP (C) No. 5579 of 2001
126. The appellant herein had filed his application praying inter alia for the following reliefs:
"(a) Grant Special Leave to Appeal against the final Judgment and Order dated
13.11.2000 passed in STA No. 459 of 1999 by the Tamil Nadu Sales Tax Appellate
Tribunal (Additional Bench). Chennai.
(b) Pass such other or further order or orders as this Hon'ble Court may deem fit and
proper in the facts and circumstances of the present case and in the interest of
justice."
127. In the said case, no order of reopening has been issued and as such it is not a case where we
were required to determine a forum in the light of the order passed in Ashok Leyland (supra).
128. The question as to whether the transaction in question constitute inter-state sale or intra-state
"sale has been decided upto Tribunal. They have approached this Court without availing the
statutory remedies provided for under the statutes. We, therefore, decline to exercise our discretion
and direct that the parties may avail the remedies under the statute.
129. In view of our aforementioned findings, the parties may approach the High Court. If necessary,
the other States wherein the local sales tax had been deposited, may be impleaded as parties so that
the lis may be determined in their presence. However, in the event, in the meanwhile any forum is
created by any Parliamentary Act in terms whereof the inter se disputes between the parties vis-a-vis
the claim of the assessee may be determined, they may approach the said forum.
CA No. 943 of 2001 :
130. The appellant herein manufactures explosives. It has its factory situated at Onnalwadi, Hosur,
Dharmapuri District. It is registered under the Central Sales Tax Act. It filed return for the
assessment year 1986-87 under the Central Sales Tax Act, 1956 claiming exemption in respect of a
sum of Rs. 34,30,302.73 representing transfer of goods to its branch at Dhanbad in the State of
Bihar and a sum of Rs. 13,91,547.18 relating to its branch at Nagpur in the State of Maharahstra. An
inspection held by the Enforcement Wing of the respondent; certain documents were recovered
from a perusal whereof it transpired that the goods were moved against the prior orders and as such
they are not entitled to exemption. The Department contended that it a Coal India Limited which
had placed orders for supply of explosives to its various subsidiary companies in North India and its
projects at Asansol, Dhanbad, Ranchi, Nagpur and Bilaspur at specified rates and in that view of the
matter the transactions constituted inter- State sales. According to the appellant, however, order
placed by M/s Coal India Limited is not an order intending to purchase but merely a standing offer.
The objection of the appellant was overruled upto the appellate authority. The matter went up to theAshok Leland Ltd vs State Of Tamil Nadu And Anr on 7 January, 2004

Tamil Nadu Sales Tax Tribunal, Coimbatore wherein it was held that the goods being
unascertainable ones must be held to be general and standard goods and tailor made to the special
requirements of any customers. It came to the conclusion that the transactions were only branch
transfers and were not liable to sales tax. It further held that the transactions having taken place
outside the State of Tamil Nadu and the transactions having been treated as local sales in other
States, the State of Tamil Nadu had no jurisdiction to impose tax in respect thereof. The Tribunal
also accepted the declaration made in terms of Section 6A. The State of Tamil Nadu being aggrieved
and dissatisfied therewith filed Tax Revision Case and by reason of the impugned judgment dated
2.12.1997 the judgment of the Tribunal was reversed. It, however, did not interfere with the order of
the Tribunal as regard penalty. Questioning the said order, the appeal has been filed before us.
Keeping in view the fact that although more than one State is involved, having regard to the facts
and circumstances of the case, it is necessary that the question may be examined afresh by the High
Court in the light of the decision of this Court. In the writ petition, it will be open to the parties to
implead the other States so that, if necessary, the matter may be heard out and disposed of in their
presence. However, in the event another forum is created by a Parliamentary Act, it will be open to
the parties to approach the said forum. These appeals and writ petitions are disposed of with the
aforementioned directions and observations. No costs.Ashok Leland Ltd vs State Of Tamil Nadu And Anr on 7 January, 2004

