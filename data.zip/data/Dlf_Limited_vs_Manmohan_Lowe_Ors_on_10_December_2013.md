Dlf Limited vs Manmohan Lowe & Ors on 10 December, 2013
Equivalent citations: 2014 AIR SCW 1857, 2014 (12) SCC 231, AIR 2014 SC
(SUPP) 1810, (2014) 138 ALLINDCAS 9 (SC), (2014) 1 RECCIVR 387, (2013) 14
SCALE 738, AIR 2014 SC (CIVIL) 1128, 2014 (105) ALR SOC 35 (SC)
Author: K.S. Radhakrishnan
Bench: A.K. Sikri, K.S. Radhakrishnan
                                                                             REPORTABLE
                        IN THE SUPREME COURT OF INDIA
                        CIVIL APPELLATE JURISDICTION
                       CIVIL APPEAL NO. 10930 OF 2013
             (@ Special Leave Petition (Civil) No.34275 of 2009)
      DLF Limited                                  ….. Appellant
                                   Versus
      Manmohan Lowe and others                       …..Respondents
                                    WITH
        Contempt Petition (Civil) No.         of 2013 (D.No.29500/12)
                                     IN
                       CIVIL APPEAL NO. 10930 OF 2013
             (@ Special Leave Petition (Civil) No.34275 of 2009)
      DLF Limited                                  ….. Petitioner
                                   Versus
      B. Jaishankar & Ors.                           …..RespondentsDlf Limited vs Manmohan Lowe & Ors on 10 December, 2013

                               J U D G M E N T
K.S. Radhakrishnan, J.
Leave granted.
2. This appeal arises out of a writ petition filed by the Apartment owners of Silver Oaks Apartments,
DLF Qutub Enclave, Phase-1, Gurgaon, seeking a writ of certiorari to quash the declaration dated
19.04.2001 filed by the Appellant, on the ground that the same is not in conformity with Section 3(f)
of the Haryana Apartment Ownership Act, 1983 (for short “the Apartment Act”) since the appellant
failed to include certain areas of the complex as “common areas and facilities” within the
declaration, thereby effectively depriving the apartment owners of their rights over the same.
3. The Division Bench of the Punjab and Haryana High Court accepted their contention and held
that the apartment owners are entitled to undivided interest in common areas and common facilities
under Section 6 of the Apartment Act and would be vitally affected if those areas are not declared as
common areas. The Court also held, inter alia, that the competent authority under Section 3(i) of the
Apartment Act is under an obligation to decide the objections of the apartment owners to the
declaration filed by the colonizer–appellant herein. Aggrieved by the same, this appeal has been
preferred by the colonizer.
4. The colonizer purchased large extent of lands in villages Chakarpur, Sarhaul, Shahpur, Nathupur
and Sikanderpur Ghosi, Tehsil and District Gurgaon, Haryana, with a view to develop a residential
colony to be known as DLF Qutab Enclave Complex. Any intending company or association having
land for converting it in the colony, was required to apply for licence under the Haryana
Development and Regulation of Urban Areas Act, 1975 (for short ‘the Development Act’). The
colonizer submitted an application in accordance with Section 3 of the Development Act for
necessary licences. During the years 1980- 81 seven licences were obtained by the Colonizer in
relation to 130.62 acres. Licences were granted by the Director, Town and Country Planning,
Haryana (DTCP) in accordance with the provisions of the Development Act. The Department of
Town and Country Planning, Haryana (the Department) in the year 1982 approved the group
complex, Silver Oaks, as part of the colony being developed by the Colonizer. Licences were initially
granted for two years, and later got periodically renewed. On 30.05.1990 a condition was imposed
by the Competent Authority that the Colonizer should provide Economically Weaker Sections
Complex (EWS) and service units to the extent of 10% of main dwelling units. Consequently, revised
plan was submitted, which was approved by the Competent Authority on 08.11.1990 in which
residential blocks comprising parking in basement, EWS Flats and three shops were approved.
There was further revision for zoning and building plan in the years 1992 and 1995.
5. The Department, in the meantime, circulated norms for provision of community facilities vide
DTCP Endst No.20028 dated 24.11.1988. During the year 1990, agreements were entered into
between the Colonizer and the Apartment Owners of the above-mentioned complex. Apartment
buyers agreement provided for sale of a quantified ‘super area’ against the sale considerationDlf Limited vs Manmohan Lowe & Ors on 10 December, 2013

specified in the agreement. The ‘super area’ comprises of an exclusive right to use the common area
within the building in which the apartment was situated. Agreement also states that the colonizer
will transfer and convey its right, title and interest in the said site, common area and common
facilities in favour of the co-operative society or limited company or association of persons, etc. in
accordance with the provisions of the Apartment Act and the Rules framed thereunder.
6. The Colonizer later applied for completion certificate on 15.04.1996 for group housing scheme
measuring 14.75 acres. The Apartment Act, though was enforced by notification dated 08.09.1986,
issued by the Haryana Department, the same was rescinded on 24.10.1997 as the concerned
department which notified the Act was the Town Planning Department. Consequently, a fresh
notification dated 10.11.1997 was issued by the Department notifying the applicability of the Act in
the entire State of Haryana. Later several sale deeds were executed by the Colonizer in favour of the
apartment owners in the year 1997, wherein both had agreed that they would conform to the
provisions of the Apartment Act. Writ Petition No.960 of 2000 was filed by respondents 1 to 5,
before the Punjab & Haryana High Court, seeking a direction to the Colonizer to file a deed of
declaration in relation to the Complex under the Apartment Act.
7. The Department later gave a partial completion certificate to the Colonizer on 22.01.2001, subject
to the condition of filing a deed of declaration under the Apartment Act within 90 days. Later the
Department on 14.03.2001 revised the earlier partial completion certificate for the complex, inter
alia, requiring the Colonizer to file a deed of declaration within a period of 90 days. It was also
provided that the responsibility of the ownership of common areas and common facilities as well as
their management and maintenance should continue to vest with the Colonizer till such time the
responsibility was transferred to the statutory condominium association under the Apartment Act.
The Colonizer accordingly on 19.04.2001 filed the “deed of declaration” along with bye-laws of the
statutory condominium association (Silver Oaks Condominium Association for short ‘the SOCA’) as
required under Section 11(2) of the Apartment Act. The Colonizer on 20.04.2001 issued a letter to
the SOCA stating that all the dwelling units, areas, with the common areas and facilities along with
other assets, plant and machinery and equipments, as declared in the declaration stands transferred
to the SOCA for the maintenance. The Colonizer on 23.04.2001 also wrote a letter to the SOCA
requesting them to take over the responsibility of maintaining common areas and facilities along
with other assets, plant and machinery and equipments etc.
8. The SOCA on 27.04.2001 passed a resolution that it would take over the responsibility of
managing of common areas and facilities along with other assets, plants and machinery and other
equipments, as transferred to the Association by the Colonizer. The same was confirmed by the
Association by sending a letter on 03.05.2001 to the Colonizer.
9. Writ Petition No.960 of 2000, filed by respondents 1 to 5 was later amended, challenging the
declaration filed by the Colonizer, stating that the same was not in conformity with the mandate of
the Apartment Act, and that the common areas and facilities should also include shops or parking
areas, community centers, nursery school and other common facilities. Amendment sought was
allowed by the High Court on 26.11.2001. Before the High Court Silver Oak Society also got
themselves impleaded as party. The High Court also impleaded the statutory SOCA as a partyDlf Limited vs Manmohan Lowe & Ors on 10 December, 2013

respondent to the writ petition. The High Court also sought a clarification from the Department with
regard to the meaning of expression “common areas and facilities”. The Department clarified that
the “common areas and common facilities” need to be defined categorically in the declaration to be
filed under Section 2 of the Apartment Act which may or may not include community buildings,
shops etc.
10. The Division Bench of the High Court after hearing all the parties took the view that the question
whether primary schools, shops or community center are common areas or any other objection of
the flat owners could be decided by the Competent Authority, having regard to the provisions,
objects and spirit of the Act. Further, the Court also took the view that it is not the intention of the
Legislature that the developer/Colonizer assumes absolute power of declaring or not declaring
areas, normally in common use, to be common areas. The Court also held that Section 11, which
deals with the contents of the declaration, cannot be read as giving absolute power to the
Colonizer/developer to exclude common areas from the said concept. The Court also held that the
apartment owners are entitled to object to the contents of the declaration and it is for the Competent
Authority to decide cross-objections. The Court after holding so, disposed of the writ petition with a
direction to the Competent Authority to take a decision on the various objections raised by the
apartment owners and the association. The legality of which is the question that arises for
consideration in this appeal.
11. Shri Mukul Rohatgi, learned senior counsel appearing for the Colonizer, submitted that the High
Court has completely misunderstood the scope of various provisions of the Development Act and the
Rules framed thereunder as well as the Apartment Act, and the Rules framed thereunder. Learned
senior counsel submitted that the judgment of the High Court has the effect of rendering the
provisions of the Development Act, particularly, Section 3(3)(a)(iv) otiose in as much as it compels
the Colonizer to divest its ownership rights in relation to community and commercial facilities
developed by it in terms of the provision of the Development Act. Learned senior counsel also
submitted that the direction of the High Court that the declaration must categorise the whole
property into “apartment, common areas and facilities” and “limited common areas and facilities” is
contrary to Section 3(f) of the Apartment Act, which itself, according to the learned senior counsel,
does not compel the Colonizer to divest its ownership rights in community and common facilities
developed by it as part of the obligation under the Development Act. Learned senior counsel also
submitted that the High Court has failed to appreciate that the community and commercial
facilities, in SOCA, were provided as part of the Colonizer’s over all obligations under Section
3(3)(a)(iv) of the Development Act for the colony as a whole and the same cannot be considered
separate only on account of being located at a specific site in the colony i.e. inside the Silver Oaks
Complex. Learned senior counsel placed considerable reliance on the Judgment of this Court in DLF
Qutub Enclave Complex Educational Charitable Trust v. State of Haryana and others (2003) 5 SCC
622 and submitted that community facilities and amenities are not part of the “development work”
under the Development Act.
12. Shri Vikas Singh, learned senior counsel appearing for the applicants in IA No.4 of 2013,
supported the Colonizer’s contentions and also submitted that the High Court has not properly
appreciated the scope of Section 3(f) of the Apartment Act. Learned senior counsel pointed out thatDlf Limited vs Manmohan Lowe & Ors on 10 December, 2013

the expression “unless the context requires in the declaration” or “lawful amendments thereto”
which finds a place in Section 3(f) of the Act has been completely overlooked by the High Court.
Learned senior counsel also submitted that the Colonizer is not under an obligation either under the
conditions of licence under the Development Act or under the provisions of the Apartment Act to
declare certain areas to be common areas and facilities.
13. Mr. Narender Hooda, learned Additional Advocate General, Haryana, appearing for the State of
Haryana, submitted that the internal community facilities are required to be provided by the
colonizer in terms of Section 3(3)(a)(iv) of the Development Act, at his own cost and the expenditure
incurred cannot be passed on to the apartment owners and colonizer continues to be the exclusive
owner of such community facilities and is free to incorporate or not, any or all such internal
community facilities in the declaration required to be filed in terms of the Apartment Act. Learned
AAG also submitted that in the instant case Silver Oaks is a part of a large colony of 130 acres and
the same cannot be treated as an independent colony but only a portion of large colony of 130 acres.
Further it is pointed out that all community facilities provided in the colony of 130 acres of which
Silver Oaks is only one part is meant for the use and enjoyment of all the residents of the colony.
14. Shri T.R. Andhiyarujina, learned senior counsel appearing for the applicants in IA No.3 of 2010
submitted that the High Court is right in holding that the intention of the legislature is that the
Colonizer cannot be conferred with an absolute power to declare or not to declare areas normally in
common use, to be common areas. Learned senior counsel submitted that apartment owners are
always entitled to object to the contents of the declaration if the contents are not in conformity with
the statutory provisions and spirit of the Apartment Act. Learned senior counsel submitted that the
High Court has only directed the Competent Authority to examine the objections raised by the
apartment owners and it is for the Competent Authority to decide as to whether the declaration is in
conformity with the Apartment Act and the Rules and Regulations framed thereunder.
15. Mrs. Madhu Tewatia, learned counsel appearing for the SOCA, took us extensively to the
provisions of the Apartment Ownership Act and the Rules framed thereunder and submitted that
the group housing complexes are totally independent and distinct entity in terms of sanctions,
applicability of development, control, norms etc. vis-à-vis plotted colonies. Learned counsel also
submitted that the internal development work shall include common facilities in the building
complex, for example, common sewerage, water supply, common staircases, corridors, ramps, lifts,
chutes etc. and the community buildings are in addition to the provisions of development work
mentioned in Rule 5 of Development Rules, 1976. Referring to the licence agreement under the
Development Act, learned counsel pointed out that the common areas and facilities do not vest or
belong to the builder and the responsibility of ownership or common areas and facilities, as well as
their management, shall continue to vest with the Colonizer only till the responsibility is transferred
to the owners of the dwelling units under the Apartment Act.
16. Learned counsel also submitted that the development charges and construction work in the
colony are paid for by the apartment owners. Learned counsel also referred to the Judgment of this
Court in Naharchand Laloochand Private Limited v. Panchali Co-operative Housing Socities Limited
(2010) 9 SCC 536, and submitted that this Court, while interpreting para-materia definition ofDlf Limited vs Manmohan Lowe & Ors on 10 December, 2013

common areas and facilities held that parking area, common area and facilities and that even the
factum of not having taken money from the apartment owners could not change the character and
nature of common area even though the builder may not have charged. Learned counsel also
submitted that Judgment in DLF Qutub Enclave (supra) can be distinguished on facts and law and
is not applicable to the case on hand since in the instant case, learned counsel submits, this Court is
concerned with the group housing multi-storied society unlike plotted colonies.
17. Shri Santosh Paul, learned counsel appearing for the applicants in IA No.5 of 2013, submitted
that the Colonizer/Developer in the State of Haryana have with impunity violated the provisions of
the Apartment Act. Learned counsel submitted that under Section 6 of the Act each apartment
owner is entitled to an undivided interest in common areas and facilities and that percentage of
undivided interest of common areas and facilities shall be deemed to be conveyed or encumbered
with the apartment even though such interest is not expressly mentioned in the conveyance or
instrument. Learned counsel also made reference to the licence format LC-7 and other relevant
provisions of the Development Act as well as the Apartment Act and submitted that the
Developer/Colonizer having connivance with the authorities taken shelter under Section 3(1) to
sustain for profiteering. Learned counsel, therefore, submitted that there is no reason to upset the
findings recorded by the High Court which are in tune with the over all public interest so that the
rights of the vulnerable sections of the society would be safeguarded from the colonizers.
18. We find that the issue involved in this case is of considerable importance in the real estate sector,
especially in the urban areas, while developing a Scheme in connection with the plot development or
group housing, hence, it is necessary to examine the various legal issues which arise for
consideration in this appeal. The primary question that has come up for consideration is with regard
to the rights of the apartment owners, vis-à-vis the colonizers over “community and commercial
facilities” referred to in Section 3(f)(7) of the Apartment Act.
19. Apartments owners, as already stated, maintained the stand that “community and commercial
facilities”, like providing community centre, schools, shops etc., would fall within the statutory
definition of “common areas and facilities” under Section 3(f) of the Apartment Act. The colonizers
maintained the stand that it can be so only if the colonizer has provided so in the statutory
declaration filed by it under Section 3(f) of the Apartment Act.
20. We are, in this case, concerned with the rights and obligations which flow to a colonizer,
vis-à-vis, the apartment owners on the basis of the Development Act as well as the Apartment Act.
Let us first examine the relevant provisions of the Development Act.
The Development Act:
21. Section 2(c) of the Development Act defines the term “colony”, which reads as follows:
“2(c) “colony” means an area of land divided or proposed to be divided into plots or
flats for residential, commercial, industrial, cyber city or cyber park purposes or for
the construction of flats in the form of group housing or for the construction ofDlf Limited vs Manmohan Lowe & Ors on 10 December, 2013

integrated commercial complexes, but an area of land divided or proposed to be
divided-
i) for the purpose of agriculture; or
(ii) as a result of family partition, inheritance, succession or partition of joint holding
not with the motive or earning profit; or
ii) in furtherance of any scheme sanction under any other law;
or
iii) by the owner of a factory for setting up a housing colony for the labour or the employees working
in the factory; provided there is no profit motive; or
iv) when it does not exceed one thousand square metres or such less area as may be decided from
time to time in an urban area by Government for the purposes of this sub-clause, shall not be a
colony.” The expression “colonizer” is defined under Section 2(d) which reads as follows :-
“2(d). "colonizer" means an individual, company or association or body of
individuals, whether incorporated or not, owning land for converting it into a colony
and to whom a licence has been granted under this Act.” The expression
“development works” is defined under Section 2(e) of the Act to mean as “internal
and external development works”. Section 2(g) defines the expression “external
development works” and reads as follows:
“2(g). “External development works” include water supply, sewerage, drains,
necessary provisions of treatment and disposal of sewage, sullage and storm water,
roads, electrical works, solid waste management and disposal, slaughter houses,
colleges, hospitals, stadium/sports complex, fire stations, grid sub- stations etc. and
any other work which the Director may specify to be executed in the periphery of or
outside colony/area for the benefit of the colony/area.” The word “flat” is defined
under Section 2(gg) of the Act, which reads as follows:
“2(gg). “Flat” means a part of any property, intended to be used for residential
purposes, including one or more rooms with enclosed spaces located on one or more
floors, with direct exit to a public street or road or to a common area leading to such
streets or roads and includes any garage or room whether or not adjacent to the
building in which such flat is located provided by the colonizer/owner of such
property for use by the owner of such flat for parking any vehicle or for residence of
any person employed in such flat, as the case may be.” The expression “group
housing” is defined under Section 2(hh) of the Development Act, which reads as
follows:Dlf Limited vs Manmohan Lowe & Ors on 10 December, 2013

“2(hh). “Group housing” means a building designed and developed in the form of
flats for residential purpose or any ancillary or appurtenant building including
community facilities, public amenities and public utility as may be prescribed.”
Section 2(hhh) defines the expression “integrated commercial complex”, which reads
as follows :-
“2(hhh). “integrated commercial complex” means building containing apartments
sharing common services and facilities and having their undivided share in the land
and meant to be used for office or for practicing of any profession or for carrying on
any occupation, trade, business or such other type of independent use, as may be
prescribed.” The expression “internal development works” is defined under Section
2(i), which reads as follows:
“2(i). “Internal development works” mean –
i) metalling of roads and paving of footpaths;
ii) turfing and plantation with trees of open spaces;
iii) street lighting;
iv) adequate and wholesome water-supply;
v) sewers and drains both from storm and sullage water and necessary provision for
their treatment and disposal; and
vi) any other work that the Director may think necessary in the interest of proper
development of a colony.” Section 3 of the Development Act deals with application
for licence, which reads as follows :-
“3. Application for licence.- (1) Any owner desiring to convert his land into a colony
shall, unless exempted under section 9, make an application to the Director, for the
grant of licence to develop a colony in the prescribed form and pay for it such fee and
conversion charges as may be prescribed. The application shall be accompanied by an
income-tax clearance certificate;
Provided that if the conversion charges have already been paid under the provisions
of the Punjab Scheduled Roads and Controlled Area Restriction of Unregulated
Development Act, 1963 (41 of 1963), no such charges shall be payable under this
section.
(2) On receipt of the application under sub section (1), the Director shall, among
other things, enquire into the following matters, namely:-Dlf Limited vs Manmohan Lowe & Ors on 10 December, 2013

(a) title to the land;
(b) extent and situation of the land;
(c) capacity to develop a colony;
(d) the layout of a colony;
(e) plan regarding the development schemes of the colony land to those of the
neighbouring areas.
(f) conformity of the development schemes of the colony land to those of the
neighbouring areas.
(3) After the enquiry under sub-section (2), the Director, by an order in writing, shall
–
(a) grant a licence in the prescribed form, after the applicant has furnished to the
Director a bank guarantee equal to twenty five per centum of the estimated cost of
development works in case of area of land divided or proposed to be divided into
plots or flats for residential, commercial or industrial purposes and a bank guarantee
equal to thirty-seven and a half per centum of the estimated cost of development
works in case of cyber city or cyber park purposes as certified by the director and has
undertaken-
(i) to enter into an agreement in the prescribed form for carrying out and completion
of development works in accordance with licence granted;
(ii) to pay proportionate development charges if the external development works as
defined in clause (g) of section 2 are to be carried out by the Government or any other
local authority. The proportion in which and the time within which, such payment is
to be made, shall be determined by the Director;
(iii) the responsibility for the maintenance and upkeep of all roads, open spaces,
public park and public health services for a period  of five years from the date of issue
of the completion certificate unless earlier relieved of this responsibility and
thereupon to transfer all such roads, open spaces, public parks and public health
services free of cost to the Government or the local authority, as the case may be;
(iv) to construct at his own cost, or get constructed by any other institution or
individual at its cost, schools, hospitals, community centers and other community
buildings on the lands set apart for this purpose, or to transfer to the Government at
any time, if so desired by the Government, free of cost the land set apart for schools,
hospitals, community centers and community buildings, in which case theDlf Limited vs Manmohan Lowe & Ors on 10 December, 2013

Government shall be at liberty to transfer such land to any person or institutions
including a local authority on such terms and conditions as it may deem fit;
v) to permit the Director or any other officer authorized by him to inspect the
execution of the layout and the development works in the colony and to carry out all
directions issued by him for ensuring due compliance of the execution of the layout
and development works in accordance with the licence granted;
Provided that the Director, having regard to the amenities which exist or are proposed to be
provided in the locality, is of the opinion that it is not necessary or possible to provide one or more
such amenities, may exempt the licensee from providing such amenities either wholly or in part;
(vi) to fulfill such terms and conditions as may be specified by the director at the time of grant of
license through bilateral agreement as may be prescribed.
(b) refuse to grant a licence, by means of a speaking order, after affording the applicant an
opportunity of being heard.
4. the license so granted shall be valid for a period of two years, and will be renewable from time to
time for a period of  one year, on payment of prescribed fee:
Provided that in the licensed colony permitted as a special project by the
Government, the license shall be valid for a maximum period of five years and shall
be renewable for a period as decided by the Government.”
22. The colonizer, in the instant case, has entered into an agreement LC-IVA under
Rule 11 of the Development Rules, 1976, whereby the colonizer has agreed to comply
with the execution of internal development works, external development works and
to construct at his own cost, community centers, community buildings, schools,
hospitals etc. in the areas earmarked for the same in the layout plan of the colony.
Internal development works are to be executed by the colonizer between boundaries
of the licensed colony and the cost of the internal development works, to be recovered
from the plot holders/apartment owners in the colony. External development works
are works required to be executed at the periphery of the colony or outside the colony
limits which are of larger and more substantial nature and meant to serve the needs
of a larger area than one colony like town level infrastructure work facilities etc.
External development works, which includes water supply, sewerage, roads, electrical
works, solid waste management disposal, colleges, hospitals, stadium etc. are to be
executed exclusively by the State Government and not by the colonizer. Section
3(3)(a)(ii) and the statutory agreement to be entered into between the colonizer and
the State Government would indicate that colonizer is required to deposit with the
Government the entire cost of external development works as quantified by the State
Government, cost of the same invariably passed on by the colonizer to the plot
holders/apartments owners on pro-rata basis. Further, the responsibility for theDlf Limited vs Manmohan Lowe & Ors on 10 December, 2013

maintenance and upkeep of all roads, open spaces, public parks and public health
services for a period of five years is on the Colonizer from the date of issue of the
completion certificate.
23. We may now examine the most crucial issue with regard to the scope of Section
3(3)(a)(iv) of the Development Act. As per the said provision, an obligation is cast on
the colonizer to construct “at its own cost” or get constructed by any other institution
or an individual at its own cost, schools, hospitals, community centers and other
community buildings on the land set apart for the said purpose. In the alternative,
the colonizer can also transfer to the Government, at any time, if so decided by the
Government, free of cost, the land set apart for schools, hospitals, community centers
and community buildings, in which case, the Government shall be at liberty to
transfer such land to any person or institution, including a local authority on such
terms and conditions, as it may deem fit. In such situation, the cost of construction
can either be met by the Government or by the transferee of the Government. The
cost incurred in discharging the obligations under Section 3(3)(a)(iv), as already
indicated, has to be borne either by the colonizer or, on transfer of the land free of
cost, by the Government or the Government transferee.
The cost incurred for construction, in that event, cannot be passed on or recovered from the plot
holders/apartment owners in the colony.
24. Section 3(3)(a)(iv) obliges the colonizer to construct at his own cost schools, hospitals,
community centers and other buildings on the lands set apart for that purpose, or also can get them
constructed by any other institution or an individual, at its own cost, but the ownership of land set
apart for the said purpose continues with the colonizer. Option is also provided under Section
3(3)(a)(iv) to the colonizer to transfer to the Government, at any time, if so desired by the
Government, free of cost, the land set apart for schools, hospitals, community centers and
community buildings, in which case, the Government shall be at liberty to transfer such land to any
person or institution, including a local authority on such terms and conditions as it may deem fit.
But, the ownership of the Colonizer cannot be transferred or divested, unless the colonizer
volunteers to transfer the same free of cost to the Government. The colonizer has taken a specific
ground in this appeal that even before filing the writ petition, they had already transferred its right
to construct two nursery schools, community center and the shops in Silver Oaks Group Housing to
third parties and it is for the third parties to construct the same, though ownership of the land vests
with the colonizer.
25. Community and other facilities like schools, hospitals, community centers, shops etc. provided
in the land set apart under Section 3(3)(a)(iv) are, therefore, meant for the benefit of the entire
colony and not for the apartment owners in one part of the colony and the costs incurred in
discharge of the statutory obligations cannot be passed on/transferred from the plot
owners/apartment owners by the colonizer. The facilities to be provided under Section 3(3)(a)(iv)
are based on the prescribed norms which are population based and the number of each type of
amenity and its placement at various places in the colony (plotted areas or group housing) are, asDlf Limited vs Manmohan Lowe & Ors on 10 December, 2013

per the lay-out plans duly approved by the DTCP under the Development Act. DTCP has prescribed
the requirement for each amenity/commercial facility for DLF City Phase I, II & III, comprising of a
total area of 1542 acres, under a composite layout plan of all the three phases, treating three phases
as a single colony. As per the approved layout plans, these amenities are earmarked at various sites
in the colony, some in the plotted areas and some in the group housing areas. So far as the present
case is concerned, we notice that the layout plans pertaining to lands covered under various licenses
in the colony are not restricted to 130 acres alone, wherein Silver Oaks Group Housing is located in
14.75 acres.
26. In Ansal Properties and Industries Limited. V. State of Haryana and Another (2009) 3 SCC 553,
this Court had occasion to examine the scope of Section 3(3)(a)(iv) along with the Regulations Act.
In that case, the Court held as follows:
“42. The responsibility regarding construction of community centres and other
community buildings could be discharged by adopting any of the three options as
mentioned hereinbefore and each one of such options is an independent option and
one cannot be connected and related with the other. We cannot read the provision
relating to construction at the own cost of the developer the schools, hospitals,
community centres and other community buildings on the land set apart for this
purpose, into an independent alternative provision relating to transfer of such land to
the Government free of cost. The aforesaid option given to the developer to construct
the community centres and other community buildings at its own cost is when he can
utilise himself to manage it. Therefore, we cannot read the aforesaid provision in the
manner sought to be read by Mr Chaudhari, for reading by adding certain words in
the aforesaid manner does not appear to be the intention of the legislature while
enacting the aforesaid legislation, for otherwise the legislature would have explicitly
said so in the body of the main part of the section itself.
In that case, the State Government sought to recover the cost of construction over the
land set apart for providing facilities which were taken over by the Government as
part of “external development charges”. This Court held that Section 3(3)(a)(iv) only
provides for the land to be transferred to the State and no provision of the Act
authorizes the State Government to recover charges towards cost of construction.
27. Later, in DLF Qutub Enclave Complex Educational Charitable Trust v. State of Haayana and
Others (2003) 5 SCC 622, while dealing with the scope of the above mentioned provision, this Court
held as follows:
“34. At the outset, we may notice that the cost of development works indisputably is
to be raised from the plot-holders, but as construction of schools, hospitals,
community centres and other community buildings do not come within the purview
of the term “development works”, the costs therefore are not to be borne by them.Dlf Limited vs Manmohan Lowe & Ors on 10 December, 2013

35. The expression “development works” as noticed hereinbefore is not synonymous
with “amenity”. The expression “amenity” has been used only in the proviso
appended to sub-clause (v) of Section 3(3)(a) and Rule 2(b) of the Rules. Rules are
subservient to the Act, although they may be read conjointly with the Act, if any
necessity arises therefor. Even Rule 5 specifies the obligation of the colonizer as
regard providing for the development works. The expression “amenity” as defined in
Rule 2(b) of the Rules is wider than “development works”. No principle of
construction of statute suggests that a wider expression used in the rule may be read
in the statute employing narrower expression. Even in the rule the said expressions
have been used for different purposes. The licence also does not postulate that all
amenities must be provided by the colonizer at its own expense. If the terms
“development works” and “amenity” are treated as carrying the same meaning, the
plot-
holders may be held to be bound to meet the costs for construction of schools, hospitals, community
centres etc. The cost of construction in terms of the said provisions thereof is to be borne by DLF or
its nominees.
36. Right of transfer of land is indisputably incidental to the right of ownership. Such a right can be
curtailed or taken away only by reason of a statute. An embargo upon the owner of the land to
transfer the same in the opinion of this Court should not be readily inferred. Section 3(3)(a)(iv) of
the Act does not expressly impose any restriction. The same is merely a part of an undertaking. …..”
28. We have to now examine the rights of apartment owners over the facilities referred to in Section
3(3)(a)(iv) of the Development Act in the light of the Apartment Act. As already indicated, it is the
obligation of the colonizer to construct schools, community centers and commercial facilities on the
lands set apart for that purpose in the colony under Section 3(3)(a)(iv) of the Development Act and
also on the basis of agreement executed between the colonizer and the DTCP. No obligation is cast
on the colonizer under the Apartment Act or the Rules framed thereunder to provide those facilities
which are specifically mentioned under Section 3(3)(a)(iv) of the Development Act. But the
Colonizer has to provide various other facilities like “common areas and facilities”, to the apartment
owners, as provided under the Apartment Act. In this regard, reference may be made to certain
provisions of the Apartment Act.
The Apartment Act:
29. Section 3(a) of the Apartment Act deals with the word “apartment”, which reads as follows:
“3(a). “Apartment” means a part of the property intended for any type of independent
use, including one or more rooms or enclosed spaces located on one or more floors or
part or parts thereof, in a building, intended to be used for residential purposes and
with a direct exit to a public street, road or highway or to a common area leading to
such street, road or highway.” Section 3(b) defines the term “apartment owner”
which reads as follows:Dlf Limited vs Manmohan Lowe & Ors on 10 December, 2013

“3(b) “Apartment owner” means the person or persons owning an apartment and
undivided interest in the common areas and facilities in the percentage specified and
established in the declaration.” Section 3(f) defines the term “common areas and
facilities” which reads as follows:
“3(f) “Common areas and facilities: unless otherwise provided in the declaration or
lawful amendments thereto means-
1) the land on which the building is located;
2) the foundations, columns, girders, beams, supports, main walls, roofs, halls,
corridors, lobbies, stairs, stair ways, fire escapes and entrances and exits of the
building;
3) the basements, cellars, yards, gardens, parking area and storage spaces;
4) the premises for the lodging of janitors or persons employed for management of
the property;
5) installation of central services such as power, light, gas, hot and cold water,
heating refrigeration, air conditioning and incinerating;
6) the elevators, tanks, pumps, motors, fans compressors, ducts and in general all
apparatus and installations existing for common use;
7) such community and commercial facilities as may be provided for in the
declaration; and
8) all other parts of the property necessary or convenient to its existing maintenance
and safety or normally in common use.” Section 3(h) defines the term “common
profits” which reads as follows:
“3(h). “Common profits” means the balance of all income, rents, profits and revenues
from the common areas and facilities remaining after the deduction of the common
expenses.” Section 3(j) defines the word “declaration” which reads as under;
“3(j). “Declaration” means the instrument to be executed and got registered in the
prescribed form and includes the amended declaration.” Section 4 of the Act deals
with the “status of apartments” which reads as under:
“4. Status of apartments.- Each apartment, together with its undivided interest in the
common areas and facilities, appurtenant to such apartment, shall for all purposes
constitute heritable and transferable immovable property within the meaning of any
law for the time being in force in the State of Haryana.” Section 5 of the Act dealsDlf Limited vs Manmohan Lowe & Ors on 10 December, 2013

with “Ownership of apartments” which reads as follows:
‘5. Ownership of apartments.- (1) Each apartment owner shall be entitled to the
exclusive ownership and possession of his apartment in accordance with the
declaration.
(2) Each apartment owner shall execute a deed of apartment in relation to his
apartment in the manner prescribed.”
30. The status of apartments together with its undivided interest in common areas and facilities,
appurtenant to such apartment, shall for all purposes constitute heritable and transferable
immovable property and each apartment owner shall be entitled to the exclusive ownership and
possession of his apartment in accordance with the declaration.
31. Section 6 of the Act deals with “common areas and facilities” which reads as follows:
“6. Common areas and facilities. – (1) Each apartment owner shall be entitled to an
undivided interest in the common areas and facilities in the percentage expressed in
the declaration. Such percentage shall be computed by taking as a basis the value of
the apartments in relation to the value of the property; and such percentage shall
reflect the limited common areas and facilities.
(2) The percentage of the undivided interest of each apartment owner in the common
areas and facilities as expressed in the declaration shall have a permanent character
and shall not be altered without the consent of all the apartment owners and
expressed in an amended declaration duly executed and registered as provided in this
Act. The percentage of the undivided interest in the common areas and facilities shall
not be separated from the apartment to which it appertains and shall be deemed to be
conveyed or encumbered with the apartment even though such interest is not
expressly mentioned in the conveyance or other instrument.
(3) The common areas and facilities shall remain undivided and no apartment owner
or any other person shall bring any action for partition or division of any part thereof
unless the property has been removed from the provisions of this Act as provided in
Sections 14 and 22. Any covenant to the contrary shall be null and void.
(4) Each apartment owner may use the common areas and facilities in accordance
with the purpose for which they are intended without hindering or encroaching upon
the lawful rights of the other apartment owners.
(5) The necessary work of maintenance, repair and replacement of the common areas
and facilities and the making of any addition or improvements thereto shall be
carried out as provided herein and in the bye-laws.Dlf Limited vs Manmohan Lowe & Ors on 10 December, 2013

(6) The association of apartment owners shall have the irrevocable right, to be
exercised by the Manager or Board of Managers thereof, to have access to each
apartment from time to time during reasonable hours as may be necessary for the
maintenance, repair and replacement of any of the common areas and facilities
therein or accessible there from or for making emergency repairs therein necessary to
prevent damage to the common areas and facilities or to another apartment or
apartments.” Declaration:
32. The Apartment Act casts an obligation on the colonizer to file a statutory declaration. Section 6
read with Section 3(f) of the Apartment Act clearly indicates that clauses 1 to 8, except 7 of Section
3(f) are to be provided by the colonizer to the apartment owners and each apartment owner is
entitled to an undivided interest in the common areas and facilities, in the percentage expressed in
the declaration. The only exception is clause 7, which gives a right to the colonizer either to provide
or not to provide in the declaration, the community and commercial facilities referred to in Section
3(3)(a)(iv) of the Development Act. There is a marked difference between “common areas and
facilities” and “community and commercial facilities”. A colonizer is duty bound to provide all the
common areas and facilities as per Section 3(f), except community and commercial facilities
referred to in Section 3(f)(7). “Common areas and facilities” referred to in Section 3(f)(7) of the
Apartment Act has a co-relation with the “Community and Commercial facilities” referred to in
Section 3(3)(a)(iv) of the Development Act. It is for that reason that a discretion has been given to
the colonizer to either provide the same or not to provide the same in the declaration referred to in
Section 3(f) of the Apartment Act. The expression “may” used in Section 3(f)(7) of the Apartment
Act clearly indicates that no duty is cast on the colonizer to give an undivided interest over those
community and commercial facilities exclusively to the apartment owners of a particular colony,
since the same have to be enjoyed by other apartment owners of DLF City, Phase I, II and III as well.
Even otherwise, the colonizer could not have parted with his ownership rights exclusively to one
Colony alone.
33. Section 11 of the Act deals with “contents of declaration” which is extracted below:
“11. Contents of declaration – (1) The declaration shall contain the following
particulars, namely :-
a) description of land on which the building and improvements are to be located and
whether the land is freehold or leasehold;
b) description of the building stating the number of storeyes and basement, the
number of apartments and the principal materials of which it is or is to be
constructed;
c) the apartment number of each apartment and statement of its location,
approximate area, number of rooms and immediate common area to which it has
access and any other data necessary for its proper identification;Dlf Limited vs Manmohan Lowe & Ors on 10 December, 2013

d) description of the limited common area and facilities;
e) description of the limited common area and facilities, if any, stating to which
apartment their use is reserved;
f) value of the property and of each apartment and the percentage of undivided
interest in the common areas and facilities appertaining to each apartment and its
owner for all purposes, including voting and a statement that the apartment and such
percentage of undivided interest are not encumbered in any manner whatsoever or
not on the date of the declaration;
g) statement of the purposes for which the building and each of the apartments are
intended and restricted as to use;
h) the name of a person to receive service of process in the cases hereinafter
provided, together with the residence or place of business of such persons which shall
be within the city, town or village in which the building is located;
i) provisions as to the percentages of votes by the apartment owners which shall be
determinative of whether to rebuild, repair, restore or sell the property in the event of
damage or destruction of all or part of the property;
j) any other details in connection with the property which the person executing the
declaration may deem desirable to set forth consistent with this Act; and
k) The method by which the declaration may be amended consistent with the
provisions of this Act.
(2) A true copy of each of the declaration and bye-laws and all amendments to the
declaration or the bye-laws shall be filed in the office of the competent authority.”
“Contents of deed of apartment” is dealt with in Section 12 of the Act which reads as
follows:
“12. Contents of deed of apartment. – (1) The deed of apartment shall include the
following particulars, namely :-
a) a description of the land as provided in Section 11 or the postal address of the
property, including in either case the number, page and date of executing the
declaration, the date and serial number of its registration under the Indian
Registration Act, 1908 and the date and other reference, if any, of its filing with the
competent authority;
b) the apartment number of the apartment in the declaration and any other data
necessary for its proper identification;Dlf Limited vs Manmohan Lowe & Ors on 10 December, 2013

c) statement of the use for which the apartment is intended and restrictions on its
use, if any;
d) the percentage of undivided interest appertaining to the apartment in the common
areas and facilities; and
e) any further details which may be desirable to set forth consistent with the
declaration and this Act.
(2) A true copy of every deed of apartment shall be filed in the office of the competent
authority.”
34. Section 13 of the Act states that the declaration and all amendments thereto and the deed of
apartment in respect of each apartment and the floor plan of the building referred to in sub- section
(2) shall be registered under the Indian Registration Act.
35. If we scan through the above mentioned provisions, what is discernible is that each apartment
owner shall be entitled to an undivided interest in the common areas and facilities in the percentage
expressed in the declaration and such percentage shall be computed by taking as a basis the value of
the apartment in relation to the value of the property. Common areas and facilities shall also remain
undivided and the apartment owner or any other person can use the common areas and facilities in
accordance with the purpose for which they are intended without entering or encroaching upon the
rights of other apartment owners. Apartment owners are entitled to an undivided interest in the
common areas and facilities in the percentage expressed in the declaration, within the meaning of
Section 3(f) (1) to (6) and (8) and it is also open to the colonizer to provide, at its own cost, the
community and commercial facilities referred to in clause 7 of Section 3(f) read with Section
3(3)(f)(iv) of the Development Act by including them in the declaration. Colonizer cannot also,
under certain circumstances, confer any undivided interest to an exclusive set of apartment owners
to the detriment of similar apartment owners, who have apartments in other phases of a larger
colony or city. Apartment owners are, therefore, not entitled to an undivided interest or possession
over those community and commercial facilities, referred to in Section 3(3)(a)(iv) of the
Development Act, unless specifically provided by the colonizer in the statutory declaration.
Ownership Vs. User:
36. We have clearly indicated that the ownership right over the land earmarked for schools,
hospitals, community centers and other community buildings referred to in Section 3(3)(a)(iv) of
the Development Act vests on the colonizer. That ownership can be divested, as already indicated,
by the colonizer through a declaration under Sections 11 to 13 read with Section 3(f) of the
Apartment Act. The colonizer has to provide those facilities in discharge of its legal obligations
under the Development Act and the Act itself has recognized its or his legal ownership over the area
set apart for those facilities under Section 3(3)(a)(iv) of the Act. All the same, the right to enjoy
those facilities referred to in Section 3(3)(a)(iv) of the Development Act, whether shown in the
declaration or not, under the Apartment Act, cannot be restricted or curtailed and the apartmentDlf Limited vs Manmohan Lowe & Ors on 10 December, 2013

owners have no other right, except the right of “user”. Community centers, nursery schools, shops
etc., therefore, being part of the approved layout plans by the DTCP, can be used by the apartment
owners and, being part of the larger colony, are intended for independent use of all the apartment
owners having direct exit to common areas, to the public street, road, etc. All those facts would
indicate, so far as apartment owners are concerned, they have only a right of user, so far as the
facilities provided under Section 3(3)(a)(iv) of the Development Act are concerned.
37. Learned counsel for respondents sought to argue that the Silver Oaks Apartments is a ‘gated’
colony and, therefore, the developments which have taken place inside the boundary walls of that
colony are to be treated as parts of internal development works and, therefore, these are parts of
common areas. In this very direction, it was further submitted that these are the necessary and
essential facilities which have to be provided to the flat owners by the developers, for the common
use of the flat owners. Though, this argument appears to be attractive, it has no merit when we
examine the nature of structures developed by the developer i.e. the appellant to which it is claiming
its exclusive right. These structures are two nursery schools, three shops and one community centre,
which cannot be treated as “common areas and facilities” within the definition of Section 3(f) of the
Act. As already pointed out above, they are parts of planning for larger area, which plans were
submitted by the appellant. It is not meant for the exclusive use of the flat owners of Silver Oaks
Apartments. Position would have been different had these been integral parts of the facilities, in the
sense that these facilities are essential for the enjoyment of the flats.
38. Common passages, staircases, lifts etc. are the examples of such common areas and facilities.
Likewise, stilt parking area may be treated as part of common areas and facilities, in certain
circumstances. Here these structures are the part of the larger area of about 130 acres in respect of
which 7 licenses were obtained for development of the colony. Silver Oaks Apartments, which
comprises of 14.75 acres, is only a part thereof. The nursery schools, shops and community centre
are meant for the development of the entire colony and are not confined only to these apartments,
as already noted in detail above. Further, as per our detailed discussion hereinabove, it is clear that
the developer is given right to transfer these “community buildings and community centers”.
Likewise, even schools cannot be termed as part of “integral development” use whereof would be
confined to residents of these apartments. Even the shops which are inside the boundary walls have
their opening from outside to enable the shopkeepers to cater to the customers not only from these
apartments, but outsiders as well. Therefore, on these facts, we are not impressed by the argument
predicated on “gated colony”.
Cost not on Apartment owners:
39. We have found that the Colonizer is legally obliged under Section 3(3)(a)(iv) of the Act to
construct at his own cost the community and commercial facilities stipulated therein and an
agreement has to be entered into by the Colonizer with the DTCP under the Development Act by
which the Colonizer is prohibited by law from recovering the cost of providing those facilities from
the apartment owners. The operative portion of the agreement executed by the colonizer reads as
follows:Dlf Limited vs Manmohan Lowe & Ors on 10 December, 2013

“j) That only convenient shopping sufficient for requirement of the Group Housing
will be allowed which shall be approximate one shop per one thousand persons,
covering a maximum area of 200 sq. ft. per shop.
k) That adequate educational, health, recreational and cultural amenities to the
norms and standards provided in the respective Development plan of the area shall
be provided.
The owner shall at his own cost construct the primary-cum- nursery school, community
building/dispensary and first aid centre on the land set apart for this purpose, or if so desired by the
Govt. shall transfer to the Govt. at any time free of cost land thus set apart for primary cum nursery
school, community building/dispensary and first aid centre, in which case the Govt. shall be at
liberty to transfer such land to any person or instruction including a local authority on such terms
and conditions as it may lay down.
o) That the owner shall abide by the provisions of the Haryana Apartment and Ownership Act, 1983.
p) That the responsibility of the ownership of the common areas and facilities as well as their
management and maintenance shall continue to vest with the colonizer till such time the
responsibility is transferred to the owners of the dwelling units under the Haryana Apartment and
Ownership Act, 1983.”
40. Section 3(3)(a)(iv) of the Development Act read with the above- mentioned clauses in the
agreement would indicate that ownership of the portion of the land set apart for the common areas
and facilities referred to therein vest with the Colonizer so also the obligation “at his own cost” to
provide those facilities in the land set apart for the said purpose. The Colonizer cannot recover cost
of land or the amounts spent by him for providing those facilities from the apartment owners. It is
for the said reason that clause 7 of Section 3(f) of the Apartment Act has not made it obligatory, on
the part of the Colonizer to include the “community and commercial” facilities in the declaration. If
the colonizer includes the same within the declaration, then Section 6 of the Apartment Act will kick
in, consequently, the apartment owners would be entitled to the undivided interest in respect of the
community and commercial facilities provided therein without bearing the cost incurred by the
colonizer in purchasing the land and the cost of construction. In our view, the colonizer could not
have included the community and commercial facilities referred to in Section 3(3)(a)(iv) of the
Development Act, because the same is meant for the benefit of the entire colony, not merely the
flat/apartment owners in one part of the colony since they form part of the lay out plans duly
approved, which takes in plotted area and the group housing societies area as well.
41. We have also gone through the Apartment Buyer’s agreement/conveyance deed. The exact extent
of area sold by the colonizer to an apartment owner is mentioned therein. The operative portion of
the same reads as follows:
“1. That the Company hereby agrees to sell and the Apartment Allottee hereby agrees
to acquire the said premises as detailed below at the rate mentioned against it andDlf Limited vs Manmohan Lowe & Ors on 10 December, 2013

upon the terms and conditions set out hereunder as mutually agreed by and between
the parties thereto.
           Particulars      Apartment    Super Area  Rate (s) per
           i.e. Bldg. No.   No.             (Appx)       sq meter
                121            82        98.28 sq. mtr.   Rs.6189/-
3(a) That the Apartment Allottee agress that the Super Area for the purpose of
calculating the sale price in respect of the said premises shall be inclusive of the area
under the periphery walls, area under columns and walls within the Apartment, half
of the area of the walls common with other apartments adjoining the said apartment
and also proportionate share of the common area in the building i.e. stairs, ramps,
walk ways, lobbies, lift wells, shafts and the like…….”
42. Considerable reliance was placed by the apartment owners on the Judgment of this Court in
Naharchand Laloochand Private Limited (supra). First of all, the Judgment is not at all dealing with
the community and commercial facilities in a group housing society with reference to the provisions
of Section 3(3)(a)(iv) of Development Act. The above-mentioned Judgment was delivered in the
context of the Maharashtra Ownership of Flats Act, 1963 (MOFA) and the Development Control
Regulation (DCR) framed under the Maharashtra Regional Town Planning Act, 1966. In that case
this Court was required to examine as to whether a stilt parking can be considered to be a garage
under the definition of “flat” under MOFA. As per the format provided under MOFA only a “flat” or
“dwelling unit” or “shop” or “garage” can be sold by a developer. Stilt parking could not be
separately sold in terms of the provisions of the MOFA, a statutory format of the agreement and the
provisions of the DCR. Such a restriction is not there either under the 1975 Regulation Act or the
Apartment Act and there is no occasion to consider whether stilt parking can be sold along with the
apartment. In any view, the present case is not concerned with the question of stilt parking. We are
in this case, pointedly concerned with the facilities provided under Section 3(3)(a)(iv) of
Development Act, consequently, the reasoning of Naharchand Laloochand Private Limited (supra)
are inapplicable to the facts of this case, if examined in the light of the Regulation Act and the
Apartment Act.
Competent Authority:
43. We are also of the view that the High Court has committed an error in directing the DTCP to
decide the objections of the apartment owners with regard to the declaration made by the colonizer.
The Competent Authority is defined under Section 3(i) of the Apartment Act. Section 11(2) provides
for filing of declaration in the office of the Competent Authority. Section 24A of the Act prescribes
penalties and prosecution for failure to file a declaration and Section 24B permits the prosecution
only with the sanction of the Competent Authority. In a given case if the developer does not provide
common areas or facilities like corridors, lobbies, staircases, lifts and fire escape etc. the CompetentDlf Limited vs Manmohan Lowe & Ors on 10 December, 2013

Authority can look into the objections of the apartment owners but when statute has given a
discretion to the colonizer to provide or not to provide as per Section 3(f)(7) of the Apartment Act
the facilities referred to in Section 3(3)(a)(iv) of Development Act, in our view no objection could be
raised by the apartment owners and they cannot claim any undivided interest over those facilities
except the right of user. In the instant case the apartment owners have raised no grievance that they
are being prevented from using the community and commercial facilities referred to in Section
3(3)(a)(iv) of Regulation Act, but they cannot claim an undivided interest or right of management
over them.
44. We may also refer to the contention raised by the apartment owners that the Judgment in DLF
Qutab Enclave (supra) is not applicable in view of the Haryana Development and Regulation of
Urban Areas (Management) Act, 2003 which came into force on 03.04.2003. We have gone through
the amended definition of “external development works”. By virtue of the amendment, the scope of
the said expression has been widened and the State Government has given a wider discretion in
expending the amount collected from the colonizer as external development charges. The
Amendment Act does not seek to transfer an obligation of actually carrying out the external
development work upon the colonizer. The Statement of Objects and Reasons of the Bill of 2003
which led to the amendment indicates that though the various decisions of the High Court have
gone in favour of the Department, the amendment was necessitated to make certain provisions more
comprehensive. In other words, the amendment has no effect on the Judgment of this Court in DLF
Qutab Enclave (supra).
45. We are of the view that the High Court has not properly appreciated or applied the various
statutory provisions of the Regulation Act and the Rules framed thereunder, the terms of licences
issued, agreements executed between the colonizer and the DTCP vis-à- vis the various provisions of
the Apartment Act, the statutory declaration made by the colonizer and the Sale Deeds executed
between the parties. In such circumstances, we are inclined to set aside the judgment of the High
Court and dismiss the writ petition filed before the High Court. The appeal is, therefore allowed.
However, there will be no order as to costs. Applications for intervention are allowed.
Contempt Petition (Civil) No. of 2013(D.No.29500/12)
46. The interim orders passed by this Court are merged in the aforesaid judgment. In such
circumstances, no further orders are necessary in the Contempt Petition and the same is disposed of
accordingly.
……..……………………..J. (K.S. Radhakrishnan) ……………………………J. (A.K. Sikri) New Delhi,
December 10, 2013.Dlf Limited vs Manmohan Lowe & Ors on 10 December, 2013

